"""Runnable screening workflow for fully GAP-FILLED trench removal.

The functions in this module connect the independently testable model layers:

* thermal resistance and a flat-front 1-D baseline;
* quasi-steady 2-D reaction--diffusion with a conservative level-set front;
* product/passivation-aware local surface chemistry and multi-step WET state;
* rejection-free graph KMC and a coarse event-flux-to-velocity mapping.

Every kinetic value below is deliberately marked as an uncalibrated smoke-test
value.  The workflow is for code verification and sensitivity wiring, not for
predicting a fab process or prescribing chemical conditions.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Iterable

import numpy as np

from coupled_rate_laws import (
    ThermalArrheniusRateLaw2D,
    ThermalArrheniusRateParameters,
)
from etch_process import (
    EtchProcessConfig,
    GapFillMaterial,
    ThermalBoundaryConditions,
)
from flat_front_1d import (
    FlatFrontEtchSolver,
    IntegrationOptions,
    InterfaceKinetics,
    MassTransportParameters,
    PassivationParameters as FlatFrontPassivationParameters,
)
from gapfill_etch_2d import (
    GapFillEtch2D,
    PassivationParameters as PassivationParameters2D,
    TransportParameters as TransportParameters2D,
)
from graph_kmc import AmorphousGraph, EventTemplate, GraphKMC, GraphSite
from numerical_settings import LOOSE_NUMERICS
from surface_chemistry import (
    LocalInterfaceConditions,
    MeanFieldSurfaceChemistry,
    MeanFieldSurfaceState,
)
from thermal_model import NM_TO_M, ThermalResistanceModel
from trench_geometry import GEOMETRY_PRESETS, get_geometry_preset
from wetting_2d import WettingParameters
from wet_sequence import (
    MeanFieldSolverAdapter,
    StepStateSemantics,
    WetProcessState,
    WetSequenceRunner,
    WetStep,
    get_mechanism_preset,
)


UNCALIBRATED_NOTICE = (
    "Uncalibrated screening parameters only; not a wet-process recipe or a "
    "predictive material model. Fit transport, speciation, thermal, and kinetic "
    "parameters to the actual deposited SiN/SiCN/SiOCN film before interpretation."
)


@dataclass(frozen=True)
class ScreeningConfig:
    """Small, plain configuration object; no hashes or content-addressed files."""

    geometry: str = "10_10_180"
    material: str = "SiN"
    solution_bulk_temperature_K: float = 298.15
    substrate_backside_temperature_K: float = 323.15
    duration_s: float = 2.0
    grid_spacing_nm: float = 1.0
    reservoir_height_nm: float = 10.0
    random_seed: int = 42
    kmc_sites: int = 24
    kmc_max_events: int = 48
    wetting_enabled: bool = False
    wetting_new_void_filling_mode: str = "liquid_inherited"
    advancing_contact_angle_deg: float = 60.0
    entrance_wetting_delay_s: float = 0.0
    entrance_pinning_pressure_Pa: float = 0.0
    reservoir_overpressure_Pa: float = 0.0
    maximum_contact_line_speed_nm_s: float | None = None
    bottom_gas_pocket_seed_height_nm: float = 0.0
    bottom_gas_activation_depth_fraction: float = 0.90
    gas_dissolution_time_s: float | None = None
    gas_residual_fraction: float = 0.0
    gas_compression_mode: str = "ideal"

    def __post_init__(self) -> None:
        if self.geometry not in GEOMETRY_PRESETS:
            choices = ", ".join(GEOMETRY_PRESETS)
            raise ValueError(f"geometry must be one of {choices}")
        GapFillMaterial(self.material)
        for name in (
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
            "duration_s",
            "grid_spacing_nm",
            "reservoir_height_nm",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if not isinstance(self.random_seed, int):
            raise TypeError("random_seed must be an integer")
        if not isinstance(self.kmc_sites, int) or self.kmc_sites < 2:
            raise ValueError("kmc_sites must be an integer >= 2")
        if not isinstance(self.kmc_max_events, int) or self.kmc_max_events < 0:
            raise ValueError("kmc_max_events must be a non-negative integer")
        if not isinstance(self.wetting_enabled, bool):
            raise TypeError("wetting_enabled must be boolean")
        # Delegate coupled wetting validation to its canonical parameter type.
        self.wetting_parameters()

    def to_dict(self) -> dict[str, object]:
        return asdict(self)

    def wetting_parameters(self) -> WettingParameters:
        return WettingParameters(
            enabled=self.wetting_enabled,
            new_void_filling_mode=self.wetting_new_void_filling_mode,  # type: ignore[arg-type]
            advancing_contact_angle_deg=self.advancing_contact_angle_deg,
            entrance_delay_s=self.entrance_wetting_delay_s,
            entrance_pinning_pressure_Pa=self.entrance_pinning_pressure_Pa,
            reservoir_overpressure_Pa=self.reservoir_overpressure_Pa,
            maximum_contact_line_speed_nm_s=(
                self.maximum_contact_line_speed_nm_s
            ),
            bottom_gas_pocket_seed_height_nm=(
                self.bottom_gas_pocket_seed_height_nm
            ),
            bottom_gas_activation_depth_fraction=(
                self.bottom_gas_activation_depth_fraction
            ),
            gas_dissolution_time_s=(
                math.inf
                if self.gas_dissolution_time_s is None
                else self.gas_dissolution_time_s
            ),
            gas_residual_fraction=self.gas_residual_fraction,
            gas_compression_mode=self.gas_compression_mode,  # type: ignore[arg-type]
            gas_temperature_K=self.solution_bulk_temperature_K,
        )


def build_process(config: ScreeningConfig) -> EtchProcessConfig:
    return EtchProcessConfig(
        geometry=get_geometry_preset(config.geometry),
        gap_fill_material=config.material,
        thermal_bc=ThermalBoundaryConditions(
            solution_bulk_temperature_K=config.solution_bulk_temperature_K,
            substrate_backside_temperature_K=config.substrate_backside_temperature_K,
        ),
    )


def thermal_bc_from_step(step: WetStep) -> ThermalBoundaryConditions:
    """Map WET names to canonical thermal names without averaging."""

    return ThermalBoundaryConditions(
        solution_bulk_temperature_K=step.solution_temperature_K,
        substrate_backside_temperature_K=step.substrate_temperature_K,
    )


def run_thermal_screening(
    process: EtchProcessConfig,
    thermal: ThermalResistanceModel,
) -> dict[str, object]:
    samples = []
    for fraction in (0.0, 0.5, 1.0):
        depth_m = fraction * process.geometry.depth_nm * NM_TO_M
        state = thermal.evaluate(depth_m, process.thermal_bc)
        samples.append(
            {
                "front_fraction": fraction,
                "front_depth_nm": depth_m / NM_TO_M,
                "interface_temperature_K": state.interface_temperature_K,
                "liquid_resistance_K_m_W": (
                    state.resistances.liquid_total_K_m_W
                ),
                "solid_resistance_K_m_W": state.resistances.solid_total_K_m_W,
                "energy_balance_residual_W_m": state.energy_balance_residual_W_m,
            }
        )
    return {
        "model": "parallel 1-D thermal resistance per out-of-plane span",
        "reaction_heat_flux_W_m2": 0.0,
        "samples": samples,
    }


def run_flat_front_screening(
    process: EtchProcessConfig,
    thermal: ThermalResistanceModel,
    duration_s: float,
) -> dict[str, object]:
    transport = MassTransportParameters(
        reactant_bulk_concentration_mol_m3=1000.0,
        reactant_diffusivity_ref_m2_s=1.0e-9,
        product_diffusivity_ref_m2_s=8.0e-10,
        reference_temperature_K=298.15,
        reactant_diffusion_activation_energy_J_mol=12_000.0,
        product_diffusion_activation_energy_J_mol=12_000.0,
    )
    kinetics = InterfaceKinetics(
        rate_constant_ref_m_s=5.0e-9,
        solid_molar_density_mol_m3=5.0e4,
        reactant_stoichiometry_mol_per_mol_solid=1.0,
        product_yield_mol_per_mol_solid=1.0,
        activation_energy_J_mol=20_000.0,
        reference_temperature_K=298.15,
        reaction_heat_release_J_mol_solid=0.0,
    )
    passivation = FlatFrontPassivationParameters(
        formation_rate_ref_s_inv=2.0e-3,
        removal_rate_ref_s_inv=5.0e-4,
        product_reference_concentration_mol_m3=100.0,
        product_order=1.0,
    )
    solver = FlatFrontEtchSolver(
        process,
        thermal,
        transport,
        kinetics,
        passivation=passivation,
        options=IntegrationOptions(
            relative_tolerance=LOOSE_NUMERICS.linear_relative_tolerance,
            absolute_tolerance=LOOSE_NUMERICS.linear_absolute_tolerance,
            maximum_time_step_s=LOOSE_NUMERICS.maximum_time_step_s,
        ),
    )
    result = solver.solve(duration_s)
    return {
        "units": {
            "length": "nm in summary; SI internally",
            "concentration": "mol/m^3",
            "time": "s",
        },
        "parameters": {
            "reactant_bulk_concentration_mol_m3": (
                transport.reactant_bulk_concentration_mol_m3
            ),
            "rate_constant_ref_m_s": kinetics.rate_constant_ref_m_s,
            "solid_molar_density_mol_m3": kinetics.solid_molar_density_mol_m3,
            "activation_energy_J_mol": kinetics.activation_energy_J_mol,
        },
        "completed": result.completed,
        "completion_time_s": result.completion_time_s,
        "sample_count": int(result.time_s.size),
        "final_time_s": float(result.time_s[-1]),
        "front_depth_nm": float(result.front_depth_nm[-1]),
        "residual_fill_depth_nm": float(result.residual_fill_depth_nm[-1]),
        "passivation_fraction": float(result.passivation_fraction[-1]),
        "interface_temperature_K": float(result.interface_temperature_K[-1]),
        "reactant_interface_concentration_mol_m3": float(
            result.reactant_interface_concentration_mol_m3[-1]
        ),
        "product_interface_concentration_mol_m3": float(
            result.product_interface_concentration_mol_m3[-1]
        ),
        "etch_velocity_nm_s": float(result.etch_velocity_m_s[-1] / NM_TO_M),
        "solver_message": result.solver_message,
    }


def run_2d_screening(
    process: EtchProcessConfig,
    thermal: ThermalResistanceModel,
    config: ScreeningConfig,
) -> dict[str, object]:
    transport = TransportParameters2D(
        reactant_diffusivity_nm2_s=1.0e9,
        product_diffusivity_nm2_s=8.0e8,
        reactant_bulk_concentration=1000.0,
        reactant_surface_transfer_nm_s=10.0,
        product_bulk_concentration=0.0,
        product_yield_concentration=5.0e4,
        product_bulk_decay_per_s=0.02,
    )
    passivation = PassivationParameters2D(
        formation_per_concentration_s=1.0e-4,
        removal_per_s=1.0e-3,
    )
    model = GapFillEtch2D(
        process,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=max(2.0, config.grid_spacing_nm),
        transport=transport,
        passivation=passivation,
        wetting_parameters=config.wetting_parameters(),
        numerical_settings=LOOSE_NUMERICS,
    )
    thermal_rate = ThermalArrheniusRateLaw2D(
        model.grid,
        thermal,
        process.thermal_bc,
        ThermalArrheniusRateParameters(
            reference_maximum_velocity_nm_s=0.2,
            half_saturation_concentration=100.0,
            product_inhibition=1.0e-3,
            reference_temperature_K=298.15,
            activation_energy_J_mol=20_000.0,
        ),
    )
    # The grid is owned by GapFillEtch2D, so attach the grid-aware adapter after
    # construction rather than duplicating grid generation in the caller.
    model.rate_law = thermal_rate
    initial = model.front.diagnostics()
    result = model.run(
        config.duration_s,
        time_step_s=min(1.0, config.duration_s),
        snapshot_every_steps=10,
    )
    finite_temperatures = thermal_rate.last_interface_temperature_K[
        np.isfinite(thermal_rate.last_interface_temperature_K)
    ]
    last_history = result.history[-1] if result.history else None
    resolution_warning = None
    if config.grid_spacing_nm > 0.5:
        resolution_warning = (
            "screening grid is coarser than 0.5 nm; repeat at 0.5 and 0.25 nm "
            "before interpreting taper or bottom-residue trends"
        )
    return {
        "units": {
            "length": "nm",
            "diffusivity": "nm^2/s",
            "velocity": "nm/s",
            "concentration": "mol/m^3 for this workflow",
        },
        "grid": {
            "shape": list(model.grid.shape),
            "dx_nm": model.grid.dx_nm,
            "dz_nm": model.grid.dz_nm,
            "initial_area_discretization_relative_error": (
                initial.initial_area_discretization_relative_error
            ),
            "resolution_warning": resolution_warning,
        },
        "initial_condition": {
            "remaining_solid_area_nm2": initial.remaining_solid_area_nm2,
            "liquid_cells_in_trench": initial.liquid_cells_in_trench,
            "fully_gap_filled": initial.remaining_mass_fraction == 1.0,
        },
        "wetting": {
            "parameters": result.wetting_parameters.to_dict(),
            "final_diagnostics": (
                asdict(result.final_wetting_diagnostics)
                if result.final_wetting_diagnostics is not None
                else None
            ),
            "interpretation": (
                "liquid_inherited is the mass-consistent default for a fully "
                "filled GAP FILL; capillary dry cells and seeded bottom gas are "
                "explicit failure-mode hypotheses"
            ),
        },
        "completed": result.completed,
        "steps": len(result.history),
        "final_time_s": result.final_diagnostics.time_s,
        "remaining_solid_area_nm2": (
            result.final_diagnostics.remaining_solid_area_nm2
        ),
        "remaining_mass_fraction": result.final_diagnostics.remaining_mass_fraction,
        "dissolved_mass_fraction": result.final_diagnostics.dissolved_mass_fraction,
        "liquid_cells_in_trench": (
            result.final_diagnostics.liquid_cells_in_trench
        ),
        "interface_temperature_min_K": (
            float(np.min(finite_temperatures))
            if finite_temperatures.size
            else None
        ),
        "interface_temperature_max_K": (
            float(np.max(finite_temperatures))
            if finite_temperatures.size
            else None
        ),
        "last_step": (
            {
                "reactant_converged": last_history.reactant_converged,
                "product_converged": last_history.product_converged,
                "nonlinear_converged": last_history.nonlinear_converged,
                "nonlinear_iterations": last_history.nonlinear_iterations,
                "nonlinear_relative_change": (
                    last_history.nonlinear_relative_change
                ),
                "front_mass_balance_relative_error": (
                    last_history.front_mass_balance_relative_error
                ),
                "time_step_limiter": last_history.time_step_limiter,
                "wetting_stable_dt_s": last_history.wetting_stable_dt_s,
                "open_void_area_nm2": last_history.open_void_area_nm2,
                "wetted_area_nm2": last_history.wetted_area_nm2,
                "gas_area_nm2": last_history.gas_area_nm2,
                "contact_line_depth_nm": (
                    last_history.contact_line_depth_nm
                ),
                "meniscus_center_depth_nm": (
                    last_history.meniscus_center_depth_nm
                ),
                "capillary_pressure_Pa": (
                    last_history.capillary_pressure_Pa
                ),
                "bottom_gas_pocket_active": (
                    last_history.bottom_gas_pocket_active
                ),
                "gas_pressure_Pa": last_history.gas_pressure_Pa,
                "phase_partition_relative_error": (
                    last_history.phase_partition_relative_error
                ),
            }
            if last_history is not None
            else None
        ),
        "coupling_limitations": [
            "local-column thermal approximation with zero reaction heat",
            "reactant Robin sink and front velocity require joint calibration to close stoichiometry",
            "quasi-steady dilute scalar transport; contact angle and gas-pocket closures need nanoscale calibration",
            "seeded gas is an explicit dewetting/gas-generation failure mode, not spontaneous gas creation from solid GAP FILL",
        ],
    }


def _surface_models() -> dict[str, MeanFieldSurfaceChemistry]:
    models: dict[str, MeanFieldSurfaceChemistry] = {}
    rates = {
        "hf": 0.08,
        "rinse": 0.0,
        "phosphoric_like": 0.04,
        "oxidative_conversion": 0.06,
        "fluoride_after_oxidation": 0.10,
    }
    for key, rate in rates.items():
        preset = get_mechanism_preset(key)
        overrides: dict[str, float] = {}
        if key == "hf":
            overrides = {
                "product_yield": 0.25,
                "passivation_yield": 0.10,
                "product_release_s": 0.01,
                "passivation_removal_s": 0.005,
            }
        elif key == "rinse":
            overrides = {
                "product_release_s": 0.8,
                "passivation_removal_s": 0.4,
            }
        elif key == "phosphoric_like":
            overrides = {
                "product_release_s": 0.1,
                "passivation_removal_s": 0.1,
            }
        elif key == "oxidative_conversion":
            overrides = {"product_yield": 0.05}
        elif key == "fluoride_after_oxidation":
            overrides = {
                "product_release_s": 0.2,
                "passivation_removal_s": 0.2,
            }
        parameters = preset.calibrated_parameters(
            rate_constant_ref_s=rate,
            reference_temperature_K=298.15,
            activation_energy_J_mol=0.0 if key == "rinse" else 20_000.0,
            **overrides,
        )
        models[key] = MeanFieldSurfaceChemistry(parameters)
    return models


def _wet_steps(
    config: ScreeningConfig,
    strategy: str,
) -> tuple[WetStep, ...]:
    common = {
        "solution_temperature_K": config.solution_bulk_temperature_K,
        "substrate_temperature_K": config.substrate_backside_temperature_K,
        "solver_increment_s": min(0.5, config.duration_s),
    }
    hf = WetStep(
        name="primary_HF",
        mechanism="hf",
        duration_s=config.duration_s,
        solution_inputs={
            "reactant_activity": 1.0,
            "reactant_concentration": 1.0,
            "product_activity": 0.05,
            "product_concentration": 0.05,
        },
        **common,
    )
    rinse = WetStep(
        name="rinse",
        mechanism="rinse",
        duration_s=0.25 * config.duration_s,
        state_semantics=StepStateSemantics(
            solution="reset", surface="carry", substrate="carry"
        ),
        solution_inputs={
            "reactant_activity": 0.0,
            "reactant_concentration": 0.0,
            "product_activity": 0.0,
            "product_concentration": 0.0,
        },
        **common,
    )
    if strategy == "hf_then_second_wet":
        second = WetStep(
            name="second_WET",
            mechanism="phosphoric_like",
            duration_s=config.duration_s,
            solution_inputs={
                "reactant_activity": 1.0,
                "reactant_concentration": 1.0,
            },
            **common,
        )
        return (hf, rinse, second)
    if strategy == "hf_then_oxidation_fluoride":
        oxidation = WetStep(
            name="oxidative_conversion",
            mechanism="oxidative_conversion",
            duration_s=config.duration_s,
            solution_inputs={
                "reactant_activity": 1.0,
                "reactant_concentration": 1.0,
            },
            **common,
        )
        second_rinse = WetStep(
            name="post_oxidation_rinse",
            mechanism="rinse",
            duration_s=0.25 * config.duration_s,
            solution_inputs={
                "reactant_activity": 0.0,
                "reactant_concentration": 0.0,
            },
            **common,
        )
        fluoride = WetStep(
            name="fluoride_after_oxidation",
            mechanism="fluoride_after_oxidation",
            duration_s=config.duration_s,
            solution_inputs={
                "reactant_activity": 1.0,
                "reactant_concentration": 1.0,
            },
            **common,
        )
        return (hf, rinse, oxidation, second_rinse, fluoride)
    raise ValueError(f"unknown WET strategy {strategy!r}")


def run_wet_sequence_screening(
    process: EtchProcessConfig,
    thermal: ThermalResistanceModel,
    config: ScreeningConfig,
    strategy: str,
) -> dict[str, object]:
    models = _surface_models()

    def conditions(
        state: WetProcessState,
        step: WetStep,
    ) -> LocalInterfaceConditions:
        if not isinstance(state.surface_state, MeanFieldSurfaceState):
            raise TypeError("surface state must be MeanFieldSurfaceState")
        removed_fraction = 1.0 - state.surface_state.material_coverage
        representative_depth_m = (
            np.clip(removed_fraction, 0.0, 1.0)
            * process.geometry.depth_nm
            * NM_TO_M
        )
        interface_temperature = thermal.interface_temperature_K(
            float(representative_depth_m),
            thermal_bc_from_step(step),
        )
        solution = state.solution_state
        return LocalInterfaceConditions(
            temperature_K=interface_temperature,
            reactant_activity=float(solution.get("reactant_activity", 0.0)),
            product_activity=float(solution.get("product_activity", 0.0)),
            reactant_concentration=float(
                solution.get("reactant_concentration", 0.0)
            ),
            product_concentration=float(
                solution.get("product_concentration", 0.0)
            ),
        )

    adapter = MeanFieldSolverAdapter(
        model_resolver=lambda step: models[step.mechanism.key],
        condition_resolver=conditions,
        material=process.gap_fill_material.value,
    )
    steps = _wet_steps(config, strategy)
    result = WetSequenceRunner(adapter).run(
        WetProcessState(surface_state=MeanFieldSurfaceState()),
        steps,
    )
    final_surface = result.final_state.surface_state
    assert isinstance(final_surface, MeanFieldSurfaceState)
    return {
        "strategy": strategy,
        "state_owner": "mean-field surface chemistry only",
        "steps": [
            {
                "name": item.step.name,
                "mechanism": item.step.mechanism.key,
                "duration_s": item.step.duration_s,
                "solver_increment_s": item.step.solver_increment_s,
                "solution_temperature_K": item.step.solution_temperature_K,
                "substrate_temperature_K": item.step.substrate_temperature_K,
                "elapsed_s": item.elapsed_s,
                "stop_reason": item.stop_reason,
                "final_metrics": dict(item.final_metrics),
            }
            for item in result.step_results
        ],
        "total_elapsed_s": result.total_elapsed_s,
        "stop_reason": result.stop_reason,
        "final_surface_state": asdict(final_surface),
        "coverage_to_nm_note": (
            "coverage/s is not converted to nm/s without a calibrated reactive "
            "layer thickness or site inventory"
        ),
    }


def _kmc_temperature_factor(temperature_K: float, barrier_J_mol: float) -> float:
    gas_constant = 8.31446261815324
    exponent = -barrier_J_mol / gas_constant * (
        1.0 / temperature_K - 1.0 / 298.15
    )
    return math.exp(float(np.clip(exponent, -700.0, 700.0)))


def build_kmc(config: ScreeningConfig, interface_temperature_K: float) -> GraphKMC:
    sites = [
        GraphSite(
            site_id=index,
            material=config.material,
            attributes={
                "exposure": 1.0 if index == 0 else 0.08,
                "depth_fraction": index / (config.kmc_sites - 1),
            },
        )
        for index in range(config.kmc_sites)
    ]
    graph = AmorphousGraph(
        sites,
        [(index, index + 1) for index in range(config.kmc_sites - 1)],
    )

    def activation_rate(context) -> float:
        temperature_factor = _kmc_temperature_factor(
            float(context.environment["interface_temperature_K"]), 18_000.0
        )
        exposure = context.site.attributes["exposure"]
        exposed_neighbour = 0.7 * context.neighbour_fraction("removed")
        return (
            0.5
            * float(context.environment["reactant_activity"])
            * temperature_factor
            * (exposure + exposed_neighbour)
        )

    def removal_rate(context) -> float:
        temperature_factor = _kmc_temperature_factor(
            float(context.environment["interface_temperature_K"]), 24_000.0
        )
        product = float(context.environment["product_activity"])
        return 0.8 * temperature_factor / (1.0 + 2.0 * product)

    events = (
        EventTemplate(
            "activate",
            "intact",
            "activated",
            activation_rate,
            dependency_radius=1,
        ),
        EventTemplate(
            "passivate",
            "activated",
            "passivated",
            rate=lambda context: 0.2
            * float(context.environment["product_activity"]),
            dependency_radius=0,
        ),
        EventTemplate(
            "depassivate",
            "passivated",
            "activated",
            rate=lambda context: 0.05
            + 0.4 * float(context.environment["rinse_activity"]),
            dependency_radius=0,
        ),
        EventTemplate(
            "remove",
            "activated",
            "removed",
            removal_rate,
            dependency_radius=1,
        ),
    )
    return GraphKMC(
        graph,
        events,
        seed=config.random_seed,
        environment={
            "interface_temperature_K": interface_temperature_K,
            "reactant_activity": 1.0,
            "product_activity": 0.15,
            "rinse_activity": 0.0,
        },
    )


def kmc_event_flux_to_velocity_nm_s(
    removal_event_flux_s: float,
    site_count: int,
    representative_site_length_nm: float,
) -> float:
    """Map removal events/s to a screening normal velocity.

    The representative length is a calibration parameter, not an atomic bond
    length implied by the graph.
    """

    if not math.isfinite(removal_event_flux_s) or removal_event_flux_s < 0.0:
        raise ValueError("removal_event_flux_s must be finite and non-negative")
    if not isinstance(site_count, int) or site_count <= 0:
        raise ValueError("site_count must be a positive integer")
    if (
        not math.isfinite(representative_site_length_nm)
        or representative_site_length_nm <= 0.0
    ):
        raise ValueError("representative_site_length_nm must be finite and positive")
    return (
        representative_site_length_nm
        * removal_event_flux_s
        / site_count
    )


def run_kmc_screening(
    process: EtchProcessConfig,
    thermal: ThermalResistanceModel,
    config: ScreeningConfig,
) -> dict[str, object]:
    representative_depth_m = 0.5 * process.geometry.depth_nm * NM_TO_M
    interface_temperature = thermal.interface_temperature_K(
        representative_depth_m,
        process.thermal_bc,
    )
    kmc = build_kmc(config, interface_temperature)
    result = kmc.run(max_events=config.kmc_max_events)
    site_length_nm = 0.3
    removal_flux = float(result.event_flux_s.get("remove", 0.0))
    velocity = kmc_event_flux_to_velocity_nm_s(
        removal_flux,
        config.kmc_sites,
        site_length_nm,
    )
    return {
        "algorithm": "rejection-free direct SSA/BKL with local propensity updates",
        "seed": config.random_seed,
        "site_count": config.kmc_sites,
        "max_events": config.kmc_max_events,
        "representative_interface_temperature_K": interface_temperature,
        "event_count": result.event_count,
        "elapsed_s": result.elapsed_s,
        "stop_reason": result.stop_reason,
        "event_counts": dict(result.event_counts),
        "event_flux_s": dict(result.event_flux_s),
        "final_state_counts": dict(result.final_state_counts),
        "rate_evaluations": result.rate_evaluations,
        "effective_velocity_nm_s": velocity,
        "velocity_mapping": {
            "representative_site_length_nm": site_length_nm,
            "formula": "site_length_nm * removal_events_per_s / site_count",
            "calibrated": False,
        },
        "event_log": [
            {
                "event_number": event.event_number,
                "time_s": event.time_s,
                "event_name": event.event_name,
                "site_id": event.site_id,
                "old_state": event.old_state,
                "new_state": event.new_state,
            }
            for event in result.event_log
        ],
    }


VALID_MODES = ("thermal", "flat_1d", "continuum_2d", "wet_sequence", "kmc")


def run_screening_workflow(
    config: ScreeningConfig,
    modes: Iterable[str] = VALID_MODES,
) -> dict[str, object]:
    selected = tuple(dict.fromkeys(modes))
    unknown = set(selected).difference(VALID_MODES)
    if unknown:
        raise ValueError(f"unknown workflow modes: {sorted(unknown)}")
    process = build_process(config)
    thermal = ThermalResistanceModel(process.geometry)
    results: dict[str, object] = {}
    if "thermal" in selected:
        results["thermal"] = run_thermal_screening(process, thermal)
    if "flat_1d" in selected:
        results["flat_1d"] = run_flat_front_screening(
            process, thermal, config.duration_s
        )
    if "continuum_2d" in selected:
        results["continuum_2d"] = run_2d_screening(process, thermal, config)
    if "wet_sequence" in selected:
        results["wet_sequence"] = {
            strategy: run_wet_sequence_screening(
                process, thermal, config, strategy
            )
            for strategy in (
                "hf_then_second_wet",
                "hf_then_oxidation_fluoride",
            )
        }
    if "kmc" in selected:
        results["kmc"] = run_kmc_screening(process, thermal, config)
    return {
        "schema_version": 2,
        "calibrated": False,
        "notice": UNCALIBRATED_NOTICE,
        "config": config.to_dict(),
        "process": process.to_dict(),
        "loose_numerics": asdict(LOOSE_NUMERICS),
        "selected_modes": list(selected),
        "results": results,
    }


__all__ = [
    "ScreeningConfig",
    "UNCALIBRATED_NOTICE",
    "VALID_MODES",
    "build_kmc",
    "build_process",
    "kmc_event_flux_to_velocity_nm_s",
    "run_screening_workflow",
    "thermal_bc_from_step",
]

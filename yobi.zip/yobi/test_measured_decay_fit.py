from __future__ import annotations

import math
import unittest

import numpy as np

from measured_decay_fit import (
    MEASURED_WINDOW_S,
    build_report,
    fit_laws,
    interval_rates_nm_min,
    load_series,
    split_etch_prediction,
    time_to_remove_s,
)


class SeriesTests(unittest.TestCase):
    def test_measured_series_decelerates(self) -> None:
        """The observation the whole analysis rests on."""

        time_s, etch_nm = load_series()
        rates = interval_rates_nm_min(time_s, etch_nm)
        self.assertEqual(len(rates), 3)
        for earlier, later in zip(rates, rates[1:]):
            self.assertLess(later, earlier)
        self.assertAlmostEqual(rates[-1] / rates[0], 0.478, delta=0.01)

    def test_series_matches_the_clock_input(self) -> None:
        time_s, etch_nm = load_series()
        np.testing.assert_allclose(time_s, [0.0, 60.0, 120.0, 180.0])
        np.testing.assert_allclose(
            etch_nm, [0.0, 0.6418, 1.1212, 1.4277], rtol=0, atol=1e-12
        )


class FitTests(unittest.TestCase):
    def test_constant_rate_is_clearly_excluded(self) -> None:
        """'Etch longer' assumes a constant rate; the data does not support it."""

        laws = {law.name: law for law in fit_laws(*load_series())}
        self.assertGreater(
            laws["linear"].rms_residual_nm,
            10.0 * laws["saturating"].rms_residual_nm,
        )

    def test_laws_are_returned_best_first(self) -> None:
        laws = fit_laws(*load_series())
        residuals = [law.rms_residual_nm for law in laws]
        self.assertEqual(residuals, sorted(residuals))

    def test_saturating_and_logarithmic_are_not_distinguished(self) -> None:
        """Four points cannot choose between them, and they must not be."""

        laws = {law.name: law for law in fit_laws(*load_series())}
        self.assertLess(
            abs(
                laws["saturating"].rms_residual_nm
                - laws["logarithmic"].rms_residual_nm
            ),
            0.01,
        )
        report = build_report()
        self.assertFalse(report["claim_boundary"]["law_selected"])

    def test_only_the_saturating_law_has_a_ceiling(self) -> None:
        for law in fit_laws(*load_series()):
            if law.name == "saturating":
                self.assertTrue(law.has_finite_ceiling)
                self.assertAlmostEqual(law.ceiling_nm, 2.20, delta=0.05)
            else:
                self.assertFalse(law.has_finite_ceiling)
                self.assertIsNone(law.ceiling_nm)


class RemovalTimeTests(unittest.TestCase):
    def test_laws_agree_up_to_two_nanometres(self) -> None:
        """Below the divergence point the extrapolations are usable."""

        laws = {law.name: law for law in fit_laws(*load_series())}
        for thickness in (0.5, 1.0, 1.5):
            log = time_to_remove_s(laws["logarithmic"], thickness)
            sat = time_to_remove_s(laws["saturating"], thickness)
            self.assertLess(abs(log - sat) / sat, 0.10, thickness)

    def test_laws_diverge_past_the_ceiling(self) -> None:
        laws = {law.name: law for law in fit_laws(*load_series())}
        self.assertIsNone(time_to_remove_s(laws["saturating"], 3.0))
        self.assertGreater(time_to_remove_s(laws["logarithmic"], 3.0), 600.0)

    def test_thick_films_are_impractical_under_either_law(self) -> None:
        laws = {law.name: law for law in fit_laws(*load_series())}
        self.assertIsNone(time_to_remove_s(laws["saturating"], 10.0))
        self.assertGreater(
            time_to_remove_s(laws["logarithmic"], 10.0), 24.0 * 3600.0
        )

    def test_extrapolation_beyond_the_window_is_flagged(self) -> None:
        report = build_report()
        row = next(
            r for r in report["removal_times_s"] if r["thickness_nm"] == 5.0
        )
        self.assertTrue(row["beyond_measured_window"]["logarithmic"])
        self.assertTrue(row["beyond_measured_window"]["saturating"])
        near = next(
            r for r in report["removal_times_s"] if r["thickness_nm"] == 0.5
        )
        self.assertFalse(near["beyond_measured_window"]["saturating"])

    def test_rejects_nonpositive_thickness(self) -> None:
        laws = fit_laws(*load_series())
        with self.assertRaises(ValueError):
            time_to_remove_s(laws[0], 0.0)


class SplitEtchTests(unittest.TestCase):
    def test_split_removes_more_than_continuous(self) -> None:
        """The prediction that separates a liquid cause from a surface one."""

        result = split_etch_prediction(
            *load_series(), segment_duration_s=60.0, segment_count=3
        )
        self.assertAlmostEqual(result["per_segment_removal_nm"], 0.6418)
        self.assertAlmostEqual(result["split_total_nm"], 1.9254, places=6)
        self.assertAlmostEqual(result["continuous_total_nm"], 1.4277)
        self.assertGreater(result["split_over_continuous"], 1.30)
        self.assertEqual(result["continuous_source"], "measured")

    def test_split_beyond_the_window_reports_no_continuous_value(self) -> None:
        result = split_etch_prediction(
            *load_series(), segment_duration_s=120.0, segment_count=3
        )
        self.assertIsNone(result["continuous_total_nm"])
        self.assertEqual(
            result["continuous_source"], "beyond the measured window"
        )

    def test_single_segment_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            split_etch_prediction(
                *load_series(), segment_duration_s=60.0, segment_count=1
            )


class ClaimBoundaryTests(unittest.TestCase):
    def test_report_states_what_it_does_not_assert(self) -> None:
        boundary = build_report()["claim_boundary"]
        self.assertFalse(boundary["mechanism_asserted"])
        self.assertFalse(boundary["activation_energy_derived"])
        self.assertEqual(boundary["point_count"], 4)
        self.assertEqual(boundary["measured_window_s"], MEASURED_WINDOW_S)

    def test_constant_rate_ratio_is_reported(self) -> None:
        report = build_report()
        self.assertGreater(report["constant_rate_residual_ratio"], 10.0)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from ozone_dhf_linear_model import (
    OzoneDHFLinearConfig,
    run_ozone_dhf_linear_model,
    save_ozone_dhf_linear_json,
)


class OzoneDHFLinearModelTests(unittest.TestCase):
    def test_dual_channel_predictions_close_and_keep_source_point(self) -> None:
        payload = run_ozone_dhf_linear_model(
            OzoneDHFLinearConfig(
                endpoint_ids=("kawarazaki_sicn_c22",),
                dhf_only_durations_s=(30.0, 60.0),
                cycle_counts=(1, 3),
            )
        )
        case = payload["cases"][0]
        self.assertEqual(case["material"], "SiCN")
        self.assertAlmostEqual(
            case["dhf_only"]["apparent_rate_nm_min"],
            0.06,
        )
        dhf = case["dhf_only"]["predictions"]
        self.assertAlmostEqual(dhf[0]["etch_amount_nm"], 0.03)
        self.assertTrue(dhf[0]["is_source_duration"])
        self.assertAlmostEqual(dhf[1]["etch_amount_nm"], 0.06)
        self.assertTrue(dhf[1]["linearly_extrapolated_from_single_endpoint"])
        cycles = case["ozone_then_dhf"]["predictions"]
        self.assertAlmostEqual(
            cycles[0]["ozone_then_dhf_total_etch_nm"],
            2.47,
        )
        self.assertAlmostEqual(
            cycles[1]["ozone_then_dhf_total_etch_nm"],
            7.41,
        )
        self.assertAlmostEqual(cycles[1]["paired_dhf_baseline_nm"], 0.09)
        self.assertAlmostEqual(
            cycles[1]["ozone_enabled_increment_nm"],
            7.32,
        )
        self.assertTrue(payload["quality"]["strictly_algebraic_closure"])
        self.assertFalse(
            payload["assumptions"][
                "ozone_enabled_increment_is_ozone_only_etch"
            ]
        )

    def test_validation_and_strict_json_round_trip(self) -> None:
        with self.assertRaisesRegex(ValueError, "unknown endpoint"):
            OzoneDHFLinearConfig(endpoint_ids=("unknown",))
        with self.assertRaisesRegex(ValueError, "non-negative"):
            OzoneDHFLinearConfig(dhf_only_durations_s=(-1.0,))
        with self.assertRaisesRegex(ValueError, "non-negative integers"):
            OzoneDHFLinearConfig(cycle_counts=(-1,))

        payload = run_ozone_dhf_linear_model()
        with tempfile.TemporaryDirectory() as directory:
            path = save_ozone_dhf_linear_json(
                payload,
                Path(directory) / "fig2.json",
            )
            saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(
            saved["schema_version"],
            "ozone-dhf-linear-blanket/v1",
        )
        self.assertEqual(len(saved["cases"]), 4)

    def test_cycle_evidence_boundary_keeps_fig4_condition_unknown(self) -> None:
        payload = run_ozone_dhf_linear_model(
            OzoneDHFLinearConfig(
                endpoint_ids=(
                    "kawarazaki_sicn_c22",
                    "kawarazaki_sin_reference",
                ),
                dhf_only_durations_s=(30.0,),
                cycle_counts=(1, 3),
            )
        )
        target_cycle_three = payload["cases"][0]["ozone_then_dhf"][
            "predictions"
        ][1]
        self.assertTrue(
            target_cycle_three["within_reported_cycle_count_range"]
        )
        self.assertFalse(
            target_cycle_three["fixed_endpoint_sequence_directly_supported"]
        )
        self.assertTrue(
            target_cycle_three[
                "fixed_endpoint_cycle_scaling_is_assumption"
            ]
        )

        sin_cycle_three = payload["cases"][1]["ozone_then_dhf"][
            "predictions"
        ][1]
        self.assertFalse(
            sin_cycle_three["within_reported_cycle_count_range"]
        )
        self.assertTrue(sin_cycle_three["cycle_count_extrapolated"])
        self.assertTrue(
            sin_cycle_three[
                "fixed_endpoint_cycle_scaling_is_assumption"
            ]
        )


if __name__ == "__main__":
    unittest.main()

"""Run the 1-D and 2-D GAP-FILL models with traceable literature inputs.

This module deliberately isolates the first literature-backed calculation
from the uncalibrated product/passivation and graph-KMC prototypes.  Published
blanket-film rates are converted into a first-order neutral-HF law, and the
same law is used for both the Robin reactant sink and moving-front velocity.
That closes the reactant inventory by construction.

Product accumulation, wetting, bubbles, precipitation, and aqueous-HF
temperature activation are disabled because the selected sources do not
provide enough parameters to calibrate them.  Consequently, a near-uniform HF
field is a useful null hypothesis: any experimentally observed bottom-only
residue then requires physics or film non-uniformity absent from this baseline.
"""

from __future__ import annotations

import math
import os
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass

import numpy as np

from etch_process import EtchProcessConfig, ThermalBoundaryConditions
from flat_front_1d import (
    FlatFrontEtchSolver,
    IntegrationOptions,
    InterfaceKinetics,
    MassTransportParameters,
    PassivationParameters as FlatFrontPassivationParameters,
)
from gapfill_etch_2d import (
    EtchHistoryEntry,
    GapFillEtch2D,
    PassivationParameters as PassivationParameters2D,
    TransportParameters as TransportParameters2D,
)
from literature_parameters import (
    HF_DIFFUSIVITY_298_M2_S,
    HF_DIFFUSIVITY_298_NM2_S,
    LITERATURE_ETCH_PRESETS,
    SOURCES,
    LiteratureEtchPreset,
    get_literature_preset,
    silicon_thermal_conductivity_W_mK,
)
from numerical_settings import LOOSE_NUMERICS, NumericalSettings
from thermal_model import (
    NM_TO_M,
    ThermalResistanceModel,
    ThermalResistanceParameters,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS, get_geometry_preset


LITERATURE_MODEL_NOTICE = (
    "Literature-backed null model, not a process recipe: blanket WER and bulk "
    "HF transport are used directly; deep-trench product/passivation, wetting, "
    "bubbles, precipitation, confinement corrections, and kinetic temperature "
    "scaling are not calibrated."
)

DEFAULT_LITERATURE_PRESET_NAMES = tuple(
    key
    for key, preset in LITERATURE_ETCH_PRESETS.items()
    if preset.rate_source_key != "kawarazaki_2024"
)


@dataclass(frozen=True)
class LiteratureSweepConfig:
    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    presets: tuple[str, ...] = DEFAULT_LITERATURE_PRESET_NAMES
    solution_bulk_temperature_K: float = 298.15
    substrate_backside_temperature_K: float = 298.15
    grid_spacing_nm: float = 0.5
    reservoir_height_nm: float = 10.0
    include_2d: bool = True
    maximum_history_points: int = 160
    maximum_fractional_front_change: float = 0.50
    comparison_exposure_s: float = 3600.0
    parallel_workers: int = 1

    def __post_init__(self) -> None:
        if not self.geometries:
            raise ValueError("at least one geometry is required")
        if not self.presets:
            raise ValueError("at least one literature preset is required")
        unknown_geometries = set(self.geometries).difference(GEOMETRY_PRESETS)
        if unknown_geometries:
            raise ValueError(f"unknown geometries: {sorted(unknown_geometries)}")
        unknown_presets = set(self.presets).difference(LITERATURE_ETCH_PRESETS)
        if unknown_presets:
            raise ValueError(f"unknown literature presets: {sorted(unknown_presets)}")
        for name in (
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
            "grid_spacing_nm",
            "reservoir_height_nm",
            "maximum_fractional_front_change",
            "comparison_exposure_s",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.maximum_fractional_front_change > 1.0:
            raise ValueError(
                "maximum_fractional_front_change must not exceed 1"
            )
        if self.maximum_history_points < 2:
            raise ValueError("maximum_history_points must be at least 2")
        if not isinstance(self.parallel_workers, int) or self.parallel_workers < 1:
            raise ValueError("parallel_workers must be a positive integer")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["geometries"] = list(self.geometries)
        result["presets"] = list(self.presets)
        return result


@dataclass(frozen=True)
class LiteratureFirstOrderRateLaw:
    """Linear neutral-HF front law matched to one blanket-film rate."""

    reference_planar_velocity_nm_s: float
    reference_neutral_hf_mol_m3: float

    def __post_init__(self) -> None:
        for name in (
            "reference_planar_velocity_nm_s",
            "reference_neutral_hf_mol_m3",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")

    def __call__(
        self,
        reactant: np.ndarray,
        product: np.ndarray,
        passivation: np.ndarray,
        interface_mask: np.ndarray,
    ) -> np.ndarray:
        interface = np.asarray(interface_mask, dtype=bool)
        shape = interface.shape
        reactant_field = np.broadcast_to(np.asarray(reactant, dtype=float), shape)
        product_field = np.broadcast_to(np.asarray(product, dtype=float), shape)
        passivation_field = np.broadcast_to(
            np.asarray(passivation, dtype=float), shape
        )
        for name, field in (
            ("reactant", reactant_field),
            ("product", product_field),
            ("passivation", passivation_field),
        ):
            if np.any(~np.isfinite(field)) or np.any(field < 0.0):
                raise ValueError(f"{name} must be finite and non-negative")
        active_fraction = np.clip(1.0 - passivation_field, 0.0, 1.0)
        velocity = (
            self.reference_planar_velocity_nm_s
            * reactant_field
            / self.reference_neutral_hf_mol_m3
            * active_fraction
        )
        # Product is checked above but intentionally absent from this null law.
        return np.where(interface, velocity, 0.0)


def _build_process(
    geometry_name: str,
    preset: LiteratureEtchPreset,
    config: LiteratureSweepConfig,
) -> EtchProcessConfig:
    return EtchProcessConfig(
        geometry=get_geometry_preset(geometry_name),
        gap_fill_material=preset.material,
        thermal_bc=ThermalBoundaryConditions(
            solution_bulk_temperature_K=config.solution_bulk_temperature_K,
            substrate_backside_temperature_K=(
                config.substrate_backside_temperature_K
            ),
        ),
    )


def _build_thermal_model(
    process: EtchProcessConfig,
    preset: LiteratureEtchPreset,
) -> ThermalResistanceModel:
    return ThermalResistanceModel(
        process.geometry,
        ThermalResistanceParameters(
            liquid_thermal_conductivity_W_mK=0.6065,
            fill_thermal_conductivity_W_mK=(
                preset.fill_thermal_conductivity_W_mK
            ),
            substrate_thermal_conductivity_W_mK=(
                silicon_thermal_conductivity_W_mK(
                    process.thermal_bc.substrate_backside_temperature_K
                )
            ),
            substrate_thickness_m=500.0e-6,
            solution_boundary_resistance_m2K_W=0.0,
            fill_substrate_contact_resistance_m2K_W=0.0,
            backside_contact_resistance_m2K_W=0.0,
        ),
    )


def _thermal_summary(
    process: EtchProcessConfig,
    thermal: ThermalResistanceModel,
) -> dict[str, object]:
    samples = []
    for fraction in (0.0, 0.5, 1.0):
        state = thermal.evaluate(
            fraction * process.geometry.depth_nm * NM_TO_M,
            process.thermal_bc,
        )
        samples.append(
            {
                "front_fraction": fraction,
                "interface_temperature_K": state.interface_temperature_K,
                "liquid_resistance_K_m_W": (
                    state.resistances.liquid_total_K_m_W
                ),
                "solid_resistance_K_m_W": (
                    state.resistances.solid_total_K_m_W
                ),
                "energy_balance_residual_W_m": (
                    state.energy_balance_residual_W_m
                ),
            }
        )
    return {
        "samples": samples,
        "parameters": asdict(thermal.parameters),
        "reaction_heat_flux_W_m2": 0.0,
        "temperature_scaling_applied_to_kinetics": False,
    }


def _run_flat_1d(
    process: EtchProcessConfig,
    thermal: ThermalResistanceModel,
    preset: LiteratureEtchPreset,
    comparison_exposure_s: float,
) -> dict[str, object]:
    speciation = preset.hf_speciation()
    concentration = speciation.neutral_hf_mol_m3
    surface_transfer_nm_s = preset.first_order_surface_transfer_nm_s()
    kinetics = InterfaceKinetics(
        rate_constant_ref_m_s=surface_transfer_nm_s * NM_TO_M,
        solid_molar_density_mol_m3=preset.solid_si_site_density_mol_m3,
        reactant_stoichiometry_mol_per_mol_solid=preset.effective_hf_per_si,
        product_yield_mol_per_mol_solid=0.0,
        activation_energy_J_mol=0.0,
        reference_temperature_K=298.15,
        reaction_heat_release_J_mol_solid=0.0,
    )
    transport = MassTransportParameters(
        reactant_bulk_concentration_mol_m3=concentration,
        reactant_diffusivity_ref_m2_s=HF_DIFFUSIVITY_298_M2_S,
        product_diffusivity_ref_m2_s=HF_DIFFUSIVITY_298_M2_S,
        product_bulk_concentration_mol_m3=0.0,
        reference_temperature_K=298.15,
        reactant_diffusion_activation_energy_J_mol=0.0,
        product_diffusion_activation_energy_J_mol=0.0,
    )
    planar_clear_time_s = process.geometry.depth_nm / preset.planar_rate_nm_s
    solver = FlatFrontEtchSolver(
        process,
        thermal,
        transport,
        kinetics,
        passivation=FlatFrontPassivationParameters(),
        options=IntegrationOptions(
            relative_tolerance=LOOSE_NUMERICS.linear_relative_tolerance,
            absolute_tolerance=LOOSE_NUMERICS.linear_absolute_tolerance,
            maximum_time_step_s=max(1.0e-6, planar_clear_time_s / 200.0),
            thermal_coupling_relative_tolerance=(
                LOOSE_NUMERICS.nonlinear_relative_tolerance
            ),
            maximum_thermal_iterations=(
                LOOSE_NUMERICS.maximum_nonlinear_iterations
            ),
        ),
    )
    top = solver.local_state(0.0, 0.0)
    bottom = solver.local_state(process.geometry.depth_nm * NM_TO_M, 0.0)
    result = solver.solve(1.25 * planar_clear_time_s)
    if (
        result.completion_time_s is not None
        and comparison_exposure_s >= result.completion_time_s
    ):
        comparison_front_depth_nm = process.geometry.depth_nm
    else:
        comparison_front_depth_nm = float(
            np.interp(
                comparison_exposure_s,
                result.time_s,
                result.front_depth_nm,
            )
        )
    geometry = process.geometry
    removed_area_nm2 = (
        geometry.top_width_nm * comparison_front_depth_nm
        - 0.5
        * (geometry.top_width_nm - geometry.bottom_width_nm)
        * comparison_front_depth_nm**2
        / geometry.depth_nm
    )
    remaining_area_fraction_at_comparison = float(
        np.clip(1.0 - removed_area_nm2 / geometry.area_nm2, 0.0, 1.0)
    )
    concentration_ratio = (
        bottom.reactant_interface_concentration_mol_m3 / concentration
    )
    bottom_damkohler = max(0.0, 1.0 / concentration_ratio - 1.0)
    return {
        "completed": result.completed,
        "completion_time_s": result.completion_time_s,
        "planar_clear_time_s": planar_clear_time_s,
        "completion_over_planar": (
            result.completion_time_s / planar_clear_time_s
            if result.completion_time_s is not None
            else None
        ),
        "front_depth_nm": float(result.front_depth_nm[-1]),
        "residual_fill_depth_nm": float(result.residual_fill_depth_nm[-1]),
        "sample_count": int(result.time_s.size),
        "top_velocity_nm_s": top.etch_velocity_m_s / NM_TO_M,
        "bottom_velocity_nm_s": bottom.etch_velocity_m_s / NM_TO_M,
        "bottom_to_top_velocity_ratio": (
            bottom.etch_velocity_m_s / top.etch_velocity_m_s
        ),
        "bottom_neutral_hf_fraction_of_bulk": concentration_ratio,
        "bottom_transport_damkohler": bottom_damkohler,
        "bottom_interface_temperature_K": bottom.interface_temperature_K,
        "comparison_exposure_s": comparison_exposure_s,
        "front_depth_nm_at_comparison_exposure": comparison_front_depth_nm,
        "remaining_area_fraction_at_comparison_exposure": (
            remaining_area_fraction_at_comparison
        ),
        "kinetic_activation_energy_J_mol": 0.0,
        "kinetic_temperature_scaling_applied": False,
        "passivation_enabled": False,
        "product_generation_enabled": False,
        "solver_message": result.solver_message,
    }


def _downsample_history(
    history: list[EtchHistoryEntry],
    planar_clear_time_s: float,
    maximum_points: int,
) -> list[dict[str, float | int | str | bool]]:
    if not history:
        return []
    if len(history) <= maximum_points:
        indices = np.arange(len(history), dtype=int)
    else:
        indices = np.unique(
            np.linspace(0, len(history) - 1, maximum_points).round().astype(int)
        )
    records: list[dict[str, float | int | str | bool]] = []
    for index in indices:
        item = history[int(index)]
        records.append(
            {
                "time_s": item.time_s,
                "time_over_planar": item.time_s / planar_clear_time_s,
                "remaining_mass_fraction": (
                    item.remaining_solid_area_nm2
                    / (item.remaining_solid_area_nm2 + item.dissolved_area_nm2)
                ),
                "mean_interface_neutral_hf_mol_m3": (
                    item.mean_interface_reactant
                ),
                "maximum_velocity_nm_s": item.maximum_velocity_nm_s,
                "reactant_converged": item.reactant_converged,
                "reactant_relative_residual": item.reactant_relative_residual,
                "front_mass_balance_relative_error": (
                    item.front_mass_balance_relative_error
                ),
                "time_step_limiter": item.time_step_limiter,
            }
        )
    return records


def _row_profile(
    model: GapFillEtch2D,
) -> dict[str, list[float]]:
    trench_rows = (model.grid.depth_nm >= 0.0) & (
        model.grid.depth_nm <= model.grid.geometry.depth_nm
    )
    depths = model.grid.depth_nm[trench_rows]
    cavity = model.grid.cavity_mask[trench_rows]
    solid = model.front.solid_fraction[trench_rows]
    discrete_width = np.sum(cavity, axis=1) * model.grid.dx_nm
    remaining_width = np.sum(solid * cavity, axis=1) * model.grid.dx_nm
    fraction = np.divide(
        remaining_width,
        discrete_width,
        out=np.zeros_like(remaining_width),
        where=discrete_width > 0.0,
    )
    return {
        "depth_nm": [float(value) for value in depths],
        "discrete_cavity_width_nm": [float(value) for value in discrete_width],
        "remaining_solid_width_nm": [float(value) for value in remaining_width],
        "remaining_row_fraction": [float(value) for value in fraction],
    }


def _run_2d(
    process: EtchProcessConfig,
    preset: LiteratureEtchPreset,
    config: LiteratureSweepConfig,
) -> dict[str, object]:
    speciation = preset.hf_speciation()
    concentration = speciation.neutral_hf_mol_m3
    planar_clear_time_s = process.geometry.depth_nm / preset.planar_rate_nm_s
    requested_time_step_s = max(1.0e-6, planar_clear_time_s / 200.0)
    numerics = NumericalSettings(
        linear_relative_tolerance=LOOSE_NUMERICS.linear_relative_tolerance,
        linear_absolute_tolerance=LOOSE_NUMERICS.linear_absolute_tolerance,
        nonlinear_relative_tolerance=LOOSE_NUMERICS.nonlinear_relative_tolerance,
        steady_state_relative_tolerance=(
            LOOSE_NUMERICS.steady_state_relative_tolerance
        ),
        mass_balance_relative_tolerance=(
            LOOSE_NUMERICS.mass_balance_relative_tolerance
        ),
        maximum_iterations=LOOSE_NUMERICS.maximum_iterations,
        maximum_nonlinear_iterations=(
            LOOSE_NUMERICS.maximum_nonlinear_iterations
        ),
        maximum_fractional_state_change=(
            config.maximum_fractional_front_change
        ),
        minimum_time_step_s=LOOSE_NUMERICS.minimum_time_step_s,
        maximum_time_step_s=max(1.0, requested_time_step_s),
    )
    model = GapFillEtch2D(
        process,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=max(2.0, config.grid_spacing_nm),
        transport=TransportParameters2D(
            reactant_diffusivity_nm2_s=HF_DIFFUSIVITY_298_NM2_S,
            product_diffusivity_nm2_s=HF_DIFFUSIVITY_298_NM2_S,
            reactant_bulk_concentration=concentration,
            reactant_surface_transfer_nm_s=(
                preset.first_order_surface_transfer_nm_s()
            ),
            product_bulk_concentration=0.0,
            product_yield_concentration=0.0,
            product_bulk_decay_per_s=0.0,
        ),
        passivation=PassivationParameters2D(),
        rate_law=LiteratureFirstOrderRateLaw(
            reference_planar_velocity_nm_s=preset.planar_rate_nm_s,
            reference_neutral_hf_mol_m3=concentration,
        ),
        numerical_settings=numerics,
        solid_density_g_cm3=preset.solid_density_g_cm3,
    )
    initial = model.front.diagnostics()
    checkpoint_targets = {
        "half_planar": 0.5 * planar_clear_time_s,
        "planar": planar_clear_time_s,
        "comparison": config.comparison_exposure_s,
    }
    grouped_targets: dict[float, list[str]] = {}
    for label, target in checkpoint_targets.items():
        grouped_targets.setdefault(float(target), []).append(label)
    checkpoint_diagnostics = {}
    checkpoint_profiles = {}
    history: list[EtchHistoryEntry] = []
    for target in sorted(grouped_targets):
        if model.front.time_s < target and np.any(model.front.solid_mask):
            segment = model.run(
                target - model.front.time_s,
                time_step_s=requested_time_step_s,
                snapshot_every_steps=10_000,
                max_steps=10_000,
            )
            history.extend(segment.history)
        diagnostics = model.front.diagnostics()
        profile = _row_profile(model)
        for label in grouped_targets[target]:
            checkpoint_diagnostics[label] = diagnostics
            checkpoint_profiles[label] = profile
    if np.any(model.front.solid_mask):
        extension = model.run(
            planar_clear_time_s,
            time_step_s=requested_time_step_s,
            snapshot_every_steps=10_000,
            max_steps=10_000,
        )
        history.extend(extension.history)
    final = model.front.diagnostics()
    completed = not np.any(model.front.solid_mask)
    at_half_planar = checkpoint_diagnostics["half_planar"]
    profile_at_half_planar = checkpoint_profiles["half_planar"]
    at_planar = checkpoint_diagnostics["planar"]
    profile_at_planar = checkpoint_profiles["planar"]
    at_comparison = checkpoint_diagnostics["comparison"]
    profile_at_comparison = checkpoint_profiles["comparison"]

    limiter_counts = Counter(entry.time_step_limiter for entry in history)
    reactant_converged = all(entry.reactant_converged for entry in history)
    product_converged = all(entry.product_converged for entry in history)
    nonlinear_converged = all(entry.nonlinear_converged for entry in history)
    completion_time_s = final.time_s if completed else None
    return {
        "completed": completed,
        "completion_time_s": completion_time_s,
        "planar_clear_time_s": planar_clear_time_s,
        "completion_over_planar": (
            completion_time_s / planar_clear_time_s
            if completion_time_s is not None
            else None
        ),
        "remaining_mass_fraction_at_planar_time": (
            at_planar.remaining_mass_fraction
        ),
        "remaining_mass_fraction_at_half_planar_time": (
            at_half_planar.remaining_mass_fraction
        ),
        "comparison_exposure_s": config.comparison_exposure_s,
        "remaining_mass_fraction_at_comparison_exposure": (
            at_comparison.remaining_mass_fraction
        ),
        "profile_at_comparison_exposure": profile_at_comparison,
        "profile_at_half_planar_time": profile_at_half_planar,
        "profile_at_planar_time": profile_at_planar,
        "grid": {
            "shape": list(model.grid.shape),
            "dx_nm": model.grid.dx_nm,
            "dz_nm": model.grid.dz_nm,
            "initial_area_discretization_relative_error": (
                initial.initial_area_discretization_relative_error
            ),
        },
        "steps": len(history),
        "requested_time_step_s": requested_time_step_s,
        "time_step_limiter_counts": dict(limiter_counts),
        "remaining_mass_fraction": final.remaining_mass_fraction,
        "reactant_converged": reactant_converged,
        "product_converged": product_converged,
        "nonlinear_converged": nonlinear_converged,
        "maximum_reactant_relative_residual": max(
            (entry.reactant_relative_residual for entry in history),
            default=0.0,
        ),
        "maximum_front_mass_balance_relative_error": max(
            (entry.front_mass_balance_relative_error for entry in history),
            default=0.0,
        ),
        "history": _downsample_history(
            history,
            planar_clear_time_s,
            config.maximum_history_points,
        ),
        "reactant_inventory_closure": (
            "Robin sink = planar_velocity * Si-site-density * 6 / bulk[HF]; "
            "the same linear [HF] factor drives the front"
        ),
        "passivation_enabled": False,
        "product_generation_enabled": False,
        "kinetic_temperature_scaling_applied": False,
    }


def run_literature_case(
    geometry_name: str,
    preset_name: str,
    config: LiteratureSweepConfig,
) -> dict[str, object]:
    preset = get_literature_preset(preset_name)
    process = _build_process(geometry_name, preset, config)
    thermal = _build_thermal_model(process, preset)
    planar_clear_time_s = process.geometry.depth_nm / preset.planar_rate_nm_s
    diffusion_time_s = (
        (process.geometry.depth_nm * NM_TO_M) ** 2 / HF_DIFFUSIVITY_298_M2_S
    )
    result: dict[str, object] = {
        "case_id": f"{geometry_name}__{preset_name}",
        "geometry": process.geometry.to_dict(),
        "material": preset.material,
        "preset": preset.to_dict(),
        "boundary_temperatures_K": {
            "solution_bulk": config.solution_bulk_temperature_K,
            "substrate_backside": config.substrate_backside_temperature_K,
        },
        "timescale_screen": {
            "planar_clear_time_s": planar_clear_time_s,
            "planar_clear_time_min": planar_clear_time_s / 60.0,
            "bulk_diffusion_time_depth_squared_over_D_s": diffusion_time_s,
            "clear_to_diffusion_time_ratio": planar_clear_time_s / diffusion_time_s,
        },
        "thermal": _thermal_summary(process, thermal),
        "flat_1d": _run_flat_1d(
            process,
            thermal,
            preset,
            config.comparison_exposure_s,
        ),
    }
    if config.include_2d:
        result["continuum_2d"] = _run_2d(process, preset, config)
    return result


def run_literature_sweep(
    config: LiteratureSweepConfig | None = None,
) -> dict[str, object]:
    resolved = config or LiteratureSweepConfig()
    case_inputs = [
        (geometry, preset, resolved)
        for geometry in resolved.geometries
        for preset in resolved.presets
    ]
    effective_workers = min(resolved.parallel_workers, len(case_inputs))
    if effective_workers == 1:
        cases = [_run_literature_case_tuple(item) for item in case_inputs]
    else:
        # One BLAS/OpenMP thread per process avoids N_processes x N_threads
        # oversubscription.  threadpoolctl also handles libraries loaded before
        # a fork; environment values cover spawned workers.
        thread_variables = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
        previous_environment = {
            name: os.environ.get(name) for name in thread_variables
        }
        for name in thread_variables:
            os.environ[name] = "1"
        try:
            with ProcessPoolExecutor(
                max_workers=effective_workers,
                initializer=_initialise_numeric_worker,
            ) as executor:
                # executor.map preserves the deterministic geometry/preset order.
                cases = list(executor.map(_run_literature_case_tuple, case_inputs))
        finally:
            for name, previous in previous_environment.items():
                if previous is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = previous
    used_source_keys: set[str] = set()
    for preset_name in resolved.presets:
        preset = get_literature_preset(preset_name)
        used_source_keys.add(preset.rate_source_key)
        used_source_keys.update(preset.property_source_keys)
    return {
        "model": "literature-backed blanket-rate null model",
        "notice": LITERATURE_MODEL_NOTICE,
        "calibrated_for_deep_trench": False,
        "config": resolved.to_dict(),
        "parallel_execution": {
            "requested_workers": resolved.parallel_workers,
            "effective_workers": effective_workers,
            "case_count": len(case_inputs),
            "case_order_preserved": True,
            "numeric_threads_per_worker": 1 if effective_workers > 1 else None,
        },
        "source_classification": {
            key: SOURCES[key].to_dict() for key in sorted(used_source_keys)
        },
        "disabled_mechanisms": [
            "product accumulation and precipitation",
            "passivation/skinning",
            "wetting and trapped gas",
            "nanoconfinement correction to bulk HF diffusivity",
            "aqueous-HF kinetic Arrhenius correction",
        ],
        "cases": cases,
    }


_WORKER_THREAD_LIMITER = None


def _initialise_numeric_worker() -> None:
    """Limit nested native threads inside each case process."""

    global _WORKER_THREAD_LIMITER
    try:
        from threadpoolctl import threadpool_limits
    except ImportError:
        return
    _WORKER_THREAD_LIMITER = threadpool_limits(limits=1)


def _run_literature_case_tuple(
    values: tuple[str, str, LiteratureSweepConfig],
) -> dict[str, object]:
    geometry, preset, config = values
    return run_literature_case(geometry, preset, config)


def nominal_preset_names() -> tuple[str, ...]:
    return tuple(
        key
        for key, preset in LITERATURE_ETCH_PRESETS.items()
        if preset.rate_band == "nominal"
    )


def preset_names_for_material(material: str) -> tuple[str, ...]:
    return tuple(
        key
        for key, preset in LITERATURE_ETCH_PRESETS.items()
        if preset.material == material
    )


__all__ = [
    "DEFAULT_LITERATURE_PRESET_NAMES",
    "LITERATURE_MODEL_NOTICE",
    "LiteratureFirstOrderRateLaw",
    "LiteratureSweepConfig",
    "nominal_preset_names",
    "preset_names_for_material",
    "run_literature_case",
    "run_literature_sweep",
]

"""What does an LED-heated interface buy the cyclic end-game?

The end-game cyclic screen priced the reset recipe for the two-material
system (silicon trench + low-k fill) at 25 C.  This screen heats it.  A
backside LED (or a hot bath) raises the reaction-front temperature; the
dHF component of every cycle accelerates by the prefactor-free Arrhenius
ratio the thermal-path screen already provides; fewer cycles are needed
to clear the same pad; and because every avoided cycle is an avoided
oxidation, **heat converts directly into silicon budget** -- the heater
helps twice, once in time and once in substrate.

Everything hinges on which activation energy governs, and that is
exactly the unresolved discrimination of the field-observation screen,
so the barrier is swept over the declared candidates rather than
asserted: the transport-limited null (0.17 eV), the corrected SiOCN
water-trimer hydrolysis saddle (0.843 eV; the 2026-07-29 strict-gate
reaudit value, superseding the retired 1.0243 eV), and the SiN
hydrolysis saddle (1.2148 eV).  At an interface 60 C those give
per-pulse factors of 2.0x, 31x, and 144x respectively: the heater is a
nothing under transport control and a game-changer under reaction
control.  The same spread is the diagnostic -- the heated cyclic
experiment measures the per-pulse improvement, and inverting it through
the same Arrhenius form returns the apparent barrier, with the
transport ceiling (1.67x at +25 K full coupling) as the reject line the
repository already established.

The Arrhenius factor is applied to the dHF-only component of the cycle;
the ozone-enabled increment is a dose-saturated self-limiting quantity
and is left unscaled by default (``scale_increment`` exposes the
optimistic bound).  Raster floors are unbeatable by heat: a film whose
cold dHF-only bar sits at the 0.05 nm resolution floor keeps an
unbounded worst-case no-reset arm at every temperature, because heating
multiplies the measurement's ignorance along with its value.

**Boundaries.**  Interface temperature is the independent variable; how
much backside overheat produces it is the thermal-path screen's
unresolved ``eta`` (swept in a companion table; a hot bath reaches the
same interface temperature at ``eta = 1`` by construction but forfeits
the depth selectivity of backside heating).  The barriers are UMA
potential-energy screening values with wide prefactor bands, not free
energies; the favoured proton-assisted rate law has an unresolved
temperature response (the protonation-enthalpy probe found no
equilibrium to assign a ``dH`` to), so the sweep brackets candidates
rather than modelling ``theta_H(T)``.  The Kawarazaki bars are treated
as 298.15 K measurements (their dHF temperature is undisclosed).  HF
speciation and diffusivity stay at 25 C values, bath physics
(evaporation, fuming, boiling, bubble nucleation) is not modelled, the
measured-blanket decay's own temperature dependence is unknown, and the
self-limiting oxide thickness keeps its declared 0.5--1.5 nm band (its
weak temperature dependence lives inside that band).  Hot dry-down
raises the AFS re-precipitation stakes; rinse discipline stays in
scope for the recipe, out of scope here.  Nothing here is a process
recipe.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from endgame_cyclic_screen import (
    CARBON_MATERIAL_KEYS,
    MATERIAL_KEYS,
    clearing_case,
    silicon_cost,
)
from literature_parameters import KAWARAZAKI_2024_FIG2_ENDPOINTS
from thermal_path_screen import (
    TRANSPORT_APPARENT_BARRIER_EV,
    arrhenius_rate_ratio,
    required_activation_energy_eV,
)


SCHEMA_VERSION = "heated-endgame-cyclic-screen/v1"
MODEL_NOTICE = (
    "Heats the two-material end-game: the dHF component of each cycle "
    "accelerates by a prefactor-free Arrhenius ratio swept over the "
    "declared barrier candidates (0.17 / 0.843 / 1.2148 eV), fewer "
    "cycles clear the same pad, and every avoided cycle is an avoided "
    "oxidation, so heat converts into silicon budget. The ozone "
    "increment stays unscaled by default (dose-saturated). Raster "
    "floors are unbeatable by heat. Interface temperature is the "
    "variable; backside-vs-bath delivery is a companion eta table. "
    "Not a process recipe."
)

REFERENCE_TEMPERATURE_K = 298.15

# Declared barrier candidates.  The water-trimer value is the corrected
# 2026-07-29 strict-gate reaudit
# (atomistic_barriers/results/barrier_reproduction_20260729/
# sella_direct_reaudit_strict_water_trimer.json), superseding the
# retired 1.0243 eV campaign value; the SiN saddle matches the accepted
# prior; the transport null is imported from the thermal-path screen.
BARRIER_CANDIDATES_EV: Mapping[str, float] = {
    "transport_limited_null": TRANSPORT_APPARENT_BARRIER_EV,
    "siocn_water_trimer_hydrolysis_corrected": 0.8431133533886168,
    "sin_hydrolysis": 1.2148,
}

DEFAULT_INTERFACE_TEMPERATURES_K = (313.15, 333.15, 353.15)
DEFAULT_PAD_THICKNESSES_NM = (1.0, 2.0, 3.0, 5.0)
DEFAULT_WET_RESET_EFFICIENCIES = (0.3, 1.0)
DEFAULT_SILICON_BUDGETS_NM = (0.5, 1.0, 2.0)
DEFAULT_OXIDE_THICKNESS_NM = 1.0
DEFAULT_MARGIN_CYCLES = 0
DEFAULT_ETA_SWEEP = (0.058, 0.382, 1.0)
DEFAULT_INTERFACE_UPLIFTS_K = (15.0, 35.0, 55.0)
MAXIMUM_CYCLES = 500

# The repository's transport reject line: full-coupling +25 K under the
# transport null.  An observed per-pulse improvement above this rejects
# transport control regardless of the thermal path.
TRANSPORT_CEILING_25K = arrhenius_rate_ratio(
    TRANSPORT_APPARENT_BARRIER_EV,
    REFERENCE_TEMPERATURE_K,
    REFERENCE_TEMPERATURE_K + 25.0,
)


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def _endpoint(key: str):
    try:
        return KAWARAZAKI_2024_FIG2_ENDPOINTS[key]
    except KeyError as exc:
        choices = ", ".join(KAWARAZAKI_2024_FIG2_ENDPOINTS)
        raise ValueError(
            f"unknown material key {key!r}; choose from {choices}"
        ) from exc


def heated_per_cycle_removal_nm(
    material_key: str,
    *,
    wet_reset_efficiency: float,
    interface_temperature_K: float,
    activation_energy_eV: float,
    scale_increment: bool = False,
) -> dict[str, float]:
    """Per-cycle removal with the dHF component Arrhenius-accelerated.

    The low bound scales the cold raster band with the same factor, so
    a film whose cold dHF-only bar can reach zero keeps a zero low
    bound at every temperature -- heat multiplies ignorance along with
    value.
    """

    efficiency = float(wet_reset_efficiency)
    if not math.isfinite(efficiency) or not 0.0 <= efficiency <= 1.0:
        raise ValueError("wet_reset_efficiency must be within [0, 1]")
    endpoint = _endpoint(material_key)
    factor = arrhenius_rate_ratio(
        activation_energy_eV,
        REFERENCE_TEMPERATURE_K,
        interface_temperature_K,
    )
    increment_factor = factor if scale_increment else 1.0
    dhf = endpoint.dhf_only_etch_amount_nm
    increment = endpoint.ozone_enabled_increment_nm_per_cycle
    resolution = endpoint.digitization_resolution_nm
    central = (
        dhf * factor + efficiency * increment * increment_factor
    )
    low = (
        max(0.0, dhf - resolution) * factor
        + efficiency
        * max(0.0, increment - 2.0 * resolution)
        * increment_factor
    )
    return {
        "central": central,
        "low": low,
        "arrhenius_factor": factor,
        "increment_scaled": bool(scale_increment),
    }


def heated_clearing_case(
    *,
    material_key: str,
    pad_thickness_nm: float,
    wet_reset_efficiency: float,
    interface_temperature_K: float,
    activation_energy_eV: float,
    scale_increment: bool = False,
    maximum_cycles: int = MAXIMUM_CYCLES,
) -> dict[str, Any]:
    """Hot cycle counts beside the cold case and the hot no-reset arm."""

    thickness = _finite_positive("pad_thickness_nm", pad_thickness_nm)
    removal = heated_per_cycle_removal_nm(
        material_key,
        wet_reset_efficiency=wet_reset_efficiency,
        interface_temperature_K=interface_temperature_K,
        activation_energy_eV=activation_energy_eV,
        scale_increment=scale_increment,
    )

    def _count(per_cycle: float) -> int | None:
        if per_cycle <= 0.0:
            return None
        cycles = math.ceil(thickness / per_cycle)
        return cycles if cycles <= int(maximum_cycles) else None

    cold = clearing_case(
        material_key=material_key,
        pad_thickness_nm=thickness,
        wet_reset_efficiency=wet_reset_efficiency,
    )
    endpoint = _endpoint(material_key)
    hot_no_reset_per_pulse = (
        endpoint.dhf_only_etch_amount_nm * removal["arrhenius_factor"]
    )
    hot_no_reset_low = (
        max(
            0.0,
            endpoint.dhf_only_etch_amount_nm
            - endpoint.digitization_resolution_nm,
        )
        * removal["arrhenius_factor"]
    )
    cycles_hot = _count(removal["central"])
    cycles_cold = cold["cycles_central"]
    return {
        "material": material_key,
        "pad_thickness_nm": thickness,
        "wet_reset_efficiency": float(wet_reset_efficiency),
        "interface_temperature_K": float(interface_temperature_K),
        "activation_energy_eV": float(activation_energy_eV),
        "heated_per_cycle_removal_nm": removal,
        "cycles_hot": cycles_hot,
        "cycles_hot_worst_raster": _count(removal["low"]),
        "cycles_cold": cycles_cold,
        "cycles_saved": (
            None
            if cycles_hot is None or cycles_cold is None
            else cycles_cold - cycles_hot
        ),
        "no_reset_pulses_hot": _count(hot_no_reset_per_pulse),
        "no_reset_unbounded_within_resolution": hot_no_reset_low <= 0.0,
    }


def heated_feasibility_row(
    *,
    pad_thickness_nm: float,
    wet_reset_efficiency: float,
    interface_temperature_K: float,
    activation_energy_eV: float,
    silicon_budget_nm: float,
    oxide_thickness_nm: float = DEFAULT_OXIDE_THICKNESS_NM,
    margin_cycles: int = DEFAULT_MARGIN_CYCLES,
    material_keys: Sequence[str] = MATERIAL_KEYS,
) -> dict[str, Any]:
    """Hot-cycle feasibility with the silicon the heat saved beside it."""

    budget = _finite_positive("silicon_budget_nm", silicon_budget_nm)
    materials: list[dict[str, Any]] = []
    for key in material_keys:
        case = heated_clearing_case(
            material_key=key,
            pad_thickness_nm=pad_thickness_nm,
            wet_reset_efficiency=wet_reset_efficiency,
            interface_temperature_K=interface_temperature_K,
            activation_energy_eV=activation_energy_eV,
        )
        cycles = case["cycles_hot"]
        if cycles is None:
            materials.append(
                {
                    "material": key,
                    "cycles_hot": None,
                    "feasible": False,
                    "infeasible_reason": "cycle count unbounded",
                }
            )
            continue
        cost = silicon_cost(
            cycles=cycles,
            margin_cycles=margin_cycles,
            oxide_thickness_nm=oxide_thickness_nm,
        )
        saved = case["cycles_saved"]
        materials.append(
            {
                "material": key,
                "cycles_hot": cycles,
                "cycles_cold": case["cycles_cold"],
                "wall_recession_nm": cost["wall_recession_nm"],
                "cleared_bottom_recession_nm": (
                    cost["cleared_bottom_recession_nm"]
                ),
                "silicon_saved_by_heating_nm": (
                    None
                    if saved is None
                    else saved * cost["per_reset_recession_nm"]
                ),
                "feasible": cost["wall_recession_nm"] <= budget + 1e-12,
            }
        )
    carbon_rows = [
        row for row in materials if row["material"] in CARBON_MATERIAL_KEYS
    ]
    return {
        "pad_thickness_nm": float(pad_thickness_nm),
        "wet_reset_efficiency": float(wet_reset_efficiency),
        "interface_temperature_K": float(interface_temperature_K),
        "activation_energy_eV": float(activation_energy_eV),
        "silicon_budget_nm": budget,
        "oxide_thickness_nm": float(oxide_thickness_nm),
        "margin_cycles": int(margin_cycles),
        "materials": materials,
        "feasible_materials": [
            row["material"] for row in materials if row["feasible"]
        ],
        "all_materials_feasible": all(
            row["feasible"] for row in materials
        ),
        "carbon_materials_feasible": all(
            row["feasible"] for row in carbon_rows
        ),
    }


def discrimination_table(
    *,
    interface_temperatures_K: Sequence[float] = (
        DEFAULT_INTERFACE_TEMPERATURES_K
    ),
    barrier_candidates_eV: Mapping[str, float] = BARRIER_CANDIDATES_EV,
) -> dict[str, Any]:
    """Predicted per-pulse improvement per barrier, and the inversion.

    The heated cyclic experiment measures the per-pulse improvement
    ratio at a known interface temperature; inverting it through the
    same Arrhenius form returns the apparent barrier without any
    absolute rate.  An observed ratio above the transport ceiling
    rejects transport control outright.
    """

    rows: list[dict[str, Any]] = []
    for temperature in interface_temperatures_K:
        for name, energy in barrier_candidates_eV.items():
            factor = arrhenius_rate_ratio(
                energy, REFERENCE_TEMPERATURE_K, temperature
            )
            rows.append(
                {
                    "interface_temperature_K": float(temperature),
                    "barrier": name,
                    "activation_energy_eV": float(energy),
                    "per_pulse_improvement": factor,
                    "apparent_barrier_from_inversion_eV": (
                        required_activation_energy_eV(
                            factor,
                            REFERENCE_TEMPERATURE_K,
                            temperature,
                        )
                    ),
                }
            )
    return {
        "rows": rows,
        "transport_ceiling_at_25K_full_coupling": TRANSPORT_CEILING_25K,
        "note": (
            "measure the per-pulse improvement at a known interface "
            "temperature and invert for the apparent barrier; above "
            "the transport ceiling, transport control is rejected "
            "regardless of the thermal path"
        ),
    }


def backside_requirement_table(
    *,
    interface_uplifts_K: Sequence[float] = DEFAULT_INTERFACE_UPLIFTS_K,
    eta_sweep: Sequence[float] = DEFAULT_ETA_SWEEP,
) -> dict[str, Any]:
    """Backside overheat needed per eta, versus the hot-bath alternative."""

    rows: list[dict[str, Any]] = []
    for uplift in interface_uplifts_K:
        _finite_positive("interface_uplift_K", uplift)
        for eta in eta_sweep:
            _finite_positive("eta", eta)
            rows.append(
                {
                    "interface_uplift_K": float(uplift),
                    "eta": float(eta),
                    "required_backside_overheat_K": float(uplift) / eta,
                }
            )
    return {
        "rows": rows,
        "note": (
            "eta is the thermal-path screen's unresolved coupling "
            "fraction (defaults span 0.058-1.0); a hot bath reaches "
            "the same interface temperature at eta = 1 by construction "
            "but forfeits the bottom-selective heating of the backside "
            "LED (the thermal path delivers more overheat to the "
            "trench bottom than to the opening)"
        ),
    }


def build_report(
    *,
    pad_thicknesses_nm: Sequence[float] = DEFAULT_PAD_THICKNESSES_NM,
    wet_reset_efficiencies: Sequence[float] = (
        DEFAULT_WET_RESET_EFFICIENCIES
    ),
    interface_temperatures_K: Sequence[float] = (
        DEFAULT_INTERFACE_TEMPERATURES_K
    ),
    barrier_candidates_eV: Mapping[str, float] = BARRIER_CANDIDATES_EV,
    silicon_budgets_nm: Sequence[float] = DEFAULT_SILICON_BUDGETS_NM,
) -> dict[str, Any]:
    """Heated clearing, feasibility, discrimination, and delivery tables."""

    for thickness in pad_thicknesses_nm:
        _finite_positive("pad_thickness_nm", thickness)
    for temperature in interface_temperatures_K:
        if float(temperature) <= REFERENCE_TEMPERATURE_K:
            raise ValueError(
                "interface temperatures must exceed the 298.15 K reference"
            )

    clearing_rows = [
        heated_clearing_case(
            material_key=key,
            pad_thickness_nm=thickness,
            wet_reset_efficiency=efficiency,
            interface_temperature_K=temperature,
            activation_energy_eV=energy,
        )
        for efficiency in wet_reset_efficiencies
        for thickness in pad_thicknesses_nm
        for temperature in interface_temperatures_K
        for energy in barrier_candidates_eV.values()
        for key in MATERIAL_KEYS
    ]

    feasibility_rows = [
        heated_feasibility_row(
            pad_thickness_nm=thickness,
            wet_reset_efficiency=efficiency,
            interface_temperature_K=temperature,
            activation_energy_eV=energy,
            silicon_budget_nm=budget,
        )
        for efficiency in wet_reset_efficiencies
        for thickness in pad_thicknesses_nm
        for temperature in interface_temperatures_K
        for energy in barrier_candidates_eV.values()
        for budget in silicon_budgets_nm
    ]

    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "reference_temperature_K": REFERENCE_TEMPERATURE_K,
        "barrier_candidates_eV": dict(barrier_candidates_eV),
        "barrier_provenance_note": (
            "transport null imported from the thermal-path screen; the "
            "water-trimer saddle is the corrected 2026-07-29 "
            "strict-gate reaudit value superseding the retired 1.0243 "
            "eV; barriers are UMA potential-energy screening values "
            "with wide prefactor bands, not free energies; the "
            "favoured proton-assisted law's temperature response is "
            "unresolved and is bracketed, not modelled"
        ),
        "assumptions": {
            "interface_temperatures_K": [
                float(value) for value in interface_temperatures_K
            ],
            "kawarazaki_reference_note": (
                "the Fig. 2 bars are treated as 298.15 K measurements; "
                "their dHF temperature is undisclosed"
            ),
            "increment_scaling_note": (
                "the ozone increment is dose-saturated and left "
                "unscaled by default; scale_increment exposes the "
                "optimistic bound"
            ),
            "oxide_thickness_note": (
                "the self-limiting oxide keeps its declared 0.5-1.5 nm "
                "band; its weak temperature dependence lives inside it"
            ),
            "speciation_note": (
                "HF speciation and diffusivity stay at 25 C values, "
                "matching the repository convention"
            ),
        },
        "clearing": clearing_rows,
        "feasibility": feasibility_rows,
        "carbon_feasible_conditions": [
            {
                key: row[key]
                for key in (
                    "wet_reset_efficiency",
                    "pad_thickness_nm",
                    "interface_temperature_K",
                    "activation_energy_eV",
                    "silicon_budget_nm",
                )
            }
            for row in feasibility_rows
            if row["carbon_materials_feasible"]
        ],
        "discrimination": discrimination_table(
            interface_temperatures_K=interface_temperatures_K,
            barrier_candidates_eV=barrier_candidates_eV,
        ),
        "backside_delivery": backside_requirement_table(),
        "reading_notes": {
            "double_payoff": (
                "every cycle the heat removes is an oxidation the "
                "silicon never pays; the heater buys time and substrate "
                "at once"
            ),
            "barrier_decides": (
                "under the transport null the heater is a ~2x nothing; "
                "under the reaction barriers it is a 30-140x "
                "game-changer at 60 C -- and the heated experiment "
                "itself measures which world is real"
            ),
            "raster_floor": (
                "heating cannot bound the floor films' no-reset arms; "
                "only a measurement can"
            ),
        },
    }


__all__ = [
    "BARRIER_CANDIDATES_EV",
    "DEFAULT_ETA_SWEEP",
    "DEFAULT_INTERFACE_TEMPERATURES_K",
    "DEFAULT_INTERFACE_UPLIFTS_K",
    "DEFAULT_MARGIN_CYCLES",
    "DEFAULT_OXIDE_THICKNESS_NM",
    "DEFAULT_PAD_THICKNESSES_NM",
    "DEFAULT_SILICON_BUDGETS_NM",
    "DEFAULT_WET_RESET_EFFICIENCIES",
    "MAXIMUM_CYCLES",
    "MODEL_NOTICE",
    "REFERENCE_TEMPERATURE_K",
    "SCHEMA_VERSION",
    "TRANSPORT_CEILING_25K",
    "backside_requirement_table",
    "build_report",
    "discrimination_table",
    "heated_clearing_case",
    "heated_feasibility_row",
    "heated_per_cycle_removal_nm",
]

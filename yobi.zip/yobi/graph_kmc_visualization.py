#!/usr/bin/env python3
"""Reproducible figures for the surface-patch graph-KMC velocity sweep.

The summary figure consumes the ordinary JSON written by
``run_graph_kmc_velocity_sweep.py``.  The event-evolution figure deliberately
reruns one small, fixed-seed surface patch because the ensemble JSON contains
replicate summaries but not per-event site histories.

These plots are diagnostics for the regenerative surface-patch rate law.  The
patch is not a trench cross-section and its site axis must not be interpreted
as a spatially correlated trench-wall morphology.
"""

from __future__ import annotations

import argparse
import json
import math
from collections import Counter
from pathlib import Path
from textwrap import fill
from typing import Mapping, Sequence

import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, Normalize, TwoSlopeNorm
from matplotlib.patches import Patch
import numpy as np

from graph_kmc_velocity_sweep import PatchEnvironment, build_surface_patch_kmc


DEFAULT_SWEEP_JSON = Path("graph_kmc_velocity_sweep_results.json")
DEFAULT_SUMMARY_FIGURE = Path("graph_kmc_summary.png")
DEFAULT_EVENT_FIGURE = Path("graph_kmc_event_evolution.png")
DEFAULT_TRACE_JSON = Path("graph_kmc_representative_trace.json")
DEFAULT_TRACE_SEED = 20260714

SURFACE_PATCH_CAVEAT = (
    "Surface-patch diagnostic only: parallel regenerative columns; no trench "
    "geometry, transport, neighbour-coupled roughening, or persistent-deposit "
    "feedback. KMC event coefficients are uncalibrated; absolute scale comes "
    "from literature blanket WER."
)

_PLOT_STYLE = {
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "axes.linewidth": 0.8,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "figure.facecolor": "white",
    "axes.facecolor": "#fbfcfd",
    "savefig.facecolor": "white",
}


def load_sweep_payload(path: str | Path) -> dict[str, object]:
    """Load and minimally validate a graph-KMC velocity sweep payload."""

    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("model") != "regenerative surface-patch graph KMC relative velocity law":
        raise ValueError("input is not a graph-KMC velocity-sweep payload")
    for key in ("config", "size_audit", "environment_table"):
        if key not in payload:
            raise ValueError(f"sweep payload is missing {key!r}")
    if not payload["size_audit"] or not payload["environment_table"]:
        raise ValueError("sweep payload contains no plotted cases")
    return payload


def _close(left: float, right: float) -> bool:
    return math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=1.0e-9)


def _select_environment_rows(
    payload: Mapping[str, object],
    *,
    material: str,
    temperature_K: float | None = None,
    hf_activity: float | None = None,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for raw_row in payload["environment_table"]:  # type: ignore[index]
        row = dict(raw_row)
        if row["material"] != material:
            continue
        environment = row["environment"]
        if temperature_K is not None and not _close(
            environment["temperature_K"], temperature_K
        ):
            continue
        if hf_activity is not None and not _close(
            environment["hf_activity"], hf_activity
        ):
            continue
        rows.append(row)
    return rows


def _finite_modifier_arrays(
    rows: Sequence[Mapping[str, object]],
    temperatures_K: Sequence[float],
    product_activities: Sequence[float],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    value = np.full((len(temperatures_K), len(product_activities)), np.nan)
    low = value.copy()
    high = value.copy()
    for row in rows:
        environment = row["environment"]
        try:
            row_index = next(
                index
                for index, temperature in enumerate(temperatures_K)
                if _close(environment["temperature_K"], temperature)
            )
            column_index = next(
                index
                for index, product in enumerate(product_activities)
                if _close(environment["product_activity"], product)
            )
        except StopIteration as error:
            raise ValueError("environment row lies outside configured axes") from error
        summary = row["relative_modifier"]
        value[row_index, column_index] = float(summary["value"])
        low[row_index, column_index] = float(summary["paired_bootstrap_95ci_low"])
        high[row_index, column_index] = float(summary["paired_bootstrap_95ci_high"])
    if not np.all(np.isfinite(value)):
        raise ValueError("modifier heatmap has missing environment combinations")
    return value, low, high


def _panel_label(axis, label: str) -> None:
    axis.text(
        -0.11,
        1.07,
        label,
        transform=axis.transAxes,
        fontsize=12,
        fontweight="bold",
        va="top",
        ha="left",
    )


def plot_graph_kmc_summary(
    payload: Mapping[str, object], output_path: str | Path
) -> None:
    """Plot size audit, environmental modifiers, velocity, and state occupancy."""

    config = payload["config"]
    materials = tuple(str(value) for value in config["materials"])
    temperatures = tuple(sorted(float(value) for value in config["temperatures_K"]))
    hf_activities = tuple(sorted(float(value) for value in config["hf_activities"]))
    products = tuple(sorted(float(value) for value in config["product_activities"]))
    if len(hf_activities) != 2:
        raise ValueError("the polished summary layout requires exactly two HF activities")
    if not materials:
        raise ValueError("sweep contains no materials")
    modifier_material = materials[0]

    heatmap_data: list[tuple[np.ndarray, np.ndarray, np.ndarray]] = []
    for hf_activity in hf_activities:
        rows = _select_environment_rows(
            payload,
            material=modifier_material,
            hf_activity=hf_activity,
        )
        heatmap_data.append(
            _finite_modifier_arrays(rows, temperatures, products)
        )
    all_modifier_values = np.concatenate([item[0].ravel() for item in heatmap_data])
    vmin = float(np.min(all_modifier_values))
    vmax = float(np.max(all_modifier_values))
    if vmin < 1.0 < vmax:
        modifier_norm: Normalize = TwoSlopeNorm(vmin=vmin, vcenter=1.0, vmax=vmax)
    else:
        modifier_norm = Normalize(vmin=vmin, vmax=max(vmax, vmin + 1.0e-12))

    reference_temperature = 298.15
    reference_hf = 1.0
    if not any(_close(value, reference_temperature) for value in temperatures):
        raise ValueError("summary requires the 298.15 K reference temperature")
    if not any(_close(value, reference_hf) for value in hf_activities):
        raise ValueError("summary requires the HF-activity 1 reference")

    with plt.rc_context(_PLOT_STYLE):
        figure = plt.figure(figsize=(14.4, 8.8))
        grid = figure.add_gridspec(
            2,
            3,
            left=0.065,
            right=0.965,
            bottom=0.145,
            top=0.89,
            wspace=0.34,
            hspace=0.46,
        )
        size_axis = figure.add_subplot(grid[0, 0])
        heat_axes = [figure.add_subplot(grid[0, index]) for index in (1, 2)]
        velocity_axis = figure.add_subplot(grid[1, 0])
        occupancy_axis = figure.add_subplot(grid[1, 1:])

        # A: finite-size audit with all stochastic replicas.
        size_items = sorted(
            payload["size_audit"], key=lambda item: int(item["site_count"])
        )
        positions = np.arange(len(size_items), dtype=float)
        for position, item in zip(positions, size_items, strict=True):
            raw_rates = np.asarray(
                [run["per_column_removal_rate_s"] for run in item["runs"]],
                dtype=float,
            )
            offsets = np.linspace(-0.16, 0.16, raw_rates.size)
            size_axis.scatter(
                position + offsets,
                raw_rates,
                s=11,
                color="#4c78a8",
                alpha=0.28,
                edgecolors="none",
                zorder=1,
            )
        size_means = np.asarray(
            [item["per_column_removal_rate_s"]["mean"] for item in size_items],
            dtype=float,
        )
        size_lows = np.asarray(
            [
                item["per_column_removal_rate_s"]["normal_approx_95ci_low"]
                for item in size_items
            ],
            dtype=float,
        )
        size_highs = np.asarray(
            [
                item["per_column_removal_rate_s"]["normal_approx_95ci_high"]
                for item in size_items
            ],
            dtype=float,
        )
        size_axis.errorbar(
            positions,
            size_means,
            yerr=np.vstack((size_means - size_lows, size_highs - size_means)),
            fmt="o-",
            color="#174a7e",
            markerfacecolor="white",
            markeredgewidth=1.4,
            linewidth=1.4,
            capsize=3,
            zorder=3,
            label="mean ± normal 95% CI",
        )
        size_axis.axhline(size_means[-1], color="0.45", linestyle="--", linewidth=0.9)
        size_axis.set_xticks(
            positions, [str(item["site_count"]) for item in size_items]
        )
        size_axis.set_xlabel("surface-patch site count, N")
        size_axis.set_ylabel("removals s$^{-1}$ column$^{-1}$")
        size_axis.set_title("Finite-size / stochastic audit")
        size_axis.grid(axis="y", color="0.88", linewidth=0.7)
        size_axis.legend(loc="best", frameon=False)
        _panel_label(size_axis, "A")

        # B/C: one environmental modifier heatmap for each HF activity.
        heat_image = None
        for panel_index, (axis, hf_activity, data) in enumerate(
            zip(heat_axes, hf_activities, heatmap_data, strict=True)
        ):
            values, lows, highs = data
            heat_image = axis.imshow(
                values,
                cmap="RdBu_r",
                norm=modifier_norm,
                origin="lower",
                aspect="auto",
            )
            for row_index in range(values.shape[0]):
                for column_index in range(values.shape[1]):
                    rgba = heat_image.cmap(heat_image.norm(values[row_index, column_index]))
                    luminance = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
                    axis.text(
                        column_index,
                        row_index,
                        f"{values[row_index, column_index]:.3f}\n"
                        f"[{lows[row_index, column_index]:.3f}, "
                        f"{highs[row_index, column_index]:.3f}]",
                        ha="center",
                        va="center",
                        fontsize=7.1,
                        color="black" if luminance > 0.57 else "white",
                    )
            axis.set_xticks(np.arange(len(products)), [f"{value:g}" for value in products])
            axis.set_yticks(
                np.arange(len(temperatures)),
                [f"{value:.2f}" for value in temperatures],
            )
            axis.set_xlabel("product activity")
            if panel_index == 0:
                axis.set_ylabel("interface temperature (K)")
            else:
                axis.tick_params(labelleft=False)
            axis.set_title(
                f"Relative KMC modifier | HF activity = {hf_activity:g}\n"
                "cell: estimate [paired-bootstrap 95% CI]"
            )
            _panel_label(axis, "B" if panel_index == 0 else "C")
        if heat_image is not None:
            colorbar = figure.colorbar(
                heat_image,
                ax=heat_axes,
                orientation="horizontal",
                fraction=0.055,
                pad=0.19,
                aspect=35,
            )
            colorbar.set_label("relative removal-velocity modifier (reference = 1)")

        # D: literature-normalized velocity at the nominal reference bath.
        material_colors = ("#176d9c", "#d0743c", "#4a9b75", "#8c6bb1")
        for material_index, material in enumerate(materials):
            rows = _select_environment_rows(
                payload,
                material=material,
                temperature_K=reference_temperature,
                hf_activity=reference_hf,
            )
            rows.sort(key=lambda row: float(row["environment"]["product_activity"]))
            if len(rows) != len(products):
                raise ValueError(f"missing reference-bath product rows for {material}")
            x = np.asarray(
                [row["environment"]["product_activity"] for row in rows], dtype=float
            )
            velocity = np.asarray(
                [row["absolute_velocity_nm_min"]["value"] for row in rows],
                dtype=float,
            )
            low = np.asarray(
                [
                    row["absolute_velocity_nm_min"][
                        "kmc_paired_bootstrap_95ci_low"
                    ]
                    for row in rows
                ],
                dtype=float,
            )
            high = np.asarray(
                [
                    row["absolute_velocity_nm_min"][
                        "kmc_paired_bootstrap_95ci_high"
                    ]
                    for row in rows
                ],
                dtype=float,
            )
            color = material_colors[material_index % len(material_colors)]
            velocity_axis.errorbar(
                x,
                velocity,
                yerr=np.vstack((velocity - low, high - velocity)),
                color=color,
                fmt="o-",
                linewidth=1.6,
                capsize=3,
                markerfacecolor="white",
                markeredgewidth=1.3,
                label=f"{material}: KMC 95% CI",
            )
            anchor_uncertainty = rows[0]["absolute_velocity_nm_min"].get(
                "blanket_anchor_uncertainty_nm_min"
            )
            if anchor_uncertainty is not None:
                modifiers = np.asarray(
                    [row["relative_modifier"]["value"] for row in rows], dtype=float
                )
                propagated = float(anchor_uncertainty) * modifiers
                velocity_axis.fill_between(
                    x,
                    velocity - propagated,
                    velocity + propagated,
                    color=color,
                    alpha=0.12,
                    linewidth=0.0,
                )
        velocity_axis.set_xticks(products, [f"{value:g}" for value in products])
        velocity_axis.set_xlabel("product activity")
        velocity_axis.set_ylabel("literature-normalized velocity (nm min$^{-1}$)")
        velocity_axis.set_title("Absolute screening velocity | 298.15 K, HF activity = 1")
        velocity_axis.grid(axis="y", color="0.88", linewidth=0.7)
        velocity_axis.legend(frameon=False, loc="best")
        velocity_axis.text(
            0.02,
            0.03,
            "bars: KMC bootstrap\nshading: blanket-anchor uncertainty (not combined)",
            transform=velocity_axis.transAxes,
            fontsize=7.2,
            va="bottom",
            color="0.3",
        )
        _panel_label(velocity_axis, "D")

        # E: time-averaged state occupancy; dots show raw replicate boundaries.
        occupancy_rows = _select_environment_rows(
            payload,
            material=modifier_material,
            temperature_K=reference_temperature,
            hf_activity=reference_hf,
        )
        occupancy_rows.sort(
            key=lambda row: float(row["environment"]["product_activity"])
        )
        states = ("intact", "activated", "passivated")
        state_colors = {
            "intact": "#c7ced6",
            "activated": "#2a9d8f",
            "passivated": "#e9a23b",
        }
        occupancy_x = np.arange(len(occupancy_rows), dtype=float)
        bottom = np.zeros(len(occupancy_rows), dtype=float)
        means_by_state: dict[str, np.ndarray] = {}
        for state in states:
            means = np.asarray(
                [
                    np.mean(
                        [
                            replicate["conditioned_time_averaged_state_fractions"][state]
                            for replicate in row["replicates"]
                        ]
                    )
                    for row in occupancy_rows
                ],
                dtype=float,
            )
            means_by_state[state] = means
            occupancy_axis.bar(
                occupancy_x,
                means,
                bottom=bottom,
                width=0.62,
                color=state_colors[state],
                edgecolor="white",
                linewidth=0.8,
                label=state,
            )
            for x_value, base, mean in zip(occupancy_x, bottom, means, strict=True):
                if mean >= 0.07:
                    occupancy_axis.text(
                        x_value,
                        base + 0.5 * mean,
                        f"{mean:.2f}",
                        ha="center",
                        va="center",
                        fontsize=8,
                    )
            bottom += means
        # Raw stochastic positions of the first two cumulative boundaries.
        for row_index, row in enumerate(occupancy_rows):
            replicates = row["replicates"]
            offsets = np.linspace(-0.19, 0.19, len(replicates))
            intact_boundary = np.asarray(
                [
                    replicate["conditioned_time_averaged_state_fractions"]["intact"]
                    for replicate in replicates
                ],
                dtype=float,
            )
            activated_boundary = intact_boundary + np.asarray(
                [
                    replicate["conditioned_time_averaged_state_fractions"]["activated"]
                    for replicate in replicates
                ],
                dtype=float,
            )
            occupancy_axis.scatter(
                row_index + offsets,
                intact_boundary,
                s=5,
                color="0.15",
                alpha=0.25,
                linewidths=0.0,
            )
            occupancy_axis.scatter(
                row_index + offsets,
                activated_boundary,
                s=5,
                color="0.15",
                alpha=0.25,
                linewidths=0.0,
            )
        occupancy_axis.set_xticks(
            occupancy_x,
            [f"{row['environment']['product_activity']:g}" for row in occupancy_rows],
        )
        occupancy_axis.set_ylim(0.0, 1.0)
        occupancy_axis.set_xlabel("product activity")
        occupancy_axis.set_ylabel("time-averaged site fraction")
        occupancy_axis.set_title(
            f"Surface-state occupancy | {modifier_material}, 298.15 K, HF activity = 1\n"
            "stacked means; dots are raw replicate boundaries"
        )
        occupancy_axis.legend(
            frameon=False,
            ncol=3,
            loc="upper center",
            bbox_to_anchor=(0.5, -0.16),
        )
        occupancy_axis.grid(axis="y", color="0.90", linewidth=0.7)
        _panel_label(occupancy_axis, "E")

        figure.suptitle(
            "Graph-KMC surface-patch ensemble: stochastic audit and screening response",
            fontsize=14,
            fontweight="bold",
            y=0.965,
        )
        figure.text(
            0.5,
            0.035,
            fill(SURFACE_PATCH_CAVEAT, width=165, break_long_words=False),
            ha="center",
            va="bottom",
            fontsize=8.2,
            color="#7a2e2e",
            bbox={
                "boxstyle": "round,pad=0.45",
                "facecolor": "#fff4ef",
                "edgecolor": "#d5a08c",
                "linewidth": 0.8,
            },
        )
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        figure.savefig(output, dpi=220)
        plt.close(figure)


def _total_removals(model) -> int:
    return int(
        round(
            sum(
                site.attributes.get("removal_count", 0.0)
                for site in model.graph.sites.values()
            )
        )
    )


def generate_representative_trace(
    *,
    site_count: int = 48,
    material: str = "SiN",
    environment: PatchEnvironment = PatchEnvironment(298.15, 1.0, 0.5),
    seed: int = DEFAULT_TRACE_SEED,
    warmup_layers: int = 1,
    measurement_layers: int = 4,
    maximum_events_per_requested_removal: int = 100,
) -> dict[str, object]:
    """Run one fixed-seed patch and return a compact, replayable event trace."""

    for name, value in (
        ("site_count", site_count),
        ("warmup_layers", warmup_layers),
        ("measurement_layers", measurement_layers),
        ("maximum_events_per_requested_removal", maximum_events_per_requested_removal),
    ):
        if not isinstance(value, int) or value <= 0:
            raise ValueError(f"{name} must be a positive integer")
    if site_count < 3:
        raise ValueError("site_count must be at least three")
    if not isinstance(seed, int) or seed < 0:
        raise ValueError("seed must be a non-negative integer")

    kmc = build_surface_patch_kmc(
        site_count,
        material,
        environment,
        seed=seed,
    )
    warmup_target = warmup_layers * site_count
    measurement_target = measurement_layers * site_count
    event_cap = maximum_events_per_requested_removal * (
        warmup_target + measurement_target
    )
    warmup = kmc.run(
        max_events=event_cap,
        stop_condition=lambda model: _total_removals(model) >= warmup_target,
    )
    if _total_removals(kmc) != warmup_target:
        raise RuntimeError("representative trace did not complete warmup")
    site_ids = kmc.graph.site_ids
    measurement_start_s = kmc.time_s
    initial_states = [kmc.graph.sites[site_id].state for site_id in site_ids]
    baseline_removals = np.asarray(
        [
            kmc.graph.sites[site_id].attributes.get("removal_count", 0.0)
            for site_id in site_ids
        ],
        dtype=int,
    )
    final_target = warmup_target + measurement_target
    result = kmc.run(
        max_events=event_cap,
        stop_condition=lambda model: _total_removals(model) >= final_target,
    )
    if _total_removals(kmc) != final_target:
        raise RuntimeError("representative trace did not complete measurement")
    final_removals = np.asarray(
        [
            kmc.graph.sites[site_id].attributes.get("removal_count", 0.0)
            for site_id in site_ids
        ],
        dtype=int,
    )
    measured_removals = final_removals - baseline_removals
    if int(np.sum(measured_removals)) != measurement_target:
        raise RuntimeError("per-site trace removal accounting is inconsistent")
    event_rows = [
        {
            "event_index": index,
            "time_from_measurement_start_s": record.time_s - measurement_start_s,
            "waiting_time_s": record.waiting_time_s,
            "event_name": record.event_name,
            "site_id": record.site_id,
            "old_state": record.old_state,
            "new_state": record.new_state,
        }
        for index, record in enumerate(result.event_log, start=1)
    ]
    return {
        "schema_version": 1,
        "model": "representative regenerative surface-patch graph-KMC trace",
        "notice": SURFACE_PATCH_CAVEAT,
        "configuration": {
            "site_count": site_count,
            "material": material,
            "environment": environment.to_dict(),
            "seed": seed,
            "warmup_layers": warmup_layers,
            "measurement_layers": measurement_layers,
            "maximum_events_per_requested_removal": (
                maximum_events_per_requested_removal
            ),
            "patch_semantics": (
                "periodic ring of independent regenerative surface columns; "
                "site index is not trench depth"
            ),
        },
        "warmup": {
            "target_removals": warmup_target,
            "elapsed_s": warmup.elapsed_s,
            "event_count": warmup.event_count,
            "event_counts": dict(warmup.event_counts),
        },
        "measurement": {
            "target_removals": measurement_target,
            "elapsed_s": result.elapsed_s,
            "event_count": result.event_count,
            "event_counts": dict(result.event_counts),
            "removal_flux_events_s": measurement_target / result.elapsed_s,
            "per_column_removal_rate_s": (
                measurement_target / (site_count * result.elapsed_s)
            ),
            "initial_site_states": initial_states,
            "final_site_states": [
                kmc.graph.sites[site_id].state for site_id in site_ids
            ],
            "removal_counts_by_site": measured_removals.tolist(),
            "removal_count_summary": {
                "mean": float(np.mean(measured_removals)),
                "sample_sd": float(np.std(measured_removals, ddof=1)),
                "minimum": int(np.min(measured_removals)),
                "maximum": int(np.max(measured_removals)),
            },
            "final_state_counts": dict(result.final_state_counts),
            "stop_reason": result.stop_reason,
            "events": event_rows,
        },
    }


def _trace_state_raster(
    trace: Mapping[str, object], sample_count: int = 240
) -> tuple[np.ndarray, np.ndarray]:
    configuration = trace["configuration"]
    measurement = trace["measurement"]
    site_count = int(configuration["site_count"])
    elapsed = float(measurement["elapsed_s"])
    if sample_count < 2:
        raise ValueError("sample_count must be at least two")
    state_code = {"intact": 0, "activated": 1, "passivated": 2}
    current = np.asarray(
        [state_code[state] for state in measurement["initial_site_states"]],
        dtype=np.int8,
    )
    if current.size != site_count:
        raise ValueError("trace initial-state count does not match site count")
    times = np.linspace(0.0, elapsed, sample_count)
    raster = np.empty((site_count, sample_count), dtype=np.int8)
    events = measurement["events"]
    event_index = 0
    for column, sample_time in enumerate(times):
        while (
            event_index < len(events)
            and float(events[event_index]["time_from_measurement_start_s"])
            <= sample_time + 1.0e-12
        ):
            event = events[event_index]
            state = event["new_state"]
            if state not in state_code:
                raise ValueError(f"trace contains unsupported site state {state!r}")
            current[int(event["site_id"])] = state_code[state]
            event_index += 1
        raster[:, column] = current
    return times, raster


def plot_graph_kmc_event_evolution(
    trace: Mapping[str, object], output_path: str | Path
) -> None:
    """Plot a fixed-seed site-state raster and its event/removal evolution."""

    configuration = trace["configuration"]
    measurement = trace["measurement"]
    events = measurement["events"]
    elapsed = float(measurement["elapsed_s"])
    site_count = int(configuration["site_count"])
    times, raster = _trace_state_raster(trace)
    state_colors = ("#d3d9df", "#20988b", "#e5a037")

    with plt.rc_context(_PLOT_STYLE):
        figure = plt.figure(figsize=(12.6, 8.4))
        grid = figure.add_gridspec(
            2,
            2,
            left=0.075,
            right=0.965,
            bottom=0.15,
            top=0.87,
            height_ratios=(1.45, 1.0),
            hspace=0.36,
            wspace=0.28,
        )
        raster_axis = figure.add_subplot(grid[0, :])
        event_axis = figure.add_subplot(grid[1, 0])
        removal_axis = figure.add_subplot(grid[1, 1])

        raster_axis.imshow(
            raster,
            origin="lower",
            aspect="auto",
            interpolation="nearest",
            extent=(0.0, elapsed, -0.5, site_count - 0.5),
            cmap=ListedColormap(state_colors),
            vmin=-0.5,
            vmax=2.5,
        )
        removal_events = [event for event in events if event["event_name"] == "remove"]
        raster_axis.scatter(
            [event["time_from_measurement_start_s"] for event in removal_events],
            [event["site_id"] for event in removal_events],
            s=9,
            marker="|",
            color="#18212b",
            linewidths=0.55,
            alpha=0.75,
            label="removal event",
        )
        raster_axis.set_xlim(0.0, elapsed)
        raster_axis.set_ylim(-0.5, site_count - 0.5)
        raster_axis.set_xlabel("measurement time (s)")
        raster_axis.set_ylabel("regenerative surface-column site index")
        raster_axis.set_title("Site-state evolution; dark ticks mark removals")
        handles = [
            Patch(facecolor=color, edgecolor="none", label=state)
            for state, color in zip(
                ("intact", "activated", "passivated"), state_colors, strict=True
            )
        ]
        handles.append(
            plt.Line2D(
                [], [], color="#18212b", marker="|", linestyle="none", label="remove"
            )
        )
        raster_axis.legend(
            handles=handles,
            frameon=False,
            ncol=4,
            loc="upper center",
            bbox_to_anchor=(0.5, -0.16),
        )
        _panel_label(raster_axis, "A")

        event_names = ("activate", "remove", "passivate", "depassivate")
        event_colors = {
            "activate": "#20988b",
            "remove": "#273746",
            "passivate": "#e5a037",
            "depassivate": "#a5622a",
        }
        counters = Counter()
        event_times = [0.0]
        cumulative = {name: [0] for name in event_names}
        for event in events:
            counters[event["event_name"]] += 1
            event_times.append(float(event["time_from_measurement_start_s"]))
            for name in event_names:
                cumulative[name].append(counters[name])
        for name in event_names:
            event_axis.step(
                event_times,
                cumulative[name],
                where="post",
                color=event_colors[name],
                linewidth=1.45,
                label=f"{name} ({counters[name]})",
            )
        event_axis.set_xlim(0.0, elapsed)
        event_axis.set_xlabel("measurement time (s)")
        event_axis.set_ylabel("cumulative event count")
        event_axis.set_title("Stochastic event sequence")
        event_axis.grid(color="0.88", linewidth=0.7)
        event_axis.legend(frameon=False, ncol=2, loc="upper left")
        _panel_label(event_axis, "B")

        removal_counts = np.asarray(measurement["removal_counts_by_site"], dtype=int)
        removal_axis.bar(
            np.arange(site_count),
            removal_counts,
            width=0.88,
            color="#4c78a8",
            edgecolor="none",
        )
        mean_removals = float(np.mean(removal_counts))
        removal_axis.axhline(
            mean_removals,
            color="#a33d32",
            linestyle="--",
            linewidth=1.2,
            label=f"mean = {mean_removals:.1f}",
        )
        removal_axis.set_xlim(-0.8, site_count - 0.2)
        removal_axis.set_xlabel("regenerative surface-column site index")
        removal_axis.set_ylabel("removal events during measurement")
        removal_axis.set_title("Per-column stochastic removal count")
        removal_axis.grid(axis="y", color="0.88", linewidth=0.7)
        removal_axis.legend(frameon=False, loc="upper right")
        summary = measurement["removal_count_summary"]
        removal_axis.text(
            0.02,
            0.96,
            f"range {summary['minimum']}–{summary['maximum']} | "
            f"sample SD {summary['sample_sd']:.2f}",
            transform=removal_axis.transAxes,
            va="top",
            fontsize=8,
            color="0.25",
        )
        _panel_label(removal_axis, "C")

        environment = configuration["environment"]
        figure.suptitle(
            "Representative graph-KMC event evolution\n"
            f"N={site_count}, {configuration['material']}, "
            f"T={environment['temperature_K']:.2f} K, "
            f"HF activity={environment['hf_activity']:g}, "
            f"product activity={environment['product_activity']:g}, "
            f"seed={configuration['seed']}",
            fontsize=13,
            fontweight="bold",
            y=0.96,
        )
        figure.text(
            0.5,
            0.035,
            fill(
                SURFACE_PATCH_CAVEAT
                + " Site-to-site variation here is stochastic, not a predicted "
                "spatial correlation.",
                width=145,
                break_long_words=False,
            ),
            ha="center",
            va="bottom",
            fontsize=8.2,
            color="#7a2e2e",
            bbox={
                "boxstyle": "round,pad=0.45",
                "facecolor": "#fff4ef",
                "edgecolor": "#d5a08c",
                "linewidth": 0.8,
            },
        )
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        figure.savefig(output, dpi=220)
        plt.close(figure)


def write_trace_json(trace: Mapping[str, object], output_path: str | Path) -> None:
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(
            trace,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )


def create_graph_kmc_visualizations(
    sweep_json: str | Path = DEFAULT_SWEEP_JSON,
    *,
    summary_figure: str | Path = DEFAULT_SUMMARY_FIGURE,
    event_figure: str | Path = DEFAULT_EVENT_FIGURE,
    trace_json: str | Path = DEFAULT_TRACE_JSON,
    trace_site_count: int = 48,
    trace_seed: int = DEFAULT_TRACE_SEED,
    trace_warmup_layers: int = 1,
    trace_measurement_layers: int = 4,
) -> dict[str, object]:
    """Create both figures and the replayable representative trace JSON."""

    payload = load_sweep_payload(sweep_json)
    plot_graph_kmc_summary(payload, summary_figure)
    trace = generate_representative_trace(
        site_count=trace_site_count,
        seed=trace_seed,
        warmup_layers=trace_warmup_layers,
        measurement_layers=trace_measurement_layers,
    )
    write_trace_json(trace, trace_json)
    plot_graph_kmc_event_evolution(trace, event_figure)
    return trace


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Visualize the graph-KMC velocity ensemble and rerun one fixed-seed "
            "representative surface-patch trace."
        )
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_SWEEP_JSON)
    parser.add_argument(
        "--summary-figure", type=Path, default=DEFAULT_SUMMARY_FIGURE
    )
    parser.add_argument("--event-figure", type=Path, default=DEFAULT_EVENT_FIGURE)
    parser.add_argument("--trace-output", type=Path, default=DEFAULT_TRACE_JSON)
    parser.add_argument("--trace-site-count", type=int, default=48)
    parser.add_argument("--trace-seed", type=int, default=DEFAULT_TRACE_SEED)
    parser.add_argument("--trace-warmup-layers", type=int, default=1)
    parser.add_argument("--trace-measurement-layers", type=int, default=4)
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    trace = create_graph_kmc_visualizations(
        args.input,
        summary_figure=args.summary_figure,
        event_figure=args.event_figure,
        trace_json=args.trace_output,
        trace_site_count=args.trace_site_count,
        trace_seed=args.trace_seed,
        trace_warmup_layers=args.trace_warmup_layers,
        trace_measurement_layers=args.trace_measurement_layers,
    )
    print(f"wrote {args.summary_figure}")
    print(f"wrote {args.event_figure}")
    print(
        f"wrote {args.trace_output}: "
        f"{trace['measurement']['event_count']} representative events"
    )
    return trace


if __name__ == "__main__":
    main()


__all__ = [
    "DEFAULT_EVENT_FIGURE",
    "DEFAULT_SUMMARY_FIGURE",
    "DEFAULT_SWEEP_JSON",
    "DEFAULT_TRACE_JSON",
    "DEFAULT_TRACE_SEED",
    "SURFACE_PATCH_CAVEAT",
    "create_graph_kmc_visualizations",
    "generate_representative_trace",
    "load_sweep_payload",
    "plot_graph_kmc_event_evolution",
    "plot_graph_kmc_summary",
    "write_trace_json",
]

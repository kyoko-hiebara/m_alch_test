"""HF-only bottom-residue mechanism screen.

This module combines only quantities that can be compared without pretending
that the five mechanism families share one calibrated state variable:

* Kawarazaki Fig. 2 dHF-only blanket endpoints provide the chemical clock.
* A sub-grid bottom-pad burn-down model varies initial residue thickness and
  a local reaction-rate multiplier at fixed physical HF times.
* Existing 2-D wetting/gas and product/passivation results are reduced to
  stage-specific fingerprints.
* The existing rinse/dry mass-balance closure is evaluated independently from
  the in-etch mechanisms.

The separation is intentional.  The full-trench continuum/KMC models start
from a completely GAP-filled cavity, whereas a 0.5--5 nm bottom pad is below
their usual 1--2 nm screening grid.  The bottom-pad calculation therefore
uses the blanket-linear thickness law directly and never presents a
full-depth clear time as a thin-residue prediction.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from attachment_discrimination import post_hf_closure
from literature_parameters import (
    KAWARAZAKI_2024_FIG2_ENDPOINTS,
    get_cyclic_etch_endpoint,
    get_literature_preset,
)
from trench_geometry import GEOMETRY_PRESETS


SCHEMA_VERSION = "hf-only-bottom-residue-screen/v1"

KAWARAZAKI_DHF_PRESET_IDS = (
    "kawarazaki_sicn_c22_dhf0p15_linear30s",
    "kawarazaki_sicn_c40_dhf0p15_linear30s",
    "kawarazaki_siocn_c5_dhf0p15_linear30s",
    "kawarazaki_sin_reference_dhf0p15_linear30s",
)

_PRESET_TO_ENDPOINT = {
    f"{endpoint_id}_dhf0p15_linear30s": endpoint_id
    for endpoint_id in KAWARAZAKI_2024_FIG2_ENDPOINTS
}

MODEL_NOTICE = (
    "HF-only mechanism screening, not a process recipe. Blanket rates are "
    "provisional linear normalizations of one raster-digitized 30 s endpoint. "
    "Bottom-pad thickness and local-rate multipliers are deterministic "
    "hypotheses; wetting/gas, product/passivation and rinse/dry coefficients "
    "remain uncalibrated until same-lot patterned measurements are supplied. "
    "No ozone-enabled removal term is used."
)


def _positive_tuple(name: str, values: Iterable[float]) -> tuple[float, ...]:
    result = tuple(float(value) for value in values)
    if not result or any(
        not math.isfinite(value) or value <= 0.0 for value in result
    ):
        raise ValueError(f"{name} must contain finite positive values")
    if len(set(result)) != len(result):
        raise ValueError(f"{name} cannot contain duplicates")
    return result


def _nonnegative_tuple(name: str, values: Iterable[float]) -> tuple[float, ...]:
    result = tuple(float(value) for value in values)
    if not result or any(
        not math.isfinite(value) or value < 0.0 for value in result
    ):
        raise ValueError(f"{name} must contain finite non-negative values")
    if len(set(result)) != len(result):
        raise ValueError(f"{name} cannot contain duplicates")
    return result


@dataclass(frozen=True)
class HFOnlyResidueScreenConfig:
    """Inputs for the calibrated bottom-pad and post-HF closure screens."""

    geometry_ids: tuple[str, ...] = ("10_10_180", "7_7_170")
    preset_ids: tuple[str, ...] = KAWARAZAKI_DHF_PRESET_IDS
    bottom_pad_thicknesses_nm: tuple[float, ...] = (0.5, 1.0, 2.0, 5.0)
    bottom_local_rate_factors: tuple[float, ...] = (1.0, 0.3, 0.1)
    hf_exposure_times_s: tuple[float, ...] = (
        30.0,
        60.0,
        120.0,
        300.0,
        600.0,
        1_800.0,
        3_600.0,
    )
    residue_detection_threshold_nm: float = 0.05
    post_hf_to_dry_window_s: float = 60.0
    rinse_start_delay_s: float = 30.0
    rinse_exchange_rates_s: tuple[float, ...] = (0.0, 0.05, 0.20)
    drying_duration_s: float = 60.0
    drying_rates_s: tuple[float, ...] = (
        1.0 / 120.0,
        1.0 / 30.0,
        1.0 / 5.0,
    )
    drydown_capture_fraction: float = 0.05
    surface_allocation_modes: tuple[str, ...] = (
        "equal_affinity",
        "bottom_selective_4x",
    )

    def __post_init__(self) -> None:
        if not self.geometry_ids or set(self.geometry_ids).difference(
            GEOMETRY_PRESETS
        ):
            raise ValueError("geometry_ids must be a non-empty known selection")
        if len(set(self.geometry_ids)) != len(self.geometry_ids):
            raise ValueError("geometry_ids cannot contain duplicates")
        if not self.preset_ids or set(self.preset_ids).difference(
            _PRESET_TO_ENDPOINT
        ):
            raise ValueError(
                "preset_ids must be Kawarazaki Fig. 2 dHF-only presets"
            )
        if len(set(self.preset_ids)) != len(self.preset_ids):
            raise ValueError("preset_ids cannot contain duplicates")
        object.__setattr__(
            self,
            "bottom_pad_thicknesses_nm",
            _positive_tuple(
                "bottom_pad_thicknesses_nm",
                self.bottom_pad_thicknesses_nm,
            ),
        )
        factors = _positive_tuple(
            "bottom_local_rate_factors", self.bottom_local_rate_factors
        )
        if any(value > 1.0 for value in factors):
            raise ValueError("bottom_local_rate_factors cannot exceed one")
        object.__setattr__(self, "bottom_local_rate_factors", factors)
        object.__setattr__(
            self,
            "hf_exposure_times_s",
            _nonnegative_tuple(
                "hf_exposure_times_s", self.hf_exposure_times_s
            ),
        )
        if (
            not math.isfinite(self.residue_detection_threshold_nm)
            or self.residue_detection_threshold_nm < 0.0
        ):
            raise ValueError(
                "residue_detection_threshold_nm must be finite and non-negative"
            )
        for name in (
            "post_hf_to_dry_window_s",
            "drying_duration_s",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if (
            not math.isfinite(self.rinse_start_delay_s)
            or self.rinse_start_delay_s < 0.0
        ):
            raise ValueError(
                "rinse_start_delay_s must be finite and non-negative"
            )
        object.__setattr__(
            self,
            "rinse_exchange_rates_s",
            _nonnegative_tuple(
                "rinse_exchange_rates_s", self.rinse_exchange_rates_s
            ),
        )
        object.__setattr__(
            self,
            "drying_rates_s",
            _positive_tuple("drying_rates_s", self.drying_rates_s),
        )
        if not 0.0 <= self.drydown_capture_fraction <= 1.0:
            raise ValueError("drydown_capture_fraction must lie within [0, 1]")
        known_modes = {"equal_affinity", "bottom_selective_4x"}
        if not self.surface_allocation_modes or set(
            self.surface_allocation_modes
        ).difference(known_modes):
            raise ValueError("unknown or empty surface_allocation_modes")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for name in (
            "geometry_ids",
            "preset_ids",
            "bottom_pad_thicknesses_nm",
            "bottom_local_rate_factors",
            "hf_exposure_times_s",
            "rinse_exchange_rates_s",
            "drying_rates_s",
            "surface_allocation_modes",
        ):
            result[name] = list(result[name])
        return result


def _endpoint_for_preset(preset_id: str):
    try:
        endpoint_id = _PRESET_TO_ENDPOINT[preset_id]
    except KeyError as exc:
        raise ValueError(
            f"{preset_id!r} is not a Kawarazaki dHF-only preset"
        ) from exc
    return get_cyclic_etch_endpoint(endpoint_id)


def blanket_anchor_rows(
    config: HFOnlyResidueScreenConfig,
) -> list[dict[str, object]]:
    """Return the dHF-only central rates and one-raster sensitivity span."""

    rows: list[dict[str, object]] = []
    for preset_id in config.preset_ids:
        preset = get_literature_preset(preset_id)
        endpoint = _endpoint_for_preset(preset_id)
        resolution = float(endpoint.digitization_resolution_nm)
        duration = float(endpoint.dhf_duration_s)
        amount = float(endpoint.dhf_only_etch_amount_nm)
        lower_amount = max(0.0, amount - resolution)
        upper_amount = amount + resolution
        rows.append(
            {
                "preset_id": preset_id,
                "endpoint_id": endpoint.key,
                "material": endpoint.material,
                "film_description": endpoint.film_description,
                "nominal_carbon_percent": endpoint.nominal_carbon_percent,
                "dhf_reported_percent": endpoint.dhf_reported_percent,
                "source_duration_s": duration,
                "source_etch_amount_nm": amount,
                "central_rate_nm_min": preset.planar_rate_nm_min,
                "one_raster_rate_sensitivity_nm_min": {
                    "lower": lower_amount * 60.0 / duration,
                    "upper": upper_amount * 60.0 / duration,
                    "is_statistical_interval": False,
                },
                "digitization_resolution_nm": resolution,
                "measurement_temperature_K": (
                    preset.reported_solution_temperature_K
                ),
                "ozone_used_in_rate_anchor": False,
                "linearity_assumption": endpoint.linearity_assumption,
                "source": endpoint.to_dict()["source"],
            }
        )
    return rows


def _clear_time_s(thickness_nm: float, rate_nm_s: float) -> float | None:
    if rate_nm_s <= 0.0:
        return None
    return thickness_nm / rate_nm_s


def run_bottom_pad_burn_down(
    config: HFOnlyResidueScreenConfig,
) -> dict[str, object]:
    """Burn down a sub-grid bottom residue pad with the blanket-linear law."""

    anchors = {row["preset_id"]: row for row in blanket_anchor_rows(config)}
    cases: list[dict[str, object]] = []
    for geometry_id in config.geometry_ids:
        geometry = GEOMETRY_PRESETS[geometry_id]
        for preset_id in config.preset_ids:
            anchor = anchors[preset_id]
            central_rate_nm_s = float(anchor["central_rate_nm_min"]) / 60.0
            rate_span = anchor["one_raster_rate_sensitivity_nm_min"]
            assert isinstance(rate_span, Mapping)
            lower_rate_nm_s = float(rate_span["lower"]) / 60.0
            upper_rate_nm_s = float(rate_span["upper"]) / 60.0
            for thickness_nm in config.bottom_pad_thicknesses_nm:
                for local_factor in config.bottom_local_rate_factors:
                    local_rate_nm_s = central_rate_nm_s * local_factor
                    central_clear_s = _clear_time_s(
                        thickness_nm, local_rate_nm_s
                    )
                    fastest_clear_s = _clear_time_s(
                        thickness_nm, upper_rate_nm_s * local_factor
                    )
                    slowest_clear_s = _clear_time_s(
                        thickness_nm, lower_rate_nm_s * local_factor
                    )
                    time_rows = []
                    for exposure_s in config.hf_exposure_times_s:
                        etched_nm = local_rate_nm_s * exposure_s
                        remaining_nm = max(0.0, thickness_nm - etched_nm)
                        time_rows.append(
                            {
                                "exposure_time_s": exposure_s,
                                "etched_thickness_nm": etched_nm,
                                "remaining_thickness_nm": remaining_nm,
                                "remaining_fraction": (
                                    remaining_nm / thickness_nm
                                ),
                                "remaining_cross_section_area_nm2_per_nm_span": (
                                    geometry.bottom_width_nm * remaining_nm
                                ),
                                "detectable_at_threshold": (
                                    remaining_nm
                                    > config.residue_detection_threshold_nm
                                ),
                            }
                        )
                    cases.append(
                        {
                            "case_id": (
                                f"{geometry_id}__{preset_id}__"
                                f"h{thickness_nm:g}__f{local_factor:g}"
                            ),
                            "geometry_id": geometry_id,
                            "bottom_width_nm": geometry.bottom_width_nm,
                            "depth_nm": geometry.depth_nm,
                            "preset_id": preset_id,
                            "material": anchor["material"],
                            "initial_bottom_pad_thickness_nm": thickness_nm,
                            "bottom_local_rate_factor": local_factor,
                            "central_local_rate_nm_min": (
                                float(anchor["central_rate_nm_min"])
                                * local_factor
                            ),
                            "central_clear_time_s": central_clear_s,
                            "central_clear_time_min": (
                                None
                                if central_clear_s is None
                                else central_clear_s / 60.0
                            ),
                            "one_raster_clear_time_sensitivity": {
                                "fastest": fastest_clear_s,
                                "slowest": slowest_clear_s,
                                "slowest_is_unbounded": (
                                    slowest_clear_s is None
                                ),
                                "is_statistical_interval": False,
                            },
                            "thickness_rate_degeneracy_coordinate_nm": (
                                thickness_nm / local_factor
                            ),
                            "time_points": time_rows,
                        }
                    )
    return {
        "model": "sub-grid bottom-pad linear burn-down",
        "calibration": "Kawarazaki Fig. 2 dHF-only central blanket rate",
        "ozone_terms_used": False,
        "assumptions": {
            "linear_blanket_rate": True,
            "fully_wetted_bottom_pad": True,
            "constant_local_rate_factor": True,
            "incubation_or_breakthrough": False,
            "passivation": False,
            "product_inhibition": False,
            "film_thickness_and_rate_factor_separately_identifiable": False,
        },
        "cases": cases,
    }


def _surface_allocation(
    geometry_id: str,
    mode: str,
) -> dict[str, float | str]:
    geometry = GEOMETRY_PRESETS[geometry_id]
    wall_length_nm = 2.0 * geometry.depth_nm
    bottom_length_nm = geometry.bottom_width_nm
    if mode == "equal_affinity":
        wall_affinity = bottom_affinity = 1.0
    elif mode == "bottom_selective_4x":
        wall_affinity = 1.0
        bottom_affinity = 4.0
    else:
        raise ValueError(f"unknown allocation mode {mode!r}")
    wall_weight = wall_length_nm * wall_affinity
    bottom_weight = bottom_length_nm * bottom_affinity
    total = wall_weight + bottom_weight
    return {
        "mode": mode,
        "wall_length_nm_per_nm_span": wall_length_nm,
        "bottom_length_nm_per_nm_span": bottom_length_nm,
        "wall_affinity": wall_affinity,
        "bottom_affinity": bottom_affinity,
        "wall_inventory_fraction": wall_weight / total,
        "bottom_inventory_fraction": bottom_weight / total,
        "bottom_to_wall_areal_density_ratio": (
            bottom_affinity / wall_affinity
        ),
    }


def run_redeposition_closure_screen(
    config: HFOnlyResidueScreenConfig,
) -> dict[str, object]:
    """Evaluate rinse/dry capture independently of in-etch passivation."""

    post_conditions: list[dict[str, object]] = []
    reference_drying_rate = 1.0 / 30.0
    for dry_enabled in (False, True):
        for immediate_quench in (False, True):
            # Immediate quench is redundant when no dry is requested; retain
            # only one no-dry control to keep the decision table compact.
            if not dry_enabled and immediate_quench:
                continue
            for rinse_rate in config.rinse_exchange_rates_s:
                for drying_rate in (
                    config.drying_rates_s
                    if dry_enabled
                    else (reference_drying_rate,)
                ):
                    closure = post_hf_closure(
                        1.0,
                        post_hf_to_dry_window_s=(
                            config.post_hf_to_dry_window_s
                        ),
                        rinse_start_delay_s=config.rinse_start_delay_s,
                        rinse_exchange_rate_s=rinse_rate,
                        immediate_quench=immediate_quench,
                        dry_enabled=dry_enabled,
                        drying_rate_s=drying_rate,
                        drying_duration_s=config.drying_duration_s,
                        drydown_capture_fraction=(
                            config.drydown_capture_fraction
                        ),
                    )
                    post_conditions.append(
                        {
                            "condition_id": (
                                f"dry{int(dry_enabled)}__"
                                f"quench{int(immediate_quench)}__"
                                f"rinse{rinse_rate:g}__"
                                f"dryrate{drying_rate:g}"
                            ),
                            **closure,
                        }
                    )

    cases: list[dict[str, object]] = []
    for geometry_id in config.geometry_ids:
        for mode in config.surface_allocation_modes:
            allocation = _surface_allocation(geometry_id, mode)
            bottom_share = float(allocation["bottom_inventory_fraction"])
            for condition in post_conditions:
                captured = float(
                    condition["captured_precursor_inventory_native"]
                )
                cases.append(
                    {
                        "case_id": (
                            f"{geometry_id}__{mode}__"
                            f"{condition['condition_id']}"
                        ),
                        "geometry_id": geometry_id,
                        "allocation": allocation,
                        "post_hf_condition": condition,
                        "captured_fraction_of_generated_inventory": captured,
                        "bottom_captured_fraction_of_generated_inventory": (
                            captured * bottom_share
                        ),
                        "wall_captured_fraction_of_generated_inventory": (
                            captured * (1.0 - bottom_share)
                        ),
                        "capture_plus_rinse_and_uncaptured_closure": (
                            abs(
                                float(
                                    condition[
                                        "rinse_removed_inventory_native"
                                    ]
                                )
                                + captured
                                + float(
                                    condition[
                                        "uncaptured_soluble_inventory_native"
                                    ]
                                )
                                - 1.0
                            )
                        ),
                    }
                )
    return {
        "model": "well-mixed rinse exchange plus first-order dry capture",
        "generated_inventory_basis": 1.0,
        "capture_is_separate_from_surface_allocation": True,
        "coefficients_calibrated": False,
        "post_hf_conditions": post_conditions,
        "cases": cases,
        "limitations": {
            "evaporation_hydrodynamics": False,
            "local_meniscus_residence_time": False,
            "deposit_species_identity": False,
            "surface_allocation": (
                "contact length times prescribed affinity; total capture is "
                "invariant to affinity"
            ),
        },
    }


def summarize_wetting_payload(
    payload: Mapping[str, object],
) -> list[dict[str, object]]:
    """Extract the cause-identification fields from a wetting sweep."""

    result: list[dict[str, object]] = []
    cases = payload.get("coupled_cases", [])
    if not isinstance(cases, Sequence):
        raise ValueError("wetting payload has no coupled_cases sequence")
    for case in cases:
        if not isinstance(case, Mapping):
            continue
        outcome = case.get("outcome")
        if not isinstance(outcome, Mapping):
            continue
        geometry = case.get("geometry")
        result.append(
            {
                "geometry_id": case.get("geometry_name"),
                "geometry": geometry,
                "scenario": case.get("scenario"),
                "scenario_interpretation": case.get(
                    "scenario_interpretation"
                ),
                "remaining_mass_fraction": outcome.get(
                    "remaining_mass_fraction"
                ),
                "bottom_15pct_remaining_fraction": outcome.get(
                    "bottom_15pct_remaining_fraction"
                ),
                "near_wall_remaining_fraction": outcome.get(
                    "near_wall_remaining_fraction"
                ),
                "final_gas_area_nm2": outcome.get("gas_area_nm2"),
                "gas_area_quantization_error_nm2": outcome.get(
                    "gas_area_quantization_error_nm2"
                ),
                "contact_line_depth_nm": outcome.get(
                    "contact_line_depth_nm"
                ),
                "gas_pressure_Pa": outcome.get("gas_pressure_Pa"),
                "high_pressure_model_warning": outcome.get(
                    "high_pressure_model_warning"
                ),
                "gas_subgrid_representation_warning": outcome.get(
                    "gas_subgrid_representation_warning"
                ),
                "phase_partition_relative_error": outcome.get(
                    "phase_partition_relative_error"
                ),
            }
        )
    return result


def summarize_wetting_mesh_convergence(
    payloads_by_grid: Mapping[str, Mapping[str, object]],
) -> dict[str, object]:
    """Compare common wetting/gas cases across a grid-spacing ladder.

    This is a numerical fingerprint check, not a calibration of contact
    angle, pinning delay, gas nucleation, or gas persistence.
    """

    if len(payloads_by_grid) < 2:
        raise ValueError("at least two wetting payloads are required")

    rows_by_grid: dict[float, dict[tuple[str, str], dict[str, object]]] = {}
    for label, payload in payloads_by_grid.items():
        config = payload.get("config")
        if not isinstance(config, Mapping):
            raise ValueError(f"wetting payload {label!r} has no config")
        grid_spacing_nm = float(config["grid_spacing_nm"])
        if not math.isfinite(grid_spacing_nm) or grid_spacing_nm <= 0.0:
            raise ValueError("wetting grid spacing must be finite and positive")
        if grid_spacing_nm in rows_by_grid:
            raise ValueError(
                f"duplicate wetting grid spacing {grid_spacing_nm:g} nm"
            )
        case_rows: dict[tuple[str, str], dict[str, object]] = {}
        for row in summarize_wetting_payload(payload):
            key = (str(row["geometry_id"]), str(row["scenario"]))
            if key in case_rows:
                raise ValueError(
                    f"duplicate wetting case {key!r} at {grid_spacing_nm:g} nm"
                )
            case_rows[key] = row
        if not case_rows:
            raise ValueError(f"wetting payload {label!r} has no cases")
        rows_by_grid[grid_spacing_nm] = case_rows

    common_keys = set.intersection(
        *(set(case_rows) for case_rows in rows_by_grid.values())
    )
    if not common_keys:
        raise ValueError("wetting payloads have no common cases")

    grid_spacings_nm = sorted(rows_by_grid, reverse=True)
    fine_grid_spacing_nm = min(grid_spacings_nm)
    near_clear_limits = {
        "remaining_mass_fraction": 0.002,
        "bottom_15pct_remaining_fraction": 0.01,
    }
    persistent_bottom_limit = 0.99
    expected_fingerprints = {
        "baseline_inherited_liquid": "near_clear",
        "bottom_gas_ideal_compression": "near_clear",
        "entrance_delayed": "persistent_bottom",
        "bottom_gas_fixed_volume_bound": "persistent_bottom",
        "combined_adverse": "persistent_bottom",
    }

    cases: list[dict[str, object]] = []
    fingerprint_checks: list[dict[str, object]] = []
    for geometry_id, scenario in sorted(common_keys):
        ladder: list[dict[str, object]] = []
        for grid_spacing_nm in grid_spacings_nm:
            row = rows_by_grid[grid_spacing_nm][(geometry_id, scenario)]
            ladder.append(
                {
                    "grid_spacing_nm": grid_spacing_nm,
                    "remaining_mass_fraction": float(
                        row["remaining_mass_fraction"]
                    ),
                    "bottom_15pct_remaining_fraction": float(
                        row["bottom_15pct_remaining_fraction"]
                    ),
                    "final_gas_area_nm2": float(
                        row["final_gas_area_nm2"]
                    ),
                    "gas_area_quantization_error_nm2": float(
                        row["gas_area_quantization_error_nm2"]
                    ),
                    "phase_partition_relative_error": float(
                        row["phase_partition_relative_error"]
                    ),
                }
            )
        total_values = [
            float(point["remaining_mass_fraction"]) for point in ladder
        ]
        bottom_values = [
            float(point["bottom_15pct_remaining_fraction"])
            for point in ladder
        ]
        cases.append(
            {
                "geometry_id": geometry_id,
                "scenario": scenario,
                "ladder": ladder,
                "remaining_mass_fraction_range": (
                    max(total_values) - min(total_values)
                ),
                "bottom_15pct_remaining_fraction_range": (
                    max(bottom_values) - min(bottom_values)
                ),
            }
        )

        expected = expected_fingerprints.get(scenario)
        if expected is None:
            continue
        if expected == "near_clear":
            passed = all(
                float(point["remaining_mass_fraction"])
                <= near_clear_limits["remaining_mass_fraction"]
                and float(point["bottom_15pct_remaining_fraction"])
                <= near_clear_limits["bottom_15pct_remaining_fraction"]
                for point in ladder
            )
        else:
            passed = all(
                float(point["bottom_15pct_remaining_fraction"])
                >= persistent_bottom_limit
                for point in ladder
            )
        fingerprint_checks.append(
            {
                "geometry_id": geometry_id,
                "scenario": scenario,
                "expected": expected,
                "passed": passed,
            }
        )

    return {
        "purpose": (
            "numerical fingerprint check for wetting/gas failure-mode "
            "branches; not physical calibration"
        ),
        "grid_spacings_nm": grid_spacings_nm,
        "finest_grid_spacing_nm": fine_grid_spacing_nm,
        "common_case_count": len(cases),
        "criteria": {
            "near_clear_limits": near_clear_limits,
            "persistent_bottom_minimum_fraction": persistent_bottom_limit,
        },
        "cases": cases,
        "fingerprint_checks": fingerprint_checks,
        "qualitative_fingerprint_preserved": bool(fingerprint_checks)
        and all(bool(check["passed"]) for check in fingerprint_checks),
    }


def _checkpoint_by_value(
    case: Mapping[str, object],
    *,
    key: str,
    requested_value: float,
) -> Mapping[str, object] | None:
    entries = case.get(key, [])
    if not isinstance(entries, Sequence):
        return None
    for entry in entries:
        if not isinstance(entry, Mapping):
            continue
        try:
            value = float(entry["requested_value"])
        except (KeyError, TypeError, ValueError):
            continue
        if math.isclose(
            value, requested_value, rel_tol=0.0, abs_tol=1.0e-12
        ):
            return entry
    return None


def summarize_product_passivation_payload(
    payload: Mapping[str, object],
    *,
    normalized_time: float | None = 1.0,
    absolute_time_s: float | None = None,
) -> list[dict[str, object]]:
    """Extract in-etch product/passivation fingerprints at a common dose."""

    if (normalized_time is None) == (absolute_time_s is None):
        raise ValueError(
            "select exactly one of normalized_time or absolute_time_s"
        )
    checkpoint_key = (
        "time_checkpoints"
        if normalized_time is not None
        else "absolute_time_checkpoints"
    )
    requested_value = (
        float(normalized_time)
        if normalized_time is not None
        else float(absolute_time_s)
    )
    cases = payload.get("cases", [])
    if not isinstance(cases, Sequence):
        raise ValueError("product/passivation payload has no cases sequence")
    result: list[dict[str, object]] = []
    for case in cases:
        if not isinstance(case, Mapping):
            continue
        checkpoint = _checkpoint_by_value(
            case,
            key=checkpoint_key,
            requested_value=requested_value,
        )
        if checkpoint is None:
            continue
        fields = checkpoint.get("fields", {})
        residue = checkpoint.get("residue", {})
        result.append(
            {
                "geometry_id": str(case.get("case_id", "")).split("__")[0],
                "preset_id": case.get("preset_key"),
                "material": case.get("material"),
                "scenario": (
                    case.get("scenario", {}).get("key")
                    if isinstance(case.get("scenario"), Mapping)
                    else None
                ),
                "time_basis": (
                    "time_over_planar_clear"
                    if normalized_time is not None
                    else "physical_time_s"
                ),
                "requested_time_value": requested_value,
                "time_s": checkpoint.get("time_s"),
                "time_over_planar_clear": checkpoint.get(
                    "time_over_planar_clear"
                ),
                "remaining_mass_fraction": checkpoint.get(
                    "remaining_mass_fraction"
                ),
                "bottom_region_remaining_fraction": (
                    residue.get("bottom_region", {}).get(
                        "remaining_fraction_of_region"
                    )
                    if isinstance(residue, Mapping)
                    and isinstance(residue.get("bottom_region"), Mapping)
                    else None
                ),
                "maximum_product_mol_m3": (
                    fields.get("maximum_product_mol_m3")
                    if isinstance(fields, Mapping)
                    else None
                ),
                "mean_interface_product_mol_m3": (
                    fields.get("mean_interface_product_mol_m3")
                    if isinstance(fields, Mapping)
                    else None
                ),
                "maximum_passivation": (
                    fields.get("maximum_passivation")
                    if isinstance(fields, Mapping)
                    else None
                ),
                "mean_interface_passivation": (
                    fields.get("mean_interface_passivation")
                    if isinstance(fields, Mapping)
                    else None
                ),
                "all_numerics_converged": all(
                    bool(case.get("convergence", {}).get(name, False))
                    for name in ("reactant", "product", "nonlinear")
                ),
                "maximum_product_inventory_balance_relative_error": (
                    case.get("convergence", {}).get(
                        "maximum_product_inventory_balance_relative_error"
                    )
                    if isinstance(case.get("convergence"), Mapping)
                    else None
                ),
            }
        )
    return result


def sha256_file(path: str | Path) -> str:
    target = Path(path)
    digest = hashlib.sha256()
    with target.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save_json(payload: Mapping[str, object], path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return target


def save_bottom_pad_csv(
    payload: Mapping[str, object],
    path: str | Path,
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = (
        "case_id",
        "geometry_id",
        "preset_id",
        "material",
        "initial_bottom_pad_thickness_nm",
        "bottom_local_rate_factor",
        "central_local_rate_nm_min",
        "central_clear_time_min",
        "exposure_time_s",
        "etched_thickness_nm",
        "remaining_thickness_nm",
        "remaining_fraction",
        "detectable_at_threshold",
    )
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for case in payload.get("cases", []):
            if not isinstance(case, Mapping):
                continue
            common = {
                key: case.get(key)
                for key in fields
                if key not in {
                    "exposure_time_s",
                    "etched_thickness_nm",
                    "remaining_thickness_nm",
                    "remaining_fraction",
                    "detectable_at_threshold",
                }
            }
            for point in case.get("time_points", []):
                if isinstance(point, Mapping):
                    writer.writerow(
                        {
                            **common,
                            **{
                                key: point.get(key)
                                for key in fields
                                if key in point
                            },
                        }
                    )
    return target


def build_screen_payload(
    config: HFOnlyResidueScreenConfig,
    *,
    wetting_payload: Mapping[str, object] | None = None,
    wetting_mesh_convergence_payload: Mapping[str, object] | None = None,
    product_passivation_payload: Mapping[str, object] | None = None,
    component_artifacts: Mapping[str, Mapping[str, object]] | None = None,
) -> dict[str, object]:
    """Assemble the stage-separated screen without merging state variables."""

    anchors = blanket_anchor_rows(config)
    bottom_pad = run_bottom_pad_burn_down(config)
    redeposition = run_redeposition_closure_screen(config)
    wetting_summary = (
        [] if wetting_payload is None else summarize_wetting_payload(
            wetting_payload
        )
    )
    passivation_summary = (
        []
        if product_passivation_payload is None
        else summarize_product_passivation_payload(
            product_passivation_payload
        )
    )
    passivation_absolute = (
        {}
        if product_passivation_payload is None
        else {
            f"{time_s:g}": summarize_product_passivation_payload(
                product_passivation_payload,
                normalized_time=None,
                absolute_time_s=time_s,
            )
            for time_s in (30.0, 60.0, 120.0)
        }
    )
    payload = {
        "schema_version": SCHEMA_VERSION,
        "model_name": "stage-separated HF-only bottom-residue screen",
        "notice": MODEL_NOTICE,
        "config": config.to_dict(),
        "blanket_anchors": anchors,
        "bottom_pad_burn_down": bottom_pad,
        "wetting_and_gas": {
            "included": wetting_payload is not None,
            "calibrated": False,
            "summary": wetting_summary,
            "mesh_convergence": dict(
                wetting_mesh_convergence_payload or {}
            ),
        },
        "product_and_passivation": {
            "included": product_passivation_payload is not None,
            "calibrated": False,
            "summary_at_one_planar_clear_time": passivation_summary,
            "summary_at_absolute_time_s": passivation_absolute,
        },
        "rinse_and_dry_redeposition": redeposition,
        "mechanism_state_ownership": {
            "blanket_and_bottom_pad": "original film thickness",
            "wetting_and_gas": "liquid/gas accessibility",
            "product_and_passivation": (
                "dissolved-Si equivalent plus reversible surface coverage"
            ),
            "rinse_and_dry_redeposition": (
                "post-HF captured precursor inventory"
            ),
            "combined_residue_used_for_causal_inference": False,
        },
        "cause_discrimination_rules": [
            {
                "observation": (
                    "HF直後・wet保持でも元膜がbottomに残る"
                ),
                "supported_families": [
                    "bottom film thickness/local reaction rate",
                    "pinning or persistent gas",
                    "in-etch product inhibition/passivation",
                ],
                "drydown_supported": False,
            },
            {
                "observation": (
                    "HF直後は清浄で、rinse/dry後だけdepositが増える"
                ),
                "supported_families": ["rinse/dry redeposition"],
                "drydown_supported": True,
            },
            {
                "observation": (
                    "forced pre-wet/degassingでbottom元膜だけ減る"
                ),
                "supported_families": ["pinning or persistent gas"],
                "drydown_supported": False,
            },
            {
                "observation": (
                    "初期bottom厚さを測ってもclear時間が厚さ比例を超える"
                ),
                "supported_families": [
                    "local reaction-rate deficit",
                    "in-etch product inhibition/passivation",
                ],
                "drydown_supported": False,
            },
        ],
        "identifiability_limits": [
            (
                "A single HF endpoint identifies bottom_thickness/"
                "local_rate_factor, not thickness and rate separately."
            ),
            (
                "Blanket WER calibrates the fully wetted chemical clock only; "
                "it does not calibrate pinning, gas lifetime or passivation."
            ),
            (
                "The Fig. 2 one-raster lower rate is zero for endpoints below "
                "the 0.05 nm digitization resolution, so their slowest clear "
                "time is unbounded by that screen."
            ),
        ],
        "component_artifacts": dict(component_artifacts or {}),
    }
    json.dumps(payload, ensure_ascii=False, allow_nan=False)
    return payload


__all__ = [
    "HFOnlyResidueScreenConfig",
    "KAWARAZAKI_DHF_PRESET_IDS",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "blanket_anchor_rows",
    "build_screen_payload",
    "run_bottom_pad_burn_down",
    "run_redeposition_closure_screen",
    "save_bottom_pad_csv",
    "save_json",
    "sha256_file",
    "summarize_product_passivation_payload",
    "summarize_wetting_mesh_convergence",
    "summarize_wetting_payload",
]

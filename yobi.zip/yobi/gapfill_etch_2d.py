"""Coupled coarse-grid model for HF removal of fully GAP-FILLED trenches.

This driver intentionally remains a prototype: transport is quasi-steady and
front motion is cell-conservative.  Product generation and the product-aware
front velocity are closed with an under-relaxed Picard iteration, while
passivation is advanced explicitly with a relaxation-rate time-step limit.  An
optional persistent wall/floor deposit is stored separately from the original
GAP FILL front and can be removed only by an explicit post-WET operation.

The reactant Robin sink is still a separately prescribed transport parameter;
it is not stoichiometrically derived from the converged front velocity.  Thus
reactant consumption, product yield, and solid removal do not yet form a fully
closed chemical inventory.  The model is intended for mechanism and
sensitivity studies, not production prediction without calibrated chemistry.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

import numpy as np

from etch_process import EtchProcessConfig, InitialPhase
from level_set_2d import FrontDiagnostics, MonotonicLevelSet2D
from numerical_settings import LOOSE_NUMERICS, NumericalSettings
from persistent_deposit import (
    DepositDiagnostics,
    DepositDissolutionResult,
    DepositFormationResult,
    DepositParameters,
    PersistentDepositPhase2D,
)
from reaction_diffusion_2d import (
    CartesianGrid2D,
    DiffusionInventoryBalance,
    DiffusionSolveResult,
    TopBoundaryCondition,
    diffusion_inventory_balance,
    interface_average_on_solid,
    solve_quasi_steady_diffusion,
)
from spatial_etchability import (
    SpatialEtchabilityField,
    SpatialEtchabilityParameters,
)
from wetting_2d import (
    WettingDiagnostics,
    WettingParameters,
    WettingState2D,
)


RateLaw = Callable[
    [np.ndarray, np.ndarray, np.ndarray, np.ndarray], np.ndarray | float
]
ReactantSinkModifierLaw = Callable[
    [np.ndarray, np.ndarray, np.ndarray], np.ndarray | float
]


@dataclass(frozen=True)
class TransportParameters:
    """Transport inputs for the prototype two-field closure.

    ``reactant_surface_transfer_nm_s`` prescribes the reactant Robin sink
    independently of the moving-front rate law.  Coupling that sink to solid
    removal through explicit stoichiometry is intentionally outside the
    current implementation.
    """

    reactant_diffusivity_nm2_s: float = 1.0e9
    product_diffusivity_nm2_s: float = 5.0e8
    reactant_bulk_concentration: float = 1.0
    reactant_surface_transfer_nm_s: float = 1.0
    reactant_top_kind: str = "dirichlet"
    reactant_top_transfer_nm_s: float | None = None
    product_bulk_concentration: float = 0.0
    product_top_kind: str = "dirichlet"
    product_top_transfer_nm_s: float | None = None
    product_yield_concentration: float = 1.0
    product_bulk_decay_per_s: float = 0.0

    def __post_init__(self) -> None:
        positive = (
            "reactant_diffusivity_nm2_s",
            "product_diffusivity_nm2_s",
        )
        nonnegative = (
            "reactant_bulk_concentration",
            "reactant_surface_transfer_nm_s",
            "product_bulk_concentration",
            "product_yield_concentration",
            "product_bulk_decay_per_s",
        )
        for name in positive:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        for name in nonnegative:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")
        # Reuse the boundary validators for kind/transfer consistency.
        TopBoundaryCondition(
            bulk_value=self.reactant_bulk_concentration,
            kind=self.reactant_top_kind,  # type: ignore[arg-type]
            transfer_velocity_nm_s=self.reactant_top_transfer_nm_s,
        )
        TopBoundaryCondition(
            bulk_value=self.product_bulk_concentration,
            kind=self.product_top_kind,  # type: ignore[arg-type]
            transfer_velocity_nm_s=self.product_top_transfer_nm_s,
        )

    @property
    def reactant_top_boundary(self) -> TopBoundaryCondition:
        return TopBoundaryCondition(
            bulk_value=self.reactant_bulk_concentration,
            kind=self.reactant_top_kind,  # type: ignore[arg-type]
            transfer_velocity_nm_s=self.reactant_top_transfer_nm_s,
        )

    @property
    def product_top_boundary(self) -> TopBoundaryCondition:
        return TopBoundaryCondition(
            bulk_value=self.product_bulk_concentration,
            kind=self.product_top_kind,  # type: ignore[arg-type]
            transfer_velocity_nm_s=self.product_top_transfer_nm_s,
        )


@dataclass(frozen=True)
class PassivationParameters:
    formation_per_concentration_s: float = 0.0
    removal_per_s: float = 0.0

    def __post_init__(self) -> None:
        for name in ("formation_per_concentration_s", "removal_per_s"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")


@dataclass(frozen=True)
class SaturatingRateLaw:
    """Simple non-negative rate law useful for smoke tests and baselines."""

    maximum_velocity_nm_s: float = 1.0
    half_saturation: float = 0.1
    product_inhibition: float = 0.5

    def __post_init__(self) -> None:
        if not math.isfinite(self.maximum_velocity_nm_s) or self.maximum_velocity_nm_s < 0.0:
            raise ValueError("maximum_velocity_nm_s must be finite and non-negative")
        if not math.isfinite(self.half_saturation) or self.half_saturation <= 0.0:
            raise ValueError("half_saturation must be finite and positive")
        if not math.isfinite(self.product_inhibition) or self.product_inhibition < 0.0:
            raise ValueError("product_inhibition must be finite and non-negative")

    def __call__(
        self,
        reactant: np.ndarray,
        product: np.ndarray,
        passivation: np.ndarray,
        interface_mask: np.ndarray,
    ) -> np.ndarray:
        saturation = reactant / (self.half_saturation + reactant)
        inhibition = 1.0 / (1.0 + self.product_inhibition * product)
        rate = (
            self.maximum_velocity_nm_s
            * saturation
            * inhibition
            * np.clip(1.0 - passivation, 0.0, 1.0)
        )
        return np.where(interface_mask, rate, 0.0)


@dataclass(frozen=True)
class _ProductVelocityCouplingResult:
    product_result: DiffusionSolveResult
    product_interface: np.ndarray
    velocity_nm_s: np.ndarray
    converged: bool
    iterations: int
    relative_change: float


@dataclass(frozen=True)
class EtchSnapshot:
    time_s: float
    solid_fraction: np.ndarray
    solid_mask: np.ndarray
    open_void_mask: np.ndarray
    liquid_mask: np.ndarray
    gas_mask: np.ndarray
    bottom_gas_mask: np.ndarray
    meniscus_depth_profile_nm: np.ndarray
    signed_distance_nm: np.ndarray
    reactant: np.ndarray
    product: np.ndarray
    passivation: np.ndarray
    wall_deposit_inventory_native: np.ndarray
    bottom_deposit_inventory_native: np.ndarray
    wall_deposit_thickness_nm: np.ndarray
    bottom_deposit_thickness_nm: np.ndarray


@dataclass(frozen=True)
class EtchHistoryEntry:
    step: int
    time_s: float
    dt_s: float
    remaining_solid_area_nm2: float
    dissolved_area_nm2: float
    dissolved_mass_fraction: float
    interface_length_nm: float
    liquid_cells_in_trench: int
    newly_liquid_cells: int
    maximum_velocity_nm_s: float
    mean_interface_reactant: float
    maximum_product: float
    mean_interface_passivation: float
    front_mass_balance_relative_error: float
    reactant_converged: bool
    product_converged: bool
    reactant_relative_residual: float
    product_relative_residual: float
    nonlinear_converged: bool = True
    nonlinear_iterations: int = 0
    nonlinear_relative_change: float = 0.0
    front_stable_dt_s: float | None = None
    passivation_stable_dt_s: float | None = None
    wetting_stable_dt_s: float | None = None
    maximum_passivation_relaxation_rate_s: float = 0.0
    time_step_limiter: str = "requested"
    product_surface_generation_rate: float = 0.0
    product_top_outflow_rate: float = 0.0
    product_bulk_decay_rate: float = 0.0
    product_inventory_balance_relative_error: float = 0.0
    product_volumetric_equilibrium_source_rate: float = 0.0
    product_precipitation_capture_rate: float = 0.0
    wet_deposit_formation_rate: float = 0.0
    wet_precipitation_converged: bool = True
    wet_precipitation_iterations: int = 0
    cumulative_product_generation_inventory_native: float = 0.0
    cumulative_product_top_outflow_inventory_native: float = 0.0
    cumulative_product_precipitation_inventory_native: float = 0.0
    cumulative_wet_deposit_inventory_native: float = 0.0
    deposit_total_inventory_native: float = 0.0
    deposit_equivalent_area_nm2: float = 0.0
    deposit_maximum_thickness_nm: float = 0.0
    deposit_subgrid_validity_warning: bool = False
    open_void_cells_in_trench: int = 0
    open_void_area_nm2: float = 0.0
    wetted_area_nm2: float = 0.0
    gas_cells_in_trench: int = 0
    gas_area_nm2: float = 0.0
    newly_opened_cells: int = 0
    newly_wetted_cells: int = 0
    contact_line_depth_nm: float = 0.0
    meniscus_center_depth_nm: float = 0.0
    capillary_pressure_Pa: float = 0.0
    hydraulic_driving_pressure_Pa: float = 0.0
    wetting_delay_active: bool = False
    bottom_gas_pocket_active: bool = False
    target_bottom_gas_area_nm2: float = 0.0
    represented_bottom_gas_area_nm2: float = 0.0
    gas_pressure_Pa: float = 0.0
    gas_inventory_mol_per_m_span: float = 0.0
    high_pressure_gas_model_warning: bool = False
    phase_partition_relative_error: float = 0.0


@dataclass(frozen=True)
class EtchSimulationResult:
    grid: CartesianGrid2D
    history: tuple[EtchHistoryEntry, ...]
    snapshots: tuple[EtchSnapshot, ...]
    final_diagnostics: FrontDiagnostics
    spatial_etchability: SpatialEtchabilityField
    final_deposit_diagnostics: DepositDiagnostics
    wetting_parameters: WettingParameters
    final_wetting_diagnostics: WettingDiagnostics | None
    completed: bool


class GapFillEtch2D:
    """Couple quasi-steady fields to a monotonically retreating front."""

    _PICARD_RELAXATION = 0.5

    def __init__(
        self,
        process: EtchProcessConfig,
        *,
        spacing_nm: float = 2.0,
        reservoir_height_nm: float = 10.0,
        lateral_margin_nm: float = 4.0,
        transport: TransportParameters | None = None,
        passivation: PassivationParameters | None = None,
        rate_law: RateLaw | None = None,
        reactant_sink_modifier_law: ReactantSinkModifierLaw | None = None,
        spatial_etchability: SpatialEtchabilityParameters | None = None,
        deposit_parameters: DepositParameters | None = None,
        wetting_parameters: WettingParameters | None = None,
        numerical_settings: NumericalSettings = LOOSE_NUMERICS,
        solid_density_g_cm3: float | None = None,
    ) -> None:
        self.process = process
        self.grid = CartesianGrid2D.from_geometry(
            process.geometry,
            spacing_nm=spacing_nm,
            reservoir_height_nm=reservoir_height_nm,
            lateral_margin_nm=lateral_margin_nm,
        )
        self.transport = transport or TransportParameters()
        self.passivation_parameters = passivation or PassivationParameters()
        self.rate_law: RateLaw = rate_law or SaturatingRateLaw()
        self.reactant_sink_modifier_law = reactant_sink_modifier_law
        self.spatial_etchability = SpatialEtchabilityField.build(
            self.grid,
            spatial_etchability,
        )
        self.numerics = numerical_settings
        self.front = MonotonicLevelSet2D(
            self.grid, solid_density_g_cm3=solid_density_g_cm3
        )
        self.wetting_parameters = wetting_parameters or WettingParameters()
        self.wetting_state = (
            WettingState2D(self.grid, self.wetting_parameters)
            if self.wetting_parameters.enabled
            else None
        )
        if self.wetting_state is not None:
            self.wetting_state.update(self.front.open_void_mask, 0.0)
        self.deposit_phase = PersistentDepositPhase2D(
            self.grid, deposit_parameters
        )
        self.passivation_field = np.zeros(self.grid.shape, dtype=float)
        self.reactant_field = np.zeros(self.grid.shape, dtype=float)
        self.product_field = np.zeros(self.grid.shape, dtype=float)
        self._last_velocity = np.zeros(self.grid.shape, dtype=float)
        self._last_product_decay_field_s = np.full(
            self.grid.shape,
            self.transport.product_bulk_decay_per_s,
            dtype=float,
        )
        self._last_product_equilibrium_source_per_s = np.zeros(
            self.grid.shape, dtype=float
        )
        self._last_precipitation_decay_field_s = np.zeros(
            self.grid.shape, dtype=float
        )
        self._last_precipitation_active_mask = np.zeros(
            self.grid.shape, dtype=bool
        )
        self._last_precipitation_converged = True
        self._last_precipitation_iterations = 0
        self.cumulative_product_generation_inventory_native = 0.0
        self.cumulative_product_top_outflow_inventory_native = 0.0
        self.cumulative_product_bulk_decay_inventory_native = 0.0
        self.cumulative_product_precipitation_inventory_native = 0.0
        self.cumulative_wet_deposit_inventory_native = 0.0
        self.cumulative_dry_deposit_inventory_native = 0.0
        self.cumulative_deposit_dissolution_inventory_native = 0.0
        self._step_number = 0

        phases = process.initial_phase_map(
            self.grid.lateral_mesh_nm, self.grid.depth_mesh_nm
        )
        if not np.all(
            phases[self.grid.cavity_mask] == InitialPhase.GAP_FILL_SOLID.value
        ):
            raise ValueError("process does not provide a completely GAP-FILLED cavity")
        if np.any(self.active_liquid_mask & self.grid.cavity_mask):
            raise ValueError("initial liquid must not occupy the GAP-FILLED trench")

    @property
    def open_void_mask(self) -> np.ndarray:
        return self.front.open_void_mask

    @property
    def active_liquid_mask(self) -> np.ndarray:
        """Actual wetted phase used by transport and front motion."""

        if self.wetting_state is None:
            return self.front.liquid_mask
        return self.wetting_state.liquid_mask

    @property
    def gas_mask(self) -> np.ndarray:
        if self.wetting_state is None:
            return np.zeros(self.grid.shape, dtype=bool)
        return self.wetting_state.gas_mask

    @property
    def bottom_gas_mask(self) -> np.ndarray:
        if self.wetting_state is None:
            return np.zeros(self.grid.shape, dtype=bool)
        return self.wetting_state.bottom_gas_mask

    @property
    def active_interface_mask(self) -> np.ndarray:
        return self.front.interface_mask_for(self.active_liquid_mask)

    @property
    def active_interface_face_length_nm(self) -> np.ndarray:
        return self.front.interface_face_length_for(self.active_liquid_mask)

    @property
    def wetting_diagnostics(self) -> WettingDiagnostics | None:
        if self.wetting_state is None:
            return None
        return self.wetting_state.diagnostics

    def _current_product_interface(self) -> np.ndarray:
        return interface_average_on_solid(
            self.product_field,
            self.active_liquid_mask,
            self.front.solid_mask,
        )

    def reactant_surface_transfer_for_current_state_nm_s(self) -> np.ndarray:
        """Return the Robin field including optional dynamic reactivity.

        A product/passivation-aware front law can be paired with a matching
        modifier so the HF sink and solid-removal velocity are reduced by the
        same local factor.  Product is lagged from the preceding accepted
        step; passivation is the state used by the upcoming step.
        """

        base = self.reactant_surface_transfer_field_nm_s
        if self.reactant_sink_modifier_law is None:
            return base
        interface = self.active_interface_mask
        raw = self.reactant_sink_modifier_law(
            self._current_product_interface(),
            self.passivation_field,
            interface,
        )
        modifier = np.broadcast_to(
            np.asarray(raw, dtype=float), self.grid.shape
        )
        if np.any(~np.isfinite(modifier)) or np.any(modifier < 0.0):
            raise ValueError(
                "reactant sink modifier must be finite and non-negative"
            )
        return base * np.where(interface, modifier, 1.0)

    def _solve_reactant(self) -> DiffusionSolveResult:
        return solve_quasi_steady_diffusion(
            self.grid,
            self.active_liquid_mask,
            self.front.solid_mask,
            diffusivity_nm2_s=self.transport.reactant_diffusivity_nm2_s,
            top_boundary=self.transport.reactant_top_boundary,
            interface_sink_velocity_nm_s=(
                self.reactant_surface_transfer_for_current_state_nm_s()
            ),
            relative_tolerance=self.numerics.linear_relative_tolerance,
            absolute_tolerance=self.numerics.linear_absolute_tolerance,
            max_iterations=self.numerics.maximum_iterations,
        )

    @property
    def reactant_surface_transfer_field_nm_s(self) -> np.ndarray:
        """Spatial Robin coefficient closed with the same film-rate field."""

        return (
            self.transport.reactant_surface_transfer_nm_s
            * self.spatial_etchability.combined_factor
        )

    def _solve_product(self, source_velocity_nm_s: np.ndarray) -> DiffusionSolveResult:
        self._last_product_decay_field_s.fill(
            self.transport.product_bulk_decay_per_s
        )
        self._last_product_equilibrium_source_per_s.fill(0.0)
        self._last_precipitation_decay_field_s.fill(0.0)
        self._last_precipitation_active_mask.fill(False)
        self._last_precipitation_converged = True
        self._last_precipitation_iterations = 0
        if (
            self.transport.product_yield_concentration == 0.0
            and self.transport.product_bulk_concentration == 0.0
        ):
            # The homogeneous zero-source/zero-boundary problem has the exact
            # zero solution.  Avoid assembling and solving the same sparse
            # system at every front step in literature null-model runs.
            return DiffusionSolveResult(
                field=np.zeros(self.grid.shape, dtype=float),
                connected_liquid_mask=self.active_liquid_mask.copy(),
                converged=True,
                iterations=0,
                relative_residual=0.0,
                used_direct_fallback=False,
            )
        source_flux = (
            self.transport.product_yield_concentration * source_velocity_nm_s
        )
        base_result = solve_quasi_steady_diffusion(
            self.grid,
            self.active_liquid_mask,
            self.front.solid_mask,
            diffusivity_nm2_s=self.transport.product_diffusivity_nm2_s,
            top_boundary=self.transport.product_top_boundary,
            interface_source_flux=source_flux,
            bulk_decay_per_s=self.transport.product_bulk_decay_per_s,
            relative_tolerance=self.numerics.linear_relative_tolerance,
            absolute_tolerance=self.numerics.linear_absolute_tolerance,
            max_iterations=self.numerics.maximum_iterations,
        )
        deposit = self.deposit_phase
        if not deposit.parameters.wet_precipitation_enabled:
            return base_result

        active = deposit.wet_active_mask(
            base_result.field, base_result.connected_liquid_mask
        )
        if not np.any(active):
            return base_result

        result = base_result
        converged = False
        iterations = 0
        solved_active = active.copy()
        precipitation_decay = np.zeros(self.grid.shape, dtype=float)
        equilibrium_source = np.zeros(self.grid.shape, dtype=float)
        for iterations in range(
            1, deposit.parameters.maximum_active_set_iterations + 1
        ):
            solved_active = active.copy()
            precipitation_decay = deposit.wet_attachment_decay_field_s(
                self.active_liquid_mask, solved_active
            )
            precipitation_decay *= (
                deposit.parameters.precipitation_yield_mol_deposit_per_mol_product
            )
            equilibrium_source = (
                precipitation_decay
                * deposit.parameters.saturation_concentration_mol_m3
            )
            total_decay = (
                self.transport.product_bulk_decay_per_s
                + precipitation_decay
            )
            result = solve_quasi_steady_diffusion(
                self.grid,
                self.active_liquid_mask,
                self.front.solid_mask,
                diffusivity_nm2_s=self.transport.product_diffusivity_nm2_s,
                top_boundary=self.transport.product_top_boundary,
                interface_source_flux=source_flux,
                volumetric_source_per_s=equilibrium_source,
                bulk_decay_per_s=total_decay,
                relative_tolerance=self.numerics.linear_relative_tolerance,
                absolute_tolerance=self.numerics.linear_absolute_tolerance,
                max_iterations=self.numerics.maximum_iterations,
            )
            candidate = deposit.wet_active_mask(
                result.field,
                result.connected_liquid_mask,
                solved_active,
            )
            if np.array_equal(candidate, solved_active):
                converged = True
                break
            active = candidate

        self._last_product_decay_field_s[:] = (
            self.transport.product_bulk_decay_per_s + precipitation_decay
        )
        self._last_product_equilibrium_source_per_s[:] = equilibrium_source
        self._last_precipitation_decay_field_s[:] = precipitation_decay
        self._last_precipitation_active_mask[:] = solved_active
        self._last_precipitation_converged = converged
        self._last_precipitation_iterations = iterations
        return result

    def _product_inventory_balance(
        self,
        result: DiffusionSolveResult,
        source_velocity_nm_s: np.ndarray,
    ) -> DiffusionInventoryBalance:
        return diffusion_inventory_balance(
            self.grid,
            result,
            self.front.solid_mask,
            diffusivity_nm2_s=self.transport.product_diffusivity_nm2_s,
            top_boundary=self.transport.product_top_boundary,
            interface_source_flux=(
                self.transport.product_yield_concentration
                * source_velocity_nm_s
            ),
            volumetric_source_per_s=(
                self._last_product_equilibrium_source_per_s
            ),
            bulk_decay_per_s=self._last_product_decay_field_s,
        )

    def _evaluate_rate(
        self,
        reactant_interface: np.ndarray,
        product_interface: np.ndarray,
    ) -> np.ndarray:
        interface = self.active_interface_mask
        raw = self.rate_law(
            reactant_interface,
            product_interface,
            self.passivation_field,
            interface,
        )
        velocity = np.broadcast_to(np.asarray(raw, dtype=float), self.grid.shape).copy()
        if np.any(~np.isfinite(velocity)) or np.any(velocity < 0.0):
            raise ValueError("rate law must return finite non-negative velocities")
        velocity *= self.spatial_etchability.combined_factor
        velocity[~interface] = 0.0
        return velocity

    @staticmethod
    def _relative_velocity_change(
        current: np.ndarray,
        candidate: np.ndarray,
        interface: np.ndarray,
    ) -> float:
        if not np.any(interface):
            return 0.0
        current_values = current[interface]
        candidate_values = candidate[interface]
        numerator = float(np.max(np.abs(candidate_values - current_values)))
        scale = max(
            float(np.max(np.abs(current_values), initial=0.0)),
            float(np.max(np.abs(candidate_values), initial=0.0)),
            np.finfo(float).tiny,
        )
        return numerator / scale

    def _solve_product_velocity_coupling(
        self,
        reactant_interface: np.ndarray,
        initial_product_interface: np.ndarray,
    ) -> _ProductVelocityCouplingResult:
        """Close product source and product-aware velocity by Picard iteration.

        At iteration ``k``, the product equation is solved using velocity
        ``v_k`` as its source.  The rate law produces the fixed-point candidate
        ``F(v_k)``.  If its relative difference from ``v_k`` is above the
        shared loose nonlinear tolerance, the next source is
        ``0.5*v_k + 0.5*F(v_k)``.  On iteration exhaustion the last finite
        source-consistent product/velocity pair is returned with an explicit
        non-convergence diagnostic.
        """
        interface = self.active_interface_mask
        velocity = self._evaluate_rate(
            reactant_interface, initial_product_interface
        )
        product_result: DiffusionSolveResult | None = None
        product_interface = np.zeros(self.grid.shape, dtype=float)
        relative_change = math.inf
        converged = False
        iterations = 0
        for iterations in range(1, self.numerics.maximum_nonlinear_iterations + 1):
            product_result = self._solve_product(velocity)
            product_interface = interface_average_on_solid(
                product_result.field,
                product_result.connected_liquid_mask,
                self.front.solid_mask,
            )
            candidate = self._evaluate_rate(
                reactant_interface, product_interface
            )
            relative_change = self._relative_velocity_change(
                velocity, candidate, interface
            )
            if relative_change <= self.numerics.nonlinear_relative_tolerance:
                converged = True
                break
            if iterations < self.numerics.maximum_nonlinear_iterations:
                relaxation = self._PICARD_RELAXATION
                velocity = (
                    (1.0 - relaxation) * velocity + relaxation * candidate
                )

        assert product_result is not None
        return _ProductVelocityCouplingResult(
            product_result=product_result,
            product_interface=product_interface,
            velocity_nm_s=velocity,
            converged=converged,
            iterations=iterations,
            relative_change=float(relative_change),
        )

    def _passivation_stable_time_step_s(
        self,
        product_interface: np.ndarray,
        interface: np.ndarray,
    ) -> tuple[float, float]:
        """Limit explicit passivation relaxation on the active interface."""
        if not np.any(interface):
            return math.inf, 0.0
        parameters = self.passivation_parameters
        formation_coefficient = (
            parameters.formation_per_concentration_s * product_interface
        )
        relaxation_rate = formation_coefficient + parameters.removal_per_s
        maximum_rate = float(np.max(relaxation_rate[interface], initial=0.0))
        if maximum_rate <= 0.0:
            return math.inf, 0.0
        stable_dt = (
            self.numerics.maximum_fractional_state_change / maximum_rate
        )
        return stable_dt, maximum_rate

    def snapshot(self) -> EtchSnapshot:
        if self.wetting_state is None:
            meniscus_depth_profile_nm = np.zeros(
                len(self.grid.lateral_nm), dtype=float
            )
        else:
            meniscus_depth_profile_nm = (
                self.wetting_state.meniscus_depth_profile_nm.copy()
            )
        return EtchSnapshot(
            time_s=self.front.time_s,
            solid_fraction=self.front.solid_fraction.copy(),
            solid_mask=self.front.solid_mask.copy(),
            open_void_mask=self.open_void_mask.copy(),
            liquid_mask=self.active_liquid_mask.copy(),
            gas_mask=self.gas_mask.copy(),
            bottom_gas_mask=self.bottom_gas_mask.copy(),
            meniscus_depth_profile_nm=meniscus_depth_profile_nm,
            signed_distance_nm=self.front.signed_distance_nm.copy(),
            reactant=self.reactant_field.copy(),
            product=self.product_field.copy(),
            passivation=self.passivation_field.copy(),
            wall_deposit_inventory_native=(
                self.deposit_phase.wall_inventory_native.copy()
            ),
            bottom_deposit_inventory_native=(
                self.deposit_phase.bottom_inventory_native.copy()
            ),
            wall_deposit_thickness_nm=(
                self.deposit_phase.wall_thickness_nm.copy()
            ),
            bottom_deposit_thickness_nm=(
                self.deposit_phase.bottom_thickness_nm.copy()
            ),
        )

    def step(self, requested_dt_s: float) -> EtchHistoryEntry:
        if not math.isfinite(requested_dt_s) or requested_dt_s <= 0.0:
            raise ValueError("requested_dt_s must be finite and positive")

        open_void_before = self.open_void_mask.copy()
        liquid_before = self.active_liquid_mask.copy()
        reactant_result = self._solve_reactant()
        reactant_interface = interface_average_on_solid(
            reactant_result.field,
            reactant_result.connected_liquid_mask,
            self.front.solid_mask,
        )
        previous_product_interface = interface_average_on_solid(
            self.product_field,
            liquid_before,
            self.front.solid_mask,
        )
        coupling = self._solve_product_velocity_coupling(
            reactant_interface, previous_product_interface
        )
        product_result = coupling.product_result
        product_interface = coupling.product_interface
        velocity = coupling.velocity_nm_s
        product_balance = self._product_inventory_balance(
            product_result,
            velocity,
        )
        front_stable_dt = self.front.stable_time_step_s(
            velocity,
            maximum_fractional_change=(
                self.numerics.maximum_fractional_state_change
            ),
            liquid_mask=(
                liquid_before if self.wetting_state is not None else None
            ),
        )
        interface = self.front.interface_mask_for(
            liquid_before if self.wetting_state is not None else None
        )
        wetting_stable_dt = (
            self.wetting_state.stable_time_step_s(
                open_void_before,
                maximum_contact_line_displacement_nm=(
                    self.numerics.maximum_fractional_state_change
                    * min(self.grid.dx_nm, self.grid.dz_nm)
                ),
                maximum_fractional_gas_change=(
                    self.numerics.maximum_fractional_state_change
                ),
            )
            if self.wetting_state is not None
            else math.inf
        )
        passivation_stable_dt, maximum_passivation_rate = (
            self._passivation_stable_time_step_s(
                product_interface, interface
            )
        )
        candidates = (
            ("requested", requested_dt_s),
            ("front", front_stable_dt),
            ("passivation", passivation_stable_dt),
            ("wetting", wetting_stable_dt),
        )
        time_step_limiter, applied_dt = min(
            candidates, key=lambda item: item[1]
        )
        if not math.isfinite(applied_dt):
            applied_dt = requested_dt_s
            time_step_limiter = "requested"
        if applied_dt <= 0.0:
            raise RuntimeError("front controller produced a non-positive time step")

        # The quasi-steady precipitation sink is scaled by the explicit yield:
        # only precursor that becomes the represented solid leaves the product
        # field.  Eligible-but-nondepositing precursor is reported separately.
        wet_formation = self.deposit_phase.accumulate_wet_precipitation(
            product_result.field,
            product_result.connected_liquid_mask,
            applied_dt,
            self._last_precipitation_active_mask,
        )
        precipitation_capture_rate = (
            wet_formation.precipitated_inventory_native / applied_dt
        )
        wet_deposit_rate = (
            wet_formation.precipitated_inventory_native / applied_dt
        )
        base_bulk_decay_rate = float(
            self.transport.product_bulk_decay_per_s
            * np.sum(
                product_result.field[
                    product_result.connected_liquid_mask
                ]
            )
            * self.grid.cell_area_nm2
        )
        self.cumulative_product_generation_inventory_native += (
            product_balance.surface_source_rate * applied_dt
        )
        self.cumulative_product_top_outflow_inventory_native += (
            product_balance.top_outflow_rate * applied_dt
        )
        self.cumulative_product_bulk_decay_inventory_native += (
            base_bulk_decay_rate * applied_dt
        )
        self.cumulative_product_precipitation_inventory_native += (
            wet_formation.precipitated_inventory_native
        )
        self.cumulative_wet_deposit_inventory_native += (
            wet_formation.precipitated_inventory_native
        )

        # Advance with the passivation state used to compute both step limits.
        # Passivation is then updated explicitly for the next transport/front
        # step; this avoids a rapid de-passivation update invalidating the
        # accepted front-motion limit within the current step.
        front_result = self.front.advance(
            velocity,
            applied_dt,
            liquid_mask=(
                liquid_before if self.wetting_state is not None else None
            ),
        )
        if self.wetting_state is not None:
            # First evolve only the void that existed throughout this front
            # step.  Then allocate cells opened at the step end with zero
            # elapsed time.  This avoids crediting a newborn void (or a newly
            # seeded gas pocket) with the entire preceding dt.
            self.wetting_state.update(open_void_before, applied_dt)
            wetting_update = self.wetting_state.update(
                self.front.open_void_mask, 0.0
            )
            liquid_after = wetting_update.liquid_mask
            wetting_diagnostics = wetting_update.diagnostics
        else:
            liquid_after = self.front.liquid_mask
            wetting_diagnostics = None
        parameters = self.passivation_parameters
        formation = (
            parameters.formation_per_concentration_s
            * product_interface
            * (1.0 - self.passivation_field)
        )
        removal = parameters.removal_per_s * self.passivation_field
        self.passivation_field[interface] += applied_dt * (
            formation[interface] - removal[interface]
        )
        self.passivation_field = np.clip(self.passivation_field, 0.0, 1.0)
        self.passivation_field[~self.front.solid_mask] = 0.0
        self.reactant_field = np.where(
            liquid_after, reactant_result.field, 0.0
        )
        self.product_field = np.where(
            liquid_after, product_result.field, 0.0
        )
        self._last_velocity = velocity
        self._step_number += 1
        diagnostics = self.front.diagnostics(liquid_mask=liquid_after)
        open_cavity_after = self.open_void_mask & self.grid.cavity_mask
        liquid_cavity_after = liquid_after & self.grid.cavity_mask
        gas_cavity_after = self.gas_mask & self.grid.cavity_mask
        newly_opened_cells = int(
            np.count_nonzero(
                open_cavity_after
                & ~(open_void_before & self.grid.cavity_mask)
            )
        )
        newly_wetted_cells = int(
            np.count_nonzero(liquid_cavity_after & ~liquid_before)
        )
        open_void_area_nm2 = float(
            np.count_nonzero(open_cavity_after) * self.grid.cell_area_nm2
        )
        wetted_area_nm2 = float(
            np.count_nonzero(liquid_cavity_after) * self.grid.cell_area_nm2
        )
        gas_area_nm2 = float(
            np.count_nonzero(gas_cavity_after) * self.grid.cell_area_nm2
        )
        if np.any(open_cavity_after):
            instant_contact_line_depth_nm = min(
                self.grid.geometry.depth_nm,
                float(
                    np.max(self.grid.depth_mesh_nm[open_cavity_after])
                    + 0.5 * self.grid.dz_nm
                ),
            )
        else:
            instant_contact_line_depth_nm = 0.0
        interface_count = int(np.count_nonzero(interface))
        mean_reactant = (
            float(np.mean(reactant_interface[interface]))
            if interface_count
            else 0.0
        )
        mean_passivation = (
            float(np.mean(self.passivation_field[interface]))
            if interface_count
            else 0.0
        )
        deposit_diagnostics = self.deposit_phase.diagnostics()
        return EtchHistoryEntry(
            step=self._step_number,
            time_s=self.front.time_s,
            dt_s=applied_dt,
            remaining_solid_area_nm2=diagnostics.remaining_solid_area_nm2,
            dissolved_area_nm2=diagnostics.dissolved_area_nm2,
            dissolved_mass_fraction=diagnostics.dissolved_mass_fraction,
            interface_length_nm=diagnostics.interface_length_nm,
            liquid_cells_in_trench=diagnostics.liquid_cells_in_trench,
            newly_liquid_cells=newly_wetted_cells,
            maximum_velocity_nm_s=float(np.max(velocity, initial=0.0)),
            mean_interface_reactant=mean_reactant,
            maximum_product=float(np.max(product_result.field, initial=0.0)),
            mean_interface_passivation=mean_passivation,
            front_mass_balance_relative_error=(
                front_result.mass_balance_relative_error
            ),
            reactant_converged=reactant_result.converged,
            product_converged=product_result.converged,
            reactant_relative_residual=reactant_result.relative_residual,
            product_relative_residual=product_result.relative_residual,
            nonlinear_converged=coupling.converged,
            nonlinear_iterations=coupling.iterations,
            nonlinear_relative_change=coupling.relative_change,
            front_stable_dt_s=(
                front_stable_dt if math.isfinite(front_stable_dt) else None
            ),
            passivation_stable_dt_s=(
                passivation_stable_dt
                if math.isfinite(passivation_stable_dt)
                else None
            ),
            wetting_stable_dt_s=(
                wetting_stable_dt
                if math.isfinite(wetting_stable_dt)
                else None
            ),
            maximum_passivation_relaxation_rate_s=(
                maximum_passivation_rate
            ),
            time_step_limiter=time_step_limiter,
            product_surface_generation_rate=(
                product_balance.surface_source_rate
            ),
            product_top_outflow_rate=product_balance.top_outflow_rate,
            product_bulk_decay_rate=product_balance.bulk_decay_rate,
            product_inventory_balance_relative_error=(
                product_balance.relative_error
            ),
            product_volumetric_equilibrium_source_rate=(
                product_balance.volumetric_source_rate
            ),
            product_precipitation_capture_rate=precipitation_capture_rate,
            wet_deposit_formation_rate=wet_deposit_rate,
            wet_precipitation_converged=(
                self._last_precipitation_converged
            ),
            wet_precipitation_iterations=(
                self._last_precipitation_iterations
            ),
            cumulative_product_generation_inventory_native=(
                self.cumulative_product_generation_inventory_native
            ),
            cumulative_product_top_outflow_inventory_native=(
                self.cumulative_product_top_outflow_inventory_native
            ),
            cumulative_product_precipitation_inventory_native=(
                self.cumulative_product_precipitation_inventory_native
            ),
            cumulative_wet_deposit_inventory_native=(
                self.cumulative_wet_deposit_inventory_native
            ),
            deposit_total_inventory_native=(
                deposit_diagnostics.total_inventory_native
            ),
            deposit_equivalent_area_nm2=(
                deposit_diagnostics.equivalent_cross_section_area_nm2
            ),
            deposit_maximum_thickness_nm=max(
                deposit_diagnostics.maximum_wall_thickness_nm,
                deposit_diagnostics.maximum_bottom_thickness_nm,
            ),
            deposit_subgrid_validity_warning=(
                deposit_diagnostics.subgrid_validity_warning
            ),
            open_void_cells_in_trench=int(
                np.count_nonzero(open_cavity_after)
            ),
            open_void_area_nm2=open_void_area_nm2,
            wetted_area_nm2=wetted_area_nm2,
            gas_cells_in_trench=int(np.count_nonzero(gas_cavity_after)),
            gas_area_nm2=gas_area_nm2,
            newly_opened_cells=newly_opened_cells,
            newly_wetted_cells=newly_wetted_cells,
            contact_line_depth_nm=(
                wetting_diagnostics.contact_line_depth_nm
                if wetting_diagnostics is not None
                else instant_contact_line_depth_nm
            ),
            meniscus_center_depth_nm=(
                wetting_diagnostics.meniscus_center_depth_nm
                if wetting_diagnostics is not None
                else 0.0
            ),
            capillary_pressure_Pa=(
                wetting_diagnostics.capillary_pressure_Pa
                if wetting_diagnostics is not None
                else 0.0
            ),
            hydraulic_driving_pressure_Pa=(
                wetting_diagnostics.hydraulic_driving_pressure_Pa
                if wetting_diagnostics is not None
                else 0.0
            ),
            wetting_delay_active=(
                wetting_diagnostics.wetting_delay_active
                if wetting_diagnostics is not None
                else False
            ),
            bottom_gas_pocket_active=(
                wetting_diagnostics.bottom_gas_pocket_active
                if wetting_diagnostics is not None
                else False
            ),
            target_bottom_gas_area_nm2=(
                wetting_diagnostics.target_bottom_gas_area_nm2
                if wetting_diagnostics is not None
                else 0.0
            ),
            represented_bottom_gas_area_nm2=(
                wetting_diagnostics.represented_bottom_gas_area_nm2
                if wetting_diagnostics is not None
                else 0.0
            ),
            gas_pressure_Pa=(
                wetting_diagnostics.gas_pressure_Pa
                if wetting_diagnostics is not None
                else 0.0
            ),
            gas_inventory_mol_per_m_span=(
                wetting_diagnostics.gas_inventory_mol_per_m_span
                if wetting_diagnostics is not None
                else 0.0
            ),
            high_pressure_gas_model_warning=(
                wetting_diagnostics.high_pressure_model_warning
                if wetting_diagnostics is not None
                else False
            ),
            phase_partition_relative_error=(
                wetting_diagnostics.phase_partition_relative_error
                if wetting_diagnostics is not None
                else abs(
                    open_void_area_nm2 - wetted_area_nm2 - gas_area_nm2
                )
                / max(
                    open_void_area_nm2,
                    wetted_area_nm2 + gas_area_nm2,
                    self.grid.cell_area_nm2,
                )
            ),
        )

    def apply_post_hf_drydown(
        self,
        *,
        solute_retention_fraction: float,
        liquid_retention_fraction: float,
        additional_trapped_inventory_native: float = 0.0,
    ) -> DepositFormationResult:
        """Create deposit, then flush the continuum solution fields.

        The retained-liquid state is used only to calculate the dry-down
        event.  It is not carried into another PDE solve because the fixed-grid
        concentration field cannot represent the contracted liquid volume.
        """
        result = self.deposit_phase.precipitate_during_drydown(
            self.product_field,
            self.active_liquid_mask,
            solute_retention_fraction=solute_retention_fraction,
            liquid_retention_fraction=liquid_retention_fraction,
            additional_trapped_inventory_native=(
                additional_trapped_inventory_native
            ),
        )
        self.cumulative_dry_deposit_inventory_native += (
            result.precipitated_inventory_native
        )
        self.product_field.fill(0.0)
        self.reactant_field.fill(0.0)
        return result

    def dissolve_persistent_deposit(
        self,
        duration_s: float,
        *,
        wall_rate_s: float,
        bottom_rate_s: float | None = None,
    ) -> DepositDissolutionResult:
        """Apply an explicit rinse or second-WET removal law to the deposit."""
        result = self.deposit_phase.dissolve(
            duration_s,
            wall_rate_s=wall_rate_s,
            bottom_rate_s=bottom_rate_s,
        )
        self.cumulative_deposit_dissolution_inventory_native += (
            result.removed_inventory_native
        )
        return result

    def run(
        self,
        total_time_s: float,
        *,
        time_step_s: float = 1.0,
        snapshot_every_steps: int = 1,
        max_steps: int = 10000,
    ) -> EtchSimulationResult:
        if not math.isfinite(total_time_s) or total_time_s < 0.0:
            raise ValueError("total_time_s must be finite and non-negative")
        if not math.isfinite(time_step_s) or time_step_s <= 0.0:
            raise ValueError("time_step_s must be finite and positive")
        if snapshot_every_steps < 1 or max_steps < 1:
            raise ValueError("snapshot interval and max_steps must be positive")

        history: list[EtchHistoryEntry] = []
        snapshots: list[EtchSnapshot] = [self.snapshot()]
        target_time = self.front.time_s + total_time_s
        tolerance = 1.0e-12 * max(1.0, target_time)
        while self.front.time_s < target_time - tolerance and np.any(
            self.front.solid_mask
        ):
            if len(history) >= max_steps:
                raise RuntimeError(
                    "maximum number of time steps reached before target time"
                )
            requested = min(time_step_s, target_time - self.front.time_s)
            entry = self.step(requested)
            history.append(entry)
            if entry.step % snapshot_every_steps == 0:
                snapshots.append(self.snapshot())
        if not math.isclose(
            snapshots[-1].time_s, self.front.time_s, rel_tol=0.0, abs_tol=tolerance
        ):
            snapshots.append(self.snapshot())
        return EtchSimulationResult(
            grid=self.grid,
            history=tuple(history),
            snapshots=tuple(snapshots),
            final_diagnostics=self.front.diagnostics(
                liquid_mask=self.active_liquid_mask
            ),
            spatial_etchability=self.spatial_etchability,
            final_deposit_diagnostics=self.deposit_phase.diagnostics(),
            wetting_parameters=self.wetting_parameters,
            final_wetting_diagnostics=self.wetting_diagnostics,
            completed=not np.any(self.front.solid_mask),
        )

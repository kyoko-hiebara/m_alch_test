"""Continuum-scale two-dimensional straight or tapered trench geometry.

All dimensions in this module are expressed in nanometres.  This is kept
separate from the atomistic builders, which use Angstroms.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Any, Mapping

import numpy as np


@dataclass(frozen=True)
class TaperedTrench2D:
    """A symmetric trench whose width changes linearly (or not) with depth."""

    name: str
    top_width_nm: float
    bottom_width_nm: float
    depth_nm: float

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("trench name must not be empty")
        for field_name in ("top_width_nm", "bottom_width_nm", "depth_nm"):
            value = float(getattr(self, field_name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{field_name} must be finite and positive")
        if self.bottom_width_nm > self.top_width_nm:
            raise ValueError("bottom_width_nm must not exceed top_width_nm")

    @property
    def area_nm2(self) -> float:
        return 0.5 * (self.top_width_nm + self.bottom_width_nm) * self.depth_nm

    @property
    def sidewall_angle_from_vertical_deg(self) -> float:
        half_width_change = 0.5 * (self.top_width_nm - self.bottom_width_nm)
        return math.degrees(math.atan2(half_width_change, self.depth_nm))

    @property
    def opening_aspect_ratio(self) -> float:
        return self.depth_nm / self.top_width_nm

    @property
    def bottom_aspect_ratio(self) -> float:
        return self.depth_nm / self.bottom_width_nm

    def width_at_depth_nm(
        self, depth_nm: float | np.ndarray
    ) -> float | np.ndarray:
        """Return the linearly interpolated width for 0 <= depth <= H."""
        depth = np.asarray(depth_nm, dtype=float)
        if np.any(~np.isfinite(depth)):
            raise ValueError("depth_nm must contain only finite values")
        if np.any((depth < 0.0) | (depth > self.depth_nm)):
            raise ValueError(f"depth_nm must be within [0, {self.depth_nm:g}]")
        fraction = depth / self.depth_nm
        result = self.top_width_nm - (
            self.top_width_nm - self.bottom_width_nm
        ) * fraction
        if result.ndim == 0:
            return float(result)
        return result

    def contains_nm(
        self,
        lateral_nm: float | np.ndarray,
        depth_nm: float | np.ndarray,
    ) -> bool | np.ndarray:
        """Return whether points lie inside the closed trapezoidal cavity."""
        lateral, depth = np.broadcast_arrays(
            np.asarray(lateral_nm, dtype=float),
            np.asarray(depth_nm, dtype=float),
        )
        if np.any(~np.isfinite(lateral)) or np.any(~np.isfinite(depth)):
            raise ValueError("coordinates must contain only finite values")
        within_depth = (depth >= 0.0) & (depth <= self.depth_nm)
        clipped_depth = np.clip(depth, 0.0, self.depth_nm)
        width = self.top_width_nm - (
            self.top_width_nm - self.bottom_width_nm
        ) * clipped_depth / self.depth_nm
        result = within_depth & (np.abs(lateral) <= 0.5 * width)
        if result.ndim == 0:
            return bool(result)
        return result

    def polygon_nm(self) -> tuple[tuple[float, float], ...]:
        """Return vertices as (lateral, depth), starting at the top-left."""
        return (
            (-0.5 * self.top_width_nm, 0.0),
            (-0.5 * self.bottom_width_nm, self.depth_nm),
            (0.5 * self.bottom_width_nm, self.depth_nm),
            (0.5 * self.top_width_nm, 0.0),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, values: Mapping[str, Any]) -> "TaperedTrench2D":
        return cls(
            name=str(values["name"]),
            top_width_nm=float(values["top_width_nm"]),
            bottom_width_nm=float(values["bottom_width_nm"]),
            depth_nm=float(values["depth_nm"]),
        )


STRAIGHT_GEOMETRY_NAMES = ("10_10_180", "7_7_170")
"""Default straight-wall geometries used by new calculations."""

LEGACY_TAPERED_GEOMETRY_NAMES = ("10_8_180", "7_4p5_170")
"""Earlier tapered geometries retained for result reproducibility."""

DEFAULT_GEOMETRY_NAMES = STRAIGHT_GEOMETRY_NAMES


GEOMETRY_PRESETS: Mapping[str, TaperedTrench2D] = MappingProxyType(
    {
        "10_10_180": TaperedTrench2D(
            name="10_10_180",
            top_width_nm=10.0,
            bottom_width_nm=10.0,
            depth_nm=180.0,
        ),
        "7_7_170": TaperedTrench2D(
            name="7_7_170",
            top_width_nm=7.0,
            bottom_width_nm=7.0,
            depth_nm=170.0,
        ),
        # Non-default straight-wall controls used to separate width and depth
        # effects in mechanism-discrimination calculations.  The production
        # defaults above remain unchanged.
        "7_7_175": TaperedTrench2D(
            name="7_7_175",
            top_width_nm=7.0,
            bottom_width_nm=7.0,
            depth_nm=175.0,
        ),
        "8_8_140": TaperedTrench2D(
            name="8_8_140",
            top_width_nm=8.0,
            bottom_width_nm=8.0,
            depth_nm=140.0,
        ),
        "8_8_175": TaperedTrench2D(
            name="8_8_175",
            top_width_nm=8.0,
            bottom_width_nm=8.0,
            depth_nm=175.0,
        ),
        "8_8_210": TaperedTrench2D(
            name="8_8_210",
            top_width_nm=8.0,
            bottom_width_nm=8.0,
            depth_nm=210.0,
        ),
        "10_10_175": TaperedTrench2D(
            name="10_10_175",
            top_width_nm=10.0,
            bottom_width_nm=10.0,
            depth_nm=175.0,
        ),
        "10_8_180": TaperedTrench2D(
            name="10_8_180",
            top_width_nm=10.0,
            bottom_width_nm=8.0,
            depth_nm=180.0,
        ),
        "7_4p5_170": TaperedTrench2D(
            name="7_4p5_170",
            top_width_nm=7.0,
            bottom_width_nm=4.5,
            depth_nm=170.0,
        ),
    }
)


def get_geometry_preset(name: str) -> TaperedTrench2D:
    try:
        return GEOMETRY_PRESETS[name]
    except KeyError as exc:
        choices = ", ".join(GEOMETRY_PRESETS)
        raise ValueError(f"unknown geometry preset {name!r}; choose from {choices}") from exc

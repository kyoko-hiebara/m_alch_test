"""Parallel mechanism and phase-map sweeps for real-dimension trench KMC.

The mechanism sweep compares five deliberately nested hypotheses.  A separate
two-dimensional phase sweep varies the HF supply and a phenomenological
``retention_strength`` that scales product inhibition and passivation-cluster
stability together.  The latter is a sensitivity coordinate, not a directly
measurable material parameter.

Every mechanism case carries a real-coordinate snapshot.  The snapshot keeps
the continuum fields and every matrix/collector site, so a plotted residual is
the residual graph itself rather than a reconstructed front.
"""

from __future__ import annotations

import math
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass, replace
from typing import Iterable, Mapping

import numpy as np

from reaction_diffusion_2d import CartesianGrid2D
from trench_geometry import (
    DEFAULT_GEOMETRY_NAMES,
    GEOMETRY_PRESETS,
    get_geometry_preset,
)
from trench_graph_kmc import (
    REGION_NAMES,
    ContinuumCouplingParameters,
    TrenchGraphConfig,
    TrenchKMCOutcome,
    TrenchKMCParameters,
    parameters_to_dict,
    run_coupled_trench_kmc,
)


MESOSCOPIC_KMC_NOTICE = (
    "Mechanism-screening mesoscopic graph KMC, not an atomistic ORB/MACE "
    "trajectory and not a calibrated wet-process recipe. One matrix node is "
    "one continuum cell. The continuum owns liquid connectivity and local "
    "HF/product/temperature; KMC alone owns solid removal, passivation, "
    "precipitation and reattachment."
)

SCENARIO_ORDER = (
    "baseline",
    "neighbor_dependence",
    "passivation_cluster",
    "precipitation_reattachment",
    "combined",
)

SCENARIO_METADATA: Mapping[str, Mapping[str, object]] = {
    "baseline": {
        "label": "Local-field baseline",
        "description": (
            "Local HF/product/temperature with single-site activation, "
            "passivation and removal; no cooperative or persistent-deposit event."
        ),
        "mechanisms": ["local_fields", "single_site_passivation"],
    },
    "neighbor_dependence": {
        "label": "Neighbour-dependent removal",
        "description": (
            "Baseline plus faster removal next to already removed matrix sites."
        ),
        "mechanisms": ["local_fields", "neighbor_dependent_removal"],
    },
    "passivation_cluster": {
        "label": "Passivation clusters",
        "description": (
            "Baseline plus cooperative passivation and cluster-stabilized "
            "depassivation."
        ),
        "mechanisms": ["local_fields", "passivation_cluster"],
    },
    "precipitation_reattachment": {
        "label": "Precipitation / reattachment",
        "description": (
            "Baseline plus persistent collector deposition, HF dissolution and "
            "wall/floor reattachment hops."
        ),
        "mechanisms": [
            "local_fields",
            "precipitation",
            "deposit_dissolution",
            "reattachment",
        ],
    },
    "combined": {
        "label": "Combined retention mechanisms",
        "description": (
            "Neighbour dependence, passivation clusters, precipitation and "
            "reattachment active together."
        ),
        "mechanisms": [
            "local_fields",
            "neighbor_dependent_removal",
            "passivation_cluster",
            "precipitation",
            "deposit_dissolution",
            "reattachment",
        ],
    },
}


def _positive(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


@dataclass(frozen=True)
class TrenchKMCSweepConfig:
    """Configuration shared by categorical and two-axis sensitivity cases."""

    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    scenarios: tuple[str, ...] = SCENARIO_ORDER
    # 1.0 nm lands cell centres on both closed walls of the 10 nm trench and
    # creates 2,349 graph sites.  1.05 nm avoids that discretisation cliff,
    # balances width errors for the 10 and 7 nm trenches, and fits below 2,000.
    grid_spacing_nm: float = 1.05
    reservoir_height_nm: float = 4.0
    lateral_margin_nm: float = 3.0
    total_time_s: float = 300.0
    macro_time_step_s: float = 10.0
    maximum_events: int = 25_000
    solution_temperature_K: float = 298.15
    substrate_temperature_K: float = 323.15
    hf_scales: tuple[float, ...] = (0.60, 1.00, 1.40)
    retention_strength_scales: tuple[float, ...] = (0.0, 1.0, 2.0)
    base_seed: int = 20260714
    parallel_workers: int = 1
    maximum_sites: int = 2_000

    def __post_init__(self) -> None:
        unknown_geometries = set(self.geometries).difference(GEOMETRY_PRESETS)
        unknown_scenarios = set(self.scenarios).difference(SCENARIO_ORDER)
        if not self.geometries or unknown_geometries:
            raise ValueError(
                f"unknown or empty geometry selection: {sorted(unknown_geometries)}"
            )
        if not self.scenarios or unknown_scenarios:
            raise ValueError(
                f"unknown or empty scenario selection: {sorted(unknown_scenarios)}"
            )
        for name in (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "total_time_s",
            "macro_time_step_s",
            "solution_temperature_K",
            "substrate_temperature_K",
        ):
            _positive(name, getattr(self, name))
        if not math.isfinite(self.lateral_margin_nm) or self.lateral_margin_nm < 0.0:
            raise ValueError("lateral_margin_nm must be finite and non-negative")
        if self.macro_time_step_s > self.total_time_s:
            raise ValueError("macro_time_step_s cannot exceed total_time_s")
        if not isinstance(self.maximum_events, int) or self.maximum_events < 1:
            raise ValueError("maximum_events must be a positive integer")
        if not isinstance(self.maximum_sites, int) or self.maximum_sites < 1:
            raise ValueError("maximum_sites must be a positive integer")
        if not isinstance(self.base_seed, int) or self.base_seed < 0:
            raise ValueError("base_seed must be a non-negative integer")
        if not isinstance(self.parallel_workers, int) or self.parallel_workers < 1:
            raise ValueError("parallel_workers must be a positive integer")
        for name in ("hf_scales", "retention_strength_scales"):
            values = tuple(float(value) for value in getattr(self, name))
            if not values or any(not math.isfinite(value) for value in values):
                raise ValueError(f"{name} must contain finite values")
            if name == "hf_scales" and any(value <= 0.0 for value in values):
                raise ValueError("hf_scales must be positive")
            if name == "retention_strength_scales" and any(
                value < 0.0 for value in values
            ):
                raise ValueError("retention_strength_scales cannot be negative")
            if len(set(values)) != len(values):
                raise ValueError(f"{name} cannot contain duplicate values")
            object.__setattr__(self, name, values)
        object.__setattr__(self, "geometries", tuple(self.geometries))
        object.__setattr__(self, "scenarios", tuple(self.scenarios))

    def to_dict(self) -> dict[str, object]:
        values = asdict(self)
        for key in (
            "geometries",
            "scenarios",
            "hf_scales",
            "retention_strength_scales",
        ):
            values[key] = list(values[key])
        return values


@dataclass(frozen=True)
class _CaseSpec:
    order: int
    case_group: str
    geometry_id: str
    scenario_id: str
    seed: int
    hf_scale: float = 1.0
    retention_strength_scale: float = 1.0


@dataclass(frozen=True)
class _WorkerInput:
    spec: _CaseSpec
    config: TrenchKMCSweepConfig
    include_snapshot: bool
    include_event_locations: bool


def _base_objects(
    config: TrenchKMCSweepConfig,
) -> tuple[TrenchGraphConfig, ContinuumCouplingParameters, TrenchKMCParameters]:
    graph = TrenchGraphConfig(maximum_sites=config.maximum_sites)
    coupling = ContinuumCouplingParameters(
        total_time_s=config.total_time_s,
        macro_time_step_s=config.macro_time_step_s,
        maximum_events=config.maximum_events,
        solution_temperature_K=config.solution_temperature_K,
        substrate_temperature_K=config.substrate_temperature_K,
    )
    return graph, coupling, TrenchKMCParameters()


def scenario_parameters(
    scenario_id: str,
    base: TrenchKMCParameters | None = None,
) -> TrenchKMCParameters:
    """Return nested scenario kinetics from the same calibrated-placeholder base."""

    if scenario_id not in SCENARIO_ORDER:
        raise ValueError(f"unknown scenario {scenario_id!r}")
    base = TrenchKMCParameters() if base is None else base
    off = {
        "removed_neighbour_boost": 0.0,
        "passivation_cluster_boost": 0.0,
        "cluster_stabilization": 0.0,
        "precipitation_rate_s": 0.0,
        "deposit_dissolution_rate_s": 0.0,
        "reattachment_rate_s": 0.0,
        "deposit_cluster_boost": 0.0,
    }
    if scenario_id == "baseline":
        return replace(base, **off)
    if scenario_id == "neighbor_dependence":
        return replace(
            base,
            **{**off, "removed_neighbour_boost": base.removed_neighbour_boost},
        )
    if scenario_id == "passivation_cluster":
        return replace(
            base,
            **{
                **off,
                "passivation_cluster_boost": base.passivation_cluster_boost,
                "cluster_stabilization": base.cluster_stabilization,
            },
        )
    if scenario_id == "precipitation_reattachment":
        return replace(
            base,
            **{
                **off,
                "precipitation_rate_s": base.precipitation_rate_s,
                "deposit_dissolution_rate_s": base.deposit_dissolution_rate_s,
                "reattachment_rate_s": base.reattachment_rate_s,
                "deposit_cluster_boost": base.deposit_cluster_boost,
            },
        )
    return base


def _phase_parameters(
    base: TrenchKMCParameters,
    retention_strength_scale: float,
) -> TrenchKMCParameters:
    scale = float(retention_strength_scale)
    return replace(
        base,
        product_inhibition_strength=base.product_inhibition_strength * scale,
        passivation_cluster_boost=base.passivation_cluster_boost * scale,
        cluster_stabilization=base.cluster_stabilization * scale,
    )


def _changed_values(
    base: TrenchKMCParameters,
    case: TrenchKMCParameters,
) -> dict[str, float]:
    reference = asdict(base)
    values = asdict(case)
    return {
        key: float(value)
        for key, value in values.items()
        if not math.isclose(float(value), float(reference[key]), rel_tol=0.0, abs_tol=0.0)
    }


def _surface_residue(outcome: TrenchKMCOutcome) -> dict[str, object]:
    graph = outcome.graph
    layout = outcome.layout
    result: dict[str, object] = {}
    for name, attribute in (
        ("top", "top_flag"),
        ("sidewall", "sidewall_flag"),
        ("bottom", "bottom_flag"),
    ):
        matrix_ids = [
            site_id
            for site_id in layout.matrix_site_ids
            if graph.sites[site_id].attributes[attribute] > 0.5
        ]
        collector_ids = [
            site_id
            for site_id in layout.collector_site_ids
            if graph.sites[site_id].attributes[attribute] > 0.5
        ]
        remaining = sum(graph.sites[site_id].state != "removed" for site_id in matrix_ids)
        passivated = sum(
            graph.sites[site_id].state == "passivated" for site_id in matrix_ids
        )
        deposits = sum(graph.sites[site_id].state == "deposit" for site_id in collector_ids)
        result[name] = {
            "matrix_site_count": len(matrix_ids),
            "remaining_matrix_count": remaining,
            "remaining_matrix_fraction": remaining / len(matrix_ids) if matrix_ids else 0.0,
            "passivated_matrix_count": passivated,
            "collector_site_count": len(collector_ids),
            "deposit_count": deposits,
            "deposit_fraction": deposits / len(collector_ids) if collector_ids else 0.0,
        }
    return result


def _snapshot(outcome: TrenchKMCOutcome) -> dict[str, object]:
    graph = outcome.graph
    layout = outcome.layout
    grid = layout.grid
    sites: dict[str, list[object]] = {
        key: []
        for key in (
            "site_id",
            "site_type",
            "material",
            "state",
            "region",
            "region_code",
            "x_nm",
            "depth_nm",
            "row",
            "column",
            "hf_activity",
            "hf2_activity",
            "fluoride_activity",
            "protonated_site_fraction",
            "product_activity",
            "temperature_K",
            "wet_exposed",
            "top",
            "sidewall",
            "bottom",
            "support_site_id",
        )
    }
    matrix_ids = set(layout.matrix_site_ids)
    for site_id in range(len(graph.sites)):
        site = graph.sites[site_id]
        code = int(round(site.attributes["region_code"]))
        values: dict[str, object] = {
            "site_id": int(site_id),
            "site_type": "matrix" if site_id in matrix_ids else "collector",
            "material": site.material,
            "state": site.state,
            "region": REGION_NAMES.get(code, "unknown"),
            "region_code": code,
            "x_nm": float(site.attributes["x_nm"]),
            "depth_nm": float(site.attributes["depth_nm"]),
            "row": int(round(site.attributes["row"])),
            "column": int(round(site.attributes["column"])),
            "hf_activity": float(site.attributes["hf_activity"]),
            "hf2_activity": float(
                site.attributes.get("hf2_activity", 0.0)
            ),
            "fluoride_activity": float(
                site.attributes.get("fluoride_activity", 0.0)
            ),
            "protonated_site_fraction": float(
                site.attributes.get("protonated_site_fraction", 0.0)
            ),
            "product_activity": float(site.attributes["product_activity"]),
            "temperature_K": float(site.attributes["temperature_K"]),
            "wet_exposed": bool(site.attributes["wet_exposed"] > 0.5),
            "top": bool(site.attributes["top_flag"] > 0.5),
            "sidewall": bool(site.attributes["sidewall_flag"] > 0.5),
            "bottom": bool(site.attributes["bottom_flag"] > 0.5),
            "support_site_id": (
                None
                if site.attributes["support_site_id"] < 0.0
                else int(round(site.attributes["support_site_id"]))
            ),
        }
        for key, value in values.items():
            sites[key].append(value)
    frame = outcome.final_frame
    return {
        "geometry": grid.geometry.to_dict(),
        "grid": {
            "shape": [int(value) for value in grid.shape],
            "x_nm": [float(value) for value in grid.lateral_nm],
            "depth_nm": [float(value) for value in grid.depth_nm],
            "dx_nm": float(grid.dx_nm),
            "dz_nm": float(grid.dz_nm),
            "reservoir_mask": grid.reservoir_mask.astype(bool).tolist(),
            "cavity_mask": grid.cavity_mask.astype(bool).tolist(),
        },
        "sites": sites,
        "fields": {
            "hf": np.asarray(frame.hf_field, dtype=float).tolist(),
            "product": np.asarray(frame.product_field, dtype=float).tolist(),
            "interface_temperature_K": np.asarray(
                frame.interface_temperature_K, dtype=float
            ).tolist(),
            "solid_mask": np.asarray(frame.solid_mask, dtype=bool).tolist(),
            "liquid_mask": np.asarray(frame.liquid_mask, dtype=bool).tolist(),
            "gas_mask": np.asarray(frame.gas_mask, dtype=bool).tolist(),
            "interface_mask": np.asarray(frame.interface_mask, dtype=bool).tolist(),
        },
    }


def _case_payload(
    spec: _CaseSpec,
    config: TrenchKMCSweepConfig,
    *,
    include_snapshot: bool,
    include_event_locations: bool,
) -> dict[str, object]:
    graph_config, base_coupling, base_kinetics = _base_objects(config)
    if spec.case_group == "mechanism":
        kinetics = scenario_parameters(spec.scenario_id, base_kinetics)
        coupling = base_coupling
    elif spec.case_group == "sensitivity":
        kinetics = _phase_parameters(base_kinetics, spec.retention_strength_scale)
        coupling = replace(
            base_coupling,
            hf_bulk_concentration=(
                base_coupling.hf_bulk_concentration * spec.hf_scale
            ),
        )
    else:
        raise ValueError(f"unsupported case group {spec.case_group!r}")

    geometry = get_geometry_preset(spec.geometry_id)
    grid = CartesianGrid2D.from_geometry(
        geometry,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=config.lateral_margin_nm,
    )
    outcome = run_coupled_trench_kmc(
        grid,
        graph_config=graph_config,
        coupling_parameters=coupling,
        kmc_parameters=kinetics,
        seed=spec.seed,
    )
    summary = dict(outcome.summary())
    summary["total_site_count"] = outcome.layout.site_count
    summary["surface_residue"] = _surface_residue(outcome)
    summary["all_field_solves_converged"] = all(
        bool(item["hf_converged"]) and bool(item["product_converged"])
        for item in outcome.sync_history
    )
    summary["maximum_site_budget"] = graph_config.maximum_sites

    if spec.case_group == "mechanism":
        case_id = f"{spec.geometry_id}__{spec.scenario_id}"
    else:
        hf_tag = str(spec.hf_scale).replace(".", "p")
        retention_tag = str(spec.retention_strength_scale).replace(".", "p")
        case_id = f"{spec.geometry_id}__hf{hf_tag}__retention{retention_tag}"
    result: dict[str, object] = {
        "order": spec.order,
        "case_id": case_id,
        "case_group": spec.case_group,
        "geometry_id": spec.geometry_id,
        "scenario_id": spec.scenario_id,
        "seed": spec.seed,
        "hf_scale": float(spec.hf_scale),
        "retention_strength_scale": float(spec.retention_strength_scale),
        "parameters": parameters_to_dict(graph_config, coupling, kinetics),
        "kinetic_changes_from_combined_default": _changed_values(
            base_kinetics, kinetics
        ),
        "summary": summary,
        "sync_history": [dict(item) for item in outcome.sync_history],
        "event_locations": (
            [dict(item) for item in outcome.event_locations]
            if include_event_locations
            else []
        ),
    }
    if include_snapshot:
        result["snapshot"] = _snapshot(outcome)
    return result


def _worker(worker_input: _WorkerInput) -> dict[str, object]:
    return _case_payload(
        worker_input.spec,
        worker_input.config,
        include_snapshot=worker_input.include_snapshot,
        include_event_locations=worker_input.include_event_locations,
    )


def _execute(
    jobs: Iterable[_WorkerInput], workers: int
) -> list[dict[str, object]]:
    job_list = list(jobs)
    if workers == 1:
        return [_worker(job) for job in job_list]
    with ProcessPoolExecutor(max_workers=workers) as executor:
        # executor.map retains the requested deterministic order.
        return list(executor.map(_worker, job_list))


def _mechanism_specs(config: TrenchKMCSweepConfig) -> list[_CaseSpec]:
    specs: list[_CaseSpec] = []
    for geometry_index, geometry_id in enumerate(config.geometries):
        common_seed = config.base_seed + 10_007 * geometry_index
        for scenario_id in config.scenarios:
            specs.append(
                _CaseSpec(
                    order=len(specs),
                    case_group="mechanism",
                    geometry_id=geometry_id,
                    scenario_id=scenario_id,
                    seed=common_seed,
                )
            )
    return specs


def _sensitivity_specs(config: TrenchKMCSweepConfig) -> list[_CaseSpec]:
    specs: list[_CaseSpec] = []
    for geometry_index, geometry_id in enumerate(config.geometries):
        common_seed = config.base_seed + 10_007 * geometry_index
        for retention in config.retention_strength_scales:
            for hf_scale in config.hf_scales:
                specs.append(
                    _CaseSpec(
                        order=len(specs),
                        case_group="sensitivity",
                        geometry_id=geometry_id,
                        scenario_id="combined_phase_grid",
                        seed=common_seed,
                        hf_scale=hf_scale,
                        retention_strength_scale=retention,
                    )
                )
    return specs


def _metric(case: Mapping[str, object], name: str) -> float:
    summary = case["summary"]
    assert isinstance(summary, Mapping)
    if name == "bottom_remaining_fraction":
        surface = summary["surface_residue"]
        assert isinstance(surface, Mapping)
        bottom = surface["bottom"]
        assert isinstance(bottom, Mapping)
        return float(bottom["remaining_matrix_fraction"])
    if name == "sidewall_remaining_fraction":
        surface = summary["surface_residue"]
        assert isinstance(surface, Mapping)
        sidewall = surface["sidewall"]
        assert isinstance(sidewall, Mapping)
        return float(sidewall["remaining_matrix_fraction"])
    if name == "deposit_fraction":
        count = float(summary["deposit_count"])
        sites = float(summary["collector_site_count"])
        return count / sites if sites else 0.0
    if name == "passivated_fraction":
        state_counts = summary["state_counts"]
        assert isinstance(state_counts, Mapping)
        return float(state_counts.get("passivated", 0)) / float(
            summary["matrix_site_count"]
        )
    return float(summary[name])


def _phase_map(
    cases: list[dict[str, object]], config: TrenchKMCSweepConfig
) -> dict[str, object]:
    metric_names = (
        "remaining_fraction",
        "bottom_remaining_fraction",
        "sidewall_remaining_fraction",
        "deposit_fraction",
        "passivated_fraction",
        "largest_passivation_cluster",
        "largest_deposit_cluster",
    )
    by_geometry: dict[str, object] = {}
    for geometry_id in config.geometries:
        lookup = {
            (float(case["retention_strength_scale"]), float(case["hf_scale"])): case
            for case in cases
            if case["geometry_id"] == geometry_id
        }
        metrics: dict[str, list[list[float]]] = {}
        for metric_name in metric_names:
            metrics[metric_name] = [
                [
                    _metric(lookup[(retention, hf_scale)], metric_name)
                    for hf_scale in config.hf_scales
                ]
                for retention in config.retention_strength_scales
            ]
        by_geometry[geometry_id] = {
            "dimension_order": ["retention_strength_scale", "hf_scale"],
            "metrics": metrics,
            "case_ids": [
                [
                    str(lookup[(retention, hf_scale)]["case_id"])
                    for hf_scale in config.hf_scales
                ]
                for retention in config.retention_strength_scales
            ],
        }
    return {
        "axes": {
            "hf_scale": list(config.hf_scales),
            "retention_strength_scale": list(config.retention_strength_scales),
        },
        "axis_definition": {
            "hf_scale": "multiplier on bulk HF concentration",
            "retention_strength_scale": (
                "common multiplier on product inhibition, cooperative "
                "passivation and cluster stabilization"
            ),
        },
        "by_geometry": by_geometry,
    }


def _scenario_table(
    config: TrenchKMCSweepConfig,
    base: TrenchKMCParameters,
) -> dict[str, object]:
    table: dict[str, object] = {}
    for scenario_id in config.scenarios:
        parameters = scenario_parameters(scenario_id, base)
        table[scenario_id] = {
            **dict(SCENARIO_METADATA[scenario_id]),
            "kinetic_parameters": asdict(parameters),
            "changes_from_combined_default": _changed_values(base, parameters),
        }
    return table


def _mechanism_sensitivity(
    cases: list[dict[str, object]], config: TrenchKMCSweepConfig
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for geometry_id in config.geometries:
        geometry_cases = {
            str(case["scenario_id"]): case
            for case in cases
            if case["geometry_id"] == geometry_id
        }
        baseline = geometry_cases.get("baseline")
        if baseline is None:
            continue
        for scenario_id in config.scenarios:
            case = geometry_cases[scenario_id]
            rows.append(
                {
                    "geometry_id": geometry_id,
                    "scenario_id": scenario_id,
                    "delta_remaining_fraction_vs_baseline": (
                        _metric(case, "remaining_fraction")
                        - _metric(baseline, "remaining_fraction")
                    ),
                    "delta_bottom_remaining_fraction_vs_baseline": (
                        _metric(case, "bottom_remaining_fraction")
                        - _metric(baseline, "bottom_remaining_fraction")
                    ),
                    "delta_deposit_fraction_vs_baseline": (
                        _metric(case, "deposit_fraction")
                        - _metric(baseline, "deposit_fraction")
                    ),
                }
            )
    return rows


def run_trench_kmc_sweep(
    config: TrenchKMCSweepConfig = TrenchKMCSweepConfig(),
) -> dict[str, object]:
    """Run all cases, preserving geometry/scenario/phase-axis ordering."""

    mechanism_specs = _mechanism_specs(config)
    sensitivity_specs = _sensitivity_specs(config)
    mechanism_jobs = [
        _WorkerInput(
            spec=spec,
            config=config,
            include_snapshot=True,
            include_event_locations=(
                spec.geometry_id == config.geometries[0]
                and spec.scenario_id == "combined"
            ),
        )
        for spec in mechanism_specs
    ]
    sensitivity_jobs = [
        _WorkerInput(
            spec=spec,
            config=config,
            include_snapshot=False,
            include_event_locations=False,
        )
        for spec in sensitivity_specs
    ]
    mechanism_cases = _execute(mechanism_jobs, config.parallel_workers)
    sensitivity_cases = _execute(sensitivity_jobs, config.parallel_workers)
    _, base_coupling, base_kinetics = _base_objects(config)

    site_counts: dict[str, object] = {}
    for geometry_id in config.geometries:
        first = next(
            case for case in mechanism_cases if case["geometry_id"] == geometry_id
        )
        summary = first["summary"]
        assert isinstance(summary, Mapping)
        site_counts[geometry_id] = {
            "matrix": int(summary["matrix_site_count"]),
            "collectors": int(summary["collector_site_count"]),
            "total": int(summary["total_site_count"]),
            "maximum": config.maximum_sites,
            "within_budget": bool(
                int(summary["total_site_count"]) <= config.maximum_sites
            ),
        }

    return {
        "schema_version": "trench-kmc-sweep/v1",
        "model_name": "real-dimension continuum-to-graph-KMC coupling",
        "notice": MESOSCOPIC_KMC_NOTICE,
        "state_ownership": {
            "continuum": [
                "top-connected liquid domain",
                "local HF concentration",
                "local product concentration",
                "interface temperature",
            ],
            "graph_kmc": [
                "GAP-FILL matrix removal",
                "passivation state and clusters",
                "persistent wall/floor deposits",
                "next-layer exposure",
            ],
            "operator_split": (
                "KMC solid states reconstruct the continuum domain at each macro "
                "synchronization; no independent level-set front is advanced."
            ),
        },
        "seed_policy": (
            "Common random seed across scenarios and phase-grid cells within each "
            "geometry; geometry g uses base_seed + 10007*g."
        ),
        "config": {
            "sweep": config.to_dict(),
            "base_coupling": asdict(base_coupling),
            "combined_default_kinetics": asdict(base_kinetics),
        },
        "geometry_order": list(config.geometries),
        "scenario_order": list(config.scenarios),
        "geometries": {
            geometry_id: get_geometry_preset(geometry_id).to_dict()
            for geometry_id in config.geometries
        },
        "scenarios": _scenario_table(config, base_kinetics),
        "site_counts": site_counts,
        "case_order": [str(case["case_id"]) for case in mechanism_cases],
        "cases": mechanism_cases,
        "sensitivity_case_order": [
            str(case["case_id"]) for case in sensitivity_cases
        ],
        "sensitivity_cases": sensitivity_cases,
        "mechanism_sensitivity": _mechanism_sensitivity(
            mechanism_cases, config
        ),
        "phase_map": _phase_map(sensitivity_cases, config),
    }


__all__ = [
    "MESOSCOPIC_KMC_NOTICE",
    "SCENARIO_METADATA",
    "SCENARIO_ORDER",
    "TrenchKMCSweepConfig",
    "run_trench_kmc_sweep",
    "scenario_parameters",
]

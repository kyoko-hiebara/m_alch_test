#!/usr/bin/env python3
"""Measure mesh and seed sensitivity of the primary-HF endpoint together.

The saved studies in this project use three different meshes (1.05, 1.4 and
1.7 nm) and one or two KMC seeds, so a difference between two chapters could be
physics, discretisation, or seed noise.  This resolves the three: the same
endpoint is recomputed on a mesh ladder with several seeds, and the mesh effect
is only called real where it exceeds the seed spread at the same mesh.

The endpoint is a physical time, so convergence is reported in the same unit a
process engineer would use, not as an abstract residual.
"""

from __future__ import annotations

import json
import math
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field, replace
from pathlib import Path
import statistics
from typing import Iterable, Mapping, Sequence

from primary_hf_endpoint import (
    PrimaryHFEndpointConfig,
    run_primary_hf_endpoint_calibration,
)


SCHEMA_VERSION = "trench-mesh-seed-convergence/v1"
DEFAULT_MESHES_NM = (1.70, 1.40, 1.05, 0.85, 0.70, 0.55, 0.45)
DEFAULT_SEEDS = (271828, 314159, 161803)
# A coarser mesh is accepted when its endpoint sits within this fraction of the
# finest mesh, judged against the seed spread at the finest mesh.
DEFAULT_TOLERANCE = 0.02


@dataclass(frozen=True)
class ConvergenceConfig:
    """Settings for one mesh/seed convergence study."""

    meshes_nm: tuple[float, ...] = DEFAULT_MESHES_NM
    replicate_seeds: tuple[int, ...] = DEFAULT_SEEDS
    geometries: tuple[str, ...] = ("10_10_180", "7_7_170")
    presets: tuple[str, ...] = (
        "sin_barcellona_b_0p55wt",
        "siocn_fujitsu_4b_100to1",
    )
    scenarios: tuple[str, ...] = ("transport_only", "passivation_hypothesis")
    target_remaining_fraction: float = 0.01
    relative_tolerance: float = DEFAULT_TOLERANCE
    maximum_events: int = 400_000
    maximum_sites: int = 40_000
    trace_points: int = 160
    parallel_workers: int = 1
    base: PrimaryHFEndpointConfig | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        if not self.meshes_nm:
            raise ValueError("meshes_nm must be non-empty")
        if any(
            not math.isfinite(float(value)) or float(value) <= 0.0
            for value in self.meshes_nm
        ):
            raise ValueError("meshes_nm must be finite and positive")
        if len(set(self.meshes_nm)) != len(self.meshes_nm):
            raise ValueError("meshes_nm cannot contain duplicates")
        if len(self.replicate_seeds) < 2:
            raise ValueError(
                "at least two seeds are required to separate seed noise "
                "from a mesh effect"
            )
        if not 0.0 < self.relative_tolerance < 1.0:
            raise ValueError("relative_tolerance must be between 0 and 1")
        object.__setattr__(
            self,
            "meshes_nm",
            tuple(sorted((float(value) for value in self.meshes_nm), reverse=True)),
        )

    def endpoint_config(self, mesh_nm: float) -> PrimaryHFEndpointConfig:
        base = self.base or PrimaryHFEndpointConfig()
        return replace(
            base,
            geometries=self.geometries,
            presets=self.presets,
            scenarios=self.scenarios,
            replicate_seeds=self.replicate_seeds,
            grid_spacing_nm=float(mesh_nm),
            maximum_events=self.maximum_events,
            maximum_sites=self.maximum_sites,
            trace_points=self.trace_points,
            parallel_workers=self.parallel_workers,
        )


def _endpoint_times_s(
    payload: Mapping[str, object],
    target: float,
) -> dict[tuple[str, str, str], dict[str, float]]:
    """Collect the across-seed endpoint spread per geometry/preset/scenario.

    The per-case ``achieved_remaining_fraction`` is discretised by the site
    count, so it does not compare equal to the requested target.  The saved
    aggregates already key on the requested target and carry the min/median/max
    across seeds, which is exactly the spread this study needs.
    """

    targets = payload.get("config", {}).get("target_remaining_fractions")
    if not isinstance(targets, list):
        raise ValueError("payload config has no target_remaining_fractions")
    try:
        position = next(
            index
            for index, value in enumerate(targets)
            if abs(float(value) - target) <= 1.0e-9
        )
    except StopIteration as error:
        raise ValueError(
            f"target {target} is not among the calculated targets"
        ) from error

    times: dict[tuple[str, str, str], list[float]] = {}
    cases = payload.get("cases")
    if not isinstance(cases, list):
        raise ValueError("payload has no cases list")
    for case in cases:
        if not isinstance(case, Mapping) or case.get("status") == "failed":
            continue
        endpoints = case.get("endpoints")
        if not isinstance(endpoints, list) or len(endpoints) != len(targets):
            continue
        endpoint = endpoints[position]
        if not isinstance(endpoint, Mapping) or not endpoint.get("reached"):
            continue
        value = endpoint.get("endpoint_physical_time_s")
        if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
            continue
        key = (
            str(case["geometry_id"]),
            str(case["preset_id"]),
            str(case["scenario"]),
        )
        times.setdefault(key, []).append(float(value))
    return times


def _spread(values: Sequence[float]) -> dict[str, float]:
    """Describe the across-seed scatter with an n-comparable yardstick.

    The range grows with sample size, so it cannot be compared between a
    three-seed and a sixteen-seed study.  The standard error of the mean is
    what decides whether a mesh difference of a given size is resolvable at
    all, so it is reported alongside.
    """

    ordered = sorted(float(value) for value in values)
    count = len(ordered)
    median = statistics.median(ordered)
    deviation = statistics.stdev(ordered) if count > 1 else 0.0
    standard_error = deviation / math.sqrt(count) if count > 0 else float("nan")
    return {
        "count": count,
        "median_s": median,
        "mean_s": statistics.fmean(ordered),
        "minimum_s": ordered[0],
        "maximum_s": ordered[-1],
        "standard_deviation_s": deviation,
        "standard_error_s": standard_error,
        "relative_spread": (
            (ordered[-1] - ordered[0]) / median if median > 0.0 else float("nan")
        ),
        "relative_standard_deviation": (
            deviation / median if median > 0.0 else float("nan")
        ),
        "relative_standard_error": (
            standard_error / median if median > 0.0 else float("nan")
        ),
    }


def _run_one_mesh(item: tuple[ConvergenceConfig, float]) -> tuple[float, dict]:
    config, mesh = item
    payload = run_primary_hf_endpoint_calibration(config.endpoint_config(mesh))
    return mesh, {
        "quality_summary": payload["quality_summary"],
        "endpoint_times_s": {
            " / ".join(key): value
            for key, value in _endpoint_times_s(
                payload, config.target_remaining_fraction
            ).items()
        },
        "site_counts": sorted(
            {
                int(case["convergence"]["matrix_site_count"])
                for case in payload["cases"]
                if isinstance(case, Mapping) and "convergence" in case
            }
        ),
    }


def run_convergence_study(
    config: ConvergenceConfig,
    *,
    workers: int = 1,
) -> dict[str, object]:
    """Recompute the endpoint on the mesh ladder and judge convergence."""

    items = [(config, mesh) for mesh in config.meshes_nm]
    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            collected = list(pool.map(_run_one_mesh, items))
    else:
        collected = [_run_one_mesh(item) for item in items]
    by_mesh = {mesh: record for mesh, record in collected}

    finest = min(config.meshes_nm)
    reference = by_mesh[finest]["endpoint_times_s"]
    series: dict[str, dict[str, object]] = {}
    for key, values in sorted(reference.items()):
        reference_spread = _spread(values)
        points = []
        for mesh in config.meshes_nm:
            observed = by_mesh[mesh]["endpoint_times_s"].get(key)
            if not observed:
                points.append(
                    {
                        "mesh_nm": mesh,
                        "observed": False,
                        "reason": "endpoint not reached at this mesh",
                    }
                )
                continue
            spread = _spread(observed)
            deviation = (
                abs(spread["median_s"] - reference_spread["median_s"])
                / reference_spread["median_s"]
            )
            points.append(
                {
                    "mesh_nm": mesh,
                    "observed": True,
                    **spread,
                    "relative_deviation_from_finest": deviation,
                    "within_tolerance": deviation <= config.relative_tolerance,
                    # A mesh effect is only resolvable once it exceeds the
                    # uncertainty on the medians being compared.  Two standard
                    # errors is the usual bar and does not grow with n the way
                    # the raw range does.
                    "resolvable_against_seed_noise": deviation
                    > 2.0
                    * math.sqrt(
                        spread["relative_standard_error"] ** 2
                        + reference_spread["relative_standard_error"] ** 2
                    ),
                    "exceeds_seed_spread": deviation > spread["relative_spread"],
                }
            )
        # The finest mesh passes its own test by construction, so it is only
        # credible as a reference if the next mesh up already agrees with it.
        second_finest = next(
            (
                point
                for point in sorted(
                    points, key=lambda item: float(item["mesh_nm"])
                )
                if point.get("observed") and float(point["mesh_nm"]) > finest
            ),
            None,
        )
        reference_verified = bool(
            second_finest is not None and second_finest["within_tolerance"]
        )
        usable = [
            point
            for point in points
            if point.get("observed")
            and point.get("within_tolerance")
            and float(point["mesh_nm"]) > finest
        ]
        coarsest_ok = max(
            (float(point["mesh_nm"]) for point in usable),
            default=None,
        )
        series[key] = {
            "reference_mesh_nm": finest,
            "reference_median_s": reference_spread["median_s"],
            "reference_seed_relative_spread": reference_spread["relative_spread"],
            "reference_seed_relative_standard_deviation": reference_spread[
                "relative_standard_deviation"
            ],
            "reference_seed_relative_standard_error": reference_spread[
                "relative_standard_error"
            ],
            "reference_seed_count": reference_spread["count"],
            # Comparing two medians at tolerance t needs
            # 2 * sd * sqrt(2/n) <= t, so n >= 8 sd^2 / t^2.
            "seeds_needed_for_tolerance": (
                int(
                    math.ceil(
                        8.0
                        * reference_spread["relative_standard_deviation"] ** 2
                        / config.relative_tolerance**2
                    )
                )
                if math.isfinite(
                    reference_spread["relative_standard_deviation"]
                )
                else None
            ),
            "reference_verified_by_next_mesh": reference_verified,
            "verifying_mesh_nm": (
                None if second_finest is None else float(second_finest["mesh_nm"])
            ),
            "coarsest_mesh_within_tolerance_nm": coarsest_ok,
            "points": points,
        }

    unverified = sorted(
        key
        for key, item in series.items()
        if not item["reference_verified_by_next_mesh"]
    )
    coarsest_values = [
        item["coarsest_mesh_within_tolerance_nm"]
        for item in series.values()
        if item["coarsest_mesh_within_tolerance_nm"] is not None
    ]
    # No recommendation while any series is still moving at the fine end: the
    # ladder has not resolved that series, so nothing on it can be trusted.
    recommended = (
        min(coarsest_values)
        if coarsest_values and not unverified
        else None
    )
    failed = sum(
        int(record["quality_summary"].get("failed_trench_runs", 0))
        for record in by_mesh.values()
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "notice": (
            "Mesh and seed sensitivity of an uncalibrated literature-prior "
            "model. Convergence here means the number stops moving with "
            "discretisation, not that it matches an experiment."
        ),
        "config": {
            "meshes_nm": list(config.meshes_nm),
            "replicate_seeds": list(config.replicate_seeds),
            "geometries": list(config.geometries),
            "presets": list(config.presets),
            "scenarios": list(config.scenarios),
            "target_remaining_fraction": config.target_remaining_fraction,
            "relative_tolerance": config.relative_tolerance,
            "maximum_events": config.maximum_events,
            "maximum_sites": config.maximum_sites,
        },
        "quality_summary": {
            "mesh_count": len(config.meshes_nm),
            "failed_trench_runs": failed,
            "series_count": len(series),
            "site_counts_by_mesh": {
                str(mesh): record["site_counts"]
                for mesh, record in sorted(by_mesh.items(), reverse=True)
            },
        },
        "recommended_production_mesh_nm": recommended,
        "series_with_unverified_reference": unverified,
        "series": series,
    }


def write_json(payload: object, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=1, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def readme_lines(payload: Mapping[str, object]) -> Iterable[str]:
    config = payload["config"]
    yield "# mesh / seed 収束スタディ"
    yield ""
    yield str(payload["notice"])
    yield ""
    yield f"- mesh ladder: {', '.join(f'{v:g}' for v in config['meshes_nm'])} nm"
    yield f"- seeds: {', '.join(str(v) for v in config['replicate_seeds'])}"
    yield f"- 判定: 最細meshからの相対差 <= {config['relative_tolerance']:.0%}"
    recommended = payload["recommended_production_mesh_nm"]
    unverified = payload.get("series_with_unverified_reference") or []
    yield (
        "- **推奨production mesh**: "
        + ("未確定" if recommended is None else f"{recommended:g} nm")
    )
    if unverified:
        yield (
            f"- 最細meshが次のmeshで裏付けられていない系列が{len(unverified)}件"
            "あるため、推奨は出していない。ladderをさらに細くする必要がある。"
        )
    yield ""
    yield "## 系列ごとの結果"
    yield ""
    yield (
        "| 系列 | 最細mesh中央値 | seed相対SD | 中央値の相対SE | "
        "必要seed数 | 最細meshの裏付け | 許容内で最も粗いmesh |"
    )
    yield "|---|---:|---:|---:|---:|---|---:|"
    for key, item in sorted(payload["series"].items()):
        coarsest = item["coarsest_mesh_within_tolerance_nm"]
        verified = (
            f"あり ({item['verifying_mesh_nm']:g} nm)"
            if item["reference_verified_by_next_mesh"]
            else "なし"
        )
        yield (
            f"| `{key}` | {item['reference_median_s'] / 60.0:.1f} min "
            f"| {item['reference_seed_relative_standard_deviation']:.1%} "
            f"| {item['reference_seed_relative_standard_error']:.1%} "
            f"| {item['seeds_needed_for_tolerance']} "
            f"| {verified} "
            f"| {'なし' if coarsest is None else f'{coarsest:g} nm'} |"
        )
    yield ""
    yield "## mesh別の逸脱"
    yield ""
    yield "| 系列 | mesh | 中央値 | 最細からの差 | 相対SD | 判定 |"
    yield "|---|---:|---:|---:|---:|---|"
    for key, item in sorted(payload["series"].items()):
        for point in item["points"]:
            if not point.get("observed"):
                yield f"| `{key}` | {point['mesh_nm']:g} nm | — | — | — | 未到達 |"
                continue
            verdict = "許容内" if point["within_tolerance"] else "許容外"
            if not point["within_tolerance"] and not point[
                "resolvable_against_seed_noise"
            ]:
                verdict = "許容外だがseedノイズと区別不能"
            yield (
                f"| `{key}` | {point['mesh_nm']:g} nm "
                f"| {point['median_s'] / 60.0:.1f} min "
                f"| {point['relative_deviation_from_finest']:.1%} "
                f"| {point['relative_standard_deviation']:.1%} | {verdict} |"
            )

from __future__ import annotations

import math
import unittest

from acid_speciation import (
    BISULFATE_KA2_298,
    MAXIMUM_IONIC_STRENGTH,
    TABULATED_MAXIMUM_IONIC_STRENGTH,
    bifluoride_quotient_spread,
    conventional_davies_activity_model,
    protonated_site_fraction,
    relative_rate_response,
    solve_acidified_speciation,
    sulfuric_molality_to_weight_percent,
    sulfuric_weight_percent_to_molality,
    table_fitted_activity_model,
    weight_percent_to_fluorine_molality,
)
from literature_parameters import hf_speciation_298K_from_weight_percent


class ActivityModelExtractionTests(unittest.TestCase):
    def test_recovered_hf_pka_matches_accepted_aqueous_value(self) -> None:
        """The table-derived acidity constant must land on the known HF pKa.

        Nothing in the fit is told what the answer should be, so agreement
        with 3.17 is an independent check that the extraction is right.
        """

        model = table_fitted_activity_model()
        pka = -math.log10(model.hf_acidity_constant)
        self.assertAlmostEqual(pka, 3.17, delta=0.03)

    def test_conventional_davies_model_also_lands_near_the_same_pka(self) -> None:
        model = conventional_davies_activity_model()
        pka = -math.log10(model.hf_acidity_constant)
        self.assertAlmostEqual(pka, 3.17, delta=0.05)
        self.assertEqual(model.davies_b, 0.3)
        self.assertFalse(model.fitted_from_table)

    def test_bifluoride_quotient_is_constant_across_the_table(self) -> None:
        """Justifies carrying K2 as a concentration quotient."""

        self.assertLess(bifluoride_quotient_spread(), 1.0e-3)

    def test_table_fit_residual_is_small(self) -> None:
        model = table_fitted_activity_model()
        self.assertLess(model.maximum_table_residual, 0.02)


class ZeroAcidConsistencyTests(unittest.TestCase):
    def test_reproduces_the_existing_converter_within_fit_residual(self) -> None:
        """With no added acid this must agree with the repository's table.

        The equilibrium reconstruction cannot be better than its own fit, so
        the tolerance is the fit residual rather than machine precision.
        """

        model = table_fitted_activity_model()
        for weight_percent in (0.05, 0.10, 0.55, 0.90):
            with self.subTest(weight_percent=weight_percent):
                fluorine = weight_percent_to_fluorine_molality(weight_percent)
                solved = solve_acidified_speciation(
                    analytical_fluorine_mol_kg=fluorine,
                    activity_model=model,
                )
                reference = hf_speciation_298K_from_weight_percent(
                    weight_percent
                )
                ratio = (
                    solved.in_mol_m3()["neutral_hf_mol_m3"]
                    / reference.neutral_hf_mol_m3
                )
                self.assertAlmostEqual(ratio, 1.0, delta=0.02)

    def test_fluorine_molality_matches_the_converter(self) -> None:
        reference = hf_speciation_298K_from_weight_percent(0.55)
        self.assertAlmostEqual(
            weight_percent_to_fluorine_molality(0.55),
            reference.analytical_hf_molality_mol_kg,
            places=12,
        )


class ClosureTests(unittest.TestCase):
    def test_fluorine_and_charge_balances_close(self) -> None:
        for sulfuric in (0.0, 0.003, 0.01, 0.03, 0.1):
            with self.subTest(sulfuric=sulfuric):
                solved = solve_acidified_speciation(
                    analytical_fluorine_mol_kg=0.2,
                    added_sulfuric_acid_mol_kg=sulfuric,
                )
                self.assertLess(abs(solved.fluorine_balance_residual), 1.0e-12)
                self.assertLess(
                    abs(solved.charge_balance_residual),
                    1.0e-12 * max(1.0, solved.proton_mol_kg),
                )

    def test_ionic_strength_matches_its_definition(self) -> None:
        solved = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.03,
        )
        expected = 0.5 * (
            solved.proton_mol_kg
            + solved.fluoride_mol_kg
            + solved.bifluoride_mol_kg
            + solved.bisulfate_mol_kg
            + 4.0 * solved.sulfate_mol_kg
        )
        self.assertAlmostEqual(
            solved.ionic_strength_mol_kg, expected, places=12
        )

    def test_sulfur_balance_closes(self) -> None:
        solved = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.05,
        )
        self.assertAlmostEqual(
            solved.bisulfate_mol_kg + solved.sulfate_mol_kg,
            0.05,
            places=12,
        )


class DirectionTests(unittest.TestCase):
    def test_added_acid_suppresses_fluoride_and_bifluoride(self) -> None:
        """Le Chatelier: strong acid pushes HF back to its neutral form."""

        base = solve_acidified_speciation(analytical_fluorine_mol_kg=0.2)
        acidified = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.03,
        )
        self.assertLess(acidified.fluoride_mol_kg, base.fluoride_mol_kg)
        self.assertLess(acidified.bifluoride_mol_kg, base.bifluoride_mol_kg)
        self.assertGreater(acidified.neutral_hf_mol_kg, base.neutral_hf_mol_kg)
        self.assertGreater(acidified.proton_mol_kg, base.proton_mol_kg)
        self.assertLess(acidified.ph, base.ph)

    def test_neutral_hf_moves_far_less_than_the_ionic_species(self) -> None:
        """This is what makes the competing rate laws separable."""

        base = solve_acidified_speciation(analytical_fluorine_mol_kg=0.2)
        acidified = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.03,
        )
        neutral_change = abs(
            acidified.neutral_hf_mol_kg / base.neutral_hf_mol_kg - 1.0
        )
        bifluoride_change = abs(
            acidified.bifluoride_mol_kg / base.bifluoride_mol_kg - 1.0
        )
        self.assertLess(neutral_change, 0.15)
        self.assertGreater(bifluoride_change, 0.3)

    def test_fluoride_decreases_monotonically_with_added_acid(self) -> None:
        previous = math.inf
        for sulfuric in (0.0, 0.003, 0.01, 0.03, 0.05, 0.08, 0.1):
            solved = solve_acidified_speciation(
                analytical_fluorine_mol_kg=0.2,
                added_sulfuric_acid_mol_kg=sulfuric,
            )
            self.assertLess(solved.fluoride_mol_kg, previous)
            previous = solved.fluoride_mol_kg


class SupportBoundaryTests(unittest.TestCase):
    def test_zero_acid_dilute_case_is_within_tabulated_support(self) -> None:
        solved = solve_acidified_speciation(analytical_fluorine_mol_kg=0.2)
        self.assertLessEqual(
            solved.ionic_strength_mol_kg, TABULATED_MAXIMUM_IONIC_STRENGTH
        )
        self.assertEqual(solved.support_status, "within_tabulated_support")

    def test_process_relevant_addition_is_flagged_as_extrapolated(self) -> None:
        solved = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.03,
        )
        self.assertEqual(
            solved.support_status, "extrapolated_beyond_tabulated_support"
        )

    def test_refuses_beyond_the_usable_ionic_strength(self) -> None:
        with self.assertRaises(ValueError) as caught:
            solve_acidified_speciation(
                analytical_fluorine_mol_kg=0.2,
                added_sulfuric_acid_mol_kg=0.5,
            )
        self.assertIn("ionic strength", str(caught.exception))

    def test_maximum_ionic_strength_is_below_the_fold_back(self) -> None:
        """The fitted Davies form turns non-monotone; refuse before it does."""

        self.assertLess(MAXIMUM_IONIC_STRENGTH, 0.45)

    def test_rejects_nonpositive_fluorine(self) -> None:
        with self.assertRaises(ValueError):
            solve_acidified_speciation(analytical_fluorine_mol_kg=0.0)

    def test_rejects_negative_acid(self) -> None:
        with self.assertRaises(ValueError):
            solve_acidified_speciation(
                analytical_fluorine_mol_kg=0.2,
                added_sulfuric_acid_mol_kg=-1.0,
            )


class RateLawTests(unittest.TestCase):
    def test_candidate_rate_laws_disagree_in_sign(self) -> None:
        """The result that makes the plant observation informative."""

        base = solve_acidified_speciation(analytical_fluorine_mol_kg=0.2)
        acidified = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.03,
        )
        response = relative_rate_response(base, acidified)
        signs = response["predicted_sign"]
        self.assertEqual(signs["bifluoride"], "slower")
        self.assertEqual(signs["proton_assisted_hf"], "faster")
        self.assertEqual(signs["neutral_hf"], "within_10_percent")

    def test_proton_assisted_response_saturates_at_large_constant(self) -> None:
        base = solve_acidified_speciation(analytical_fluorine_mol_kg=0.2)
        acidified = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.03,
        )
        response = relative_rate_response(
            base,
            acidified,
            surface_protonation_constants_kg_mol=(0.01, 1.0e6),
        )
        assisted = response["proton_assisted_hf"]
        self.assertGreater(assisted["K=0.01"], assisted["K=1e+06"])
        # Fully saturated: only the neutral-HF factor survives.
        self.assertAlmostEqual(
            assisted["K=1e+06"],
            acidified.neutral_hf_mol_kg / base.neutral_hf_mol_kg,
            places=4,
        )

    def test_protonated_site_fraction_limits(self) -> None:
        self.assertAlmostEqual(protonated_site_fraction(0.0, 1.0), 0.0)
        self.assertAlmostEqual(
            protonated_site_fraction(1.0, 1.0e9), 1.0, places=8
        )

    def test_rejects_mixed_activity_models(self) -> None:
        base = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            activity_model=table_fitted_activity_model(),
        )
        other = solve_acidified_speciation(
            analytical_fluorine_mol_kg=0.2,
            added_sulfuric_acid_mol_kg=0.01,
            activity_model=conventional_davies_activity_model(),
        )
        with self.assertRaises(ValueError):
            relative_rate_response(base, other)


class ExternalConstantTests(unittest.TestCase):
    def test_bisulfate_constant_is_the_declared_external_input(self) -> None:
        self.assertAlmostEqual(-math.log10(BISULFATE_KA2_298), 1.99, delta=0.01)

    def test_sulfuric_weight_percent_conversion(self) -> None:
        # 1 wt% H2SO4 is 0.103 mol/kg, which already carries a 0.55 wt% dHF
        # past the tabulated ionic-strength support.
        molality = sulfuric_weight_percent_to_molality(1.0)
        self.assertAlmostEqual(molality, 0.1029885, places=6)
        self.assertEqual(sulfuric_weight_percent_to_molality(0.0), 0.0)

    def test_sulfuric_conversion_round_trips(self) -> None:
        for percent in (0.0, 0.5, 1.0, 5.0):
            with self.subTest(percent=percent):
                molality = sulfuric_weight_percent_to_molality(percent)
                self.assertAlmostEqual(
                    sulfuric_molality_to_weight_percent(molality),
                    percent,
                    places=10,
                )


if __name__ == "__main__":
    unittest.main()

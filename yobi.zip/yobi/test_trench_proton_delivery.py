from __future__ import annotations

import math
import unittest

from trench_proton_delivery import (
    LIMITING_ABOVE,
    NEGLIGIBLE_BELOW,
    PROTONS_PER_SILICON,
    VERDICT_LIMITING,
    VERDICT_MARGINAL,
    VERDICT_NEGLIGIBLE,
    build_report,
    classify,
    depletion_fraction,
    etch_flux_mol_m2_s,
    sulfuric_theta_lever,
    sweep_depletion,
    wall_titration,
)


class FluxTests(unittest.TestCase):
    def test_etch_flux_converts_rate_and_density(self) -> None:
        # 0.6418e-9/60 m/s * 5.31e4 mol/m3 = 5.68e-7 mol Si / m2 s
        flux = etch_flux_mol_m2_s(0.6418, 5.31e4)
        self.assertAlmostEqual(flux, 5.68e-7, delta=0.02e-7)

    def test_stoichiometry_is_four_thirds_protons_per_silicon(self) -> None:
        """Every nitrogen of Si3N4 leaves as ammonium."""

        self.assertAlmostEqual(PROTONS_PER_SILICON, 4.0 / 3.0)

    def test_rejects_nonpositive_rate(self) -> None:
        with self.assertRaises(ValueError):
            etch_flux_mol_m2_s(0.0, 5.31e4)


class DepletionTests(unittest.TestCase):
    def test_depletion_matches_the_hand_calculation(self) -> None:
        """The order-of-magnitude check that motivated the module."""

        silicon_flux = etch_flux_mol_m2_s(0.6418, 5.31e4)
        delta = depletion_fraction(
            demand_flux_mol_m2_s=PROTONS_PER_SILICON * silicon_flux,
            diffusivity_m2_s=9.31e-9,
            bulk_concentration_mol_m3=19.59,
            depth_m=180e-9,
        )
        self.assertAlmostEqual(delta, 7.5e-7, delta=0.2e-7)

    def test_depletion_scales_linearly_with_demand_and_depth(self) -> None:
        base = dict(
            diffusivity_m2_s=9.31e-9,
            bulk_concentration_mol_m3=19.59,
            depth_m=180e-9,
        )
        one = depletion_fraction(demand_flux_mol_m2_s=1e-9, **base)
        two = depletion_fraction(demand_flux_mol_m2_s=2e-9, **base)
        self.assertAlmostEqual(two, 2.0 * one)
        deeper = depletion_fraction(
            demand_flux_mol_m2_s=1e-9,
            diffusivity_m2_s=9.31e-9,
            bulk_concentration_mol_m3=19.59,
            depth_m=360e-9,
        )
        self.assertAlmostEqual(deeper, 2.0 * one)

    def test_zero_demand_is_zero_depletion(self) -> None:
        self.assertEqual(
            depletion_fraction(
                demand_flux_mol_m2_s=0.0,
                diffusivity_m2_s=1e-9,
                bulk_concentration_mol_m3=10.0,
                depth_m=1e-7,
            ),
            0.0,
        )


class VerdictTests(unittest.TestCase):
    def test_bands(self) -> None:
        self.assertEqual(classify(NEGLIGIBLE_BELOW / 10), VERDICT_NEGLIGIBLE)
        self.assertEqual(classify(0.05), VERDICT_MARGINAL)
        self.assertEqual(classify(LIMITING_ABOVE * 2), VERDICT_LIMITING)

    def test_rejects_negative(self) -> None:
        with self.assertRaises(ValueError):
            classify(-0.1)


class SweepTests(unittest.TestCase):
    def test_plausible_envelope_is_negligible(self) -> None:
        """The decisive result: within 19x rate and 10x slower diffusion the
        proton draw-down never leaves the negligible band."""

        from trench_proton_delivery import (
            PLAUSIBLE_DIFFUSIVITY_REDUCTION_MAX,
            PLAUSIBLE_RATE_MULTIPLIER_MAX,
        )

        cases = [
            c
            for c in sweep_depletion()
            if c.rate_multiplier <= PLAUSIBLE_RATE_MULTIPLIER_MAX
            and c.diffusivity_reduction <= PLAUSIBLE_DIFFUSIVITY_REDUCTION_MAX
        ]
        worst = max(case.proton_depletion for case in cases)
        self.assertLess(worst, NEGLIGIBLE_BELOW)

    def test_extreme_corner_reaches_marginal_but_hf_fails_first(self) -> None:
        """Past the envelope the proton goes marginal -- and HF goes limiting
        at the same corner, so the proton is still not the binding limit."""

        cases = sweep_depletion()
        extreme = max(cases, key=lambda c: c.proton_depletion)
        self.assertGreater(extreme.proton_depletion, NEGLIGIBLE_BELOW)
        self.assertGreater(extreme.hf_depletion, extreme.proton_depletion)

    def test_hf_depletes_first_in_every_case(self) -> None:
        """The parameter-light invariant the conclusion leans on."""

        for case in sweep_depletion():
            self.assertGreater(
                case.hf_depletion, 1.5 * case.proton_depletion, case
            )

    def test_worst_case_is_the_expected_corner(self) -> None:
        cases = sweep_depletion()
        worst = max(cases, key=lambda case: case.proton_depletion)
        self.assertEqual(worst.rate_multiplier, 100.0)
        self.assertEqual(worst.diffusivity_reduction, 100.0)
        # weaker acid, deeper trench is the harder corner
        self.assertEqual(worst.hf_weight_percent, 0.15)

    def test_hf_and_proton_channels_are_both_reported(self) -> None:
        for case in sweep_depletion():
            self.assertGreaterEqual(case.hf_depletion, 0.0)
            self.assertGreaterEqual(case.proton_depletion, 0.0)
            self.assertAlmostEqual(
                case.front_over_bulk_proton, 1.0 - case.proton_depletion
            )

    def test_sweep_covers_both_geometries(self) -> None:
        names = {case.geometry for case in sweep_depletion()}
        self.assertEqual(names, {"10_10_180", "7_7_170"})


class WallTitrationTests(unittest.TestCase):
    def test_wall_demand_exceeds_liquid_inventory(self) -> None:
        """The one channel where the numbers are actually large."""

        result = wall_titration(
            site_density_mol_m3=5.31e4,
            depth_m=180e-9,
            width_m=10e-9,
            proton_concentration_mol_m3=19.59,
            proton_diffusivity_m2_s=9.31e-9,
        )
        self.assertGreater(result["demand_over_inventory"], 100.0)

    def test_but_the_reservoir_refills_it_in_under_a_millisecond(self) -> None:
        result = wall_titration(
            site_density_mol_m3=5.31e4,
            depth_m=180e-9,
            width_m=10e-9,
            proton_concentration_mol_m3=19.59,
            proton_diffusivity_m2_s=9.31e-9,
        )
        self.assertLess(result["refill_time_s"], 1.0e-3)


class SulfuricLeverTests(unittest.TestCase):
    def test_theta_gain_is_monotonic_in_dose(self) -> None:
        rows = sulfuric_theta_lever()
        for key in rows[0]["theta"]:
            gains = [row["theta_gain_over_dhf"][key] for row in rows]
            for earlier, later in zip(gains, gains[1:]):
                self.assertGreaterEqual(later, earlier)

    def test_saturation_kills_the_lever_at_small_k_half(self) -> None:
        """Past C_H >> K_half more acid buys nothing."""

        rows = sulfuric_theta_lever()
        top = rows[-1]
        self.assertLess(top["theta_gain_over_dhf"]["K_half=0.01"], 1.5)
        self.assertGreater(top["theta_gain_over_dhf"]["K_half=1"], 3.0)

    def test_zero_dose_row_is_the_reference(self) -> None:
        rows = sulfuric_theta_lever()
        self.assertEqual(rows[0]["added_sulfuric_mol_kg"], 0.0)
        for key, gain in rows[0]["theta_gain_over_dhf"].items():
            self.assertAlmostEqual(gain, 1.0, places=12, msg=key)


class ReportTests(unittest.TestCase):
    def test_verdict_is_negligible_and_consequences_follow(self) -> None:
        report = build_report()
        self.assertEqual(report["verdict"], VERDICT_NEGLIGIBLE)
        self.assertIn("excluded", report["consequences"]["rank_3_reading"])
        self.assertIn("bulk theta_H", report["consequences"]["h2so4_reading"])
        self.assertIn(
            "film side", report["consequences"]["bottom_specificity_reading"]
        )

    def test_transient_is_microseconds(self) -> None:
        report = build_report()
        self.assertLess(report["diffusion_transient_s"], 1.0e-4)

    def test_report_records_the_external_constants(self) -> None:
        constants = build_report()["external_constants"]
        self.assertIn("Grotthuss", constants["proton_diffusivity_source"])

    def test_sweep_uses_the_larger_literature_rate_as_base(self) -> None:
        rates = build_report()["rates_nm_min"]
        self.assertGreater(rates["literature_base"], rates["measured_initial"])


if __name__ == "__main__":
    unittest.main()

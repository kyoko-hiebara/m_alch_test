#!/usr/bin/env python3
"""Visual summaries for the wide trench-process parameter sweep.

The reader is intentionally tolerant of small schema changes in the sweep
coordinator.  It accepts mappings directly or strict-JSON paths, record lists
or nested PRCC tables, list- or mapping-based phase maps, and both columnar and
record-oriented graph snapshots.

All figures state that the calculation is an uncalibrated screening model.
The functions use the non-interactive Matplotlib backend and default to 300 dpi.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib import patheffects
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, Normalize
from matplotlib.patches import Patch
import numpy as np


SCREENING_NOTICE = (
    "Screening model only — kinetics, passivation, attachment and second-WET "
    "parameters are uncalibrated; do not interpret as a process recipe."
)

CLASS_ORDER = (
    "complete_removal",
    "bottom_residue",
    "wall_residue",
    "precipitation_residue",
)

CLASS_LABELS = {
    "complete_removal": "Complete removal",
    "bottom_residue": "Bottom residue",
    "wall_residue": "Wall residue",
    "precipitation_residue": "Precipitation residue",
}

# Colour-blind-conscious, deliberately well-separated hues.  The same mapping
# is used in every categorical figure.
CLASS_COLORS = {
    "complete_removal": "#009E73",  # blue-green
    "bottom_residue": "#E69F00",  # orange
    "wall_residue": "#6F4C9B",  # purple
    "precipitation_residue": "#882255",  # dark magenta/brown
}

_CLASS_CODES = {name: index for index, name in enumerate(CLASS_ORDER)}
_CLASS_ABBREVIATIONS = {
    "complete_removal": "C",
    "bottom_residue": "B",
    "wall_residue": "W",
    "precipitation_residue": "P",
}

_STYLE = {
    "font.size": 8.5,
    "axes.titlesize": 9.5,
    "axes.labelsize": 8.5,
    "axes.linewidth": 0.75,
    "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5,
    "legend.fontsize": 7.2,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
}

_GENERIC_TREE_KEYS = {
    "sensitivity",
    "sensitivity_prcc",
    "prcc",
    "rows",
    "results",
    "rankings",
    "by_geometry",
    "by_metric",
    "metrics",
    "outputs",
    "data",
}


def _load_payload(value: Mapping[str, Any] | str | Path) -> Mapping[str, Any]:
    if isinstance(value, (str, Path)):
        result = json.loads(Path(value).read_text(encoding="utf-8"))
        if not isinstance(result, Mapping):
            raise ValueError("process-window JSON must contain a mapping")
        return result
    if not isinstance(value, Mapping):
        raise TypeError("expected a mapping or a JSON path")
    return value


def _destination(path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def _finish_figure(
    figure: plt.Figure,
    output_path: str | Path,
    *,
    dpi: int,
    bottom: float = 0.075,
) -> Path:
    if not isinstance(dpi, int) or dpi < 1:
        raise ValueError("dpi must be a positive integer")
    figure.text(
        0.5,
        0.012,
        SCREENING_NOTICE,
        ha="center",
        va="bottom",
        fontsize=7.2,
        color="0.32",
    )
    figure.subplots_adjust(bottom=bottom)
    destination = _destination(output_path)
    figure.savefig(destination, dpi=dpi, bbox_inches="tight")
    plt.close(figure)
    return destination


def _no_data_figure(
    output_path: str | Path,
    *,
    title: str,
    message: str,
    dpi: int,
) -> Path:
    """Write a valid, explicitly labelled placeholder for an omitted study."""

    with plt.rc_context(_STYLE):
        figure, axis = plt.subplots(figsize=(8.0, 3.6))
        axis.set_axis_off()
        axis.text(
            0.5,
            0.57,
            "No data",
            transform=axis.transAxes,
            ha="center",
            va="center",
            fontsize=18,
            color="0.30",
        )
        axis.text(
            0.5,
            0.38,
            message,
            transform=axis.transAxes,
            ha="center",
            va="center",
            fontsize=9,
            color="0.38",
            wrap=True,
        )
        figure.suptitle(title, y=0.94, fontsize=12)
        return _finish_figure(figure, output_path, dpi=dpi, bottom=0.12)


def _normalise_class(value: Any) -> str | None:
    if isinstance(value, Mapping):
        for key in ("primary_class", "dominant_class", "class", "label"):
            if key in value:
                return _normalise_class(value[key])
        return None
    if isinstance(value, (int, np.integer)):
        index = int(value)
        return CLASS_ORDER[index] if 0 <= index < len(CLASS_ORDER) else None
    if isinstance(value, (float, np.floating)) and float(value).is_integer():
        return _normalise_class(int(value))
    if value is None:
        return None
    token = str(value).strip().lower().replace("-", "_").replace(" ", "_")
    direct = {
        "complete": "complete_removal",
        "clear": "complete_removal",
        "cleared": "complete_removal",
        "fully_removed": "complete_removal",
        "complete_removal": "complete_removal",
        "bottom": "bottom_residue",
        "bottom_remaining": "bottom_residue",
        "bottom_residual": "bottom_residue",
        "bottom_residue": "bottom_residue",
        "wall": "wall_residue",
        "sidewall": "wall_residue",
        "sidewall_residue": "wall_residue",
        "wall_residual": "wall_residue",
        "wall_residue": "wall_residue",
        "deposit": "precipitation_residue",
        "deposit_residue": "precipitation_residue",
        "precipitate": "precipitation_residue",
        "precipitate_residue": "precipitation_residue",
        "precipitation": "precipitation_residue",
        "precipitation_residue": "precipitation_residue",
    }
    if token in direct:
        return direct[token]
    if "complete" in token or "clear" in token:
        return "complete_removal"
    if "bottom" in token or "floor" in token:
        return "bottom_residue"
    if "wall" in token:
        return "wall_residue"
    if "deposit" in token or "precip" in token:
        return "precipitation_residue"
    return None


def _first(mapping: Mapping[str, Any], names: Iterable[str]) -> Any:
    for name in names:
        if name in mapping:
            return mapping[name]
    return None


def _number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _known_geometry_ids(payload: Mapping[str, Any]) -> set[str]:
    result: set[str] = set()
    order = payload.get("geometry_order")
    if isinstance(order, Sequence) and not isinstance(order, (str, bytes)):
        result.update(str(value) for value in order)
    geometries = payload.get("geometries")
    if isinstance(geometries, Mapping):
        result.update(str(value) for value in geometries)
    for group in (payload.get("cases"), payload.get("aggregates")):
        if isinstance(group, Sequence) and not isinstance(group, (str, bytes)):
            for item in group:
                if isinstance(item, Mapping):
                    geometry = _first(item, ("geometry_id", "geometry", "geometry_name"))
                    if isinstance(geometry, str):
                        result.add(geometry)
    return result


def _looks_like_metric(token: str) -> bool:
    lowered = token.lower()
    return any(
        part in lowered
        for part in (
            "remaining",
            "residue",
            "deposit",
            "precip",
            "probability",
            "fraction",
            "score",
            "cluster",
            "complete",
        )
    )


def _ci(mapping: Mapping[str, Any]) -> tuple[float | None, float | None]:
    low = _number(_first(mapping, ("ci_low", "lower", "lower_ci", "p025")))
    high = _number(_first(mapping, ("ci_high", "upper", "upper_ci", "p975")))
    if low is not None and high is not None:
        return low, high
    interval = _first(mapping, ("ci", "ci95", "confidence_interval"))
    if (
        isinstance(interval, Sequence)
        and not isinstance(interval, (str, bytes))
        and len(interval) >= 2
    ):
        return _number(interval[0]), _number(interval[1])
    return None, None


def _extract_prcc_rows(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    root = payload.get("sensitivity", payload.get("sensitivity_prcc"))
    if root is None:
        raise ValueError("payload contains no sensitivity/PRCC section")
    if isinstance(root, Mapping) and isinstance(root.get("metrics"), Mapping):
        # The coordinator stores material/geometry-resolved PRCC under
        # ``strata`` for machine-readable follow-up.  The mandatory overview
        # figure stays readable by plotting the pooled metrics only; otherwise
        # 4 strata x 5 responses becomes a >20,000-pixel-tall panel and mixes
        # SiN/SiOCN bars under the same geometry title.
        root = {key: value for key, value in root.items() if key != "strata"}
    geometries = _known_geometry_ids(payload)
    rows: list[dict[str, Any]] = []

    def add_row(
        mapping: Mapping[str, Any],
        path: tuple[str, ...],
        geometry_hint: str | None,
        metric_hint: str | None,
        parameter_hint: str | None,
    ) -> bool:
        coefficient = None
        for key in ("coefficient", "estimate", "value", "prcc", "rho"):
            candidate = mapping.get(key)
            if not isinstance(candidate, (Mapping, Sequence)) or isinstance(
                candidate, (str, bytes)
            ):
                coefficient = _number(candidate)
                if coefficient is not None:
                    break
        if coefficient is None:
            return False

        parameter = _first(
            mapping,
            ("parameter", "parameter_id", "parameter_name", "input", "factor"),
        )
        metric = _first(
            mapping,
            ("metric", "metric_id", "output", "output_metric", "response"),
        )
        geometry = _first(mapping, ("geometry_id", "geometry", "geometry_name"))
        tokens = [token for token in path if token not in _GENERIC_TREE_KEYS]
        geometry_value = str(geometry) if geometry is not None else geometry_hint
        if geometry_value is None:
            geometry_value = next((token for token in tokens if token in geometries), "all")
        metric_value = str(metric) if metric is not None else metric_hint
        if metric_value is None:
            metric_value = next(
                (token for token in reversed(tokens) if _looks_like_metric(token)),
                "response",
            )
        parameter_value = str(parameter) if parameter is not None else parameter_hint
        if parameter_value is None:
            candidates = [
                token
                for token in tokens
                if token != geometry_value and token != metric_value
            ]
            parameter_value = candidates[-1] if candidates else "parameter"
        low, high = _ci(mapping)
        rows.append(
            {
                "geometry_id": geometry_value,
                "metric": metric_value,
                "parameter": parameter_value,
                "coefficient": coefficient,
                "ci_low": low,
                "ci_high": high,
            }
        )
        return True

    def walk(
        node: Any,
        path: tuple[str, ...] = (),
        geometry_hint: str | None = None,
        metric_hint: str | None = None,
        parameter_hint: str | None = None,
    ) -> None:
        if isinstance(node, Mapping):
            local_geometry = geometry_hint
            declared_geometry = _first(
                node, ("geometry_id", "geometry", "geometry_name")
            )
            if isinstance(declared_geometry, str):
                local_geometry = declared_geometry
            local_metric = metric_hint
            declared_metric = _first(
                node, ("metric", "metric_id", "output", "output_metric", "response")
            )
            if isinstance(declared_metric, str):
                local_metric = declared_metric
            if add_row(node, path, local_geometry, local_metric, parameter_hint):
                return
            for raw_key, value in node.items():
                key = str(raw_key)
                next_geometry = local_geometry
                next_metric = local_metric
                next_parameter = parameter_hint
                if key in geometries:
                    next_geometry = key
                elif next_metric is None and _looks_like_metric(key):
                    next_metric = key
                elif key not in _GENERIC_TREE_KEYS:
                    next_parameter = key
                if (
                    isinstance(value, (int, float, np.number))
                    and not isinstance(value, (bool, np.bool_))
                    and math.isfinite(float(value))
                ):
                    # Compact nested form: geometry -> metric -> parameter -> rho.
                    metadata_keys = {
                        "schema_version",
                        "sample_count",
                        "bootstrap_samples",
                        "confidence_level",
                        "seed",
                        "metric_index",
                        "bootstrap_valid",
                    }
                    if (
                        next_metric is not None
                        and key not in metadata_keys
                        and -1.0 <= float(value) <= 1.0
                    ):
                        tokens = [token for token in (*path, key) if token not in _GENERIC_TREE_KEYS]
                        metric_value = next_metric or next(
                            (token for token in reversed(tokens[:-1]) if _looks_like_metric(token)),
                            "response",
                        )
                        geometry_value = next_geometry or next(
                            (token for token in tokens if token in geometries),
                            "all",
                        )
                        rows.append(
                            {
                                "geometry_id": geometry_value,
                                "metric": metric_value,
                                "parameter": key,
                                "coefficient": float(value),
                                "ci_low": None,
                                "ci_high": None,
                            }
                        )
                else:
                    walk(
                        value,
                        (*path, key),
                        next_geometry,
                        next_metric,
                        next_parameter,
                    )
        elif isinstance(node, Sequence) and not isinstance(node, (str, bytes)):
            for item in node:
                walk(item, path, geometry_hint, metric_hint, parameter_hint)

    walk(root)
    unique: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str, float]] = set()
    for row in rows:
        key = (
            str(row["geometry_id"]),
            str(row["metric"]),
            str(row["parameter"]),
            float(row["coefficient"]),
        )
        if key not in seen:
            seen.add(key)
            unique.append(row)
    if not unique:
        raise ValueError("sensitivity section contains no readable PRCC rows")
    return unique


def plot_sensitivity_prcc(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot horizontal PRCC bars and available confidence intervals."""

    payload = _load_payload(payload_or_path)
    rows = _extract_prcc_rows(payload)
    groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault((row["geometry_id"], row["metric"]), []).append(row)
    ordered_groups = list(groups.items())
    panel_count = len(ordered_groups)
    columns = min(2, panel_count)
    panel_rows = int(math.ceil(panel_count / columns))
    maximum_parameters = max(len(values) for _, values in ordered_groups)
    panel_height = max(3.0, 1.25 + 0.29 * maximum_parameters)

    with plt.rc_context(_STYLE):
        figure, axes_array = plt.subplots(
            panel_rows,
            columns,
            figsize=(7.0 * columns, panel_height * panel_rows),
            squeeze=False,
        )
        axes = list(axes_array.ravel())
        for axis, ((geometry, metric), values) in zip(
            axes, ordered_groups, strict=False
        ):
            ordered = sorted(values, key=lambda item: abs(item["coefficient"]))
            coefficients = np.asarray(
                [float(item["coefficient"]) for item in ordered], dtype=float
            )
            positions = np.arange(len(ordered), dtype=float)
            colors = np.where(coefficients >= 0.0, "#0072B2", "#D55E00")
            axis.barh(positions, coefficients, color=colors, height=0.68, linewidth=0)
            for position, item in zip(positions, ordered, strict=True):
                low, high = item["ci_low"], item["ci_high"]
                if low is None or high is None:
                    continue
                centre = float(item["coefficient"])
                axis.errorbar(
                    centre,
                    position,
                    xerr=np.asarray([[max(centre - low, 0.0)], [max(high - centre, 0.0)]]),
                    fmt="none",
                    ecolor="0.18",
                    elinewidth=0.8,
                    capsize=2.0,
                    zorder=4,
                )
            axis.axvline(0.0, color="0.20", linewidth=0.75)
            axis.set_yticks(positions, [str(item["parameter"]) for item in ordered])
            axis.set_xlim(-1.05, 1.05)
            axis.set_xlabel("partial rank correlation coefficient")
            axis.set_title(f"{geometry} | {metric}")
            axis.grid(axis="x", color="0.88", linewidth=0.6)
            axis.set_axisbelow(True)
        for axis in axes[panel_count:]:
            axis.set_visible(False)
        figure.suptitle("Global parameter sensitivity (PRCC)", y=0.995, fontsize=12)
        figure.tight_layout(rect=(0.02, 0.18, 0.99, 0.97))
        return _finish_figure(figure, output_path, dpi=dpi, bottom=0.19)


@dataclass(frozen=True)
class _PhaseView:
    geometry_id: str
    x_name: str
    y_name: str
    x_values: np.ndarray
    y_values: np.ndarray
    dominant_codes: np.ndarray
    dominant_probability: np.ndarray
    class_probabilities: Mapping[str, np.ndarray]
    hard_probability_fallback: bool


def _phase_records(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    root = payload.get("phase_maps", payload.get("phase_map"))
    if root is None:
        return []
    def expand(item: Mapping[str, Any]) -> list[Mapping[str, Any]]:
        strata = item.get("strata")
        if not isinstance(strata, Sequence) or isinstance(strata, (str, bytes)):
            return [dict(item)]
        shared = {key: value for key, value in item.items() if key != "strata"}
        result = []
        for stratum in strata:
            if isinstance(stratum, Mapping):
                result.append({**shared, **dict(stratum)})
        return result

    if isinstance(root, Sequence) and not isinstance(root, (str, bytes)):
        records: list[Mapping[str, Any]] = []
        for item in root:
            if isinstance(item, Mapping):
                records.extend(expand(item))
        return records
    if not isinstance(root, Mapping):
        raise ValueError("phase_maps must be a list or mapping")
    for key in ("maps", "records", "items"):
        value = root.get(key)
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            records = []
            for item in value:
                if isinstance(item, Mapping):
                    records.extend(expand(item))
            return records

    records: list[Mapping[str, Any]] = []
    by_geometry = root.get("by_geometry")
    if isinstance(by_geometry, Mapping):
        shared_axes = root.get("axes")
        for geometry, value in by_geometry.items():
            if isinstance(value, Mapping):
                nested = value.get("maps")
                if isinstance(nested, Sequence) and not isinstance(nested, (str, bytes)):
                    for item in nested:
                        if isinstance(item, Mapping):
                            record = dict(item)
                            record.setdefault("geometry_id", str(geometry))
                            if shared_axes is not None:
                                record.setdefault("axes", shared_axes)
                            records.extend(expand(record))
                else:
                    record = dict(value)
                    record.setdefault("geometry_id", str(geometry))
                    if shared_axes is not None:
                        record.setdefault("axes", shared_axes)
                    records.extend(expand(record))
        return records

    for key, value in root.items():
        if key in {"axes", "axis_definition", "dimension_order"}:
            continue
        if isinstance(value, Mapping):
            record = dict(value)
            record.setdefault("map_id", str(key))
            records.extend(expand(record))
    if records:
        return records
    # A single phase-map record is also valid.
    return [root]


def _axis_definition(
    record: Mapping[str, Any], axis: str
) -> tuple[str | None, np.ndarray | None]:
    name = _first(
        record,
        (
            f"{axis}_parameter",
            f"{axis}_name",
            f"parameter_{axis}",
            f"axis_{axis}_name",
        ),
    )
    values = _first(
        record,
        (f"{axis}_values", f"{axis}_centers", f"axis_{axis}_values"),
    )
    axes = record.get("axes")
    if isinstance(axes, Mapping):
        definition = axes.get(axis, axes.get(f"axis_{axis}"))
        if isinstance(definition, Mapping):
            if name is None:
                name = _first(definition, ("parameter", "name", "id", "label"))
            if values is None:
                values = _first(definition, ("values", "centers", "coordinates"))
        elif definition is not None and values is None:
            values = definition

    order = record.get("dimension_order")
    if (
        isinstance(order, Sequence)
        and not isinstance(order, (str, bytes))
        and len(order) == 2
    ):
        ordered_name = str(order[1] if axis == "x" else order[0])
        if name is None:
            name = ordered_name
        if values is None and isinstance(axes, Mapping):
            values = axes.get(ordered_name)
    if name is not None and values is None and isinstance(axes, Mapping):
        values = axes.get(str(name))
    array = None if values is None else np.asarray(values, dtype=float).reshape(-1)
    return None if name is None else str(name), array


def _probability_mapping(record: Mapping[str, Any]) -> dict[str, np.ndarray]:
    raw = _first(
        record,
        ("class_probabilities", "class_probability", "probabilities", "probability_maps"),
    )
    result: dict[str, np.ndarray] = {}
    if isinstance(raw, Mapping):
        for key, value in raw.items():
            class_name = _normalise_class(key)
            if class_name is not None:
                result[class_name] = np.asarray(value, dtype=float)
    elif isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)):
        for item in raw:
            if not isinstance(item, Mapping):
                continue
            class_name = _normalise_class(_first(item, ("class", "class_id", "name")))
            values = _first(item, ("values", "probability", "matrix"))
            if class_name is not None and values is not None:
                result[class_name] = np.asarray(values, dtype=float)
    # Some coordinators put each probability matrix directly on the record.
    for class_name in CLASS_ORDER:
        for key in (class_name, f"p_{class_name}", f"probability_{class_name}"):
            if key in record and class_name not in result:
                result[class_name] = np.asarray(record[key], dtype=float)
    return result


def _class_code_array(value: Any) -> np.ndarray:
    raw = np.asarray(value, dtype=object)
    result = np.full(raw.shape, -1, dtype=np.int16)
    for index in np.ndindex(raw.shape):
        name = _normalise_class(raw[index])
        if name is not None:
            result[index] = _CLASS_CODES[name]
    return result


def _orient_matrix(value: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    array = np.asarray(value)
    if array.shape == shape:
        return array.copy()
    if array.shape == (shape[1], shape[0]):
        return array.T.copy()
    if array.size == shape[0] * shape[1]:
        return array.reshape(shape).copy()
    raise ValueError(f"phase matrix shape {array.shape} cannot map to {shape}")


def _normalise_phase(record: Mapping[str, Any]) -> _PhaseView:
    probabilities = _probability_mapping(record)
    dominant_raw = _first(
        record,
        ("dominant_class", "dominant_classes", "classification", "classes"),
    )
    candidate_shape: tuple[int, int] | None = None
    if dominant_raw is not None:
        dominant_candidate = np.asarray(dominant_raw, dtype=object)
        if dominant_candidate.ndim == 2:
            candidate_shape = dominant_candidate.shape
    if candidate_shape is None:
        for values in probabilities.values():
            if values.ndim == 2:
                candidate_shape = values.shape
                break
    if candidate_shape is None:
        raise ValueError("phase map needs a two-dimensional class/probability matrix")

    x_name, x_values = _axis_definition(record, "x")
    y_name, y_values = _axis_definition(record, "y")
    ny, nx = candidate_shape
    # If axis lengths clearly indicate a transpose, orient to axis order.
    if (
        x_values is not None
        and y_values is not None
        and len(x_values) in {ny, ny + 1}
        and len(y_values) in {nx, nx + 1}
        and not (
            len(x_values) in {nx, nx + 1} and len(y_values) in {ny, ny + 1}
        )
    ):
        ny, nx = nx, ny
    shape = (ny, nx)

    probability_arrays: dict[str, np.ndarray] = {}
    for class_name, values in probabilities.items():
        probability_arrays[class_name] = np.clip(
            _orient_matrix(np.asarray(values, dtype=float), shape), 0.0, 1.0
        )
    fallback = False
    if dominant_raw is not None:
        dominant = _orient_matrix(_class_code_array(dominant_raw), shape).astype(np.int16)
    elif probability_arrays:
        stack = np.stack(
            [
                probability_arrays.get(name, np.zeros(shape, dtype=float))
                for name in CLASS_ORDER
            ],
            axis=0,
        )
        dominant = np.argmax(np.nan_to_num(stack, nan=-1.0), axis=0).astype(np.int16)
    else:
        raise ValueError("phase map has neither dominant classes nor probabilities")

    dominant_probability_raw = _first(
        record,
        ("dominant_probability", "dominant_probabilities", "confidence", "class_confidence"),
    )
    if dominant_probability_raw is not None:
        dominant_probability = np.clip(
            _orient_matrix(np.asarray(dominant_probability_raw, dtype=float), shape),
            0.0,
            1.0,
        )
    elif probability_arrays:
        stack = np.stack(
            [
                probability_arrays.get(name, np.zeros(shape, dtype=float))
                for name in CLASS_ORDER
            ],
            axis=0,
        )
        dominant_probability = np.nanmax(stack, axis=0)
    else:
        dominant_probability = np.ones(shape, dtype=float)

    if not probability_arrays:
        fallback = True
        probability_arrays = {
            class_name: (dominant == code).astype(float)
            for class_name, code in _CLASS_CODES.items()
        }
    else:
        for class_name in CLASS_ORDER:
            probability_arrays.setdefault(class_name, np.zeros(shape, dtype=float))

    x_values = np.arange(nx, dtype=float) if x_values is None else x_values
    y_values = np.arange(ny, dtype=float) if y_values is None else y_values
    if len(x_values) not in {nx, nx + 1} or len(y_values) not in {ny, ny + 1}:
        raise ValueError("phase axis lengths must match matrix centres or edges")
    geometry = _first(record, ("geometry_id", "geometry", "geometry_name"))
    material = record.get("material")
    stratum_label = "all" if geometry is None else str(geometry)
    if material is not None:
        stratum_label += f" / {material}"
    elif record.get("preset_id") is not None:
        stratum_label += f" / {record['preset_id']}"
    return _PhaseView(
        geometry_id=stratum_label,
        x_name=x_name or "x parameter",
        y_name=y_name or "y parameter",
        x_values=x_values,
        y_values=y_values,
        dominant_codes=dominant,
        dominant_probability=dominant_probability,
        class_probabilities=probability_arrays,
        hard_probability_fallback=fallback,
    )


def _coordinate_edges(values: np.ndarray, count: int) -> np.ndarray:
    coordinates = np.asarray(values, dtype=float).reshape(-1)
    if coordinates.size == count + 1:
        return coordinates
    if coordinates.size != count:
        raise ValueError("coordinate count does not match phase matrix")
    if count == 1:
        span = max(abs(float(coordinates[0])) * 0.1, 0.5)
        return np.asarray((coordinates[0] - span, coordinates[0] + span))
    if np.any(np.diff(coordinates) <= 0.0):
        raise ValueError("phase coordinates must increase strictly")
    edges = np.empty(count + 1, dtype=float)
    edges[1:-1] = 0.5 * (coordinates[:-1] + coordinates[1:])
    edges[0] = coordinates[0] - 0.5 * (coordinates[1] - coordinates[0])
    edges[-1] = coordinates[-1] + 0.5 * (coordinates[-1] - coordinates[-2])
    return edges


def _coordinate_centres(values: np.ndarray, count: int) -> np.ndarray:
    coordinates = np.asarray(values, dtype=float).reshape(-1)
    if coordinates.size == count:
        return coordinates
    if coordinates.size == count + 1:
        return 0.5 * (coordinates[:-1] + coordinates[1:])
    raise ValueError("coordinate count does not match phase matrix")


def _phase_views(payload: Mapping[str, Any]) -> list[_PhaseView]:
    views = [_normalise_phase(record) for record in _phase_records(payload)]
    return views


def _phase_axis_ticks(axis: plt.Axes, view: _PhaseView) -> None:
    ny, nx = view.dominant_codes.shape
    x = _coordinate_centres(view.x_values, nx)
    y = _coordinate_centres(view.y_values, ny)
    x_indices = np.arange(nx) if nx <= 7 else np.linspace(0, nx - 1, 5).round().astype(int)
    y_indices = np.arange(ny) if ny <= 7 else np.linspace(0, ny - 1, 5).round().astype(int)
    # Phase grids are sampled uniformly in each parameter's declared
    # transformed coordinate.  Display cells at equal width/height and retain
    # the physical values as tick labels; plotting raw log-spaced values would
    # visually collapse the low-end cells.
    axis.set_xticks(x_indices, [f"{x[index]:.3g}" for index in x_indices])
    axis.set_yticks(y_indices, [f"{y[index]:.3g}" for index in y_indices])
    axis.set_xlabel(view.x_name)
    axis.set_ylabel(view.y_name)


def plot_dominant_phase_maps(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot dominant outcome class and its replicate probability per cell."""

    payload = _load_payload(payload_or_path)
    views = _phase_views(payload)
    if not views:
        return _no_data_figure(
            output_path,
            title="Process-window phase classification",
            message=(
                "Phase-map calculations were omitted (for example by a "
                "global-only run), so no dominant-class grid is available."
            ),
            dpi=dpi,
        )
    columns = (
        len(views)
        if len(views) <= 2
        else (3 if len(views) <= 6 else 4)
    )
    rows = int(math.ceil(len(views) / columns))
    cmap = ListedColormap([CLASS_COLORS[name] for name in CLASS_ORDER])
    legend = [
        Patch(facecolor=CLASS_COLORS[name], label=CLASS_LABELS[name])
        for name in CLASS_ORDER
    ]
    with plt.rc_context(_STYLE):
        figure, axes_array = plt.subplots(
            rows,
            columns,
            figsize=(4.45 * columns, 3.65 * rows),
            squeeze=False,
        )
        axes = list(axes_array.ravel())
        for axis, view in zip(axes, views, strict=False):
            ny, nx = view.dominant_codes.shape
            x_edges = np.arange(nx + 1, dtype=float) - 0.5
            y_edges = np.arange(ny + 1, dtype=float) - 0.5
            masked = np.ma.masked_where(view.dominant_codes < 0, view.dominant_codes)
            axis.pcolormesh(
                x_edges,
                y_edges,
                masked,
                cmap=cmap,
                vmin=-0.5,
                vmax=len(CLASS_ORDER) - 0.5,
                shading="flat",
                edgecolors="white",
                linewidth=0.4,
                rasterized=True,
            )
            for row_index in range(ny):
                for column_index in range(nx):
                    code = int(view.dominant_codes[row_index, column_index])
                    probability = float(
                        view.dominant_probability[row_index, column_index]
                    )
                    if code < 0 or not math.isfinite(probability):
                        continue
                    class_name = CLASS_ORDER[code]
                    annotation = axis.text(
                        float(column_index),
                        float(row_index),
                        f"{_CLASS_ABBREVIATIONS[class_name]} {probability:.0%}",
                        ha="center",
                        va="center",
                        fontsize=6.2 if max(nx, ny) <= 10 else 5.1,
                        color="white",
                        fontweight="bold",
                    )
                    annotation.set_path_effects(
                        [patheffects.withStroke(linewidth=1.25, foreground="0.16")]
                    )
            _phase_axis_ticks(axis, view)
            axis.set_title(f"{view.geometry_id} | dominant process outcome")
        for axis in axes[len(views) :]:
            axis.set_visible(False)
        figure.legend(
            handles=legend,
            loc="upper center",
            bbox_to_anchor=(0.5, 0.955),
            ncol=4,
            frameon=False,
        )
        figure.suptitle("Process-window phase classification", y=0.995, fontsize=12)
        figure.tight_layout(rect=(0.02, 0.14, 0.99, 0.88))
        return _finish_figure(figure, output_path, dpi=dpi, bottom=0.15)


def _light_to_color(color: str, name: str) -> LinearSegmentedColormap:
    return LinearSegmentedColormap.from_list(name, ("#F5F5F5", color), N=256)


def plot_class_probability_maps(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot four class-probability heatmaps for every geometry/axis pair."""

    payload = _load_payload(payload_or_path)
    views = _phase_views(payload)
    if not views:
        return _no_data_figure(
            output_path,
            title="Outcome probability maps",
            message=(
                "Phase-map calculations were omitted, so class-probability "
                "heatmaps are not available."
            ),
            dpi=dpi,
        )
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(
            len(views),
            len(CLASS_ORDER),
            figsize=(4.0 * len(CLASS_ORDER), 3.75 * len(views)),
            squeeze=False,
        )
        for row_index, view in enumerate(views):
            ny, nx = view.dominant_codes.shape
            x_edges = np.arange(nx + 1, dtype=float) - 0.5
            y_edges = np.arange(ny + 1, dtype=float) - 0.5
            for column_index, class_name in enumerate(CLASS_ORDER):
                axis = axes[row_index, column_index]
                values = np.asarray(view.class_probabilities[class_name], dtype=float)
                axis.pcolormesh(
                    x_edges,
                    y_edges,
                    np.ma.masked_invalid(values),
                    cmap=_light_to_color(CLASS_COLORS[class_name], f"{class_name}_{row_index}"),
                    norm=Normalize(0.0, 1.0),
                    shading="flat",
                    edgecolors="white",
                    linewidth=0.35,
                    rasterized=True,
                )
                if len(views) <= 2 and nx * ny <= 36:
                    for iy in range(ny):
                        for ix in range(nx):
                            probability = float(values[iy, ix])
                            if math.isfinite(probability):
                                axis.text(
                                    float(ix),
                                    float(iy),
                                    f"{probability:.0%}",
                                    ha="center",
                                    va="center",
                                    fontsize=5.8,
                                    color="0.12" if probability < 0.58 else "white",
                                )
                _phase_axis_ticks(axis, view)
                axis.set_title(CLASS_LABELS[class_name])
                if column_index == 0:
                    fallback = " | hard-class fallback" if view.hard_probability_fallback else ""
                    axis.set_ylabel(f"{view.geometry_id}{fallback}\n{view.y_name}")
                else:
                    axis.set_ylabel("")
        figure.suptitle(
            "Outcome probability maps (light = 0, saturated = 1)",
            y=0.992,
            fontsize=12,
        )
        figure.tight_layout(rect=(0.02, 0.14, 0.995, 0.965))
        return _finish_figure(figure, output_path, dpi=dpi, bottom=0.15)


def _representative_records(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    raw = payload.get("representatives")
    result: list[Mapping[str, Any]] = []
    if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)):
        result.extend(dict(item) for item in raw if isinstance(item, Mapping))
    elif isinstance(raw, Mapping):
        for key in ("cases", "records", "items"):
            values = raw.get(key)
            if isinstance(values, Sequence) and not isinstance(values, (str, bytes)):
                result.extend(
                    dict(item) for item in values if isinstance(item, Mapping)
                )
                break
        else:
            for key, value in raw.items():
                if isinstance(value, Mapping):
                    record = dict(value)
                    record.setdefault("representative_id", str(key))
                    result.append(record)
    if result:
        return result
    cases = payload.get("cases")
    if isinstance(cases, Sequence) and not isinstance(cases, (str, bytes)):
        for item in cases:
            if isinstance(item, Mapping) and (
                "snapshot" in item or _find_profile(item) is not None
            ):
                result.append(dict(item))
    return result


def _site_records(value: Any) -> tuple[Mapping[str, Any], ...]:
    if value is None:
        return ()
    if isinstance(value, Mapping):
        if "records" in value:
            return _site_records(value["records"])
        columns = dict(value)
        lengths = []
        for column in columns.values():
            if isinstance(column, (str, bytes)):
                continue
            array = np.asarray(column, dtype=object)
            if array.ndim > 0:
                lengths.append(len(array))
        if not lengths or len(set(lengths)) != 1:
            return ()
        records = []
        for index in range(lengths[0]):
            row: dict[str, Any] = {}
            for key, column in columns.items():
                array = np.asarray(column, dtype=object)
                item = array.item() if array.ndim == 0 else array[index]
                row[str(key)] = item.item() if isinstance(item, np.generic) else item
            records.append(row)
        return tuple(records)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return tuple(dict(item) for item in value if isinstance(item, Mapping))
    return ()


def _snapshot_from_representative(record: Mapping[str, Any]) -> Mapping[str, Any] | None:
    snapshot = record.get("snapshot")
    if isinstance(snapshot, Mapping):
        return snapshot
    if "sites" in record:
        return record
    return None


def _find_profile(record: Mapping[str, Any]) -> Mapping[str, Any] | None:
    for key in (
        "spatial_profile",
        "residue_profile",
        "depth_profile",
        "profile",
        "spatial_metric_profile",
    ):
        value = record.get(key)
        if isinstance(value, Mapping):
            return value
    metrics = record.get("metrics")
    if isinstance(metrics, Mapping):
        for key in (
            "spatial_profile",
            "residue_profile",
            "depth_profile",
            "profile",
        ):
            value = metrics.get(key)
            if isinstance(value, Mapping):
                return value
    return None


def _representative_title(record: Mapping[str, Any]) -> str:
    geometry = _first(record, ("geometry_id", "geometry", "geometry_name"))
    material = record.get("material")
    preset = record.get("preset_id")
    classification = _first(
        record,
        ("primary_class", "dominant_class", "class", "classification"),
    )
    class_name = _normalise_class(classification)
    case_id = _first(record, ("case_id", "representative_id", "id"))
    parts = []
    if geometry is not None:
        parts.append(str(geometry))
    if material is not None:
        parts.append(str(material))
    elif preset is not None:
        parts.append(str(preset))
    if class_name is not None:
        parts.append(CLASS_LABELS[class_name])
    if not parts and case_id is not None:
        parts.append(str(case_id))
    return " | ".join(parts) if parts else "Representative outcome"


def _record_number(record: Mapping[str, Any], *names: str, default: float = 0.0) -> float:
    value = _number(_first(record, names))
    return default if value is None else value


def _plot_snapshot(axis: plt.Axes, representative: Mapping[str, Any]) -> bool:
    snapshot = _snapshot_from_representative(representative)
    if snapshot is None:
        return False
    sites = _site_records(snapshot.get("sites"))
    if not sites:
        return False
    matrix: list[Mapping[str, Any]] = []
    collectors: list[Mapping[str, Any]] = []
    for site in sites:
        site_type = str(site.get("site_type", site.get("type", "matrix"))).lower()
        if _record_number(site, "collector_flag") > 0.5 or site_type == "collector":
            collectors.append(site)
        else:
            matrix.append(site)

    def coordinates(records: Sequence[Mapping[str, Any]]) -> tuple[np.ndarray, np.ndarray]:
        return (
            np.asarray(
                [_record_number(item, "x_nm", "lateral_nm") for item in records],
                dtype=float,
            ),
            np.asarray(
                [_record_number(item, "depth_nm", "z_nm") for item in records],
                dtype=float,
            ),
        )

    removed = [site for site in matrix if str(site.get("state", "intact")) == "removed"]
    remaining = [site for site in matrix if str(site.get("state", "intact")) != "removed"]
    if removed:
        x, depth = coordinates(removed)
        axis.scatter(
            x,
            depth,
            marker="s",
            s=9,
            color="#B9DDE5",
            alpha=0.22,
            linewidth=0,
            rasterized=True,
            label="removed matrix",
        )
    state_colors = {
        "buried": "#55575A",
        "intact": "#55575A",
        "activated": "#0072B2",
        "passivated": CLASS_COLORS["bottom_residue"],
    }
    for state in ("buried", "intact", "activated", "passivated"):
        selected = [site for site in remaining if str(site.get("state", "intact")) == state]
        if not selected:
            continue
        x, depth = coordinates(selected)
        axis.scatter(
            x,
            depth,
            marker="s",
            s=12,
            color=state_colors[state],
            alpha=0.88,
            linewidth=0,
            rasterized=True,
            label=f"matrix {state}",
        )
    other_remaining = [
        site
        for site in remaining
        if str(site.get("state", "intact")) not in state_colors
    ]
    if other_remaining:
        x, depth = coordinates(other_remaining)
        axis.scatter(
            x,
            depth,
            marker="s",
            s=12,
            color="#55575A",
            alpha=0.88,
            linewidth=0,
            rasterized=True,
            label="matrix residue",
        )

    deposit_sites: list[Mapping[str, Any]] = []
    deposit_strength: list[float] = []
    for site in collectors:
        coverage = max(_record_number(site, "deposit_coverage", "coverage"), 0.0)
        thickness = max(
            _record_number(site, "deposit_thickness_nm", "thickness_nm"), 0.0
        )
        state_is_deposit = str(site.get("state", "collector")) == "deposit"
        if state_is_deposit or coverage > 0.0 or thickness > 0.0:
            deposit_sites.append(site)
            # Coverage is the preferred dimensionless strength.  Thickness is
            # a fallback and is softly compressed so a single large value does
            # not dominate marker sizes.
            deposit_strength.append(
                coverage if coverage > 0.0 else (1.0 if state_is_deposit and thickness == 0.0 else math.log1p(thickness))
            )
    if deposit_sites:
        x, depth = coordinates(deposit_sites)
        strength = np.asarray(deposit_strength, dtype=float)
        normalised = np.clip(strength, 0.0, 1.0)
        visual_strength = np.sqrt(normalised)
        sizes = 4.0 + 64.0 * visual_strength
        alpha = 0.08 + 0.88 * visual_strength
        base_rgb = np.asarray(matplotlib.colors.to_rgb(CLASS_COLORS["precipitation_residue"]))
        rgba = np.column_stack(
            (
                np.broadcast_to(base_rgb, (len(deposit_sites), 3)),
                alpha,
            )
        )
        axis.scatter(
            x,
            depth,
            marker="D",
            s=sizes,
            facecolors=rgba,
            edgecolors="#FFFFFF",
            linewidth=0.35,
            rasterized=True,
            label="collector deposit",
            zorder=5,
        )
    axis.set_xlabel("lateral x (nm; visually expanded)")
    axis.set_ylabel("depth z (nm)")
    axis.invert_yaxis()
    axis.grid(color="0.91", linewidth=0.45)
    return True


def _profile_series(profile: Mapping[str, Any]) -> tuple[np.ndarray, list[tuple[str, np.ndarray]]]:
    depth_raw = _first(profile, ("depth_nm", "z_nm", "depth", "coordinate_nm"))
    if depth_raw is None:
        raise ValueError("spatial profile needs depth_nm/z_nm")
    depth = np.asarray(depth_raw, dtype=float).reshape(-1)
    series: list[tuple[str, np.ndarray]] = []
    sources = [profile]
    metrics = profile.get("metrics")
    if isinstance(metrics, Mapping):
        sources.append(metrics)
    excluded = {"depth_nm", "z_nm", "depth", "coordinate_nm", "metrics"}
    for source in sources:
        for key, value in source.items():
            if key in excluded or isinstance(value, (str, bytes, Mapping)):
                continue
            array = np.asarray(value, dtype=float)
            if array.ndim == 1 and array.size == depth.size:
                series.append((str(key), array))
    if not series:
        raise ValueError("spatial profile contains no depth-aligned metric")
    return depth, series


def _plot_profile(axis: plt.Axes, representative: Mapping[str, Any]) -> bool:
    profile = _find_profile(representative)
    if profile is None:
        return False
    depth, series = _profile_series(profile)
    palette = (
        CLASS_COLORS["bottom_residue"],
        CLASS_COLORS["wall_residue"],
        CLASS_COLORS["precipitation_residue"],
        CLASS_COLORS["complete_removal"],
        "#0072B2",
    )
    for index, (name, values) in enumerate(series[:5]):
        axis.plot(values, depth, color=palette[index], linewidth=1.7, label=name)
    axis.invert_yaxis()
    axis.set_xlabel("spatial residue metric")
    axis.set_ylabel("depth z (nm)")
    axis.grid(color="0.90", linewidth=0.55)
    return True


def plot_representative_residue_graphs(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
    max_panels: int = 16,
) -> Path:
    """Plot representative graph snapshots or spatial-profile fallbacks."""

    if not isinstance(max_panels, int) or max_panels < 1:
        raise ValueError("max_panels must be a positive integer")
    payload = _load_payload(payload_or_path)
    representatives = _representative_records(payload)[:max_panels]
    if not representatives:
        return _no_data_figure(
            output_path,
            title="Representative final residue graphs",
            message=(
                "Representative reruns were omitted, so no graph snapshot or "
                "spatial profile is available."
            ),
            dpi=dpi,
        )
    columns = min(4, len(representatives))
    rows = int(math.ceil(len(representatives) / columns))
    with plt.rc_context(_STYLE):
        figure, axes_array = plt.subplots(
            rows,
            columns,
            figsize=(3.45 * columns, 5.0 * rows),
            squeeze=False,
        )
        axes = list(axes_array.ravel())
        used_labels: dict[str, Any] = {}
        for axis, representative in zip(axes, representatives, strict=False):
            plotted = _plot_snapshot(axis, representative)
            if not plotted:
                plotted = _plot_profile(axis, representative)
            if not plotted:
                axis.text(
                    0.5,
                    0.5,
                    "No graph snapshot or spatial profile",
                    ha="center",
                    va="center",
                    transform=axis.transAxes,
                )
                axis.set_axis_off()
            axis.set_title(_representative_title(representative))
            handles, labels = axis.get_legend_handles_labels()
            for handle, label in zip(handles, labels, strict=True):
                used_labels.setdefault(label, handle)
        for axis in axes[len(representatives) :]:
            axis.set_visible(False)
        if used_labels:
            figure.legend(
                used_labels.values(),
                used_labels.keys(),
                loc="upper center",
                bbox_to_anchor=(0.5, 0.945),
                ncol=min(5, len(used_labels)),
                frameon=False,
            )
        figure.suptitle(
            "Representative final residue graphs (horizontal dimension expanded)",
            y=0.995,
            fontsize=12,
        )
        figure.tight_layout(rect=(0.02, 0.14, 0.99, 0.87))
        return _finish_figure(figure, output_path, dpi=dpi, bottom=0.15)


def plot_process_window_visualizations(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_directory: str | Path,
    *,
    dpi: int = 300,
) -> dict[str, Path]:
    """Write the four mandatory process-window figures."""

    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    return {
        "sensitivity_prcc": plot_sensitivity_prcc(
            payload_or_path, output / "sensitivity_prcc.png", dpi=dpi
        ),
        "dominant_phase_maps": plot_dominant_phase_maps(
            payload_or_path, output / "dominant_phase_maps.png", dpi=dpi
        ),
        "class_probability_maps": plot_class_probability_maps(
            payload_or_path, output / "class_probability_maps.png", dpi=dpi
        ),
        "representative_residue_graphs": plot_representative_residue_graphs(
            payload_or_path, output / "representative_residue_graphs.png", dpi=dpi
        ),
    }


def plot_process_window_outputs(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_directory: str | Path,
    *,
    dpi: int = 300,
) -> dict[str, Path]:
    """Backward-compatible coordinator entry point for all four figures."""

    return plot_process_window_visualizations(
        payload_or_path,
        output_directory,
        dpi=dpi,
    )


__all__ = [
    "CLASS_COLORS",
    "CLASS_LABELS",
    "CLASS_ORDER",
    "SCREENING_NOTICE",
    "plot_class_probability_maps",
    "plot_dominant_phase_maps",
    "plot_process_window_outputs",
    "plot_process_window_visualizations",
    "plot_representative_residue_graphs",
    "plot_sensitivity_prcc",
]

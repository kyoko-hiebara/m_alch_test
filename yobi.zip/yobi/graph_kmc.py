"""Rejection-free kinetic Monte Carlo on an amorphous connectivity graph.

No external graph package is required.  The connectivity is fixed during a
run; dissolution is represented by site states (for example ``removed``), so
the original amorphous neighbourhood remains available for bookkeeping.
Event rates may depend on a site's attributes and neighbour states.  After an
event, only the dependency neighbourhood of changed sites is recomputed.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np


class SiteState(str, Enum):
    INTACT = "intact"
    ACTIVATED = "activated"
    OXIDIZED = "oxidized"
    PASSIVATED = "passivated"
    REMOVED = "removed"


def _state_name(value: str | SiteState) -> str:
    if isinstance(value, Enum):
        return str(value.value)
    value = str(value)
    if not value:
        raise ValueError("site state must not be empty")
    return value


@dataclass
class GraphSite:
    site_id: int
    state: str | SiteState = SiteState.INTACT
    material: str = "SiN"
    attributes: dict[str, float] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.site_id, int):
            raise TypeError("site_id must be an integer")
        self.state = _state_name(self.state)
        self.material = str(self.material)
        if not self.material:
            raise ValueError("material must not be empty")
        copied: dict[str, float] = {}
        for name, value in self.attributes.items():
            number = float(value)
            if not math.isfinite(number):
                raise ValueError(f"site attribute {name!r} must be finite")
            copied[str(name)] = number
        self.attributes = copied

    def copy(self) -> "GraphSite":
        return GraphSite(
            site_id=self.site_id,
            state=self.state,
            material=self.material,
            attributes=dict(self.attributes),
        )


class AmorphousGraph:
    """Small undirected adjacency graph with mutable site state/attributes."""

    def __init__(
        self,
        sites: Iterable[GraphSite] | Mapping[int, GraphSite],
        edges: Iterable[tuple[int, int]] = (),
    ) -> None:
        values = sites.values() if isinstance(sites, Mapping) else sites
        self.sites: dict[int, GraphSite] = {}
        for site in values:
            if site.site_id in self.sites:
                raise ValueError(f"duplicate site id {site.site_id}")
            self.sites[site.site_id] = site.copy()
        if not self.sites:
            raise ValueError("an amorphous graph needs at least one site")
        self._adjacency: dict[int, set[int]] = {
            site_id: set() for site_id in self.sites
        }
        for left, right in edges:
            self.add_edge(left, right)

    def copy(self) -> "AmorphousGraph":
        edges = [
            (left, right)
            for left in self.site_ids
            for right in self._adjacency[left]
            if left < right
        ]
        return AmorphousGraph(self.sites, edges)

    @property
    def site_ids(self) -> tuple[int, ...]:
        return tuple(sorted(self.sites))

    def add_edge(self, left: int, right: int) -> None:
        if left == right:
            raise ValueError("self edges are not supported")
        if left not in self.sites or right not in self.sites:
            raise KeyError("both edge endpoints must exist")
        self._adjacency[left].add(right)
        self._adjacency[right].add(left)

    def neighbors(self, site_id: int) -> tuple[int, ...]:
        if site_id not in self.sites:
            raise KeyError(site_id)
        return tuple(sorted(self._adjacency[site_id]))

    def coordination(
        self,
        site_id: int,
        *,
        states: Iterable[str | SiteState] | None = None,
    ) -> int:
        neighbours = self._adjacency[site_id]
        if states is None:
            return len(neighbours)
        allowed = {_state_name(state) for state in states}
        return sum(self.sites[other].state in allowed for other in neighbours)

    def state_counts(self) -> dict[str, int]:
        return dict(Counter(site.state for site in self.sites.values()))


@dataclass(frozen=True)
class EventContext:
    graph: AmorphousGraph
    site_id: int
    event_name: str
    time_s: float
    environment: Mapping[str, Any]

    @property
    def site(self) -> GraphSite:
        return self.graph.sites[self.site_id]

    @property
    def neighbours(self) -> tuple[GraphSite, ...]:
        return tuple(
            self.graph.sites[other] for other in self.graph.neighbors(self.site_id)
        )

    def neighbour_count(self, state: str | SiteState | None = None) -> int:
        if state is None:
            return len(self.graph.neighbors(self.site_id))
        expected = _state_name(state)
        return sum(neighbour.state == expected for neighbour in self.neighbours)

    def neighbour_fraction(self, state: str | SiteState) -> float:
        count = self.neighbour_count()
        return 0.0 if count == 0 else self.neighbour_count(state) / count


RateCallable = Callable[[EventContext], float]
PredicateCallable = Callable[[EventContext], bool]
ActionCallable = Callable[[EventContext, np.random.Generator], Iterable[int] | None]


@dataclass(frozen=True)
class EventTemplate:
    """A local state transition and its propensity model.

    ``dependency_radius`` must cover every graph shell inspected by ``rate`` or
    ``enabled``.  A custom action must return every site whose state or
    attributes changed so the local propensity cache can be updated correctly.
    """

    name: str
    from_states: Sequence[str | SiteState] | str | SiteState
    to_state: str | SiteState | None
    rate: float | RateCallable
    enabled: PredicateCallable | None = None
    action: ActionCallable | None = None
    attribute_updates: Mapping[str, float] = field(default_factory=dict)
    dependency_radius: int = 1

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("event name must not be empty")
        states = self.from_states
        if isinstance(states, (str, Enum)):
            states = (states,)
        normalized_states = tuple(_state_name(state) for state in states)
        if not normalized_states:
            raise ValueError("from_states must not be empty")
        object.__setattr__(self, "from_states", normalized_states)
        if self.to_state is not None:
            object.__setattr__(self, "to_state", _state_name(self.to_state))
        if self.to_state is None and self.action is None:
            raise ValueError("an event requires to_state or a custom action")
        if not callable(self.rate):
            value = float(self.rate)
            if not math.isfinite(value) or value < 0.0:
                raise ValueError("event rate must be finite and nonnegative")
            object.__setattr__(self, "rate", value)
        if not isinstance(self.dependency_radius, int) or self.dependency_radius < 0:
            raise ValueError("dependency_radius must be a nonnegative integer")
        updates: dict[str, float] = {}
        for name, value in self.attribute_updates.items():
            number = float(value)
            if not math.isfinite(number):
                raise ValueError(f"attribute update {name!r} must be finite")
            updates[str(name)] = number
        object.__setattr__(self, "attribute_updates", updates)

    def is_enabled(self, context: EventContext) -> bool:
        if context.site.state not in self.from_states:
            return False
        return True if self.enabled is None else bool(self.enabled(context))

    def base_rate(self, context: EventContext) -> float:
        return float(self.rate(context) if callable(self.rate) else self.rate)

    def execute(
        self,
        context: EventContext,
        rng: np.random.Generator,
    ) -> tuple[int, ...]:
        changed: Iterable[int] | None
        if self.action is not None:
            changed = self.action(context, rng)
        else:
            context.site.state = str(self.to_state)
            changed = (context.site_id,)
        for name, value in self.attribute_updates.items():
            context.site.attributes[name] = value
        if changed is None:
            changed = (context.site_id,)
        changed_set = {int(site_id) for site_id in changed}
        if self.attribute_updates:
            changed_set.add(context.site_id)
        if not changed_set:
            changed_set.add(context.site_id)
        unknown = changed_set.difference(context.graph.sites)
        if unknown:
            raise KeyError(f"event reported unknown changed sites: {sorted(unknown)}")
        return tuple(sorted(changed_set))


SurrogateCallable = Callable[[EventContext], float | None]


@dataclass(frozen=True)
class ChemistryRateProvider:
    """Optional absolute-rate overrides from a table and/or surrogate.

    Lookup proceeds from most to least specific:
    ``(event, state, material)``, ``(event, material)``, ``(event, state)``,
    then ``event``.  A non-``None`` surrogate result takes precedence.  Missing
    entries fall back to the event template's own rate.
    """

    table: Mapping[Any, float] = field(default_factory=dict)
    surrogate: SurrogateCallable | None = None

    def __post_init__(self) -> None:
        copied: dict[Any, float] = {}
        for key, value in self.table.items():
            number = float(value)
            if not math.isfinite(number) or number < 0.0:
                raise ValueError(f"rate table value for {key!r} is invalid")
            copied[key] = number
        object.__setattr__(self, "table", copied)

    def lookup(self, context: EventContext) -> float | None:
        if self.surrogate is not None:
            predicted = self.surrogate(context)
            if predicted is not None:
                return float(predicted)
        site = context.site
        keys = (
            (context.event_name, site.state, site.material),
            (context.event_name, site.material),
            (context.event_name, site.state),
            context.event_name,
        )
        for key in keys:
            if key in self.table:
                return float(self.table[key])
        return None


class _FenwickTree:
    """Fenwick tree for O(log N) propensity updates and event selection."""

    def __init__(self, values: np.ndarray):
        self.values = np.asarray(values, dtype=float).copy()
        self.tree = np.zeros(len(self.values) + 1, dtype=float)
        self.positive_count = 0
        self.rebuild()

    def rebuild(self) -> None:
        """Rebuild accumulated sums from the authoritative slot values.

        Repeated positive-to-zero updates can leave a few ulps in the Fenwick
        sums even though every propensity slot is exactly zero.  ``values`` is
        therefore the source of truth; the positive-slot count also lets the
        caller distinguish exhaustion from a physically valid, extremely slow
        event without imposing an absolute rate cutoff.
        """

        self.tree.fill(0.0)
        self.positive_count = int(np.count_nonzero(self.values > 0.0))
        for index, value in enumerate(self.values):
            if value > 0.0:
                self._add(index, float(value))

    def _add(self, index: int, delta: float) -> None:
        tree_index = index + 1
        while tree_index < len(self.tree):
            self.tree[tree_index] += delta
            tree_index += tree_index & -tree_index

    @property
    def total(self) -> float:
        result = 0.0
        index = len(self.values)
        while index > 0:
            result += self.tree[index]
            index -= index & -index
        return float(result)

    def set(self, index: int, value: float) -> None:
        new_value = float(value)
        old_value = float(self.values[index])
        if old_value <= 0.0 < new_value:
            self.positive_count += 1
        elif old_value > 0.0 >= new_value:
            self.positive_count -= 1
        delta = new_value - old_value
        self.values[index] = new_value
        self._add(index, delta)

    def find_by_cumulative(self, target: float) -> int:
        total = self.total
        if not 0.0 <= target < total:
            raise ValueError("target must lie in [0, total propensity)")
        index = 0
        bit = 1 << (len(self.values).bit_length() - 1)
        remaining = float(target)
        while bit:
            candidate = index + bit
            if candidate <= len(self.values) and self.tree[candidate] <= remaining:
                remaining -= self.tree[candidate]
                index = candidate
            bit >>= 1
        return min(index, len(self.values) - 1)


@dataclass(frozen=True)
class EventRecord:
    event_number: int
    time_s: float
    waiting_time_s: float
    event_name: str
    site_id: int
    old_state: str
    new_state: str
    selected_rate_s: float
    total_rate_s: float
    changed_sites: tuple[int, ...]


@dataclass(frozen=True)
class KMCResult:
    elapsed_s: float
    final_time_s: float
    event_count: int
    stop_reason: str
    event_log: tuple[EventRecord, ...]
    event_counts: Mapping[str, int]
    event_flux_s: Mapping[str, float]
    final_state_counts: Mapping[str, int]
    final_total_rate_s: float
    rate_evaluations: int


class GraphKMC:
    """Direct SSA/BKL engine with cached local propensities."""

    def __init__(
        self,
        graph: AmorphousGraph,
        event_templates: Sequence[EventTemplate],
        *,
        seed: int | None = None,
        rate_provider: ChemistryRateProvider | Mapping[Any, float] | None = None,
        environment: Mapping[str, Any] | None = None,
        copy_graph: bool = True,
    ) -> None:
        if not event_templates:
            raise ValueError("at least one event template is required")
        self.graph = graph.copy() if copy_graph else graph
        self.event_templates = tuple(event_templates)
        self.environment: dict[str, Any] = dict(environment or {})
        if rate_provider is None:
            self.rate_provider = ChemistryRateProvider()
        elif isinstance(rate_provider, ChemistryRateProvider):
            self.rate_provider = rate_provider
        else:
            self.rate_provider = ChemistryRateProvider(table=rate_provider)
        self.rng = np.random.default_rng(seed)
        self.time_s = 0.0
        self.event_log: list[EventRecord] = []
        self.rate_evaluations = 0
        self._site_ids = self.graph.site_ids
        self._slot_keys = tuple(
            (template_index, site_id)
            for template_index in range(len(self.event_templates))
            for site_id in self._site_ids
        )
        self._slot_by_key = {
            key: index for index, key in enumerate(self._slot_keys)
        }
        rates = np.asarray(
            [self._evaluate_slot(*key) for key in self._slot_keys], dtype=float
        )
        self._propensities = _FenwickTree(rates)
        self._maximum_dependency_radius = max(
            template.dependency_radius for template in self.event_templates
        )

    @property
    def total_rate_s(self) -> float:
        if self._propensities.positive_count == 0:
            return 0.0
        total = self._propensities.total
        if not math.isfinite(total) or total <= 0.0:
            # The slots are known to contain a positive rate, so a non-positive
            # accumulated sum is numerical drift rather than event exhaustion.
            self._propensities.rebuild()
            total = self._propensities.total
        if not math.isfinite(total) or total <= 0.0:
            raise RuntimeError("positive propensity slots have an invalid total")
        return total

    def _context(self, template: EventTemplate, site_id: int) -> EventContext:
        return EventContext(
            graph=self.graph,
            site_id=site_id,
            event_name=template.name,
            time_s=self.time_s,
            environment=self.environment,
        )

    def _evaluate_slot(self, template_index: int, site_id: int) -> float:
        self.rate_evaluations += 1
        template = self.event_templates[template_index]
        context = self._context(template, site_id)
        if not template.is_enabled(context):
            return 0.0
        override = self.rate_provider.lookup(context)
        value = template.base_rate(context) if override is None else override
        value = float(value)
        if not math.isfinite(value) or value < 0.0:
            raise ValueError(
                f"event {template.name!r} produced invalid rate {value} at site {site_id}"
            )
        return value

    def _dependency_neighbourhood(self, changed_sites: Iterable[int]) -> set[int]:
        visited = {int(site_id) for site_id in changed_sites}
        frontier = set(visited)
        for _ in range(self._maximum_dependency_radius):
            following: set[int] = set()
            for site_id in frontier:
                following.update(self.graph.neighbors(site_id))
            following.difference_update(visited)
            if not following:
                break
            visited.update(following)
            frontier = following
        return visited

    def refresh_sites(self, site_ids: Iterable[int], *, expand: bool = False) -> None:
        sites = {int(site_id) for site_id in site_ids}
        unknown = sites.difference(self.graph.sites)
        if unknown:
            raise KeyError(f"unknown sites: {sorted(unknown)}")
        if expand:
            sites = self._dependency_neighbourhood(sites)
        for template_index in range(len(self.event_templates)):
            for site_id in sorted(sites):
                slot = self._slot_by_key[(template_index, site_id)]
                self._propensities.set(
                    slot, self._evaluate_slot(template_index, site_id)
                )

    def refresh_all(self) -> None:
        self.refresh_sites(self._site_ids)

    def set_environment(
        self,
        updates: Mapping[str, Any],
        *,
        affected_sites: Iterable[int] | None = None,
    ) -> None:
        """Update chemistry fields, then refresh global or declared local rates."""

        self.environment.update(updates)
        if affected_sites is None:
            self.refresh_all()
        else:
            self.refresh_sites(affected_sites, expand=True)

    def step(self, *, horizon_time_s: float | None = None) -> EventRecord | None:
        """Draw and execute one exact SSA event, or return ``None`` at a horizon."""

        total = self.total_rate_s
        if total <= 0.0:
            return None
        uniform_wait = max(float(self.rng.random()), np.finfo(float).tiny)
        waiting_time = -math.log(uniform_wait) / total
        if horizon_time_s is not None:
            horizon = float(horizon_time_s)
            if horizon < self.time_s:
                raise ValueError("horizon_time_s cannot precede current KMC time")
            if self.time_s + waiting_time > horizon:
                self.time_s = horizon
                return None
        selection_fraction = float(self.rng.random())
        threshold = selection_fraction * total
        slot = self._propensities.find_by_cumulative(threshold)
        template_index, site_id = self._slot_keys[slot]
        template = self.event_templates[template_index]
        selected_rate = float(self._propensities.values[slot])
        if selected_rate <= 0.0:
            # A stale ulp in a cumulative branch can place the selector in a
            # zero-rate slot.  Rebuild once, retain the same uniform quantile,
            # and fall back to an exact linear cumulative scan if necessary.
            self._propensities.rebuild()
            total = self.total_rate_s
            if total <= 0.0:
                return None
            threshold = min(
                selection_fraction * total,
                float(np.nextafter(total, 0.0)),
            )
            slot = self._propensities.find_by_cumulative(threshold)
            selected_rate = float(self._propensities.values[slot])
            if selected_rate <= 0.0:
                cumulative = np.cumsum(self._propensities.values, dtype=float)
                slot = int(np.searchsorted(cumulative, threshold, side="right"))
                if slot >= len(self._slot_keys) or self._propensities.values[slot] <= 0.0:
                    positive = np.flatnonzero(self._propensities.values > 0.0)
                    if positive.size == 0:
                        return None
                    slot = int(positive[-1])
                selected_rate = float(self._propensities.values[slot])
            template_index, site_id = self._slot_keys[slot]
            template = self.event_templates[template_index]
        self.time_s += waiting_time
        context = self._context(template, site_id)
        old_state = context.site.state
        changed_sites = template.execute(context, self.rng)
        new_state = self.graph.sites[site_id].state
        record = EventRecord(
            event_number=len(self.event_log) + 1,
            time_s=self.time_s,
            waiting_time_s=waiting_time,
            event_name=template.name,
            site_id=site_id,
            old_state=old_state,
            new_state=new_state,
            selected_rate_s=selected_rate,
            total_rate_s=total,
            changed_sites=changed_sites,
        )
        self.event_log.append(record)
        self.refresh_sites(changed_sites, expand=True)
        return record

    def run(
        self,
        *,
        max_events: int | None = None,
        max_time_s: float | None = None,
        stop_condition: Callable[["GraphKMC"], bool] | None = None,
    ) -> KMCResult:
        """Run until an event/time limit, a callback, or exhaustion of events.

        ``max_time_s`` is a duration measured from the beginning of this call,
        not an absolute time.  Propensities should be time-homogeneous between
        events; after externally changing a field, call :meth:`set_environment`.
        """

        if max_events is None and max_time_s is None and stop_condition is None:
            raise ValueError("run requires a finite limit or stop_condition")
        if max_events is not None and (not isinstance(max_events, int) or max_events < 0):
            raise ValueError("max_events must be a nonnegative integer")
        if max_time_s is not None:
            max_time_s = float(max_time_s)
            if not math.isfinite(max_time_s) or max_time_s < 0.0:
                raise ValueError("max_time_s must be finite and nonnegative")

        start_time = self.time_s
        start_log = len(self.event_log)
        start_evaluations = self.rate_evaluations
        horizon = math.inf if max_time_s is None else start_time + max_time_s
        stop_reason = "unknown"
        while True:
            generated = len(self.event_log) - start_log
            if stop_condition is not None and stop_condition(self):
                stop_reason = "stop_condition"
                break
            if max_events is not None and generated >= max_events:
                stop_reason = "max_events"
                break
            if self.time_s >= horizon:
                stop_reason = "max_time"
                break
            if self.total_rate_s <= 0.0:
                stop_reason = "no_events"
                break
            record = self.step(
                horizon_time_s=None if math.isinf(horizon) else horizon
            )
            if record is None:
                stop_reason = "max_time" if self.time_s >= horizon else "no_events"
                break

        records = tuple(self.event_log[start_log:])
        counts = Counter(record.event_name for record in records)
        elapsed = self.time_s - start_time
        flux = {
            name: (count / elapsed if elapsed > 0.0 else 0.0)
            for name, count in counts.items()
        }
        return KMCResult(
            elapsed_s=elapsed,
            final_time_s=self.time_s,
            event_count=len(records),
            stop_reason=stop_reason,
            event_log=records,
            event_counts=dict(counts),
            event_flux_s=flux,
            final_state_counts=self.graph.state_counts(),
            final_total_rate_s=self.total_rate_s,
            rate_evaluations=self.rate_evaluations - start_evaluations,
        )


__all__ = [
    "AmorphousGraph",
    "ChemistryRateProvider",
    "EventContext",
    "EventRecord",
    "EventTemplate",
    "GraphKMC",
    "GraphSite",
    "KMCResult",
    "SiteState",
]

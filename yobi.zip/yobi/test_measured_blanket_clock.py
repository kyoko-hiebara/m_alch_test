from __future__ import annotations

import json
from pathlib import Path
import tempfile
import unittest

from measured_blanket_clock import (
    BlanketEtchPoint,
    BlanketEtchTimeSeries,
    analyze_blanket_time_series,
    load_blanket_time_series_csv,
    piecewise_cumulative_etch_nm,
    piecewise_time_at_etch_amount_s,
    run_measured_bottom_pad_screen,
)
from run_sin_blanket_recalibration import main as run_recalibration


INPUT_PATH = Path("inputs/sin_blanket_user_20260728.csv")


class MeasuredBlanketClockTests(unittest.TestCase):
    def series(self) -> BlanketEtchTimeSeries:
        return load_blanket_time_series_csv(INPUT_PATH)

    def test_supplied_points_and_interval_rates_are_exact(self) -> None:
        series = self.series()
        self.assertEqual(
            [point.etch_amount_nm for point in series.points],
            [0.0, 0.6418, 1.1212, 1.4277],
        )
        analysis = analyze_blanket_time_series(series)
        rates = [
            row["interval_rate_nm_min"]
            for row in analysis["interval_rates"]
        ]
        self.assertAlmostEqual(rates[0], 0.6418)
        self.assertAlmostEqual(rates[1], 0.4794)
        self.assertAlmostEqual(rates[2], 0.3065)
        self.assertFalse(analysis["constant_rate_validated"])

    def test_linear_fits_are_comparison_only(self) -> None:
        analysis = analyze_blanket_time_series(self.series())
        origin = analysis["origin_constrained_linear_fit"]
        free = analysis["unconstrained_linear_fit"]
        self.assertAlmostEqual(origin["slope_nm_min"], 0.51195)
        self.assertAlmostEqual(origin["centered_r_squared"], 0.9672816102552272)
        self.assertAlmostEqual(free["slope_nm_min"], 0.47625)
        self.assertAlmostEqual(free["intercept_nm"], 0.0833)
        self.assertFalse(free["used_as_calibration_clock"])

    def test_piecewise_interpolation_and_clear_time(self) -> None:
        series = self.series()
        etch_30, status = piecewise_cumulative_etch_nm(series, 30.0)
        self.assertEqual(status, "piecewise_interpolated")
        self.assertAlmostEqual(etch_30, 0.3209)
        self.assertAlmostEqual(
            piecewise_time_at_etch_amount_s(series, 0.5),
            46.74353381115613,
        )
        self.assertAlmostEqual(
            piecewise_time_at_etch_amount_s(series, 1.0),
            104.83103879849813,
        )
        self.assertIsNone(
            piecewise_time_at_etch_amount_s(series, 2.0)
        )
        beyond, beyond_status = piecewise_cumulative_etch_nm(
            series, 181.0
        )
        self.assertIsNone(beyond)
        self.assertEqual(beyond_status, "outside_measured_window")

    def test_bottom_pad_screen_preserves_censoring_and_comparisons(
        self,
    ) -> None:
        payload = run_measured_bottom_pad_screen(self.series())
        one_nm = next(
            case
            for case in payload["cases"]
            if case["geometry_id"] == "10_10_180"
            and case["initial_bottom_pad_thickness_nm"] == 1.0
            and case["bottom_local_rate_factor"] == 1.0
        )
        checkpoint_30 = next(
            point
            for point in one_nm["checkpoints"]
            if point["exposure_time_s"] == 30.0
        )
        self.assertAlmostEqual(
            checkpoint_30["empirical_piecewise"][
                "remaining_thickness_nm"
            ],
            0.6791,
        )
        self.assertAlmostEqual(
            checkpoint_30["literature_linear_comparison"][
                "remaining_thickness_nm"
            ],
            0.96,
        )
        two_nm = next(
            case
            for case in payload["cases"]
            if case["geometry_id"] == "10_10_180"
            and case["initial_bottom_pad_thickness_nm"] == 2.0
            and case["bottom_local_rate_factor"] == 1.0
        )
        self.assertIsNone(two_nm["empirical_clear_time_s"])
        self.assertEqual(
            two_nm["empirical_clear_time_status"],
            "right_censored_at_measured_window",
        )
        self.assertEqual(two_nm["empirical_right_censor_time_s"], 180.0)
        json.dumps(payload, ensure_ascii=False, allow_nan=False)

    def test_invalid_nonmonotonic_series_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            BlanketEtchTimeSeries(
                calibration_id="bad",
                material="SiN",
                condition_note="test",
                points=(
                    BlanketEtchPoint(0.0, 0.0, "assumed_origin", "test"),
                    BlanketEtchPoint(60.0, 1.0, "user_measurement", "test"),
                    BlanketEtchPoint(120.0, 0.9, "user_measurement", "test"),
                ),
            )

    def test_cli_writes_strict_outputs_and_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            payload = run_recalibration(
                [
                    "--input-csv",
                    str(INPUT_PATH),
                    "--output-dir",
                    str(output),
                    "--no-figure",
                ]
            )
            saved = json.loads(
                (output / "sin_blanket_recalibration.json").read_text()
            )
            self.assertEqual(
                saved["schema_version"], payload["schema_version"]
            )
            manifest = json.loads(
                (output / "manifest_sha256.json").read_text()
            )
            self.assertIn("sin_blanket_recalibration.json", manifest["files"])
            self.assertIn(str(INPUT_PATH), manifest["inputs"])


if __name__ == "__main__":
    unittest.main()

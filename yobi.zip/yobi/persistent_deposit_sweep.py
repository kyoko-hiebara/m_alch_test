"""Literature-anchored persistent-deposit sensitivity sweep.

The primary HF calculation removes the original fully GAP-FILLED SiN/SiCN/SiOCN
with the existing two-dimensional reaction--diffusion/front model.  A wet
supersaturation route is coupled during that calculation.  Drain/dry-down is
then an explicit event, followed by branched rinse/second-WET operations.

Only the AFS-like solubility and molar density used for the SiN branch are
literature properties.  Capture fractions, attachment velocity, surface
affinity and post-dry dissolution doses are deliberately labelled as
uncalibrated sensitivity parameters.  The SiOCN deposit is a generic proxy.
"""

from __future__ import annotations

import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from typing import Mapping

import numpy as np

from etch_process import EtchProcessConfig, ThermalBoundaryConditions
from gapfill_etch_2d import GapFillEtch2D, PassivationParameters, TransportParameters
from literature_parameters import (
    HF_DIFFUSIVITY_298_NM2_S,
    LITERATURE_ETCH_PRESETS,
    LiteratureEtchPreset,
    get_literature_preset,
)
from literature_sweep import nominal_preset_names
from numerical_settings import LOOSE_NUMERICS, NumericalSettings
from persistent_deposit import DepositParameters, PersistentDepositPhase2D
from product_passivation_sweep import CoupledLiteratureInterfaceLaw
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS, get_geometry_preset


AFS_MOLAR_VOLUME_M3_MOL = 8.908e-5
AFS_MOLAR_DENSITY_MOL_M3 = 1.0 / AFS_MOLAR_VOLUME_M3_MOL
AFS_MOLAR_MASS_KG_MOL = 0.17815
AFS_WATER_SOLUBILITY_MOL_M3 = 1_190.0
LIU_IMMEDIATE_DI_RINSE_S = 30.0

PERSISTENT_DEPOSIT_NOTICE = (
    "Mechanism sensitivity calculation, not a wet-process recipe. The SiN "
    "AFS-like solubility/density and blanket etch inputs retain literature "
    "provenance. Meniscus capture, wall affinity, attachment kinetics and "
    "post-dry dissolution rates are uncalibrated hypotheses. The SiOCN "
    "deposit species is not identified and uses the AFS properties only as a "
    "transparent numerical proxy."
)

SIOCN_N_TO_SI_BY_PRESET: Mapping[str, float] = {
    "siocn_fujitsu_4a_100to1": 32.9 / 35.0,
    "siocn_fujitsu_4b_100to1": 30.6 / 34.1,
    "siocn_fujitsu_4d_100to1": 23.4 / 32.6,
}


@dataclass(frozen=True)
class PersistentDepositSweepConfig:
    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    presets: tuple[str, ...] = nominal_preset_names()
    grid_spacing_nm: float = 1.0
    reservoir_height_nm: float = 10.0
    product_diffusivity_over_hf: float = 0.1
    maximum_fractional_front_change: float = 0.50
    target_remaining_gap_fill_fraction: float = 1.0e-3
    maximum_time_over_planar_clear: float = 1.20
    requested_steps_per_planar_clear: int = 50
    wet_attachment_damkohler: float = 10.0
    cumulative_capture_fractions: tuple[float, ...] = (0.001, 0.01, 0.10)
    wall_selective_affinity_ratio: float = 5.0
    solution_bulk_temperature_K: float = 298.15
    substrate_backside_temperature_K: float = 298.15
    allow_partial_primary_for_sensitivity: bool = False
    parallel_workers: int = 1

    def __post_init__(self) -> None:
        if not self.geometries or not self.presets:
            raise ValueError("geometry and preset selections cannot be empty")
        unknown_geometries = set(self.geometries).difference(GEOMETRY_PRESETS)
        unknown_presets = set(self.presets).difference(LITERATURE_ETCH_PRESETS)
        if unknown_geometries:
            raise ValueError(f"unknown geometries: {sorted(unknown_geometries)}")
        if unknown_presets:
            raise ValueError(f"unknown presets: {sorted(unknown_presets)}")
        positive_names = (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "product_diffusivity_over_hf",
            "maximum_fractional_front_change",
            "target_remaining_gap_fill_fraction",
            "maximum_time_over_planar_clear",
            "wet_attachment_damkohler",
            "wall_selective_affinity_ratio",
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
        )
        for name in positive_names:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.maximum_fractional_front_change > 1.0:
            raise ValueError("maximum fractional front change cannot exceed one")
        if self.target_remaining_gap_fill_fraction >= 1.0:
            raise ValueError("target remaining fraction must be below one")
        if not isinstance(self.requested_steps_per_planar_clear, int) or (
            self.requested_steps_per_planar_clear < 1
        ):
            raise ValueError("requested_steps_per_planar_clear must be positive")
        fractions = tuple(float(value) for value in self.cumulative_capture_fractions)
        if not fractions or any(
            not math.isfinite(value) or not 0.0 < value <= 1.0
            for value in fractions
        ):
            raise ValueError("cumulative capture fractions must lie within (0, 1]")
        object.__setattr__(self, "cumulative_capture_fractions", tuple(sorted(set(fractions))))
        if not isinstance(self.parallel_workers, int) or self.parallel_workers < 1:
            raise ValueError("parallel_workers must be a positive integer")
        if not isinstance(self.allow_partial_primary_for_sensitivity, bool):
            raise ValueError("allow_partial_primary_for_sensitivity must be boolean")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for name in ("geometries", "presets", "cumulative_capture_fractions"):
            result[name] = list(getattr(self, name))
        return result


def afs_solubility_from_hf_mol_m3(hf_analytical_mol_m3: float) -> float:
    """Return the Frayret quadratic fit, with an explicit low-HF caveat.

    The paper measured pure water and >=5 M HF.  Evaluating the fit at the
    present ~0.28 M analytical HF is therefore a model interpolation between
    the water point and the first HF measurement, not a direct datum.
    """
    hf_molar = float(hf_analytical_mol_m3) / 1_000.0
    if not math.isfinite(hf_molar) or hf_molar < 0.0:
        raise ValueError("analytical HF concentration must be non-negative")
    return 1_000.0 * (
        0.0017 * hf_molar**2 - 0.0578 * hf_molar + 1.19
    )


def _deposit_yield(preset: LiteratureEtchPreset) -> tuple[float, str]:
    if preset.material == "SiN":
        return (
            2.0 / 3.0,
            "Si3N4 nitrogen-balance upper bound; not a measured deposit yield",
        )
    n_to_si = SIOCN_N_TO_SI_BY_PRESET.get(preset.key, 1.0)
    return (
        0.5 * n_to_si,
        "N/(2 Si) upper-bound proxy from disclosed XPS; deposit species unverified",
    )


def _deposit_parameters(
    preset: LiteratureEtchPreset,
    config: PersistentDepositSweepConfig,
    clear_time_s: float,
    *,
    wall_affinity: float,
) -> tuple[DepositParameters, dict[str, object]]:
    speciation = preset.hf_speciation()
    csat = afs_solubility_from_hf_mol_m3(
        speciation.analytical_fluorine_mol_m3
    )
    yield_value, yield_basis = _deposit_yield(preset)
    species = (
        "AFS_like_(NH4)2SiF6"
        if preset.material == "SiN"
        else f"generic_{preset.material}_deposit"
    )
    # For a one-cell-thick collector, this gives lambda*t_clear of roughly the
    # requested Damkohler number. Exact lambda also contains local face length.
    attachment_velocity = (
        config.wet_attachment_damkohler
        * config.grid_spacing_nm
        / clear_time_s
    )
    parameters = DepositParameters(
        species_name=species,
        saturation_concentration_mol_m3=csat,
        attachment_velocity_nm_s=attachment_velocity,
        wall_affinity=wall_affinity,
        bottom_affinity=1.0,
        deposit_molar_density_mol_m3=AFS_MOLAR_DENSITY_MOL_M3,
        deposit_molar_mass_kg_mol=(
            AFS_MOLAR_MASS_KG_MOL if preset.material == "SiN" else None
        ),
        precipitation_yield_mol_deposit_per_mol_product=yield_value,
        active_set_relative_tolerance=1.0e-3,
        maximum_active_set_iterations=8,
        subgrid_warning_thickness_over_cell=0.5,
    )
    provenance = {
        "species_interpretation": species,
        "saturation_concentration_mol_m3": csat,
        "saturation_basis": (
            "Frayret AFS fit evaluated at analytical HF"
            if preset.material == "SiN"
            else "AFS numerical proxy; no SiOCN/dHF precipitate datum"
        ),
        "analytical_hf_mol_m3": speciation.analytical_fluorine_mol_m3,
        "molar_density_mol_m3": AFS_MOLAR_DENSITY_MOL_M3,
        "deposit_molar_mass_kg_mol": (
            AFS_MOLAR_MASS_KG_MOL if preset.material == "SiN" else None
        ),
        "density_basis": (
            "AFS crystallographic molar volume"
            if preset.material == "SiN"
            else "AFS numerical proxy; generic SiOCN deposit density unknown"
        ),
        "precipitation_yield": yield_value,
        "yield_basis": yield_basis,
        "wet_attachment_velocity_nm_s": attachment_velocity,
        "wet_attachment_basis": "uncalibrated Damkohler sensitivity",
        "wall_affinity": wall_affinity,
        "bottom_affinity": 1.0,
        "affinity_basis": "uncalibrated surface-allocation sensitivity",
    }
    return parameters, provenance


def _numerics(config: PersistentDepositSweepConfig) -> NumericalSettings:
    return NumericalSettings(
        linear_relative_tolerance=LOOSE_NUMERICS.linear_relative_tolerance,
        linear_absolute_tolerance=LOOSE_NUMERICS.linear_absolute_tolerance,
        nonlinear_relative_tolerance=LOOSE_NUMERICS.nonlinear_relative_tolerance,
        steady_state_relative_tolerance=LOOSE_NUMERICS.steady_state_relative_tolerance,
        mass_balance_relative_tolerance=LOOSE_NUMERICS.mass_balance_relative_tolerance,
        maximum_iterations=LOOSE_NUMERICS.maximum_iterations,
        maximum_nonlinear_iterations=LOOSE_NUMERICS.maximum_nonlinear_iterations,
        maximum_fractional_state_change=config.maximum_fractional_front_change,
        minimum_time_step_s=LOOSE_NUMERICS.minimum_time_step_s,
        maximum_time_step_s=LOOSE_NUMERICS.maximum_time_step_s,
    )


def _build_primary_model(
    geometry_name: str,
    preset: LiteratureEtchPreset,
    config: PersistentDepositSweepConfig,
) -> tuple[GapFillEtch2D, float, dict[str, object]]:
    geometry = get_geometry_preset(geometry_name)
    clear_time = geometry.depth_nm / preset.planar_rate_nm_s
    deposit_parameters, provenance = _deposit_parameters(
        preset, config, clear_time, wall_affinity=1.0
    )
    hf_bulk = preset.hf_speciation().neutral_hf_mol_m3
    law = CoupledLiteratureInterfaceLaw(
        reference_velocity_nm_s=preset.planar_rate_nm_s,
        reference_hf_mol_m3=hf_bulk,
    )
    process = EtchProcessConfig(
        geometry=geometry,
        gap_fill_material=preset.material,
        thermal_bc=ThermalBoundaryConditions(
            solution_bulk_temperature_K=config.solution_bulk_temperature_K,
            substrate_backside_temperature_K=config.substrate_backside_temperature_K,
        ),
    )
    model = GapFillEtch2D(
        process,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=max(2.0, config.grid_spacing_nm),
        transport=TransportParameters(
            reactant_diffusivity_nm2_s=HF_DIFFUSIVITY_298_NM2_S,
            product_diffusivity_nm2_s=(
                config.product_diffusivity_over_hf * HF_DIFFUSIVITY_298_NM2_S
            ),
            reactant_bulk_concentration=hf_bulk,
            reactant_surface_transfer_nm_s=preset.first_order_surface_transfer_nm_s(),
            product_bulk_concentration=0.0,
            product_yield_concentration=preset.solid_si_site_density_mol_m3,
            product_bulk_decay_per_s=0.0,
        ),
        passivation=PassivationParameters(),
        rate_law=law,
        reactant_sink_modifier_law=law.reactivity_modifier,
        deposit_parameters=deposit_parameters,
        numerical_settings=_numerics(config),
        solid_density_g_cm3=preset.solid_density_g_cm3,
    )
    return model, clear_time, provenance


def _clone_phase_with_parameters(
    source: PersistentDepositPhase2D,
    parameters: DepositParameters,
) -> PersistentDepositPhase2D:
    phase = PersistentDepositPhase2D(source.grid, parameters)
    phase.wall_inventory_native[:] = source.wall_inventory_native
    phase.bottom_inventory_native[:] = source.bottom_inventory_native
    return phase


def _post_treatments() -> dict[str, dict[str, float | str]]:
    duration = 30.0
    return {
        "no_post_wet": {
            "description": "dry endpoint; no deposit dissolution",
            "duration_s": 0.0,
            "wall_rate_s": 0.0,
            "bottom_rate_s": 0.0,
            "basis": "control",
        },
        "DI_30s_after_dry": {
            "description": "first-order 95% removal convention after drying",
            "duration_s": duration,
            "wall_rate_s": math.log(20.0) / duration,
            "bottom_rate_s": math.log(20.0) / duration,
            "basis": "uncalibrated; Liu supports immediate pre-dry rinse, not this rate",
        },
        "second_WET_30s": {
            "description": "strong deposit-targeted second WET, Xi=5",
            "duration_s": duration,
            "wall_rate_s": 5.0 / duration,
            "bottom_rate_s": 5.0 / duration,
            "basis": "uncalibrated mechanism target",
        },
        "HF_control_30s": {
            "description": "matched-duration weak deposit removal, Xi=0.1",
            "duration_s": duration,
            "wall_rate_s": 0.1 / duration,
            "bottom_rate_s": 0.1 / duration,
            "basis": "uncalibrated matched-duration control",
        },
    }


def _collector_map(phase: PersistentDepositPhase2D) -> dict[str, object]:
    wall = phase.wall_thickness_nm
    bottom = phase.bottom_thickness_nm
    collector = (phase.wall_contact_length_nm + phase.bottom_contact_length_nm) > 0.0
    rows, columns = np.nonzero(collector)
    return {
        "x_nm": [float(value) for value in phase.grid.lateral_mesh_nm[rows, columns]],
        "depth_nm": [float(value) for value in phase.grid.depth_mesh_nm[rows, columns]],
        "wall_thickness_nm": [float(value) for value in wall[rows, columns]],
        "bottom_thickness_nm": [float(value) for value in bottom[rows, columns]],
    }


def _formation_scenarios(config: PersistentDepositSweepConfig) -> list[dict[str, object]]:
    result: list[dict[str, object]] = [
        {
            "key": "immediate_DI_before_dry",
            "solute_retention_fraction": 0.0,
            "cumulative_capture_fraction": 0.0,
            "pre_dry_DI_s": LIU_IMMEDIATE_DI_RINSE_S,
            "interpretation": "rinse removes drain solute before any dry-down",
        },
        {
            "key": "endpoint_solution_dry",
            "solute_retention_fraction": 1.0,
            "cumulative_capture_fraction": 0.0,
            "pre_dry_DI_s": 0.0,
            "interpretation": (
                "last-reactive-step quasi-steady field proxy; not a transient "
                "drain inventory"
            ),
        },
    ]
    for fraction in config.cumulative_capture_fractions:
        label = f"meniscus_capture_{fraction:.4g}".replace(".", "p")
        result.append(
            {
                "key": label,
                "solute_retention_fraction": 0.0,
                "cumulative_capture_fraction": fraction,
                "pre_dry_DI_s": 0.0,
                "interpretation": (
                    "total captured fraction of cumulative generated product; "
                    "exclusive of the endpoint-field proxy"
                ),
            }
        )
    return result


def run_persistent_deposit_case(
    geometry_name: str,
    preset_name: str,
    config: PersistentDepositSweepConfig,
) -> dict[str, object]:
    preset = get_literature_preset(preset_name)
    model, clear_time, primary_provenance = _build_primary_model(
        geometry_name, preset, config
    )
    maximum_time = config.maximum_time_over_planar_clear * clear_time
    requested_dt = clear_time / config.requested_steps_per_planar_clear
    history = []
    maximum_product = 0.0
    maximum_saturation_ratio = 0.0
    maximum_steps = 50_000
    saturation = model.deposit_phase.parameters.saturation_concentration_mol_m3
    while (
        model.front.time_s < maximum_time
        and model.front.diagnostics().remaining_mass_fraction
        > config.target_remaining_gap_fill_fraction
        and np.any(model.front.solid_mask)
        and len(history) < maximum_steps
    ):
        entry = model.step(min(requested_dt, maximum_time - model.front.time_s))
        history.append(entry)
        maximum_product = max(maximum_product, entry.maximum_product)
        maximum_saturation_ratio = max(
            maximum_saturation_ratio, entry.maximum_product / saturation
        )

    final = model.front.diagnostics()
    primary_target_reached = (
        final.remaining_mass_fraction
        <= config.target_remaining_gap_fill_fraction
    )
    if (
        not primary_target_reached
        and not config.allow_partial_primary_for_sensitivity
    ):
        raise RuntimeError(
            f"primary HF target was not reached for {geometry_name}/{preset_name}: "
            f"remaining={final.remaining_mass_fraction:.6g}, "
            f"target={config.target_remaining_gap_fill_fraction:.6g}"
        )
    endpoint_liquid = model.front.liquid_mask & model.grid.cavity_mask
    endpoint_product_inventory = float(
        np.sum(model.product_field[endpoint_liquid]) * model.grid.cell_area_nm2
    )
    expected_generated_from_removed_solid = (
        preset.solid_si_site_density_mol_m3 * final.dissolved_area_nm2
    )
    generation_closure_ratio = (
        model.cumulative_product_generation_inventory_native
        / expected_generated_from_removed_solid
        if expected_generated_from_removed_solid > 0.0
        else 1.0
    )
    integrated_product_residual = (
        model.cumulative_product_generation_inventory_native
        - model.cumulative_product_top_outflow_inventory_native
        - model.cumulative_product_bulk_decay_inventory_native
        - model.cumulative_product_precipitation_inventory_native
    )
    post_treatments = _post_treatments()
    branches: list[dict[str, object]] = []
    representative_map: dict[str, object] | None = None
    representative_capture_distance = math.inf
    affinity_cases = (
        ("uniform_affinity", 1.0),
        ("wall_selective", config.wall_selective_affinity_ratio),
    )
    for affinity_key, wall_affinity in affinity_cases:
        branch_parameters, branch_provenance = _deposit_parameters(
            preset, config, clear_time, wall_affinity=wall_affinity
        )
        for formation_definition in _formation_scenarios(config):
            phase = _clone_phase_with_parameters(
                model.deposit_phase, branch_parameters
            )
            pre_rinse = None
            pre_dry_duration = float(formation_definition["pre_dry_DI_s"])
            if pre_dry_duration > 0.0:
                pre_rinse = phase.dissolve(
                    pre_dry_duration,
                    wall_rate_s=math.log(20.0) / pre_dry_duration,
                    bottom_rate_s=math.log(20.0) / pre_dry_duration,
                )
            capture_fraction = float(
                formation_definition["cumulative_capture_fraction"]
            )
            drydown = phase.precipitate_during_drydown(
                model.product_field,
                model.front.liquid_mask,
                solute_retention_fraction=float(
                    formation_definition["solute_retention_fraction"]
                ),
                liquid_retention_fraction=0.0,
                additional_trapped_inventory_native=(
                    capture_fraction
                    * model.cumulative_product_generation_inventory_native
                ),
            )
            before_post = phase.diagnostics()
            endpoints: dict[str, object] = {}
            for treatment_key, treatment in post_treatments.items():
                treated = phase.copy()
                dissolution = treated.dissolve(
                    float(treatment["duration_s"]),
                    wall_rate_s=float(treatment["wall_rate_s"]),
                    bottom_rate_s=float(treatment["bottom_rate_s"]),
                )
                endpoints[treatment_key] = {
                    "operation": treatment,
                    "dissolution": dissolution.to_dict(),
                    "final_deposit": treated.diagnostics().to_dict(),
                }
            branch = {
                "branch_id": (
                    f"{affinity_key}__{formation_definition['key']}"
                ),
                "affinity_case": affinity_key,
                "formation_scenario": formation_definition,
                "parameter_provenance": branch_provenance,
                "pre_dry_rinse": pre_rinse.to_dict() if pre_rinse else None,
                "drydown_formation": drydown.to_dict(),
                "before_post_wet": before_post.to_dict(),
                "post_treatment_endpoints": endpoints,
            }
            branches.append(branch)
            capture_distance = abs(capture_fraction - 0.01)
            if (
                affinity_key == "wall_selective"
                and capture_fraction > 0.0
                and capture_distance < representative_capture_distance
            ):
                representative_map = {
                    "branch_id": branch["branch_id"],
                    "cumulative_capture_fraction": capture_fraction,
                    "deposit": _collector_map(phase),
                }
                representative_capture_distance = capture_distance

    wet_diagnostics = model.deposit_phase.diagnostics()
    return {
        "case_id": f"{geometry_name}__{preset_name}",
        "geometry": model.grid.geometry.to_dict(),
        "preset_key": preset.key,
        "material": preset.material,
        "planar_rate_nm_min": preset.planar_rate_nm_min,
        "planar_clear_time_s": clear_time,
        "boundary_temperatures_K": {
            "solution_bulk": config.solution_bulk_temperature_K,
            "substrate_backside": config.substrate_backside_temperature_K,
            "mode": "independent boundary metadata only",
            "kinetic_temperature_correction_applied": False,
        },
        "grid": {
            "shape": list(model.grid.shape),
            "dx_nm": model.grid.dx_nm,
            "dz_nm": model.grid.dz_nm,
            "initial_area_discretization_relative_error": (
                final.initial_area_discretization_relative_error
            ),
        },
        "primary_HF": {
            "steps": len(history),
            "time_s": final.time_s,
            "time_over_planar_clear": final.time_s / clear_time,
            "remaining_gap_fill_fraction": final.remaining_mass_fraction,
            "target_reached": primary_target_reached,
            "partial_primary_sensitivity_was_allowed": (
                not primary_target_reached
                and config.allow_partial_primary_for_sensitivity
            ),
            "maximum_product_mol_m3": maximum_product,
            "AFS_proxy_saturation_mol_m3": saturation,
            "maximum_saturation_ratio": maximum_saturation_ratio,
            "endpoint_dissolved_product_inventory_native": endpoint_product_inventory,
            "endpoint_field_semantics": (
                "quasi-steady field from the last reactive solve, before the "
                "accepted front advance; used only as a drain sensitivity proxy"
            ),
            "cumulative_generated_product_inventory_native": (
                model.cumulative_product_generation_inventory_native
            ),
            "expected_generation_from_actual_solid_removal_native": (
                expected_generated_from_removed_solid
            ),
            "generation_to_actual_removal_ratio": generation_closure_ratio,
            "cumulative_top_outflow_inventory_native": (
                model.cumulative_product_top_outflow_inventory_native
            ),
            "wet_precipitation_product_capture_inventory_native": (
                model.cumulative_product_precipitation_inventory_native
            ),
            "wet_deposit": wet_diagnostics.to_dict(),
            "integrated_quasi_steady_product_residual_native": (
                integrated_product_residual
            ),
            "parameter_provenance": primary_provenance,
        },
        "branches": branches,
        "representative_2d_map": representative_map,
        "convergence": {
            "reactant": all(entry.reactant_converged for entry in history),
            "product": all(entry.product_converged for entry in history),
            "front_product_picard": all(entry.nonlinear_converged for entry in history),
            "wet_precipitation_active_set": all(
                entry.wet_precipitation_converged for entry in history
            ),
            "maximum_product_inventory_balance_relative_error": max(
                (entry.product_inventory_balance_relative_error for entry in history),
                default=0.0,
            ),
            "maximum_front_mass_balance_relative_error": max(
                (entry.front_mass_balance_relative_error for entry in history),
                default=0.0,
            ),
            "terminated_by_step_limit": len(history) >= maximum_steps,
        },
    }


_WORKER_THREAD_LIMITER = None


def _initialise_worker() -> None:
    global _WORKER_THREAD_LIMITER
    try:
        from threadpoolctl import threadpool_limits
    except ImportError:
        return
    _WORKER_THREAD_LIMITER = threadpool_limits(limits=1)


def _run_case_tuple(
    values: tuple[str, str, PersistentDepositSweepConfig],
) -> dict[str, object]:
    return run_persistent_deposit_case(*values)


def _summary(cases: list[dict[str, object]]) -> dict[str, object]:
    wet_ratios = [
        float(case["primary_HF"]["maximum_saturation_ratio"])  # type: ignore[index]
        for case in cases
    ]
    wet_deposits = [
        float(
            case["primary_HF"]["wet_deposit"]["fraction_of_initial_gap_fill_area"]  # type: ignore[index]
        )
        for case in cases
    ]
    return {
        "case_count": len(cases),
        "maximum_wet_saturation_ratio": max(wet_ratios, default=0.0),
        "maximum_wet_deposit_fraction": max(wet_deposits, default=0.0),
        "literature_csat_wet_precipitation_is_null_in_all_cases": all(
            value == 0.0 for value in wet_deposits
        ),
        "interpretation": (
            "A null wet route does not rule out dry-down deposition; compare "
            "the immediate-rinse and meniscus-capture branches."
        ),
    }


def run_persistent_deposit_sweep(
    config: PersistentDepositSweepConfig | None = None,
) -> dict[str, object]:
    resolved = config or PersistentDepositSweepConfig()
    inputs = [
        (geometry, preset, resolved)
        for geometry in resolved.geometries
        for preset in resolved.presets
    ]
    workers = min(resolved.parallel_workers, len(inputs))
    if workers == 1:
        cases = [_run_case_tuple(item) for item in inputs]
    else:
        variables = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
        previous = {name: os.environ.get(name) for name in variables}
        for name in variables:
            os.environ[name] = "1"
        try:
            with ProcessPoolExecutor(
                max_workers=workers,
                initializer=_initialise_worker,
            ) as executor:
                cases = list(executor.map(_run_case_tuple, inputs))
        finally:
            for name, value in previous.items():
                if value is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = value
    return {
        "schema_version": 1,
        "model": "2-D persistent precipitation and wall/floor attachment sweep",
        "notice": PERSISTENT_DEPOSIT_NOTICE,
        "calibrated_deposit_kinetics": False,
        "temperature_coupling": (
            "solution and substrate temperatures are independent boundary "
            "metadata; this sweep does not yet correct D, WER, Csat or attachment"
        ),
        "config": resolved.to_dict(),
        "literature_sources": {
            "SiN_HF_drydown_and_rinse": "https://doi.org/10.1063/1.4905282",
            "AFS_solubility_and_density": "https://doi.org/10.1016/j.cplett.2006.06.044",
        },
        "parameter_classification": {
            "literature_anchored": [
                "SiN AFS-like identity",
                "AFS water/HF solubility fit",
                "AFS molar volume",
                "immediate flowing-DI rinse observation at >=30 s",
                "blanket etch rates and HF transport inputs",
            ],
            "derived_bounds": [
                "nitrogen-balance maximum deposit yield",
            ],
            "uncalibrated_hypotheses": [
                "wet attachment Damkohler number",
                "wall/bottom affinity",
                "cumulative meniscus capture fraction",
                "all post-dry dissolution rates",
                "all SiOCN deposit properties and identity",
            ],
        },
        "formation_scenarios": _formation_scenarios(resolved),
        "post_treatments": _post_treatments(),
        "parallel_execution": {
            "requested_workers": resolved.parallel_workers,
            "effective_workers": workers,
            "case_count": len(inputs),
            "case_order_preserved": True,
        },
        "cases": cases,
        "summary": _summary(cases),
    }


def plot_representative_deposit_maps(
    payload: Mapping[str, object], output_path: str
) -> None:
    """Render one wall-selective 1% meniscus map per geometry/material case."""
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize

    cases = list(payload["cases"])  # type: ignore[arg-type]
    if not cases:
        raise ValueError("payload contains no cases")
    representative_fractions = [
        float(case["representative_2d_map"]["cumulative_capture_fraction"])
        for case in cases
    ]
    capture_label = (
        f"{100.0 * representative_fractions[0]:g}% cumulative capture"
        if all(
            math.isclose(value, representative_fractions[0])
            for value in representative_fractions
        )
        else "nearest-to-1% cumulative capture"
    )
    thickness_values: list[float] = []
    for case in cases:
        map_data = case["representative_2d_map"]["deposit"]
        thickness_values.extend(
            np.add(
                map_data["wall_thickness_nm"],
                map_data["bottom_thickness_nm"],
            ).tolist()
        )
    vmax = max(thickness_values, default=1.0)
    norm = Normalize(vmin=0.0, vmax=max(vmax, np.finfo(float).eps))
    columns = 2
    rows = math.ceil(len(cases) / columns)
    figure, axes = plt.subplots(
        rows,
        columns,
        figsize=(8.4, 3.5 * rows),
        squeeze=False,
        constrained_layout=True,
    )
    figure.suptitle(
        f"Persistent deposit map: wall-selective / {capture_label}",
        fontsize=10,
    )
    scatter = None
    horizontal_exaggeration = 10.0
    for panel_index, (axis, case) in enumerate(
        zip(axes.flat, cases, strict=False)
    ):
        geometry = case["geometry"]
        map_data = case["representative_2d_map"]["deposit"]
        x = np.asarray(map_data["x_nm"], dtype=float)
        depth = np.asarray(map_data["depth_nm"], dtype=float)
        thickness = np.asarray(map_data["wall_thickness_nm"], dtype=float) + np.asarray(
            map_data["bottom_thickness_nm"], dtype=float
        )
        half_top = 0.5 * float(geometry["top_width_nm"])
        half_bottom = 0.5 * float(geometry["bottom_width_nm"])
        trench_depth = float(geometry["depth_nm"])
        axis.plot(
            horizontal_exaggeration
            * np.asarray([-half_top, -half_bottom, half_bottom, half_top]),
            [0.0, trench_depth, trench_depth, 0.0],
            color="0.25",
            linewidth=1.0,
        )
        scatter = axis.scatter(
            horizontal_exaggeration * x,
            depth,
            c=thickness,
            cmap="magma",
            norm=norm,
            s=10,
            marker="s",
            linewidths=0.0,
        )
        axis.set_title(
            f"{geometry['top_width_nm']:g}→{geometry['bottom_width_nm']:g} nm, "
            f"H={geometry['depth_nm']:g} nm | {case['material']}",
            fontsize=9,
        )
        if panel_index // columns == rows - 1:
            axis.set_xlabel("x (nm; horizontal ×10)")
        if panel_index % columns == 0:
            axis.set_ylabel("depth (nm)")
        axis.set_xticks(
            horizontal_exaggeration * np.asarray([-half_top, 0.0, half_top]),
            labels=[f"{-half_top:g}", "0", f"{half_top:g}"],
        )
        axis.invert_yaxis()
        axis.set_aspect("equal", adjustable="box")
    for axis in axes.flat[len(cases):]:
        axis.set_visible(False)
    if scatter is not None:
        figure.colorbar(scatter, ax=axes, label="deposit thickness (nm)", shrink=0.85)
    figure.savefig(output_path, dpi=220)
    plt.close(figure)


__all__ = [
    "AFS_MOLAR_DENSITY_MOL_M3",
    "AFS_MOLAR_MASS_KG_MOL",
    "AFS_WATER_SOLUBILITY_MOL_M3",
    "PERSISTENT_DEPOSIT_NOTICE",
    "PersistentDepositSweepConfig",
    "afs_solubility_from_hf_mol_m3",
    "plot_representative_deposit_maps",
    "run_persistent_deposit_case",
    "run_persistent_deposit_sweep",
]

"""Dimensionless ozone-delivery screen for a straight high-aspect-ratio slit.

For a slit of width ``w`` and depth ``L``, the steady one-dimensional model is

    D_eff d2C/dz2 - (2 k_s / w) C = 0,

with fixed concentration at the opening and zero flux at the closed bottom.
The Thiele modulus is

    phi = L sqrt(2 k_s / (w D_eff)).

The exact bottom and depth-average concentration fractions are ``sech(phi)``
and ``tanh(phi) / phi``.  Keeping ``phi`` as the primary input avoids inventing
an ozone diffusivity or surface reaction velocity that the cited experiment
does not report.  If an effective diffusivity is supplied, the equivalent
first-order wall velocity is also returned.

This is a delivery diagnostic, not a chemistry or etch-depth prediction.
Continuum validity, Knudsen transport, ozone decomposition, adsorption
saturation, transients, and film-dependent reaction mechanisms remain open.
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

from trench_geometry import (
    DEFAULT_GEOMETRY_NAMES,
    GEOMETRY_PRESETS,
    get_geometry_preset,
)


SCHEMA_VERSION = "ozone-slit-penetration-screen/v1"
MODEL_NOTICE = (
    "Dimensionless steady-state first-order wall-sink screen, not a process "
    "recipe. The primary result is concentration delivery versus Thiele "
    "modulus. No ozone diffusivity, wall reaction velocity, transient dose, "
    "surface saturation, Knudsen correction, or etch conversion is inferred "
    "from Kawarazaki et al. The closed bottom is treated as non-reactive, so "
    "delivery is optimistic if the bottom surface also consumes ozone."
)


def _rounded(value: float) -> float:
    return round(float(value), 12)


def _sech(value: float) -> float:
    """Stable hyperbolic secant for non-negative finite values."""

    if value == 0.0:
        return 1.0
    decay = math.exp(-value)
    return 2.0 * decay / (1.0 + decay * decay)


def _log_cosh(value: float) -> float:
    magnitude = abs(value)
    return (
        magnitude
        + math.log1p(math.exp(-2.0 * magnitude))
        - math.log(2.0)
    )


def concentration_fraction_at_depth(
    thiele_modulus: float,
    normalized_depth: float,
) -> float:
    """Return C(z)/C(opening) for z/L in [0, 1]."""

    phi = float(thiele_modulus)
    fraction = float(normalized_depth)
    if not math.isfinite(phi) or phi < 0.0:
        raise ValueError("thiele_modulus must be finite and non-negative")
    if not math.isfinite(fraction) or not 0.0 <= fraction <= 1.0:
        raise ValueError("normalized_depth must be finite and within [0, 1]")
    log_ratio = _log_cosh(phi * (1.0 - fraction)) - _log_cosh(phi)
    return math.exp(log_ratio)


@dataclass(frozen=True)
class OzonePenetrationConfig:
    geometry_names: tuple[str, ...] = tuple(DEFAULT_GEOMETRY_NAMES)
    thiele_moduli: tuple[float, ...] = (0.0, 0.1, 0.3, 1.0, 2.0, 3.0, 5.0)
    normalized_profile_depths: tuple[float, ...] = (
        0.0,
        0.25,
        0.5,
        0.75,
        1.0,
    )
    bottom_delivery_targets: tuple[float, ...] = (0.9, 0.5, 0.1)
    effective_diffusivity_m2_s: float | None = None
    exposure_duration_s: float = 30.0
    steady_state_fourier_threshold: float = 10.0

    def __post_init__(self) -> None:
        if not self.geometry_names:
            raise ValueError("geometry_names cannot be empty")
        unknown = set(self.geometry_names).difference(GEOMETRY_PRESETS)
        if unknown:
            raise ValueError(f"unknown geometry_names: {sorted(unknown)}")
        if len(set(self.geometry_names)) != len(self.geometry_names):
            raise ValueError("geometry_names cannot contain duplicates")
        for name in self.geometry_names:
            geometry = get_geometry_preset(name)
            if not math.isclose(
                geometry.top_width_nm,
                geometry.bottom_width_nm,
                rel_tol=0.0,
                abs_tol=1.0e-12,
            ):
                raise ValueError(
                    "ozone slit screen currently requires straight geometry"
                )
        if not self.thiele_moduli:
            raise ValueError("thiele_moduli cannot be empty")
        moduli = tuple(float(value) for value in self.thiele_moduli)
        if any(not math.isfinite(value) or value < 0.0 for value in moduli):
            raise ValueError(
                "thiele_moduli must be finite and non-negative"
            )
        if len(set(moduli)) != len(moduli):
            raise ValueError("thiele_moduli cannot contain duplicates")
        depths = tuple(float(value) for value in self.normalized_profile_depths)
        if not depths:
            raise ValueError("normalized_profile_depths cannot be empty")
        if any(
            not math.isfinite(value) or not 0.0 <= value <= 1.0
            for value in depths
        ):
            raise ValueError(
                "normalized_profile_depths must lie within [0, 1]"
            )
        if len(set(depths)) != len(depths):
            raise ValueError(
                "normalized_profile_depths cannot contain duplicates"
            )
        targets = tuple(float(value) for value in self.bottom_delivery_targets)
        if not targets:
            raise ValueError("bottom_delivery_targets cannot be empty")
        if any(
            not math.isfinite(value) or not 0.0 < value <= 1.0
            for value in targets
        ):
            raise ValueError(
                "bottom_delivery_targets must lie within (0, 1]"
            )
        if len(set(targets)) != len(targets):
            raise ValueError(
                "bottom_delivery_targets cannot contain duplicates"
            )
        if self.effective_diffusivity_m2_s is not None:
            diffusivity = float(self.effective_diffusivity_m2_s)
            if not math.isfinite(diffusivity) or diffusivity <= 0.0:
                raise ValueError(
                    "effective_diffusivity_m2_s must be finite and positive"
                )
            object.__setattr__(
                self, "effective_diffusivity_m2_s", diffusivity
            )
        for field_name in (
            "exposure_duration_s",
            "steady_state_fourier_threshold",
        ):
            value = float(getattr(self, field_name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{field_name} must be finite and positive")
            object.__setattr__(self, field_name, value)
        object.__setattr__(self, "geometry_names", tuple(self.geometry_names))
        object.__setattr__(self, "thiele_moduli", moduli)
        object.__setattr__(
            self, "normalized_profile_depths", depths
        )
        object.__setattr__(
            self, "bottom_delivery_targets", targets
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["geometry_names"] = list(self.geometry_names)
        result["thiele_moduli"] = list(self.thiele_moduli)
        result["normalized_profile_depths"] = list(
            self.normalized_profile_depths
        )
        result["bottom_delivery_targets"] = list(
            self.bottom_delivery_targets
        )
        return result


def _sink_ratio_m_inv(phi: float, width_m: float, depth_m: float) -> float:
    """Return k_s / D_eff from phi, in inverse metres."""

    return phi * phi * width_m / (2.0 * depth_m * depth_m)


def _geometry_case(
    geometry_name: str,
    config: OzonePenetrationConfig,
) -> dict[str, object]:
    geometry = get_geometry_preset(geometry_name)
    width_m = geometry.top_width_nm * 1.0e-9
    depth_m = geometry.depth_nm * 1.0e-9
    sweep: list[dict[str, object]] = []
    for phi in config.thiele_moduli:
        bottom_fraction = _sech(phi)
        mean_fraction = 1.0 if phi == 0.0 else math.tanh(phi) / phi
        sink_ratio = _sink_ratio_m_inv(phi, width_m, depth_m)
        row: dict[str, object] = {
            "thiele_modulus": phi,
            "surface_velocity_over_diffusivity_m_inv": _rounded(sink_ratio),
            "bottom_concentration_fraction": _rounded(bottom_fraction),
            "depth_average_concentration_fraction": _rounded(mean_fraction),
            "bottom_depletion_fraction": _rounded(1.0 - bottom_fraction),
            "profile": [
                {
                    "normalized_depth": normalized_depth,
                    "concentration_fraction": _rounded(
                        concentration_fraction_at_depth(
                            phi, normalized_depth
                        )
                    ),
                }
                for normalized_depth in config.normalized_profile_depths
            ],
        }
        if config.effective_diffusivity_m2_s is not None:
            row["equivalent_surface_reaction_velocity_m_s"] = _rounded(
                sink_ratio * config.effective_diffusivity_m2_s
            )
        sweep.append(row)

    thresholds: list[dict[str, object]] = []
    for target in config.bottom_delivery_targets:
        threshold_phi = math.acosh(1.0 / target)
        sink_ratio = _sink_ratio_m_inv(
            threshold_phi, width_m, depth_m
        )
        threshold: dict[str, object] = {
            "minimum_bottom_concentration_fraction": target,
            "maximum_thiele_modulus": _rounded(threshold_phi),
            "maximum_surface_velocity_over_diffusivity_m_inv": _rounded(
                sink_ratio
            ),
        }
        if config.effective_diffusivity_m2_s is not None:
            threshold[
                "maximum_equivalent_surface_reaction_velocity_m_s"
            ] = _rounded(sink_ratio * config.effective_diffusivity_m2_s)
        thresholds.append(threshold)

    minimum_diffusivity_for_steady_screen = (
        config.steady_state_fourier_threshold
        * depth_m
        * depth_m
        / config.exposure_duration_s
    )
    transient_check: dict[str, object] = {
        "exposure_duration_s": config.exposure_duration_s,
        "fourier_number_definition": "Fo=D_eff*t/L^2",
        "steady_state_screen_threshold": (
            config.steady_state_fourier_threshold
        ),
        "minimum_effective_diffusivity_m2_s_for_threshold": (
            minimum_diffusivity_for_steady_screen
        ),
    }
    if config.effective_diffusivity_m2_s is None:
        transient_check["fourier_number"] = None
        transient_check["steady_state_screen_passes"] = None
        transient_check["status"] = (
            "undetermined: supply an effective diffusivity"
        )
    else:
        fourier_number = (
            config.effective_diffusivity_m2_s
            * config.exposure_duration_s
            / (depth_m * depth_m)
        )
        passes = fourier_number >= config.steady_state_fourier_threshold
        transient_check["fourier_number"] = _rounded(fourier_number)
        transient_check["steady_state_screen_passes"] = passes
        transient_check["status"] = (
            "screening threshold passed"
            if passes
            else "steady-state use not supported by Fourier-number threshold"
        )

    return {
        "geometry_name": geometry_name,
        "width_nm": geometry.top_width_nm,
        "depth_nm": geometry.depth_nm,
        "aspect_ratio": geometry.opening_aspect_ratio,
        "sweep": sweep,
        "bottom_delivery_thresholds": thresholds,
        "transient_check": transient_check,
    }


def run_ozone_penetration_screen(
    config: OzonePenetrationConfig = OzonePenetrationConfig(),
) -> dict[str, object]:
    cases = [
        _geometry_case(geometry_name, config)
        for geometry_name in config.geometry_names
    ]
    monotonic_cases = all(
        all(
            float(current["bottom_concentration_fraction"])
            >= float(following["bottom_concentration_fraction"])
            for current, following in zip(
                sorted(
                    case["sweep"],
                    key=lambda row: float(row["thiele_modulus"]),
                ),
                sorted(
                    case["sweep"],
                    key=lambda row: float(row["thiele_modulus"]),
                )[1:],
            )
        )
        for case in cases
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "model": "steady one-dimensional reactive-slit ozone delivery",
        "notice": MODEL_NOTICE,
        "config": config.to_dict(),
        "equations": {
            "governing_equation": "D_eff*C'' - (2*k_s/w)*C = 0",
            "boundary_conditions": "C(0)=C_opening; dC/dz(L)=0",
            "thiele_modulus": "phi=L*sqrt(2*k_s/(w*D_eff))",
            "bottom_fraction": "C(L)/C(0)=sech(phi)",
            "depth_average_fraction": "<C>/C(0)=tanh(phi)/phi",
        },
        "assumptions": {
            "steady_state": True,
            "straight_constant_width_slit": True,
            "first_order_wall_sink": True,
            "continuum_transport": True,
            "closed_bottom_is_nonreactive_zero_flux": True,
            "delivery_is_optimistic_if_bottom_reacts": True,
            "knudsen_correction_included": False,
            "transient_dose_included": False,
            "surface_saturation_included": False,
            "etch_conversion_included": False,
        },
        "quality": {
            "geometry_case_count": len(cases),
            "sweep_case_count": sum(len(case["sweep"]) for case in cases),
            "bottom_delivery_monotonic_with_phi": monotonic_cases,
            "opening_boundary_exact": all(
                all(
                    math.isclose(
                        float(row["profile"][0]["concentration_fraction"]),
                        1.0,
                        rel_tol=0.0,
                        abs_tol=1.0e-12,
                    )
                    for row in case["sweep"]
                )
                for case in cases
                if config.normalized_profile_depths[0] == 0.0
            ),
            "steady_state_checks_determined": sum(
                case["transient_check"]["steady_state_screen_passes"]
                is not None
                for case in cases
            ),
            "steady_state_checks_passed": sum(
                case["transient_check"]["steady_state_screen_passes"] is True
                for case in cases
            ),
        },
        "cases": cases,
    }


def save_ozone_penetration_json(
    payload: dict[str, object],
    path: str | Path,
) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    destination.write_text(text + "\n", encoding="utf-8")
    return destination


__all__ = [
    "MODEL_NOTICE",
    "OzonePenetrationConfig",
    "SCHEMA_VERSION",
    "concentration_fraction_at_depth",
    "run_ozone_penetration_screen",
    "save_ozone_penetration_json",
]

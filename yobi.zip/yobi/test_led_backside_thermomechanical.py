from __future__ import annotations

import math
import unittest

import numpy as np

from led_backside_thermomechanical import (
    SILICON_DENSITY_KG_M3,
    WATER_BULK_TEMPERATURE_K,
    band_averaged_absorptance,
    default_local_paths,
    default_residue_cases,
    free_plate_surface_strain_from_profile,
    inverse_delamination_temperature,
    local_global_active_area_fraction_ceiling,
    local_residue_thermal_state,
    optical_absorption_air_sio2_si,
    required_incident_irradiance_W_m2,
    required_incident_irradiance_exact_W_m2,
    silicon_enthalpy_change_J_kg,
    silicon_free_thermal_strain,
    silicon_heat_capacity_J_kgK,
    silicon_linear_expansion_coefficient_per_K,
    simulate_1d_wafer_constant_flux,
    square_pulse_temperature_history,
    substrate_temperature_for_delta_K,
    temperature_after_constant_irradiance_K,
    thermomechanical_state,
    wafer_area_m2,
    whole_wafer_irradiance_W_m2,
)


class GeometryAndPropertiesTests(unittest.TestCase):
    def test_300_mm_wafer_area(self) -> None:
        self.assertAlmostEqual(wafer_area_m2(), math.pi * 0.15**2, places=14)

    def test_780_W_area_reference(self) -> None:
        irradiance = whole_wafer_irradiance_W_m2(780.0)
        self.assertAlmostEqual(irradiance / 1.0e4, 1.103474, places=5)

    def test_nist_cp_and_enthalpy_are_consistent(self) -> None:
        temperature = 350.0
        step = 1.0e-3
        derivative = (
            silicon_enthalpy_change_J_kg(temperature + step)
            - silicon_enthalpy_change_J_kg(temperature - step)
        ) / (2.0 * step)
        self.assertAlmostEqual(
            derivative, silicon_heat_capacity_J_kgK(temperature), delta=1.0e-5
        )

    def test_okada_strain_derivative_is_cte(self) -> None:
        temperature = 350.0
        step = 1.0e-3
        derivative = (
            silicon_free_thermal_strain(temperature + step)
            - silicon_free_thermal_strain(temperature - step)
        ) / (2.0 * step)
        self.assertAlmostEqual(
            derivative,
            silicon_linear_expansion_coefficient_per_K(temperature),
            delta=1.0e-12,
        )


class OpticalTests(unittest.TestCase):
    def test_bare_si_matches_direct_fresnel_formula(self) -> None:
        result = optical_absorption_air_sio2_si(400.0, 0.0)
        expected_reflectance = ((5.613 - 1.0) ** 2 + 0.296**2) / (
            (5.613 + 1.0) ** 2 + 0.296**2
        )
        self.assertAlmostEqual(result.reflectance, expected_reflectance, places=13)
        self.assertAlmostEqual(result.absorptance, 1.0 - expected_reflectance)

    def test_absorption_depth_is_submicron(self) -> None:
        result = optical_absorption_air_sio2_si(400.0, 0.0)
        self.assertAlmostEqual(result.silicon_absorption_depth_nm, 107.5269, places=3)

    def test_native_oxide_is_near_bare(self) -> None:
        bare = band_averaged_absorptance(0.0)
        native = band_averaged_absorptance(2.0)
        self.assertLess(abs(native - bare), 0.002)

    def test_70_nm_oxide_is_antireflective_in_selected_band(self) -> None:
        self.assertGreater(
            band_averaged_absorptance(70.0), band_averaged_absorptance(0.0) + 0.25
        )


class WaferHeatingTests(unittest.TestCase):
    def test_no_loss_inverse_is_exact_energy_balance(self) -> None:
        thickness = 775.0e-6
        target = 350.0
        duration = 10.0
        absorption = band_averaged_absorptance(2.0)
        required = required_incident_irradiance_W_m2(
            target, duration, thickness, absorption, 0.0
        )
        absorbed_energy = required * absorption * duration
        expected = (
            SILICON_DENSITY_KG_M3
            * thickness
            * silicon_enthalpy_change_J_kg(target)
        )
        self.assertAlmostEqual(absorbed_energy, expected, places=8)

    def test_average_cp_inverse_matches_exact_variable_cp(self) -> None:
        absorption = band_averaged_absorptance(2.0)
        approximate = required_incident_irradiance_W_m2(
            373.0, 30.0, 775.0e-6, absorption, 1000.0
        )
        exact = required_incident_irradiance_exact_W_m2(
            373.0, 30.0, 775.0e-6, absorption, 1000.0
        )
        self.assertLess(abs(approximate / exact - 1.0), 0.003)

    def test_exact_inverse_round_trip(self) -> None:
        absorption = band_averaged_absorptance(70.0)
        required = required_incident_irradiance_exact_W_m2(
            360.0, 12.0, 500.0e-6, absorption, 100.0
        )
        recovered = temperature_after_constant_irradiance_K(
            required, 12.0, 500.0e-6, absorption, 100.0
        )
        self.assertAlmostEqual(recovered, 360.0, delta=2.0e-6)

    def test_duty_one_is_uninterrupted_continuous_constant_cp(self) -> None:
        absorption = band_averaged_absorptance(2.0)
        pulse = square_pulse_temperature_history(
            1.0e4, 0.1, 1.0, 12.0, 775.0e-6, absorption, 100.0
        )
        cp = silicon_heat_capacity_J_kgK(WATER_BULK_TEMPERATURE_K)
        capacity = SILICON_DENSITY_KG_M3 * 775.0e-6 * cp
        expected_rise = absorption * 1.0e4 / 100.0 * (
            1.0 - math.exp(-100.0 * 12.0 / capacity)
        )
        self.assertAlmostEqual(
            pulse.final_temperature_K,
            WATER_BULK_TEMPERATURE_K + expected_rise,
            places=10,
        )

    def test_pulsing_raises_peak_at_same_average_power(self) -> None:
        absorption = band_averaged_absorptance(2.0)
        pulsed = square_pulse_temperature_history(
            2.0e4, 1.0, 0.5, 60.0, 775.0e-6, absorption, 1000.0
        )
        continuous_average = square_pulse_temperature_history(
            1.0e4, 1.0, 1.0, 60.0, 775.0e-6, absorption, 1000.0
        )
        self.assertGreater(
            pulsed.peak_temperature_K, continuous_average.peak_temperature_K
        )

    def test_peak_to_valley_is_last_completed_cycle_not_total_warmup(self) -> None:
        absorption = band_averaged_absorptance(2.0)
        pulse = square_pulse_temperature_history(
            1.7e4, 0.01, 0.5, 60.0, 775.0e-6, absorption, 1000.0
        )
        self.assertLess(pulse.peak_to_valley_K, 0.1)
        self.assertGreater(
            pulse.peak_temperature_K - WATER_BULK_TEMPERATURE_K,
            100.0 * pulse.peak_to_valley_K,
        )


class LocalResidueAndMechanicsTests(unittest.TestCase):
    def test_local_global_area_fraction_matches_heat_budget_ratio(self) -> None:
        path = default_local_paths()[2]
        state = local_residue_thermal_state(WATER_BULK_TEMPERATURE_K + 1.0, path)
        expected = 1000.0 / state.heat_flux_W_m2
        self.assertAlmostEqual(
            local_global_active_area_fraction_ceiling(path, 1000.0),
            expected,
            places=14,
        )

    def test_local_temperature_fractions_close(self) -> None:
        path = default_local_paths()[0]
        state = local_residue_thermal_state(400.0, path)
        self.assertAlmostEqual(
            state.residue_heating_fraction + state.residue_cold_fraction,
            1.0,
            places=14,
        )
        self.assertAlmostEqual(
            state.substrate_residue_delta_K + state.residue_water_delta_K,
            400.0 - WATER_BULK_TEMPERATURE_K,
            places=12,
        )

    def test_nm_residue_relaxation_is_much_shorter_than_ms(self) -> None:
        for path in default_local_paths():
            state = local_residue_thermal_state(350.0, path)
            self.assertLess(state.relaxation_time_s, 1.0e-6)

    def test_stored_energy_identity(self) -> None:
        path = default_local_paths()[2]
        residue = default_residue_cases()[0]
        state = thermomechanical_state(373.0, path, residue)
        expected = (
            residue.biaxial_modulus_Pa
            * state.mismatch_strain**2
            * residue.thickness_m
        )
        self.assertAlmostEqual(state.stored_energy_upper_bound_J_m2, expected)

    def test_inverse_threshold_round_trip(self) -> None:
        path = default_local_paths()[2]
        residue = default_residue_cases()[0]
        threshold = inverse_delamination_temperature(1.0e-5, path, residue)
        self.assertTrue(threshold.reached)
        assert threshold.required_substrate_temperature_K is not None
        state = thermomechanical_state(
            threshold.required_substrate_temperature_K, path, residue
        )
        self.assertAlmostEqual(
            state.stored_energy_upper_bound_J_m2, 1.0e-5, delta=1.0e-12
        )

    def test_temperature_for_desired_delta_round_trip(self) -> None:
        path = default_local_paths()[1]
        substrate = substrate_temperature_for_delta_K(10.0, path)
        state = local_residue_thermal_state(substrate, path)
        self.assertAlmostEqual(state.substrate_residue_delta_K, 10.0, places=11)


class OneDimensionalValidationTests(unittest.TestCase):
    def test_uniform_profile_has_zero_curvature(self) -> None:
        profile = np.full(20, 350.0)
        front_strain, curvature = free_plate_surface_strain_from_profile(
            profile, 775.0e-6
        )
        self.assertAlmostEqual(curvature, 0.0, places=13)
        self.assertAlmostEqual(front_strain, silicon_free_thermal_strain(350.0))

    def test_no_loss_1d_mean_obeys_energy_balance(self) -> None:
        absorption = band_averaged_absorptance(2.0)
        result = simulate_1d_wafer_constant_flux(
            5.0e3, 0.01, 775.0e-6, absorption, 0.0, cell_count=40
        )
        cp = silicon_heat_capacity_J_kgK(WATER_BULK_TEMPERATURE_K)
        expected_rise = (
            absorption * 5.0e3 * 0.01 / (SILICON_DENSITY_KG_M3 * 775.0e-6 * cp)
        )
        self.assertAlmostEqual(
            result.mean_temperature_K - WATER_BULK_TEMPERATURE_K,
            expected_rise,
            delta=2.0e-7,
        )

    def test_small_biot_mean_agrees_with_lumped(self) -> None:
        absorption = band_averaged_absorptance(2.0)
        result = simulate_1d_wafer_constant_flux(
            1.0e4, 5.0, 775.0e-6, absorption, 100.0, cell_count=60
        )
        self.assertLess(result.biot_number, 0.01)
        self.assertLess(abs(result.mean_vs_lumped_delta_K), 0.03)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Run and visualize the real-dimension continuum/graph-KMC sensitivity study."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

from trench_geometry import DEFAULT_GEOMETRY_NAMES
from trench_kmc_sweep import (
    SCENARIO_ORDER,
    TrenchKMCSweepConfig,
    run_trench_kmc_sweep,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run the two standard straight-wall trenches with local continuum "
            "fields, multilayer graph KMC, persistent deposits and an explicit "
            "HF-supply x retention-strength phase map."
        )
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/trench_graph_kmc"),
        help="directory for strict JSON and the three mandatory PNG figures",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent processes; 0 selects up to four workers",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=20260714,
        help="base seed; the same seed is reused across sensitivities per geometry",
    )
    parser.add_argument(
        "--total-time-s",
        type=float,
        default=None,
        help=(
            "native clock horizon; a finer mesh needs longer to reach the same "
            "removed fraction"
        ),
    )
    parser.add_argument(
        "--grid-spacing-nm",
        type=float,
        default=None,
        help="override the graph mesh; see results/mesh_seed_convergence",
    )
    parser.add_argument(
        "--maximum-sites",
        type=int,
        default=None,
        help="graph site budget; must grow with a finer mesh",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help=(
            "use a 2 nm graph, shorter horizon and 2 x 3 phase grid for a fast "
            "end-to-end check"
        ),
    )
    return parser


def _config(args: argparse.Namespace) -> TrenchKMCSweepConfig:
    if args.workers < 0:
        raise ValueError("workers must be zero or a positive integer")
    if args.seed < 0:
        raise ValueError("seed must be non-negative")
    geometry_count = len(DEFAULT_GEOMETRY_NAMES)
    phase_case_count = geometry_count * (6 if args.quick else 9)
    mechanism_case_count = geometry_count * len(SCENARIO_ORDER)
    case_count = mechanism_case_count + phase_case_count
    workers = (
        min(4, os.cpu_count() or 1, case_count)
        if args.workers == 0
        else min(args.workers, case_count)
    )
    common: dict[str, object] = {
        "base_seed": args.seed,
        "parallel_workers": workers,
    }
    if args.maximum_sites is not None:
        common["maximum_sites"] = int(args.maximum_sites)
    if args.grid_spacing_nm is not None:
        common["grid_spacing_nm"] = float(args.grid_spacing_nm)
    if args.total_time_s is not None:
        common["total_time_s"] = float(args.total_time_s)
    if args.quick:
        common.setdefault("grid_spacing_nm", 2.0)
        return TrenchKMCSweepConfig(
            **common,
            total_time_s=160.0,
            macro_time_step_s=10.0,
            maximum_events=12_000,
            hf_scales=(0.70, 1.30),
            retention_strength_scales=(0.0, 1.0, 2.0),
        )
    return TrenchKMCSweepConfig(**common)


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config = _config(args)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = run_trench_kmc_sweep(config)

    result_path = output_dir / "trench_kmc_sweep_results.json"
    phase_path = output_dir / "trench_kmc_phase_maps.png"
    summary_path = output_dir / "trench_kmc_sensitivity_summary.png"
    history_path = output_dir / "trench_kmc_event_history.png"
    payload["artifacts"] = {
        "results_json": result_path.name,
        "phase_maps": phase_path.name,
        "sensitivity_summary": summary_path.name,
        "event_history": history_path.name,
    }

    # Imported after computation to keep worker imports free of plotting state.
    from trench_graph_kmc_visualization import (
        plot_trench_kmc_event_history,
        plot_trench_kmc_phase_maps,
        plot_trench_kmc_sensitivity_summary,
    )

    plot_trench_kmc_phase_maps(payload, phase_path)
    plot_trench_kmc_sensitivity_summary(payload, summary_path)
    representative = next(
        case
        for case in payload["cases"]
        if case["geometry_id"] == config.geometries[0]
        and case["scenario_id"] == "combined"
    )
    plot_trench_kmc_event_history(representative, history_path)

    result_path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return payload


if __name__ == "__main__":
    main()

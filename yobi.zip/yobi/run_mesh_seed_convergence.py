#!/usr/bin/env python3
"""Run the mesh/seed convergence study for the primary-HF endpoint."""

from __future__ import annotations

import argparse
import os
from pathlib import Path


for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ[_thread_variable] = "1"


from mesh_seed_convergence import (  # noqa: E402
    ConvergenceConfig,
    readme_lines,
    run_convergence_study,
    write_json,
)

RESULT_NAME = "mesh_seed_convergence_results.json"
README_NAME = "README_JA.md"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mode",
        choices=("smoke", "quick", "full"),
        default="quick",
        help=(
            "smoke=one geometry/preset and three meshes; quick=full matrix on "
            "six meshes with three seeds; full adds two finer meshes"
        ),
    )
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/mesh_seed_convergence"),
    )
    return parser


def config_for_mode(mode: str) -> ConvergenceConfig:
    if mode == "smoke":
        return ConvergenceConfig(
            meshes_nm=(1.70, 1.05, 0.85),
            replicate_seeds=(271828, 314159),
            geometries=("10_10_180",),
            presets=("sin_barcellona_b_0p55wt",),
            scenarios=("transport_only",),
        )
    if mode == "quick":
        return ConvergenceConfig()
    if mode == "full":
        return ConvergenceConfig(
            meshes_nm=(1.70, 1.40, 1.05, 0.85, 0.70, 0.55, 0.45, 0.35, 0.28),
            replicate_seeds=(271828, 314159, 161803, 141421, 173205),
        )
    raise ValueError("mode must be smoke, quick or full")


def main(argv: list[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    config = config_for_mode(arguments.mode)
    workers = (
        min(len(config.meshes_nm), os.cpu_count() or 1, 8)
        if arguments.workers == 0
        else max(1, arguments.workers)
    )
    payload = run_convergence_study(config, workers=workers)
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    result_path = write_json(payload, arguments.output_dir / RESULT_NAME)
    readme_path = arguments.output_dir / README_NAME
    readme_path.write_text(
        "\n".join(readme_lines(payload)) + "\n", encoding="utf-8"
    )
    print(f"mode: {arguments.mode}")
    print(f"mesh workers: {workers}")
    print(f"failed trench runs: {payload['quality_summary']['failed_trench_runs']}")
    print(
        "recommended production mesh: "
        f"{payload['recommended_production_mesh_nm']} nm"
    )
    print(f"JSON: {result_path}")
    print(f"README: {readme_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

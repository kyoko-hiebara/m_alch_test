from __future__ import annotations

import math
import unittest

import numpy as np

from measured_blanket_clock import load_blanket_time_series_csv
from sin_fullfill_recipe_screen import (
    SiNFullFillRecipeConfig,
    build_aligned_straight_grid,
    run_sin_fullfill_recipe_screen,
    simulate_dhf_fullfill_front,
)
from trench_geometry import GEOMETRY_PRESETS


INPUT_CSV = "inputs/sin_blanket_user_20260728.csv"


class SiNFullFillRecipeScreenTests(unittest.TestCase):
    def setUp(self) -> None:
        self.series = load_blanket_time_series_csv(INPUT_CSV)
        self.config = SiNFullFillRecipeConfig(
            nominal_grid_spacings_nm=(0.5, 0.25),
        )

    def test_aligned_grid_closes_straight_cavity_area(self) -> None:
        geometry = GEOMETRY_PRESETS["10_10_180"]
        for spacing_nm in (0.5, 0.25, 0.125):
            grid = build_aligned_straight_grid(
                geometry,
                nominal_spacing_nm=spacing_nm,
                reservoir_height_nm=2.0,
                lateral_margin_nm=2.0,
            )
            area_nm2 = (
                np.count_nonzero(grid.cavity_mask) * grid.cell_area_nm2
            )
            self.assertAlmostEqual(area_nm2, geometry.area_nm2, places=10)

    def test_20_second_front_matches_piecewise_clock(self) -> None:
        result = simulate_dhf_fullfill_front(
            self.series,
            self.config,
            nominal_spacing_nm=0.25,
        )
        metrics = result.metrics
        expected_retreat_nm = 0.6418 / 3.0
        self.assertAlmostEqual(
            float(metrics["equivalent_planar_retreat_nm"]),
            expected_retreat_nm,
            places=12,
        )
        self.assertAlmostEqual(
            float(metrics["dissolved_area_nm2"]),
            10.0 * expected_retreat_nm,
            places=11,
        )
        self.assertFalse(metrics["bottom_exposed"])
        self.assertEqual(metrics["bottom_minimum_solid_fraction"], 1.0)
        self.assertLess(
            float(metrics["maximum_step_mass_balance_relative_error"]),
            1.0e-12,
        )

    def test_recipe_keeps_sc1_out_of_quantitative_endpoint(self) -> None:
        payload = run_sin_fullfill_recipe_screen(
            self.series, self.config
        )
        endpoint = payload["dhf_calibrated_endpoint"]
        expected_retreat_nm = 0.6418 / 3.0
        self.assertAlmostEqual(endpoint["top_retreat_nm"], expected_retreat_nm)
        self.assertAlmostEqual(
            endpoint["remaining_solid_fraction"],
            1.0 - expected_retreat_nm / 180.0,
        )
        stages = payload["stage_states"]
        self.assertEqual(
            stages[2]["quantitative_status"],
            "state_preserving_matrix_assumption",
        )
        self.assertIsNone(stages[3]["quantified_top_retreat_nm"])
        self.assertIsNone(stages[4]["quantified_top_retreat_nm"])
        self.assertFalse(
            payload["claim_boundary"][
                "sc1_quantitative_prediction_available"
            ]
        )
        self.assertFalse(
            payload["claim_boundary"]["drydown_redeposition_enabled"]
        )

    def test_sc1_rate_ratio_is_only_a_sensitivity_axis(self) -> None:
        payload = run_sin_fullfill_recipe_screen(
            self.series, self.config
        )
        rows = {
            row["alpha_SC1_to_initial_dHF_rate"]: row
            for row in payload["sc1_sensitivity"]
        }
        alpha_one = rows[1.0]
        self.assertAlmostEqual(alpha_one["SC1_rate_nm_min"], 0.6418)
        self.assertAlmostEqual(
            alpha_one["SC1_added_retreat_nm"], 3.0 * 0.6418
        )
        self.assertAlmostEqual(
            alpha_one["total_top_retreat_after_SC1_nm"],
            0.6418 / 3.0 + 3.0 * 0.6418,
        )
        self.assertEqual(
            alpha_one["status"],
            "uncalibrated_sensitivity_not_prediction",
        )

    def test_config_rejects_tapered_geometry(self) -> None:
        with self.assertRaises(ValueError):
            SiNFullFillRecipeConfig(geometry_id="10_8_180")

    def test_recipe_end_times_close_at_320_seconds(self) -> None:
        payload = run_sin_fullfill_recipe_screen(
            self.series, self.config
        )
        stages = payload["stage_states"]
        self.assertTrue(
            all(
                left["end_time_s"] <= right["end_time_s"]
                for left, right in zip(stages, stages[1:])
            )
        )
        self.assertTrue(
            math.isclose(stages[-1]["end_time_s"], 320.0)
        )


if __name__ == "__main__":
    unittest.main()

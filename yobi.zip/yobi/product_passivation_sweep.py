"""Literature-timescale sweep for dissolved product and passivation effects.

Blanket WER, neutral-HF concentration, HF diffusivity, and solid Si-site
density come from :mod:`literature_parameters`.  Product inhibition and
passivation kinetics are not identified by those sources, so they are expressed
as dimensionless ratios relative to a transparent transport timescale.

The dissolved product field is defined as mol/m3 of dissolved-Si equivalent.
One mol of solid Si sites therefore produces one mol of this bookkeeping
species.  This definition closes the source inventory but does not assert a
specific aqueous SiF6 / SiF4 / oligomer distribution.
"""

from __future__ import annotations

import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Mapping

import numpy as np

from etch_process import EtchProcessConfig, ThermalBoundaryConditions
from gapfill_etch_2d import (
    GapFillEtch2D,
    PassivationParameters,
    TransportParameters,
)
from literature_parameters import (
    HF_DIFFUSIVITY_298_NM2_S,
    LITERATURE_ETCH_PRESETS,
    LiteratureEtchPreset,
    get_literature_preset,
)
from literature_sweep import nominal_preset_names
from numerical_settings import LOOSE_NUMERICS, NumericalSettings
from reaction_diffusion_2d import interface_average_on_solid
from spatial_etchability import analyse_residue_topology
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS, get_geometry_preset


PRODUCT_PASSIVATION_NOTICE = (
    "Mechanism sensitivity calculation, not a wet-process recipe. Blanket WER, "
    "neutral-HF transport, and solid site density retain literature provenance; "
    "product inhibition, product diffusivity ratio, and passivation theta/tau "
    "are explicit uncalibrated hypotheses."
)


@dataclass(frozen=True)
class ProductPassivationScenario:
    key: str
    description: str
    product_generation_enabled: bool
    product_diffusivity_over_hf: float = 1.0
    product_inhibition_c50_over_reference: float | None = None
    passivation_equilibrium_at_reference: float = 0.0
    passivation_tau_over_planar_clear: float = 0.1
    assumption: str = ""

    def __post_init__(self) -> None:
        if not self.key:
            raise ValueError("scenario key cannot be empty")
        if (
            not math.isfinite(self.product_diffusivity_over_hf)
            or self.product_diffusivity_over_hf <= 0.0
        ):
            raise ValueError("product diffusivity ratio must be positive")
        if self.product_inhibition_c50_over_reference is not None and (
            not math.isfinite(self.product_inhibition_c50_over_reference)
            or self.product_inhibition_c50_over_reference <= 0.0
        ):
            raise ValueError("product C50 ratio must be positive when provided")
        theta = float(self.passivation_equilibrium_at_reference)
        if not math.isfinite(theta) or not 0.0 <= theta < 1.0:
            raise ValueError("passivation equilibrium must lie within [0, 1)")
        if (
            not math.isfinite(self.passivation_tau_over_planar_clear)
            or self.passivation_tau_over_planar_clear <= 0.0
        ):
            raise ValueError("passivation tau ratio must be positive")

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


PRODUCT_PASSIVATION_SCENARIOS: Mapping[str, ProductPassivationScenario] = (
    MappingProxyType(
        {
            item.key: item
            for item in (
                ProductPassivationScenario(
                    key="null",
                    description="literature blanket-rate null model",
                    product_generation_enabled=False,
                    assumption="no dissolved product and no passivation",
                ),
                ProductPassivationScenario(
                    key="product_transport",
                    description="stoichiometric dissolved-Si field without feedback",
                    product_generation_enabled=True,
                    assumption=(
                        "D_product = D_HF; dissolved-Si equivalent is diagnostic only"
                    ),
                ),
                ProductPassivationScenario(
                    key="product_inhibition",
                    description="product directly inhibits the coupled interface law",
                    product_generation_enabled=True,
                    product_inhibition_c50_over_reference=1.0,
                    assumption=(
                        "C50 equals the planar full-depth reference product concentration"
                    ),
                ),
                ProductPassivationScenario(
                    key="reversible_passivation",
                    description="moderate reversible product-driven passivation",
                    product_generation_enabled=True,
                    passivation_equilibrium_at_reference=0.5,
                    passivation_tau_over_planar_clear=0.1,
                    assumption=(
                        "theta_eq=0.5 at C_product,ref and tau=0.1 planar-clear time"
                    ),
                ),
                ProductPassivationScenario(
                    key="product_plus_passivation",
                    description=(
                        "slow product escape, direct inhibition, and strong passivation"
                    ),
                    product_generation_enabled=True,
                    product_diffusivity_over_hf=0.1,
                    product_inhibition_c50_over_reference=1.0,
                    passivation_equilibrium_at_reference=0.8,
                    passivation_tau_over_planar_clear=0.1,
                    assumption=(
                        "D_product/D_HF=0.1, C50/Cref=1, theta_eq=0.8, "
                        "tau/t_clear=0.1"
                    ),
                ),
            )
        }
    )
)


@dataclass(frozen=True)
class ProductPassivationSweepConfig:
    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    presets: tuple[str, ...] = nominal_preset_names()
    scenarios: tuple[str, ...] = tuple(PRODUCT_PASSIVATION_SCENARIOS)
    target_remaining_fractions: tuple[float, ...] = (0.50, 0.10)
    sample_time_over_planar_clear: tuple[float, ...] = (0.50, 1.0, 2.0)
    sample_times_s: tuple[float, ...] = ()
    grid_spacing_nm: float = 1.0
    reservoir_height_nm: float = 10.0
    maximum_fractional_front_change: float = 0.50
    solution_bulk_temperature_K: float = 298.15
    substrate_backside_temperature_K: float = 298.15
    parallel_workers: int = 1

    def __post_init__(self) -> None:
        if not self.geometries or not self.presets or not self.scenarios:
            raise ValueError("geometry, preset, and scenario selections cannot be empty")
        unknown_geometry = set(self.geometries).difference(GEOMETRY_PRESETS)
        unknown_preset = set(self.presets).difference(LITERATURE_ETCH_PRESETS)
        unknown_scenario = set(self.scenarios).difference(
            PRODUCT_PASSIVATION_SCENARIOS
        )
        if unknown_geometry:
            raise ValueError(f"unknown geometries: {sorted(unknown_geometry)}")
        if unknown_preset:
            raise ValueError(f"unknown presets: {sorted(unknown_preset)}")
        if unknown_scenario:
            raise ValueError(f"unknown scenarios: {sorted(unknown_scenario)}")
        targets = tuple(float(value) for value in self.target_remaining_fractions)
        if not targets or any(
            not math.isfinite(value) or not 0.0 < value < 1.0
            for value in targets
        ):
            raise ValueError("remaining-fraction targets must lie within (0, 1)")
        times = tuple(float(value) for value in self.sample_time_over_planar_clear)
        if not times or any(not math.isfinite(value) or value <= 0.0 for value in times):
            raise ValueError("normalised sample times must be positive")
        absolute_times = tuple(float(value) for value in self.sample_times_s)
        if any(
            not math.isfinite(value) or value <= 0.0
            for value in absolute_times
        ):
            raise ValueError("absolute sample times must be positive")
        object.__setattr__(
            self,
            "target_remaining_fractions",
            tuple(sorted(set(targets), reverse=True)),
        )
        object.__setattr__(
            self,
            "sample_time_over_planar_clear",
            tuple(sorted(set(times))),
        )
        object.__setattr__(
            self,
            "sample_times_s",
            tuple(sorted(set(absolute_times))),
        )
        for name in (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "maximum_fractional_front_change",
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.maximum_fractional_front_change > 1.0:
            raise ValueError("maximum fractional front change cannot exceed one")
        if not isinstance(self.parallel_workers, int) or self.parallel_workers < 1:
            raise ValueError("parallel_workers must be a positive integer")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for key in (
            "geometries",
            "presets",
            "scenarios",
            "target_remaining_fractions",
            "sample_time_over_planar_clear",
            "sample_times_s",
        ):
            result[key] = list(getattr(self, key))
        return result


@dataclass(frozen=True)
class CoupledLiteratureInterfaceLaw:
    """One modifier shared by front velocity and the lagged HF Robin sink."""

    reference_velocity_nm_s: float
    reference_hf_mol_m3: float
    product_c50_mol_m3: float | None = None

    def __post_init__(self) -> None:
        for name in ("reference_velocity_nm_s", "reference_hf_mol_m3"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be positive")
        if self.product_c50_mol_m3 is not None and (
            not math.isfinite(self.product_c50_mol_m3)
            or self.product_c50_mol_m3 <= 0.0
        ):
            raise ValueError("product C50 must be positive when provided")

    def reactivity_modifier(
        self,
        product: np.ndarray,
        passivation: np.ndarray,
        interface: np.ndarray,
    ) -> np.ndarray:
        product_field = np.asarray(product, dtype=float)
        passivation_field = np.asarray(passivation, dtype=float)
        if np.any(~np.isfinite(product_field)) or np.any(product_field < 0.0):
            raise ValueError("product must be finite and non-negative")
        if np.any(~np.isfinite(passivation_field)) or np.any(
            passivation_field < 0.0
        ):
            raise ValueError("passivation must be finite and non-negative")
        inhibition = np.ones(np.broadcast_shapes(product_field.shape, interface.shape))
        if self.product_c50_mol_m3 is not None:
            inhibition = 1.0 / (
                1.0 + product_field / self.product_c50_mol_m3
            )
        modifier = inhibition * np.clip(1.0 - passivation_field, 0.0, 1.0)
        return np.where(interface, modifier, 1.0)

    def __call__(
        self,
        reactant: np.ndarray,
        product: np.ndarray,
        passivation: np.ndarray,
        interface: np.ndarray,
    ) -> np.ndarray:
        modifier = self.reactivity_modifier(product, passivation, interface)
        velocity = (
            self.reference_velocity_nm_s
            * np.asarray(reactant, dtype=float)
            / self.reference_hf_mol_m3
            * modifier
        )
        if np.any(~np.isfinite(velocity)) or np.any(velocity < 0.0):
            raise ValueError("coupled interface velocity must be finite and non-negative")
        return np.where(interface, velocity, 0.0)


def get_product_passivation_scenario(name: str) -> ProductPassivationScenario:
    try:
        return PRODUCT_PASSIVATION_SCENARIOS[name]
    except KeyError as exc:
        choices = ", ".join(PRODUCT_PASSIVATION_SCENARIOS)
        raise ValueError(f"unknown scenario {name!r}; choose from {choices}") from exc


def characteristic_product_concentration_mol_m3(
    preset: LiteratureEtchPreset,
    depth_nm: float,
) -> float:
    """Planar full-depth diffusion estimate C*=rho_Si v H / D_HF."""

    depth = float(depth_nm)
    if not math.isfinite(depth) or depth <= 0.0:
        raise ValueError("depth_nm must be positive")
    return (
        preset.solid_si_site_density_mol_m3
        * preset.planar_rate_nm_s
        * depth
        / HF_DIFFUSIVITY_298_NM2_S
    )


def _numerics(config: ProductPassivationSweepConfig) -> NumericalSettings:
    return NumericalSettings(
        linear_relative_tolerance=LOOSE_NUMERICS.linear_relative_tolerance,
        linear_absolute_tolerance=LOOSE_NUMERICS.linear_absolute_tolerance,
        nonlinear_relative_tolerance=LOOSE_NUMERICS.nonlinear_relative_tolerance,
        steady_state_relative_tolerance=LOOSE_NUMERICS.steady_state_relative_tolerance,
        mass_balance_relative_tolerance=LOOSE_NUMERICS.mass_balance_relative_tolerance,
        maximum_iterations=LOOSE_NUMERICS.maximum_iterations,
        maximum_nonlinear_iterations=LOOSE_NUMERICS.maximum_nonlinear_iterations,
        maximum_fractional_state_change=config.maximum_fractional_front_change,
        minimum_time_step_s=LOOSE_NUMERICS.minimum_time_step_s,
        maximum_time_step_s=LOOSE_NUMERICS.maximum_time_step_s,
    )


def _build_model(
    geometry_name: str,
    preset: LiteratureEtchPreset,
    scenario: ProductPassivationScenario,
    config: ProductPassivationSweepConfig,
) -> tuple[GapFillEtch2D, dict[str, float | None]]:
    geometry = get_geometry_preset(geometry_name)
    clear_time = geometry.depth_nm / preset.planar_rate_nm_s
    product_reference = characteristic_product_concentration_mol_m3(
        preset, geometry.depth_nm
    )
    product_c50 = (
        scenario.product_inhibition_c50_over_reference * product_reference
        if scenario.product_inhibition_c50_over_reference is not None
        else None
    )
    theta = scenario.passivation_equilibrium_at_reference
    tau = scenario.passivation_tau_over_planar_clear * clear_time
    formation = theta / (product_reference * tau) if theta > 0.0 else 0.0
    removal = (1.0 - theta) / tau if theta > 0.0 else 0.0
    hf_bulk = preset.hf_speciation().neutral_hf_mol_m3
    law = CoupledLiteratureInterfaceLaw(
        reference_velocity_nm_s=preset.planar_rate_nm_s,
        reference_hf_mol_m3=hf_bulk,
        product_c50_mol_m3=product_c50,
    )
    process = EtchProcessConfig(
        geometry=geometry,
        gap_fill_material=preset.material,
        thermal_bc=ThermalBoundaryConditions(
            solution_bulk_temperature_K=config.solution_bulk_temperature_K,
            substrate_backside_temperature_K=config.substrate_backside_temperature_K,
        ),
    )
    model = GapFillEtch2D(
        process,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=max(2.0, config.grid_spacing_nm),
        transport=TransportParameters(
            reactant_diffusivity_nm2_s=HF_DIFFUSIVITY_298_NM2_S,
            product_diffusivity_nm2_s=(
                scenario.product_diffusivity_over_hf
                * HF_DIFFUSIVITY_298_NM2_S
            ),
            reactant_bulk_concentration=hf_bulk,
            reactant_surface_transfer_nm_s=(
                preset.first_order_surface_transfer_nm_s()
            ),
            product_bulk_concentration=0.0,
            product_yield_concentration=(
                preset.solid_si_site_density_mol_m3
                if scenario.product_generation_enabled
                else 0.0
            ),
            product_bulk_decay_per_s=0.0,
        ),
        passivation=PassivationParameters(
            formation_per_concentration_s=formation,
            removal_per_s=removal,
        ),
        rate_law=law,
        reactant_sink_modifier_law=law.reactivity_modifier,
        numerical_settings=_numerics(config),
        solid_density_g_cm3=preset.solid_density_g_cm3,
    )
    return model, {
        "planar_clear_time_s": clear_time,
        "product_reference_concentration_mol_m3": product_reference,
        "product_c50_mol_m3": product_c50,
        "passivation_formation_per_mol_m3_s": formation,
        "passivation_removal_per_s": removal,
        "passivation_tau_s": tau if theta > 0.0 else None,
    }


def _field_summary(model: GapFillEtch2D) -> dict[str, float]:
    interface = model.front.interface_mask
    product_interface = interface_average_on_solid(
        model.product_field,
        model.front.liquid_mask,
        model.front.solid_mask,
    )
    if np.any(interface):
        mean_product = float(np.mean(product_interface[interface]))
        maximum_product = float(np.max(product_interface[interface], initial=0.0))
        mean_passivation = float(np.mean(model.passivation_field[interface]))
        maximum_passivation = float(
            np.max(model.passivation_field[interface], initial=0.0)
        )
        sink_modifier = model.reactant_surface_transfer_for_current_state_nm_s()
        static_sink = model.reactant_surface_transfer_field_nm_s
        ratios = np.divide(
            sink_modifier[interface],
            static_sink[interface],
            out=np.ones(np.count_nonzero(interface), dtype=float),
            where=static_sink[interface] > 0.0,
        )
        mean_sink_modifier = float(np.mean(ratios))
    else:
        mean_product = maximum_product = 0.0
        mean_passivation = maximum_passivation = 0.0
        mean_sink_modifier = 1.0
    return {
        "maximum_product_mol_m3": maximum_product,
        "mean_interface_product_mol_m3": mean_product,
        "maximum_passivation": maximum_passivation,
        "mean_interface_passivation": mean_passivation,
        "mean_reactant_sink_modifier": mean_sink_modifier,
    }


def _depth_profile(model: GapFillEtch2D) -> dict[str, list[float]]:
    rows = (model.grid.depth_nm >= 0.0) & (
        model.grid.depth_nm <= model.grid.geometry.depth_nm
    )
    cavity = model.grid.cavity_mask[rows]
    solid = model.front.solid_fraction[rows]
    width = np.sum(cavity, axis=1) * model.grid.dx_nm
    remaining = np.sum(solid * cavity, axis=1) * model.grid.dx_nm
    fraction = np.divide(
        remaining, width, out=np.zeros_like(remaining), where=width > 0.0
    )
    return {
        "depth_nm": [float(value) for value in model.grid.depth_nm[rows]],
        "remaining_row_fraction": [float(value) for value in fraction],
    }


def _checkpoint(
    model: GapFillEtch2D,
    clear_time_s: float,
    *,
    kind: str,
    requested_value: float,
) -> dict[str, object]:
    diagnostics = model.front.diagnostics()
    topology = analyse_residue_topology(model.front)
    return {
        "kind": kind,
        "requested_value": requested_value,
        "time_s": diagnostics.time_s,
        "time_over_planar_clear": diagnostics.time_s / clear_time_s,
        "remaining_mass_fraction": diagnostics.remaining_mass_fraction,
        "fields": _field_summary(model),
        "residue": topology.to_dict(),
        "depth_profile": _depth_profile(model),
    }


def run_product_passivation_case(
    geometry_name: str,
    preset_name: str,
    scenario_name: str,
    config: ProductPassivationSweepConfig,
) -> dict[str, object]:
    preset = get_literature_preset(preset_name)
    scenario = get_product_passivation_scenario(scenario_name)
    model, derived = _build_model(geometry_name, preset, scenario, config)
    initial = model.front.diagnostics()
    clear_time = float(derived["planar_clear_time_s"])
    requested_absolute_times = tuple(config.sample_times_s)
    maximum_time = max(
        max(config.sample_time_over_planar_clear) * clear_time,
        max(requested_absolute_times, default=0.0),
    )
    requested_dt = clear_time / 50.0
    fraction_checkpoints: dict[float, dict[str, object]] = {}
    time_checkpoints: dict[float, dict[str, object]] = {}
    absolute_time_checkpoints: dict[float, dict[str, object]] = {}
    maximum_product = 0.0
    maximum_passivation = 0.0
    history = []
    maximum_steps = 50_000
    while (
        model.front.time_s < maximum_time
        and np.any(model.front.solid_mask)
        and len(history) < maximum_steps
    ):
        pending_times = [
            value * clear_time
            for value in config.sample_time_over_planar_clear
            if value not in time_checkpoints
            and value * clear_time > model.front.time_s + 1.0e-12
        ]
        pending_times.extend(
            value
            for value in requested_absolute_times
            if value not in absolute_time_checkpoints
            and value > model.front.time_s + 1.0e-12
        )
        next_time = min(pending_times, default=maximum_time)
        dt = min(requested_dt, next_time - model.front.time_s, maximum_time - model.front.time_s)
        if dt <= 0.0:
            break
        entry = model.step(dt)
        history.append(entry)
        maximum_product = max(maximum_product, entry.maximum_product)
        maximum_passivation = max(
            maximum_passivation,
            entry.mean_interface_passivation,
            float(np.max(model.passivation_field, initial=0.0)),
        )
        diagnostics = model.front.diagnostics()
        for target in config.target_remaining_fractions:
            if (
                target not in fraction_checkpoints
                and diagnostics.remaining_mass_fraction <= target
            ):
                fraction_checkpoints[target] = _checkpoint(
                    model,
                    clear_time,
                    kind="remaining_fraction",
                    requested_value=target,
                )
        for normalised_time in config.sample_time_over_planar_clear:
            target_time = normalised_time * clear_time
            if (
                normalised_time not in time_checkpoints
                and model.front.time_s >= target_time - 1.0e-9 * clear_time
            ):
                time_checkpoints[normalised_time] = _checkpoint(
                    model,
                    clear_time,
                    kind="time_over_planar_clear",
                    requested_value=normalised_time,
                )
        for absolute_time_s in requested_absolute_times:
            if (
                absolute_time_s not in absolute_time_checkpoints
                and model.front.time_s >= absolute_time_s
                - 1.0e-9 * max(clear_time, absolute_time_s)
            ):
                absolute_time_checkpoints[absolute_time_s] = _checkpoint(
                    model,
                    clear_time,
                    kind="time_s",
                    requested_value=absolute_time_s,
                )

    final = model.front.diagnostics()
    fraction_payload = [
        fraction_checkpoints.get(
            target,
            {
                "kind": "remaining_fraction",
                "requested_value": target,
                "reached": False,
                "final_remaining_mass_fraction": final.remaining_mass_fraction,
                "final_time_s": final.time_s,
            },
        )
        for target in config.target_remaining_fractions
    ]
    time_payload = [
        time_checkpoints.get(
            target,
            {
                "kind": "time_over_planar_clear",
                "requested_value": target,
                "reached": False,
                "completed_before_sample": not np.any(model.front.solid_mask),
                "final_time_s": final.time_s,
            },
        )
        for target in config.sample_time_over_planar_clear
    ]
    absolute_time_payload = [
        absolute_time_checkpoints.get(
            target,
            {
                "kind": "time_s",
                "requested_value": target,
                "reached": False,
                "completed_before_sample": not np.any(model.front.solid_mask),
                "final_time_s": final.time_s,
            },
        )
        for target in requested_absolute_times
    ]
    for item in fraction_payload + time_payload + absolute_time_payload:
        item.setdefault("reached", True)
    return {
        "case_id": f"{geometry_name}__{preset_name}__{scenario_name}",
        "geometry": model.grid.geometry.to_dict(),
        "preset_key": preset.key,
        "material": preset.material,
        "planar_rate_nm_min": preset.planar_rate_nm_min,
        "scenario": scenario.to_dict(),
        "derived_parameters": derived,
        "boundary_temperatures_K": {
            "solution_bulk": config.solution_bulk_temperature_K,
            "substrate_backside": config.substrate_backside_temperature_K,
            "kinetic_temperature_correction_applied": False,
        },
        "grid": {
            "shape": list(model.grid.shape),
            "dx_nm": model.grid.dx_nm,
            "dz_nm": model.grid.dz_nm,
            "initial_area_discretization_relative_error": (
                initial.initial_area_discretization_relative_error
            ),
        },
        "steps": len(history),
        "completed": not np.any(model.front.solid_mask),
        "terminated_by_step_limit": len(history) >= maximum_steps,
        "final_time_s": final.time_s,
        "final_time_over_planar_clear": final.time_s / clear_time,
        "final_remaining_mass_fraction": final.remaining_mass_fraction,
        "maximum_product_mol_m3": maximum_product,
        "maximum_passivation": maximum_passivation,
        "fraction_checkpoints": fraction_payload,
        "time_checkpoints": time_payload,
        "absolute_time_checkpoints": absolute_time_payload,
        "convergence": {
            "reactant": all(item.reactant_converged for item in history),
            "product": all(item.product_converged for item in history),
            "nonlinear": all(item.nonlinear_converged for item in history),
            "maximum_reactant_relative_residual": max(
                (item.reactant_relative_residual for item in history), default=0.0
            ),
            "maximum_product_relative_residual": max(
                (item.product_relative_residual for item in history), default=0.0
            ),
            "maximum_front_mass_balance_relative_error": max(
                (item.front_mass_balance_relative_error for item in history),
                default=0.0,
            ),
            "maximum_product_inventory_balance_relative_error": max(
                (
                    item.product_inventory_balance_relative_error
                    for item in history
                ),
                default=0.0,
            ),
        },
        "inventory_scope": {
            "product_definition": "dissolved-Si equivalent",
            "product_yield_mol_per_mol_Si": (
                1.0 if scenario.product_generation_enabled else 0.0
            ),
            "front_and_HF_sink_share_reactivity_modifier": True,
            "HF_sink_product_value_is_lagged_one_accepted_step": True,
            "explicit_product_flux_balance_diagnostic": True,
            "product_inventory_rate_units": (
                "concentration * nm2 / s per unit out-of-plane span"
            ),
            "persistent_deposit_phase": False,
        },
    }


_WORKER_THREAD_LIMITER = None


def _initialise_worker() -> None:
    global _WORKER_THREAD_LIMITER
    try:
        from threadpoolctl import threadpool_limits
    except ImportError:
        return
    _WORKER_THREAD_LIMITER = threadpool_limits(limits=1)


def _run_case_tuple(
    values: tuple[str, str, str, ProductPassivationSweepConfig],
) -> dict[str, object]:
    return run_product_passivation_case(*values)


def run_product_passivation_sweep(
    config: ProductPassivationSweepConfig | None = None,
) -> dict[str, object]:
    resolved = config or ProductPassivationSweepConfig()
    inputs = [
        (geometry, preset, scenario, resolved)
        for geometry in resolved.geometries
        for preset in resolved.presets
        for scenario in resolved.scenarios
    ]
    workers = min(resolved.parallel_workers, len(inputs))
    if workers == 1:
        cases = [_run_case_tuple(item) for item in inputs]
    else:
        variables = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
        previous = {name: os.environ.get(name) for name in variables}
        for name in variables:
            os.environ[name] = "1"
        try:
            with ProcessPoolExecutor(
                max_workers=workers,
                initializer=_initialise_worker,
            ) as executor:
                cases = list(executor.map(_run_case_tuple, inputs))
        finally:
            for name, value in previous.items():
                if value is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = value
    return {
        "model": "2-D dissolved-product and passivation mechanism sweep",
        "notice": PRODUCT_PASSIVATION_NOTICE,
        "calibrated_product_or_passivation_parameters": False,
        "config": resolved.to_dict(),
        "parallel_execution": {
            "requested_workers": resolved.parallel_workers,
            "effective_workers": workers,
            "case_count": len(inputs),
            "case_order_preserved": True,
        },
        "cases": cases,
    }


__all__ = [
    "CoupledLiteratureInterfaceLaw",
    "PRODUCT_PASSIVATION_NOTICE",
    "PRODUCT_PASSIVATION_SCENARIOS",
    "ProductPassivationScenario",
    "ProductPassivationSweepConfig",
    "characteristic_product_concentration_mol_m3",
    "get_product_passivation_scenario",
    "run_product_passivation_case",
    "run_product_passivation_sweep",
]

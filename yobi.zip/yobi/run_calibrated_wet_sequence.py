#!/usr/bin/env python3
"""Run exact primary-HF endpoint through rinse/dry/second-WET branches."""

from __future__ import annotations

import argparse
import os
from dataclasses import replace
from pathlib import Path

from calibrated_wet_sequence import (
    BRANCH_ACCESSIBLE_SCALED,
    BRANCH_ALL_PHYSICAL,
    CalibratedWetSequenceConfig,
    run_calibrated_wet_sequence,
    save_calibrated_wet_sequence_csv,
    save_calibrated_wet_sequence_json,
)
from literature_sweep import nominal_preset_names
from primary_hf_endpoint import load_blanket_rate_csv


RESULT_NAME = "calibrated_wet_sequence_results.json"
CSV_NAME = "calibrated_wet_sequence_table.csv"
README_NAME = "README_JA.md"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Stop a blanket-clock-calibrated primary-HF graph at an exact "
            "remaining-fraction endpoint, then continue the live state "
            "through rinse, dry-down and second-WET collector branches."
        )
    )
    parser.add_argument(
        "--mode",
        choices=("smoke", "quick", "full"),
        default="quick",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="worker processes; 0 selects up to eight automatically",
    )
    parser.add_argument(
        "--target-remaining",
        type=float,
        default=0.01,
        help="exact original GAP FILL remaining-fraction endpoint",
    )
    parser.add_argument(
        "--blanket-csv",
        type=Path,
        default=None,
        help=(
            "optional measured preset_id,rate_nm_min,"
            "measurement_temperature_K and optional uncertainty_nm_min,"
            "source_note CSV"
        ),
    )
    parser.add_argument(
        "--liquid-temperature-K",
        type=float,
        default=298.15,
    )
    parser.add_argument(
        "--substrate-temperature-K",
        type=float,
        default=298.15,
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/calibrated_wet_sequence"),
    )
    return parser


def config_for_mode(
    mode: str,
    workers: int,
    *,
    target_remaining_fraction: float = 0.01,
    liquid_temperature_K: float = 298.15,
    substrate_temperature_K: float = 298.15,
) -> CalibratedWetSequenceConfig:
    common = {
        "primary_target_remaining_fraction": target_remaining_fraction,
        "solution_temperature_K": liquid_temperature_K,
        "substrate_temperature_K": substrate_temperature_K,
    }
    if mode == "smoke":
        config = CalibratedWetSequenceConfig(
            geometries=("10_10_180",),
            presets=("sin_barcellona_b_0p55wt",),
            scenarios=("transport_only",),
            replicate_seeds=(17,),
            grid_spacing_nm=20.0,
            reservoir_height_nm=20.0,
            lateral_margin_nm=0.0,
            primary_sync_steps=4,
            maximum_events=5_000,
            coupon_width_nm=40.0,
            coupon_depth_nm=60.0,
            coupon_maximum_events=5_000,
            surface_profile_bins=6,
            **common,
        )
    elif mode == "quick":
        config = CalibratedWetSequenceConfig(**common)
    elif mode == "full":
        config = CalibratedWetSequenceConfig(
            presets=tuple(sorted(nominal_preset_names()))
            + (
                "sin_barcellona_a_0p55wt",
                "sin_barcellona_c_0p55wt",
                "siocn_fujitsu_4a_100to1",
                "siocn_fujitsu_4d_100to1",
            ),
            replicate_seeds=(271828, 314159, 161803, 141421, 173205),
            grid_spacing_nm=1.4,
            primary_sync_steps=90,
            maximum_events=120_000,
            coupon_width_nm=28.0,
            coupon_depth_nm=56.0,
            coupon_maximum_events=30_000,
            surface_profile_bins=32,
            **common,
        )
    else:
        raise ValueError("mode must be smoke, quick or full")
    requested = (
        len(config.geometries)
        * len(config.presets)
        * len(config.scenarios)
        * len(config.replicate_seeds)
    )
    resolved = (
        min(8, os.cpu_count() or 1, requested)
        if workers == 0
        else min(workers, requested)
    )
    if resolved < 1:
        raise ValueError("workers must be non-negative")
    return replace(config, parallel_workers=resolved)


def _result_lines(payload: dict[str, object]) -> list[str]:
    cases = [
        case
        for case in payload.get("cases", [])
        if case.get("collector_branch_id") == BRANCH_ALL_PHYSICAL
    ]
    lines = []
    keys = list(
        dict.fromkeys(
            (
                case["geometry_id"],
                case["material"],
                case["scenario"],
            )
            for case in cases
        )
    )
    for geometry_id, material, scenario in keys:
        subset = [
            case
            for case in cases
            if case["geometry_id"] == geometry_id
            and case["material"] == material
            and case["scenario"] == scenario
        ]
        endpoint_min = [
            float(case["primary_endpoint"]["endpoint_physical_time_s"])
            / 60.0
            for case in subset
        ]
        final = [
            100.0
            * float(
                case["final_metrics"][
                    "second_wet_combined_residue_fraction"
                ]
            )
            for case in subset
        ]
        contrasts = [
            item
            for item in payload.get("paired_branch_contrasts", [])
            if item.get("geometry_id") == geometry_id
            and item.get("material") == material
            and item.get("scenario") == scenario
            and "area_scaled_lower_to_upper_inventory_ratio" in item
        ]
        lower_ratio = [
            float(item["area_scaled_lower_to_upper_inventory_ratio"])
            for item in contrasts
        ]
        if not endpoint_min:
            continue
        endpoint_display = sum(endpoint_min) / len(endpoint_min)
        final_display = sum(final) / len(final)
        lower_display = (
            "n/a"
            if not lower_ratio
            else f"{100.0 * sum(lower_ratio) / len(lower_ratio):.1f}%"
        )
        lines.append(
            f"- {geometry_id} / {material} / {scenario}: "
            f"一次HF終点 {endpoint_display:.1f} min; "
            f"second-WET後combined残渣 {final_display:.3f}%; "
            f"面積scale量下限/上限析出量 {lower_display}"
        )
    return lines


def write_readme(payload: dict[str, object], path: Path) -> Path:
    quality = payload["quality_summary"]
    lines = [
        "# 校正一次HF → rinse → dry-down → second-WET",
        "",
        "一次HFをblanket-WER物理clockの厳密event endpointで停止し、"
        "同じlive graph/fieldを後段へ渡した計算です。",
        "",
        f"- coupon成功: {quality['successful_coupon_runs']}/"
        f"{quality['expected_coupon_runs']}",
        f"- 後段実行strata: {quality['executed_downstream_strata']}",
        f"- endpoint未到達によるskip: {quality['skipped_censored_strata']}",
        f"- primary失敗: {quality['failed_primary_strata']}",
        f"- branch成功: {quality['successful_branch_cases']}",
        f"- mass balance失敗: {quality['mass_balance_failure_cases']}",
        f"- fixed-inventory pair不一致: "
        f"{quality['fixed_inventory_pair_mismatch_count']}",
        "",
        "## 代表集計",
        "",
        *_result_lines(payload),
        "",
        "## collector枝の意味",
        "",
        "- `all_physical_fixed_inventory`: 全wall/bottomへ配分する空間上限。",
        "- `endpoint_accessible_fixed_inventory`: 捕捉量は同じで、一次HF終点の液アクセス面だけへ再配分。",
        "- `all_physical_area_scaled_reference`: 面積scale比較用の上限参照。",
        "- `endpoint_accessible_area_scaled`: 液アクセスweighted面積に比例して捕捉量も下げる量下限仮説。",
        "- fixed-inventory比較は総析出量の上下限ではなく、付着位置・局所密度のbracketです。",
        "",
        "## 解釈境界",
        "",
        "- endpoint未到達、event上限、非収束状態から後段を自動生成しません。",
        "- endpoint瞬間product場と累積生成poolは別保存し、dry-downで二重計上しません。",
        "- graph second-WETは一次HF blanket clockを暫定再利用し、独立校正済みではありません。",
        "- Si/liner loss、CD loss、粗さ、検出限界を含まないためrecipeではありません。",
        "",
        "## 成果物",
        "",
        f"- `{RESULT_NAME}`: live lineage、全stage、全branch、mask/profile",
        f"- `{CSV_NAME}`: branch別平坦表",
        "- `calibrated_wet_stage_envelope.png`: stage別元膜・析出・合計",
        "- `collector_accessibility_comparison.png`: collector枝のpaired比較",
        "- `calibrated_wet_sequence_masks.png`: 実寸stage断面",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def quality_exit_code(quality: dict[str, object]) -> int:
    failures = sum(
        int(quality.get(key, 0))
        for key in (
            "failed_coupon_runs",
            "failed_primary_strata",
            "mass_balance_failure_cases",
            "fixed_inventory_pair_mismatch_count",
        )
    )
    return 0 if failures == 0 else 1


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    config = config_for_mode(
        args.mode,
        args.workers,
        target_remaining_fraction=args.target_remaining,
        liquid_temperature_K=args.liquid_temperature_K,
        substrate_temperature_K=args.substrate_temperature_K,
    )
    if args.blanket_csv is not None:
        overrides = load_blanket_rate_csv(args.blanket_csv)
        unknown = set(overrides).difference(config.presets)
        if unknown:
            raise ValueError(
                "blanket CSV contains presets outside this mode: "
                f"{sorted(unknown)}"
            )
        config = replace(config, blanket_rate_inputs=overrides)

    payload = run_calibrated_wet_sequence(config)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = save_calibrated_wet_sequence_json(
        payload, args.output_dir / RESULT_NAME
    )
    csv_path = save_calibrated_wet_sequence_csv(
        payload, args.output_dir / CSV_NAME
    )

    from calibrated_wet_sequence_visualization import (
        plot_calibrated_wet_sequence_visualizations,
    )

    figures = plot_calibrated_wet_sequence_visualizations(
        payload, args.output_dir
    )
    payload["artifacts"] = {
        **{key: value.name for key, value in figures.items()},
        "table_csv": csv_path.name,
        "readme": README_NAME,
    }
    readme_path = write_readme(payload, args.output_dir / README_NAME)
    json_path = save_calibrated_wet_sequence_json(payload, json_path)

    quality = payload["quality_summary"]
    print(f"mode: {args.mode}")
    print(
        "primary downstream executed/skipped/failed: "
        f"{quality['executed_downstream_strata']}/"
        f"{quality['skipped_censored_strata']}/"
        f"{quality['failed_primary_strata']}"
    )
    print(
        "branch cases/mass failures: "
        f"{quality['successful_branch_cases']}/"
        f"{quality['mass_balance_failure_cases']}"
    )
    print(f"JSON: {json_path}")
    print(f"CSV: {csv_path}")
    print(f"README: {readme_path}")
    for key, value in figures.items():
        print(f"{key}: {value}")
    return quality_exit_code(quality)


if __name__ == "__main__":
    raise SystemExit(main())

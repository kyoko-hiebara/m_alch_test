#!/usr/bin/env python3
"""Run the targeted multicore dry-down / surface-affinity sweep."""

from __future__ import annotations

import argparse
from dataclasses import replace
import os
from pathlib import Path


for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ[_thread_variable] = "1"


from attachment_discrimination import (  # noqa: E402
    AttachmentDiscriminationConfig,
    run_attachment_discrimination,
    save_attachment_contrast_csv,
    save_attachment_discrimination_csv,
    save_attachment_discrimination_json,
)
from attachment_discrimination_visualization import (  # noqa: E402
    plot_attachment_discrimination_visualizations,
)


RESULT_NAME = "attachment_discrimination_results.json"
CSV_NAME = "attachment_discrimination_cases.csv"
CONTRAST_CSV_NAME = "attachment_probe_contrasts.csv"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Separate dry-down capture amount from wall/bottom allocation, "
            "preserving HF/rinse/dry/second-WET endpoints and mass balances."
        )
    )
    parser.add_argument(
        "--mode",
        choices=("smoke", "quick", "full"),
        default="quick",
        help=(
            "smoke=coarse one-seed code check; quick=10x180 and 7x170 nm/"
            "two seeds/5x5 maps; full=the two target trenches plus 8x175 nm/"
            "five seeds/7x7 maps"
        ),
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="primary-stratum worker processes; 0 selects up to eight",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/attachment_discrimination"),
        help="directory for strict JSON and flat case CSV",
    )
    return parser


def config_for_mode(mode: str, workers: int = 0) -> AttachmentDiscriminationConfig:
    if workers < 0:
        raise ValueError("workers must be zero or positive")
    if mode == "smoke":
        config = AttachmentDiscriminationConfig(
            geometries=("8_8_175",),
            replicate_seeds=(271828,),
            include_phase_maps=False,
            phase_levels=3,
            grid_spacing_nm=10.0,
            reservoir_height_nm=10.0,
            lateral_margin_nm=0.0,
            primary_hf_duration_s=30.0,
            primary_sync_steps=2,
            maximum_events=1_000,
            surface_profile_bins=12,
            parallel_workers=1,
        )
    elif mode == "quick":
        config = AttachmentDiscriminationConfig(
            geometries=("10_10_180", "7_7_170"),
            replicate_seeds=(271828, 314159),
            include_phase_maps=True,
            phase_levels=5,
            grid_spacing_nm=1.7,
            surface_profile_bins=24,
            parallel_workers=1,
        )
    elif mode == "full":
        config = AttachmentDiscriminationConfig(
            geometries=("10_10_180", "7_7_170", "8_8_175"),
            replicate_seeds=(271828, 314159, 161803, 141421, 173205),
            include_phase_maps=True,
            phase_levels=7,
            grid_spacing_nm=1.4,
            surface_profile_bins=32,
            parallel_workers=1,
        )
    else:
        raise ValueError("mode must be smoke, quick or full")

    strata = len(config.geometries) * len(config.presets) * len(config.replicate_seeds)
    resolved = (
        min(8, os.cpu_count() or 1, strata)
        if workers == 0
        else min(workers, strata)
    )
    return replace(config, parallel_workers=max(1, resolved))


def main() -> int:
    args = build_parser().parse_args()
    config = config_for_mode(args.mode, args.workers)
    payload = run_attachment_discrimination(config)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    figures = plot_attachment_discrimination_visualizations(
        payload, args.output_dir
    )
    csv_path = save_attachment_discrimination_csv(
        payload, args.output_dir / CSV_NAME
    )
    contrast_csv_path = save_attachment_contrast_csv(
        payload, args.output_dir / CONTRAST_CSV_NAME
    )
    payload["artifacts"] = {
        **{key: path.name for key, path in figures.items()},
        "case_csv": csv_path.name,
        "probe_contrast_csv": contrast_csv_path.name,
    }
    json_path = save_attachment_discrimination_json(
        payload, args.output_dir / RESULT_NAME
    )
    quality = payload["quality_summary"]
    print(f"mode: {args.mode}")
    print(
        "primary strata: "
        f"{quality['successful_primary_strata']}/"
        f"{quality['requested_primary_strata']}"
    )
    print(
        "post-HF cases: "
        f"{quality['successful_post_hf_cases']}/"
        f"{quality['requested_post_hf_cases']}"
    )
    print(f"mass-balance failures: {quality['mass_balance_failure_count']}")
    print(f"JSON: {json_path}")
    print(f"CSV: {csv_path}")
    print(f"probe contrasts: {contrast_csv_path}")
    for key, path in figures.items():
        print(f"{key}: {path}")
    return 0 if int(quality["failed_case_count"]) == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

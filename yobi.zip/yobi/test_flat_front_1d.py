from __future__ import annotations

import math
import unittest

import numpy as np

from etch_process import (
    EtchProcessConfig,
    GapFillMaterial,
    ThermalBoundaryConditions,
)
from flat_front_1d import (
    FlatFrontEtchSolver,
    IntegrationOptions,
    InterfaceKinetics,
    MassTransportParameters,
    PassivationParameters,
)
from thermal_model import ThermalResistanceModel, ThermalResistanceParameters
from trench_geometry import TaperedTrench2D, get_geometry_preset


class FlatFrontEtchSolverTests(unittest.TestCase):
    @staticmethod
    def make_solver(
        *,
        passivation: PassivationParameters | None = None,
        rate_constant_m_s: float = 1.0e-7,
        heat_release_J_mol: float = 0.0,
    ) -> FlatFrontEtchSolver:
        geometry = TaperedTrench2D("constant", 10.0, 10.0, 100.0)
        process = EtchProcessConfig(
            geometry=geometry,
            gap_fill_material=GapFillMaterial.SIN,
            thermal_bc=ThermalBoundaryConditions(298.15, 298.15),
        )
        thermal = ThermalResistanceModel(
            geometry,
            ThermalResistanceParameters(
                substrate_thickness_m=20.0e-9,
                effective_substrate_width_m=10.0e-9,
                backside_contact_resistance_m2K_W=1.0e-8,
            ),
        )
        return FlatFrontEtchSolver(
            process,
            thermal,
            MassTransportParameters(
                reactant_bulk_concentration_mol_m3=1000.0,
                reactant_diffusivity_ref_m2_s=1.0e-9,
                product_diffusivity_ref_m2_s=1.0e-9,
            ),
            InterfaceKinetics(
                rate_constant_ref_m_s=rate_constant_m_s,
                solid_molar_density_mol_m3=1000.0,
                reaction_heat_release_J_mol_solid=heat_release_J_mol,
            ),
            passivation=passivation,
            options=IntegrationOptions(
                relative_tolerance=1.0e-5,
                absolute_tolerance=1.0e-8,
                maximum_time_step_s=0.05,
            ),
        )

    def test_starts_fully_filled_and_reaches_bottom(self) -> None:
        solver = self.make_solver()
        result = solver.solve(2.0)
        self.assertEqual(result.front_depth_m[0], 0.0)
        self.assertAlmostEqual(result.residual_fill_depth_nm[0], 100.0)
        self.assertTrue(result.completed)
        self.assertIsNotNone(result.completion_time_s)
        self.assertAlmostEqual(result.completion_time_s or 0.0, 1.0, delta=0.02)
        self.assertAlmostEqual(result.front_depth_nm[-1], 100.0, places=8)
        self.assertAlmostEqual(result.residual_fill_depth_nm[-1], 0.0, places=8)
        self.assertTrue(np.all(np.diff(result.front_depth_m) >= 0.0))
        self.assertGreater(result.time_s.size, 3)
        self.assertFalse(result.time_s.flags.writeable)

    def test_quasi_steady_reactant_and_product_resistances(self) -> None:
        solver = self.make_solver()
        initial = solver.local_state(0.0, 0.0)
        middle = solver.local_state(50.0e-9, 0.0)
        self.assertEqual(initial.reactant_transport_resistance_s_m2, 0.0)
        self.assertEqual(initial.product_interface_concentration_mol_m3, 0.0)
        self.assertGreater(middle.reactant_transport_resistance_s_m2, 0.0)
        self.assertGreater(middle.product_transport_resistance_s_m2, 0.0)
        self.assertLess(
            middle.reactant_interface_concentration_mol_m3,
            solver.transport.reactant_bulk_concentration_mol_m3,
        )
        self.assertGreater(middle.product_interface_concentration_mol_m3, 0.0)
        self.assertAlmostEqual(
            middle.etch_velocity_m_s,
            middle.solid_removal_flux_mol_m2_s
            / solver.kinetics.solid_molar_density_mol_m3,
        )

    def test_tapered_width_uses_exact_integrated_diffusion_resistance(self) -> None:
        geometry = get_geometry_preset("10_8_180")
        process = EtchProcessConfig(
            geometry,
            GapFillMaterial.SIOCN,
            ThermalBoundaryConditions(300.0, 320.0),
        )
        thermal = ThermalResistanceModel(geometry)
        diffusivity = 2.0e-9
        solver = FlatFrontEtchSolver(
            process,
            thermal,
            MassTransportParameters(
                reactant_bulk_concentration_mol_m3=500.0,
                reactant_diffusivity_ref_m2_s=diffusivity,
                product_diffusivity_ref_m2_s=diffusivity,
                reference_temperature_K=300.0,
            ),
            InterfaceKinetics(1.0e-9, 5.0e4, reference_temperature_K=300.0),
        )
        bottom = solver.local_state(180.0e-9, 0.0)
        expected_shape = 180.0 / (10.0 - 8.0) * math.log(10.0 / 8.0)
        self.assertTrue(
            math.isclose(
                bottom.reactant_transport_resistance_s_m2,
                expected_shape / diffusivity,
                rel_tol=1.0e-12,
            )
        )
        self.assertAlmostEqual(bottom.front_width_m, 8.0e-9)

    def test_passivation_grows_and_slows_front(self) -> None:
        unblocked = self.make_solver()
        blocking = self.make_solver(
            passivation=PassivationParameters(
                formation_rate_ref_s_inv=2.0,
                removal_rate_ref_s_inv=0.0,
                product_order=0.0,
            )
        )
        reference = unblocked.solve(0.5)
        passivated = blocking.solve(0.5)
        self.assertGreater(passivated.passivation_fraction[-1], 0.0)
        self.assertLess(passivated.front_depth_m[-1], reference.front_depth_m[-1])
        self.assertLess(
            passivated.etch_velocity_m_s[-1],
            passivated.etch_velocity_m_s[0],
        )

    def test_reaction_heat_is_coupled_to_local_removal_flux(self) -> None:
        adiabatic_reaction = self.make_solver(heat_release_J_mol=1.0e9)
        heated = adiabatic_reaction.local_state(50.0e-9, 0.0)
        cold = self.make_solver().local_state(50.0e-9, 0.0)
        self.assertGreater(heated.interface_temperature_K, cold.interface_temperature_K)
        expected_heat_flux = (
            adiabatic_reaction.kinetics.reaction_heat_release_J_mol_solid
            * heated.solid_removal_flux_mol_m2_s
        )
        self.assertAlmostEqual(
            heated.reaction_heat_flux_W_m2,
            expected_heat_flux,
            delta=0.01 * expected_heat_flux,
        )
        self.assertAlmostEqual(
            heated.thermal_state.energy_balance_residual_W_m,
            0.0,
            places=10,
        )

    def test_zero_kinetic_rate_leaves_a_fully_filled_trench(self) -> None:
        solver = self.make_solver(rate_constant_m_s=0.0)
        result = solver.solve(0.2)
        self.assertFalse(result.completed)
        self.assertIsNone(result.completion_time_s)
        np.testing.assert_allclose(result.front_depth_m, 0.0)
        np.testing.assert_allclose(result.residual_fill_depth_nm, 100.0)

    def test_invalid_inputs_and_mismatched_geometry_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            MassTransportParameters(-1.0)
        with self.assertRaises(ValueError):
            InterfaceKinetics(1.0e-9, 0.0)
        with self.assertRaises(ValueError):
            PassivationParameters(initial_fraction=1.1)
        with self.assertRaises(ValueError):
            IntegrationOptions(maximum_time_step_s=0.0)

        solver = self.make_solver()
        with self.assertRaises(ValueError):
            solver.local_state(0.0, -0.1)
        with self.assertRaises(ValueError):
            solver.solve(0.0)

        other_geometry = TaperedTrench2D("other", 11.0, 10.0, 100.0)
        with self.assertRaisesRegex(ValueError, "same geometry"):
            FlatFrontEtchSolver(
                solver.process,
                ThermalResistanceModel(other_geometry),
                solver.transport,
                solver.kinetics,
            )


if __name__ == "__main__":
    unittest.main()

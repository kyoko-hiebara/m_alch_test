"""Adapters that connect continuum interface rates to the thermal model.

The 2-D transport/front solver works in nm and seconds, whereas the thermal
resistance model works in SI units.  This module owns that conversion and keeps
the solution-bulk and substrate-backside temperatures as independent boundary
conditions.

For a non-flat 2-D front, :class:`ThermalArrheniusRateLaw2D` applies the 1-D
thermal network independently at each exposed cell depth.  This is a local
column approximation: it does not represent lateral heat spreading or a fully
conjugate 2-D temperature field.  Reaction heat is deliberately excluded here
because applying the flat-front heat rate independently to every cell would
double count the total interface heat.  Reaction heat remains available in the
flat-front 1-D solver, where the thermal area is well defined.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from etch_process import ThermalBoundaryConditions
from reaction_diffusion_2d import CartesianGrid2D
from thermal_model import NM_TO_M, ThermalResistanceModel


GAS_CONSTANT_J_MOL_K = 8.31446261815324


def _finite_nonnegative(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    return number


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


@dataclass(frozen=True)
class ThermalArrheniusRateParameters:
    """Uncalibrated functional form for a 2-D normal-velocity law.

    Concentrations are in the caller's internally consistent units.  The
    returned normal velocity is in nm/s.
    """

    reference_maximum_velocity_nm_s: float = 1.0
    half_saturation_concentration: float = 0.1
    product_inhibition: float = 0.5
    reference_temperature_K: float = 298.15
    activation_energy_J_mol: float = 0.0

    def __post_init__(self) -> None:
        _finite_nonnegative(
            "reference_maximum_velocity_nm_s",
            self.reference_maximum_velocity_nm_s,
        )
        _finite_positive(
            "half_saturation_concentration",
            self.half_saturation_concentration,
        )
        _finite_nonnegative("product_inhibition", self.product_inhibition)
        _finite_positive("reference_temperature_K", self.reference_temperature_K)
        _finite_nonnegative("activation_energy_J_mol", self.activation_energy_J_mol)


class ThermalArrheniusRateLaw2D:
    """Evaluate a thermally activated 2-D velocity without averaging the BCs.

    The most recently evaluated temperature field is exposed for diagnostics.
    Values outside the current solid/liquid interface are ``NaN``.
    """

    def __init__(
        self,
        grid: CartesianGrid2D,
        thermal_model: ThermalResistanceModel,
        boundary_conditions: ThermalBoundaryConditions,
        parameters: ThermalArrheniusRateParameters | None = None,
    ) -> None:
        if grid.geometry != thermal_model.geometry:
            raise ValueError("grid and thermal_model must use the same geometry")
        self.grid = grid
        self.thermal_model = thermal_model
        self.boundary_conditions = boundary_conditions
        self.parameters = parameters or ThermalArrheniusRateParameters()
        self.last_interface_temperature_K = np.full(grid.shape, np.nan)

    def set_boundary_conditions(
        self, boundary_conditions: ThermalBoundaryConditions
    ) -> None:
        """Replace both external temperatures for a later WET step."""

        if not isinstance(boundary_conditions, ThermalBoundaryConditions):
            raise TypeError("boundary_conditions must be ThermalBoundaryConditions")
        self.boundary_conditions = boundary_conditions

    def _temperature_field(self, interface_mask: np.ndarray) -> np.ndarray:
        temperature = np.full(self.grid.shape, np.nan, dtype=float)
        rows, columns = np.nonzero(interface_mask)
        if len(rows) == 0:
            self.last_interface_temperature_K = temperature
            return temperature

        # All cells in a row share the same local-column thermal resistance.
        for row in np.unique(rows):
            depth_nm = float(
                np.clip(
                    self.grid.depth_nm[row],
                    0.0,
                    self.grid.geometry.depth_nm,
                )
            )
            local_temperature = self.thermal_model.interface_temperature_K(
                depth_nm * NM_TO_M,
                self.boundary_conditions,
                reaction_heat_flux_W_m2=0.0,
            )
            row_interface = interface_mask[row]
            temperature[row, row_interface] = local_temperature
        self.last_interface_temperature_K = temperature
        return temperature

    def __call__(
        self,
        reactant: np.ndarray,
        product: np.ndarray,
        passivation: np.ndarray,
        interface_mask: np.ndarray,
    ) -> np.ndarray:
        interface = np.asarray(interface_mask, dtype=bool)
        if interface.shape != self.grid.shape:
            raise ValueError("interface_mask must match the 2-D grid")
        fields = []
        for name, values in (
            ("reactant", reactant),
            ("product", product),
            ("passivation", passivation),
        ):
            field = np.broadcast_to(np.asarray(values, dtype=float), self.grid.shape)
            if np.any(~np.isfinite(field)):
                raise ValueError(f"{name} must contain only finite values")
            if np.any(field < 0.0):
                raise ValueError(f"{name} must be non-negative")
            fields.append(field)
        reactant_field, product_field, passivation_field = fields

        temperature = self._temperature_field(interface)
        velocity = np.zeros(self.grid.shape, dtype=float)
        if not np.any(interface):
            return velocity

        p = self.parameters
        exponent = -p.activation_energy_J_mol / GAS_CONSTANT_J_MOL_K * (
            1.0 / temperature[interface] - 1.0 / p.reference_temperature_K
        )
        arrhenius = np.exp(np.clip(exponent, -700.0, 700.0))
        local_reactant = reactant_field[interface]
        saturation = local_reactant / (
            p.half_saturation_concentration + local_reactant
        )
        inhibition = 1.0 / (
            1.0 + p.product_inhibition * product_field[interface]
        )
        active_fraction = np.clip(1.0 - passivation_field[interface], 0.0, 1.0)
        velocity[interface] = (
            p.reference_maximum_velocity_nm_s
            * arrhenius
            * saturation
            * inhibition
            * active_fraction
        )
        if np.any(~np.isfinite(velocity)) or np.any(velocity < 0.0):
            raise RuntimeError("thermal Arrhenius rate produced an invalid velocity")
        return velocity


__all__ = [
    "ThermalArrheniusRateLaw2D",
    "ThermalArrheniusRateParameters",
]

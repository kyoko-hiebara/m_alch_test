"""Hypothesis sweep for depth- and wall-dependent GAP-FILL residue.

Published blanket WER fixes the overall SiN/SiCN/SiOCN timescale. The spatial
factors in this file are deliberately *not* fitted values: they ask what
morphology would result if the as-deposited film were slower near the bottom,
the Si sidewall, or the trench floor.  Cases are compared at equal global
remaining fractions so a slower clock is not mistaken for wall enrichment.

This layer represents unreacted original GAP FILL (a wall rail/stringer).  It
does not represent a new solid deposited from dissolved products; a persistent
wall-deposit phase must be added separately for that mechanism.
"""

from __future__ import annotations

import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Mapping

import numpy as np

from etch_process import EtchProcessConfig, ThermalBoundaryConditions
from gapfill_etch_2d import (
    GapFillEtch2D,
    PassivationParameters,
    TransportParameters,
)
from literature_parameters import (
    HF_DIFFUSIVITY_298_NM2_S,
    LITERATURE_ETCH_PRESETS,
    LiteratureEtchPreset,
    get_literature_preset,
)
from literature_sweep import LiteratureFirstOrderRateLaw, nominal_preset_names
from numerical_settings import LOOSE_NUMERICS, NumericalSettings
from spatial_etchability import (
    SpatialEtchabilityParameters,
    analyse_residue_topology,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS, get_geometry_preset


STATIC_HYPOTHESIS_NOTICE = (
    "Static film-quality hypothesis sweep, not a fitted process model or wet "
    "recipe. Spatial multipliers are assumptions; blanket WER and HF transport "
    "retain their literature provenance."
)


@dataclass(frozen=True)
class SpatialHypothesisScenario:
    key: str
    description: str
    parameters: SpatialEtchabilityParameters
    assumption: str

    def to_dict(self) -> dict[str, object]:
        return {
            "key": self.key,
            "description": self.description,
            "parameters": self.parameters.to_dict(),
            "assumption": self.assumption,
        }


SPATIAL_HYPOTHESIS_SCENARIOS: Mapping[str, SpatialHypothesisScenario] = (
    MappingProxyType(
        {
            scenario.key: scenario
            for scenario in (
                SpatialHypothesisScenario(
                    key="uniform",
                    description="identity field; literature blanket-rate null model",
                    parameters=SpatialEtchabilityParameters(),
                    assumption="none beyond the blanket-rate null model",
                ),
                SpatialHypothesisScenario(
                    key="depth_slow",
                    description=(
                        "continuous top-to-bottom film-quality gradient; bottom "
                        "intrinsic rate is 0.2 times the top rate"
                    ),
                    parameters=SpatialEtchabilityParameters(
                        top_rate_factor=1.0,
                        bottom_rate_factor=0.2,
                        depth_exponent=1.0,
                    ),
                    assumption=(
                        "exploratory bottom/top factor 0.2; not a measured full-fill "
                        "composition profile"
                    ),
                ),
                SpatialHypothesisScenario(
                    key="floor_layer",
                    description=(
                        "slow interfacial layer localised at the trench floor"
                    ),
                    parameters=SpatialEtchabilityParameters(
                        floor_rate_factor=0.05,
                        floor_influence_length_nm=2.0,
                    ),
                    assumption=(
                        "exploratory floor factor 0.05 and 2 nm decay length; "
                        "represents adhesion/densification, not precipitation"
                    ),
                ),
                SpatialHypothesisScenario(
                    key="wall_layer",
                    description=(
                        "slow sidewall-interfacial GAP FILL that can form wall rails"
                    ),
                    parameters=SpatialEtchabilityParameters(
                        sidewall_rate_factor=0.1,
                        sidewall_influence_length_nm=1.0,
                    ),
                    assumption=(
                        "exploratory wall/core factor 0.1 and 1 nm decay length; "
                        "literature supports direction-dependent WER but not this "
                        "specific multiplier"
                    ),
                ),
                SpatialHypothesisScenario(
                    key="depth_wall_combined",
                    description=(
                        "bottom-slow gradient multiplied by a slow sidewall layer"
                    ),
                    parameters=SpatialEtchabilityParameters(
                        top_rate_factor=1.0,
                        bottom_rate_factor=0.2,
                        depth_exponent=1.0,
                        sidewall_rate_factor=0.1,
                        sidewall_influence_length_nm=1.0,
                    ),
                    assumption=(
                        "product of the depth_slow and wall_layer exploratory fields"
                    ),
                ),
            )
        }
    )
)


@dataclass(frozen=True)
class NonuniformSweepConfig:
    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    presets: tuple[str, ...] = nominal_preset_names()
    scenarios: tuple[str, ...] = tuple(SPATIAL_HYPOTHESIS_SCENARIOS)
    target_remaining_fractions: tuple[float, ...] = (0.50, 0.10, 0.05)
    grid_spacing_nm: float = 0.5
    reservoir_height_nm: float = 10.0
    sidewall_diagnostic_band_nm: float = 1.0
    bottom_diagnostic_band_nm: float = 2.0
    maximum_fractional_front_change: float = 0.50
    maximum_uniform_clear_time_multiplier: float = 12.0
    solution_bulk_temperature_K: float = 298.15
    substrate_backside_temperature_K: float = 298.15
    parallel_workers: int = 1

    def __post_init__(self) -> None:
        if not self.geometries or not self.presets or not self.scenarios:
            raise ValueError("geometry, preset, and scenario selections cannot be empty")
        unknown_geometry = set(self.geometries).difference(GEOMETRY_PRESETS)
        unknown_preset = set(self.presets).difference(LITERATURE_ETCH_PRESETS)
        unknown_scenario = set(self.scenarios).difference(
            SPATIAL_HYPOTHESIS_SCENARIOS
        )
        if unknown_geometry:
            raise ValueError(f"unknown geometries: {sorted(unknown_geometry)}")
        if unknown_preset:
            raise ValueError(f"unknown literature presets: {sorted(unknown_preset)}")
        if unknown_scenario:
            raise ValueError(f"unknown scenarios: {sorted(unknown_scenario)}")
        targets = tuple(float(value) for value in self.target_remaining_fractions)
        if not targets or any(
            not math.isfinite(value) or not 0.0 < value < 1.0
            for value in targets
        ):
            raise ValueError("target remaining fractions must lie within (0, 1)")
        if len(set(targets)) != len(targets):
            raise ValueError("target remaining fractions must be unique")
        object.__setattr__(
            self,
            "target_remaining_fractions",
            tuple(sorted(targets, reverse=True)),
        )
        for name in (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "sidewall_diagnostic_band_nm",
            "bottom_diagnostic_band_nm",
            "maximum_fractional_front_change",
            "maximum_uniform_clear_time_multiplier",
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.maximum_fractional_front_change > 1.0:
            raise ValueError("maximum_fractional_front_change must not exceed 1")
        if not isinstance(self.parallel_workers, int) or self.parallel_workers < 1:
            raise ValueError("parallel_workers must be a positive integer")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for name in (
            "geometries",
            "presets",
            "scenarios",
            "target_remaining_fractions",
        ):
            result[name] = list(getattr(self, name))
        return result


def get_spatial_scenario(name: str) -> SpatialHypothesisScenario:
    try:
        return SPATIAL_HYPOTHESIS_SCENARIOS[name]
    except KeyError as exc:
        choices = ", ".join(SPATIAL_HYPOTHESIS_SCENARIOS)
        raise ValueError(f"unknown scenario {name!r}; choose from {choices}") from exc


def _numerics(config: NonuniformSweepConfig) -> NumericalSettings:
    return NumericalSettings(
        linear_relative_tolerance=LOOSE_NUMERICS.linear_relative_tolerance,
        linear_absolute_tolerance=LOOSE_NUMERICS.linear_absolute_tolerance,
        nonlinear_relative_tolerance=LOOSE_NUMERICS.nonlinear_relative_tolerance,
        steady_state_relative_tolerance=(
            LOOSE_NUMERICS.steady_state_relative_tolerance
        ),
        mass_balance_relative_tolerance=(
            LOOSE_NUMERICS.mass_balance_relative_tolerance
        ),
        maximum_iterations=LOOSE_NUMERICS.maximum_iterations,
        maximum_nonlinear_iterations=(
            LOOSE_NUMERICS.maximum_nonlinear_iterations
        ),
        maximum_fractional_state_change=(
            config.maximum_fractional_front_change
        ),
        minimum_time_step_s=LOOSE_NUMERICS.minimum_time_step_s,
        maximum_time_step_s=LOOSE_NUMERICS.maximum_time_step_s,
    )


def _build_model(
    geometry_name: str,
    preset: LiteratureEtchPreset,
    scenario: SpatialHypothesisScenario,
    config: NonuniformSweepConfig,
) -> GapFillEtch2D:
    process = EtchProcessConfig(
        geometry=get_geometry_preset(geometry_name),
        gap_fill_material=preset.material,
        thermal_bc=ThermalBoundaryConditions(
            solution_bulk_temperature_K=config.solution_bulk_temperature_K,
            substrate_backside_temperature_K=(
                config.substrate_backside_temperature_K
            ),
        ),
    )
    concentration = preset.hf_speciation().neutral_hf_mol_m3
    model = GapFillEtch2D(
        process,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=max(2.0, config.grid_spacing_nm),
        transport=TransportParameters(
            reactant_diffusivity_nm2_s=HF_DIFFUSIVITY_298_NM2_S,
            product_diffusivity_nm2_s=HF_DIFFUSIVITY_298_NM2_S,
            reactant_bulk_concentration=concentration,
            reactant_surface_transfer_nm_s=(
                preset.first_order_surface_transfer_nm_s()
            ),
            product_bulk_concentration=0.0,
            product_yield_concentration=0.0,
            product_bulk_decay_per_s=0.0,
        ),
        passivation=PassivationParameters(),
        rate_law=LiteratureFirstOrderRateLaw(
            reference_planar_velocity_nm_s=preset.planar_rate_nm_s,
            reference_neutral_hf_mol_m3=concentration,
        ),
        spatial_etchability=scenario.parameters,
        numerical_settings=_numerics(config),
        solid_density_g_cm3=preset.solid_density_g_cm3,
    )
    return model


def _row_profile(model: GapFillEtch2D) -> dict[str, list[float]]:
    rows = (model.grid.depth_nm >= 0.0) & (
        model.grid.depth_nm <= model.grid.geometry.depth_nm
    )
    cavity = model.grid.cavity_mask[rows]
    solid = model.front.solid_fraction[rows]
    width = np.sum(cavity, axis=1) * model.grid.dx_nm
    remaining = np.sum(solid * cavity, axis=1) * model.grid.dx_nm
    fraction = np.divide(
        remaining,
        width,
        out=np.zeros_like(remaining),
        where=width > 0.0,
    )
    return {
        "depth_nm": [float(value) for value in model.grid.depth_nm[rows]],
        "cavity_width_nm": [float(value) for value in width],
        "remaining_width_nm": [float(value) for value in remaining],
        "remaining_row_fraction": [float(value) for value in fraction],
    }


def _wall_distance_distribution(model: GapFillEtch2D) -> dict[str, object]:
    distances = model.spatial_etchability.distances.sidewall_distance_nm
    cavity = model.grid.cavity_mask
    solid = model.front.solid_fraction
    bins = (0.0, 0.5, 1.0, 2.0, 4.0, math.inf)
    records = []
    for lower, upper in zip(bins[:-1], bins[1:], strict=True):
        region = cavity & (distances >= lower) & (distances < upper)
        initial = float(np.count_nonzero(region) * model.grid.cell_area_nm2)
        remaining = float(
            np.sum(solid[region]) * model.grid.cell_area_nm2
        )
        records.append(
            {
                "lower_nm": lower,
                "upper_nm": upper if math.isfinite(upper) else None,
                "initial_area_nm2": initial,
                "remaining_area_nm2": remaining,
                "remaining_fraction": remaining / initial if initial > 0.0 else 0.0,
            }
        )
    return {"bins": records}


def _solid_map(model: GapFillEtch2D) -> dict[str, object]:
    rows = model.grid.depth_nm >= 0.0
    return {
        "lateral_nm": [float(value) for value in model.grid.lateral_nm],
        "depth_nm": [float(value) for value in model.grid.depth_nm[rows]],
        "solid_fraction": np.round(
            model.front.solid_fraction[rows], 6
        ).tolist(),
    }


def _checkpoint_payload(
    model: GapFillEtch2D,
    target: float,
    uniform_clear_time_s: float,
    *,
    config: NonuniformSweepConfig,
    include_map: bool,
) -> dict[str, object]:
    topology = analyse_residue_topology(
        model.front,
        sidewall_band_nm=config.sidewall_diagnostic_band_nm,
        bottom_band_nm=config.bottom_diagnostic_band_nm,
    )
    result: dict[str, object] = {
        "target_remaining_fraction": target,
        "achieved_remaining_fraction": topology.remaining_mass_fraction,
        "time_s": model.front.time_s,
        "time_over_uniform_clear": model.front.time_s / uniform_clear_time_s,
        "residue": topology.to_dict(),
        "row_profile": _row_profile(model),
        "wall_distance_distribution": _wall_distance_distribution(model),
    }
    if include_map:
        result["solid_map"] = _solid_map(model)
    return result


def run_nonuniform_case(
    geometry_name: str,
    preset_name: str,
    scenario_name: str,
    config: NonuniformSweepConfig,
) -> dict[str, object]:
    preset = get_literature_preset(preset_name)
    scenario = get_spatial_scenario(scenario_name)
    model = _build_model(geometry_name, preset, scenario, config)
    initial = model.front.diagnostics()
    uniform_clear_time_s = (
        model.grid.geometry.depth_nm / preset.planar_rate_nm_s
    )
    maximum_time_s = (
        config.maximum_uniform_clear_time_multiplier * uniform_clear_time_s
    )
    requested_time_step_s = uniform_clear_time_s / 50.0
    targets = config.target_remaining_fractions
    minimum_target = min(targets)
    captured: dict[float, dict[str, object]] = {}
    history = []
    maximum_steps = 30_000
    while (
        model.front.time_s < maximum_time_s
        and np.any(model.front.solid_mask)
        and len(history) < maximum_steps
        and model.front.diagnostics().remaining_mass_fraction > minimum_target
    ):
        entry = model.step(
            min(requested_time_step_s, maximum_time_s - model.front.time_s)
        )
        history.append(entry)
        remaining = model.front.diagnostics().remaining_mass_fraction
        for target in targets:
            if target not in captured and remaining <= target:
                captured[target] = _checkpoint_payload(
                    model,
                    target,
                    uniform_clear_time_s,
                    config=config,
                    include_map=(target == minimum_target),
                )

    final = model.front.diagnostics()
    checkpoints = [
        captured.get(
            target,
            {
                "target_remaining_fraction": target,
                "reached": False,
                "final_remaining_fraction": final.remaining_mass_fraction,
                "final_time_s": final.time_s,
            },
        )
        for target in targets
    ]
    for checkpoint in checkpoints:
        checkpoint.setdefault("reached", True)
    return {
        "case_id": f"{geometry_name}__{preset_name}__{scenario_name}",
        "geometry": model.grid.geometry.to_dict(),
        "material": preset.material,
        "preset_key": preset.key,
        "planar_rate_nm_min": preset.planar_rate_nm_min,
        "scenario": scenario.to_dict(),
        "spatial_etchability": model.spatial_etchability.summary(),
        "uniform_clear_time_s": uniform_clear_time_s,
        "maximum_time_s": maximum_time_s,
        "requested_time_step_s": requested_time_step_s,
        "grid": {
            "shape": list(model.grid.shape),
            "dx_nm": model.grid.dx_nm,
            "dz_nm": model.grid.dz_nm,
            "initial_area_discretization_relative_error": (
                initial.initial_area_discretization_relative_error
            ),
        },
        "steps": len(history),
        "completed": not np.any(model.front.solid_mask),
        "final_time_s": final.time_s,
        "final_remaining_mass_fraction": final.remaining_mass_fraction,
        "all_targets_reached": all(target in captured for target in targets),
        "terminated_by_step_limit": len(history) >= maximum_steps,
        "convergence": {
            "reactant": all(item.reactant_converged for item in history),
            "product": all(item.product_converged for item in history),
            "nonlinear": all(item.nonlinear_converged for item in history),
            "maximum_reactant_relative_residual": max(
                (item.reactant_relative_residual for item in history),
                default=0.0,
            ),
            "maximum_front_mass_balance_relative_error": max(
                (item.front_mass_balance_relative_error for item in history),
                default=0.0,
            ),
        },
        "checkpoints": checkpoints,
        "model_scope": {
            "original_gap_fill_wall_rail": True,
            "new_wall_deposit_phase": False,
            "product_passivation": False,
            "wetting_or_bubble": False,
        },
    }


_WORKER_THREAD_LIMITER = None


def _initialise_numeric_worker() -> None:
    global _WORKER_THREAD_LIMITER
    try:
        from threadpoolctl import threadpool_limits
    except ImportError:
        return
    _WORKER_THREAD_LIMITER = threadpool_limits(limits=1)


def _run_case_tuple(
    values: tuple[str, str, str, NonuniformSweepConfig],
) -> dict[str, object]:
    return run_nonuniform_case(*values)


def run_nonuniform_sweep(
    config: NonuniformSweepConfig | None = None,
) -> dict[str, object]:
    resolved = config or NonuniformSweepConfig()
    inputs = [
        (geometry, preset, scenario, resolved)
        for geometry in resolved.geometries
        for preset in resolved.presets
        for scenario in resolved.scenarios
    ]
    workers = min(resolved.parallel_workers, len(inputs))
    if workers == 1:
        cases = [_run_case_tuple(values) for values in inputs]
    else:
        variables = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
        previous = {name: os.environ.get(name) for name in variables}
        for name in variables:
            os.environ[name] = "1"
        try:
            with ProcessPoolExecutor(
                max_workers=workers,
                initializer=_initialise_numeric_worker,
            ) as executor:
                cases = list(executor.map(_run_case_tuple, inputs))
        finally:
            for name, value in previous.items():
                if value is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = value
    return {
        "model": "static spatial film-quality residue hypothesis sweep",
        "notice": STATIC_HYPOTHESIS_NOTICE,
        "calibrated_spatial_factors": False,
        "config": resolved.to_dict(),
        "parallel_execution": {
            "requested_workers": resolved.parallel_workers,
            "effective_workers": workers,
            "case_count": len(inputs),
            "case_order_preserved": True,
        },
        "literature_context": {
            "direction_dependent_SiN_WER": (
                "Faraz et al. reported process-dependent top/sidewall/bottom "
                "WER and selective sidewall retention in 3-D trenches."
            ),
            "url": "https://doi.org/10.1021/acsami.8b00183",
            "counterexample_url": "https://doi.org/10.1021/acsami.6b12267",
            "interpretation": (
                "directional rate factors are deposition-specific fields, not "
                "universal SiN, SiCN, or SiOCN constants"
            ),
        },
        "cases": cases,
    }


__all__ = [
    "NonuniformSweepConfig",
    "SPATIAL_HYPOTHESIS_SCENARIOS",
    "STATIC_HYPOTHESIS_NOTICE",
    "SpatialHypothesisScenario",
    "get_spatial_scenario",
    "run_nonuniform_case",
    "run_nonuniform_sweep",
]

"""Claim-safe descriptive screen for Kawarazaki et al. Figure 3.

The source is a one-page ECS meeting abstract.  Its official raster contains
Figure 3 bake-time points for three ALD blanket films.  The values below are
approximate axis-calibrated readings of the four non-zero bake times shown in
the raster.  The plotted zero-second origin is deliberately not represented as
a measurement because the source does not define it consistently with the
non-zero dHF-only losses reported in Figure 2.

This module performs descriptive arithmetic only.  It does not fit a kinetic
law, estimate a saturation time constant, interpolate, extrapolate, or infer a
reaction mechanism.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path


SCHEMA_VERSION = "kawarazaki-fig3-plateau-screen/v1"
DOI = "10.1149/MA2024-02312265mtgabs"
ARTICLE_URL = (
    "https://iopscience.iop.org/article/"
    "10.1149/MA2024-02312265mtgabs"
)
ECS_RECORD_URL = (
    "https://ecs.confex.com/ecs/prime2024/"
    "meetingapp.cgi/Paper/191475"
)
FIGURE_URL = (
    "https://content.cld.iop.org/journals/2151-2043/"
    "MA2024-02/31/2265/revision1/2265fig1.jpg"
)
FIGURE_SHA256 = (
    "eb0aae0412e849b341ed399a3bdc887018bf6d4ab57ea8f81af35c5f8a113faa"
)
MEASURED_BAKE_TIMES_S = (15, 30, 60, 120)
TAIL_START_S = 30

# This is a raster readout tolerance, not an experimental uncertainty.
PER_POINT_READOUT_TOLERANCE_NM = 0.05
PAIRWISE_READOUT_TOLERANCE_NM = 2.0 * PER_POINT_READOUT_TOLERANCE_NM


@dataclass(frozen=True)
class Fig3DigitizedSeries:
    """One material series read approximately from the official Figure 3."""

    material_id: str
    material: str
    figure_label: str
    nominal_carbon_percent: float
    etch_amount_nm_per_cycle: tuple[float, ...]

    def __post_init__(self) -> None:
        if not self.material_id:
            raise ValueError("material_id cannot be empty")
        if self.material not in {"SiCN", "SiOCN"}:
            raise ValueError("material must be SiCN or SiOCN")
        carbon = float(self.nominal_carbon_percent)
        if not math.isfinite(carbon) or not 0.0 <= carbon <= 100.0:
            raise ValueError(
                "nominal_carbon_percent must be finite and within [0, 100]"
            )
        if len(self.etch_amount_nm_per_cycle) != len(
            MEASURED_BAKE_TIMES_S
        ):
            raise ValueError(
                "etch_amount_nm_per_cycle must match the measured bake times"
            )
        values = tuple(float(value) for value in self.etch_amount_nm_per_cycle)
        if any(not math.isfinite(value) or value < 0.0 for value in values):
            raise ValueError(
                "etch_amount_nm_per_cycle values must be finite and "
                "non-negative"
            )
        object.__setattr__(self, "nominal_carbon_percent", carbon)
        object.__setattr__(self, "etch_amount_nm_per_cycle", values)

    def measurements(self) -> list[dict[str, object]]:
        return [
            {
                "bake_time_s": bake_time,
                "etch_amount_nm_per_cycle": value,
                "value_basis": "official_raster_digitized_approximate",
                "is_interpolated": False,
                "is_extrapolated": False,
            }
            for bake_time, value in zip(
                MEASURED_BAKE_TIMES_S,
                self.etch_amount_nm_per_cycle,
                strict=True,
            )
        ]


FIG3_SERIES = (
    Fig3DigitizedSeries(
        material_id="sicn_c22",
        material="SiCN",
        figure_label="SiCN(C:22%)",
        nominal_carbon_percent=22.0,
        etch_amount_nm_per_cycle=(2.50, 2.92, 2.93, 2.96),
    ),
    Fig3DigitizedSeries(
        material_id="sicn_c40",
        material="SiCN",
        figure_label="SiCN(C:40%)",
        nominal_carbon_percent=40.0,
        etch_amount_nm_per_cycle=(0.68, 0.84, 0.75, 0.84),
    ),
    Fig3DigitizedSeries(
        material_id="siocn_c5",
        material="SiOCN",
        figure_label="SiOCN(C:5%)",
        nominal_carbon_percent=5.0,
        etch_amount_nm_per_cycle=(0.52, 0.60, 0.51, 0.52),
    ),
)


def _rounded(value: float) -> float:
    return round(float(value), 12)


def _adjacent_changes(
    times_s: tuple[int, ...],
    values_nm: tuple[float, ...],
) -> list[dict[str, object]]:
    return [
        {
            "from_bake_time_s": start_time,
            "to_bake_time_s": end_time,
            "change_nm_per_cycle": _rounded(end_value - start_value),
            "absolute_change_nm_per_cycle": _rounded(
                abs(end_value - start_value)
            ),
        }
        for start_time, end_time, start_value, end_value in zip(
            times_s[:-1],
            times_s[1:],
            values_nm[:-1],
            values_nm[1:],
            strict=True,
        )
    ]


def descriptive_plateau_diagnostics(
    series: Fig3DigitizedSeries,
) -> dict[str, object]:
    """Summarize the measured post-30 s spread without fitting a model."""

    tail_pairs = [
        (time_s, value)
        for time_s, value in zip(
            MEASURED_BAKE_TIMES_S,
            series.etch_amount_nm_per_cycle,
            strict=True,
        )
        if time_s >= TAIL_START_S
    ]
    tail_times = tuple(time_s for time_s, _ in tail_pairs)
    tail_values = tuple(value for _, value in tail_pairs)
    tail_minimum = min(tail_values)
    tail_maximum = max(tail_values)
    tail_mean = sum(tail_values) / len(tail_values)
    tail_span = tail_maximum - tail_minimum
    within_readout_tolerance = (
        tail_span <= PAIRWISE_READOUT_TOLERANCE_NM + 1.0e-12
    )
    return {
        "kind": "descriptive_post_30_s_spread_only",
        "tail_window_measured_times_s": list(tail_times),
        "tail_sample_count": len(tail_values),
        "tail_mean_nm_per_cycle": _rounded(tail_mean),
        "tail_minimum_nm_per_cycle": _rounded(tail_minimum),
        "tail_maximum_nm_per_cycle": _rounded(tail_maximum),
        "tail_span_nm_per_cycle": _rounded(tail_span),
        "tail_endpoint_change_30_to_120_nm_per_cycle": _rounded(
            tail_values[-1] - tail_values[0]
        ),
        "change_15_to_30_nm_per_cycle": _rounded(
            series.etch_amount_nm_per_cycle[1]
            - series.etch_amount_nm_per_cycle[0]
        ),
        "adjacent_measured_changes": _adjacent_changes(
            MEASURED_BAKE_TIMES_S,
            series.etch_amount_nm_per_cycle,
        ),
        "pairwise_readout_tolerance_nm": (
            PAIRWISE_READOUT_TOLERANCE_NM
        ),
        "post_30_s_span_within_pairwise_readout_tolerance": (
            within_readout_tolerance
        ),
        "screen_label": (
            "post_30_s_values_within_raster_readout_tolerance"
            if within_readout_tolerance
            else "post_30_s_variation_exceeds_raster_readout_tolerance"
        ),
        "plateau_proven": False,
    }


def build_fig3_plateau_screen() -> dict[str, object]:
    """Build a strict-JSON-compatible descriptive Figure 3 payload."""

    materials = [
        {
            "material_id": series.material_id,
            "material": series.material,
            "figure_label": series.figure_label,
            "nominal_carbon_percent": series.nominal_carbon_percent,
            "carbon_percent_basis": (
                "figure label only; analytical method and percentage basis "
                "not disclosed"
            ),
            "measurements": series.measurements(),
            "diagnostics": descriptive_plateau_diagnostics(series),
        }
        for series in FIG3_SERIES
    ]
    return {
        "schema_version": SCHEMA_VERSION,
        "analysis": (
            "Kawarazaki et al. Figure 3 empirical bake-time plateau screen"
        ),
        "source": {
            "doi": DOI,
            "article_url": ARTICLE_URL,
            "ecs_program_record_url": ECS_RECORD_URL,
            "official_figure_url": FIGURE_URL,
            "official_figure_sha256": FIGURE_SHA256,
            "official_figure_width_px": 1280,
            "official_figure_height_px": 719,
            "panel": "Fig. 3",
            "figure_axis_quantity": "Etching amount [nm/cycle]",
        },
        "experimental_context": {
            "sample_geometry": "ALD blanket films on 300 mm Si wafers",
            "native_oxide_preclean": {
                "chemistry": "dHF",
                "reported_percent": 0.15,
                "concentration_basis": "not stated in abstract",
                "duration_s": None,
            },
            "ozone_bake": {
                "temperature_C": 240.0,
                "ozone_concentration_g_m3": 100.0,
                "measured_bake_times_s": list(MEASURED_BAKE_TIMES_S),
            },
            "wet_removal": {
                "chemistry": "dHF",
                "reported_percent": 0.15,
                "concentration_basis": "not stated in abstract",
                "duration_s": 30.0,
            },
            "thickness_measurement": (
                "ellipsometry before and after processing"
            ),
        },
        "digitization": {
            "values_are_approximate": True,
            "method": (
                "manual axis-calibrated readout from the official "
                "1280 x 719 raster"
            ),
            "per_point_readout_tolerance_nm": (
                PER_POINT_READOUT_TOLERANCE_NM
            ),
            "readout_tolerance_is_experimental_uncertainty": False,
            "source_error_bars_available": False,
            "zero_second_marker_in_source_raster": True,
            "zero_second_marker_encoded_as_measurement": False,
            "zero_second_omission_reason": (
                "the source does not define the plotted origin consistently "
                "with the non-zero dHF-only losses reported in Fig. 2"
            ),
        },
        "cross_panel_warning": {
            "purpose": "claim_boundary_only_not_a_shared_calibration",
            "fig2_and_fig3_30_s_values_are_identical": False,
            "panels_numerically_mergeable_without_missing_condition_resolution": (
                False
            ),
            "approximate_raster_examples": [
                {
                    "material_id": "sicn_c22",
                    "fig3_30_s_nm_per_cycle": 2.92,
                    "fig2_30_s_ozone_then_dhf_nm": 2.47,
                },
                {
                    "material_id": "sicn_c40",
                    "fig3_30_s_nm_per_cycle": 0.84,
                    "fig2_30_s_ozone_then_dhf_nm": 0.70,
                },
                {
                    "material_id": "siocn_c5",
                    "fig3_30_s_nm_per_cycle": 0.60,
                    "fig2_30_s_ozone_then_dhf_nm": 0.50,
                },
            ],
            "warning": (
                "The approximate Fig. 3 values at the 30 s tick differ from "
                "the approximate Fig. 2 bars labelled as a 30 s ozone bake. "
                "Do not merge the panels or calibrate one shared 30 s "
                "endpoint unless the missing panel-specific condition or "
                "run-to-run explanation is resolved."
            ),
        },
        "analysis_constraints": {
            "measured_times_only": True,
            "kinetic_model_fitted": False,
            "interpolation_performed": False,
            "extrapolation_performed": False,
            "saturation_time_constant_estimated": False,
            "plateau_onset_estimated": False,
            "reaction_mechanism_inferred": False,
            "cycle_linearity_evaluated": False,
            "fig2_fig3_shared_30_s_endpoint_calibrated": False,
            "patterned_feature_validated": False,
        },
        "plateau_screen_definition": {
            "tail_start_s": TAIL_START_S,
            "tail_times_must_be_measured": True,
            "diagnostic": (
                "maximum minus minimum of measured 30, 60 and 120 s values"
            ),
            "comparison_tolerance_nm": PAIRWISE_READOUT_TOLERANCE_NM,
            "comparison_tolerance_basis": (
                "sum of two approximate per-point raster readout tolerances; "
                "not a statistical confidence interval"
            ),
        },
        "materials": materials,
        "summary": {
            "material_count": len(materials),
            "all_post_30_s_spans_within_pairwise_readout_tolerance": all(
                bool(
                    material["diagnostics"][
                        "post_30_s_span_within_pairwise_readout_tolerance"
                    ]
                )
                for material in materials
            ),
            "claim_boundary": (
                "The raster supports a descriptive post-30 s plateau screen "
                "at the plotted blanket-film conditions only; it does not "
                "establish fitted kinetics, an exact saturation time, "
                "patterned-feature uniformity, or a transferable recipe."
            ),
        },
    }


def save_fig3_plateau_screen_json(
    payload: dict[str, object],
    path: str | Path,
) -> Path:
    """Save strict JSON, rejecting NaN and infinities."""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    destination.write_text(text + "\n", encoding="utf-8")
    return destination


__all__ = [
    "FIG3_SERIES",
    "MEASURED_BAKE_TIMES_S",
    "PAIRWISE_READOUT_TOLERANCE_NM",
    "PER_POINT_READOUT_TOLERANCE_NM",
    "SCHEMA_VERSION",
    "Fig3DigitizedSeries",
    "build_fig3_plateau_screen",
    "descriptive_plateau_diagnostics",
    "save_fig3_plateau_screen_json",
]

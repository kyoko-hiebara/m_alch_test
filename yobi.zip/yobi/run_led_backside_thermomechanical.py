"""Generate the dated 300 mm backside-LED inverse screening report."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import os
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex-mpl-led-backside")

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LogNorm

from led_backside_thermomechanical import (
    SCHEMA_VERSION,
    USHIO_STATED_PROCESS_CEILING_K,
    WAFER_DIAMETER_M,
    WATER_BOILING_POINT_1ATM_K,
    WATER_BULK_TEMPERATURE_K,
    LocalThermalPath,
    band_averaged_absorptance,
    default_local_paths,
    default_residue_cases,
    inverse_delamination_temperature,
    local_global_active_area_fraction_ceiling,
    local_residue_thermal_state,
    optical_absorption_air_sio2_si,
    required_incident_irradiance_W_m2,
    required_incident_irradiance_exact_W_m2,
    simulate_1d_wafer_constant_flux,
    square_pulse_temperature_history,
    substrate_temperature_for_delta_K,
    temperature_after_constant_irradiance_K,
    thermomechanical_state,
    wafer_area_m2,
    whole_wafer_irradiance_W_m2,
)


DEFAULT_OUTPUT_DIR = Path("results/led_backside_thermomechanical_20260801")
THEORY_MEMO = Path("research_memos/LED_BACKSIDE_THERMOMECHANICAL_THEORY_20260801.html")
MODEL_NOTICE = (
    "Inverse screening model, not a cleaning recipe. The reported Gamma_crit is "
    "the phi=1 stored-film elastic-energy upper bound. Actual removal additionally "
    "requires the real interface fracture energy, a crack or edge geometry, and a "
    "self-consistent local/global water heat path. Ushio 780/1200 W values are "
    "shown only as whole-wafer optical-equivalent references; electrical-to-optical "
    "conversion and delivery efficiency are not assumed."
)


def _json_default(value: Any) -> Any:
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"not JSON serializable: {type(value).__name__}")


def write_json(path: Path, payload: Any) -> None:
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            default=_json_default,
        )
        + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty CSV: {path}")
    fieldnames: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                fieldnames.append(key)
                seen.add(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fmt(value: float | None, digits: int = 3) -> str:
    if value is None:
        return "—"
    if value == 0.0:
        return "0"
    magnitude = abs(value)
    if magnitude >= 1.0e4 or magnitude < 1.0e-3:
        return f"{value:.{digits}e}"
    return f"{value:.{digits}f}"


def optical_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for oxide_nm in np.linspace(0.0, 500.0, 501):
        result_395 = optical_absorption_air_sio2_si(395.0, float(oxide_nm))
        result_400 = optical_absorption_air_sio2_si(400.0, float(oxide_nm))
        rows.append(
            {
                "oxide_thickness_nm": float(oxide_nm),
                "absorptance_395": result_395.absorptance,
                "reflectance_395": result_395.reflectance,
                "absorption_depth_395_nm": result_395.silicon_absorption_depth_nm,
                "absorptance_400": result_400.absorptance,
                "reflectance_400": result_400.reflectance,
                "absorption_depth_400_nm": result_400.silicon_absorption_depth_nm,
                "band_average_absorptance": 0.5
                * (result_395.absorptance + result_400.absorptance),
            }
        )
    return rows


def local_path_rows(paths: Sequence[LocalThermalPath]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in paths:
        for temperature in (323.15, 350.0, 373.15, 450.0, 600.0, 873.15):
            state = local_residue_thermal_state(temperature, path)
            row = asdict(path)
            row.update(state.to_dict())
            row["water_1atm_valid"] = temperature <= WATER_BOILING_POINT_1ATM_K
            rows.append(row)
    return rows


def local_global_compatibility_rows(
    paths: Sequence[LocalThermalPath],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in paths:
        state = local_residue_thermal_state(
            WATER_BULK_TEMPERATURE_K + 1.0, path
        )
        for heat_transfer in (100.0, 1000.0, 10000.0):
            fraction = local_global_active_area_fraction_ceiling(
                path, heat_transfer
            )
            rows.append(
                {
                    "path_name": path.name,
                    "total_heat_transfer_W_m2K": heat_transfer,
                    "local_unit_delta_heat_flux_W_m2K": state.heat_flux_W_m2,
                    "maximum_active_projected_area_fraction": fraction,
                    "maximum_active_projected_area_percent": 100.0 * fraction,
                    "maximum_active_projected_area_m2": fraction * wafer_area_m2(),
                    "interpretation": (
                        "linear heat-budget ceiling only; assumes local paths act "
                        "in parallel over a projected area fraction"
                    ),
                }
            )
    return rows


def mechanical_sweep_rows(
    paths: Sequence[LocalThermalPath], residues: Sequence[Any]
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    temperatures = np.linspace(WATER_BULK_TEMPERATURE_K, 873.15, 576)
    for residue in residues:
        for path in paths:
            for temperature in temperatures:
                state = thermomechanical_state(float(temperature), path, residue)
                rows.append(
                    {
                        **state.to_dict(),
                        "residue_thickness_nm": residue.thickness_m * 1.0e9,
                        "residue_cte_per_K": residue.thermal_expansion_per_K,
                        "residue_biaxial_modulus_Pa": residue.biaxial_modulus_Pa,
                        "water_1atm_valid": temperature
                        <= WATER_BOILING_POINT_1ATM_K,
                        "ushio_stated_range_valid": temperature
                        <= USHIO_STATED_PROCESS_CEILING_K,
                    }
                )
    return rows


def inverse_threshold_rows(
    paths: Sequence[LocalThermalPath], residues: Sequence[Any]
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    fracture_energies = [10.0**exponent for exponent in range(-10, 1)]
    for residue in residues:
        for path in paths:
            for fracture_energy in fracture_energies:
                threshold = inverse_delamination_temperature(
                    fracture_energy, path, residue
                )
                rows.append(
                    {
                        **threshold.to_dict(),
                        "residue_thickness_nm": residue.thickness_m * 1.0e9,
                        "residue_interpretation": residue.interpretation,
                        "path_interpretation": path.interpretation,
                    }
                )
    return rows


def delta_inverse_rows(paths: Sequence[LocalThermalPath]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in paths:
        unit_state = local_residue_thermal_state(
            WATER_BULK_TEMPERATURE_K + 1.0, path
        )
        for desired_delta in (0.01, 0.1, 1.0, 5.0, 10.0, 25.0, 50.0):
            substrate = substrate_temperature_for_delta_K(desired_delta, path)
            state = local_residue_thermal_state(substrate, path)
            rows.append(
                {
                    "path_name": path.name,
                    "desired_substrate_residue_delta_K": desired_delta,
                    "required_substrate_temperature_K": substrate,
                    "resulting_residue_temperature_K": state.residue_temperature_K,
                    "residue_cold_fraction": unit_state.residue_cold_fraction,
                    "water_1atm_valid": substrate <= WATER_BOILING_POINT_1ATM_K,
                    "ushio_stated_range_valid": substrate
                    <= USHIO_STATED_PROCESS_CEILING_K,
                    "interpretation": path.interpretation,
                }
            )
    return rows


def continuous_inverse_rows(
    paths: Sequence[LocalThermalPath], residues: Sequence[Any]
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    fracture_energies = (1.0e-8, 1.0e-7, 1.0e-6, 1.0e-5, 1.0e-4, 1.0e-3)
    thicknesses_um = (100.0, 200.0, 300.0, 500.0, 775.0, 1000.0)
    durations_s = (0.01, 0.1, 1.0, 10.0, 30.0, 100.0, 300.0)
    heat_transfer_values = (100.0, 1000.0, 10000.0)
    oxide_values_nm = (2.0, 70.0)
    area = wafer_area_m2()
    for residue in residues[:2]:
        for path in paths:
            for fracture_energy in fracture_energies:
                threshold = inverse_delamination_temperature(
                    fracture_energy, path, residue
                )
                target = threshold.required_substrate_temperature_K
                if not threshold.reached or target is None or target > 1499.0:
                    continue
                for thickness_um in thicknesses_um:
                    for duration in durations_s:
                        for heat_transfer in heat_transfer_values:
                            for oxide_nm in oxide_values_nm:
                                absorption = band_averaged_absorptance(oxide_nm)
                                irradiance = required_incident_irradiance_W_m2(
                                    target,
                                    duration,
                                    thickness_um * 1.0e-6,
                                    absorption,
                                    heat_transfer,
                                )
                                optical_power = irradiance * area
                                steady_irradiance = (
                                    heat_transfer
                                    * (target - WATER_BULK_TEMPERATURE_K)
                                    / absorption
                                )
                                rows.append(
                                    {
                                        "assumed_fracture_energy_J_m2": fracture_energy,
                                        "residue_case": residue.name,
                                        "path_name": path.name,
                                        "required_substrate_temperature_K": target,
                                        "required_residue_temperature_K": threshold.required_residue_temperature_K,
                                        "required_substrate_residue_delta_K": threshold.required_substrate_residue_delta_K,
                                        "wafer_thickness_um": thickness_um,
                                        "duration_s": duration,
                                        "total_heat_transfer_W_m2K": heat_transfer,
                                        "oxide_thickness_nm": oxide_nm,
                                        "absorptance": absorption,
                                        "required_incident_irradiance_W_m2": irradiance,
                                        "required_incident_irradiance_W_cm2": irradiance
                                        / 1.0e4,
                                        "required_whole_wafer_optical_power_W": optical_power,
                                        "power_over_780W_reference": optical_power / 780.0,
                                        "power_over_1200W_reference": optical_power / 1200.0,
                                        "steady_incident_irradiance_W_m2": steady_irradiance,
                                        "water_1atm_valid": target
                                        <= WATER_BOILING_POINT_1ATM_K,
                                        "ushio_stated_range_valid": target
                                        <= USHIO_STATED_PROCESS_CEILING_K,
                                    }
                                )
    return rows


def forward_reference_rows(
    paths: Sequence[LocalThermalPath], residues: Sequence[Any]
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    area = wafer_area_m2()
    path = next(item for item in paths if item.name == "near_debond_180nm_water")
    residue = next(item for item in residues if item.name == "sinx_like_2nm")
    for nominal_power_W in (100.0, 300.0, 780.0, 1200.0, 3000.0):
        irradiance = nominal_power_W / area
        for thickness_um in (300.0, 775.0, 1000.0):
            for duration in (1.0, 10.0, 30.0, 100.0):
                for heat_transfer in (100.0, 1000.0, 10000.0):
                    for oxide_nm in (2.0, 70.0):
                        absorption = band_averaged_absorptance(oxide_nm)
                        temperature = temperature_after_constant_irradiance_K(
                            irradiance,
                            duration,
                            thickness_um * 1.0e-6,
                            absorption,
                            heat_transfer,
                            maximum_temperature_K=1499.0,
                        )
                        capped = temperature >= 1499.0 - 1.0e-6
                        if not capped:
                            thermal = local_residue_thermal_state(temperature, path)
                            mechanical = thermomechanical_state(
                                temperature, path, residue
                            )
                            residue_temperature = thermal.residue_temperature_K
                            delta_temperature = thermal.substrate_residue_delta_K
                            gamma_crit = mechanical.stored_energy_upper_bound_J_m2
                        else:
                            residue_temperature = None
                            delta_temperature = None
                            gamma_crit = None
                        rows.append(
                            {
                                "whole_wafer_optical_equivalent_power_W": nominal_power_W,
                                "incident_irradiance_W_m2": irradiance,
                                "incident_irradiance_W_cm2": irradiance / 1.0e4,
                                "wafer_thickness_um": thickness_um,
                                "duration_s": duration,
                                "total_heat_transfer_W_m2K": heat_transfer,
                                "oxide_thickness_nm": oxide_nm,
                                "absorptance": absorption,
                                "substrate_temperature_K": temperature,
                                "residue_temperature_K_near_debond_path": residue_temperature,
                                "substrate_residue_delta_K_near_debond_path": delta_temperature,
                                "gamma_crit_J_m2_sinx_2nm_near_debond": gamma_crit,
                                "temperature_capped_at_model_limit": capped,
                                "water_1atm_valid": temperature
                                <= WATER_BOILING_POINT_1ATM_K,
                                "power_definition_warning": (
                                    "optical-equivalent reference; not Ushio electrical-to-wafer calibration"
                                ),
                            }
                        )
    return rows


def pulse_rows(
    paths: Sequence[LocalThermalPath], residues: Sequence[Any]
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    area = wafer_area_m2()
    path = next(item for item in paths if item.name == "near_debond_180nm_water")
    residue = next(item for item in residues if item.name == "sinx_like_2nm")
    for peak_power_W in (780.0, 1200.0, 3000.0):
        peak_irradiance = peak_power_W / area
        for period in (0.01, 0.1, 1.0, 10.0):
            for duty in (0.1, 0.5):
                for thickness_um in (300.0, 775.0):
                    for heat_transfer in (100.0, 1000.0, 10000.0):
                        for oxide_nm in (2.0, 70.0):
                            absorption = band_averaged_absorptance(oxide_nm)
                            pulse = square_pulse_temperature_history(
                                peak_irradiance,
                                period,
                                duty,
                                60.0,
                                thickness_um * 1.0e-6,
                                absorption,
                                heat_transfer,
                            )
                            same_average = square_pulse_temperature_history(
                                peak_irradiance * duty,
                                period,
                                1.0,
                                60.0,
                                thickness_um * 1.0e-6,
                                absorption,
                                heat_transfer,
                            )
                            if pulse.peak_temperature_K < 1499.0:
                                local = local_residue_thermal_state(
                                    pulse.peak_temperature_K, path
                                )
                                mechanical = thermomechanical_state(
                                    pulse.peak_temperature_K, path, residue
                                )
                                peak_delta = local.substrate_residue_delta_K
                                gamma_crit = mechanical.stored_energy_upper_bound_J_m2
                            else:
                                peak_delta = None
                                gamma_crit = None
                            rows.append(
                                {
                                    "peak_whole_wafer_optical_equivalent_power_W": peak_power_W,
                                    "peak_incident_irradiance_W_cm2": peak_irradiance
                                    / 1.0e4,
                                    "average_incident_irradiance_W_cm2": peak_irradiance
                                    * duty
                                    / 1.0e4,
                                    "period_s": period,
                                    "duty_cycle": duty,
                                    "pulse_on_s": pulse.pulse_on_s,
                                    "total_duration_s": 60.0,
                                    "wafer_thickness_um": thickness_um,
                                    "total_heat_transfer_W_m2K": heat_transfer,
                                    "oxide_thickness_nm": oxide_nm,
                                    "absorptance": absorption,
                                    "pulse_peak_temperature_K": pulse.peak_temperature_K,
                                    "pulse_minimum_cycle_temperature_K": pulse.minimum_cycle_temperature_K,
                                    "pulse_final_temperature_K": pulse.final_temperature_K,
                                    "pulse_peak_to_valley_K": pulse.peak_to_valley_K,
                                    "same_average_continuous_temperature_K": same_average.peak_temperature_K,
                                    "pulse_peak_gain_over_same_average_K": pulse.peak_temperature_K
                                    - same_average.peak_temperature_K,
                                    "substrate_residue_delta_at_peak_K": peak_delta,
                                    "gamma_crit_at_peak_J_m2": gamma_crit,
                                    "cycle_count": pulse.cycle_count,
                                    "diffusion_time_s": pulse.diffusion_time_s,
                                    "pulse_to_diffusion_time_ratio": pulse.pulse_to_diffusion_time_ratio,
                                    "lumped_pulse_warning": pulse.lumped_pulse_warning,
                                    "water_1atm_valid": pulse.peak_temperature_K
                                    <= WATER_BOILING_POINT_1ATM_K,
                                    "pulse_property_model": "constant Cp at 298.15 K",
                                }
                            )
    return rows


def validation_payload() -> dict[str, Any]:
    inverse_checks: list[dict[str, Any]] = []
    for target in (323.15, 350.0, 373.0, 500.0):
        for thickness_um in (100.0, 775.0):
            for duration in (1.0, 30.0):
                for heat_transfer in (0.0, 100.0, 1000.0):
                    absorption = band_averaged_absorptance(2.0)
                    approximate = required_incident_irradiance_W_m2(
                        target,
                        duration,
                        thickness_um * 1.0e-6,
                        absorption,
                        heat_transfer,
                    )
                    exact = required_incident_irradiance_exact_W_m2(
                        target,
                        duration,
                        thickness_um * 1.0e-6,
                        absorption,
                        heat_transfer,
                    )
                    inverse_checks.append(
                        {
                            "target_temperature_K": target,
                            "wafer_thickness_um": thickness_um,
                            "duration_s": duration,
                            "total_heat_transfer_W_m2K": heat_transfer,
                            "average_cp_inverse_W_m2": approximate,
                            "variable_cp_exact_inverse_W_m2": exact,
                            "relative_error": approximate / exact - 1.0,
                        }
                    )

    one_d_cases = (
        (780.0, 775.0, 1.0, 100.0, 2.0),
        (780.0, 775.0, 10.0, 100.0, 2.0),
        (780.0, 775.0, 30.0, 100.0, 2.0),
        (1200.0, 775.0, 10.0, 1000.0, 70.0),
        (3000.0, 775.0, 0.001, 1000.0, 2.0),
        (3000.0, 775.0, 0.01, 1000.0, 2.0),
        (3000.0, 300.0, 0.01, 1000.0, 2.0),
    )
    one_d_checks: list[dict[str, Any]] = []
    area = wafer_area_m2()
    for power, thickness_um, duration, heat_transfer, oxide_nm in one_d_cases:
        result = simulate_1d_wafer_constant_flux(
            power / area,
            duration,
            thickness_um * 1.0e-6,
            band_averaged_absorptance(oxide_nm),
            heat_transfer,
            cell_count=80,
        )
        one_d_checks.append(
            {
                "whole_wafer_optical_equivalent_power_W": power,
                "wafer_thickness_um": thickness_um,
                "duration_s": duration,
                "total_heat_transfer_W_m2K": heat_transfer,
                "oxide_thickness_nm": oxide_nm,
                **result.to_dict(),
            }
        )

    convergence: list[dict[str, Any]] = []
    for cells in (40, 80, 160):
        result = simulate_1d_wafer_constant_flux(
            1200.0 / area,
            0.01,
            775.0e-6,
            band_averaged_absorptance(2.0),
            1000.0,
            cell_count=cells,
        )
        convergence.append(
            {
                "cell_count": cells,
                "backside_temperature_K": result.backside_temperature_K,
                "frontside_temperature_K": result.frontside_temperature_K,
                "mean_temperature_K": result.mean_temperature_K,
            }
        )
    return {
        "average_cp_inverse_vs_variable_cp_exact": inverse_checks,
        "one_dimensional_checks": one_d_checks,
        "one_dimensional_mesh_convergence": convergence,
        "max_abs_inverse_relative_error": max(
            abs(row["relative_error"]) for row in inverse_checks
        ),
        "max_abs_1d_mean_vs_lumped_K": max(
            abs(row["mean_vs_lumped_delta_K"]) for row in one_d_checks
        ),
    }


def configure_plot_style() -> None:
    plt.rcParams.update(
        {
            "figure.dpi": 140,
            "savefig.dpi": 180,
            "font.size": 9.5,
            "axes.titlesize": 11,
            "axes.labelsize": 9.5,
            "legend.fontsize": 8,
            "axes.grid": True,
            "grid.alpha": 0.23,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def plot_summary(
    output_path: Path,
    paths: Sequence[LocalThermalPath],
    residues: Sequence[Any],
) -> None:
    configure_plot_style()
    fig, axes = plt.subplots(2, 2, figsize=(12.2, 8.2), constrained_layout=True)

    oxide = np.linspace(0.0, 500.0, 1001)
    for wavelength, color in ((395.0, "#7a2e68"), (400.0, "#145a7b")):
        values = [
            optical_absorption_air_sio2_si(wavelength, float(value)).absorptance
            for value in oxide
        ]
        axes[0, 0].plot(oxide, values, color=color, label=f"{wavelength:.0f} nm")
    axes[0, 0].axvline(2.0, color="#555", ls=":", lw=1, label="2 nm native-like")
    axes[0, 0].axvline(70.0, color="#925d00", ls="--", lw=1, label="70 nm")
    axes[0, 0].set(xlabel="Backside SiO2 thickness (nm)", ylabel="Absorptance", title="(a) Air / SiO2 / thick-Si optics")
    axes[0, 0].set_ylim(0.45, 0.84)
    axes[0, 0].legend(ncol=2)

    path_labels = [path.name.replace("_180nm_water", "").replace("_", "\n") for path in paths]
    cold_fractions = [
        local_residue_thermal_state(350.0, path).residue_cold_fraction
        for path in paths
    ]
    bars = axes[0, 1].bar(
        range(len(paths)), cold_fractions, color=["#4f7892", "#77923f", "#c6842b", "#9a4d6f"]
    )
    axes[0, 1].set_xticks(range(len(paths)), path_labels)
    axes[0, 1].set_ylim(0.0, 1.0)
    axes[0, 1].set(ylabel="(Ts - Tr) / (Ts - Twater)", title="(b) Fraction of wafer overheat kept as Ts-Tr")
    for bar, value in zip(bars, cold_fractions, strict=True):
        axes[0, 1].text(bar.get_x() + bar.get_width() / 2, value + 0.025, f"{value:.3f}", ha="center", va="bottom", fontsize=8)

    residue = next(item for item in residues if item.name == "sinx_like_2nm")
    temperatures = np.linspace(298.16, 873.15, 800)
    colors = ("#145a7b", "#3d7a52", "#c06c20", "#8a3c75")
    for path, color in zip(paths, colors, strict=True):
        energies = [
            thermomechanical_state(float(t), path, residue).stored_energy_upper_bound_J_m2
            for t in temperatures
        ]
        axes[1, 0].plot(temperatures, energies, color=color, label=path.name)
    for gamma in (1.0e-6, 1.0e-5, 1.0e-4):
        axes[1, 0].axhline(gamma, color="#777", ls=":", lw=0.8)
        axes[1, 0].text(865, gamma * 1.08, f"Gamma={gamma:g}", ha="right", fontsize=7)
    axes[1, 0].axvline(WATER_BOILING_POINT_1ATM_K, color="#9a2f2f", ls="--", lw=1.2, label="water 1 atm limit")
    axes[1, 0].axvline(350.0, color="#777", ls=":", lw=1.0, label="350 K CFD reference")
    axes[1, 0].set_yscale("log")
    axes[1, 0].set_ylim(1.0e-10, 1.0e-2)
    axes[1, 0].set(xlabel="Substrate temperature Ts (K)", ylabel="Gamma_crit upper bound (J/m2)", title="(c) SiNx-like 2 nm stored-energy ceiling")
    axes[1, 0].legend(fontsize=6.8, loc="lower right")

    path = next(item for item in paths if item.name == "near_debond_180nm_water")
    duration_grid = np.logspace(-2, math.log10(300.0), 250)
    absorption = band_averaged_absorptance(2.0)
    styles = {100.0: "-", 1000.0: "--"}
    gamma_colors = {1.0e-6: "#145a7b", 1.0e-5: "#7a2e68", 1.0e-4: "#c06c20"}
    for gamma, color in gamma_colors.items():
        threshold = inverse_delamination_temperature(gamma, path, residue)
        target = threshold.required_substrate_temperature_K
        if target is None:
            continue
        for heat_transfer, linestyle in styles.items():
            intensity = [
                required_incident_irradiance_W_m2(
                    target, float(duration), 775.0e-6, absorption, heat_transfer
                )
                / 1.0e4
                for duration in duration_grid
            ]
            axes[1, 1].plot(
                duration_grid,
                intensity,
                color=color,
                ls=linestyle,
                label=f"Gamma {gamma:g}, Treq {target:.0f} K, H {heat_transfer:.0f}",
            )
    axes[1, 1].axhline(
        whole_wafer_irradiance_W_m2(780.0) / 1.0e4,
        color="#555",
        ls=":",
        label="780 W / wafer optical-equivalent",
    )
    axes[1, 1].axhline(
        whole_wafer_irradiance_W_m2(1200.0) / 1.0e4,
        color="#111",
        ls=":",
        label="1200 W / wafer optical-equivalent",
    )
    axes[1, 1].set_xscale("log")
    axes[1, 1].set_yscale("log")
    axes[1, 1].set_ylim(1.0e-1, 1.0e4)
    axes[1, 1].set(xlabel="Continuous irradiation time (s)", ylabel="Required incident irradiance (W/cm2)", title="(d) LED mapping of mechanically derived Treq")
    axes[1, 1].legend(fontsize=6.4, loc="upper right")

    fig.suptitle("300 mm backside 395–400 nm LED: inverse thermomechanical screen", fontsize=14, fontweight="bold")
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)


def plot_mechanism_contour(output_path: Path, residue: Any) -> None:
    configure_plot_style()
    temperatures = np.linspace(298.15, 500.0, 280)
    interface_resistances = np.logspace(-9, -5, 240)
    water_column = 180.0e-9 / 0.6065
    delta = np.empty((interface_resistances.size, temperatures.size))
    gamma = np.empty_like(delta)
    for row_index, resistance in enumerate(interface_resistances):
        path = LocalThermalPath(
            name="contour",
            silicon_residue_resistance_m2K_W=float(resistance),
            residue_water_resistance_m2K_W=1.0e-8,
            water_path_resistance_m2K_W=water_column,
        )
        for column_index, temperature in enumerate(temperatures):
            thermal = local_residue_thermal_state(float(temperature), path)
            mechanical = thermomechanical_state(float(temperature), path, residue)
            delta[row_index, column_index] = thermal.substrate_residue_delta_K
            gamma[row_index, column_index] = max(
                mechanical.stored_energy_upper_bound_J_m2, 1.0e-14
            )
    fig, axes = plt.subplots(1, 2, figsize=(12.2, 4.8), constrained_layout=True)
    mesh0 = axes[0].pcolormesh(
        temperatures,
        interface_resistances,
        delta,
        shading="auto",
        cmap="viridis",
    )
    contour0 = axes[0].contour(
        temperatures,
        interface_resistances,
        delta,
        levels=(0.1, 1, 5, 10, 25, 50, 100),
        colors="white",
        linewidths=0.65,
    )
    axes[0].clabel(contour0, fmt="%g K", fontsize=7)
    fig.colorbar(mesh0, ax=axes[0], label="Ts - Tr (K)")

    mesh1 = axes[1].pcolormesh(
        temperatures,
        interface_resistances,
        gamma,
        shading="auto",
        cmap="magma",
        norm=LogNorm(vmin=1.0e-10, vmax=1.0e-2),
    )
    contour1 = axes[1].contour(
        temperatures,
        interface_resistances,
        gamma,
        levels=(1.0e-7, 1.0e-6, 1.0e-5, 1.0e-4, 1.0e-3),
        colors="white",
        linewidths=0.65,
    )
    axes[1].clabel(contour1, fmt=lambda value: f"{value:g}", fontsize=7)
    fig.colorbar(mesh1, ax=axes[1], label="Gamma_crit (J/m2)")
    for axis, title in zip(
        axes,
        ("(a) Temperature difference", "(b) Stored-energy upper bound"),
        strict=True,
    ):
        axis.set_yscale("log")
        axis.axvline(WATER_BOILING_POINT_1ATM_K, color="#4cc9f0", ls="--", lw=1.2)
        axis.axvline(350.0, color="white", ls=":", lw=1.0)
        axis.set(xlabel="Substrate temperature Ts (K)", ylabel="Si/residue thermal resistance (m2 K/W)", title=title)
    fig.suptitle("SiNx-like 2 nm, 180 nm stagnant-water local path", fontsize=13, fontweight="bold")
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)


def plot_pulse_comparison(output_path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    configure_plot_style()
    selected = [
        row
        for row in rows
        if row["peak_whole_wafer_optical_equivalent_power_W"] == 1200.0
        and row["wafer_thickness_um"] == 775.0
        and row["oxide_thickness_nm"] == 2.0
        and row["duty_cycle"] == 0.5
    ]
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.4), constrained_layout=True)
    colors = {100.0: "#145a7b", 1000.0: "#7a2e68", 10000.0: "#c06c20"}
    for heat_transfer, color in colors.items():
        group = sorted(
            [row for row in selected if row["total_heat_transfer_W_m2K"] == heat_transfer],
            key=lambda item: item["period_s"],
        )
        axes[0].plot(
            [row["period_s"] for row in group],
            [row["pulse_peak_gain_over_same_average_K"] for row in group],
            marker="o",
            color=color,
            label=f"H={heat_transfer:.0f}",
        )
        axes[1].plot(
            [row["period_s"] for row in group],
            [row["pulse_peak_to_valley_K"] for row in group],
            marker="o",
            color=color,
            label=f"H={heat_transfer:.0f}",
        )
    for axis in axes:
        axis.set_xscale("log")
        axis.set_xlabel("Pulse period (s), duty=0.5")
        axis.legend()
    axes[0].set_ylabel("Peak gain over continuous same-average (K)")
    axes[0].set_title("(a) Peak-temperature benefit")
    axes[1].set_ylabel("Peak-to-valley wafer temperature (K)")
    axes[1].set_title("(b) Thermal-cycle amplitude")
    fig.suptitle("1200 W/wafer optical-equivalent peak, 775 µm, native-like oxide", fontsize=12.5, fontweight="bold")
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)


def _threshold_lookup(
    paths: Sequence[LocalThermalPath],
    residue: Any,
    gamma_values: Sequence[float],
) -> dict[tuple[str, float], Any]:
    return {
        (path.name, gamma): inverse_delamination_temperature(gamma, path, residue)
        for path in paths
        for gamma in gamma_values
    }


def build_report_html(
    summary: Mapping[str, Any],
    paths: Sequence[LocalThermalPath],
    residues: Sequence[Any],
    pulse_data: Sequence[Mapping[str, Any]],
    validation: Mapping[str, Any],
) -> str:
    sinx2 = next(item for item in residues if item.name == "sinx_like_2nm")
    sinx10 = next(item for item in residues if item.name == "sinx_like_10nm")
    gamma_values = (1.0e-7, 1.0e-6, 1.0e-5, 1.0e-4, 1.0e-3)
    thresholds = _threshold_lookup(paths, sinx2, gamma_values)

    threshold_header = "".join(f"<th>Γ={gamma:g}</th>" for gamma in gamma_values)
    threshold_body = []
    for path in paths:
        cells = []
        for gamma in gamma_values:
            threshold = thresholds[(path.name, gamma)]
            if not threshold.reached:
                cells.append("<td>1499 Kまで未到達</td>")
                continue
            target = threshold.required_substrate_temperature_K
            delta = threshold.required_substrate_residue_delta_K
            validity = "水1 atm内" if threshold.water_1atm_valid else "水相変化域"
            cells.append(
                f"<td><strong>{fmt(target, 1)} K</strong><br>ΔT={fmt(delta, 1)} K<br><span class='small'>{validity}</span></td>"
            )
        threshold_body.append(
            f"<tr><th>{html.escape(path.name)}</th>{''.join(cells)}</tr>"
        )

    path_body = []
    compatibility_body = []
    for path in paths:
        state350 = local_residue_thermal_state(350.0, path)
        state373 = local_residue_thermal_state(373.15, path)
        gamma373 = thermomechanical_state(373.15, path, sinx2).stored_energy_upper_bound_J_m2
        path_body.append(
            "<tr>"
            f"<th>{html.escape(path.name)}</th>"
            f"<td>{state350.residue_cold_fraction:.4f}</td>"
            f"<td>{state350.substrate_residue_delta_K:.2f}</td>"
            f"<td>{state373.substrate_residue_delta_K:.2f}</td>"
            f"<td>{state350.relaxation_time_s:.3e}</td>"
            f"<td>{gamma373:.3e}</td>"
            "</tr>"
        )
        compatibility_cells = "".join(
            f"<td>{100.0 * local_global_active_area_fraction_ceiling(path, heat_transfer):.4g}%</td>"
            for heat_transfer in (100.0, 1000.0, 10000.0)
        )
        compatibility_body.append(
            f"<tr><th>{html.escape(path.name)}</th>{compatibility_cells}</tr>"
        )

    near_path = next(item for item in paths if item.name == "near_debond_180nm_water")
    led_body = []
    for gamma in (1.0e-6, 1.0e-5, 1.0e-4):
        threshold = inverse_delamination_temperature(gamma, near_path, sinx2)
        target = threshold.required_substrate_temperature_K
        assert target is not None
        row_cells = []
        for duration in (10.0, 30.0, 100.0):
            irradiance = required_incident_irradiance_W_m2(
                target,
                duration,
                775.0e-6,
                band_averaged_absorptance(2.0),
                100.0,
            )
            optical_power = irradiance * wafer_area_m2()
            row_cells.append(
                f"<td>{irradiance/1e4:.2f} W/cm²<br>{optical_power:.0f} W/wafer</td>"
            )
        led_body.append(
            f"<tr><th>{gamma:g}</th><td>{target:.1f}</td><td>{threshold.required_substrate_residue_delta_K:.1f}</td>{''.join(row_cells)}</tr>"
        )

    pulse_selected = sorted(
        [
            row
            for row in pulse_data
            if row["peak_whole_wafer_optical_equivalent_power_W"] == 1200.0
            and row["wafer_thickness_um"] == 775.0
            and row["oxide_thickness_nm"] == 2.0
            and row["duty_cycle"] == 0.5
            and row["total_heat_transfer_W_m2K"] == 1000.0
        ],
        key=lambda item: item["period_s"],
    )
    pulse_body = "".join(
        "<tr>"
        f"<td>{row['period_s']:g}</td>"
        f"<td>{row['pulse_on_s']:g}</td>"
        f"<td>{row['pulse_peak_temperature_K']:.2f}</td>"
        f"<td>{row['same_average_continuous_temperature_K']:.2f}</td>"
        f"<td>{row['pulse_peak_gain_over_same_average_K']:.3f}</td>"
        f"<td>{row['pulse_peak_to_valley_K']:.3f}</td>"
        f"<td>{'要1D確認' if row['lumped_pulse_warning'] else 'lumped範囲'}</td>"
        "</tr>"
        for row in pulse_selected
    )

    well = next(item for item in paths if item.name == "well_bonded_180nm_water")
    perfect = next(item for item in paths if item.name == "perfect_water_sink_extreme")
    gamma_well_2 = thermomechanical_state(373.15, well, sinx2).stored_energy_upper_bound_J_m2
    gamma_near_2 = thermomechanical_state(373.15, near_path, sinx2).stored_energy_upper_bound_J_m2
    gamma_perfect_2 = thermomechanical_state(373.15, perfect, sinx2).stored_energy_upper_bound_J_m2
    gamma_perfect_10 = thermomechanical_state(373.15, perfect, sinx10).stored_energy_upper_bound_J_m2
    tau_max = max(
        local_residue_thermal_state(350.0, path).relaxation_time_s for path in paths
    )

    return f"""<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>裏面UV-LED熱膨張剥離 逆算結果</title>
<style>
:root{{--ink:#17212b;--muted:#596876;--line:#d7e0e7;--paper:#fff;--wash:#f2f7fa;--accent:#7a2e68;--blue:#145a7b;--green:#176b53;--amber:#925d00;--red:#9a2f2f}}
*{{box-sizing:border-box}} body{{margin:0;background:#eaf0f4;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Hiragino Sans","Yu Gothic",sans-serif;line-height:1.7}}
main{{width:min(1180px,calc(100% - 30px));margin:24px auto 70px;padding:40px 48px 54px;background:var(--paper);border:1px solid var(--line);border-radius:16px;box-shadow:0 10px 30px #20304014}}
h1,h2,h3{{line-height:1.35}} h1{{margin:0 0 8px}} h2{{margin-top:2.1em;border-bottom:2px solid var(--line);padding-bottom:.25em}} h3{{color:var(--blue)}}
.meta,.small{{color:var(--muted);font-size:.88rem}} .lead{{font-size:1.08rem;padding:18px 21px;background:#fbf3f8;border-left:5px solid var(--accent);border-radius:8px}}
.grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}} .card{{padding:16px 18px;border:1px solid var(--line);border-radius:10px;background:var(--wash)}}
.good{{border-left:5px solid var(--green)}} .warn{{border-left:5px solid var(--amber)}} .stop{{border-left:5px solid var(--red)}}
table{{width:100%;border-collapse:collapse;margin:12px 0 22px;font-size:.91rem}} th,td{{border:1px solid var(--line);padding:8px 9px;vertical-align:top}} th{{background:#edf3f7;text-align:left}}
img{{display:block;width:100%;height:auto;margin:16px 0;border:1px solid var(--line);border-radius:10px}} code{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}} a{{color:var(--blue);text-underline-offset:2px}}
.scroll{{overflow-x:auto}} @media(max-width:760px){{main{{width:100%;margin:0;padding:25px 18px;border-radius:0}}.grid{{grid-template-columns:1fr}}}}
</style></head><body><main>
<h1>300 mmウエハー裏面 395–400 nm LED<br>熱膨張剥離の逆算結果</h1>
<p class="meta">生成日 2026-08-01 ／ schema {SCHEMA_VERSION} ／ 水bulk 298.15 K</p>
<p class="lead"><strong>答えは単一の温度ではない。</strong> 残渣が取れる温度は、実界面破壊エネルギーΓ、残渣厚み・弾性率・CTE、Si–残渣熱抵抗で大きく変わる。今回のSiN<sub>x</sub>-like 2 nmモデルでは、1 atm水の相変化前に供給できる弾性エネルギー上限は、良接合で{gamma_well_2:.2e} J/m²、near-debond感度で{gamma_near_2:.2e} J/m²、perfect-water-sink極端値で{gamma_perfect_2:.2e} J/m²だった。したがってΓが10<sup>−4</sup> J/m²以上なら、2 nm残渣をこの機構だけで水中剥離する説明は成立しない。</p>

<div class="grid">
<section class="card good"><h3>成立し得る狭い条件</h3><p>すでにSiとの熱接触が非常に弱い、Γが10<sup>−6</sup>–10<sup>−5</sup> J/m²級以下、初期debond/edgeがある、という“ほぼ取れかけ”残渣なら、必要条件へ届き得る。</p></section>
<section class="card stop"><h3>一般説明にはならない</h3><p>良接合2 nm SiN<sub>x</sub>-likeでは、373.15 KでもΓ<sub>crit</sub>は{gamma_well_2:.2e} J/m²。化学結合した膜の剥離を説明する規模ではない。</p></section>
<section class="card warn"><h3>LEDパルスの意味</h3><p>全感度ケースで残渣熱緩和時定数は最大でも{tau_max:.2e} s。ms–sのLED点滅は残渣の熱遅れを利用できず、主にウエハー温度cycleを作る。</p></section>
<section class="card"><h3>350 Kの位置づけ</h3><p>350 Kは判定閾値に使っていない。旧CFDの参考縦線だけで、Γから必要温度を逆算した。</p></section>
</div>

<h2>1. 何K・何K差ならΓへ届くか</h2>
<p>下表はSiN<sub>x</sub>-like 2 nmについて、<code>Γcrit=Γ</code>となる<strong>最初の</strong>基板温度とSi–残渣温度差。<code>Γcrit</code>は形状係数φ=1の最大エネルギーなので、到達しても剥離の十分条件ではない。</p>
<div class="scroll"><table><thead><tr><th>局所熱path</th>{threshold_header}</tr></thead><tbody>{''.join(threshold_body)}</tbody></table></div>
<p><strong>具体例：</strong>near-debond感度ではΓ=10<sup>−6</sup> J/m²に319.7 K、ΔT≈16 K、Γ=10<sup>−5</sup> J/m²に約361 K、ΔT≈48 Kが必要。Γ=10<sup>−4</sup> J/m²では約471 K、ΔT≈132 Kとなり、1 atmの水を液体のまま扱うモデル外へ出る。</p>
<p>10 nm SiN<sub>x</sub>-likeのperfect-water-sink極端値でも、373.15 KでΓ<sub>crit</sub>={gamma_perfect_10:.2e} J/m²。厚みを5倍にするとエネルギーも概ね5倍だが、10<sup>−4</sup> J/m²境界にはほぼ届かない。</p>
<img src="mechanism_contour.png" alt="基板温度とSi残渣熱抵抗に対する温度差と剥離エネルギー上限">

<h2>2. なぜ“水に触れた残渣だけ冷たい”とは限らないか</h2>
<div class="scroll"><table><thead><tr><th>局所熱path</th><th>冷却分率</th><th>ΔT @ Ts=350 K</th><th>ΔT @ Ts=373.15 K</th><th>残渣τ [s]</th><th>Γcrit @373.15 K [J/m²]</th></tr></thead><tbody>{''.join(path_body)}</tbody></table></div>
<p>冷却分率は <code>(Ts−Tr)/(Ts−Twater)</code>。良接合では0.035しかなく、Ts=350 Kでも残渣は約348 Kまで追従する。near-debondでは0.765となるが、その大きな温度差自体が「Si–残渣の熱接触がすでに非常に悪い」ことを仮定している。</p>
<h3>局所温度差とウエハー全体熱収支の両立上限</h3>
<p>180 nm水柱の局所熱流束を、ウエハー全体の <code>H(Ts−Twater)</code> で賄える最大投影面積率は次の通り。near-debondでも <code>H=1000 W m⁻² K⁻¹</code> なら約0.13%に限られる。したがって表の大きなΔTは、残渣が疎な局所spot、非常に強い除熱、または短時間過渡でなければ全ウエハー熱収支と両立しない。</p>
<div class="scroll"><table><thead><tr><th>局所熱path</th><th>H=100</th><th>H=1000</th><th>H=10000</th></tr></thead><tbody>{''.join(compatibility_body)}</tbody></table></div>
<p>なお、高CTE残渣では残渣も熱くなった方がSiとの自由膨張差が大きくなる場合があり、<strong>冷たい残渣ほど必ず剥がれやすい、という単調関係でもない</strong>。材料組成の同定が必要。</p>
<img src="summary.png" alt="光吸収、温度差分率、剥離エネルギー、LED逆算の4パネル図">

<h2>3. 必要温度をLED条件へ写像</h2>
<p>下表はnear-debond / SiN<sub>x</sub>-like 2 nm、775 µm、native-like SiO₂ 2 nm、weak coolingの感度値 <code>H=100 W m⁻² K⁻¹</code>。W/waferは<strong>実際にウエハーへ届く光出力</strong>で、Ushio装置の電気Wではない。</p>
<div class="scroll"><table><thead><tr><th>仮定Γ [J/m²]</th><th>Treq [K]</th><th>ΔTreq [K]</th><th>10 s</th><th>30 s</th><th>100 s</th></tr></thead><tbody>{''.join(led_body)}</tbody></table></div>
<p>global heat-transfer <code>H</code> が100→1000→10000 W m⁻² K⁻¹へ上がると、長時間の必要照度はほぼ比例して増える。ウエハー厚みは主に過渡時間へ効き、定常必要熱流束はほぼ変えない。2 nm native-like oxideのband吸収率は{summary['optics']['native_like_absorptance']:.3f}、70 nmでは{summary['optics']['oxide_70nm_absorptance']:.3f}。</p>

<h2>4. 連続照射とパルス</h2>
<p>1200 W/waferを<strong>光peakの仮定値</strong>として、775 µm、oxide 2 nm、H=1000、duty 0.5、総時間60 sを比較した。同じ平均光powerの連続照射に対するpeak上昇だけを示す。</p>
<div class="scroll"><table><thead><tr><th>period [s]</th><th>on [s]</th><th>pulse peak [K]</th><th>同平均連続 [K]</th><th>peak gain [K]</th><th>peak-valley [K]</th><th>判定</th></tr></thead><tbody>{pulse_body}</tbody></table></div>
<p>短周期ではウエハーが平均powerだけを見るため差が小さい。長周期ほどpeakとcycle振幅は増えるが、残渣τはps–ns級なので残渣の遅れは使えない。<code>on&lt;10 tdiff</code>の行はlumped結果を定量採用せず、1D確認対象。</p>
<img src="pulse_comparison.png" alt="パルス周期と連続同平均照射の比較">

<h2>5. 数値検証</h2>
<ul>
<li>平均Cp逆算とNIST Cp(T)直接積分の最大相対差：{validation['max_abs_inverse_relative_error']:.3%}</li>
<li>代表7条件の1D有限体積平均温度と同じconstant-property lumped解の最大差：{validation['max_abs_1d_mean_vs_lumped_K']:.4f} K</li>
<li>光学：oxide=0でbare-Si Fresnel式へ一致、pulse duty=1で連続constant-Cp解へ一致。</li>
<li>単体試験23件。テストコマンドは下記。</li>
</ul>

<h2>6. 解釈境界と次の測定</h2>
<div class="grid">
<section class="card stop"><h3>まだ言えないこと</h3><ul><li>実残渣が取れる一意の温度</li><li>Ushio 780/1200 Wから実照度への変換</li><li>パルスcycle数から剥離寿命への変換</li><li>水の沸騰・気泡・流れを含むrecipe</li></ul></section>
<section class="card good"><h3>最小の測定</h3><ul><li>ウエハー面の光W/cm²</li><li>裏面・前面温度の時間波形</li><li>wafer近傍水温と流量</li><li>残渣厚み・組成</li><li>付着力またはblister/scratch相当のΓ</li></ul></section>
</div>
<p>もし実際にヒーターで残渣が減るのにΓがこの上限より大きければ、熱膨張剥離より、Arrhenius化学反応、濡れ・気泡、流体力、または395–400 nmのphoto-assisted効果を優先して検証すべき。</p>

<h2>7. 成果物と再実行</h2>
<ul>
<li><a href="../../research_memos/LED_BACKSIDE_THERMOMECHANICAL_THEORY_20260801.html">実装前の理論メモHTML</a></li>
<li><a href="inverse_delamination_thresholds.csv">Γ→必要K/ΔT</a>、<a href="continuous_inverse.csv">必要K→LED強度・時間・厚み</a></li>
<li><a href="local_global_heat_budget.csv">局所/全体熱収支</a>、<a href="pulse_comparison.csv">pulse sweep</a>、<a href="validation.json">独立検証</a>、<a href="summary.json">要約JSON</a></li>
</ul>
<pre><code>python3 -m unittest -v test_led_backside_thermomechanical.py
python3 run_led_backside_thermomechanical.py</code></pre>

<h2>8. 出典</h2>
<ol>
<li><a href="https://www.ushio.co.jp/jp/feature/thermal/product/led.html">Ushio LED加熱ユニット</a>（公式仕様・用途・400 nm例）</li>
<li><a href="https://doi.org/10.1109/JEDS.2024.3365150">Yamada et al., IEEE JEDS 12, 195–200 (2024)</a>（UV-LED HZO anneal）</li>
<li><a href="https://doi.org/10.1016/j.solmat.2008.06.009">Green (2008)</a>（Si 300 Kのn, κ, α）</li>
<li><a href="https://doi.org/10.1364/JOSA.55.001205">Malitson (1965)</a>、<a href="https://doi.org/10.1063/1.367101">Herzinger et al. (1998)</a>（SiO₂/Si光学）</li>
<li><a href="https://webbook.nist.gov/cgi/cbook.cgi?ID=C7440213&amp;Mask=3&amp;Units=SI">NIST SRD 69</a>、<a href="https://doi.org/10.1103/PhysRev.130.1743">Shanks et al. (1963)</a>、<a href="https://doi.org/10.1063/1.333965">Okada–Tokumaru (1984)</a>（Si熱物性・CTE）</li>
<li><a href="https://doi.org/10.1364/AO.51.007229">Tien–Lin (2012)</a>、Vlassak–Nix (1992)（SiN<sub>x</sub> CTE・弾性）</li>
<li><a href="https://doi.org/10.1103/PhysRevLett.96.186101">Ge–Cahill–Braun (2006)</a>、<a href="https://doi.org/10.1016/j.applthermaleng.2024.122762">silica/water MD (2024)</a>（solid/water熱抵抗）</li>
<li><a href="https://doi.org/10.1016/S0040-6090(02)00973-2">Yu–Hutchinson (2003)</a>（薄膜delamination energy）</li>
</ol>
<p class="small">{html.escape(MODEL_NOTICE)}</p>
</main></body></html>"""


def build_summary(
    paths: Sequence[LocalThermalPath],
    residues: Sequence[Any],
    validation: Mapping[str, Any],
) -> dict[str, Any]:
    sinx2 = next(item for item in residues if item.name == "sinx_like_2nm")
    sinx10 = next(item for item in residues if item.name == "sinx_like_10nm")
    path_summary: dict[str, Any] = {}
    for path in paths:
        at350 = local_residue_thermal_state(350.0, path)
        gamma2 = thermomechanical_state(373.15, path, sinx2)
        gamma10 = thermomechanical_state(373.15, path, sinx10)
        path_summary[path.name] = {
            "residue_cold_fraction": at350.residue_cold_fraction,
            "substrate_residue_delta_at_350K_K": at350.substrate_residue_delta_K,
            "relaxation_time_s": at350.relaxation_time_s,
            "maximum_active_area_fraction_at_H1000": local_global_active_area_fraction_ceiling(
                path, 1000.0
            ),
            "gamma_crit_sinx_2nm_at_373p15K_J_m2": gamma2.stored_energy_upper_bound_J_m2,
            "gamma_crit_sinx_10nm_at_373p15K_J_m2": gamma10.stored_energy_upper_bound_J_m2,
            "interpretation": path.interpretation,
        }
    thresholds: dict[str, Any] = {}
    for path in paths:
        thresholds[path.name] = {
            f"gamma_{gamma:g}": inverse_delamination_temperature(
                gamma, path, sinx2
            ).to_dict()
            for gamma in (1.0e-7, 1.0e-6, 1.0e-5, 1.0e-4, 1.0e-3)
        }
    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "date": "2026-08-01",
        "inputs": {
            "wafer_diameter_m": WAFER_DIAMETER_M,
            "wafer_area_m2": wafer_area_m2(),
            "nominal_wafer_thickness_um": 775.0,
            "water_bulk_temperature_K": WATER_BULK_TEMPERATURE_K,
            "wavelengths_nm": [395.0, 400.0],
            "global_heat_transfer_sensitivity_W_m2K": [100.0, 1000.0, 10000.0],
            "ushio_780W_area_reference_W_cm2": whole_wafer_irradiance_W_m2(780.0)
            / 1.0e4,
            "ushio_1200W_area_reference_W_cm2": whole_wafer_irradiance_W_m2(1200.0)
            / 1.0e4,
            "power_reference_warning": (
                "area division only; not electrical-to-optical or delivery calibration"
            ),
        },
        "optics": {
            "bare_si_absorptance": band_averaged_absorptance(0.0),
            "native_like_absorptance": band_averaged_absorptance(2.0),
            "oxide_70nm_absorptance": band_averaged_absorptance(70.0),
            "absorption_depth_395_nm": optical_absorption_air_sio2_si(
                395.0, 0.0
            ).silicon_absorption_depth_nm,
            "absorption_depth_400_nm": optical_absorption_air_sio2_si(
                400.0, 0.0
            ).silicon_absorption_depth_nm,
        },
        "local_paths": path_summary,
        "sinx_2nm_inverse_thresholds": thresholds,
        "validation": {
            "max_abs_inverse_relative_error": validation[
                "max_abs_inverse_relative_error"
            ],
            "max_abs_1d_mean_vs_lumped_K": validation[
                "max_abs_1d_mean_vs_lumped_K"
            ],
        },
        "claim_boundary": {
            "gamma_crit_meaning": (
                "phi=1 bonded-film stored elastic energy per area; necessary, not sufficient"
            ),
            "aqueous_validity": "T <= 373.15 K only for 1 atm no-phase-change interpretation",
            "residue_cases": [asdict(item) for item in residues],
            "photochemistry": "not modelled",
            "fatigue": "stress amplitude reported; no cycle-to-removal law",
        },
    }


def write_readme(path: Path, summary: Mapping[str, Any]) -> None:
    near = summary["local_paths"]["near_debond_180nm_water"]
    well = summary["local_paths"]["well_bonded_180nm_water"]
    text = f"""# 300 mm裏面UV-LED熱膨張剥離 逆算screen

詳細は `index.html` と、実装前に固定した
`../../research_memos/LED_BACKSIDE_THERMOMECHANICAL_THEORY_20260801.html` を参照。

## 要点

- 一意の「剥がれる温度」は出していない。仮定Γごとに必要な基板温度とSi–残渣温度差を逆算した。
- SiNx-like 2 nmのΓcrit上限（373.15 K）は、良接合で {well['gamma_crit_sinx_2nm_at_373p15K_J_m2']:.3e} J/m2、near-debond感度で {near['gamma_crit_sinx_2nm_at_373p15K_J_m2']:.3e} J/m2。
- nm残渣の熱緩和は全感度ケースでµsより十分短い。ms–s LED pulseは残渣の熱遅れを利用しない。
- near-debond局所pathを全体H=1000 W/m2/Kと両立できる投影面積率上限は {100.0 * near['maximum_active_area_fraction_at_H1000']:.3g}%。大きな温度差を全面へ適用しない。
- 780/1200 Wはwhole-wafer optical-equivalent参考線であり、Ushio装置の電気Wを光Wへ変換していない。
- `Gamma_crit`はphi=1の弾性エネルギー上限。実Γ、初期crack、形状が別途必要。

## 再実行

```bash
python3 -m unittest -v test_led_backside_thermomechanical.py
python3 run_led_backside_thermomechanical.py
```
"""
    path.write_text(text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    args = parser.parse_args()
    output_dir: Path = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    if not THEORY_MEMO.exists():
        raise FileNotFoundError(
            "the pre-implementation theory memo must exist before running the model"
        )

    paths = default_local_paths()
    residues = default_residue_cases()

    optical = optical_rows()
    local = local_path_rows(paths)
    local_global = local_global_compatibility_rows(paths)
    mechanical = mechanical_sweep_rows(paths, residues)
    inverse = inverse_threshold_rows(paths, residues)
    delta_inverse = delta_inverse_rows(paths)
    continuous = continuous_inverse_rows(paths, residues)
    forward = forward_reference_rows(paths, residues)
    pulses = pulse_rows(paths, residues)
    validation = validation_payload()
    summary = build_summary(paths, residues, validation)
    summary["theory_memo"] = {
        "path": str(THEORY_MEMO),
        "sha256": sha256(THEORY_MEMO),
    }

    write_csv(output_dir / "optical_absorption.csv", optical)
    write_csv(output_dir / "local_thermal_paths.csv", local)
    write_csv(output_dir / "local_global_heat_budget.csv", local_global)
    write_csv(output_dir / "thermomechanical_temperature_sweep.csv", mechanical)
    write_csv(output_dir / "inverse_delamination_thresholds.csv", inverse)
    write_csv(output_dir / "temperature_difference_inverse.csv", delta_inverse)
    write_csv(output_dir / "continuous_inverse.csv", continuous)
    write_csv(output_dir / "forward_reference.csv", forward)
    write_csv(output_dir / "pulse_comparison.csv", pulses)
    write_json(output_dir / "validation.json", validation)
    write_json(output_dir / "summary.json", summary)

    plot_summary(output_dir / "summary.png", paths, residues)
    plot_mechanism_contour(output_dir / "mechanism_contour.png", residues[0])
    plot_pulse_comparison(output_dir / "pulse_comparison.png", pulses)

    report_html = build_report_html(summary, paths, residues, pulses, validation)
    (output_dir / "index.html").write_text(report_html, encoding="utf-8")
    write_readme(output_dir / "README_JA.md", summary)

    artifact_names = sorted(
        path.name
        for path in output_dir.iterdir()
        if path.is_file() and path.name != "manifest_sha256.json"
    )
    manifest = {
        "schema_version": "sha256-manifest/v1",
        "theory_memo": {
            "path": str(THEORY_MEMO),
            "sha256": sha256(THEORY_MEMO),
        },
        "artifacts": {
            name: sha256(output_dir / name) for name in artifact_names
        },
    }
    write_json(output_dir / "manifest_sha256.json", manifest)
    print(json.dumps({"output_dir": str(output_dir), "summary": summary}, ensure_ascii=False, indent=2, default=_json_default))


if __name__ == "__main__":
    main()

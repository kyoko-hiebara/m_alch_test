#!/usr/bin/env python3
"""CLI for the literature-anchored multi-arm WET sequence sweep."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

from literature_parameters import LITERATURE_ETCH_PRESETS
from literature_sweep import nominal_preset_names
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS
from wet_sequence_sweep import (
    WET_SEQUENCE_ARMS,
    WetSequenceSweepConfig,
    run_wet_sequence_sweep,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run HF/rinse/second-WET and oxidation/fluoride controls. The "
            "primary clock uses blanket WER; secondary coefficients are "
            "uncalibrated screening assumptions, not recipes."
        )
    )
    parser.add_argument(
        "--geometry",
        choices=tuple(GEOMETRY_PRESETS),
        action="append",
        help="repeat to select geometries (default: both straight-wall standards)",
    )
    parser.add_argument(
        "--preset",
        choices=tuple(LITERATURE_ETCH_PRESETS),
        action="append",
        help="repeat to select blanket-WER presets (default: nominal SiN/SiOCN)",
    )
    parser.add_argument(
        "--arm",
        choices=tuple(WET_SEQUENCE_ARMS),
        action="append",
        help="repeat to select sequence arms (default: all six arms)",
    )
    parser.add_argument(
        "--primary-clear-fraction",
        type=float,
        default=0.80,
        help="primary HF duration divided by depth/blanket-WER (default: 0.80)",
    )
    parser.add_argument("--rinse-duration-s", type=float, default=30.0)
    parser.add_argument(
        "--second-wet-clear-fraction", type=float, default=0.25
    )
    parser.add_argument("--oxidation-clear-fraction", type=float, default=0.25)
    parser.add_argument("--fluoride-clear-fraction", type=float, default=0.25)
    parser.add_argument(
        "--solution-temperature-k",
        type=float,
        default=298.15,
        help="independent solution-bulk boundary temperature [K]",
    )
    parser.add_argument(
        "--substrate-temperature-k",
        type=float,
        default=298.15,
        help="independent Si substrate-backside boundary temperature [K]",
    )
    parser.add_argument(
        "--reactive-chunks",
        type=int,
        default=12,
        help="piecewise-constant thermal coupling chunks per reactive step",
    )
    parser.add_argument(
        "--rinse-chunks",
        type=int,
        default=4,
        help="piecewise-constant thermal coupling chunks per rinse",
    )
    parser.add_argument(
        "--second-wet-rate-multiplier",
        type=float,
        default=0.70,
        help="uncalibrated multiplier relative to k_ref=blanket-WER/depth",
    )
    parser.add_argument(
        "--oxidation-rate-multiplier", type=float, default=1.00
    )
    parser.add_argument(
        "--fluoride-rate-multiplier", type=float, default=2.00
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent case processes; 0 selects up to 4 automatically",
    )
    parser.add_argument(
        "--list-arms",
        action="store_true",
        help="print the six arm definitions and exit",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="ordinary JSON output path; no hash-based storage is used",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    if args.list_arms:
        payload: dict[str, object] = {
            "arms": {
                name: arm.to_dict() for name, arm in WET_SEQUENCE_ARMS.items()
            }
        }
    else:
        geometries = tuple(dict.fromkeys(args.geometry or DEFAULT_GEOMETRY_NAMES))
        presets = tuple(dict.fromkeys(args.preset or nominal_preset_names()))
        arms = tuple(dict.fromkeys(args.arm or WET_SEQUENCE_ARMS))
        case_count = len(geometries) * len(presets)
        if args.workers < 0:
            raise ValueError("workers must be zero or a positive integer")
        workers = (
            min(4, os.cpu_count() or 1, case_count)
            if args.workers == 0
            else min(args.workers, case_count)
        )
        config = WetSequenceSweepConfig(
            geometries=geometries,
            presets=presets,
            arms=arms,
            primary_hf_clear_time_fraction=args.primary_clear_fraction,
            rinse_duration_s=args.rinse_duration_s,
            second_wet_clear_time_fraction=args.second_wet_clear_fraction,
            oxidation_clear_time_fraction=args.oxidation_clear_fraction,
            fluoride_clear_time_fraction=args.fluoride_clear_fraction,
            solution_bulk_temperature_K=args.solution_temperature_k,
            substrate_backside_temperature_K=args.substrate_temperature_k,
            integration_chunks_per_reactive_step=args.reactive_chunks,
            integration_chunks_per_rinse=args.rinse_chunks,
            parallel_workers=workers,
            second_wet_rate_multiplier=args.second_wet_rate_multiplier,
            oxidation_rate_multiplier=args.oxidation_rate_multiplier,
            fluoride_rate_multiplier=args.fluoride_rate_multiplier,
        )
        payload = run_wet_sequence_sweep(config)
    # Strict JSON: fail loudly rather than writing implementation-specific
    # NaN/Infinity tokens if a solver ever produces a non-finite value.
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    return payload


if __name__ == "__main__":
    main()

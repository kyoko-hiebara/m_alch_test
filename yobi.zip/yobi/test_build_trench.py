from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

import build_trench


ROOT = Path(__file__).resolve().parent


class BuildTrenchTests(unittest.TestCase):
    def parse(self, *arguments: str):
        return build_trench.build_parser().parse_args(
            ["--si", str(ROOT / "si_8atom.xyz"), "--sin", str(ROOT / "SiN_56atom.xyz"), *arguments]
        )

    def test_bare_trench_geometry_and_xy_period(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "bare.xyz"
            args = self.parse(
                "--substrate-thickness", "24",
                "--trench-depth", "12",
                "--trench-width", "16",
                "--structure-depth", "16",
                "--sidewall-thickness", "6",
                "--vacuum", "2",
                "--sin-mode", "none",
                "-o", str(output),
            )
            species, positions, groups, cell, stats = build_trench.build(args)

            lattice_period = 5.468728
            self.assertAlmostEqual(stats.actual_length_x, 3 * lattice_period, places=7)
            self.assertAlmostEqual(cell[0, 0], stats.actual_length_x, places=7)
            self.assertAlmostEqual(cell[1, 1], 6 * lattice_period, places=7)
            self.assertAlmostEqual(cell[2, 2], 28.0, places=7)
            self.assertAlmostEqual(stats.length_y, cell[1, 1], places=7)
            self.assertTrue(np.all(groups == "Si_substrate"))
            self.assertTrue(np.all(species == "Si"))
            self.assertTrue(np.all((positions[:, 1] >= 0.0) & (positions[:, 1] < cell[1, 1])))
            local = positions - np.asarray([0.0, 0.0, 2.0])
            cavity = (
                (local[:, 1] > stats.sidewall_thickness + build_trench.TOL)
                & (
                    local[:, 1]
                    < stats.sidewall_thickness + 16.0 - build_trench.TOL
                )
                & (local[:, 2] > 12.0 + build_trench.TOL)
            )
            self.assertFalse(np.any(cavity))
            header = output.read_text(encoding="utf-8").splitlines()[1]
            self.assertIn('pbc="T T F"', header)
            self.assertIn("geometry_shift_y=0.00000000", header)
            self.assertIn("termination_scope=all", header)

            seam_bond_found = False
            for first in range(len(positions) - 1):
                raw_delta = positions[first + 1 :] - positions[first]
                crosses_y = np.abs(raw_delta[:, 1]) > 0.5 * cell[1, 1]
                delta = raw_delta.copy()
                delta[:, 0] -= np.rint(delta[:, 0] / cell[0, 0]) * cell[0, 0]
                delta[:, 1] -= np.rint(delta[:, 1] / cell[1, 1]) * cell[1, 1]
                distance = np.linalg.norm(delta, axis=1)
                if np.any(crosses_y & np.isclose(distance, 2.368028687, atol=1.0e-6)):
                    seam_bond_found = True
                    break
            self.assertTrue(seam_bond_found)

    def test_fill_is_commensurate_and_has_no_severe_overlap(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "fill.xyz"
            args = self.parse(
                "--substrate-thickness", "30",
                "--trench-depth", "18",
                "--trench-width", "20",
                "--structure-depth", "16",
                "--sidewall-thickness", "8",
                "--vacuum", "2",
                "--sin-mode", "fill",
                "--termination", "h",
                "--termination-scope", "trench",
                "--phase-trials", "3",
                "-o", str(output),
            )
            species, positions, groups, cell, stats = build_trench.build(args)

            self.assertGreater(np.count_nonzero(groups == "SiN_fill"), 0)
            self.assertGreater(np.count_nonzero(species == "N"), 0)
            self.assertGreater(np.count_nonzero(groups == "H_termination"), 0)
            self.assertIsNotNone(stats.sin_strain)
            self.assertLessEqual(abs(float(stats.sin_strain)), args.max_sin_strain)
            substrate = positions[groups == "Si_substrate"]
            fill = positions[groups == "SiN_fill"]
            fill_species = species[groups == "SiN_fill"]
            interface = build_trench.minimum_distances(
                fill,
                substrate,
                stats.actual_length_x,
                length_y=cell[1, 1],
            )
            self.assertGreaterEqual(np.min(interface[fill_species == "N"]), 1.60 - 1.0e-8)
            self.assertGreaterEqual(np.min(interface[fill_species == "Si"]), 2.10 - 1.0e-8)
            components = build_trench.sin_bonded_components(
                fill_species,
                fill,
                stats.actual_length_x,
                length_y=cell[1, 1],
            )
            self.assertTrue(all(len(component) >= args.fill_min_component_atoms for component in components))
            native_substrate_coordination = np.zeros(len(substrate), dtype=int)
            interface_substrate_coordination = np.zeros(len(substrate), dtype=int)
            interface_fill_coordination = np.zeros(len(fill), dtype=int)
            for index, atom in enumerate(substrate):
                delta = substrate - atom
                delta[:, 0] -= np.rint(delta[:, 0] / stats.actual_length_x) * stats.actual_length_x
                delta[:, 1] -= np.rint(delta[:, 1] / cell[1, 1]) * cell[1, 1]
                distance = np.linalg.norm(delta, axis=1)
                native_substrate_coordination[index] = np.count_nonzero(
                    (distance > 1.0e-8) & (distance <= 2.60)
                )
            for index, atom in enumerate(fill):
                delta = substrate - atom
                delta[:, 0] -= np.rint(delta[:, 0] / stats.actual_length_x) * stats.actual_length_x
                delta[:, 1] -= np.rint(delta[:, 1] / cell[1, 1]) * cell[1, 1]
                cutoff = 2.25 if fill_species[index] == "N" else 2.75
                bonded = np.flatnonzero(np.linalg.norm(delta, axis=1) <= cutoff)
                interface_fill_coordination[index] = len(bonded)
                interface_substrate_coordination[bonded] += 1
            self.assertTrue(
                np.all(native_substrate_coordination + interface_substrate_coordination <= 4)
            )
            internal = build_trench.sin_internal_coordination(
                fill_species,
                fill,
                stats.actual_length_x,
                length_y=cell[1, 1],
            )
            nominal = np.where(fill_species == "N", 3, 4)
            newly_bonded = interface_fill_coordination > 0
            self.assertTrue(
                np.all(
                    internal[newly_bonded] + interface_fill_coordination[newly_bonded]
                    <= nominal[newly_bonded]
                )
            )
            distance, pair = build_trench.minimum_pair_distance_below(
                positions,
                stats.actual_length_x,
                0.65,
                length_y=cell[1, 1],
            )
            self.assertIsNone(pair, msg=f"severe overlap at {distance}")

    def test_residue_is_deterministic_and_wall_anchored(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            outputs = [Path(directory) / "residue1.xyz", Path(directory) / "residue2.xyz"]
            results = []
            for output in outputs:
                args = self.parse(
                    "--substrate-thickness", "40",
                    "--trench-depth", "25",
                    "--trench-width", "30",
                    "--structure-depth", "32",
                    "--sin-mode", "residue",
                    "--residue-coverage", "0.50",
                    "--residue-max-height", "1",
                    "--residue-min-atoms", "1",
                    "--phase-trials", "3",
                    "--seed", "6",
                    "-o", str(output),
                )
                results.append(build_trench.build(args))
            species1, positions1, groups1, cell1, stats1 = results[0]
            species2, positions2, groups2, _, _ = results[1]
            np.testing.assert_array_equal(species1, species2)
            np.testing.assert_array_equal(groups1, groups2)
            np.testing.assert_allclose(positions1, positions2, atol=1.0e-12)

            substrate = positions1[groups1 == "Si_substrate"]
            residue = positions1[groups1 == "SiN_residue"]
            residue_species = species1[groups1 == "SiN_residue"]
            self.assertGreater(len(residue), 0)
            distances = build_trench.minimum_distances(
                residue,
                substrate,
                stats1.actual_length_x,
                length_y=cell1[1, 1],
            )
            contact_cutoff = np.where(residue_species == "N", 2.25, 2.75)
            self.assertGreater(np.count_nonzero(distances <= contact_cutoff), 0)
            # The unshifted trench floor is z=15 A and default vacuum shifts it to z=20 A.
            self.assertLessEqual(np.max(residue[:, 2]), 21.0 + build_trench.TOL)

    def test_h_termination_avoids_hydrogen_crowding(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            args = self.parse(
                "--substrate-thickness", "24",
                "--trench-depth", "12",
                "--trench-width", "16",
                "--structure-depth", "16",
                "--sidewall-thickness", "6",
                "--termination", "h",
                "--termination-scope", "all",
                "-o", str(Path(directory) / "h.xyz"),
            )
            _, positions, groups, cell, stats = build_trench.build(args)
            hydrogen = positions[groups == "H_termination"]
            substrate = positions[groups == "Si_substrate"]
            self.assertGreater(len(hydrogen), 0)
            self.assertEqual(stats.termination_collision_skips, 0)
            self.assertEqual(
                stats.termination_h + stats.dangling_covered_by_sin,
                stats.dangling_considered,
            )
            self.assertGreater(np.count_nonzero(hydrogen[:, 2] < np.min(substrate[:, 2])), 0)
            self.assertGreater(np.count_nonzero(hydrogen[:, 2] > np.max(substrate[:, 2])), 0)
            sih = build_trench.minimum_distances(
                hydrogen,
                substrate,
                stats.actual_length_x,
                length_y=cell[1, 1],
            )
            np.testing.assert_allclose(sih, 1.48, atol=1.0e-7)
            _, crowded_pair = build_trench.minimum_pair_distance_below(
                hydrogen,
                stats.actual_length_x,
                1.60 - 1.0e-8,
                length_y=cell[1, 1],
            )
            self.assertIsNone(crowded_pair)

    def test_bottom_thickness_alternative(self) -> None:
        args = self.parse(
            "--bottom-thickness", "12",
            "--trench-depth", "18",
        )
        self.assertAlmostEqual(build_trench.validate_arguments(args), 30.0)

    def test_default_and_generated_aspect_ratio_are_twenty(self) -> None:
        defaults = self.parse()
        self.assertAlmostEqual(
            defaults.trench_depth / defaults.trench_width, 20.0, places=8
        )
        with tempfile.TemporaryDirectory() as directory:
            args = self.parse(
                "--bottom-thickness", "5.468728",
                "--trench-depth", "80",
                "--trench-width", "4",
                "--structure-depth", "5.468728",
                "--length-snap", "strict",
                "--vacuum", "2",
                "-o", str(Path(directory) / "aspect20.xyz"),
            )
            _, positions, groups, cell, stats = build_trench.build(args)
            self.assertAlmostEqual(args.trench_depth / args.trench_width, 20.0)
            local = positions[groups == "Si_substrate"] - np.asarray([0.0, 0.0, 2.0])
            in_cavity = (
                (local[:, 1] > stats.sidewall_thickness + build_trench.TOL)
                & (
                    local[:, 1]
                    < stats.sidewall_thickness + args.trench_width - build_trench.TOL
                )
                & (local[:, 2] > args.bottom_thickness + build_trench.TOL)
            )
            self.assertFalse(np.any(in_cavity))
            self.assertTrue(np.any(local[:, 2] <= args.bottom_thickness))
            self.assertTrue(
                np.any(
                    (local[:, 1] < stats.sidewall_thickness)
                    & (local[:, 2] > args.bottom_thickness)
                )
            )
            self.assertTrue(np.all((positions[:, 1] >= 0.0) & (positions[:, 1] < cell[1, 1])))

    def test_one_sin_atom_cannot_cover_two_dangling_bonds(self) -> None:
        angle = np.radians(20.0)
        dangling = [
            (0, np.asarray([1.0, 0.0, 0.0])),
            (0, np.asarray([np.cos(angle), np.sin(angle), 0.0])),
        ]
        assignments = build_trench.assign_sin_covered_dangling_bonds(
            dangling=dangling,
            substrate_positions=np.asarray([[0.0, 0.0, 0.0]]),
            sin_species=np.asarray(["N"]),
            sin_positions=np.asarray([[1.70 * np.cos(angle / 2), 1.70 * np.sin(angle / 2), 0.0]]),
            length_x=20.0,
        )
        self.assertEqual(len(assignments), 1)
        self.assertEqual(len(set(assignments.values())), 1)

    def test_sub_lattice_resolution_trench_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            args = self.parse(
                "--substrate-thickness", "24",
                "--trench-depth", "0.1",
                "--trench-width", "16",
                "--sidewall-thickness", "6",
                "-o", str(Path(directory) / "too_narrow.xyz"),
            )
            with self.assertRaisesRegex(ValueError, "removes no Si atoms"):
                build_trench.build(args)

    def test_oh_geometry_and_all_z_surfaces(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            # Regression: adding the top/bottom rays used to perturb the greedy
            # OH orientation sequence and leave one unrelated trench ray bare.
            args = self.parse(
                "--substrate-thickness", "40",
                "--trench-depth", "25",
                "--trench-width", "10.937456",
                "--structure-depth", "16",
                "--termination", "oh",
                "--termination-scope", "all",
                "-o", str(Path(directory) / "oh.xyz"),
            )
            _, positions, groups, cell, stats = build_trench.build(args)
            oxygen = positions[groups == "OH_oxygen"]
            hydrogen = positions[groups == "OH_hydrogen"]
            substrate = positions[groups == "Si_substrate"]
            self.assertGreater(len(oxygen), 0)
            self.assertEqual(len(oxygen), len(hydrogen))
            self.assertEqual(stats.termination_collision_skips, 0)
            self.assertEqual(
                stats.termination_o + stats.dangling_covered_by_sin,
                stats.dangling_considered,
            )
            self.assertGreater(np.count_nonzero(oxygen[:, 2] < np.min(substrate[:, 2])), 0)
            self.assertGreater(np.count_nonzero(oxygen[:, 2] > np.max(substrate[:, 2])), 0)
            oh = build_trench.minimum_distances(
                oxygen,
                hydrogen,
                stats.actual_length_x,
                length_y=cell[1, 1],
            )
            sio = build_trench.minimum_distances(
                oxygen,
                substrate,
                stats.actual_length_x,
                length_y=cell[1, 1],
            )
            np.testing.assert_allclose(oh, 0.98, atol=1.0e-7)
            np.testing.assert_allclose(sio, 1.63, atol=1.0e-7)
            _, crowded_oxygen = build_trench.minimum_pair_distance_below(
                oxygen,
                stats.actual_length_x,
                1.80 - 1.0e-8,
                length_y=cell[1, 1],
            )
            _, crowded_hydrogen = build_trench.minimum_pair_distance_below(
                hydrogen,
                stats.actual_length_x,
                1.60 - 1.0e-8,
                length_y=cell[1, 1],
            )
            self.assertIsNone(crowded_oxygen)
            self.assertIsNone(crowded_hydrogen)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Command-line entry point for the uncalibrated GAP FILL screening models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from simulation_workflow import (
    ScreeningConfig,
    VALID_MODES,
    run_screening_workflow,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run thermal, 1-D, 2-D, WET-sequence, and graph-KMC screening "
            "models. Built-in kinetics are uncalibrated and are not recipes."
        )
    )
    parser.add_argument(
        "--mode",
        choices=("all",) + VALID_MODES,
        action="append",
        help="model layer to run; repeat for several (default: all)",
    )
    parser.add_argument(
        "--geometry",
        choices=tuple(GEOMETRY_PRESETS),
        default=DEFAULT_GEOMETRY_NAMES[0],
    )
    parser.add_argument(
        "--material",
        choices=("SiN", "SiCN", "SiOCN"),
        default="SiN",
    )
    parser.add_argument(
        "--solution-temperature-k",
        type=float,
        default=298.15,
        help="HF solution bulk temperature [K]",
    )
    parser.add_argument(
        "--substrate-temperature-k",
        type=float,
        default=323.15,
        help="Si substrate backside temperature [K]",
    )
    parser.add_argument("--duration-s", type=float, default=2.0)
    parser.add_argument("--grid-spacing-nm", type=float, default=1.0)
    parser.add_argument("--reservoir-height-nm", type=float, default=10.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--kmc-sites", type=int, default=24)
    parser.add_argument("--kmc-max-events", type=int, default=48)
    parser.add_argument(
        "--wetting",
        action="store_true",
        help="enable the explicit 2-D wet/dry/gas phase model",
    )
    parser.add_argument(
        "--new-void-filling-mode",
        choices=("liquid_inherited", "capillary"),
        default="liquid_inherited",
        help=(
            "liquid_inherited is the fully-filled GAP FILL default; capillary "
            "represents an explicit dry-seam/dewetting hypothesis"
        ),
    )
    parser.add_argument("--contact-angle-deg", type=float, default=60.0)
    parser.add_argument(
        "--entrance-wetting-delay-s",
        type=float,
        default=0.0,
        help="requires --new-void-filling-mode capillary",
    )
    parser.add_argument(
        "--entrance-pinning-pressure-pa",
        type=float,
        default=0.0,
        help="requires --new-void-filling-mode capillary",
    )
    parser.add_argument("--reservoir-overpressure-pa", type=float, default=0.0)
    parser.add_argument(
        "--maximum-contact-line-speed-nm-s",
        type=float,
        help="requires --new-void-filling-mode capillary",
    )
    parser.add_argument("--bottom-gas-pocket-height-nm", type=float, default=0.0)
    parser.add_argument(
        "--bottom-gas-activation-depth-fraction", type=float, default=0.90
    )
    parser.add_argument(
        "--gas-dissolution-time-s",
        type=float,
        help="first-order gas loss time; omitted means a persistent pocket",
    )
    parser.add_argument("--gas-residual-fraction", type=float, default=0.0)
    parser.add_argument(
        "--gas-compression-mode",
        choices=("ideal", "none"),
        default="ideal",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="optional ordinary JSON output path; no hash-based directory is used",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    requested = args.mode or ["all"]
    modes = VALID_MODES if "all" in requested else tuple(requested)
    config = ScreeningConfig(
        geometry=args.geometry,
        material=args.material,
        solution_bulk_temperature_K=args.solution_temperature_k,
        substrate_backside_temperature_K=args.substrate_temperature_k,
        duration_s=args.duration_s,
        grid_spacing_nm=args.grid_spacing_nm,
        reservoir_height_nm=args.reservoir_height_nm,
        random_seed=args.seed,
        kmc_sites=args.kmc_sites,
        kmc_max_events=args.kmc_max_events,
        wetting_enabled=args.wetting,
        wetting_new_void_filling_mode=args.new_void_filling_mode,
        advancing_contact_angle_deg=args.contact_angle_deg,
        entrance_wetting_delay_s=args.entrance_wetting_delay_s,
        entrance_pinning_pressure_Pa=args.entrance_pinning_pressure_pa,
        reservoir_overpressure_Pa=args.reservoir_overpressure_pa,
        maximum_contact_line_speed_nm_s=(
            args.maximum_contact_line_speed_nm_s
        ),
        bottom_gas_pocket_seed_height_nm=(
            args.bottom_gas_pocket_height_nm
        ),
        bottom_gas_activation_depth_fraction=(
            args.bottom_gas_activation_depth_fraction
        ),
        gas_dissolution_time_s=args.gas_dissolution_time_s,
        gas_residual_fraction=args.gas_residual_fraction,
        gas_compression_mode=args.gas_compression_mode,
    )
    payload = run_screening_workflow(config, modes)
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    return payload


if __name__ == "__main__":
    main()

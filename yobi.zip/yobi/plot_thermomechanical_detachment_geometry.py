"""Plot a geometry-resolved thermomechanical detachment screening figure.

The figure is a local bottom-of-trench cross-section for the 10 x 180 nm
straight-wall geometry.  It extends the existing two-resistance and thin-film
thermoelastic model spatially by prescribing a Si/residue thermal-resistance
profile that rises from a well-contacted centre to near-debonded residue edges.

The interfacial quantity is U_A / Gamma, where U_A is the film elastic energy
integrated through the residue thickness.  It is a screening proxy, not an
energy-release rate from a crack-growth or cohesive-zone solution.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any

os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex-mpl-thermomechanical-geometry")

import matplotlib

matplotlib.use("Agg")
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import LineCollection
from matplotlib.colors import LogNorm, Normalize
from matplotlib.patches import Polygon

from led_backside_thermomechanical import (
    WATER_BULK_TEMPERATURE_K,
    WATER_THERMAL_CONDUCTIVITY_W_MK,
    LocalThermalPath,
    ResidueMechanicalProperties,
    band_averaged_absorptance,
    default_residue_cases,
    inverse_delamination_temperature,
    required_incident_irradiance_W_m2,
    silicon_free_thermal_strain,
    thermomechanical_state,
)


# Mandatory editable-text settings for publication exports.
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
mpl.rcParams.update(
    {
        "font.size": 6.5,
        "axes.titlesize": 7.2,
        "axes.labelsize": 6.5,
        "xtick.labelsize": 5.8,
        "ytick.labelsize": 5.8,
        "axes.linewidth": 0.7,
        "legend.frameon": False,
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    }
)


DEFAULT_OUTPUT_DIR = Path(
    "figures/thermomechanical_detachment_geometry_20260802"
)


@dataclass(frozen=True)
class FigureScenario:
    trench_width_nm: float = 10.0
    trench_depth_nm: float = 180.0
    local_window_half_width_nm: float = 7.0
    local_window_substrate_depth_nm: float = 8.0
    local_window_water_height_nm: float = 8.0
    residue_width_nm: float = 9.0
    residue_thickness_nm: float = 2.0
    centre_interface_resistance_m2K_W: float = 1.0e-8
    edge_interface_resistance_m2K_W: float = 1.0e-6
    edge_decay_length_nm: float = 0.75
    residue_water_resistance_m2K_W: float = 1.0e-8
    water_path_length_nm: float = 180.0
    fracture_energy_J_m2: float = 1.0e-5
    illumination_duration_s: float = 30.0
    wafer_thickness_um: float = 775.0
    oxide_thickness_nm: float = 2.0
    total_heat_transfer_W_m2K: float = 100.0
    deformation_magnification: float = 1500.0
    interface_points: int = 401

    def __post_init__(self) -> None:
        positive = (
            "trench_width_nm",
            "trench_depth_nm",
            "local_window_half_width_nm",
            "local_window_substrate_depth_nm",
            "local_window_water_height_nm",
            "residue_width_nm",
            "residue_thickness_nm",
            "centre_interface_resistance_m2K_W",
            "edge_interface_resistance_m2K_W",
            "edge_decay_length_nm",
            "residue_water_resistance_m2K_W",
            "water_path_length_nm",
            "fracture_energy_J_m2",
            "illumination_duration_s",
            "wafer_thickness_um",
            "total_heat_transfer_W_m2K",
            "deformation_magnification",
        )
        for name in positive:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.residue_width_nm >= self.trench_width_nm:
            raise ValueError("residue_width_nm must be smaller than trench_width_nm")
        if self.edge_interface_resistance_m2K_W <= self.centre_interface_resistance_m2K_W:
            raise ValueError("edge resistance must exceed centre resistance")
        if self.interface_points < 51 or self.interface_points % 2 == 0:
            raise ValueError("interface_points must be an odd integer >= 51")


@dataclass(frozen=True)
class DetachmentFields:
    substrate_temperature_K: float
    incident_irradiance_W_cm2: float
    silicon_free_strain: float
    x_nm: np.ndarray
    interface_resistance_m2K_W: np.ndarray
    residue_temperature_K: np.ndarray
    substrate_residue_delta_K: np.ndarray
    mismatch_strain: np.ndarray
    biaxial_stress_Pa: np.ndarray
    elastic_energy_density_J_m3: np.ndarray
    elastic_energy_per_area_J_m2: np.ndarray
    energy_to_fracture_ratio: np.ndarray
    normal_total_strain: np.ndarray

    def edge_index(self) -> int:
        maximum = float(np.max(self.energy_to_fracture_ratio))
        maxima = np.flatnonzero(
            np.isclose(
                self.energy_to_fracture_ratio,
                maximum,
                rtol=1.0e-10,
                atol=1.0e-14,
            )
        )
        # The profile is symmetric.  Use the right-hand maximum so that the
        # callout remains local and does not cross the residue in the figure.
        return int(maxima[-1])


def residue_properties(scenario: FigureScenario) -> ResidueMechanicalProperties:
    anchor = default_residue_cases()[0]
    return replace(
        anchor,
        name=f"sinx_like_{scenario.residue_thickness_nm:g}nm_geometry",
        thickness_m=scenario.residue_thickness_nm * 1.0e-9,
    )


def local_path(
    scenario: FigureScenario,
    interface_resistance_m2K_W: float,
    *,
    name: str,
) -> LocalThermalPath:
    return LocalThermalPath(
        name=name,
        silicon_residue_resistance_m2K_W=interface_resistance_m2K_W,
        residue_water_resistance_m2K_W=scenario.residue_water_resistance_m2K_W,
        water_path_resistance_m2K_W=(
            scenario.water_path_length_nm * 1.0e-9
            / WATER_THERMAL_CONDUCTIVITY_W_MK
        ),
        residue_thickness_m=scenario.residue_thickness_nm * 1.0e-9,
        interpretation=(
            "local bottom-of-trench screening path; prescribed spatial "
            "Si/residue thermal resistance"
        ),
    )


def interface_resistance_profile(
    scenario: FigureScenario, x_nm: np.ndarray
) -> np.ndarray:
    half_width = 0.5 * scenario.residue_width_nm
    distance_to_nearest_edge = np.maximum(0.0, half_width - np.abs(x_nm))
    edge_weight = np.exp(
        -(distance_to_nearest_edge / scenario.edge_decay_length_nm) ** 2
    )
    return scenario.centre_interface_resistance_m2K_W + edge_weight * (
        scenario.edge_interface_resistance_m2K_W
        - scenario.centre_interface_resistance_m2K_W
    )


def calculate_detachment_fields(
    scenario: FigureScenario,
) -> DetachmentFields:
    residue = residue_properties(scenario)
    edge_path = local_path(
        scenario,
        scenario.edge_interface_resistance_m2K_W,
        name="edge_near_debond",
    )
    threshold = inverse_delamination_temperature(
        scenario.fracture_energy_J_m2,
        edge_path,
        residue,
    )
    if not threshold.reached or threshold.required_substrate_temperature_K is None:
        raise RuntimeError("fracture-energy threshold was not reached")
    substrate_temperature = threshold.required_substrate_temperature_K
    if not threshold.water_1atm_valid:
        raise RuntimeError("selected threshold leaves the 1-atm liquid-water range")

    incident_irradiance = required_incident_irradiance_W_m2(
        substrate_temperature,
        scenario.illumination_duration_s,
        scenario.wafer_thickness_um * 1.0e-6,
        band_averaged_absorptance(scenario.oxide_thickness_nm),
        scenario.total_heat_transfer_W_m2K,
    )
    x_nm = np.linspace(
        -0.5 * scenario.residue_width_nm,
        0.5 * scenario.residue_width_nm,
        scenario.interface_points,
    )
    resistance = interface_resistance_profile(scenario, x_nm)

    residue_temperature = np.empty_like(x_nm)
    delta = np.empty_like(x_nm)
    mismatch = np.empty_like(x_nm)
    stress = np.empty_like(x_nm)
    energy_per_area = np.empty_like(x_nm)
    residue_free_strain = np.empty_like(x_nm)
    for index, value in enumerate(resistance):
        path = local_path(scenario, float(value), name=f"profile_{index}")
        state = thermomechanical_state(
            substrate_temperature,
            path,
            residue,
        )
        residue_temperature[index] = state.residue_temperature_K
        delta[index] = state.substrate_residue_delta_K
        mismatch[index] = state.mismatch_strain
        stress[index] = state.biaxial_stress_Pa
        energy_per_area[index] = state.stored_energy_upper_bound_J_m2
        residue_free_strain[index] = state.residue_free_strain

    silicon_strain = silicon_free_thermal_strain(substrate_temperature)
    energy_density = energy_per_area / residue.thickness_m
    normal_total_strain = residue_free_strain - (
        2.0 * residue.poisson_ratio / (1.0 - residue.poisson_ratio)
    ) * mismatch
    return DetachmentFields(
        substrate_temperature_K=substrate_temperature,
        incident_irradiance_W_cm2=incident_irradiance / 1.0e4,
        silicon_free_strain=silicon_strain,
        x_nm=x_nm,
        interface_resistance_m2K_W=resistance,
        residue_temperature_K=residue_temperature,
        substrate_residue_delta_K=delta,
        mismatch_strain=mismatch,
        biaxial_stress_Pa=stress,
        elastic_energy_density_J_m3=energy_density,
        elastic_energy_per_area_J_m2=energy_per_area,
        energy_to_fracture_ratio=energy_per_area
        / scenario.fracture_energy_J_m2,
        normal_total_strain=normal_total_strain,
    )


def _cell_average(values: np.ndarray) -> np.ndarray:
    return 0.25 * (
        values[:-1, :-1]
        + values[1:, :-1]
        + values[:-1, 1:]
        + values[1:, 1:]
    )


def _uniform_deformed_mesh(
    x_bounds_nm: tuple[float, float],
    y_bounds_nm: tuple[float, float],
    strain: float,
    magnification: float,
    *,
    nx: int = 41,
    ny: int = 31,
) -> tuple[np.ndarray, np.ndarray]:
    x = np.linspace(*x_bounds_nm, nx)
    y = np.linspace(*y_bounds_nm, ny)
    x_grid, y_grid = np.meshgrid(x, y)
    scale = 1.0 + magnification * strain
    return x_grid * scale, y_grid * scale


def _residue_deformed_mesh(
    scenario: FigureScenario,
    fields: DetachmentFields,
    *,
    ny: int = 25,
) -> tuple[np.ndarray, np.ndarray]:
    y = np.linspace(0.0, scenario.residue_thickness_nm, ny)
    x_grid, y_grid = np.meshgrid(fields.x_nm, y)
    x_deformed = x_grid * (
        1.0 + scenario.deformation_magnification * fields.silicon_free_strain
    )
    y_deformed = y_grid * (
        1.0
        + scenario.deformation_magnification
        * fields.normal_total_strain[np.newaxis, :]
    )
    return x_deformed, y_deformed


def _add_water_background(
    ax: plt.Axes,
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> None:
    scale = 1.0 + scenario.deformation_magnification * fields.silicon_free_strain
    half_trench = 0.5 * scenario.trench_width_nm * scale
    height = scenario.local_window_water_height_nm * scale
    polygon = Polygon(
        [(-half_trench, 0.0), (half_trench, 0.0), (half_trench, height), (-half_trench, height)],
        closed=True,
        facecolor="#E8F3F5",
        edgecolor="none",
        zorder=0,
    )
    ax.add_patch(polygon)


def _draw_undeformed_outlines(
    ax: plt.Axes,
    scenario: FigureScenario,
) -> None:
    neutral = "#767676"
    dash = (0, (3, 2))
    lw = 0.7
    half_window = scenario.local_window_half_width_nm
    half_trench = 0.5 * scenario.trench_width_nm
    depth = scenario.local_window_substrate_depth_nm
    water_height = scenario.local_window_water_height_nm
    half_residue = 0.5 * scenario.residue_width_nm
    h = scenario.residue_thickness_nm
    lines = (
        ([-half_window, half_window, half_window, -half_window, -half_window], [-depth, -depth, 0, 0, -depth]),
        ([-half_window, -half_trench, -half_trench, -half_window, -half_window], [0, 0, water_height, water_height, 0]),
        ([half_trench, half_window, half_window, half_trench, half_trench], [0, 0, water_height, water_height, 0]),
        ([-half_residue, half_residue, half_residue, -half_residue, -half_residue], [0, 0, h, h, 0]),
    )
    for x, y in lines:
        ax.plot(x, y, color=neutral, lw=lw, ls=dash, zorder=12)


def _draw_si_temperature(
    ax: plt.Axes,
    scenario: FigureScenario,
    fields: DetachmentFields,
    *,
    cmap: mpl.colors.Colormap,
    norm: mpl.colors.Normalize,
) -> mpl.collections.QuadMesh:
    pieces = (
        (
            (-scenario.local_window_half_width_nm, scenario.local_window_half_width_nm),
            (-scenario.local_window_substrate_depth_nm, 0.0),
        ),
        (
            (-scenario.local_window_half_width_nm, -0.5 * scenario.trench_width_nm),
            (0.0, scenario.local_window_water_height_nm),
        ),
        (
            (0.5 * scenario.trench_width_nm, scenario.local_window_half_width_nm),
            (0.0, scenario.local_window_water_height_nm),
        ),
    )
    mesh = None
    for x_bounds, y_bounds in pieces:
        x_grid, y_grid = _uniform_deformed_mesh(
            x_bounds,
            y_bounds,
            fields.silicon_free_strain,
            scenario.deformation_magnification,
        )
        values = np.full((y_grid.shape[0] - 1, x_grid.shape[1] - 1), fields.substrate_temperature_K)
        mesh = ax.pcolormesh(
            x_grid,
            y_grid,
            values,
            cmap=cmap,
            norm=norm,
            shading="flat",
            rasterized=True,
            zorder=2,
        )
    assert mesh is not None
    return mesh


def _draw_si_neutral(
    ax: plt.Axes,
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> None:
    scale = 1.0 + scenario.deformation_magnification * fields.silicon_free_strain
    half_window = scenario.local_window_half_width_nm * scale
    half_trench = 0.5 * scenario.trench_width_nm * scale
    depth = scenario.local_window_substrate_depth_nm * scale
    height = scenario.local_window_water_height_nm * scale
    polygons = (
        [(-half_window, -depth), (half_window, -depth), (half_window, 0), (-half_window, 0)],
        [(-half_window, 0), (-half_trench, 0), (-half_trench, height), (-half_window, height)],
        [(half_trench, 0), (half_window, 0), (half_window, height), (half_trench, height)],
    )
    for vertices in polygons:
        ax.add_patch(
            Polygon(
                vertices,
                closed=True,
                facecolor="#D9D9D9",
                edgecolor="#272727",
                linewidth=0.8,
                zorder=2,
            )
        )


def _style_geometry_axis(
    ax: plt.Axes,
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> None:
    scale = 1.0 + scenario.deformation_magnification * fields.silicon_free_strain
    x_limit = 1.06 * scenario.local_window_half_width_nm * scale
    y_limit = 1.06 * max(
        scenario.local_window_substrate_depth_nm,
        scenario.local_window_water_height_nm,
    ) * scale
    ax.set_xlim(-x_limit, x_limit)
    ax.set_ylim(-y_limit, y_limit)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("Displayed lateral coordinate (nm)")
    ax.set_ylabel("Displayed normal coordinate (nm)")
    ax.tick_params(direction="out", length=2.5, width=0.6)
    ax.spines["right"].set_visible(False)
    ax.spines["top"].set_visible(False)


def make_figure(
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> plt.Figure:
    figure = plt.figure(figsize=(183.0 / 25.4, 105.0 / 25.4))
    grid = figure.add_gridspec(
        1,
        2,
        left=0.07,
        right=0.94,
        bottom=0.17,
        top=0.88,
        wspace=0.36,
    )
    ax_temperature = figure.add_subplot(grid[0, 0])
    ax_energy = figure.add_subplot(grid[0, 1])
    temperature_cmap = mpl.colormaps["cividis"]
    energy_cmap = mpl.colormaps["magma"]
    interface_cmap = mpl.colormaps["inferno"]

    _add_water_background(ax_temperature, scenario, fields)
    temperature_norm = Normalize(
        vmin=WATER_BULK_TEMPERATURE_K,
        vmax=fields.substrate_temperature_K,
    )
    temperature_mesh = _draw_si_temperature(
        ax_temperature,
        scenario,
        fields,
        cmap=temperature_cmap,
        norm=temperature_norm,
    )
    x_residue, y_residue = _residue_deformed_mesh(scenario, fields)
    temperature_nodes = np.tile(
        fields.residue_temperature_K,
        (y_residue.shape[0], 1),
    )
    ax_temperature.pcolormesh(
        x_residue,
        y_residue,
        _cell_average(temperature_nodes),
        cmap=temperature_cmap,
        norm=temperature_norm,
        shading="flat",
        rasterized=True,
        zorder=5,
    )
    contour_levels = [
        value
        for value in (320.0, 340.0, 355.0)
        if fields.residue_temperature_K.min() < value < fields.residue_temperature_K.max()
    ]
    if contour_levels:
        ax_temperature.contour(
            x_residue,
            y_residue,
            temperature_nodes,
            levels=contour_levels,
            colors="white",
            linewidths=0.45,
            zorder=7,
        )
    ax_temperature.plot(
        x_residue[0],
        y_residue[0],
        color="#272727",
        lw=0.8,
        zorder=9,
    )
    ax_temperature.plot(
        x_residue[-1],
        y_residue[-1],
        color="#272727",
        lw=0.8,
        zorder=9,
    )
    _draw_undeformed_outlines(ax_temperature, scenario)
    _style_geometry_axis(ax_temperature, scenario, fields)
    ax_temperature.set_title(
        r"Temperature $T(x,t^*)$ and magnified deformation",
        loc="left",
        pad=5,
        fontweight="bold",
    )
    ax_temperature.text(
        -0.13,
        1.05,
        "a",
        transform=ax_temperature.transAxes,
        fontsize=8,
        fontweight="bold",
        va="bottom",
    )
    ax_temperature.text(
        0.02,
        0.04,
        "Si substrate",
        transform=ax_temperature.transAxes,
        color="white",
        fontsize=6.0,
        fontweight="bold",
        zorder=20,
    )
    ax_temperature.text(
        0.49,
        0.82,
        "water",
        transform=ax_temperature.transAxes,
        ha="center",
        color="#4D4D4D",
        fontsize=5.8,
    )
    edge_index = fields.edge_index()
    edge_x = x_residue[-1, edge_index]
    edge_y = y_residue[-1, edge_index]
    ax_temperature.annotate(
        (
            f"cold edge\n$T_r$={fields.residue_temperature_K[edge_index]:.1f} K\n"
            f"$\\Delta T$={fields.substrate_residue_delta_K[edge_index]:.1f} K"
        ),
        xy=(edge_x, edge_y),
        xytext=(0.60, 0.70),
        textcoords="axes fraction",
        arrowprops={"arrowstyle": "-", "color": "#272727", "lw": 0.7},
        fontsize=5.8,
        ha="left",
        va="bottom",
    )
    cax_temperature = ax_temperature.inset_axes([1.03, 0.12, 0.035, 0.76])
    colorbar_temperature = figure.colorbar(
        temperature_mesh,
        cax=cax_temperature,
    )
    colorbar_temperature.set_label("Temperature (K)", labelpad=2)
    colorbar_temperature.ax.tick_params(length=2, width=0.5, pad=1)

    _add_water_background(ax_energy, scenario, fields)
    _draw_si_neutral(ax_energy, scenario, fields)
    energy_kJ_m3 = fields.elastic_energy_density_J_m3 / 1.0e3
    positive_floor = max(1.0e-4, float(np.max(energy_kJ_m3)) * 1.0e-4)
    energy_norm = LogNorm(
        vmin=positive_floor,
        vmax=float(np.max(energy_kJ_m3)) * 1.02,
    )
    energy_nodes = np.tile(
        np.maximum(energy_kJ_m3, positive_floor),
        (y_residue.shape[0], 1),
    )
    energy_mesh = ax_energy.pcolormesh(
        x_residue,
        y_residue,
        _cell_average(energy_nodes),
        cmap=energy_cmap,
        norm=energy_norm,
        shading="flat",
        rasterized=True,
        zorder=5,
    )
    ax_energy.plot(
        x_residue[-1],
        y_residue[-1],
        color="#272727",
        lw=0.8,
        zorder=9,
    )
    interface_points = np.column_stack(
        (x_residue[0], y_residue[0])
    ).reshape(-1, 1, 2)
    segments = np.concatenate(
        (interface_points[:-1], interface_points[1:]),
        axis=1,
    )
    segment_ratio = 0.5 * (
        fields.energy_to_fracture_ratio[:-1]
        + fields.energy_to_fracture_ratio[1:]
    )
    interface_line = LineCollection(
        segments,
        cmap=interface_cmap,
        norm=Normalize(0.0, 1.0),
        linewidths=5.0,
        zorder=12,
    )
    interface_line.set_array(segment_ratio)
    ax_energy.add_collection(interface_line)
    _draw_undeformed_outlines(ax_energy, scenario)
    _style_geometry_axis(ax_energy, scenario, fields)
    ax_energy.set_title(
        r"Residue $u_{el}$ and interfacial $U_A/\Gamma$ proxy",
        loc="left",
        pad=5,
        fontweight="bold",
    )
    ax_energy.text(
        -0.13,
        1.05,
        "b",
        transform=ax_energy.transAxes,
        fontsize=8,
        fontweight="bold",
        va="bottom",
    )
    ax_energy.text(
        0.02,
        0.04,
        "Si substrate",
        transform=ax_energy.transAxes,
        color="#4D4D4D",
        fontsize=6.0,
        fontweight="bold",
        zorder=20,
    )
    ax_energy.annotate(
        (
            f"edge maximum\n$U_A/\\Gamma$={fields.energy_to_fracture_ratio[edge_index]:.2f}\n"
            f"$\\sigma$={fields.biaxial_stress_Pa[edge_index] / 1.0e6:.1f} MPa"
        ),
        xy=(x_residue[0, edge_index], y_residue[0, edge_index]),
        xytext=(0.57, 0.72),
        textcoords="axes fraction",
        arrowprops={"arrowstyle": "-", "color": "#272727", "lw": 0.7},
        fontsize=5.8,
        ha="left",
        va="bottom",
    )
    cax_energy = ax_energy.inset_axes([1.03, 0.54, 0.035, 0.34])
    colorbar_energy = figure.colorbar(energy_mesh, cax=cax_energy)
    colorbar_energy.set_label(r"$u_{el}$ (kJ m$^{-3}$)", labelpad=2)
    colorbar_energy.ax.tick_params(length=2, width=0.5, pad=1)
    cax_interface = ax_energy.inset_axes([1.03, 0.12, 0.035, 0.28])
    colorbar_interface = figure.colorbar(interface_line, cax=cax_interface)
    colorbar_interface.set_ticks([0.0, 0.5, 1.0])
    colorbar_interface.set_label(r"$U_A/\Gamma$", labelpad=2)
    colorbar_interface.ax.tick_params(length=2, width=0.5, pad=1)

    figure.text(
        0.5,
        0.055,
        (
            f"10 × 180 nm trench bottom; SiN$_x$-like {scenario.residue_thickness_nm:g} nm residue; "
            f"$t^*$={scenario.illumination_duration_s:g} s, $T_s$={fields.substrate_temperature_K:.1f} K, "
            f"incident optical intensity={fields.incident_irradiance_W_cm2:.2f} W cm$^{{-2}}$; "
            f"$\\Gamma$={scenario.fracture_energy_J_m2:.0e} J m$^{{-2}}$"
        ),
        ha="center",
        va="center",
        fontsize=5.8,
    )
    figure.text(
        0.5,
        0.020,
        (
            f"Solid: deformed geometry; dashed: undeformed; displacement ×{scenario.deformation_magnification:g}. "
            "$U_A/\\Gamma$ is a stored-energy screening proxy, not a crack-growth $G/\\Gamma$ solution."
        ),
        ha="center",
        va="center",
        fontsize=5.4,
        color="#4D4D4D",
    )
    return figure


def write_source_csv(
    path: Path,
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = (
        "x_nm",
        "interface_resistance_m2K_W",
        "substrate_temperature_K",
        "residue_temperature_K",
        "substrate_residue_delta_K",
        "mismatch_strain",
        "biaxial_stress_Pa",
        "elastic_energy_density_J_m3",
        "elastic_energy_per_area_J_m2",
        "energy_to_fracture_ratio",
        "normal_total_strain",
    )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for index, x_nm in enumerate(fields.x_nm):
            writer.writerow(
                {
                    "x_nm": float(x_nm),
                    "interface_resistance_m2K_W": float(
                        fields.interface_resistance_m2K_W[index]
                    ),
                    "substrate_temperature_K": fields.substrate_temperature_K,
                    "residue_temperature_K": float(
                        fields.residue_temperature_K[index]
                    ),
                    "substrate_residue_delta_K": float(
                        fields.substrate_residue_delta_K[index]
                    ),
                    "mismatch_strain": float(fields.mismatch_strain[index]),
                    "biaxial_stress_Pa": float(fields.biaxial_stress_Pa[index]),
                    "elastic_energy_density_J_m3": float(
                        fields.elastic_energy_density_J_m3[index]
                    ),
                    "elastic_energy_per_area_J_m2": float(
                        fields.elastic_energy_per_area_J_m2[index]
                    ),
                    "energy_to_fracture_ratio": float(
                        fields.energy_to_fracture_ratio[index]
                    ),
                    "normal_total_strain": float(
                        fields.normal_total_strain[index]
                    ),
                }
            )


def write_metadata(
    path: Path,
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> None:
    edge = fields.edge_index()
    payload: dict[str, Any] = {
        "schema_version": "thermomechanical-geometry-figure/v1",
        "figure_contract": {
            "core_conclusion": (
                "Under a prescribed near-debond edge thermal-resistance profile, "
                "the stored elastic-energy proxy localizes at residue edges."
            ),
            "archetype": "schematic-led composite",
            "backend": "Python/matplotlib only",
            "final_size_mm": [183.0, 105.0],
            "panel_a": "temperature and magnified geometry",
            "panel_b": "elastic-energy density and interfacial U_A/Gamma proxy",
        },
        "scenario": asdict(scenario),
        "derived": {
            "substrate_temperature_K": fields.substrate_temperature_K,
            "incident_irradiance_W_cm2": fields.incident_irradiance_W_cm2,
            "maximum_energy_to_fracture_ratio": float(
                np.max(fields.energy_to_fracture_ratio)
            ),
            "maximum_location_x_nm": float(fields.x_nm[edge]),
            "edge_residue_temperature_K": float(
                fields.residue_temperature_K[edge]
            ),
            "edge_delta_temperature_K": float(
                fields.substrate_residue_delta_K[edge]
            ),
            "edge_biaxial_stress_MPa": float(
                fields.biaxial_stress_Pa[edge] / 1.0e6
            ),
        },
        "claim_boundaries": {
            "interface_metric": (
                "U_A/Gamma is the phi=1 stored-film-energy ceiling divided by an "
                "assumed fracture energy; it is not a computed crack-tip G/Gamma."
            ),
            "spatial_profile": (
                "The Si/residue thermal resistance is prescribed from 1e-8 m2K/W "
                "at the centre to 1e-6 m2K/W at the edges."
            ),
            "deformation": (
                "The substrate uses free Si thermal strain and the residue uses "
                "equibiaxial plane-stress thickness strain; displacements are magnified."
            ),
            "not_modelled": [
                "crack growth",
                "cohesive damage",
                "fluid traction",
                "boiling or bubbles",
                "self-consistent 2D conjugate heat transfer",
            ],
        },
        "source_data": "source_data.csv",
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def write_readme(
    path: Path,
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> None:
    edge = fields.edge_index()
    text = f"""# Geometry-resolved thermomechanical detachment figure

## Figure contract

- Core conclusion: prescribed near-debond thermal resistance localizes the stored-energy proxy at residue edges.
- Panel a: substrate/residue temperature and magnified thermally deformed geometry.
- Panel b: residue elastic-energy density and interfacial `U_A/Gamma` band.
- Backend: Python/matplotlib only.
- Final size: 183 x 105 mm.

## Selected screening state

- `t* = {scenario.illumination_duration_s:g} s`
- `Ts = {fields.substrate_temperature_K:.3f} K`
- optical irradiance on wafer = `{fields.incident_irradiance_W_cm2:.3f} W/cm2`
- assumed `Gamma = {scenario.fracture_energy_J_m2:.3e} J/m2`
- edge `Tr = {fields.residue_temperature_K[edge]:.3f} K`
- edge `Ts-Tr = {fields.substrate_residue_delta_K[edge]:.3f} K`
- edge stress = `{fields.biaxial_stress_Pa[edge] / 1e6:.3f} MPa`
- maximum `U_A/Gamma = {np.max(fields.energy_to_fracture_ratio):.6f}`

`U_A/Gamma` is a phi=1 stored-energy screening proxy, not a computed crack-tip `G/Gamma`.
The thermal-resistance edge profile and deformation magnification are explicit sensitivity assumptions.
"""
    path.write_text(text, encoding="utf-8")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_manifest(output_dir: Path) -> None:
    manifest_path = output_dir / "SHA256SUMS.json"
    artifact_paths = sorted(
        path
        for path in output_dir.iterdir()
        if path.is_file() and path != manifest_path
    )
    source_paths = (
        Path(__file__).resolve(),
        Path(__file__).resolve().with_name("led_backside_thermomechanical.py"),
        Path(__file__).resolve().with_name(
            "test_plot_thermomechanical_detachment_geometry.py"
        ),
    )
    payload = {
        "schema_version": "sha256-manifest/v1",
        "artifacts": {
            path.name: _sha256(path)
            for path in artifact_paths
        },
        "sources": {
            path.name: _sha256(path)
            for path in source_paths
        },
    }
    manifest_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def save_outputs(
    output_dir: Path,
    scenario: FigureScenario,
    fields: DetachmentFields,
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    base = output_dir / "thermomechanical_detachment_geometry"
    figure = make_figure(scenario, fields)
    outputs = [
        base.with_suffix(".svg"),
        base.with_suffix(".pdf"),
        base.with_suffix(".png"),
        base.with_suffix(".tiff"),
    ]
    figure.savefig(outputs[0])
    figure.savefig(outputs[1])
    figure.savefig(outputs[2], dpi=300)
    figure.savefig(
        outputs[3],
        dpi=600,
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(figure)
    write_source_csv(output_dir / "source_data.csv", scenario, fields)
    write_metadata(output_dir / "metadata.json", scenario, fields)
    write_readme(output_dir / "README_JA.md", scenario, fields)
    write_manifest(output_dir)
    return outputs


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--gamma-j-m2", type=float, default=1.0e-5)
    parser.add_argument("--duration-s", type=float, default=30.0)
    parser.add_argument("--deformation-magnification", type=float, default=1500.0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scenario = FigureScenario(
        fracture_energy_J_m2=args.gamma_j_m2,
        illumination_duration_s=args.duration_s,
        deformation_magnification=args.deformation_magnification,
    )
    fields = calculate_detachment_fields(scenario)
    outputs = save_outputs(args.output_dir, scenario, fields)
    summary = {
        "output_dir": str(args.output_dir),
        "outputs": [str(path) for path in outputs],
        "substrate_temperature_K": fields.substrate_temperature_K,
        "incident_irradiance_W_cm2": fields.incident_irradiance_W_cm2,
        "maximum_energy_to_fracture_ratio": float(
            np.max(fields.energy_to_fracture_ratio)
        ),
    }
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

"""Which pulsed recipe removes the most, no matter why the etch slows down?

The measured blanket series decelerates and the cause is not identified: the
slowdown can live in the liquid (accumulating products, local depletion) or on
the surface (a converted, less reactive layer).  Those two families respond
oppositely to the two available reset operations -- a liquid exchange resets a
liquid-side cause and does nothing to a surface-side one; a chemical reset
step (oxidising strip such as O3 or SC1) resets both, at the cost of extra
recipe time and unknown extra removal, which is conservatively taken as zero.

Rather than guess the mechanism, this screen simulates candidate recipes under
**every combination** of decay law (saturating and logarithmic, the two that
fit the measured points equally well) and cause family (liquid side, surface
side), and ranks recipes by their **worst case** across those four scenarios.
A recipe that wins in the worst case is one that can be recommended before the
mechanism is known; the size of its spread across scenarios is exactly what
the split-etch experiment would measure.

Decay state semantics:

* saturating law -- rate ``r = r0 (1 - x)``; a segment of duration ``t``
  starting at state ``x0`` removes ``D (1 - x0)(1 - e^(-t/T))``;
* logarithmic law -- rate ages as ``A / (tau + a)``; a segment removes
  ``A ln((tau + a + t) / (tau + a))``.

An exchange resets the state only under the liquid-side hypothesis; a chemical
reset step resets it under both (its liquid is fresh too).

**Boundaries.**  The laws are four-point fits carried outside their measured
window; the chemical reset is credited with zero intrinsic removal and full
state reset -- the first is conservative, the second optimistic, and both are
declared.  Recipe overhead (exchange and reset durations) is tracked as wall
time but no chemistry runs during it.  Nothing here is a process recipe until
the split-etch comparison confirms which scenario column is real.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping, Sequence

from measured_decay_fit import RemovalLaw, fit_laws, load_series


SCHEMA_VERSION = "decay-robust-pulsed-recipe-screen/v1"
MODEL_NOTICE = (
    "Recipe comparison under every combination of fitted decay law "
    "(saturating, logarithmic) and cause family (liquid side, surface side), "
    "ranked by worst case. The chemical reset step is credited with zero "
    "intrinsic removal (conservative) and full state reset (optimistic). "
    "The laws are four-point fits extrapolated outside the 180 s window. "
    "Not a process recipe until the split-etch experiment picks the real "
    "scenario column."
)

HYPOTHESIS_LIQUID = "liquid_side"
HYPOTHESIS_SURFACE = "surface_side"
HYPOTHESES = (HYPOTHESIS_LIQUID, HYPOTHESIS_SURFACE)

LAW_NAMES = ("saturating", "logarithmic")

ETCH = "etch"
EXCHANGE = "exchange"
RESET = "reset"

DEFAULT_EXCHANGE_OVERHEAD_S = 10.0
DEFAULT_RESET_OVERHEAD_S = 60.0


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


@dataclass(frozen=True)
class Recipe:
    """A sequence of etch / exchange / reset steps."""

    name: str
    description: str
    steps: tuple[tuple[str, float], ...]

    def active_etch_time_s(self) -> float:
        return sum(dur for kind, dur in self.steps if kind == ETCH)

    def wall_time_s(
        self,
        *,
        exchange_overhead_s: float = DEFAULT_EXCHANGE_OVERHEAD_S,
        reset_overhead_s: float = DEFAULT_RESET_OVERHEAD_S,
    ) -> float:
        total = 0.0
        for kind, dur in self.steps:
            if kind == ETCH:
                total += dur
            elif kind == EXCHANGE:
                total += exchange_overhead_s
            elif kind == RESET:
                total += reset_overhead_s
            else:
                raise ValueError(f"unknown step kind: {kind}")
        return total

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "steps": [list(step) for step in self.steps],
            "active_etch_time_s": self.active_etch_time_s(),
            "wall_time_s": self.wall_time_s(),
        }


def _etch_pulses(count: int, duration_s: float) -> tuple[tuple[str, float], ...]:
    return tuple((ETCH, float(duration_s)) for _ in range(count))


def _interleave(
    pulses: Sequence[tuple[str, float]], separator: str
) -> tuple[tuple[str, float], ...]:
    steps: list[tuple[str, float]] = []
    for index, pulse in enumerate(pulses):
        if index:
            steps.append((separator, 0.0))
        steps.append(pulse)
    return tuple(steps)


def default_recipes() -> tuple[Recipe, ...]:
    """Candidates at matched 180 s active etch time, plus a futility control."""

    return (
        Recipe(
            name="continuous_180s",
            description="one continuous 180 s etch; the measured baseline",
            steps=((ETCH, 180.0),),
        ),
        Recipe(
            name="continuous_600s",
            description=(
                "one continuous 600 s etch; the 'just etch longer' control"
            ),
            steps=((ETCH, 600.0),),
        ),
        Recipe(
            name="split_3x60s_exchange",
            description="three 60 s pulses with a liquid exchange between",
            steps=_interleave(_etch_pulses(3, 60.0), EXCHANGE),
        ),
        Recipe(
            name="split_6x30s_exchange",
            description="six 30 s pulses with a liquid exchange between",
            steps=_interleave(_etch_pulses(6, 30.0), EXCHANGE),
        ),
        Recipe(
            name="cycle_3x60s_reset",
            description=(
                "three 60 s pulses with a chemical reset step between"
            ),
            steps=_interleave(_etch_pulses(3, 60.0), RESET),
        ),
        Recipe(
            name="cycle_6x30s_reset",
            description="six 30 s pulses with a chemical reset step between",
            steps=_interleave(_etch_pulses(6, 30.0), RESET),
        ),
    )


class _DecayState:
    """Per-law decay state with the two reset semantics."""

    def __init__(self, law: RemovalLaw):
        self.law = law
        if law.name == "saturating":
            self._x = 0.0
        elif law.name == "logarithmic":
            self._age_s = 0.0
        else:
            raise ValueError(
                f"unsupported decay law for the recipe screen: {law.name}"
            )

    def etch(self, duration_s: float) -> float:
        duration = _finite_positive("duration_s", duration_s)
        parameters = self.law.parameters
        if self.law.name == "saturating":
            ceiling = parameters["ceiling_nm"]
            tau = parameters["tau_s"]
            removed = (
                ceiling * (1.0 - self._x) * (1.0 - math.exp(-duration / tau))
            )
            self._x = 1.0 - (1.0 - self._x) * math.exp(-duration / tau)
            return removed
        amplitude = parameters["amplitude_nm"]
        tau = parameters["tau_s"]
        removed = amplitude * math.log(
            (tau + self._age_s + duration) / (tau + self._age_s)
        )
        self._age_s += duration
        return removed

    def reset(self) -> None:
        if self.law.name == "saturating":
            self._x = 0.0
        else:
            self._age_s = 0.0


def simulate_recipe(
    recipe: Recipe, law: RemovalLaw, hypothesis: str
) -> float:
    """Total removal of one recipe under one (law, cause-family) scenario."""

    if hypothesis not in HYPOTHESES:
        raise ValueError(f"unknown hypothesis: {hypothesis}")
    state = _DecayState(law)
    removed = 0.0
    for kind, duration in recipe.steps:
        if kind == ETCH:
            removed += state.etch(duration)
        elif kind == EXCHANGE:
            if hypothesis == HYPOTHESIS_LIQUID:
                state.reset()
        elif kind == RESET:
            state.reset()
        else:
            raise ValueError(f"unknown step kind: {kind}")
    return removed


@dataclass(frozen=True)
class RecipeOutcome:
    """One recipe across all four scenarios."""

    recipe: Recipe
    removal_nm: dict[str, float] = field(default_factory=dict)

    def worst_case_nm(self) -> float:
        return min(self.removal_nm.values())

    def best_case_nm(self) -> float:
        return max(self.removal_nm.values())

    def spread(self) -> float:
        worst = self.worst_case_nm()
        return self.best_case_nm() / worst if worst > 0 else math.inf

    def to_dict(self) -> dict[str, Any]:
        return {
            **self.recipe.to_dict(),
            "removal_nm": dict(self.removal_nm),
            "worst_case_nm": self.worst_case_nm(),
            "best_case_nm": self.best_case_nm(),
            "best_over_worst": self.spread(),
        }


def evaluate_recipes(
    recipes: Sequence[Recipe] | None = None,
) -> list[RecipeOutcome]:
    """Every recipe under every (law, hypothesis) scenario."""

    laws = {
        law.name: law
        for law in fit_laws(*load_series())
        if law.name in LAW_NAMES
    }
    outcomes: list[RecipeOutcome] = []
    for recipe in recipes or default_recipes():
        removal: dict[str, float] = {}
        for law_name in LAW_NAMES:
            for hypothesis in HYPOTHESES:
                key = f"{law_name}+{hypothesis}"
                removal[key] = simulate_recipe(
                    recipe, laws[law_name], hypothesis
                )
        outcomes.append(RecipeOutcome(recipe=recipe, removal_nm=removal))
    return outcomes


def dominance(outcomes: Sequence[RecipeOutcome]) -> list[dict[str, Any]]:
    """Scenario-wise dominance among recipes of equal active etch time.

    Recipe A dominates B when it removes at least as much in every scenario
    and strictly more in at least one.  Only recipes with the same active etch
    time are compared, so the statement is about *structure*, not about
    spending more HF time.
    """

    results: list[dict[str, Any]] = []
    for one in outcomes:
        dominated_by: list[str] = []
        for other in outcomes:
            if other.recipe.name == one.recipe.name:
                continue
            if not math.isclose(
                other.recipe.active_etch_time_s(),
                one.recipe.active_etch_time_s(),
            ):
                continue
            keys = one.removal_nm.keys()
            at_least = all(
                other.removal_nm[key] >= one.removal_nm[key] - 1e-12
                for key in keys
            )
            strictly = any(
                other.removal_nm[key] > one.removal_nm[key] + 1e-9
                for key in keys
            )
            if at_least and strictly:
                dominated_by.append(other.recipe.name)
        results.append(
            {
                "recipe": one.recipe.name,
                "dominated_by": dominated_by,
                "undominated": not dominated_by,
            }
        )
    return results


def cycles_to_clear(
    *,
    pad_thickness_nm: float,
    pulse_duration_s: float = 60.0,
    maximum_cycles: int = 200,
) -> dict[str, Any]:
    """Reset-cycles needed to clear a pad, worst case across both laws.

    With a chemical reset between pulses every pulse starts on the fresh
    curve, so the per-cycle removal is the fresh-curve value and the cycle
    count follows directly.  This is the number that turns the screen into a
    recipe proposal once the reset chemistry is chosen.
    """

    thickness = _finite_positive("pad_thickness_nm", pad_thickness_nm)
    duration = _finite_positive("pulse_duration_s", pulse_duration_s)
    laws = {
        law.name: law
        for law in fit_laws(*load_series())
        if law.name in LAW_NAMES
    }
    per_cycle = {
        name: _DecayState(law).etch(duration) for name, law in laws.items()
    }
    worst_per_cycle = min(per_cycle.values())
    cycles = math.ceil(thickness / worst_per_cycle)
    return {
        "pad_thickness_nm": thickness,
        "pulse_duration_s": duration,
        "per_cycle_removal_nm": per_cycle,
        "worst_case_per_cycle_nm": worst_per_cycle,
        "cycles_needed_worst_case": cycles,
        "active_etch_time_s": cycles * duration,
        "feasible_within_maximum": cycles <= int(maximum_cycles),
        "continuous_equivalent_reachable": {
            name: (
                law.ceiling_nm is None or thickness < law.ceiling_nm
            )
            for name, law in laws.items()
        },
    }


def build_report() -> dict[str, Any]:
    """Ranking, dominance, and clear-cycle tables for the default recipes."""

    outcomes = evaluate_recipes()
    ranked = sorted(
        outcomes, key=lambda outcome: outcome.worst_case_nm(), reverse=True
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "scenarios": [
            f"{law}+{hypothesis}"
            for law in LAW_NAMES
            for hypothesis in HYPOTHESES
        ],
        "reset_step_assumptions": {
            "intrinsic_removal_nm": 0.0,
            "state_reset_efficiency": 1.0,
            "note": (
                "zero intrinsic removal is conservative, full reset is "
                "optimistic; both declared, neither measured"
            ),
        },
        "recipes_ranked_by_worst_case": [
            outcome.to_dict() for outcome in ranked
        ],
        "dominance": dominance(outcomes),
        "clear_cycles": [
            cycles_to_clear(pad_thickness_nm=thickness)
            for thickness in (1.0, 2.0, 3.0, 5.0)
        ],
        "discriminating_experiment": {
            "name": "split etch versus continuous etch",
            "prediction": (
                "under a liquid-side cause split_3x60s_exchange beats "
                "continuous_180s by the full fresh-curve margin; under a "
                "surface-side cause they tie. The measured gap selects the "
                "scenario column"
            ),
        },
    }


__all__ = [
    "DEFAULT_EXCHANGE_OVERHEAD_S",
    "DEFAULT_RESET_OVERHEAD_S",
    "ETCH",
    "EXCHANGE",
    "HYPOTHESES",
    "HYPOTHESIS_LIQUID",
    "HYPOTHESIS_SURFACE",
    "LAW_NAMES",
    "MODEL_NOTICE",
    "RESET",
    "SCHEMA_VERSION",
    "Recipe",
    "RecipeOutcome",
    "build_report",
    "cycles_to_clear",
    "default_recipes",
    "dominance",
    "evaluate_recipes",
    "simulate_recipe",
]

from __future__ import annotations

import math
import unittest

from pulsed_recipe_screen import Recipe, default_recipes, evaluate_recipes
from reset_silicon_cost_screen import (
    ResetOxidationAssumptions,
    budget_ranking,
    build_report,
    clear_cycles_with_recession,
    count_recipe_events,
    marginal_costs,
    per_reset_recession_nm,
    price_recipes,
    recession_after_resets_nm,
    silicon_per_oxide_thickness_ratio,
)


def _priced():
    return price_recipes(outcomes=evaluate_recipes())


def _row(priced, name: str):
    return next(row for row in priced if row["name"] == name)


class ConsumedSiliconRatioTests(unittest.TestCase):
    def test_ratio_is_the_standard_oxidation_bookkeeping_value(self) -> None:
        """Vm(Si)/Vm(SiO2) must land at the familiar ~0.44."""

        ratio = silicon_per_oxide_thickness_ratio()
        self.assertGreater(ratio, 0.43)
        self.assertLess(ratio, 0.45)

    def test_ratio_matches_the_molar_volume_arithmetic(self) -> None:
        expected = (28.0855 / 2.329) / (60.0843 / 2.196)
        self.assertAlmostEqual(
            silicon_per_oxide_thickness_ratio(), expected, places=12
        )


class PerResetRecessionTests(unittest.TestCase):
    def test_recession_scales_linearly_with_oxide_thickness(self) -> None:
        thin = per_reset_recession_nm(
            ResetOxidationAssumptions(oxide_thickness_nm=0.5)
        )
        thick = per_reset_recession_nm(
            ResetOxidationAssumptions(oxide_thickness_nm=1.5)
        )
        self.assertAlmostEqual(thick, 3.0 * thin, places=12)

    def test_partial_regrowth_scales_the_oxide_term(self) -> None:
        full = per_reset_recession_nm(ResetOxidationAssumptions())
        half = per_reset_recession_nm(
            ResetOxidationAssumptions(regrowth_completeness=0.5)
        )
        self.assertAlmostEqual(half, 0.5 * full, places=12)

    def test_direct_silicon_etch_adds_on_top(self) -> None:
        base = per_reset_recession_nm(ResetOxidationAssumptions())
        with_etch = per_reset_recession_nm(
            ResetOxidationAssumptions(direct_silicon_etch_nm_per_reset=0.1)
        )
        self.assertAlmostEqual(with_etch, base + 0.1, places=12)

    def test_cumulative_recession_is_linear_in_reset_count(self) -> None:
        assumptions = ResetOxidationAssumptions()
        single = per_reset_recession_nm(assumptions)
        self.assertAlmostEqual(
            recession_after_resets_nm(5, assumptions), 5 * single, places=12
        )
        self.assertEqual(recession_after_resets_nm(0, assumptions), 0.0)

    def test_invalid_assumptions_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ResetOxidationAssumptions(oxide_thickness_nm=0.0)
        with self.assertRaises(ValueError):
            ResetOxidationAssumptions(regrowth_completeness=0.0)
        with self.assertRaises(ValueError):
            ResetOxidationAssumptions(regrowth_completeness=1.5)
        with self.assertRaises(ValueError):
            ResetOxidationAssumptions(direct_silicon_etch_nm_per_reset=-0.1)
        with self.assertRaises(ValueError):
            recession_after_resets_nm(-1, ResetOxidationAssumptions())


class RecipeEventTests(unittest.TestCase):
    def test_interleaved_reset_counts(self) -> None:
        """Three pulses carry two resets; six pulses carry five."""

        by_name = {recipe.name: recipe for recipe in default_recipes()}
        self.assertEqual(
            count_recipe_events(by_name["cycle_3x60s_reset"])[
                "n_reset_events"
            ],
            2,
        )
        self.assertEqual(
            count_recipe_events(by_name["cycle_6x30s_reset"])[
                "n_reset_events"
            ],
            5,
        )
        self.assertEqual(
            count_recipe_events(by_name["continuous_180s"])[
                "n_reset_events"
            ],
            0,
        )
        self.assertEqual(
            count_recipe_events(by_name["split_3x60s_exchange"])[
                "n_exchange_events"
            ],
            2,
        )

    def test_every_default_recipe_ends_hf_last(self) -> None:
        """A recipe ending in a reset would hand epitaxy an oxide."""

        for recipe in default_recipes():
            self.assertTrue(
                count_recipe_events(recipe)["ends_hf_last"], recipe.name
            )

    def test_unknown_step_kinds_are_rejected(self) -> None:
        bad = Recipe(name="bad", description="", steps=(("boil", 10.0),))
        with self.assertRaises(ValueError):
            count_recipe_events(bad)


class PricedRecipeTests(unittest.TestCase):
    def test_exchange_recipes_are_recession_free(self) -> None:
        """Liquid exchange spends no silicon; that is its selling point."""

        priced = _priced()
        for name in (
            "continuous_180s",
            "continuous_600s",
            "split_3x60s_exchange",
            "split_6x30s_exchange",
        ):
            row = _row(priced, name)
            self.assertTrue(row["recession_free"], name)
            self.assertEqual(
                row["full_exposure_recession_nm"]["1"], 0.0, name
            )
            self.assertIsNone(
                row["worst_case_removal_per_silicon_nm"]["1"], name
            )

    def test_cycle_recession_at_the_centre_of_the_band(self) -> None:
        """Five resets at t_ox = 1 nm cost ~2.2 nm of silicon."""

        priced = _priced()
        ratio = silicon_per_oxide_thickness_ratio()
        self.assertAlmostEqual(
            _row(priced, "cycle_6x30s_reset")[
                "full_exposure_recession_nm"
            ]["1"],
            5 * ratio,
            places=12,
        )
        self.assertAlmostEqual(
            _row(priced, "cycle_3x60s_reset")[
                "full_exposure_recession_nm"
            ]["1"],
            2 * ratio,
            places=12,
        )

    def test_removal_numbers_are_inherited_unchanged(self) -> None:
        """This screen adds a cost axis; it must not touch the physics."""

        outcomes = {o.recipe.name: o for o in evaluate_recipes()}
        for row in _priced():
            self.assertAlmostEqual(
                row["worst_case_nm"],
                outcomes[row["name"]].worst_case_nm(),
                places=12,
            )


class BudgetRankingTests(unittest.TestCase):
    def test_tight_budget_excludes_every_reset_cycle(self) -> None:
        """At t_ox = 1 nm even two resets overrun a 0.5 nm budget."""

        rows = budget_ranking(_priced(), budgets_nm=(0.5,))
        row = next(
            r
            for r in rows
            if r["oxide_thickness_nm"] == 1.0
            and r["silicon_budget_nm"] == 0.5
        )
        excluded = {entry["recipe"] for entry in row["excluded"]}
        self.assertIn("cycle_3x60s_reset", excluded)
        self.assertIn("cycle_6x30s_reset", excluded)
        self.assertAlmostEqual(
            row["winner_worst_case_removal_nm"], 1.4325, delta=0.01
        )

    def test_middle_budget_flips_the_winner_to_the_coarse_cycle(self) -> None:
        """One nm of silicon buys cycle_3x60s but not cycle_6x30s."""

        rows = budget_ranking(_priced(), budgets_nm=(1.0,))
        row = next(
            r
            for r in rows
            if r["oxide_thickness_nm"] == 1.0
            and r["silicon_budget_nm"] == 1.0
        )
        self.assertEqual(row["winners"], ["cycle_3x60s_reset"])
        excluded = {entry["recipe"] for entry in row["excluded"]}
        self.assertIn("cycle_6x30s_reset", excluded)

    def test_unlimited_budget_reproduces_the_original_ranking(self) -> None:
        """Without the cost axis the fine cycle wins, as in v1."""

        rows = budget_ranking(_priced(), budgets_nm=(None,))
        row = next(
            r
            for r in rows
            if r["oxide_thickness_nm"] == 1.0
            and r["silicon_budget_nm"] is None
        )
        self.assertEqual(row["winners"], ["cycle_6x30s_reset"])
        self.assertEqual(row["excluded"], [])

    def test_thin_oxide_readmits_the_coarse_cycle_at_half_nm(self) -> None:
        rows = budget_ranking(_priced(), budgets_nm=(0.5,))
        row = next(
            r
            for r in rows
            if r["oxide_thickness_nm"] == 0.5
            and r["silicon_budget_nm"] == 0.5
        )
        self.assertEqual(row["winners"], ["cycle_3x60s_reset"])

    def test_matched_active_time_excludes_the_600s_control(self) -> None:
        """continuous_600s spends 3.3x the HF time; it must not compete."""

        for row in budget_ranking(_priced(), budgets_nm=(None,)):
            self.assertNotIn("continuous_600s", row["winners"])
            self.assertNotIn(
                "continuous_600s",
                {entry["recipe"] for entry in row["excluded"]},
            )

    def test_nonpositive_budget_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            budget_ranking(_priced(), budgets_nm=(0.0,))


class MarginalCostTests(unittest.TestCase):
    def test_finer_pulsing_costs_several_nm_silicon_per_nm_residue(
        self,
    ) -> None:
        """The 3x60 -> 6x30 step buys +0.17 nm for three extra resets."""

        rows = marginal_costs(_priced())
        step = next(
            r for r in rows if r["to_recipe"] == "cycle_6x30s_reset"
        )
        self.assertEqual(step["extra_reset_events"], 3)
        self.assertGreater(step["silicon_nm_per_residue_nm"]["1"], 5.0)

    def test_first_cycle_step_is_far_cheaper_than_the_second(self) -> None:
        """Diminishing returns: the first two resets buy most of the gain."""

        rows = marginal_costs(_priced())
        first = next(
            r for r in rows if r["to_recipe"] == "cycle_3x60s_reset"
        )
        second = next(
            r for r in rows if r["to_recipe"] == "cycle_6x30s_reset"
        )
        self.assertLess(
            first["silicon_nm_per_residue_nm"]["1"],
            0.5 * second["silicon_nm_per_residue_nm"]["1"],
        )

    def test_missing_chain_recipe_is_reported(self) -> None:
        with self.assertRaises(ValueError):
            marginal_costs(_priced(), chain=("continuous_180s", "phantom"))


class ClearCycleRecessionTests(unittest.TestCase):
    def test_reset_events_are_cycles_minus_one(self) -> None:
        for row in clear_cycles_with_recession():
            self.assertEqual(
                row["reset_events"], row["cycles_needed_worst_case"] - 1
            )

    def test_wall_recession_prices_the_thick_pad(self) -> None:
        """Clearing 5 nm costs about three nm of wall silicon at t_ox=1."""

        row = next(
            r
            for r in clear_cycles_with_recession()
            if r["pad_thickness_nm"] == 5.0
        )
        ratio = silicon_per_oxide_thickness_ratio()
        self.assertAlmostEqual(
            row["wall_full_exposure_recession_nm"]["1"],
            row["reset_events"] * ratio,
            places=12,
        )
        self.assertGreater(row["wall_full_exposure_recession_nm"]["1"], 3.0)

    def test_margin_cycle_cost_equals_one_reset(self) -> None:
        """Every over-etch cycle hits the freshly cleared bottom once."""

        row = clear_cycles_with_recession()[0]
        self.assertAlmostEqual(
            row["cleared_bottom_recession_per_margin_cycle_nm"]["1"],
            per_reset_recession_nm(ResetOxidationAssumptions()),
            places=12,
        )


class ReportTests(unittest.TestCase):
    def test_report_declares_every_assumption(self) -> None:
        report = build_report()
        assumptions = report["assumptions"]
        self.assertIn("assumed band", assumptions["oxide_thickness_status"])
        self.assertIn("recession-maximising", assumptions["regrowth_note"])
        self.assertIn("optimistic", assumptions["direct_etch_note"])
        self.assertIn(
            "inherited unchanged", assumptions["residue_side_credit"]
        )
        self.assertIn("parallel", assumptions["serial_strip_dead_time"])

    def test_report_covers_the_declared_band_and_budgets(self) -> None:
        report = build_report()
        self.assertEqual(
            report["assumptions"]["oxide_thickness_band_nm"],
            [0.5, 1.0, 1.5],
        )
        budgets = {
            row["silicon_budget_nm"] for row in report["budget_ranking"]
        }
        self.assertEqual(budgets, {0.5, 1.0, 2.0, None})

    def test_report_rejects_a_bad_band(self) -> None:
        with self.assertRaises(ValueError):
            build_report(oxide_thicknesses_nm=(1.0, -0.5))


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import unittest

import numpy as np

from level_set_2d import MonotonicLevelSet2D
from reaction_diffusion_2d import CartesianGrid2D
from spatial_etchability import (
    SpatialEtchabilityField,
    SpatialEtchabilityParameters,
    SpatiallyModifiedRateLaw,
    analyse_residue_topology,
)
from trench_geometry import TaperedTrench2D


def make_grid() -> CartesianGrid2D:
    return CartesianGrid2D.from_geometry(
        TaperedTrench2D("spatial", 20.0, 16.0, 30.0),
        spacing_nm=1.0,
        reservoir_height_nm=3.0,
        lateral_margin_nm=2.0,
    )


class SpatialEtchabilityTests(unittest.TestCase):
    def test_uniform_profile_is_exactly_one(self) -> None:
        grid = make_grid()
        field = SpatialEtchabilityField.build(grid)
        np.testing.assert_allclose(field.combined_factor, 1.0)
        self.assertEqual(field.summary()["minimum"], 1.0)
        self.assertEqual(field.summary()["maximum"], 1.0)

    def test_depth_wall_and_floor_factors_are_spatially_resolved(self) -> None:
        grid = make_grid()
        field = SpatialEtchabilityField.build(
            grid,
            SpatialEtchabilityParameters(
                top_rate_factor=1.0,
                bottom_rate_factor=0.5,
                depth_exponent=1.0,
                sidewall_rate_factor=0.2,
                sidewall_influence_length_nm=1.0,
                floor_rate_factor=0.3,
                floor_influence_length_nm=1.0,
            ),
        )
        cavity_rows = np.flatnonzero(np.any(grid.cavity_mask, axis=1))
        top_row = int(cavity_rows[0])
        bottom_row = int(cavity_rows[-1])
        centre = int(np.argmin(np.abs(grid.lateral_nm)))
        self.assertGreater(
            field.depth_factor[top_row, centre],
            field.depth_factor[bottom_row, centre],
        )
        middle_row = int(cavity_rows[len(cavity_rows) // 2])
        columns = np.flatnonzero(grid.cavity_mask[middle_row])
        near_wall = int(columns[0])
        self.assertLess(
            field.sidewall_factor[middle_row, near_wall],
            field.sidewall_factor[middle_row, centre],
        )
        self.assertLess(
            field.floor_factor[bottom_row, centre],
            field.floor_factor[top_row, centre],
        )
        self.assertTrue(np.all(field.combined_factor[~grid.cavity_mask] == 1.0))

    def test_rate_wrapper_multiplies_only_interface_values(self) -> None:
        grid = make_grid()
        field = SpatialEtchabilityField.build(
            grid,
            SpatialEtchabilityParameters(
                top_rate_factor=0.8,
                bottom_rate_factor=0.4,
            ),
        )

        def unit_rate(reactant, product, passivation, interface):
            return np.ones(grid.shape)

        wrapper = SpatiallyModifiedRateLaw(unit_rate, field)
        interface = grid.cavity_mask.copy()
        velocity = wrapper(
            np.ones(grid.shape),
            np.zeros(grid.shape),
            np.zeros(grid.shape),
            interface,
        )
        np.testing.assert_allclose(
            velocity[interface], field.combined_factor[interface]
        )
        self.assertTrue(np.all(velocity[~interface] == 0.0))

    def test_residue_regions_are_disjoint_and_full_fill_is_attached(self) -> None:
        front = MonotonicLevelSet2D(make_grid())
        result = analyse_residue_topology(
            front,
            sidewall_band_nm=2.0,
            bottom_band_nm=3.0,
        )
        region_area = (
            result.sidewall_region.initial_area_nm2
            + result.bottom_region.initial_area_nm2
            + result.core_region.initial_area_nm2
        )
        self.assertAlmostEqual(region_area, front.initial_solid_area_nm2)
        self.assertEqual(result.sidewall_region.remaining_fraction_of_region, 1.0)
        self.assertEqual(result.bottom_region.remaining_fraction_of_region, 1.0)
        self.assertEqual(result.core_region.remaining_fraction_of_region, 1.0)
        self.assertEqual(result.total_component_count, 1)
        self.assertEqual(result.sidewall_and_bottom.component_count, 1)
        self.assertAlmostEqual(
            result.sidewall_and_bottom.fraction_of_total_remaining, 1.0
        )
        self.assertAlmostEqual(result.wall_to_core_retention_ratio, 1.0)
        self.assertAlmostEqual(result.bottom_to_upper_retention_ratio, 1.0)
        self.assertAlmostEqual(result.left_right_asymmetry, 0.0)
        self.assertGreater(result.sidewall_contact_length_nm, 0.0)
        self.assertGreater(result.bottom_contact_length_nm, 0.0)

    def test_side_bottom_and_isolated_components_are_separated(self) -> None:
        front = MonotonicLevelSet2D(make_grid())
        grid = front.grid
        field = SpatialEtchabilityField.build(grid)
        front.solid_fraction[:] = 0.0

        cavity_rows = np.flatnonzero(np.any(grid.cavity_mask, axis=1))
        centre = int(np.argmin(np.abs(grid.lateral_nm)))
        side_row = int(cavity_rows[len(cavity_rows) // 3])
        side_columns = np.flatnonzero(grid.cavity_mask[side_row])
        side_cell = (side_row, int(side_columns[0]))
        bottom_cell = (int(cavity_rows[-1]), centre)
        isolated_cell = (int(cavity_rows[len(cavity_rows) // 2]), centre)
        for cell in (side_cell, bottom_cell, isolated_cell):
            front.solid_fraction[cell] = 1.0

        result = analyse_residue_topology(front)
        self.assertEqual(result.total_component_count, 3)
        self.assertEqual(result.sidewall_only.component_count, 1)
        self.assertEqual(result.bottom_only.component_count, 1)
        self.assertEqual(result.isolated.component_count, 1)
        self.assertEqual(result.sidewall_and_bottom.component_count, 0)
        self.assertLess(result.classified_area_balance_relative_error, 1.0e-14)
        self.assertGreater(result.largest_component_area_nm2, 0.0)
        # The analytic sidewall distance is retained for later plotting/debug.
        self.assertTrue(np.isfinite(field.distances.sidewall_distance_nm[side_cell]))


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""CLI for the literature-normalized graph-KMC velocity ensemble."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from graph_kmc_velocity_sweep import (
    DEFAULT_HF_ACTIVITIES,
    DEFAULT_MATERIALS,
    DEFAULT_PRODUCT_ACTIVITIES,
    DEFAULT_SITE_COUNTS,
    DEFAULT_TEMPERATURES_K,
    GraphKMCVelocitySweepConfig,
    run_graph_kmc_velocity_sweep,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run a surface-patch graph-KMC ensemble. Absolute velocities use "
            "nominal literature blanket WER; KMC supplies an uncalibrated "
            "relative modifier."
        )
    )
    parser.add_argument(
        "--site-count",
        type=int,
        action="append",
        help="size-audit site count; repeat (default: 24,48,96,192)",
    )
    parser.add_argument("--environment-site-count", type=int, default=96)
    parser.add_argument("--replicas", type=int, default=32)
    parser.add_argument(
        "--temperature-k",
        type=float,
        action="append",
        help="local interface temperature; repeat (default: 288.15,298.15,323.15)",
    )
    parser.add_argument(
        "--hf-activity",
        type=float,
        action="append",
        help="HF activity relative to each blanket reference bath; repeat",
    )
    parser.add_argument(
        "--product-activity",
        type=float,
        action="append",
        help="dimensionless product activity; repeat",
    )
    parser.add_argument(
        "--material",
        choices=DEFAULT_MATERIALS,
        action="append",
        help="material blanket anchor; repeat (default: both)",
    )
    parser.add_argument("--warmup-layers", type=int, default=1)
    parser.add_argument("--measurement-layers", type=int, default=4)
    parser.add_argument(
        "--max-events-per-removal",
        type=int,
        default=100,
        help="safety event cap multiplier",
    )
    parser.add_argument("--root-seed", type=int, default=20260714)
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="process workers; 0 selects up to four",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="ordinary JSON output path; no hash-based directory is used",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config = GraphKMCVelocitySweepConfig(
        site_counts=tuple(args.site_count or DEFAULT_SITE_COUNTS),
        environment_site_count=args.environment_site_count,
        replicas=args.replicas,
        temperatures_K=tuple(args.temperature_k or DEFAULT_TEMPERATURES_K),
        hf_activities=tuple(args.hf_activity or DEFAULT_HF_ACTIVITIES),
        product_activities=tuple(
            args.product_activity or DEFAULT_PRODUCT_ACTIVITIES
        ),
        materials=tuple(args.material or DEFAULT_MATERIALS),
        warmup_layers=args.warmup_layers,
        measurement_layers=args.measurement_layers,
        maximum_events_per_requested_removal=args.max_events_per_removal,
        root_seed=args.root_seed,
        workers=args.workers,
    )
    payload = run_graph_kmc_velocity_sweep(config)
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
        print(
            f"wrote {args.output}: "
            f"{payload['case_counts']['environment_condition_replicates']} "
            "environment replicates"
        )
    return payload


if __name__ == "__main__":
    main()

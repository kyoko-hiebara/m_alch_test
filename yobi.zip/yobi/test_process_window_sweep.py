from __future__ import annotations

import json
import math
import unittest

from literature_parameters import (
    get_literature_preset,
    hf_speciation_298K_from_weight_percent,
)
from process_window_sampling import default_parameter_definitions
from process_window_sweep import (
    CLASS_ORDER,
    ProcessCaseSpec,
    ProcessWindowConfig,
    _WorkerInput,
    _case_objects,
    _execute,
    _phase_map_payload,
    _run_case,
)


GEOMETRY = "10_10_180"
PRESET = "sin_barcellona_b_0p55wt"


def coarse_config(**overrides: object) -> ProcessWindowConfig:
    """A real but tiny continuum/graph case suitable for spawn tests."""

    values: dict[str, object] = {
        "geometries": (GEOMETRY,),
        "presets": (PRESET,),
        "design_points": 2,
        "design_seed": 20260714,
        "parameter_bounds_set": "quick",
        "replicate_seeds": (123,),
        "grid_spacing_nm": 20.0,
        "reservoir_height_nm": 20.0,
        "lateral_margin_nm": 0.0,
        "primary_hf_duration_s": 1800.0,
        "primary_sync_steps": 2,
        "maximum_events": 100,
        "second_wet_duration_s": 100.0,
        "phase_levels": 3,
        "maximum_phase_pairs": 0,
        "bootstrap_samples": 0,
        "parallel_workers": 1,
        "include_phase_maps": False,
        "include_representatives": False,
    }
    values.update(overrides)
    return ProcessWindowConfig(**values)


def reference_parameters(**overrides: float) -> dict[str, float]:
    values = {
        definition.name: float(definition.reference_value)
        for definition in default_parameter_definitions()
    }
    # Deliberately different boundaries make accidental averaging detectable.
    values.update(
        liquid_temperature_K=291.0,
        substrate_temperature_K=347.0,
        rinse_delay_s=5.0,
        second_wet_rate_multiplier=2.0,
    )
    values.update({key: float(value) for key, value in overrides.items()})
    return values


def make_spec(
    order: int = 0,
    *,
    seed: int = 123,
    parameters: dict[str, float] | None = None,
) -> ProcessCaseSpec:
    return ProcessCaseSpec(
        order=order,
        case_group="test",
        design_index=order,
        geometry_id=GEOMETRY,
        preset_id=PRESET,
        replicate_index=0,
        seed=seed,
        parameters=reference_parameters() if parameters is None else parameters,
    )


def assert_finite_tree(testcase: unittest.TestCase, value: object) -> None:
    if isinstance(value, float):
        testcase.assertTrue(math.isfinite(value))
    elif isinstance(value, dict):
        for item in value.values():
            assert_finite_tree(testcase, item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            assert_finite_tree(testcase, item)


class ProcessWindowConfigTests(unittest.TestCase):
    def test_validation_rejects_bad_scope_numerics_and_parallel_controls(self) -> None:
        invalid = (
            ({"geometries": ()}, "known selection"),
            ({"geometries": ("missing",)}, "known selection"),
            ({"presets": ("missing",)}, "known selection"),
            ({"design_points": 6}, "power of two"),
            ({"design_seed": -1}, "non-negative"),
            ({"parameter_bounds_set": "wide"}, "quick.*full"),
            ({"replicate_seeds": (1, 1)}, "duplicates"),
            ({"grid_spacing_nm": 0.0}, "finite and positive"),
            ({"lateral_margin_nm": -0.1}, "non-negative"),
            ({"primary_macro_time_step_s": 0.0}, "finite and positive"),
            (
                {"primary_hf_target_remaining_fraction": 1.0},
                "primary_hf_target_remaining_fraction",
            ),
            ({"primary_sync_steps": 0}, "must be positive"),
            ({"maximum_events": 0}, "must be positive"),
            ({"phase_levels": 2}, "phase_levels"),
            ({"maximum_phase_pairs": -1}, "phase_levels"),
            ({"bootstrap_samples": -1}, "bootstrap_samples"),
            ({"parallel_workers": 0}, "parallel_workers"),
        )
        for updates, message in invalid:
            with self.subTest(updates=updates):
                with self.assertRaisesRegex(ValueError, message):
                    coarse_config(**updates)

    def test_to_dict_is_plain_and_preserves_separate_seed_order(self) -> None:
        config = coarse_config(replicate_seeds=(9, 3))
        payload = config.to_dict()
        self.assertEqual(payload["replicate_seeds"], [9, 3])
        self.assertEqual(payload["geometries"], [GEOMETRY])
        self.assertEqual(payload["presets"], [PRESET])
        json.dumps(payload, allow_nan=False)


class ProcessCaseObjectTests(unittest.TestCase):
    def test_case_objects_keep_temperatures_independent_and_map_physical_hf(self) -> None:
        parameters = reference_parameters(hf_bulk_scale=1.25)
        spec = make_spec(parameters=parameters)
        (
            grid,
            graph_config,
            coupling,
            kinetics,
            spatial,
            derived,
        ) = _case_objects(spec, coarse_config())

        preset = get_literature_preset(PRESET)
        expected_weight_percent = preset.transport_hf_weight_percent * 1.25
        expected_speciation = hf_speciation_298K_from_weight_percent(
            expected_weight_percent
        )
        self.assertAlmostEqual(
            float(derived["hf_weight_percent"]), expected_weight_percent
        )
        self.assertAlmostEqual(
            coupling.hf_bulk_concentration,
            expected_speciation.neutral_hf_mol_m3,
        )
        self.assertAlmostEqual(
            float(derived["hf_neutral_mol_m3"]),
            expected_speciation.neutral_hf_mol_m3,
        )
        self.assertAlmostEqual(
            float(derived["hf_analytical_mol_m3"]),
            expected_speciation.analytical_fluorine_mol_m3,
        )
        self.assertEqual(coupling.solution_temperature_K, 291.0)
        self.assertEqual(coupling.substrate_temperature_K, 347.0)
        self.assertNotEqual(
            coupling.solution_temperature_K, coupling.substrate_temperature_K
        )
        self.assertEqual(grid.geometry.name, GEOMETRY)
        self.assertEqual(graph_config.material, preset.material)
        self.assertGreater(kinetics.removal_rate_s, 0.0)
        self.assertEqual(spatial.bottom_rate_factor, parameters["depth_quality_factor"])

    def test_primary_endpoint_target_and_independent_macro_step_are_propagated(
        self,
    ) -> None:
        spec = make_spec()
        explicit = coarse_config(
            primary_hf_duration_s=123.0,
            primary_sync_steps=3,
            primary_macro_time_step_s=7.0,
            primary_hf_target_remaining_fraction=0.25,
        )
        _, _, coupling, _, _, derived = _case_objects(spec, explicit)

        self.assertEqual(coupling.total_time_s, 123.0)
        self.assertEqual(coupling.macro_time_step_s, 7.0)
        self.assertEqual(coupling.target_remaining_fraction, 0.25)
        self.assertEqual(derived["primary_macro_time_step_s"], 7.0)
        self.assertEqual(
            derived["primary_hf_target_remaining_fraction"],
            0.25,
        )

        default = coarse_config(
            primary_hf_duration_s=123.0,
            primary_sync_steps=3,
        )
        _, _, default_coupling, _, _, default_derived = _case_objects(
            spec, default
        )
        self.assertEqual(default_coupling.macro_time_step_s, 41.0)
        self.assertIsNone(default_coupling.target_remaining_fraction)
        self.assertEqual(default_derived["primary_macro_time_step_s"], 41.0)
        self.assertIsNone(
            default_derived["primary_hf_target_remaining_fraction"]
        )


class RealCoarseCaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = coarse_config()
        cls.case = _run_case(_WorkerInput(make_spec(), cls.config))

    def test_primary_second_wet_state_continuity_and_monotonicity(self) -> None:
        case = self.case
        self.assertEqual(case["status"], "ok")
        stages = case["stage_summaries"]
        primary = stages["primary_hf"]
        second = stages["second_wet_matrix"]
        final = stages["final"]

        self.assertEqual(
            primary["state_counts"], second["before_metrics"]["state_counts"]
        )
        self.assertEqual(primary["time_s"], second["source_time_s"])
        self.assertAlmostEqual(
            second["total_time_s"],
            second["source_time_s"] + second["duration_s"],
        )
        self.assertGreaterEqual(
            second["after_metrics"]["removed_fraction"],
            second["before_metrics"]["removed_fraction"],
        )
        self.assertEqual(
            final["state_counts"], second["after_metrics"]["state_counts"]
        )
        deposit = stages["second_wet_deposit"]
        self.assertLessEqual(
            deposit["after_inventory_native"], deposit["before_inventory_native"]
        )

    def test_four_class_schema_convergence_and_strict_finite_json(self) -> None:
        case = self.case
        self.assertEqual(
            CLASS_ORDER,
            (
                "complete_removal",
                "bottom_residue",
                "wall_residue",
                "precipitation_residue",
            ),
        )
        classification = case["classification"]
        self.assertIn(classification["primary_class"], CLASS_ORDER)
        for key in (
            "coexist",
            "mixed",
            "score",
            "bottom_region_flag",
            "wall_region_flag",
        ):
            self.assertIn(key, classification)
        self.assertTrue(case["convergence"]["all_hf_synchronizations"])
        self.assertTrue(case["convergence"]["all_product_synchronizations"])
        self.assertTrue(case["convergence"]["maximum_site_budget_ok"])
        assert_finite_tree(self, case)
        encoded = json.dumps(case, allow_nan=False, sort_keys=True)
        self.assertNotIn("NaN", encoded)
        self.assertNotIn("Infinity", encoded)

    def test_deposit_amount_density_thickness_and_coverage_are_exported(self) -> None:
        metrics = self.case["deposit_metrics"]
        for key in (
            "deposit_total_inventory_native",
            "deposit_total_mol_per_nm_span",
            "deposit_wall_areal_inventory_mol_m2",
            "deposit_bottom_areal_inventory_mol_m2",
            "deposit_mean_wall_thickness_nm",
            "deposit_mean_bottom_thickness_nm",
            "deposit_wall_coverage_fraction",
            "deposit_bottom_coverage_fraction",
        ):
            self.assertIn(key, metrics)
            self.assertGreaterEqual(float(metrics[key]), 0.0)
        # The SiN/AFS interpretation has a defined molar mass; generic SiOCN
        # intentionally reports null until its precipitate composition is
        # measured.
        self.assertIsNotNone(metrics["deposit_total_mass_kg_per_nm_span"])


class ProcessExecutionTests(unittest.TestCase):
    def test_execute_workers_one_and_two_preserve_order_and_metrics(self) -> None:
        config = coarse_config()
        jobs = [
            _WorkerInput(make_spec(0, seed=123), config),
            _WorkerInput(make_spec(1, seed=456), config),
        ]
        serial = _execute(jobs, workers=1)
        parallel = _execute(jobs, workers=2)

        self.assertEqual(
            [case["case_id"] for case in parallel],
            [case["case_id"] for case in serial],
        )
        self.assertEqual(
            [case["order"] for case in parallel],
            [case["order"] for case in serial],
        )
        for serial_case, parallel_case in zip(serial, parallel, strict=True):
            self.assertEqual(serial_case["status"], "ok")
            self.assertEqual(parallel_case["status"], "ok")
            self.assertEqual(parallel_case["metrics"], serial_case["metrics"])
            self.assertEqual(
                parallel_case["classification"], serial_case["classification"]
            )


class PhaseProbabilityTests(unittest.TestCase):
    def test_mock_phase_probabilities_form_a_partition_at_every_cell(self) -> None:
        config = coarse_config(replicate_seeds=(11, 22))
        values = [0.5, 1.0, 1.5]
        pair = {
            "pair_id": "p1_hf__wall",
            "x_parameter": "hf_bulk_scale",
            "y_parameter": "wall_affinity",
            "x_values": values,
            "y_values": values,
        }
        cases: list[dict[str, object]] = []
        for y_index in range(3):
            for x_index in range(3):
                for replicate_index in range(2):
                    class_name = CLASS_ORDER[
                        (3 * y_index + x_index + replicate_index) % len(CLASS_ORDER)
                    ]
                    cases.append(
                        {
                            "status": "ok",
                            "case_id": (
                                f"phase_{y_index}_{x_index}_{replicate_index}"
                            ),
                            "pair_id": pair["pair_id"],
                            "geometry_id": GEOMETRY,
                            "preset_id": PRESET,
                            "x_index": x_index,
                            "y_index": y_index,
                            "classification": {"primary_class": class_name},
                        }
                    )

        payload = _phase_map_payload([pair], cases, config)
        self.assertEqual(len(payload), 1)
        stratum = payload[0]["strata"][0]
        probabilities = stratum["class_probabilities"]
        for y_index in range(3):
            for x_index in range(3):
                total = sum(
                    probabilities[class_name][y_index][x_index]
                    for class_name in CLASS_ORDER
                )
                self.assertAlmostEqual(total, 1.0)
                self.assertAlmostEqual(
                    stratum["dominant_probability"][y_index][x_index], 0.5
                )
                self.assertEqual(
                    len(stratum["case_ids"][y_index][x_index]), 2
                )


if __name__ == "__main__":
    unittest.main()

"""Provisional dual-channel blanket model for Kawarazaki et al. Fig. 2.

The source reports paired 30 s blanket-film thickness losses:

* dHF-only removal;
* one fixed 240 degC, 30 s ozone bake followed by 30 s dHF.

This module implements the explicitly requested provisional linearity:

* dHF-only thickness loss scales with dHF exposure time;
* the fixed ozone/dHF endpoint scales with integer cycle count.

The paired difference is labelled ``ozone_enabled_increment``.  It is not an
ozone-only etch amount and does not identify oxidation, dissolution, or native
oxide preclean contributions separately.
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

from literature_parameters import (
    KAWARAZAKI_2024_FIG2_ENDPOINTS,
    get_cyclic_etch_endpoint,
)


SCHEMA_VERSION = "ozone-dhf-linear-blanket/v1"
MODEL_NOTICE = (
    "Provisional literature-prior blanket model, not a process recipe. "
    "Fig. 2 raster endpoints have no experimental error bars. dHF time and "
    "fixed ozone/dHF cycle count are assumed linear by request; no ozone-time, "
    "temperature, composition, transport, patterned-feature, or damage "
    "extrapolation is encoded."
)


@dataclass(frozen=True)
class OzoneDHFLinearConfig:
    endpoint_ids: tuple[str, ...] = tuple(KAWARAZAKI_2024_FIG2_ENDPOINTS)
    dhf_only_durations_s: tuple[float, ...] = (30.0, 60.0, 120.0)
    cycle_counts: tuple[int, ...] = (1, 2, 3)

    def __post_init__(self) -> None:
        if not self.endpoint_ids:
            raise ValueError("endpoint_ids cannot be empty")
        unknown = set(self.endpoint_ids).difference(
            KAWARAZAKI_2024_FIG2_ENDPOINTS
        )
        if unknown:
            raise ValueError(f"unknown endpoint_ids: {sorted(unknown)}")
        if len(set(self.endpoint_ids)) != len(self.endpoint_ids):
            raise ValueError("endpoint_ids cannot contain duplicates")
        if not self.dhf_only_durations_s:
            raise ValueError("dhf_only_durations_s cannot be empty")
        for duration in self.dhf_only_durations_s:
            value = float(duration)
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(
                    "dhf_only_durations_s must be finite and non-negative"
                )
        if len(set(self.dhf_only_durations_s)) != len(
            self.dhf_only_durations_s
        ):
            raise ValueError("dhf_only_durations_s cannot contain duplicates")
        if not self.cycle_counts:
            raise ValueError("cycle_counts cannot be empty")
        if any(
            not isinstance(cycles, int) or cycles < 0
            for cycles in self.cycle_counts
        ):
            raise ValueError(
                "cycle_counts must contain non-negative integers"
            )
        if len(set(self.cycle_counts)) != len(self.cycle_counts):
            raise ValueError("cycle_counts cannot contain duplicates")
        object.__setattr__(self, "endpoint_ids", tuple(self.endpoint_ids))
        object.__setattr__(
            self,
            "dhf_only_durations_s",
            tuple(float(value) for value in self.dhf_only_durations_s),
        )
        object.__setattr__(self, "cycle_counts", tuple(self.cycle_counts))

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["endpoint_ids"] = list(self.endpoint_ids)
        result["dhf_only_durations_s"] = list(self.dhf_only_durations_s)
        result["cycle_counts"] = list(self.cycle_counts)
        return result


def _case(endpoint_id: str, config: OzoneDHFLinearConfig) -> dict[str, object]:
    endpoint = get_cyclic_etch_endpoint(endpoint_id)
    cycle_conditions_match = (
        endpoint.reported_cycle_ozone_duration_matches_endpoint
    )
    dhf_predictions = [
        {
            "duration_s": duration,
            "etch_amount_nm": endpoint.predict_dhf_only_etch_nm(duration),
            "is_source_duration": math.isclose(
                duration,
                endpoint.dhf_duration_s,
                rel_tol=0.0,
                abs_tol=1.0e-12,
            ),
            "linearly_extrapolated_from_single_endpoint": not math.isclose(
                duration,
                endpoint.dhf_duration_s,
                rel_tol=0.0,
                abs_tol=1.0e-12,
            ),
        }
        for duration in config.dhf_only_durations_s
    ]
    cycle_predictions = []
    for cycles in config.cycle_counts:
        total = endpoint.predict_ozone_dhf_etch_nm(cycles)
        paired_hf_baseline = round(
            cycles * endpoint.dhf_only_etch_amount_nm,
            12,
        )
        ozone_enabled = round(
            cycles * endpoint.ozone_enabled_increment_nm_per_cycle,
            12,
        )
        cycle_predictions.append(
            {
                "cycles": cycles,
                "ozone_then_dhf_total_etch_nm": total,
                "paired_dhf_baseline_nm": paired_hf_baseline,
                "ozone_enabled_increment_nm": ozone_enabled,
                "decomposition_residual_nm": round(
                    total - paired_hf_baseline - ozone_enabled,
                    12,
                ),
                "reported_cycle_linearity_max": (
                    endpoint.reported_cycle_linearity_max
                ),
                "within_reported_cycle_count_range": (
                    cycles <= endpoint.reported_cycle_linearity_max
                ),
                "cycle_count_extrapolated": (
                    cycles > endpoint.reported_cycle_linearity_max
                ),
                "fixed_endpoint_sequence_directly_supported": (
                    cycles <= 1
                    or (
                        cycles <= endpoint.reported_cycle_linearity_max
                        and cycle_conditions_match
                    )
                ),
                "fixed_endpoint_cycle_scaling_is_assumption": (
                    cycles > 1
                    and (
                        cycles > endpoint.reported_cycle_linearity_max
                        or not cycle_conditions_match
                    )
                ),
                "fixed_cycle_conditions": {
                    "ozone_bake_temperature_K": (
                        endpoint.ozone_bake_temperature_K
                    ),
                    "ozone_concentration_g_m3": (
                        endpoint.ozone_concentration_g_m3
                    ),
                    "ozone_bake_duration_s": endpoint.ozone_bake_duration_s,
                    "dhf_reported_percent": endpoint.dhf_reported_percent,
                    "dhf_duration_s": endpoint.dhf_duration_s,
                },
            }
        )
    return {
        "endpoint_id": endpoint_id,
        "material": endpoint.material,
        "film_description": endpoint.film_description,
        "source_endpoint": endpoint.to_dict(),
        "dhf_only": {
            "apparent_rate_nm_min": (
                endpoint.dhf_only_apparent_rate_nm_min
            ),
            "predictions": dhf_predictions,
        },
        "ozone_then_dhf": {
            "etch_amount_nm_per_fixed_cycle": (
                endpoint.ozone_then_dhf_etch_amount_nm
            ),
            "ozone_enabled_increment_nm_per_cycle": (
                endpoint.ozone_enabled_increment_nm_per_cycle
            ),
            "predictions": cycle_predictions,
        },
    }


def run_ozone_dhf_linear_model(
    config: OzoneDHFLinearConfig = OzoneDHFLinearConfig(),
) -> dict[str, object]:
    cases = [_case(endpoint_id, config) for endpoint_id in config.endpoint_ids]
    maximum_decomposition_residual = max(
        abs(float(row["decomposition_residual_nm"]))
        for case in cases
        for row in case["ozone_then_dhf"]["predictions"]
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "model": "Kawarazaki Fig. 2 provisional dual-channel blanket model",
        "notice": MODEL_NOTICE,
        "config": config.to_dict(),
        "assumptions": {
            "dhf_only_time_linearity": True,
            "fixed_cycle_count_linearity": True,
            "ozone_bake_time_scaling": False,
            "ozone_enabled_increment_is_ozone_only_etch": False,
            "experimental_error_bars_available": False,
            "patterned_feature_validation": False,
        },
        "quality": {
            "case_count": len(cases),
            "maximum_decomposition_residual_nm": (
                maximum_decomposition_residual
            ),
            "strictly_algebraic_closure": (
                maximum_decomposition_residual <= 1.0e-12
            ),
        },
        "cases": cases,
    }


def save_ozone_dhf_linear_json(
    payload: dict[str, object], path: str | Path
) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    destination.write_text(text + "\n", encoding="utf-8")
    return destination


__all__ = [
    "MODEL_NOTICE",
    "OzoneDHFLinearConfig",
    "SCHEMA_VERSION",
    "run_ozone_dhf_linear_model",
    "save_ozone_dhf_linear_json",
]

"""Targeted dry-down versus surface-affinity discrimination sweep.

The primary HF continuum/graph-KMC calculation is shared by every post-HF
probe in one ``(geometry, material, seed)`` stratum.  Post-HF product capture
and surface allocation are deliberately separate operations:

* rinse and drying conditions determine a scalar captured precursor amount;
* wall/bottom affinities only allocate that already-fixed amount.

The coefficients are screening hypotheses, not calibrated recipe settings.
All four requested endpoints (HF, rinse, dry-down, second-WET) retain explicit
mass-balance closures and persistent-deposit diagnostics.
"""

from __future__ import annotations

import csv
import json
import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np

from literature_parameters import (
    get_literature_preset,
    hf_speciation_298K_from_weight_percent,
)
from literature_sweep import nominal_preset_names
from persistent_deposit import (
    NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN,
    DepositParameters,
    PersistentDepositPhase2D,
)
from persistent_deposit_sweep import (
    AFS_MOLAR_MASS_KG_MOL,
    AFS_MOLAR_DENSITY_MOL_M3,
    _deposit_yield,
    afs_solubility_from_hf_mol_m3,
)
from process_window_sweep import (
    ProcessCaseSpec,
    ProcessWindowConfig,
    _case_objects,
)
from trench_geometry import GEOMETRY_PRESETS
from trench_graph_kmc import (
    SecondWetKMCParameters,
    run_coupled_trench_kmc,
    run_second_wet_stage,
    trench_residue_metrics,
)


SCHEMA_VERSION = "trench-attachment-discrimination/v1"
MODEL_NOTICE = (
    "Uncalibrated mechanism-discrimination calculation, not a process recipe. "
    "A fixed post-HF-to-dry window uses a well-mixed exponential rinse "
    "exchange closure and a first-order drying extent. Surface affinity only "
    "allocates fixed captured precursor and cannot change its total amount. "
    "SiOCN deposit identity and all post-HF coefficients require experimental "
    "calibration."
)


def _finite_nonnegative(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")


def _finite_positive(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


@dataclass(frozen=True)
class AttachmentProbe:
    """One independently varied post-HF diagnostic coordinate."""

    name: str
    label_ja: str
    parameter: str
    values: tuple[float | bool, ...]
    unit: str
    transform: str
    expected_readout: str

    def __post_init__(self) -> None:
        if not self.name or not self.label_ja or not self.parameter:
            raise ValueError("probe name, label and parameter cannot be empty")
        if self.transform not in {"binary", "linear", "log"}:
            raise ValueError("probe transform must be binary, linear or log")
        if len(self.values) < 2:
            raise ValueError("each probe needs at least two values")
        numeric = tuple(float(value) for value in self.values)
        if any(not math.isfinite(value) for value in numeric):
            raise ValueError("probe values must be finite")
        if self.transform == "log" and any(value <= 0.0 for value in numeric):
            raise ValueError("log probe values must be positive")
        object.__setattr__(self, "values", tuple(self.values))

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "label_ja": self.label_ja,
            "parameter": self.parameter,
            "values": list(self.values),
            "unit": self.unit,
            "transform": self.transform,
            "expected_readout": self.expected_readout,
        }


def default_attachment_probes() -> tuple[AttachmentProbe, ...]:
    """Return the seven requested independent diagnostic probes."""

    return (
        AttachmentProbe(
            "dry_enabled",
            "dry / no-dry",
            "dry_enabled",
            (False, True),
            "boolean",
            "binary",
            "A deposit appearing only after dry-down supports dry capture.",
        ),
        AttachmentProbe(
            "drying_rate",
            "乾燥速度（時定数）",
            "drying_rate_s",
            (1.0 / 120.0, 1.0 / 30.0, 1.0 / 5.0),
            "s^-1",
            "log",
            "Total deposit follows drying extent; allocation should not.",
        ),
        AttachmentProbe(
            "rinse_flow",
            "rinse flow交換速度",
            "rinse_exchange_rate_s",
            (0.0, 0.05, 0.20),
            "s^-1",
            "linear",
            "Faster exchange lowers soluble residual and total deposit.",
        ),
        AttachmentProbe(
            "immediate_quench",
            "即時quench",
            "immediate_quench",
            (False, True),
            "boolean",
            "binary",
            "Starting rinse at t=0 increases its effective flow duration.",
        ),
        AttachmentProbe(
            "wall_pretreatment",
            "wall表面前処理",
            "wall_pretreatment_multiplier",
            (0.25, 1.0, 4.0),
            "relative",
            "log",
            "Wall share changes while total captured amount stays fixed.",
        ),
        AttachmentProbe(
            "wall_material_selectivity",
            "wall材質選択性",
            "wall_material_selectivity",
            (0.25, 1.0, 4.0),
            "relative",
            "log",
            "Wall share/density changes without a total-capture change.",
        ),
        AttachmentProbe(
            "bottom_material_selectivity",
            "bottom材質選択性",
            "bottom_material_selectivity",
            (0.25, 1.0, 4.0),
            "relative",
            "log",
            "Bottom share/density changes without a total-capture change.",
        ),
    )


DEFAULT_PHASE_PAIRS = (
    ("drying_rate", "wall_pretreatment"),
    ("rinse_flow", "wall_pretreatment"),
    ("wall_material_selectivity", "bottom_material_selectivity"),
)


@dataclass(frozen=True)
class AttachmentDiscriminationConfig:
    """Primary-run controls and post-HF discrimination design."""

    geometries: tuple[str, ...] = ("10_10_180", "7_7_170")
    presets: tuple[str, ...] = nominal_preset_names()
    replicate_seeds: tuple[int, ...] = (271828, 314159)
    probes: tuple[AttachmentProbe, ...] = default_attachment_probes()
    phase_pairs: tuple[tuple[str, str], ...] = DEFAULT_PHASE_PAIRS
    include_phase_maps: bool = True
    phase_levels: int = 5
    parallel_workers: int = 1
    grid_spacing_nm: float = 1.7
    reservoir_height_nm: float = 4.0
    lateral_margin_nm: float = 3.0
    primary_hf_duration_s: float = 300.0
    primary_sync_steps: int = 30
    maximum_events: int = 40_000
    post_hf_to_dry_window_s: float = 60.0
    rinse_start_delay_s: float = 30.0
    rinse_exchange_rate_s: float = 0.05
    drying_duration_s: float = 60.0
    drying_rate_s: float = 1.0 / 30.0
    drydown_capture_fraction: float = 0.05
    dry_enabled: bool = True
    immediate_quench: bool = False
    wall_pretreatment_multiplier: float = 1.0
    wall_material_selectivity: float = 1.0
    bottom_material_selectivity: float = 1.0
    second_wet_duration_s: float = 30.0
    second_wet_rate_multiplier: float = 0.70
    deposit_reference_dissolution_rate_s: float = 0.025
    surface_profile_bins: int = 24

    def __post_init__(self) -> None:
        unknown_geometries = set(self.geometries).difference(GEOMETRY_PRESETS)
        if not self.geometries or unknown_geometries:
            raise ValueError("geometries must be a non-empty known selection")
        if not self.presets:
            raise ValueError("presets cannot be empty")
        for preset_id in self.presets:
            get_literature_preset(preset_id)
        if not self.replicate_seeds or any(seed < 0 for seed in self.replicate_seeds):
            raise ValueError("replicate_seeds must contain non-negative integers")
        if len(set(self.replicate_seeds)) != len(self.replicate_seeds):
            raise ValueError("replicate_seeds cannot contain duplicates")
        if not self.probes:
            raise ValueError("probes cannot be empty")
        probe_names = [probe.name for probe in self.probes]
        if len(set(probe_names)) != len(probe_names):
            raise ValueError("probe names cannot contain duplicates")
        for pair in self.phase_pairs:
            if len(pair) != 2 or pair[0] == pair[1]:
                raise ValueError("phase pairs must contain two distinct probes")
            if set(pair).difference(probe_names):
                raise ValueError("phase pairs must reference configured probes")
        for name in (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "primary_hf_duration_s",
            "post_hf_to_dry_window_s",
            "drying_duration_s",
            "drying_rate_s",
            "second_wet_duration_s",
            "deposit_reference_dissolution_rate_s",
        ):
            _finite_positive(name, getattr(self, name))
        for name in (
            "lateral_margin_nm",
            "rinse_start_delay_s",
            "rinse_exchange_rate_s",
            "second_wet_rate_multiplier",
        ):
            _finite_nonnegative(name, getattr(self, name))
        for name in (
            "wall_pretreatment_multiplier",
            "wall_material_selectivity",
            "bottom_material_selectivity",
        ):
            _finite_positive(name, getattr(self, name))
        if not 0.0 <= self.drydown_capture_fraction <= 1.0:
            raise ValueError("drydown_capture_fraction must lie within [0, 1]")
        if self.primary_sync_steps < 1 or self.maximum_events < 1:
            raise ValueError("primary_sync_steps and maximum_events must be positive")
        if self.parallel_workers < 1:
            raise ValueError("parallel_workers must be positive")
        if self.phase_levels < 3:
            raise ValueError("phase_levels must be at least three")
        if self.surface_profile_bins < 4:
            raise ValueError("surface_profile_bins must be at least four")
        object.__setattr__(self, "geometries", tuple(self.geometries))
        object.__setattr__(self, "presets", tuple(self.presets))
        object.__setattr__(self, "replicate_seeds", tuple(self.replicate_seeds))
        object.__setattr__(self, "probes", tuple(self.probes))
        object.__setattr__(self, "phase_pairs", tuple(tuple(pair) for pair in self.phase_pairs))

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["geometries"] = list(self.geometries)
        result["presets"] = list(self.presets)
        result["replicate_seeds"] = list(self.replicate_seeds)
        result["probes"] = [probe.to_dict() for probe in self.probes]
        result["phase_pairs"] = [list(pair) for pair in self.phase_pairs]
        return result

    def process_window_config(self) -> ProcessWindowConfig:
        return ProcessWindowConfig(
            geometries=self.geometries,
            presets=self.presets,
            design_points=2,
            replicate_seeds=self.replicate_seeds,
            grid_spacing_nm=self.grid_spacing_nm,
            reservoir_height_nm=self.reservoir_height_nm,
            lateral_margin_nm=self.lateral_margin_nm,
            primary_hf_duration_s=self.primary_hf_duration_s,
            primary_sync_steps=self.primary_sync_steps,
            maximum_events=self.maximum_events,
            second_wet_duration_s=self.second_wet_duration_s,
            deposit_reference_dissolution_rate_s=(
                self.deposit_reference_dissolution_rate_s
            ),
            phase_levels=3,
            maximum_phase_pairs=0,
            bootstrap_samples=0,
            parallel_workers=1,
            include_phase_maps=False,
            include_representatives=False,
        )


@dataclass(frozen=True)
class AttachmentCaseDesign:
    local_order: int
    case_group: str
    probe_name: str
    probe_level: int
    parameters: Mapping[str, float | bool]
    pair_id: str | None = None
    x_index: int | None = None
    y_index: int | None = None


@dataclass(frozen=True)
class _StratumJob:
    stratum_order: int
    geometry_id: str
    preset_id: str
    replicate_index: int
    seed: int
    config: AttachmentDiscriminationConfig
    designs: tuple[AttachmentCaseDesign, ...]


def _reference_parameters(config: AttachmentDiscriminationConfig) -> dict[str, float | bool]:
    return {
        "dry_enabled": bool(config.dry_enabled),
        "drying_rate_s": float(config.drying_rate_s),
        "rinse_exchange_rate_s": float(config.rinse_exchange_rate_s),
        "immediate_quench": bool(config.immediate_quench),
        "wall_pretreatment_multiplier": float(config.wall_pretreatment_multiplier),
        "wall_material_selectivity": float(config.wall_material_selectivity),
        "bottom_material_selectivity": float(config.bottom_material_selectivity),
    }


def _primary_parameters() -> dict[str, float]:
    """Reference primary-HF conditions, identical for all post-HF probes."""

    return {
        "hf_bulk_scale": 1.0,
        "liquid_temperature_K": 298.15,
        "substrate_temperature_K": 323.15,
        "depth_quality_factor": 1.0,
        "wall_quality_factor": 1.0,
        "floor_quality_factor": 1.0,
        "product_inhibition_strength": 2.0,
        "passivation_generation_rate_s": 0.26,
        "passivation_release_rate_s": 0.08,
    }


def _phase_values(probe: AttachmentProbe, levels: int) -> tuple[float | bool, ...]:
    if probe.transform == "binary":
        return tuple(probe.values)
    low = float(probe.values[0])
    high = float(probe.values[-1])
    unit = np.linspace(0.0, 1.0, levels)
    if probe.transform == "log":
        values = np.exp(math.log(low) + unit * (math.log(high) - math.log(low)))
    else:
        values = low + unit * (high - low)
    return tuple(float(value) for value in values)


def build_attachment_design(
    config: AttachmentDiscriminationConfig,
) -> tuple[tuple[AttachmentCaseDesign, ...], list[dict[str, object]]]:
    """Create OAT contrasts and selected interaction maps."""

    reference = _reference_parameters(config)
    designs: list[AttachmentCaseDesign] = []
    for probe in config.probes:
        for level, value in enumerate(probe.values):
            parameters = dict(reference)
            parameters[probe.parameter] = value
            designs.append(
                AttachmentCaseDesign(
                    local_order=len(designs),
                    case_group="probe",
                    probe_name=probe.name,
                    probe_level=level,
                    parameters=parameters,
                )
            )

    metadata: list[dict[str, object]] = []
    if config.include_phase_maps:
        by_name = {probe.name: probe for probe in config.probes}
        for x_name, y_name in config.phase_pairs:
            x_probe = by_name[x_name]
            y_probe = by_name[y_name]
            x_values = _phase_values(x_probe, config.phase_levels)
            y_values = _phase_values(y_probe, config.phase_levels)
            pair_id = f"{x_name}__{y_name}"
            metadata.append(
                {
                    "pair_id": pair_id,
                    "x_name": x_name,
                    "x_parameter": x_probe.parameter,
                    "x_label_ja": x_probe.label_ja,
                    "x_unit": x_probe.unit,
                    "x_values": list(x_values),
                    "y_name": y_name,
                    "y_parameter": y_probe.parameter,
                    "y_label_ja": y_probe.label_ja,
                    "y_unit": y_probe.unit,
                    "y_values": list(y_values),
                }
            )
            for y_index, y_value in enumerate(y_values):
                for x_index, x_value in enumerate(x_values):
                    parameters = dict(reference)
                    parameters[x_probe.parameter] = x_value
                    parameters[y_probe.parameter] = y_value
                    designs.append(
                        AttachmentCaseDesign(
                            local_order=len(designs),
                            case_group="phase_map",
                            probe_name=pair_id,
                            probe_level=y_index * len(x_values) + x_index,
                            parameters=parameters,
                            pair_id=pair_id,
                            x_index=x_index,
                            y_index=y_index,
                        )
                    )
    return tuple(designs), metadata


def post_hf_closure(
    generated_inventory_native: float,
    *,
    post_hf_to_dry_window_s: float,
    rinse_start_delay_s: float,
    rinse_exchange_rate_s: float,
    immediate_quench: bool,
    dry_enabled: bool,
    drying_rate_s: float,
    drying_duration_s: float,
    drydown_capture_fraction: float,
) -> dict[str, float | bool]:
    """Return the scalar rinse/dry closure, before surface allocation."""

    _finite_nonnegative("generated_inventory_native", generated_inventory_native)
    _finite_positive("post_hf_to_dry_window_s", post_hf_to_dry_window_s)
    _finite_nonnegative("rinse_start_delay_s", rinse_start_delay_s)
    _finite_nonnegative("rinse_exchange_rate_s", rinse_exchange_rate_s)
    _finite_positive("drying_rate_s", drying_rate_s)
    _finite_positive("drying_duration_s", drying_duration_s)
    if not 0.0 <= drydown_capture_fraction <= 1.0:
        raise ValueError("drydown_capture_fraction must lie within [0, 1]")

    effective_delay = 0.0 if immediate_quench else rinse_start_delay_s
    flow_duration = max(post_hf_to_dry_window_s - effective_delay, 0.0)
    rinse_retention = math.exp(-rinse_exchange_rate_s * flow_duration)
    soluble_residual = generated_inventory_native * rinse_retention
    rinse_removed = generated_inventory_native - soluble_residual
    dry_extent = (
        1.0 - math.exp(-drying_rate_s * drying_duration_s)
        if dry_enabled
        else 0.0
    )
    captured = soluble_residual * drydown_capture_fraction * dry_extent
    uncaptured = soluble_residual - captured
    return {
        "immediate_quench": bool(immediate_quench),
        "effective_rinse_start_delay_s": effective_delay,
        "effective_rinse_flow_duration_s": flow_duration,
        "rinse_exchange_rate_s": rinse_exchange_rate_s,
        "rinse_exchange_number": rinse_exchange_rate_s * flow_duration,
        "rinse_retention_fraction": rinse_retention,
        "rinse_removed_inventory_native": rinse_removed,
        "soluble_residual_inventory_native": soluble_residual,
        "dry_enabled": bool(dry_enabled),
        "drying_rate_s": drying_rate_s,
        "drying_time_constant_s": 1.0 / drying_rate_s,
        "drying_duration_s": drying_duration_s,
        "dry_extent": dry_extent,
        "drydown_capture_fraction": drydown_capture_fraction,
        "captured_precursor_inventory_native": captured,
        "effective_capture_fraction_of_generated": (
            rinse_retention * drydown_capture_fraction * dry_extent
        ),
        "uncaptured_soluble_inventory_native": uncaptured,
    }


def _balance(
    input_inventory_native: float,
    outputs: Mapping[str, float],
) -> dict[str, object]:
    output_total = float(sum(float(value) for value in outputs.values()))
    error = output_total - float(input_inventory_native)
    scale = max(abs(float(input_inventory_native)), 1.0e-300)
    return {
        "input_inventory_native": float(input_inventory_native),
        "outputs_inventory_native": {
            key: float(value) for key, value in outputs.items()
        },
        "output_total_inventory_native": output_total,
        "closure_error_inventory_native": error,
        "closure_relative_error": abs(error) / scale,
        "closed": bool(abs(error) <= 1.0e-12 * scale),
    }


def _surface_normalized(phase: PersistentDepositPhase2D) -> dict[str, float]:
    wall_inventory = float(np.sum(phase.wall_inventory_native))
    bottom_inventory = float(np.sum(phase.bottom_inventory_native))
    wall_length = float(np.sum(phase.wall_contact_length_nm))
    bottom_length = float(np.sum(phase.bottom_contact_length_nm))
    minimum_cell = min(phase.grid.dx_nm, phase.grid.dz_nm)
    wall_thickness = phase.wall_thickness_nm
    bottom_thickness = phase.bottom_thickness_nm

    def coverage(thickness: np.ndarray, contact: np.ndarray, length: float) -> float:
        if length <= 0.0:
            return 0.0
        local = np.clip(thickness / minimum_cell, 0.0, 1.0)
        return float(np.sum(local * contact) / length)

    return {
        "wall_contact_length_nm": wall_length,
        "bottom_contact_length_nm": bottom_length,
        "wall_inventory_native_per_nm": wall_inventory / wall_length if wall_length else 0.0,
        "bottom_inventory_native_per_nm": bottom_inventory / bottom_length if bottom_length else 0.0,
        "wall_areal_density_mol_m2": (
            wall_inventory * 1.0e-9 / wall_length if wall_length else 0.0
        ),
        "bottom_areal_density_mol_m2": (
            bottom_inventory * 1.0e-9 / bottom_length if bottom_length else 0.0
        ),
        "wall_grid_cell_equivalent_coverage_fraction": coverage(
            wall_thickness, phase.wall_contact_length_nm, wall_length
        ),
        "bottom_grid_cell_equivalent_coverage_fraction": coverage(
            bottom_thickness, phase.bottom_contact_length_nm, bottom_length
        ),
    }


def _deposit_stage(phase: PersistentDepositPhase2D) -> dict[str, object]:
    diagnostics = phase.diagnostics().to_dict()
    # Keep the full current diagnostics mapping so future persistent-deposit
    # fields remain consumable without a schema rewrite.
    return {
        "deposit_diagnostics": diagnostics,
        "surface_normalized": _surface_normalized(phase),
    }


def _surface_profile(
    phase: PersistentDepositPhase2D,
    bins: int,
) -> dict[str, list[float]]:
    grid = phase.grid
    depth_fraction = np.clip(
        grid.depth_mesh_nm / grid.geometry.depth_nm, 0.0, 1.0
    )
    depth_edges = np.linspace(0.0, 1.0, bins + 1)
    wall_total = float(np.sum(phase.wall_inventory_native))
    wall_inventory_fraction: list[float] = []
    wall_mean_thickness: list[float] = []
    wall_coverage: list[float] = []
    for index in range(bins):
        mask = (
            (depth_fraction >= depth_edges[index])
            & (depth_fraction < depth_edges[index + 1] + (1.0e-12 if index == bins - 1 else 0.0))
            & (phase.wall_contact_length_nm > 0.0)
        )
        length = float(np.sum(phase.wall_contact_length_nm[mask]))
        inventory = float(np.sum(phase.wall_inventory_native[mask]))
        wall_inventory_fraction.append(inventory / wall_total if wall_total else 0.0)
        if length:
            wall_mean_thickness.append(
                inventory / (phase.parameters.deposit_molar_density_mol_m3 * length)
            )
            wall_coverage.append(
                float(
                    np.sum(
                        (
                            1.0
                            - np.exp(
                                -phase.wall_thickness_nm[mask]
                                / phase.parameters.coverage_reference_thickness_nm
                            )
                        )
                        * phase.wall_contact_length_nm[mask]
                    )
                    / length
                )
            )
        else:
            wall_mean_thickness.append(0.0)
            wall_coverage.append(0.0)

    bottom_width = grid.geometry.bottom_width_nm
    x_fraction = np.clip(
        (grid.lateral_mesh_nm + 0.5 * bottom_width) / bottom_width,
        0.0,
        1.0,
    )
    x_edges = np.linspace(0.0, 1.0, bins + 1)
    bottom_total = float(np.sum(phase.bottom_inventory_native))
    bottom_inventory_fraction: list[float] = []
    bottom_mean_thickness: list[float] = []
    bottom_coverage: list[float] = []
    for index in range(bins):
        mask = (
            (x_fraction >= x_edges[index])
            & (x_fraction < x_edges[index + 1] + (1.0e-12 if index == bins - 1 else 0.0))
            & (phase.bottom_contact_length_nm > 0.0)
        )
        length = float(np.sum(phase.bottom_contact_length_nm[mask]))
        inventory = float(np.sum(phase.bottom_inventory_native[mask]))
        bottom_inventory_fraction.append(inventory / bottom_total if bottom_total else 0.0)
        if length:
            bottom_mean_thickness.append(
                inventory / (phase.parameters.deposit_molar_density_mol_m3 * length)
            )
            bottom_coverage.append(
                float(
                    np.sum(
                        (
                            1.0
                            - np.exp(
                                -phase.bottom_thickness_nm[mask]
                                / phase.parameters.coverage_reference_thickness_nm
                            )
                        )
                        * phase.bottom_contact_length_nm[mask]
                    )
                    / length
                )
            )
        else:
            bottom_mean_thickness.append(0.0)
            bottom_coverage.append(0.0)
    centres = ((depth_edges[:-1] + depth_edges[1:]) * 0.5).tolist()
    x_centres = ((x_edges[:-1] + x_edges[1:]) * 0.5).tolist()
    return {
        "wall_depth_fraction": centres,
        "wall_inventory_fraction": wall_inventory_fraction,
        "wall_mean_thickness_nm": wall_mean_thickness,
        "wall_coverage_fraction": wall_coverage,
        "bottom_x_fraction": x_centres,
        "bottom_inventory_fraction": bottom_inventory_fraction,
        "bottom_mean_thickness_nm": bottom_mean_thickness,
        "bottom_coverage_fraction": bottom_coverage,
    }


def _matrix_stage(summary: Mapping[str, object]) -> dict[str, object]:
    regions = summary.get("region_metrics", {})
    return {
        "remaining_fraction": float(summary.get("remaining_fraction", 0.0)),
        "state_counts": dict(summary.get("state_counts", {})),
        "region_metrics": dict(regions) if isinstance(regions, Mapping) else {},
    }


def _residue_components(
    matrix_summary: Mapping[str, object],
    deposit_diagnostics: Mapping[str, object],
    *,
    material: str,
    deposit_species_name: str,
    initial_matrix_site_count: int,
    cell_area_nm2: float,
) -> dict[str, object]:
    """Report native film and post-HF deposit on one discrete-area basis."""

    state_counts = dict(matrix_summary.get("state_counts", {}))
    observed_site_count = sum(int(count) for count in state_counts.values())
    if observed_site_count != initial_matrix_site_count:
        raise ValueError(
            "matrix state-count total changed from the initial discrete site count"
        )
    remaining_site_count = observed_site_count - int(state_counts.get("removed", 0))
    initial_area_nm2 = initial_matrix_site_count * cell_area_nm2
    if initial_area_nm2 <= 0.0:
        raise ValueError("discrete initial GAP-FILL area must be positive")

    original_area_nm2 = remaining_site_count * cell_area_nm2
    deposit_inventory = float(deposit_diagnostics["total_inventory_native"])
    deposit_area_nm2 = float(
        deposit_diagnostics["equivalent_cross_section_area_nm2"]
    )
    original_fraction = original_area_nm2 / initial_area_nm2
    deposit_fraction = deposit_area_nm2 / initial_area_nm2
    combined_area_nm2 = original_area_nm2 + deposit_area_nm2
    combined_fraction = original_fraction + deposit_fraction
    return {
        "normalization": {
            "basis": "discrete_initial_gap_fill_area",
            "initial_matrix_site_count": initial_matrix_site_count,
            "cell_area_nm2": cell_area_nm2,
            "discrete_initial_gap_fill_area_nm2": initial_area_nm2,
        },
        "original_gap_fill": {
            "origin": "initial_gap_fill",
            "material": material,
            "remaining_site_count": remaining_site_count,
            "equivalent_cross_section_area_nm2": original_area_nm2,
            "fraction_of_discrete_initial_gap_fill_area": original_fraction,
        },
        "post_hf_deposit": {
            "origin": "post_hf_precipitate",
            "species_name": deposit_species_name,
            "inventory_native": deposit_inventory,
            "equivalent_cross_section_area_nm2": deposit_area_nm2,
            "fraction_of_discrete_initial_gap_fill_area": deposit_fraction,
        },
        "combined": {
            "equivalent_cross_section_area_nm2": combined_area_nm2,
            "fraction_of_discrete_initial_gap_fill_area": combined_fraction,
        },
    }


def _deposit_parameters(
    preset_id: str,
    wall_weight: float,
    bottom_weight: float,
) -> tuple[DepositParameters, float, str]:
    preset = get_literature_preset(preset_id)
    yield_value, yield_basis = _deposit_yield(preset)
    analytical_hf = hf_speciation_298K_from_weight_percent(
        preset.transport_hf_weight_percent
    ).analytical_fluorine_mol_m3
    parameters = DepositParameters(
        species_name=(
            "AFS_like_(NH4)2SiF6"
            if preset.material == "SiN"
            else f"generic_{preset.material}_deposit"
        ),
        saturation_concentration_mol_m3=afs_solubility_from_hf_mol_m3(
            analytical_hf
        ),
        attachment_velocity_nm_s=0.0,
        wall_affinity=wall_weight,
        bottom_affinity=bottom_weight,
        deposit_molar_density_mol_m3=AFS_MOLAR_DENSITY_MOL_M3,
        precipitation_yield_mol_deposit_per_mol_product=yield_value,
        deposit_molar_mass_kg_mol=(
            AFS_MOLAR_MASS_KG_MOL if preset.material == "SiN" else None
        ),
        active_set_relative_tolerance=1.0e-3,
        maximum_active_set_iterations=8,
        subgrid_warning_thickness_over_cell=0.5,
    )
    return parameters, yield_value, yield_basis


def _case_id(job: _StratumJob, design: AttachmentCaseDesign) -> str:
    suffix = (
        f"__x{design.x_index:02d}__y{design.y_index:02d}"
        if design.x_index is not None and design.y_index is not None
        else f"__l{design.probe_level:02d}"
    )
    return (
        f"{design.case_group}__{design.probe_name}{suffix}__{job.geometry_id}__"
        f"{job.preset_id}__r{job.replicate_index}"
    )


def _run_post_case(
    job: _StratumJob,
    design: AttachmentCaseDesign,
    outcome: object,
    primary_summary: Mapping[str, object],
    generated_inventory: float,
    continuum_endpoint_inventory: float,
    second_wet_summary: Mapping[str, object],
    final_summary: Mapping[str, object],
) -> dict[str, object]:
    config = job.config
    parameters = dict(design.parameters)
    closure = post_hf_closure(
        generated_inventory,
        post_hf_to_dry_window_s=config.post_hf_to_dry_window_s,
        rinse_start_delay_s=config.rinse_start_delay_s,
        rinse_exchange_rate_s=float(parameters["rinse_exchange_rate_s"]),
        immediate_quench=bool(parameters["immediate_quench"]),
        dry_enabled=bool(parameters["dry_enabled"]),
        drying_rate_s=float(parameters["drying_rate_s"]),
        drying_duration_s=config.drying_duration_s,
        drydown_capture_fraction=config.drydown_capture_fraction,
    )
    wall_weight = (
        float(parameters["wall_pretreatment_multiplier"])
        * float(parameters["wall_material_selectivity"])
    )
    bottom_weight = float(parameters["bottom_material_selectivity"])
    deposit_parameters, yield_value, yield_basis = _deposit_parameters(
        job.preset_id, wall_weight, bottom_weight
    )
    phase = PersistentDepositPhase2D(outcome.layout.grid, deposit_parameters)
    zero_deposit = _deposit_stage(phase)
    captured = float(closure["captured_precursor_inventory_native"])
    formation = phase.precipitate_during_drydown(
        np.zeros(outcome.layout.grid.shape, dtype=float),
        outcome.layout.grid.cavity_mask,
        solute_retention_fraction=0.0,
        liquid_retention_fraction=0.0,
        additional_trapped_inventory_native=captured,
    )
    formation_payload = formation.to_dict()
    dry_stage_deposit = _deposit_stage(phase)
    dry_surface_profile = (
        _surface_profile(phase, config.surface_profile_bins)
        if design.case_group == "probe"
        else None
    )
    dry_diagnostics = dry_stage_deposit["deposit_diagnostics"]
    assert isinstance(dry_diagnostics, Mapping)
    attached = float(dry_diagnostics["total_inventory_native"])
    nondeposit_yield = max(0.0, captured - attached)

    dissolution_rate = (
        config.deposit_reference_dissolution_rate_s
        * config.second_wet_rate_multiplier
    )
    dissolution = phase.dissolve(
        config.second_wet_duration_s,
        wall_rate_s=dissolution_rate,
        bottom_rate_s=dissolution_rate,
    )
    second_stage_deposit = _deposit_stage(phase)
    second_diagnostics = second_stage_deposit["deposit_diagnostics"]
    assert isinstance(second_diagnostics, Mapping)
    second_after = float(second_diagnostics["total_inventory_native"])

    hf_balance = _balance(generated_inventory, {"model_soluble_pool": generated_inventory})
    rinse_balance = _balance(
        generated_inventory,
        {
            "removed_by_rinse": float(closure["rinse_removed_inventory_native"]),
            "soluble_residual": float(closure["soluble_residual_inventory_native"]),
        },
    )
    dry_balance = _balance(
        float(closure["soluble_residual_inventory_native"]),
        {
            "attached_deposit": attached,
            "captured_but_not_deposited_by_yield": nondeposit_yield,
            "uncaptured_soluble": float(closure["uncaptured_soluble_inventory_native"]),
        },
    )
    second_balance = _balance(
        attached,
        {
            "deposit_removed_by_second_wet": float(dissolution.removed_inventory_native),
            "deposit_after_second_wet": second_after,
        },
    )
    dry_surface = dry_stage_deposit["surface_normalized"]
    second_surface = second_stage_deposit["surface_normalized"]
    assert isinstance(dry_surface, Mapping) and isinstance(second_surface, Mapping)
    zero_diagnostics = zero_deposit["deposit_diagnostics"]
    assert isinstance(zero_diagnostics, Mapping)
    initial_matrix_site_count = int(primary_summary["matrix_site_count"])
    cell_area_nm2 = float(outcome.layout.grid.cell_area_nm2)
    material = get_literature_preset(job.preset_id).material
    component_common = {
        "material": material,
        "deposit_species_name": deposit_parameters.species_name,
        "initial_matrix_site_count": initial_matrix_site_count,
        "cell_area_nm2": cell_area_nm2,
    }
    primary_zero_components = _residue_components(
        primary_summary,
        zero_diagnostics,
        **component_common,
    )
    dry_components = _residue_components(
        primary_summary,
        dry_diagnostics,
        **component_common,
    )
    second_components = _residue_components(
        final_summary,
        second_diagnostics,
        **component_common,
    )
    initial_area = outcome.layout.grid.geometry.area_nm2
    wall_density_native = float(
        dry_diagnostics.get("wall_inventory_density_native_per_nm2", 0.0)
    )
    bottom_density_native = float(
        dry_diagnostics.get("bottom_inventory_density_native_per_nm2", 0.0)
    )
    density_sum = wall_density_native + bottom_density_native
    wall_bottom_density_contrast = (
        (wall_density_native - bottom_density_native) / density_sum
        if density_sum > 0.0
        else 0.0
    )
    metrics = {
        "hf_matrix_remaining_fraction": float(primary_summary["remaining_fraction"]),
        "second_wet_matrix_remaining_fraction": float(final_summary["remaining_fraction"]),
        "drydown_total_deposit_inventory_native": attached,
        "final_total_deposit_inventory_native": second_after,
        "drydown_total_deposit_mol_per_nm_span": (
            attached * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN
        ),
        "total_deposit_equivalent_area_nm2": float(
            dry_diagnostics["equivalent_cross_section_area_nm2"]
        ),
        "deposit_fraction_of_initial_gap_fill_area": (
            float(dry_diagnostics["equivalent_cross_section_area_nm2"]) / initial_area
        ),
        "wall_deposit_fraction": float(dry_diagnostics["wall_fraction_of_deposit"]),
        "bottom_deposit_fraction": float(dry_diagnostics["bottom_fraction_of_deposit"]),
        "wall_deposit_density_native_per_nm": float(
            dry_surface["wall_inventory_native_per_nm"]
        ),
        "bottom_deposit_density_native_per_nm": float(
            dry_surface["bottom_inventory_native_per_nm"]
        ),
        "wall_areal_density_mol_m2": float(dry_surface["wall_areal_density_mol_m2"]),
        "bottom_areal_density_mol_m2": float(dry_surface["bottom_areal_density_mol_m2"]),
        "wall_mean_thickness_nm": float(dry_diagnostics["mean_wall_thickness_nm"]),
        "wall_maximum_thickness_nm": float(dry_diagnostics["maximum_wall_thickness_nm"]),
        "bottom_mean_thickness_nm": float(dry_diagnostics["mean_bottom_thickness_nm"]),
        "bottom_maximum_thickness_nm": float(dry_diagnostics["maximum_bottom_thickness_nm"]),
        "wall_coverage_fraction": float(
            dry_diagnostics.get("wall_continuous_coverage_fraction", 0.0)
        ),
        "bottom_coverage_fraction": float(
            dry_diagnostics.get("bottom_continuous_coverage_fraction", 0.0)
        ),
        "wall_grid_cell_equivalent_coverage_fraction": float(
            dry_surface["wall_grid_cell_equivalent_coverage_fraction"]
        ),
        "bottom_grid_cell_equivalent_coverage_fraction": float(
            dry_surface["bottom_grid_cell_equivalent_coverage_fraction"]
        ),
        "wall_geometric_coverage_fraction": float(
            dry_diagnostics.get("wall_geometric_coverage_fraction", 0.0)
        ),
        "bottom_geometric_coverage_fraction": float(
            dry_diagnostics.get("bottom_geometric_coverage_fraction", 0.0)
        ),
        "wall_continuous_coverage_fraction": float(
            dry_diagnostics.get("wall_continuous_coverage_fraction", 0.0)
        ),
        "bottom_continuous_coverage_fraction": float(
            dry_diagnostics.get("bottom_continuous_coverage_fraction", 0.0)
        ),
        "total_continuous_coverage_fraction": float(
            dry_diagnostics.get("total_continuous_coverage_fraction", 0.0)
        ),
        "total_mean_thickness_nm": float(
            dry_diagnostics.get("total_mean_thickness_nm", 0.0)
        ),
        "total_mass_kg_per_nm_span": dry_diagnostics.get(
            "total_mass_kg_per_nm_span"
        ),
        "second_wet_removed_deposit_fraction": (
            float(dissolution.removed_inventory_native) / attached if attached else 0.0
        ),
        "wall_inventory_density_native_per_nm2": wall_density_native,
        "bottom_inventory_density_native_per_nm2": bottom_density_native,
        "wall_excess_density_native_per_nm2": (
            wall_density_native - bottom_density_native
        ),
        # Geometry-independent allocation readout.  Unlike wall inventory
        # share, this is not biased by the much larger sidewall area of a
        # high-aspect-ratio trench; unlike absolute density excess, it is
        # invariant to the captured total.
        "wall_bottom_density_contrast": wall_bottom_density_contrast,
        "second_wet_wall_coverage_fraction": float(
            second_diagnostics.get("wall_continuous_coverage_fraction", 0.0)
        ),
        "second_wet_bottom_coverage_fraction": float(
            second_diagnostics.get("bottom_continuous_coverage_fraction", 0.0)
        ),
    }
    stages = {
        "hf_endpoint": {
            "matrix": _matrix_stage(primary_summary),
            "modeled_rinseable_product_pool_inventory_native": generated_inventory,
            "continuum_snapshot_product_inventory_native": continuum_endpoint_inventory,
            **zero_deposit,
            "residue_components": primary_zero_components,
            "mass_balance": hf_balance,
        },
        "rinse_endpoint": {
            "matrix": _matrix_stage(primary_summary),
            "modeled_rinseable_product_pool_inventory_native": float(
                closure["soluble_residual_inventory_native"]
            ),
            **zero_deposit,
            "residue_components": primary_zero_components,
            "mass_balance": rinse_balance,
        },
        "drydown_endpoint": {
            "matrix": _matrix_stage(primary_summary),
            "modeled_rinseable_product_pool_inventory_native": float(
                closure["uncaptured_soluble_inventory_native"]
            ),
            **dry_stage_deposit,
            "residue_components": dry_components,
            "formation": formation_payload,
            "mass_balance": dry_balance,
        },
        "second_wet_endpoint": {
            "matrix": _matrix_stage(final_summary),
            "matrix_transition": dict(second_wet_summary),
            "modeled_rinseable_product_pool_inventory_native": 0.0,
            **second_stage_deposit,
            "residue_components": second_components,
            "dissolution": dissolution.to_dict(),
            "mass_balance": second_balance,
        },
    }
    return {
        "case_id": _case_id(job, design),
        "local_order": design.local_order,
        "case_group": design.case_group,
        "probe_name": design.probe_name,
        "probe_level": design.probe_level,
        "pair_id": design.pair_id,
        "x_index": design.x_index,
        "y_index": design.y_index,
        "geometry_id": job.geometry_id,
        "preset_id": job.preset_id,
        "material": material,
        "replicate_index": job.replicate_index,
        "seed": job.seed,
        "status": "ok",
        "parameters": {
            **parameters,
            "rinse_start_delay_s": config.rinse_start_delay_s,
            "post_hf_to_dry_window_s": config.post_hf_to_dry_window_s,
            "drying_duration_s": config.drying_duration_s,
            "drydown_capture_fraction": config.drydown_capture_fraction,
            "wall_effective_weight": wall_weight,
            "bottom_effective_weight": bottom_weight,
        },
        "derived_conditions": {
            **closure,
            "precipitation_yield": yield_value,
            "yield_basis": yield_basis,
            "deposit_model_parameters": deposit_parameters.to_dict(),
            "allocation_invariant": (
                "affinity weights allocate captured precursor only; captured "
                "total is computed before phase construction"
            ),
            "collector_basis": (
                "all physical wall/floor collectors; meniscus-migration "
                "upper bound independent of primary endpoint accessibility"
            ),
            "effective_wall_to_bottom_affinity_ratio": (
                wall_weight / bottom_weight
            ),
            "structural_nonidentifiability": (
                "This closure observes only wall_pretreatment_multiplier * "
                "wall_material_selectivity / bottom_material_selectivity. "
                "Pretreatment and wall-material factors need independently "
                "labelled experiments for separate inference."
            ),
        },
        "stages": stages,
        "metrics": metrics,
        "surface_profiles": (
            {
                "drydown_endpoint": dry_surface_profile,
                "second_wet_endpoint": _surface_profile(
                    phase, config.surface_profile_bins
                ),
            }
            if design.case_group == "probe"
            else {}
        ),
        "convergence": {
            "all_stage_mass_balances_closed": all(
                bool(item["mass_balance"]["closed"]) for item in stages.values()
            ),
            "primary_hf_all_converged": all(
                bool(item["hf_converged"]) for item in outcome.sync_history
            ),
            "primary_product_all_converged": all(
                bool(item["product_converged"]) for item in outcome.sync_history
            ),
            "primary_stop_reason": outcome.stop_reason,
        },
    }


def _run_stratum(job: _StratumJob) -> dict[str, object]:
    try:
        primary_spec = ProcessCaseSpec(
            order=job.stratum_order,
            case_group="attachment_primary",
            design_index=job.stratum_order,
            geometry_id=job.geometry_id,
            preset_id=job.preset_id,
            replicate_index=job.replicate_index,
            seed=job.seed,
            parameters=_primary_parameters(),
        )
        grid, graph_config, coupling, kinetics, spatial, derived = _case_objects(
            primary_spec, job.config.process_window_config()
        )
        outcome = run_coupled_trench_kmc(
            grid,
            graph_config=graph_config,
            coupling_parameters=coupling,
            kmc_parameters=kinetics,
            spatial_etchability_parameters=spatial,
            seed=job.seed,
        )
        primary_summary = outcome.summary()
        removed_count = int(primary_summary["state_counts"].get("removed", 0))
        preset = get_literature_preset(job.preset_id)
        generated_inventory = (
            removed_count
            * grid.cell_area_nm2
            * preset.solid_si_site_density_mol_m3
        )
        endpoint_inventory = float(
            np.sum(
                outcome.final_frame.product_field[
                    outcome.final_frame.liquid_mask & grid.cavity_mask
                ]
            )
            * grid.cell_area_nm2
        )
        second = run_second_wet_stage(
            outcome,
            parameters=SecondWetKMCParameters(
                duration_s=job.config.second_wet_duration_s,
                common_rate_multiplier=job.config.second_wet_rate_multiplier,
                matrix_removal_rate_s=float(derived["nominal_site_rate_s"]),
                deposit_dissolution_rate_s=0.0,
            ),
            seed=job.seed + 1_000_003,
        )
        second_summary = second.summary()
        final_summary = trench_residue_metrics(second.graph, outcome.layout)
        cases = [
            _run_post_case(
                job,
                design,
                outcome,
                primary_summary,
                generated_inventory,
                endpoint_inventory,
                second_summary,
                final_summary,
            )
            for design in job.designs
        ]
        return {
            "stratum_order": job.stratum_order,
            "status": "ok",
            "primary_run_count": 1,
            "second_wet_matrix_run_count": 1,
            "cases": cases,
        }
    except Exception as exc:
        failed_cases = [
            {
                "case_id": _case_id(job, design),
                "local_order": design.local_order,
                "case_group": design.case_group,
                "probe_name": design.probe_name,
                "probe_level": design.probe_level,
                "pair_id": design.pair_id,
                "x_index": design.x_index,
                "y_index": design.y_index,
                "geometry_id": job.geometry_id,
                "preset_id": job.preset_id,
                "material": get_literature_preset(job.preset_id).material,
                "replicate_index": job.replicate_index,
                "seed": job.seed,
                "status": "failed",
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            }
            for design in job.designs
        ]
        return {
            "stratum_order": job.stratum_order,
            "status": "failed",
            "primary_run_count": 1,
            "second_wet_matrix_run_count": 0,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "cases": failed_cases,
        }


def _worker_initializer() -> None:
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = "1"
    try:
        from threadpoolctl import threadpool_limits

        threadpool_limits(1)
    except ImportError:
        pass


def _execute_strata(
    jobs: Sequence[_StratumJob], workers: int
) -> list[dict[str, object]]:
    if workers == 1:
        return [_run_stratum(job) for job in jobs]
    with ProcessPoolExecutor(
        max_workers=min(workers, len(jobs)), initializer=_worker_initializer
    ) as executor:
        return list(executor.map(_run_stratum, jobs, chunksize=1))


_CONTRAST_METRICS = (
    "drydown_total_deposit_inventory_native",
    "final_total_deposit_inventory_native",
    "wall_deposit_fraction",
    "bottom_deposit_fraction",
    "wall_areal_density_mol_m2",
    "bottom_areal_density_mol_m2",
    "wall_inventory_density_native_per_nm2",
    "bottom_inventory_density_native_per_nm2",
    "wall_excess_density_native_per_nm2",
    "wall_bottom_density_contrast",
    "wall_mean_thickness_nm",
    "bottom_mean_thickness_nm",
    "wall_coverage_fraction",
    "bottom_coverage_fraction",
)


def _contrast_payload(
    cases: Sequence[Mapping[str, object]],
    config: AttachmentDiscriminationConfig,
) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for geometry_id in config.geometries:
        for preset_id in config.presets:
            for probe in config.probes:
                levels: list[dict[str, object]] = []
                for level, value in enumerate(probe.values):
                    subset = [
                        case
                        for case in cases
                        if case.get("status") == "ok"
                        and case.get("case_group") == "probe"
                        and case.get("geometry_id") == geometry_id
                        and case.get("preset_id") == preset_id
                        and case.get("probe_name") == probe.name
                        and int(case.get("probe_level", -1)) == level
                    ]
                    medians: dict[str, float | None] = {}
                    for metric in _CONTRAST_METRICS:
                        values = [
                            float(case["metrics"][metric])
                            for case in subset
                            if isinstance(case.get("metrics"), Mapping)
                        ]
                        medians[metric] = float(np.median(values)) if values else None
                    levels.append(
                        {
                            "level": level,
                            "value": value,
                            "successful_case_count": len(subset),
                            "metric_medians": medians,
                            "case_ids": [str(case["case_id"]) for case in subset],
                        }
                    )
                total_values = [
                    float(value)
                    for item in levels
                    for value in [item["metric_medians"]["drydown_total_deposit_inventory_native"]]
                    if value is not None
                ]
                allocation_contrasts = [
                    float(value)
                    for item in levels
                    for value in [
                        item["metric_medians"]["wall_bottom_density_contrast"]
                    ]
                    if value is not None
                    and item["metric_medians"]["drydown_total_deposit_inventory_native"]
                    is not None
                    and float(
                        item["metric_medians"]["drydown_total_deposit_inventory_native"]
                    )
                    > 0.0
                ]
                total_scale = max(max(total_values, default=0.0), 1.0e-300)
                total_span = (
                    (max(total_values) - min(total_values)) / total_scale
                    if total_values
                    else 0.0
                )
                allocation_span = (
                    max(allocation_contrasts) - min(allocation_contrasts)
                    if allocation_contrasts
                    else 0.0
                )
                complete = all(
                    int(item["successful_case_count"]) > 0 for item in levels
                )
                if not complete:
                    interpretation = "insufficient_data"
                elif total_span > 0.05 and allocation_span <= 0.05:
                    interpretation = "capture_amount_dominated"
                elif total_span <= 0.05 and allocation_span > 0.05:
                    interpretation = "surface_allocation_dominated"
                elif total_span > 0.05 and allocation_span > 0.05:
                    interpretation = "mixed_response"
                else:
                    interpretation = "weak_response"
                result.append(
                    {
                        "geometry_id": geometry_id,
                        "preset_id": preset_id,
                        "material": get_literature_preset(preset_id).material,
                        "probe_name": probe.name,
                        "probe_label_ja": probe.label_ja,
                        "parameter": probe.parameter,
                        "unit": probe.unit,
                        "levels": levels,
                        "relative_total_inventory_span": total_span,
                        "wall_allocation_span": allocation_span,
                        "wall_allocation_metric": (
                            "(wall_density-bottom_density)/"
                            "(wall_density+bottom_density)"
                        ),
                        "complete": complete,
                        "interpretation": interpretation,
                    }
                )
    return result


def _phase_map_payload(
    metadata: Sequence[Mapping[str, object]],
    cases: Sequence[Mapping[str, object]],
    config: AttachmentDiscriminationConfig,
) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for item in metadata:
        pair_id = str(item["pair_id"])
        nx = len(item["x_values"])
        ny = len(item["y_values"])
        strata: list[dict[str, object]] = []
        for geometry_id in config.geometries:
            for preset_id in config.presets:
                metric_grids: dict[str, list[list[float | None]]] = {
                    metric: [[None for _ in range(nx)] for _ in range(ny)]
                    for metric in _CONTRAST_METRICS
                }
                case_ids = [[[] for _ in range(nx)] for _ in range(ny)]
                successful_counts = [[0 for _ in range(nx)] for _ in range(ny)]
                for y_index in range(ny):
                    for x_index in range(nx):
                        subset = [
                            case
                            for case in cases
                            if case.get("status") == "ok"
                            and case.get("pair_id") == pair_id
                            and case.get("geometry_id") == geometry_id
                            and case.get("preset_id") == preset_id
                            and int(case.get("x_index", -1)) == x_index
                            and int(case.get("y_index", -1)) == y_index
                        ]
                        successful_counts[y_index][x_index] = len(subset)
                        case_ids[y_index][x_index] = [str(case["case_id"]) for case in subset]
                        for metric in _CONTRAST_METRICS:
                            values = [float(case["metrics"][metric]) for case in subset]
                            if values:
                                metric_grids[metric][y_index][x_index] = float(np.median(values))
                strata.append(
                    {
                        "geometry_id": geometry_id,
                        "preset_id": preset_id,
                        "material": get_literature_preset(preset_id).material,
                        "successful_case_counts": successful_counts,
                        "metric_grids": metric_grids,
                        "case_ids": case_ids,
                    }
                )
        result.append({**dict(item), "strata": strata})
    return result


def run_attachment_discrimination(
    config: AttachmentDiscriminationConfig = AttachmentDiscriminationConfig(),
) -> dict[str, object]:
    """Run one primary HF simulation per stratum and all post-HF probes."""

    designs, phase_metadata = build_attachment_design(config)
    jobs: list[_StratumJob] = []
    for geometry_id in config.geometries:
        for preset_index, preset_id in enumerate(config.presets):
            for replicate_index, base_seed in enumerate(config.replicate_seeds):
                jobs.append(
                    _StratumJob(
                        stratum_order=len(jobs),
                        geometry_id=geometry_id,
                        preset_id=preset_id,
                        replicate_index=replicate_index,
                        seed=int(base_seed) + 100_003 * preset_index,
                        config=config,
                        designs=designs,
                    )
                )
    stratum_results = _execute_strata(jobs, config.parallel_workers)
    stratum_results.sort(key=lambda item: int(item["stratum_order"]))
    cases: list[dict[str, object]] = []
    for stratum in stratum_results:
        stratum_cases = list(stratum["cases"])
        stratum_cases.sort(key=lambda item: int(item["local_order"]))
        cases.extend(stratum_cases)
    for order, case in enumerate(cases):
        case["order"] = order

    failed = [case for case in cases if case.get("status") != "ok"]
    successful = [case for case in cases if case.get("status") == "ok"]
    return {
        "schema_version": SCHEMA_VERSION,
        "model_name": "stage-resolved dry-down / wall-affinity discrimination",
        "notice": MODEL_NOTICE,
        "config": config.to_dict(),
        "probe_definitions": [probe.to_dict() for probe in config.probes],
        "primary_reuse": {
            "requested_stratum_count": len(jobs),
            "primary_run_count": len(stratum_results),
            "second_wet_matrix_run_count": sum(
                int(item.get("second_wet_matrix_run_count", 0))
                for item in stratum_results
            ),
            "post_hf_case_count": len(cases),
            "strategy": (
                "one primary continuum/graph-KMC run per geometry/preset/seed; "
                "one shared second-WET matrix continuation per stratum; fresh "
                "persistent-deposit phase for every post-HF case"
            ),
        },
        "cases": cases,
        "contrasts": _contrast_payload(cases, config),
        "phase_maps": _phase_map_payload(
            phase_metadata, cases, config
        ) if config.include_phase_maps else [],
        "parallel_execution": {
            "backend": "ProcessPoolExecutor",
            "workers": config.parallel_workers,
            "case_order_preserved": True,
            "worker_numeric_thread_limit_requested": 1,
        },
        "quality_summary": {
            "requested_primary_strata": len(jobs),
            "successful_primary_strata": sum(
                item.get("status") == "ok" for item in stratum_results
            ),
            "requested_second_wet_matrix_strata": len(jobs),
            "successful_second_wet_matrix_strata": sum(
                int(item.get("second_wet_matrix_run_count", 0))
                for item in stratum_results
            ),
            "requested_post_hf_cases": len(cases),
            "successful_post_hf_cases": len(successful),
            "failed_case_count": len(failed),
            "failed_case_ids": [str(case["case_id"]) for case in failed],
            "mass_balance_failure_count": sum(
                not bool(case["convergence"]["all_stage_mass_balances_closed"])
                for case in successful
            ),
            "primary_hf_nonconverged_case_count": sum(
                not bool(case["convergence"]["primary_hf_all_converged"])
                for case in successful
            ),
            "primary_product_nonconverged_case_count": sum(
                not bool(case["convergence"]["primary_product_all_converged"])
                for case in successful
            ),
        },
        "model_limitations": {
            "status": "screening hypotheses; coefficients are not recipe limits",
            "primary_hf": (
                "Reference primary conditions are held fixed because all requested "
                "probes occur after HF endpoint."
            ),
            "rinse": (
                "Well-mixed first-order exchange: soluble residual = generated * "
                "exp(-exchange_rate * max(window-delay, 0))."
            ),
            "composite_dose_identifiability": (
                "Rinse endpoints identify the exchange number (rate times effective "
                "flow duration), while deposit amount identifies the composite "
                "rinse_retention * capture_fraction * dry_extent. Rate, duration "
                "and capture fraction require independently varied experiments for "
                "separate inference."
            ),
            "post_hf_mass_balance_basis": (
                "The stage closure starts from a cumulative-generated, modeled "
                "rinseable product pool. The quasi-steady continuum endpoint "
                "inventory is retained separately as a diagnostic and is not a "
                "global transient product balance."
            ),
            "drying": (
                "First-order dry extent; no evaporation hydrodynamics or local "
                "contact-line residence-time distribution."
            ),
            "allocation": (
                "Pretreatment and material selectivity are multiplicative surface "
                "weights and affect allocation only, never captured total."
            ),
            "allocation_identifiability": (
                "The modeled allocation identifies only the ratio "
                "wall_pretreatment_multiplier * wall_material_selectivity / "
                "bottom_material_selectivity. Equal-factor pretreatment and wall-"
                "material OAT probes are mathematically identical; independently "
                "labelled material/preparation experiments are required to infer "
                "the three factors separately."
            ),
            "collector_accessibility": (
                "For orthogonal wall/bottom allocation tests, dry-down inventory "
                "is distributed over all physical wall/floor collectors. This is "
                "a meniscus-migration upper bound: it can place deposit on a "
                "collector still screened by residual GAP FILL at the primary-HF "
                "endpoint. Interpret it together with the reported matrix-"
                "remaining fraction; an endpoint-liquid-accessible branch is a "
                "future lower-bound comparison."
            ),
            "deposit_identity": (
                "SiN uses an AFS-like proxy; SiOCN persistent species is unverified."
            ),
            "coverage": (
                "Primary coverage outputs use the core Poisson proxy "
                "1-exp(-thickness/coverage_reference_thickness); explicitly named "
                "grid-cell-equivalent fields retain the thickness/grid-spacing "
                "clip. Neither is an atomically resolved island percolation model."
            ),
        },
        "artifacts": {},
    }


def save_attachment_discrimination_json(
    payload: Mapping[str, object], path: str | Path
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return target


_CSV_PARAMETER_FIELDS = (
    "dry_enabled",
    "drying_rate_s",
    "immediate_quench",
    "rinse_exchange_rate_s",
    "wall_pretreatment_multiplier",
    "wall_material_selectivity",
    "bottom_material_selectivity",
    "wall_effective_weight",
    "bottom_effective_weight",
)


def save_attachment_discrimination_csv(
    payload: Mapping[str, object], path: str | Path
) -> Path:
    """Write one flat row per post-HF case with stage-resolved core metrics."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    cases = payload.get("cases", [])
    rows = [case for case in cases if isinstance(case, Mapping)] if isinstance(
        cases, Sequence
    ) and not isinstance(cases, (str, bytes)) else []
    metric_fields = list(_CONTRAST_METRICS) + [
        "hf_matrix_remaining_fraction",
        "second_wet_matrix_remaining_fraction",
        "total_deposit_equivalent_area_nm2",
        "deposit_fraction_of_initial_gap_fill_area",
        "wall_deposit_density_native_per_nm",
        "bottom_deposit_density_native_per_nm",
        "second_wet_removed_deposit_fraction",
        "wall_maximum_thickness_nm",
        "bottom_maximum_thickness_nm",
        "total_mean_thickness_nm",
        "total_mass_kg_per_nm_span",
        "drydown_total_deposit_mol_per_nm_span",
        "wall_continuous_coverage_fraction",
        "bottom_continuous_coverage_fraction",
        "total_continuous_coverage_fraction",
    ]
    fieldnames = [
        "order",
        "case_id",
        "status",
        "case_group",
        "probe_name",
        "probe_level",
        "pair_id",
        "x_index",
        "y_index",
        "geometry_id",
        "preset_id",
        "material",
        "replicate_index",
        "seed",
        *_CSV_PARAMETER_FIELDS,
        "effective_rinse_start_delay_s",
        "effective_rinse_flow_duration_s",
        "rinse_retention_fraction",
        "drying_time_constant_s",
        "dry_extent",
        "captured_precursor_inventory_native",
        "rinse_exchange_number",
        "effective_capture_fraction_of_generated",
        *metric_fields,
        "all_stage_mass_balances_closed",
        "error_type",
        "error_message",
    ]
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for case in rows:
            row = {key: case.get(key, "") for key in fieldnames}
            parameters = case.get("parameters", {})
            if isinstance(parameters, Mapping):
                for key in _CSV_PARAMETER_FIELDS:
                    row[key] = parameters.get(key, "")
            derived = case.get("derived_conditions", {})
            if isinstance(derived, Mapping):
                for key in (
                    "effective_rinse_start_delay_s",
                    "effective_rinse_flow_duration_s",
                    "rinse_retention_fraction",
                    "drying_time_constant_s",
                    "dry_extent",
                    "captured_precursor_inventory_native",
                    "rinse_exchange_number",
                    "effective_capture_fraction_of_generated",
                ):
                    row[key] = derived.get(key, "")
            metrics = case.get("metrics", {})
            if isinstance(metrics, Mapping):
                for key in metric_fields:
                    row[key] = metrics.get(key, "")
            convergence = case.get("convergence", {})
            if isinstance(convergence, Mapping):
                row["all_stage_mass_balances_closed"] = convergence.get(
                    "all_stage_mass_balances_closed", ""
                )
            writer.writerow(row)
    return target


def save_attachment_contrast_csv(
    payload: Mapping[str, object], path: str | Path
) -> Path:
    """Write the compact experiment-facing probe interpretation table."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = payload.get("contrasts", [])
    contrasts = [item for item in raw if isinstance(item, Mapping)] if isinstance(
        raw, Sequence
    ) and not isinstance(raw, (str, bytes)) else []
    fieldnames = [
        "geometry_id",
        "preset_id",
        "material",
        "probe_name",
        "probe_label_ja",
        "parameter",
        "unit",
        "low_value",
        "high_value",
        "low_total_deposit_inventory_native",
        "high_total_deposit_inventory_native",
        "low_wall_bottom_density_contrast",
        "high_wall_bottom_density_contrast",
        "relative_total_inventory_span",
        "wall_allocation_span",
        "wall_allocation_metric",
        "complete",
        "interpretation",
    ]
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for contrast in contrasts:
            levels = contrast.get("levels", [])
            level_rows = [item for item in levels if isinstance(item, Mapping)] if isinstance(
                levels, Sequence
            ) and not isinstance(levels, (str, bytes)) else []
            low = level_rows[0] if level_rows else {}
            high = level_rows[-1] if level_rows else {}
            low_metrics = low.get("metric_medians", {})
            high_metrics = high.get("metric_medians", {})
            low_metrics = low_metrics if isinstance(low_metrics, Mapping) else {}
            high_metrics = high_metrics if isinstance(high_metrics, Mapping) else {}
            writer.writerow(
                {
                    "geometry_id": contrast.get("geometry_id", ""),
                    "preset_id": contrast.get("preset_id", ""),
                    "material": contrast.get("material", ""),
                    "probe_name": contrast.get("probe_name", ""),
                    "probe_label_ja": contrast.get("probe_label_ja", ""),
                    "parameter": contrast.get("parameter", ""),
                    "unit": contrast.get("unit", ""),
                    "low_value": low.get("value", ""),
                    "high_value": high.get("value", ""),
                    "low_total_deposit_inventory_native": low_metrics.get(
                        "drydown_total_deposit_inventory_native", ""
                    ),
                    "high_total_deposit_inventory_native": high_metrics.get(
                        "drydown_total_deposit_inventory_native", ""
                    ),
                    "low_wall_bottom_density_contrast": low_metrics.get(
                        "wall_bottom_density_contrast", ""
                    ),
                    "high_wall_bottom_density_contrast": high_metrics.get(
                        "wall_bottom_density_contrast", ""
                    ),
                    "relative_total_inventory_span": contrast.get(
                        "relative_total_inventory_span", ""
                    ),
                    "wall_allocation_span": contrast.get(
                        "wall_allocation_span", ""
                    ),
                    "wall_allocation_metric": contrast.get(
                        "wall_allocation_metric", ""
                    ),
                    "complete": contrast.get("complete", ""),
                    "interpretation": contrast.get("interpretation", ""),
                }
            )
    return target


__all__ = [
    "AttachmentDiscriminationConfig",
    "AttachmentProbe",
    "DEFAULT_PHASE_PAIRS",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "build_attachment_design",
    "default_attachment_probes",
    "post_hf_closure",
    "run_attachment_discrimination",
    "save_attachment_contrast_csv",
    "save_attachment_discrimination_csv",
    "save_attachment_discrimination_json",
]

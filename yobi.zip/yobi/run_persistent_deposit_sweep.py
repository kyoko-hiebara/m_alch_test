#!/usr/bin/env python3
"""CLI for persistent precipitation and wall/floor-attachment sensitivities."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

from literature_parameters import LITERATURE_ETCH_PRESETS
from literature_sweep import nominal_preset_names
from persistent_deposit_sweep import (
    PersistentDepositSweepConfig,
    plot_representative_deposit_maps,
    run_persistent_deposit_sweep,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run 2-D wet-precipitation, dry-down attachment and post-WET "
            "sensitivity cases. Deposit kinetics are not calibrated."
        )
    )
    parser.add_argument("--geometry", choices=tuple(GEOMETRY_PRESETS), action="append")
    parser.add_argument("--preset", choices=tuple(LITERATURE_ETCH_PRESETS), action="append")
    parser.add_argument("--grid-spacing-nm", type=float, default=1.0)
    parser.add_argument("--reservoir-height-nm", type=float, default=10.0)
    parser.add_argument("--product-diffusivity-over-hf", type=float, default=0.1)
    parser.add_argument("--maximum-fractional-front-change", type=float, default=0.50)
    parser.add_argument("--target-remaining", type=float, default=1.0e-3)
    parser.add_argument("--maximum-clear-time", type=float, default=1.20)
    parser.add_argument("--steps-per-clear", type=int, default=50)
    parser.add_argument("--wet-attachment-da", type=float, default=10.0)
    parser.add_argument("--capture-fraction", type=float, action="append")
    parser.add_argument("--wall-affinity-ratio", type=float, default=5.0)
    parser.add_argument(
        "--solution-temperature-k",
        type=float,
        default=298.15,
        help="independent solution boundary metadata; no kinetic correction yet",
    )
    parser.add_argument(
        "--substrate-temperature-k",
        type=float,
        default=298.15,
        help="independent substrate boundary metadata; no kinetic correction yet",
    )
    parser.add_argument(
        "--allow-partial-primary",
        action="store_true",
        help="permit dry-down sensitivity before the GAP FILL target is reached",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent primary-HF case processes; 0 selects up to 4",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("persistent_deposit_sweep_results.json"),
    )
    parser.add_argument(
        "--figure",
        type=Path,
        default=Path("persistent_deposit_maps.png"),
    )
    parser.add_argument("--no-figure", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    geometries = tuple(dict.fromkeys(args.geometry or DEFAULT_GEOMETRY_NAMES))
    presets = tuple(dict.fromkeys(args.preset or nominal_preset_names()))
    capture_fractions = tuple(
        dict.fromkeys(args.capture_fraction or (0.001, 0.01, 0.10))
    )
    case_count = len(geometries) * len(presets)
    if args.workers < 0:
        raise ValueError("workers must be zero or a positive integer")
    workers = (
        min(4, os.cpu_count() or 1, case_count)
        if args.workers == 0
        else min(args.workers, case_count)
    )
    payload = run_persistent_deposit_sweep(
        PersistentDepositSweepConfig(
            geometries=geometries,
            presets=presets,
            grid_spacing_nm=args.grid_spacing_nm,
            reservoir_height_nm=args.reservoir_height_nm,
            product_diffusivity_over_hf=args.product_diffusivity_over_hf,
            maximum_fractional_front_change=args.maximum_fractional_front_change,
            target_remaining_gap_fill_fraction=args.target_remaining,
            maximum_time_over_planar_clear=args.maximum_clear_time,
            requested_steps_per_planar_clear=args.steps_per_clear,
            wet_attachment_damkohler=args.wet_attachment_da,
            cumulative_capture_fractions=capture_fractions,
            wall_selective_affinity_ratio=args.wall_affinity_ratio,
            solution_bulk_temperature_K=args.solution_temperature_k,
            substrate_backside_temperature_K=args.substrate_temperature_k,
            allow_partial_primary_for_sensitivity=args.allow_partial_primary,
            parallel_workers=workers,
        )
    )
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text + "\n", encoding="utf-8")
    if not args.no_figure:
        args.figure.parent.mkdir(parents=True, exist_ok=True)
        plot_representative_deposit_maps(payload, str(args.figure))
    return payload


if __name__ == "__main__":
    main()

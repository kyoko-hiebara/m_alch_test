"""Multicore global sensitivity and phase-map study for GAP-FILL removal.

This coordinator joins the existing real-dimension continuum/graph-KMC,
spatial film-quality, persistent-deposit, and post-WET models.  The sampled
domains are deliberately broad *screening* domains.  They are not process
recipes and several post-HF coefficients remain uncalibrated hypotheses.

The expensive design is a scrambled Sobol sequence rather than a Cartesian
product.  A second pass evaluates only the most influential parameter pairs
on regular grids, which makes the resulting phase maps readable without
requiring 3**13 cases.
"""

from __future__ import annotations

import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np

from literature_parameters import (
    HF_DIFFUSIVITY_298_NM2_S,
    LITERATURE_ETCH_PRESETS,
    get_literature_preset,
    hf_speciation_298K_from_weight_percent,
)
from literature_sweep import nominal_preset_names
from persistent_deposit import DepositParameters, PersistentDepositPhase2D
from persistent_deposit_sweep import (
    AFS_MOLAR_DENSITY_MOL_M3,
    AFS_MOLAR_MASS_KG_MOL,
    _deposit_yield,
    afs_solubility_from_hf_mol_m3,
)
from reaction_diffusion_2d import CartesianGrid2D
from spatial_etchability import SpatialEtchabilityParameters
from trench_geometry import (
    DEFAULT_GEOMETRY_NAMES,
    GEOMETRY_PRESETS,
    get_geometry_preset,
)
from trench_graph_kmc import (
    REGION_NAMES,
    ContinuumCouplingParameters,
    SecondWetKMCParameters,
    TrenchGraphConfig,
    TrenchKMCOutcome,
    TrenchKMCParameters,
    run_coupled_trench_kmc,
    trench_residue_metrics,
)


SCHEMA_VERSION = "trench-kmc-global-sensitivity/v1"
CLASS_ORDER = (
    "complete_removal",
    "bottom_residue",
    "wall_residue",
    "precipitation_residue",
)
CLASS_LABELS_JA = {
    "complete_removal": "完全除去",
    "bottom_residue": "底残り",
    "wall_residue": "壁残り",
    "precipitation_residue": "析出残り",
}

PROCESS_WINDOW_NOTICE = (
    "Broad mechanism-screening calculation, not a calibrated wet-process "
    "recipe. Primary-HF transport uses 298 K HF speciation/diffusivity; the "
    "graph KMC uses local interface-temperature Arrhenius factors. The rinse-"
    "delay capture closure, wall affinity, SiOCN deposit identity and second-"
    "WET rates are uncalibrated hypotheses."
)

GRAPH_RATE_REFERENCE_PRESET_ID = "sin_barcellona_b_0p55wt"


def _positive(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


@dataclass(frozen=True)
class ProcessWindowConfig:
    """Execution controls for one global design plus targeted pair maps."""

    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    presets: tuple[str, ...] = nominal_preset_names()
    design_points: int = 128
    design_seed: int = 20260714
    parameter_bounds_set: str = "full"
    replicate_seeds: tuple[int, ...] = (271828,)
    grid_spacing_nm: float = 1.4
    reservoir_height_nm: float = 4.0
    lateral_margin_nm: float = 3.0
    primary_hf_duration_s: float = 300.0
    primary_sync_steps: int = 30
    maximum_events: int = 40_000
    # Site count grows as the mesh is refined; a fixed budget silently caps a
    # convergence study instead of letting it run.
    maximum_sites: int = 2_500
    second_wet_duration_s: float = 30.0
    deposit_reference_dissolution_rate_s: float = 0.025
    rinse_delay_capture_tau_s: float = 30.0
    sidewall_influence_length_nm: float = 2.0
    floor_influence_length_nm: float = 5.0
    minimum_material_rate_factor: float = 0.01
    phase_levels: int = 7
    maximum_phase_pairs: int = 4
    bootstrap_samples: int = 200
    parallel_workers: int = 1
    include_phase_maps: bool = True
    include_representatives: bool = True
    primary_macro_time_step_s: float | None = None
    primary_hf_target_remaining_fraction: float | None = None

    def __post_init__(self) -> None:
        if not self.geometries or set(self.geometries).difference(GEOMETRY_PRESETS):
            raise ValueError("geometries must be a non-empty known selection")
        if not self.presets or set(self.presets).difference(LITERATURE_ETCH_PRESETS):
            raise ValueError("presets must be a non-empty known selection")
        if self.design_points < 2 or self.design_points & (self.design_points - 1):
            raise ValueError("design_points must be a power of two >= 2")
        if self.design_seed < 0:
            raise ValueError("design_seed must be non-negative")
        if self.parameter_bounds_set not in {"quick", "full"}:
            raise ValueError("parameter_bounds_set must be 'quick' or 'full'")
        if not self.replicate_seeds or any(seed < 0 for seed in self.replicate_seeds):
            raise ValueError("replicate_seeds must contain non-negative integers")
        if len(set(self.replicate_seeds)) != len(self.replicate_seeds):
            raise ValueError("replicate_seeds cannot contain duplicates")
        for name in (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "primary_hf_duration_s",
            "second_wet_duration_s",
            "deposit_reference_dissolution_rate_s",
            "rinse_delay_capture_tau_s",
            "sidewall_influence_length_nm",
            "floor_influence_length_nm",
            "minimum_material_rate_factor",
        ):
            _positive(name, getattr(self, name))
        if not math.isfinite(self.lateral_margin_nm) or self.lateral_margin_nm < 0.0:
            raise ValueError("lateral_margin_nm must be finite and non-negative")
        if self.primary_macro_time_step_s is not None:
            _positive("primary_macro_time_step_s", self.primary_macro_time_step_s)
            object.__setattr__(
                self,
                "primary_macro_time_step_s",
                float(self.primary_macro_time_step_s),
            )
        if self.primary_hf_target_remaining_fraction is not None:
            target = float(self.primary_hf_target_remaining_fraction)
            if not math.isfinite(target) or not 0.0 <= target < 1.0:
                raise ValueError(
                    "primary_hf_target_remaining_fraction must be finite "
                    "and lie within [0, 1)"
                )
            object.__setattr__(
                self,
                "primary_hf_target_remaining_fraction",
                target,
            )
        if self.primary_sync_steps < 1 or self.maximum_events < 1:
            raise ValueError("primary_sync_steps and maximum_events must be positive")
        if self.phase_levels < 3 or self.maximum_phase_pairs < 0:
            raise ValueError("phase_levels >= 3 and maximum_phase_pairs >= 0 required")
        if self.bootstrap_samples < 0 or self.parallel_workers < 1:
            raise ValueError("bootstrap_samples >= 0 and parallel_workers >= 1 required")
        object.__setattr__(self, "geometries", tuple(self.geometries))
        object.__setattr__(self, "presets", tuple(self.presets))
        object.__setattr__(self, "replicate_seeds", tuple(self.replicate_seeds))

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for key in ("geometries", "presets", "replicate_seeds"):
            result[key] = list(result[key])
        return result


@dataclass(frozen=True)
class ProcessCaseSpec:
    order: int
    case_group: str
    design_index: int
    geometry_id: str
    preset_id: str
    replicate_index: int
    seed: int
    parameters: Mapping[str, float]
    design_role: str = "sobol"
    pair_id: str | None = None
    x_index: int | None = None
    y_index: int | None = None


@dataclass(frozen=True)
class _WorkerInput:
    spec: ProcessCaseSpec
    config: ProcessWindowConfig
    include_snapshot: bool = False


def _parameter_value(parameters: Mapping[str, float], *names: str) -> float:
    for name in names:
        if name in parameters:
            return float(parameters[name])
    raise KeyError(f"missing parameter; expected one of {names}")


def _spatial_parameters(parameters: Mapping[str, float], config: ProcessWindowConfig) -> SpatialEtchabilityParameters:
    return SpatialEtchabilityParameters(
        top_rate_factor=1.0,
        bottom_rate_factor=_parameter_value(
            parameters,
            "depth_bottom_rate_factor",
            "depth_rate_factor",
            "depth_quality_factor",
        ),
        depth_exponent=1.0,
        sidewall_rate_factor=_parameter_value(
            parameters,
            "sidewall_rate_factor",
            "wall_rate_factor",
            "wall_quality_factor",
        ),
        sidewall_influence_length_nm=config.sidewall_influence_length_nm,
        floor_rate_factor=_parameter_value(
            parameters, "floor_rate_factor", "floor_quality_factor"
        ),
        floor_influence_length_nm=config.floor_influence_length_nm,
        minimum_combined_rate_factor=config.minimum_material_rate_factor,
    )


def _case_objects(
    spec: ProcessCaseSpec,
    config: ProcessWindowConfig,
) -> tuple[
    CartesianGrid2D,
    TrenchGraphConfig,
    ContinuumCouplingParameters,
    TrenchKMCParameters,
    SpatialEtchabilityParameters,
    dict[str, object],
]:
    geometry = get_geometry_preset(spec.geometry_id)
    preset = get_literature_preset(spec.preset_id)
    grid = CartesianGrid2D.from_geometry(
        geometry,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=config.lateral_margin_nm,
    )
    hf_scale = _parameter_value(spec.parameters, "hf_bulk_scale")
    hf_weight_percent = preset.transport_hf_weight_percent * hf_scale
    speciation = hf_speciation_298K_from_weight_percent(hf_weight_percent)
    nominal_speciation = preset.hf_speciation()
    product_diffusivity_nm2_s = 0.1 * HF_DIFFUSIVITY_298_NM2_S
    product_reference = (
        preset.solid_si_site_density_mol_m3
        * preset.planar_rate_nm_s
        * geometry.depth_nm
        / product_diffusivity_nm2_s
    )
    planar_clear_time_s = geometry.depth_nm / preset.planar_rate_nm_s
    primary_duration_s = config.primary_hf_duration_s
    macro_time_step_s = (
        primary_duration_s / config.primary_sync_steps
        if config.primary_macro_time_step_s is None
        else config.primary_macro_time_step_s
    )

    coupling = ContinuumCouplingParameters(
        hf_bulk_concentration=speciation.neutral_hf_mol_m3,
        hf_diffusivity_nm2_s=HF_DIFFUSIVITY_298_NM2_S,
        hf_interface_sink_velocity_nm_s=preset.first_order_surface_transfer_nm_s(),
        product_diffusivity_nm2_s=product_diffusivity_nm2_s,
        product_interface_source_flux=(
            preset.solid_si_site_density_mol_m3 * preset.planar_rate_nm_s
        ),
        product_bulk_decay_per_s=0.0,
        hf_reference_concentration=nominal_speciation.neutral_hf_mol_m3,
        product_reference_concentration=product_reference,
        solution_temperature_K=_parameter_value(
            spec.parameters, "solution_temperature_K", "liquid_temperature_K"
        ),
        substrate_temperature_K=_parameter_value(
            spec.parameters, "substrate_temperature_K"
        ),
        macro_time_step_s=macro_time_step_s,
        total_time_s=primary_duration_s,
        target_remaining_fraction=(
            config.primary_hf_target_remaining_fraction
        ),
        maximum_events=config.maximum_events,
        relative_tolerance=1.0e-4,
        absolute_tolerance=1.0e-8,
        maximum_iterations=400,
    )
    # Preserve the existing mesoscopic absolute clock while anchoring the
    # *relative* SiN/SiCN/SiOCN rate to the selected literature blanket WER. The
    # 1 s^-1 reference remains uncalibrated; the material ratio is evidence-
    # anchored and prevents two very different blanket films from receiving
    # identical graph kinetics.
    reference_rate_nm_min = get_literature_preset(
        GRAPH_RATE_REFERENCE_PRESET_ID
    ).planar_rate_nm_min
    material_graph_rate_scale = preset.planar_rate_nm_min / reference_rate_nm_min
    nominal_site_rate_s = material_graph_rate_scale
    kinetics = TrenchKMCParameters(
        activation_rate_s=2.2 * material_graph_rate_scale,
        removal_rate_s=nominal_site_rate_s,
        passivation_rate_s=_parameter_value(
            spec.parameters, "passivation_rate_s", "passivation_formation_rate_s"
            , "passivation_generation_rate_s"
        ),
        depassivation_rate_s=_parameter_value(
            spec.parameters, "depassivation_rate_s", "passivation_removal_rate_s"
            , "passivation_release_rate_s"
        ),
        precipitation_rate_s=0.0,
        deposit_dissolution_rate_s=0.0,
        reattachment_rate_s=0.0,
        product_inhibition_strength=_parameter_value(
            spec.parameters, "product_inhibition_strength"
        ),
        top_rate_factor=1.0,
        sidewall_rate_factor=1.0,
        bottom_rate_factor=1.0,
        core_rate_factor=1.0,
    )
    spatial = _spatial_parameters(spec.parameters, config)
    graph_config = TrenchGraphConfig(
        maximum_sites=config.maximum_sites,
        material=preset.material,
    )
    derived: dict[str, object] = {
        "material": preset.material,
        "hf_weight_percent": hf_weight_percent,
        "hf_neutral_mol_m3": speciation.neutral_hf_mol_m3,
        "hf_analytical_mol_m3": speciation.analytical_fluorine_mol_m3,
        "nominal_hf_weight_percent": preset.transport_hf_weight_percent,
        "planar_rate_nm_min": preset.planar_rate_nm_min,
        "planar_clear_time_s": planar_clear_time_s,
        "primary_duration_s": primary_duration_s,
        "primary_macro_time_step_s": macro_time_step_s,
        "primary_hf_target_remaining_fraction": (
            config.primary_hf_target_remaining_fraction
        ),
        "primary_time_over_planar_clear": primary_duration_s / planar_clear_time_s,
        "nominal_site_rate_s": nominal_site_rate_s,
        "graph_rate_reference_preset_id": GRAPH_RATE_REFERENCE_PRESET_ID,
        "material_graph_rate_scale_from_literature_WER": material_graph_rate_scale,
        "product_reference_concentration_mol_m3": product_reference,
    }
    return grid, graph_config, coupling, kinetics, spatial, derived


def _deposit_phase(
    outcome: TrenchKMCOutcome,
    spec: ProcessCaseSpec,
    config: ProcessWindowConfig,
    *,
    removed_count: int,
) -> tuple[PersistentDepositPhase2D, dict[str, object], dict[str, object]]:
    preset = get_literature_preset(spec.preset_id)
    wait_s = _parameter_value(spec.parameters, "rinse_delay_s")
    capture_inf = _parameter_value(
        spec.parameters,
        "dry_capture_fraction",
        "dry_down_capture_fraction",
        "drydown_capture_fraction",
    )
    effective_capture = capture_inf * (
        1.0 - math.exp(-wait_s / config.rinse_delay_capture_tau_s)
    )
    wall_affinity = _parameter_value(
        spec.parameters, "wall_affinity_ratio", "wall_affinity"
    )
    yield_value, yield_basis = _deposit_yield(preset)
    saturation = afs_solubility_from_hf_mol_m3(
        hf_speciation_298K_from_weight_percent(
            preset.transport_hf_weight_percent
            * _parameter_value(spec.parameters, "hf_bulk_scale")
        ).analytical_fluorine_mol_m3
    )
    deposit_parameters = DepositParameters(
        species_name=(
            "AFS_like_(NH4)2SiF6"
            if preset.material == "SiN"
            else f"generic_{preset.material}_deposit"
        ),
        saturation_concentration_mol_m3=saturation,
        attachment_velocity_nm_s=0.0,
        wall_affinity=wall_affinity,
        bottom_affinity=1.0,
        deposit_molar_density_mol_m3=AFS_MOLAR_DENSITY_MOL_M3,
        # AFS mass is meaningful only for the SiN salt interpretation.  The
        # SiOCN phase remains a generic Si-equivalent inventory until its
        # composition is measured.
        deposit_molar_mass_kg_mol=(
            AFS_MOLAR_MASS_KG_MOL if preset.material == "SiN" else None
        ),
        precipitation_yield_mol_deposit_per_mol_product=yield_value,
        active_set_relative_tolerance=1.0e-3,
        maximum_active_set_iterations=8,
        subgrid_warning_thickness_over_cell=0.5,
    )
    phase = PersistentDepositPhase2D(outcome.layout.grid, deposit_parameters)
    generated_inventory_native = (
        removed_count
        * outcome.layout.grid.cell_area_nm2
        * preset.solid_si_site_density_mol_m3
    )
    trapped_inventory_native = effective_capture * generated_inventory_native
    formation_warning: str | None = None
    collector_exposure_basis = "primary_endpoint_liquid_exposed_collectors"
    if trapped_inventory_native > 0.0:
        try:
            formation = phase.precipitate_during_drydown(
                np.zeros(outcome.layout.grid.shape, dtype=float),
                outcome.final_frame.liquid_mask,
                solute_retention_fraction=0.0,
                liquid_retention_fraction=0.0,
                additional_trapped_inventory_native=trapped_inventory_native,
            )
            formation_payload = formation.to_dict()
        except (RuntimeError, ValueError) as exc:
            # A narrow central dissolution path can generate product before a
            # physical sidewall/floor collector cell is exposed.  During real
            # drain-down the meniscus can still migrate to those surfaces.  Use
            # all physical collectors as an explicit upper-bound fallback,
            # preserving inventory and recording the assumption instead of
            # silently converting the case to zero deposit.
            formation_warning = (
                "no endpoint-liquid wall/floor collector; dry-down inventory "
                "allocated over all physical collectors as a meniscus-"
                "migration upper bound"
            )
            collector_exposure_basis = "all_physical_collectors_upper_bound"
            formation = phase.precipitate_during_drydown(
                np.zeros(outcome.layout.grid.shape, dtype=float),
                outcome.layout.grid.cavity_mask,
                solute_retention_fraction=0.0,
                liquid_retention_fraction=0.0,
                additional_trapped_inventory_native=trapped_inventory_native,
            )
            formation_payload = formation.to_dict()
    else:
        formation_payload = {
            "route": "post_HF_drydown",
            "precipitated_inventory_native": 0.0,
            "diagnostics": phase.diagnostics().to_dict(),
        }
    formation_payload["formation_warning"] = formation_warning
    formation_payload["collector_exposure_basis"] = collector_exposure_basis
    closure = {
        "rinse_delay_s": wait_s,
        "capture_time_constant_s": config.rinse_delay_capture_tau_s,
        "asymptotic_capture_fraction": capture_inf,
        "effective_capture_fraction": effective_capture,
        "generated_product_inventory_native": generated_inventory_native,
        "trapped_product_inventory_native": trapped_inventory_native,
        "wall_to_bottom_affinity_ratio": wall_affinity,
        "precipitation_yield": yield_value,
        "yield_basis": yield_basis,
        "wait_model": "capture_inf*(1-exp(-wait/tau)); frozen primary endpoint",
    }
    return phase, formation_payload, closure


def _deposit_metrics(phase: PersistentDepositPhase2D) -> dict[str, float | None]:
    contact_length = phase.wall_contact_length_nm + phase.bottom_contact_length_nm
    one_cell_capacity_native = (
        phase.parameters.deposit_molar_density_mol_m3
        * float(np.sum(contact_length))
        * min(phase.grid.dx_nm, phase.grid.dz_nm)
    )
    total_inventory = float(np.sum(phase.total_inventory_native_field))
    equivalent_collector_layers = (
        total_inventory / one_cell_capacity_native
        if one_cell_capacity_native > 0.0
        else 0.0
    )
    diagnostics = phase.diagnostics()
    return {
        "deposit_collector_fraction": min(equivalent_collector_layers, 1.0),
        "deposit_equivalent_collector_layers": equivalent_collector_layers,
        "deposit_fraction_of_initial_gap_fill_area": (
            diagnostics.fraction_of_initial_gap_fill_area
        ),
        "deposit_equivalent_area_nm2": diagnostics.equivalent_cross_section_area_nm2,
        "deposit_wall_fraction": diagnostics.wall_fraction_of_deposit,
        "deposit_bottom_fraction": diagnostics.bottom_fraction_of_deposit,
        "deposit_total_inventory_native": diagnostics.total_inventory_native,
        "deposit_wall_inventory_native": diagnostics.wall_inventory_native,
        "deposit_bottom_inventory_native": diagnostics.bottom_inventory_native,
        "deposit_total_mol_per_nm_span": diagnostics.total_mol_per_nm_span,
        "deposit_total_mass_kg_per_nm_span": diagnostics.total_mass_kg_per_nm_span,
        "deposit_wall_areal_inventory_mol_m2": (
            diagnostics.wall_areal_inventory_mol_m2
        ),
        "deposit_bottom_areal_inventory_mol_m2": (
            diagnostics.bottom_areal_inventory_mol_m2
        ),
        "deposit_total_areal_inventory_mol_m2": (
            diagnostics.total_areal_inventory_mol_m2
        ),
        "deposit_mean_wall_thickness_nm": diagnostics.mean_wall_thickness_nm,
        "deposit_mean_bottom_thickness_nm": diagnostics.mean_bottom_thickness_nm,
        "deposit_mean_total_thickness_nm": diagnostics.total_mean_thickness_nm,
        "deposit_wall_coverage_fraction": (
            diagnostics.wall_continuous_coverage_fraction
        ),
        "deposit_bottom_coverage_fraction": (
            diagnostics.bottom_continuous_coverage_fraction
        ),
        "deposit_total_coverage_fraction": (
            diagnostics.total_continuous_coverage_fraction
        ),
        "deposit_wall_geometric_coverage_fraction": (
            diagnostics.wall_geometric_coverage_fraction
        ),
        "deposit_bottom_geometric_coverage_fraction": (
            diagnostics.bottom_geometric_coverage_fraction
        ),
        "deposit_total_geometric_coverage_fraction": (
            diagnostics.total_geometric_coverage_fraction
        ),
        "deposit_wall_mean_layer_equivalents": (
            diagnostics.wall_mean_layer_equivalents
        ),
        "deposit_bottom_mean_layer_equivalents": (
            diagnostics.bottom_mean_layer_equivalents
        ),
        "maximum_deposit_thickness_nm": max(
            diagnostics.maximum_wall_thickness_nm,
            diagnostics.maximum_bottom_thickness_nm,
        ),
    }


def _snapshot(
    outcome: TrenchKMCOutcome,
    final_graph: object,
    phase: PersistentDepositPhase2D,
) -> dict[str, object]:
    graph = final_graph
    layout = outcome.layout
    matrix_ids = set(layout.matrix_site_ids)
    contact = phase.wall_contact_length_nm + phase.bottom_contact_length_nm
    capacity = (
        phase.parameters.deposit_molar_density_mol_m3
        * contact
        * min(phase.grid.dx_nm, phase.grid.dz_nm)
    )
    local_inventory = phase.total_inventory_native_field
    local_coverage = np.divide(
        local_inventory,
        capacity,
        out=np.zeros_like(local_inventory),
        where=capacity > 0.0,
    )
    local_thickness = phase.wall_thickness_nm + phase.bottom_thickness_nm
    keys = (
        "site_id",
        "site_type",
        "state",
        "region",
        "x_nm",
        "depth_nm",
        "top",
        "sidewall",
        "bottom",
        "material_rate_factor",
        "deposit_coverage",
        "deposit_thickness_nm",
    )
    sites: dict[str, list[object]] = {key: [] for key in keys}
    for site_id in graph.site_ids:
        site = graph.sites[site_id]
        is_matrix = site_id in matrix_ids
        if is_matrix:
            row, col = layout.cell_by_site[site_id]
            deposit_coverage = 0.0
            deposit_thickness = 0.0
        else:
            support = layout.support_by_collector[site_id]
            row, col = layout.cell_by_site[support]
            deposit_coverage = float(local_coverage[row, col])
            deposit_thickness = float(local_thickness[row, col])
        code = int(round(site.attributes.get("region_code", 3.0)))
        values: dict[str, object] = {
            "site_id": int(site_id),
            "site_type": "matrix" if is_matrix else "collector",
            "state": site.state,
            "region": REGION_NAMES.get(code, "unknown"),
            "x_nm": float(site.attributes["x_nm"]),
            "depth_nm": float(site.attributes["depth_nm"]),
            "top": bool(site.attributes.get("top_flag", 0.0) > 0.5),
            "sidewall": bool(site.attributes.get("sidewall_flag", 0.0) > 0.5),
            "bottom": bool(site.attributes.get("bottom_flag", 0.0) > 0.5),
            "material_rate_factor": float(
                site.attributes.get("material_rate_factor", 1.0)
            ),
            "deposit_coverage": deposit_coverage,
            "deposit_thickness_nm": deposit_thickness,
        }
        for key, value in values.items():
            sites[key].append(value)
    return {
        "geometry": layout.grid.geometry.to_dict(),
        "grid": {
            "dx_nm": float(layout.grid.dx_nm),
            "dz_nm": float(layout.grid.dz_nm),
            "shape": [int(value) for value in layout.grid.shape],
        },
        "sites": sites,
        "deposit_diagnostics": phase.diagnostics().to_dict(),
    }


def _classification_inputs(
    summary: Mapping[str, object],
    deposit: Mapping[str, float],
) -> dict[str, float | int]:
    regions = summary["region_metrics"]
    assert isinstance(regions, Mapping)
    bottom = regions["bottom"]
    wall = regions["sidewall"]
    assert isinstance(bottom, Mapping) and isinstance(wall, Mapping)
    collector_count = int(summary["collector_site_count"])
    deposit_fraction = float(deposit["deposit_collector_fraction"])
    return {
        "matrix_remaining_fraction": float(summary["remaining_fraction"]),
        "matrix_site_count": int(summary["matrix_site_count"]),
        "bottom_remaining_fraction": float(bottom["remaining_fraction"]),
        "bottom_remaining_count": int(bottom["remaining_count"]),
        "bottom_site_count": int(bottom["site_count"]),
        "wall_remaining_fraction": float(wall["remaining_fraction"]),
        "wall_remaining_count": int(wall["remaining_count"]),
        "wall_site_count": int(wall["site_count"]),
        "deposit_fraction": deposit_fraction,
        "deposit_count": deposit_fraction * collector_count,
        "collector_site_count": collector_count,
    }


def _run_case(worker_input: _WorkerInput) -> dict[str, object]:
    spec, config = worker_input.spec, worker_input.config
    from process_window_sampling import classify_residue

    grid, graph_config, coupling, kinetics, spatial, derived = _case_objects(
        spec, config
    )
    # The spatial keyword is provided by the graph-KMC bridge added for this
    # study.  Static film quality multiplies removal once, not activation.
    outcome = run_coupled_trench_kmc(
        grid,
        graph_config=graph_config,
        coupling_parameters=coupling,
        kmc_parameters=kinetics,
        spatial_etchability_parameters=spatial,
        seed=spec.seed,
    )
    primary_summary = outcome.summary()
    removed_count = int(primary_summary["state_counts"].get("removed", 0))
    phase, formation, capture_closure = _deposit_phase(
        outcome,
        spec,
        config,
        removed_count=removed_count,
    )

    from trench_graph_kmc import run_second_wet_stage

    second_multiplier = _parameter_value(
        spec.parameters, "second_wet_rate_multiplier", "second_wet_rate"
    )
    second = run_second_wet_stage(
        outcome,
        parameters=SecondWetKMCParameters(
            duration_s=config.second_wet_duration_s,
            common_rate_multiplier=second_multiplier,
            matrix_removal_rate_s=kinetics.removal_rate_s,
            deposit_dissolution_rate_s=0.0,
        ),
        seed=spec.seed + 1_000_003,
    )
    final_graph = second.graph
    dissolution = phase.dissolve(
        config.second_wet_duration_s,
        wall_rate_s=(
            config.deposit_reference_dissolution_rate_s * second_multiplier
        ),
        bottom_rate_s=(
            config.deposit_reference_dissolution_rate_s * second_multiplier
        ),
    )
    final_summary = trench_residue_metrics(final_graph, outcome.layout)
    deposit_metrics = _deposit_metrics(phase)
    classification_inputs = _classification_inputs(final_summary, deposit_metrics)
    classification = classify_residue(classification_inputs)
    raw_class = str(
        classification.get(
            "primary_class", classification.get("classification", "")
        )
    )
    primary_class = (
        "precipitation_residue" if raw_class == "deposit_residue" else raw_class
    )
    other_matrix_only = (
        bool(classification.get("matrix_residue", False))
        and int(classification_inputs["bottom_remaining_count"]) == 0
        and int(classification_inputs["wall_remaining_count"]) == 0
    )
    if other_matrix_only:
        # The requested display has only bottom and wall matrix-failure bins.
        # Keep an explicit flag and collapse top/core-only residue into the
        # non-bottom (wall) bin instead of the classifier's conservative tie-
        # to-bottom rule.
        primary_class = "wall_residue"
        classification["other_matrix_residue_collapsed_to_wall"] = True
    else:
        classification["other_matrix_residue_collapsed_to_wall"] = False
    if primary_class not in CLASS_ORDER:
        raise ValueError(f"unsupported residue classification {raw_class!r}")
    classification["primary_class"] = primary_class
    classification["primary_class_ja"] = CLASS_LABELS_JA[primary_class]
    metrics = {
        "total_remaining_fraction": float(final_summary["remaining_fraction"]),
        "bottom_remaining_fraction": float(
            classification_inputs["bottom_remaining_fraction"]
        ),
        "wall_remaining_fraction": float(
            classification_inputs["wall_remaining_fraction"]
        ),
        "deposit_fraction": float(classification_inputs["deposit_fraction"]),
        "wall_deposit_fraction": (
            float(classification_inputs["deposit_fraction"])
            * float(deposit_metrics["deposit_wall_fraction"])
        ),
        "passivated_fraction": (
            float(final_summary["state_counts"].get("passivated", 0))
            / float(final_summary["matrix_site_count"])
        ),
    }
    result: dict[str, object] = {
        "order": spec.order,
        "case_id": _case_id(spec),
        "case_group": spec.case_group,
        "design_index": spec.design_index,
        "geometry_id": spec.geometry_id,
        "preset_id": spec.preset_id,
        "material": derived["material"],
        "replicate_index": spec.replicate_index,
        "seed": spec.seed,
        "design_role": spec.design_role,
        "pair_id": spec.pair_id,
        "x_index": spec.x_index,
        "y_index": spec.y_index,
        "status": "ok",
        "parameters": {key: float(value) for key, value in spec.parameters.items()},
        "derived_conditions": derived,
        "stage_summaries": {
            "primary_hf": primary_summary,
            "rinse_delay_and_drydown": {
                "capture_closure": capture_closure,
                "formation": formation,
            },
            "second_wet_matrix": second.summary(),
            "second_wet_deposit": dissolution.to_dict(),
            "final": final_summary,
        },
        "metrics": metrics,
        "classification_inputs": classification_inputs,
        "classification": classification,
        "convergence": {
            "all_hf_synchronizations": all(
                bool(item["hf_converged"]) for item in outcome.sync_history
            ),
            "all_product_synchronizations": all(
                bool(item["product_converged"]) for item in outcome.sync_history
            ),
            "primary_stop_reason": outcome.stop_reason,
            "maximum_site_budget_ok": outcome.layout.site_count <= graph_config.maximum_sites,
        },
        "model_parameters": {
            "graph": asdict(graph_config),
            "coupling": asdict(coupling),
            "kinetics": asdict(kinetics),
            "spatial_etchability": spatial.to_dict(),
        },
        "deposit_metrics": deposit_metrics,
    }
    if worker_input.include_snapshot:
        result["snapshot"] = _snapshot(outcome, final_graph, phase)
    return result


def _worker(worker_input: _WorkerInput) -> dict[str, object]:
    try:
        return _run_case(worker_input)
    except Exception as exc:  # Keep a broad design running if one point fails.
        spec = worker_input.spec
        return {
            "order": spec.order,
            "case_id": _case_id(spec),
            "case_group": spec.case_group,
            "design_index": spec.design_index,
            "geometry_id": spec.geometry_id,
            "preset_id": spec.preset_id,
            "replicate_index": spec.replicate_index,
            "seed": spec.seed,
            "design_role": spec.design_role,
            "pair_id": spec.pair_id,
            "x_index": spec.x_index,
            "y_index": spec.y_index,
            "parameters": {key: float(value) for key, value in spec.parameters.items()},
            "status": "failed",
            "error_type": type(exc).__name__,
            "error_message": str(exc),
        }


def _worker_initializer() -> None:
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = "1"
    try:
        from threadpoolctl import threadpool_limits

        threadpool_limits(1)
    except ImportError:
        pass


def _case_id(spec: ProcessCaseSpec) -> str:
    pair = "" if spec.pair_id is None else f"__{spec.pair_id}"
    return (
        f"{spec.case_group}{pair}__d{spec.design_index:04d}__"
        f"{spec.geometry_id}__{spec.preset_id}__r{spec.replicate_index}"
    )


def _execute(
    jobs: Iterable[_WorkerInput], workers: int
) -> list[dict[str, object]]:
    job_list = list(jobs)
    if workers == 1:
        return [_worker(job) for job in job_list]
    with ProcessPoolExecutor(
        max_workers=min(workers, len(job_list)),
        initializer=_worker_initializer,
    ) as executor:
        chunksize = max(1, len(job_list) // max(1, workers * 16))
        return list(executor.map(_worker, job_list, chunksize=chunksize))


def _global_specs(
    design: Sequence[Mapping[str, float]], config: ProcessWindowConfig
) -> list[ProcessCaseSpec]:
    specs: list[ProcessCaseSpec] = []
    for design_index, row in enumerate(design):
        clean = {
            key: float(value)
            for key, value in row.items()
            if isinstance(value, (int, float, np.integer, np.floating))
            and key not in {"design_index", "sobol_index"}
        }
        design_role = str(row.get("design_role", "sobol"))
        for geometry_index, geometry_id in enumerate(config.geometries):
            for preset_index, preset_id in enumerate(config.presets):
                for replicate_index, base_seed in enumerate(config.replicate_seeds):
                    seed = (
                        int(base_seed)
                        + 10_007 * geometry_index
                        + 100_003 * preset_index
                    )
                    specs.append(
                        ProcessCaseSpec(
                            order=len(specs),
                            case_group="sobol",
                            design_index=design_index,
                            geometry_id=geometry_id,
                            preset_id=preset_id,
                            replicate_index=replicate_index,
                            seed=seed,
                            parameters=clean,
                            design_role=design_role,
                        )
                    )
    return specs


def _aggregate_design_rows(
    cases: Sequence[Mapping[str, object]],
    parameter_names: Sequence[str],
    *,
    geometry_id: str | None = None,
    preset_id: str | None = None,
) -> list[dict[str, float]]:
    successful = [
        case
        for case in cases
        if case.get("status") == "ok"
        and case.get("design_role", "sobol") == "sobol"
        and (geometry_id is None or case.get("geometry_id") == geometry_id)
        and (preset_id is None or case.get("preset_id") == preset_id)
    ]
    indices = sorted({int(case["design_index"]) for case in successful})
    rows: list[dict[str, float]] = []
    for index in indices:
        subset = [case for case in successful if int(case["design_index"]) == index]
        if not subset:
            continue
        params = subset[0]["parameters"]
        assert isinstance(params, Mapping)
        row = {name: float(params[name]) for name in parameter_names}
        for metric in (
            "total_remaining_fraction",
            "bottom_remaining_fraction",
            "wall_remaining_fraction",
            "deposit_fraction",
            "wall_deposit_fraction",
            "passivated_fraction",
        ):
            values = [float(case["metrics"][metric]) for case in subset]
            row[metric] = float(np.median(values))
        rows.append(row)
    return rows


def _select_parameter_pairs(
    sensitivity: Mapping[str, object], maximum_pairs: int
) -> list[tuple[str, str]]:
    if maximum_pairs <= 0:
        return []
    rows = sensitivity.get("rows", sensitivity.get("results", []))
    metric_mapping = sensitivity.get("metrics")
    if isinstance(metric_mapping, Mapping):
        rows = []
        for metric_name, metric_payload in metric_mapping.items():
            if not isinstance(metric_payload, Mapping):
                continue
            parameter_results = metric_payload.get("parameter_results", [])
            if not isinstance(parameter_results, Sequence):
                continue
            for item in parameter_results:
                if isinstance(item, Mapping):
                    rows.append({"metric": metric_name, **dict(item)})
    if isinstance(rows, Mapping):
        rows = rows.get("rows", [])
    candidates: list[tuple[float, str, str]] = []
    if isinstance(rows, Sequence):
        by_metric: dict[str, list[tuple[float, str]]] = {}
        for item in rows:
            if not isinstance(item, Mapping):
                continue
            metric = str(item.get("metric", item.get("response", "")))
            parameter = str(item.get("parameter", ""))
            coefficient = float(item.get("prcc", item.get("coefficient", 0.0)))
            if metric and parameter and math.isfinite(coefficient):
                by_metric.setdefault(metric, []).append((abs(coefficient), parameter))
        for metric, ranked in by_metric.items():
            ranked.sort(reverse=True)
            if len(ranked) >= 2:
                candidates.append(
                    (ranked[0][0] + ranked[1][0], ranked[0][1], ranked[1][1])
                )
    unique: list[tuple[str, str]] = []
    seen: set[frozenset[str]] = set()
    for _, left, right in sorted(candidates, reverse=True):
        key = frozenset((left, right))
        if left == right or key in seen:
            continue
        seen.add(key)
        unique.append((left, right))
        if len(unique) >= maximum_pairs:
            break
    # If several responses share the same two dominant drivers, retain a few
    # mechanistically diagnostic maps instead of returning duplicate science.
    # The global Sobol/PRCC still covers all 13 variables; these fallbacks make
    # rinse/dry-down and attachment/second-WET interactions directly readable.
    for left, right in (
        ("rinse_delay_s", "drydown_capture_fraction"),
        ("wall_affinity", "second_wet_rate_multiplier"),
        ("hf_bulk_scale", "liquid_temperature_K"),
        ("product_inhibition_strength", "passivation_generation_rate_s"),
        ("depth_quality_factor", "floor_quality_factor"),
    ):
        key = frozenset((left, right))
        if key in seen:
            continue
        seen.add(key)
        unique.append((left, right))
        if len(unique) >= maximum_pairs:
            break
    return unique


def _phase_specs(
    pairs: Sequence[tuple[str, str]],
    definitions: Sequence[object],
    config: ProcessWindowConfig,
) -> tuple[list[ProcessCaseSpec], list[dict[str, object]]]:
    from process_window_sampling import parameter_grid_values

    definitions_by_name = {getattr(item, "name"): item for item in definitions}
    centre = {
        name: float(values[0])
        for name, values in (
            (
                name,
                parameter_grid_values(
                    definition, 3, bounds_set=config.parameter_bounds_set
                )[1:2],
            )
            for name, definition in definitions_by_name.items()
        )
    }
    specs: list[ProcessCaseSpec] = []
    metadata: list[dict[str, object]] = []
    for pair_index, (x_name, y_name) in enumerate(pairs):
        pair_names = {x_name, y_name}
        deposit_focus = pair_names.issubset(
            {
                "rinse_delay_s",
                "drydown_capture_fraction",
                "wall_affinity",
                "second_wet_rate_multiplier",
            }
        )
        held = dict(centre)
        context = "median_screening_conditions"
        if deposit_focus:
            # Matrix residue has deliberate classification precedence.  A
            # deposit-focused phase map would therefore be uniformly hidden
            # unless the held primary-HF coordinates first clear the matrix.
            # Use the favourable endpoints of the selected bounds while
            # preserving the two plotted axes themselves.
            context = "matrix_clearing_deposit_focus"
            for name in (
                "hf_bulk_scale",
                "liquid_temperature_K",
                "substrate_temperature_K",
                "depth_quality_factor",
                "wall_quality_factor",
                "floor_quality_factor",
                "passivation_release_rate_s",
            ):
                held[name] = definitions_by_name[name].bounds(
                    config.parameter_bounds_set
                )[1]
            for name in (
                "product_inhibition_strength",
                "passivation_generation_rate_s",
            ):
                held[name] = definitions_by_name[name].bounds(
                    config.parameter_bounds_set
                )[0]
            held["rinse_delay_s"] = definitions_by_name["rinse_delay_s"].bounds(
                config.parameter_bounds_set
            )[1]
            held["drydown_capture_fraction"] = definitions_by_name[
                "drydown_capture_fraction"
            ].bounds(config.parameter_bounds_set)[1]
            held["second_wet_rate_multiplier"] = definitions_by_name[
                "second_wet_rate_multiplier"
            ].bounds(config.parameter_bounds_set)[0]
        x_values = parameter_grid_values(
            definitions_by_name[x_name],
            config.phase_levels,
            bounds_set=config.parameter_bounds_set,
        )
        y_values = parameter_grid_values(
            definitions_by_name[y_name],
            config.phase_levels,
            bounds_set=config.parameter_bounds_set,
        )
        pair_id = f"p{pair_index + 1}_{x_name}__{y_name}"
        metadata.append(
            {
                "pair_id": pair_id,
                "x_parameter": x_name,
                "y_parameter": y_name,
                "x_values": [float(value) for value in x_values],
                "y_values": [float(value) for value in y_values],
                "held_parameter_context": context,
                "held_parameters": {
                    key: float(value)
                    for key, value in held.items()
                    if key not in pair_names
                },
            }
        )
        for y_index, y_value in enumerate(y_values):
            for x_index, x_value in enumerate(x_values):
                parameters = dict(held)
                parameters[x_name] = float(x_value)
                parameters[y_name] = float(y_value)
                phase_design_index = y_index * len(x_values) + x_index
                for geometry_index, geometry_id in enumerate(config.geometries):
                    for preset_index, preset_id in enumerate(config.presets):
                        for replicate_index, base_seed in enumerate(config.replicate_seeds):
                            seed = (
                                int(base_seed)
                                + 10_007 * geometry_index
                                + 100_003 * preset_index
                            )
                            specs.append(
                                ProcessCaseSpec(
                                    order=len(specs),
                                    case_group="phase_map",
                                    design_index=phase_design_index,
                                    geometry_id=geometry_id,
                                    preset_id=preset_id,
                                    replicate_index=replicate_index,
                                    seed=seed,
                                    parameters=parameters,
                                    design_role="phase_grid",
                                    pair_id=pair_id,
                                    x_index=x_index,
                                    y_index=y_index,
                                )
                            )
    return specs, metadata


def _phase_map_payload(
    metadata: Sequence[Mapping[str, object]],
    cases: Sequence[Mapping[str, object]],
    config: ProcessWindowConfig,
) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for pair in metadata:
        pair_id = str(pair["pair_id"])
        nx = len(pair["x_values"])
        ny = len(pair["y_values"])
        strata: list[dict[str, object]] = []
        for geometry_id in config.geometries:
            for preset_id in config.presets:
                class_probabilities = {
                    key: [[0.0 for _ in range(nx)] for _ in range(ny)]
                    for key in CLASS_ORDER
                }
                metric_medians: dict[str, list[list[float | None]]] = {
                    name: [[None for _ in range(nx)] for _ in range(ny)]
                    for name in (
                        "total_remaining_fraction",
                        "bottom_remaining_fraction",
                        "wall_remaining_fraction",
                        "deposit_fraction",
                        "wall_deposit_fraction",
                    )
                }
                dominant = [["failed" for _ in range(nx)] for _ in range(ny)]
                probability = [[0.0 for _ in range(nx)] for _ in range(ny)]
                failure_probability = [[1.0 for _ in range(nx)] for _ in range(ny)]
                requested_count = [[0 for _ in range(nx)] for _ in range(ny)]
                successful_count = [[0 for _ in range(nx)] for _ in range(ny)]
                case_ids: list[list[list[str]]] = [
                    [[] for _ in range(nx)] for _ in range(ny)
                ]
                for y_index in range(ny):
                    for x_index in range(nx):
                        requested = [
                            case
                            for case in cases
                            if case.get("pair_id") == pair_id
                            and case.get("geometry_id") == geometry_id
                            and case.get("preset_id") == preset_id
                            and int(case.get("x_index", -1)) == x_index
                            and int(case.get("y_index", -1)) == y_index
                        ]
                        subset = [
                            case for case in requested if case.get("status") == "ok"
                        ]
                        requested_count[y_index][x_index] = len(requested)
                        successful_count[y_index][x_index] = len(subset)
                        failure_probability[y_index][x_index] = (
                            (len(requested) - len(subset)) / len(requested)
                            if requested
                            else 1.0
                        )
                        case_ids[y_index][x_index].extend(
                            str(case["case_id"]) for case in requested
                        )
                        if not subset:
                            continue
                        counts = {key: 0 for key in CLASS_ORDER}
                        for case in subset:
                            classification = case["classification"]
                            key = str(classification["primary_class"])
                            counts[key] += 1
                        for key in CLASS_ORDER:
                            class_probabilities[key][y_index][x_index] = (
                                counts[key] / len(requested)
                            )
                        for metric_name, grid_values in metric_medians.items():
                            available = [
                                float(case["metrics"][metric_name])
                                for case in subset
                                if isinstance(case.get("metrics"), Mapping)
                                and metric_name in case["metrics"]
                            ]
                            if available:
                                grid_values[y_index][x_index] = float(
                                    np.median(available)
                                )
                        winner = max(CLASS_ORDER, key=lambda key: counts[key])
                        dominant[y_index][x_index] = winner
                        probability[y_index][x_index] = (
                            counts[winner] / len(requested)
                        )
                strata.append(
                    {
                        "geometry_id": geometry_id,
                        "preset_id": preset_id,
                        "material": get_literature_preset(preset_id).material,
                        "dominant_class": dominant,
                        "dominant_probability": probability,
                        "failure_probability": failure_probability,
                        "requested_replicate_count": requested_count,
                        "successful_replicate_count": successful_count,
                        "class_probabilities": class_probabilities,
                        "metric_medians": metric_medians,
                        "case_ids": case_ids,
                    }
                )
        result.append({**dict(pair), "strata": strata})
    return result


def _representative_specs(
    global_cases: Sequence[Mapping[str, object]],
    specs: Sequence[ProcessCaseSpec],
) -> list[ProcessCaseSpec]:
    by_id = {
        (spec.design_index, spec.geometry_id, spec.preset_id, spec.replicate_index): spec
        for spec in specs
    }
    selected: list[ProcessCaseSpec] = []
    for geometry_id in sorted({str(case["geometry_id"]) for case in global_cases}):
        for preset_id in sorted({str(case["preset_id"]) for case in global_cases}):
            for class_name in CLASS_ORDER:
                subset = [
                    case
                    for case in global_cases
                    if case.get("status") == "ok"
                    and case["geometry_id"] == geometry_id
                    and case["preset_id"] == preset_id
                    and case["classification"]["primary_class"] == class_name
                ]
                if not subset:
                    continue
                metric_names = (
                    "total_remaining_fraction",
                    "bottom_remaining_fraction",
                    "wall_remaining_fraction",
                    "deposit_fraction",
                )
                centre = np.asarray(
                    [
                        np.median([float(case["metrics"][name]) for case in subset])
                        for name in metric_names
                    ]
                )
                chosen = min(
                    subset,
                    key=lambda case: float(
                        np.linalg.norm(
                            np.asarray([float(case["metrics"][name]) for name in metric_names])
                            - centre
                        )
                    ),
                )
                key = (
                    int(chosen["design_index"]),
                    geometry_id,
                    preset_id,
                    int(chosen["replicate_index"]),
                )
                selected.append(by_id[key])
    return selected


def _classification_counts(cases: Sequence[Mapping[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for geometry_id in sorted({str(case["geometry_id"]) for case in cases}):
        for preset_id in sorted({str(case["preset_id"]) for case in cases}):
            subset = [
                case
                for case in cases
                if case.get("status") == "ok"
                and case["geometry_id"] == geometry_id
                and case["preset_id"] == preset_id
            ]
            counts = {key: 0 for key in CLASS_ORDER}
            for case in subset:
                counts[str(case["classification"]["primary_class"])] += 1
            result[f"{geometry_id}__{preset_id}"] = {
                "geometry_id": geometry_id,
                "preset_id": preset_id,
                "material": get_literature_preset(preset_id).material,
                "successful_case_count": len(subset),
                "counts": counts,
                "fractions": {
                    key: counts[key] / len(subset) if subset else 0.0
                    for key in CLASS_ORDER
                },
            }
    return result


def run_process_window_sweep(
    config: ProcessWindowConfig = ProcessWindowConfig(),
) -> dict[str, object]:
    """Run the global Sobol design, selected phase maps and representatives."""

    from process_window_sampling import (
        compute_prcc,
        default_parameter_definitions,
        generate_sobol_design,
    )

    definitions = default_parameter_definitions()
    parameter_names = [item.name for item in definitions]
    design = generate_sobol_design(
        config.design_points,
        config.design_seed,
        bounds_set=config.parameter_bounds_set,
        definitions=definitions,
    )
    global_specs = _global_specs(design, config)
    global_cases = _execute(
        (_WorkerInput(spec, config) for spec in global_specs),
        config.parallel_workers,
    )
    metric_names = (
        "total_remaining_fraction",
        "bottom_remaining_fraction",
        "wall_remaining_fraction",
        "deposit_fraction",
        "wall_deposit_fraction",
    )

    def analyse_rows(
        rows: list[dict[str, float]], seed: int
    ) -> dict[str, object]:
        if len(rows) <= len(parameter_names) + 1:
            return {
                "status": "insufficient_samples",
                "sample_count": len(rows),
                "required_sample_count": len(parameter_names) + 2,
                "parameter_names": parameter_names,
                "metric_names": list(metric_names),
                "metrics": {},
            }
        result = compute_prcc(
            rows,
            parameter_names=parameter_names,
            metric_names=metric_names,
            bootstrap_samples=config.bootstrap_samples,
            seed=seed,
        )
        result["status"] = "ok"
        return result

    sensitivity_rows = _aggregate_design_rows(global_cases, parameter_names)
    sensitivity = analyse_rows(sensitivity_rows, config.design_seed + 17)
    sensitivity["scope"] = (
        "pooled median across geometry, material and KMC replicate for each "
        "Sobol point; zero-capture control excluded"
    )
    sensitivity_strata: dict[str, object] = {}
    for geometry_index, geometry_id in enumerate(config.geometries):
        for preset_index, preset_id in enumerate(config.presets):
            key = f"{geometry_id}__{preset_id}"
            rows = _aggregate_design_rows(
                global_cases,
                parameter_names,
                geometry_id=geometry_id,
                preset_id=preset_id,
            )
            item = analyse_rows(
                rows,
                config.design_seed
                + 10_007 * (geometry_index + 1)
                + 100_003 * (preset_index + 1),
            )
            item["geometry_id"] = geometry_id
            item["preset_id"] = preset_id
            item["material"] = get_literature_preset(preset_id).material
            sensitivity_strata[key] = item
    sensitivity["strata"] = sensitivity_strata
    pairs = (
        _select_parameter_pairs(sensitivity, config.maximum_phase_pairs)
        if config.include_phase_maps
        else []
    )
    phase_specs, phase_metadata = _phase_specs(pairs, definitions, config)
    phase_cases = _execute(
        (_WorkerInput(spec, config) for spec in phase_specs),
        config.parallel_workers,
    ) if phase_specs else []
    phase_maps = _phase_map_payload(phase_metadata, phase_cases, config)

    representatives: list[dict[str, object]] = []
    representative_cases: list[dict[str, object]] = []
    if config.include_representatives:
        representative_specs = _representative_specs(global_cases, global_specs)
        representative_cases = _execute(
            (_WorkerInput(spec, config, include_snapshot=True) for spec in representative_specs),
            config.parallel_workers,
        )
        for case in representative_cases:
            if case.get("status") == "ok":
                representatives.append(case)

    all_requested_cases = (
        list(global_cases) + list(phase_cases) + list(representative_cases)
    )
    failed = [
        case for case in all_requested_cases
        if case.get("status") != "ok"
    ]
    successful_requested = [
        case for case in all_requested_cases if case.get("status") == "ok"
    ]
    return {
        "schema_version": SCHEMA_VERSION,
        "model_name": "real-trench continuum / graph-KMC process-window sweep",
        "notice": PROCESS_WINDOW_NOTICE,
        "class_order": list(CLASS_ORDER),
        "class_labels_ja": CLASS_LABELS_JA,
        "config": config.to_dict(),
        "design": {
            "kind": "scrambled_Sobol",
            "seed": config.design_seed,
            "sobol_point_count": config.design_points,
            "row_count_including_controls": len(design),
            "bounds_set": config.parameter_bounds_set,
            "dimension_order": parameter_names,
            "parameter_definitions": [item.to_dict() for item in definitions],
            "replicate_seeds": list(config.replicate_seeds),
            "common_random_numbers": True,
            "rows": design,
        },
        "parallel_execution": {
            "workers": config.parallel_workers,
            "case_order_preserved": True,
            "worker_numeric_thread_limit_requested": 1,
            "numeric_thread_limit_method": (
                "OMP/OpenBLAS/MKL/Accelerate/NumExpr environment variables; "
                "threadpoolctl also used when installed"
            ),
            "backend": "ProcessPoolExecutor",
        },
        "global_cases": global_cases,
        "classification_counts": _classification_counts(global_cases),
        "sensitivity": sensitivity,
        "selected_phase_pairs": [list(pair) for pair in pairs],
        "phase_cases": phase_cases,
        "phase_maps": phase_maps,
        "representatives": representatives,
        "quality_summary": {
            "requested_global_case_count": len(global_specs),
            "requested_phase_case_count": len(phase_specs),
            "successful_global_case_count": sum(
                case.get("status") == "ok" for case in global_cases
            ),
            "successful_phase_case_count": sum(
                case.get("status") == "ok" for case in phase_cases
            ),
            "requested_representative_case_count": len(representative_cases),
            "successful_representative_case_count": sum(
                case.get("status") == "ok" for case in representative_cases
            ),
            "failed_case_count": len(failed),
            "failed_case_ids": [str(case["case_id"]) for case in failed],
            "hf_nonconverged_case_count": sum(
                not bool(case["convergence"]["all_hf_synchronizations"])
                for case in successful_requested
            ),
            "product_nonconverged_case_count": sum(
                not bool(case["convergence"]["all_product_synchronizations"])
                for case in successful_requested
            ),
            "primary_maximum_events_case_count": sum(
                case["convergence"]["primary_stop_reason"] == "maximum_events"
                for case in successful_requested
            ),
            "drydown_collector_fallback_case_count": sum(
                case["stage_summaries"]["rinse_delay_and_drydown"]["formation"].get(
                    "formation_warning"
                )
                is not None
                for case in successful_requested
            ),
        },
        "model_limitations": {
            "parameter_status": "screening domains, not recipe limits",
            "hf_speciation": "Hamer-Wu 298 K table; not temperature corrected",
            "hf_diffusivity": "298 K bulk value; nanoconfinement omitted",
            "temperature_coupling": (
                "local thermal-resistance temperature changes graph activation/"
                "removal Arrhenius rates; the continuum Robin sink remains at "
                "its reference literature value"
            ),
            "graph_rate_calibration": (
                "absolute 1 s^-1 graph clock is uncalibrated; SiN/SiCN/SiOCN "
                "prefactors are scaled by their nominal literature blanket-WER "
                "ratio relative to sin_barcellona_b_0p55wt"
            ),
            "product_source_coupling": (
                "continuum product source uses the literature planar flux at "
                "each wet interface and is not updated from interval-by-interval "
                "KMC removal counts; dry-down cumulative inventory does use the "
                "actual removed-site count"
            ),
            "rinse_delay": (
                "frozen-endpoint asymptotic attachment closure with fixed 30 s tau"
            ),
            "deposit": (
                "SiN AFS-like density/solubility proxy; SiOCN species unverified"
            ),
            "second_wet": (
                "alternative-chemistry direct graph removal and first-order "
                "deposit dissolution; both multipliers uncalibrated"
            ),
            "phase_probability": (
                "empirical fraction over configured KMC replicate seeds; quick "
                "mode has one seed, so values are 0 or 1 rather than uncertainty "
                "estimates"
            ),
        },
        "artifacts": {},
    }


__all__ = [
    "CLASS_LABELS_JA",
    "CLASS_ORDER",
    "PROCESS_WINDOW_NOTICE",
    "ProcessCaseSpec",
    "ProcessWindowConfig",
    "run_process_window_sweep",
]

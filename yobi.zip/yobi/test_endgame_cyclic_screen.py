from __future__ import annotations

import unittest

from endgame_cyclic_screen import (
    build_report,
    clearing_case,
    feasibility_row,
    silicon_cost,
)
from reset_silicon_cost_screen import silicon_per_oxide_thickness_ratio
from spacer_pullback_screen import cycles_to_clear_residue


C22 = "kawarazaki_sicn_c22"
C40 = "kawarazaki_sicn_c40"
C5 = "kawarazaki_siocn_c5"
SIN = "kawarazaki_sin_reference"


def _material(row, key: str):
    return next(entry for entry in row["materials"] if entry["material"] == key)


class ClearingCaseTests(unittest.TestCase):
    def test_cyclic_counts_match_the_maximin_machinery(self) -> None:
        """Same clock, same code path as the spacer screen's residue side."""

        for key, expected in ((C22, 1), (C40, 3), (C5, 4), (SIN, 50)):
            case = clearing_case(
                material_key=key,
                pad_thickness_nm=2.0,
                wet_reset_efficiency=1.0,
            )
            self.assertEqual(case["cycles_central"], expected, key)
            reference = cycles_to_clear_residue(
                key, thickness_nm=2.0, wet_reset_efficiency=1.0
            )
            self.assertEqual(
                case["cycles_central"], reference["cycles_central"], key
            )

    def test_no_reset_arm_is_plain_dhf(self) -> None:
        """epsilon = 0: C22 needs 67 pulses for the same 2 nm."""

        case = clearing_case(
            material_key=C22,
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
        )
        self.assertEqual(case["no_reset_pulses_central"], 67)
        self.assertAlmostEqual(case["reset_leverage"], 67.0, places=9)

    def test_reset_buys_little_for_the_fast_dhf_film(self) -> None:
        """SiOCN C:5% halves its pulses; cycling is not automatic."""

        case = clearing_case(
            material_key=C5,
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
        )
        self.assertEqual(case["no_reset_pulses_central"], 8)
        self.assertAlmostEqual(case["reset_leverage"], 2.0, places=9)

    def test_sin_gains_nothing_from_the_reset(self) -> None:
        case = clearing_case(
            material_key=SIN,
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
        )
        self.assertAlmostEqual(case["reset_leverage"], 1.0, places=9)

    def test_floor_films_have_unbounded_no_reset_arms(self) -> None:
        """C22's dHF-only bar sits at the raster floor."""

        case = clearing_case(
            material_key=C22,
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
        )
        self.assertTrue(case["no_reset_unbounded_within_resolution"])


class SiliconCostTests(unittest.TestCase):
    def test_walls_pay_every_cycle_and_bottom_pays_the_margin(self) -> None:
        ratio = silicon_per_oxide_thickness_ratio()
        cost = silicon_cost(
            cycles=3, margin_cycles=2, oxide_thickness_nm=1.0
        )
        self.assertAlmostEqual(
            cost["wall_recession_nm"], 5 * ratio, places=12
        )
        self.assertAlmostEqual(
            cost["cleared_bottom_recession_nm"], 2 * ratio, places=12
        )

    def test_zero_margin_spares_the_cleared_bottom(self) -> None:
        cost = silicon_cost(
            cycles=4, margin_cycles=0, oxide_thickness_nm=1.0
        )
        self.assertEqual(cost["cleared_bottom_recession_nm"], 0.0)

    def test_invalid_inputs_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            silicon_cost(cycles=0, margin_cycles=0, oxide_thickness_nm=1.0)
        with self.assertRaises(ValueError):
            silicon_cost(cycles=1, margin_cycles=-1, oxide_thickness_nm=1.0)


class FeasibilityTests(unittest.TestCase):
    def test_carbon_films_pass_where_sin_fails(self) -> None:
        """The two-material system has no selectivity deadlock."""

        row = feasibility_row(
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            oxide_thickness_nm=1.0,
            silicon_budget_nm=2.0,
            margin_cycles=0,
        )
        self.assertTrue(row["carbon_materials_feasible"])
        self.assertFalse(row["all_materials_feasible"])
        self.assertFalse(_material(row, SIN)["feasible"])
        self.assertAlmostEqual(
            _material(row, C5)["wall_recession_nm"],
            4 * silicon_per_oxide_thickness_ratio(),
            places=12,
        )

    def test_weak_wet_reset_breaks_the_carbon_verdict(self) -> None:
        """epsilon = 0.3 doubles the cycles and blows the budget."""

        row = feasibility_row(
            pad_thickness_nm=2.0,
            wet_reset_efficiency=0.3,
            oxide_thickness_nm=1.0,
            silicon_budget_nm=2.0,
            margin_cycles=0,
        )
        self.assertFalse(row["carbon_materials_feasible"])
        self.assertTrue(_material(row, C22)["feasible"])

    def test_margin_cycles_can_outweigh_material_choice(self) -> None:
        """Two margin cycles push SiOCN C:5% past the same budget."""

        row = feasibility_row(
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            oxide_thickness_nm=1.0,
            silicon_budget_nm=2.0,
            margin_cycles=2,
        )
        self.assertFalse(row["carbon_materials_feasible"])
        self.assertFalse(_material(row, C5)["feasible"])
        self.assertAlmostEqual(
            _material(row, C5)["cleared_bottom_recession_nm"],
            2 * silicon_per_oxide_thickness_ratio(),
            places=12,
        )

    def test_thin_oxide_readmits_the_carbon_cohort_at_half_nm(self) -> None:
        row = feasibility_row(
            pad_thickness_nm=1.0,
            wet_reset_efficiency=1.0,
            oxide_thickness_nm=0.5,
            silicon_budget_nm=0.5,
            margin_cycles=0,
        )
        self.assertTrue(row["carbon_materials_feasible"])

    def test_unclearable_pad_is_reported_with_a_reason(self) -> None:
        """A pad beyond the cycle cap cannot be judged feasible."""

        row = feasibility_row(
            pad_thickness_nm=25.0,
            wet_reset_efficiency=1.0,
            oxide_thickness_nm=1.0,
            silicon_budget_nm=2.0,
            margin_cycles=0,
        )
        entry = _material(row, SIN)
        self.assertFalse(entry["feasible"])
        self.assertIn("unbounded", entry["infeasible_reason"])

    def test_worst_carbon_material_is_identified(self) -> None:
        row = feasibility_row(
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            oxide_thickness_nm=1.0,
            silicon_budget_nm=2.0,
            margin_cycles=0,
        )
        self.assertEqual(row["worst_carbon_material"]["material"], C5)

    def test_nonpositive_budget_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            feasibility_row(
                pad_thickness_nm=2.0,
                wet_reset_efficiency=1.0,
                oxide_thickness_nm=1.0,
                silicon_budget_nm=0.0,
                margin_cycles=0,
            )


class ReportTests(unittest.TestCase):
    def test_report_never_passes_the_full_matrix(self) -> None:
        """A SiN-like fill always blows the silicon budget."""

        report = build_report()
        for row in report["feasibility"]:
            self.assertFalse(row["all_materials_feasible"])

    def test_carbon_feasible_conditions_exist_and_are_listed(self) -> None:
        report = build_report()
        conditions = report["carbon_feasible_conditions"]
        self.assertTrue(conditions)
        self.assertIn(
            {
                "wet_reset_efficiency": 1.0,
                "pad_thickness_nm": 2.0,
                "oxide_thickness_nm": 1.0,
                "silicon_budget_nm": 2.0,
                "margin_cycles": 0,
            },
            conditions,
        )

    def test_report_declares_the_scope_and_clock(self) -> None:
        report = build_report()
        self.assertIn("does not apply", report["system_note"])
        self.assertIn("N oxidation events", report["cycle_structure_note"])
        self.assertIn(
            "different film", report["assumptions"]["clock_note"]
        )

    def test_report_sweeps_have_the_declared_sizes(self) -> None:
        report = build_report()
        self.assertEqual(len(report["clearing"]), 2 * 5 * 4)
        self.assertEqual(len(report["feasibility"]), 2 * 5 * 3 * 3 * 3)

    def test_report_rejects_bad_sweeps(self) -> None:
        with self.assertRaises(ValueError):
            build_report(pad_thicknesses_nm=(0.0,))
        with self.assertRaises(ValueError):
            build_report(margin_cycles=(-1,))


if __name__ == "__main__":
    unittest.main()

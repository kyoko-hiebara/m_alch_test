from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from graph_kmc_visualization import (
    SURFACE_PATCH_CAVEAT,
    create_graph_kmc_visualizations,
    generate_representative_trace,
    load_sweep_payload,
)


ROOT = Path(__file__).resolve().parent
SWEEP_JSON = ROOT / "graph_kmc_velocity_sweep_results.json"


class GraphKMCVisualizationTests(unittest.TestCase):
    def test_fixed_seed_trace_is_reproducible_and_mass_conservative(self) -> None:
        options = {
            "site_count": 12,
            "seed": 314159,
            "warmup_layers": 1,
            "measurement_layers": 2,
        }
        first = generate_representative_trace(**options)
        second = generate_representative_trace(**options)
        self.assertEqual(first, second)
        measurement = first["measurement"]
        self.assertEqual(measurement["target_removals"], 24)
        self.assertEqual(sum(measurement["removal_counts_by_site"]), 24)
        self.assertEqual(measurement["event_counts"]["remove"], 24)
        self.assertEqual(len(measurement["events"]), measurement["event_count"])
        self.assertEqual(measurement["removal_count_summary"]["mean"], 2.0)
        times = [
            event["time_from_measurement_start_s"]
            for event in measurement["events"]
        ]
        self.assertEqual(times, sorted(times))
        self.assertGreater(times[0], 0.0)
        self.assertLessEqual(times[-1], measurement["elapsed_s"])
        self.assertIn("no trench geometry", first["notice"])

    def test_trace_configuration_validation(self) -> None:
        with self.assertRaisesRegex(ValueError, "at least three"):
            generate_representative_trace(site_count=2)
        with self.assertRaisesRegex(ValueError, "non-negative"):
            generate_representative_trace(seed=-1)
        with self.assertRaisesRegex(ValueError, "positive integer"):
            generate_representative_trace(measurement_layers=0)

    def test_end_to_end_writes_two_pngs_and_strict_trace_json(self) -> None:
        payload = load_sweep_payload(SWEEP_JSON)
        self.assertEqual(payload["schema_version"], 1)
        with tempfile.TemporaryDirectory() as directory:
            directory_path = Path(directory)
            summary = directory_path / "summary.png"
            evolution = directory_path / "events.png"
            trace_path = directory_path / "trace.json"
            trace = create_graph_kmc_visualizations(
                SWEEP_JSON,
                summary_figure=summary,
                event_figure=evolution,
                trace_json=trace_path,
                trace_site_count=12,
                trace_seed=2718,
                trace_warmup_layers=1,
                trace_measurement_layers=2,
            )
            for figure in (summary, evolution):
                self.assertTrue(figure.is_file())
                self.assertGreater(figure.stat().st_size, 10_000)
                self.assertEqual(figure.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")
            raw_json = trace_path.read_text(encoding="utf-8")
            saved = json.loads(raw_json)
            self.assertEqual(saved, trace)
            self.assertNotIn("NaN", raw_json)
            self.assertNotIn("Infinity", raw_json)
            self.assertEqual(saved["configuration"]["site_count"], 12)
            self.assertEqual(saved["configuration"]["seed"], 2718)
            self.assertEqual(saved["notice"], SURFACE_PATCH_CAVEAT)


if __name__ == "__main__":
    unittest.main()

"""Shared permissive numerical defaults for prototype simulations.

These defaults intentionally favour fast model development over high-accuracy
production results.  Individual solvers may expose additional limits, but the
same tolerance vocabulary is used by the integration driver.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class NumericalSettings:
    linear_relative_tolerance: float = 1.0e-4
    linear_absolute_tolerance: float = 1.0e-8
    nonlinear_relative_tolerance: float = 5.0e-3
    steady_state_relative_tolerance: float = 1.0e-3
    mass_balance_relative_tolerance: float = 5.0e-2
    maximum_iterations: int = 500
    maximum_nonlinear_iterations: int = 30
    maximum_fractional_state_change: float = 0.10
    minimum_time_step_s: float = 1.0e-9
    maximum_time_step_s: float = 1.0

    def __post_init__(self) -> None:
        positive_floats = (
            "linear_relative_tolerance",
            "linear_absolute_tolerance",
            "nonlinear_relative_tolerance",
            "steady_state_relative_tolerance",
            "mass_balance_relative_tolerance",
            "maximum_fractional_state_change",
            "minimum_time_step_s",
            "maximum_time_step_s",
        )
        for name in positive_floats:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.maximum_iterations < 1 or self.maximum_nonlinear_iterations < 1:
            raise ValueError("iteration limits must be positive")
        if self.minimum_time_step_s > self.maximum_time_step_s:
            raise ValueError("minimum_time_step_s must not exceed maximum_time_step_s")
        if self.maximum_fractional_state_change > 1.0:
            raise ValueError("maximum_fractional_state_change must not exceed 1")

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


LOOSE_NUMERICS = NumericalSettings()

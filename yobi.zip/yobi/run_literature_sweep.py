#!/usr/bin/env python3
"""CLI for the traceable literature-value GAP-FILL null model."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

from literature_parameters import LITERATURE_ETCH_PRESETS
from literature_sweep import (
    DEFAULT_LITERATURE_PRESET_NAMES,
    LiteratureSweepConfig,
    nominal_preset_names,
    preset_names_for_material,
    run_literature_sweep,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run film-specific published blanket WER values through the 1-D "
            "and 2-D GAP-FILL null models. This is not a wet-process recipe."
        )
    )
    parser.add_argument(
        "--geometry",
        choices=tuple(GEOMETRY_PRESETS),
        action="append",
        help="repeat to select geometries (default: both straight-wall standards)",
    )
    parser.add_argument(
        "--preset",
        choices=tuple(LITERATURE_ETCH_PRESETS),
        action="append",
        help="repeat to select film presets",
    )
    parser.add_argument(
        "--material",
        choices=("SiN", "SiCN", "SiOCN"),
        action="append",
        help="select every preset for one material; ignored when --preset is used",
    )
    parser.add_argument(
        "--nominal-only",
        action="store_true",
        help="select the nominal-rate film for each selected material",
    )
    parser.add_argument(
        "--solution-temperature-k",
        type=float,
        default=298.15,
        help="independent HF solution bulk temperature [K]",
    )
    parser.add_argument(
        "--substrate-temperature-k",
        type=float,
        default=298.15,
        help="independent Si substrate backside temperature [K]",
    )
    parser.add_argument("--grid-spacing-nm", type=float, default=0.5)
    parser.add_argument("--reservoir-height-nm", type=float, default=10.0)
    parser.add_argument(
        "--maximum-fractional-front-change",
        type=float,
        default=0.50,
        help="loose per-step interface-cell removal limit (default: 0.50)",
    )
    parser.add_argument(
        "--skip-2d",
        action="store_true",
        help="run only timescale, thermal, and flat-front calculations",
    )
    parser.add_argument(
        "--maximum-history-points",
        type=int,
        default=160,
        help="maximum downsampled 2-D history records saved per case",
    )
    parser.add_argument(
        "--comparison-exposure-s",
        type=float,
        default=3600.0,
        help="common exposure time for residual/profile comparison (default: 3600)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent case processes; 0 selects up to 4 automatically",
    )
    parser.add_argument(
        "--list-presets",
        action="store_true",
        help="print preset descriptions and exit",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="ordinary JSON output path; no hash-based storage is used",
    )
    return parser


def _selected_presets(args: argparse.Namespace) -> tuple[str, ...]:
    if args.preset:
        selected = tuple(dict.fromkeys(args.preset))
    elif args.material:
        materials = tuple(dict.fromkeys(args.material))
        selected = tuple(
            name
            for material in materials
            for name in preset_names_for_material(material)
        )
    else:
        selected = DEFAULT_LITERATURE_PRESET_NAMES
    if args.nominal_only:
        nominal = set(nominal_preset_names())
        selected = tuple(name for name in selected if name in nominal)
    if not selected:
        raise ValueError("preset selection is empty")
    return selected


def _preset_listing() -> dict[str, object]:
    return {
        key: {
            "material": preset.material,
            "rate_band": preset.rate_band,
            "film_description": preset.film_description,
            "planar_rate_nm_min": preset.planar_rate_nm_min,
            "reported_solution": preset.reported_solution,
            "rate_source": preset.rate_source_key,
        }
        for key, preset in LITERATURE_ETCH_PRESETS.items()
    }


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    if args.list_presets:
        payload: dict[str, object] = {"presets": _preset_listing()}
    else:
        geometries = tuple(dict.fromkeys(args.geometry or DEFAULT_GEOMETRY_NAMES))
        presets = _selected_presets(args)
        case_count = len(geometries) * len(presets)
        if args.workers < 0:
            raise ValueError("workers must be zero or a positive integer")
        workers = (
            min(4, os.cpu_count() or 1, case_count)
            if args.workers == 0
            else min(args.workers, case_count)
        )
        config = LiteratureSweepConfig(
            geometries=geometries,
            presets=presets,
            solution_bulk_temperature_K=args.solution_temperature_k,
            substrate_backside_temperature_K=args.substrate_temperature_k,
            grid_spacing_nm=args.grid_spacing_nm,
            reservoir_height_nm=args.reservoir_height_nm,
            include_2d=not args.skip_2d,
            maximum_history_points=args.maximum_history_points,
            maximum_fractional_front_change=(
                args.maximum_fractional_front_change
            ),
            comparison_exposure_s=args.comparison_exposure_s,
            parallel_workers=workers,
        )
        payload = run_literature_sweep(config)
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    return payload


if __name__ == "__main__":
    main()

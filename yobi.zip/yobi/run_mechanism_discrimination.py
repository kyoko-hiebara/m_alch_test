#!/usr/bin/env python3
"""Run the multicore, burden-matched residue-mechanism diagnostics."""

from __future__ import annotations

import argparse
import csv
from dataclasses import replace
import json
import os
from pathlib import Path
from typing import Mapping, Sequence


# Limit native numerical libraries before importing NumPy/SciPy through the
# model.  Multiprocessing supplies the outer parallelism for this calculation.
for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ[_thread_variable] = "1"


from mechanism_discrimination import (  # noqa: E402
    CAUSE_PROFILES,
    MechanismDiscriminationConfig,
    run_mechanism_discrimination,
    save_mechanism_discrimination_json,
)


RESULT_NAME = "mechanism_discrimination_results.json"
CSV_NAME = "cause_diagnosis_table.csv"
EXPERIMENT_CSV_NAME = "experimental_cause_decision_table.csv"
README_NAME = "README_JA.md"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Calibrate nine equal-burden residue hypotheses, apply paired "
            "temperature/HF/rinse/geometry/second-WET probes, and write "
            "mechanism fingerprints plus diagnostic figures."
        )
    )
    parser.add_argument(
        "--mode",
        choices=("smoke", "quick", "full"),
        default="quick",
        help=(
            "smoke=one seed/coarse grid/three calibration candidates; "
            "quick=two seeds/1.7 nm/100 bootstrap; "
            "full=three seeds/1.4 nm/400 bootstrap"
        ),
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="worker processes; 0 selects up to eight automatically",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/mechanism_discrimination"),
        help="directory for JSON, CSV, README and the three PNG figures",
    )
    return parser


def _three_candidate_overrides() -> dict[str, tuple[float, ...]]:
    """Retain broad low/centre/high calibration coverage for smoke mode."""

    result: dict[str, tuple[float, ...]] = {}
    for cause_id, profile in CAUSE_PROFILES.items():
        values = profile.calibration_candidates
        selected = (values[0], values[len(values) // 2], values[-1])
        # Preserve order while remaining robust if a future profile repeats an
        # endpoint or contains fewer than three distinct values.
        result[cause_id] = tuple(dict.fromkeys(float(value) for value in selected))
    return result


def _requested_case_count(config: MechanismDiscriminationConfig) -> int:
    calibration = len(config.replicate_seeds) * len(config.presets) * sum(
        len(config.calibration_candidates(cause_id))
        for cause_id in config.cause_ids
    )
    probes = (
        len(config.cause_ids)
        * len(config.presets)
        * len(config.probes)
        * 3
        * len(config.replicate_seeds)
    )
    return calibration + probes


def _config(mode: str, workers: int) -> MechanismDiscriminationConfig:
    if workers < 0:
        raise ValueError("workers must be zero or positive")
    if mode == "smoke":
        config = MechanismDiscriminationConfig(
            replicate_seeds=(271828,),
            calibration_candidates_override=_three_candidate_overrides(),
            bootstrap_samples=20,
            grid_spacing_nm=3.0,
            primary_sync_steps=12,
            maximum_events=15_000,
            parallel_workers=1,
        )
    elif mode == "quick":
        config = MechanismDiscriminationConfig(
            replicate_seeds=(271828, 314159),
            bootstrap_samples=100,
            grid_spacing_nm=1.7,
            parallel_workers=1,
        )
    elif mode == "full":
        config = MechanismDiscriminationConfig(
            replicate_seeds=(271828, 314159, 161803),
            bootstrap_samples=400,
            grid_spacing_nm=1.4,
            parallel_workers=1,
        )
    else:  # Defensive for direct callers; argparse already constrains this.
        raise ValueError("mode must be smoke, quick or full")

    requested = _requested_case_count(config)
    resolved_workers = (
        min(8, os.cpu_count() or 1, requested)
        if workers == 0
        else min(workers, requested)
    )
    return replace(config, parallel_workers=max(1, resolved_workers))


_CSV_PREFERRED_FIELDS = (
    "cause_id",
    "cause_label_ja",
    "preset_id",
    "material",
    "strongest_probe",
    "identifiability",
    "ambiguous_with",
    "nearest_other_cause",
    "nearest_distance",
    "probe_strengths",
    "burden_directions",
    "raw_probe_effects_percentage_points",
    "primary_passivated_fraction_at_centre",
    "primary_passivation_cluster_fraction_at_centre",
    "primary_bottom_remaining_fraction_at_centre",
    "primary_wall_remaining_fraction_at_centre",
    "native_wall_longest_run_at_centre",
    "deposit_wall_longest_run_at_centre",
    "maximum_gas_fraction_at_centre",
    "deepest_wetted_fraction_at_centre",
    "expected_signature",
)


def _csv_cell(value: object) -> object:
    if value is None:
        return ""
    if isinstance(value, (Mapping, list, tuple)):
        return json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
            separators=(",", ":"),
        )
    return value


def _write_diagnosis_csv(payload: Mapping[str, object], path: Path) -> Path:
    raw_rows = payload.get("diagnosis_table", [])
    rows = [dict(row) for row in raw_rows if isinstance(row, Mapping)] if isinstance(
        raw_rows, Sequence
    ) and not isinstance(raw_rows, (str, bytes)) else []
    available = {key for row in rows for key in row}
    fieldnames = [key for key in _CSV_PREFERRED_FIELDS if key in available]
    fieldnames.extend(sorted(available.difference(fieldnames)))
    if not fieldnames:
        fieldnames = list(_CSV_PREFERRED_FIELDS)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_cell(row.get(key)) for key in fieldnames})
    return path


_EXPERIMENT_EFFECT_FIELDS = (
    "liquid_temperature_residue_reduction_pp",
    "substrate_temperature_residue_reduction_pp",
    "hf_concentration_residue_reduction_pp",
    "rinse_delay_deposit_increase_pp",
    "narrow_width_residue_penalty_pp",
    "depth_residue_penalty_pp",
    "second_wet_residue_reduction_pp",
)


def _write_experimental_decision_csv(
    payload: Mapping[str, object], path: Path
) -> Path:
    """Write a flat, experiment-facing cause table with percentage-point effects."""

    raw_rows = payload.get("diagnosis_table", [])
    diagnoses = [row for row in raw_rows if isinstance(row, Mapping)] if isinstance(
        raw_rows, Sequence
    ) and not isinstance(raw_rows, (str, bytes)) else []
    raw_calibrations = payload.get("calibrations", [])
    calibrations = {
        (str(item.get("cause_id", "")), str(item.get("preset_id", ""))): item
        for item in raw_calibrations
        if isinstance(item, Mapping)
    } if isinstance(raw_calibrations, Sequence) and not isinstance(
        raw_calibrations, (str, bytes)
    ) else {}
    morphology_fields = (
        "primary_passivation_cluster_fraction_at_centre",
        "primary_bottom_remaining_fraction_at_centre",
        "primary_wall_remaining_fraction_at_centre",
        "native_wall_longest_run_at_centre",
        "deposit_wall_longest_run_at_centre",
        "maximum_gas_fraction_at_centre",
        "deepest_wetted_fraction_at_centre",
    )
    fieldnames = [
        "cause_id", "cause_label_ja", "material", "preset_id",
        "calibrated_burden", "calibration_target_reached",
        *_EXPERIMENT_EFFECT_FIELDS, *morphology_fields,
        "identifiability", "ambiguous_with", "expected_signature",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for row in diagnoses:
            key = (str(row.get("cause_id", "")), str(row.get("preset_id", "")))
            calibration = calibrations.get(key, {})
            effects = row.get("raw_probe_effects_percentage_points", {})
            effects = effects if isinstance(effects, Mapping) else {}
            flat: dict[str, object] = {
                "cause_id": key[0],
                "cause_label_ja": row.get("cause_label_ja", ""),
                "material": row.get("material", ""),
                "preset_id": key[1],
                "calibrated_burden": calibration.get("apparent_burden", ""),
                "calibration_target_reached": calibration.get("target_reached", ""),
                "identifiability": row.get("identifiability", ""),
                "ambiguous_with": _csv_cell(row.get("ambiguous_with", [])),
                "expected_signature": row.get("expected_signature", ""),
            }
            flat.update({field: effects.get(field, "") for field in _EXPERIMENT_EFFECT_FIELDS})
            flat.update({field: row.get(field, "") for field in morphology_fields})
            writer.writerow(flat)
    return path


def _representative_cases(payload: Mapping[str, object]) -> list[dict[str, object]]:
    """Select one centre-condition scalar morphology row per cause/material."""

    raw = payload.get("probe_cases", [])
    if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
        return []
    selected: list[dict[str, object]] = []
    seen: set[tuple[str, str]] = set()
    # Width-centre cases use the explicit reference geometry (8 nm x 175 nm).
    preferred = [
        case for case in raw
        if isinstance(case, Mapping)
        and case.get("status") == "ok"
        and case.get("probe_name") == "width"
        and case.get("probe_level") == "centre"
    ]
    fallback = [
        case for case in raw
        if isinstance(case, Mapping)
        and case.get("status") == "ok"
        and case.get("probe_level") == "centre"
    ]
    for case in preferred + fallback:
        key = (str(case.get("cause_id", "")), str(case.get("preset_id", "")))
        if key in seen:
            continue
        seen.add(key)
        selected.append(dict(case))
    return selected


def _ambiguity_pairs(payload: Mapping[str, object]) -> list[str]:
    raw = payload.get("diagnosis_table", [])
    if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
        return []
    pairs: set[tuple[str, str, str]] = set()
    for row in raw:
        if not isinstance(row, Mapping) or row.get("identifiability") != "ambiguous":
            continue
        cause = str(row.get("cause_id", "unknown"))
        scope = str(row.get("material", row.get("preset_id", "unknown")))
        others = row.get("ambiguous_with", [])
        if not isinstance(others, Sequence) or isinstance(others, (str, bytes)):
            continue
        for other in others:
            left, right = sorted((cause, str(other)))
            pairs.add((scope, left, right))
    return [f"{scope}: {left} ↔ {right}" for scope, left, right in sorted(pairs)]


def _readme(payload: Mapping[str, object], mode: str) -> str:
    quality_raw = payload.get("quality_summary", {})
    quality = quality_raw if isinstance(quality_raw, Mapping) else {}
    config_raw = payload.get("config", {})
    config = config_raw if isinstance(config_raw, Mapping) else {}
    calibration_requested = int(quality.get("requested_calibration_cases", 0))
    probe_requested = int(quality.get("requested_probe_cases", 0))
    successful = int(quality.get("successful_case_count", 0))
    failed = int(quality.get("failed_case_count", 0))
    reached = int(quality.get("calibrations_within_0p10_burden", 0))
    calibration_count = int(quality.get("calibration_count", 0))
    ambiguities = _ambiguity_pairs(payload)

    lines = [
        "# 残渣原因を識別するための機構fingerprint計算",
        "",
        f"実行モード: `{mode}`",
        "",
        "同程度の見かけ残渣量へ校正した原因仮説に、温度・HF濃度・rinse待ち・"
        "trench幅/深さ・second-WETのpaired probeを与えた未校正screeningです。",
        "製造recipeや検証済みの因果診断器ではありません。",
        "",
        "## 実行件数",
        "",
        f"- calibration: {calibration_requested} cases",
        f"- diagnostic probes: {probe_requested} cases",
        f"- 成功: {successful} cases / 失敗: {failed} cases",
        f"- 共通KMC seeds: {config.get('replicate_seeds', [])}",
        f"- worker processes: {config.get('parallel_workers', 1)}",
        "",
        "## Burden matching",
        "",
        f"目標残渣量との差が0.10以内だった校正は {reached} / {calibration_count} 件です。",
        "目標へ届かなかったcause/materialは、fingerprint強度の比較前に校正範囲を再検討してください。",
        "",
        "## 主な曖昧性",
        "",
    ]
    if ambiguities:
        lines.extend(f"- {item}" for item in ambiguities[:24])
        if len(ambiguities) > 24:
            lines.append(f"- ほか {len(ambiguities) - 24} pairs（CSV/JSON参照）")
    else:
        lines.append("- 現在のmodel距離閾値では曖昧pairは報告されませんでした。")

    lines.extend(
        (
            "",
            "## 原因判定の読み方",
            "",
            "- 液温依存は反応/passivation寄りですが、単独では固有反応・生成物阻害・膜質差を確定できません。",
            "- HF依存は供給律速の候補です。bottom/top HF比と幅/深さcontrolを併用します。",
            "- rinse delayでprimary matrixではなくdepositだけが増えればdry-down/再付着寄りです。",
            "- 幅を狭めた時の残渣増加と非zero gasを組み合わせて濡れ/gas仮説を判定します。深さ単独は非特異的です。",
            "- primary後のnative wall連続残渣はwall膜質、matrix除去後のdeposit wall連続残渣はdry-down/wall affinityです。",
            "- dry-downとwall affinityは現在のprobeではほぼ同じため、表面前処理または短delay/quench対照が必要です。",
            "",
        )
    )

    lines.extend(("", "## 推奨probe順序", ""))
    greedy = payload.get("greedy_probe_order", [])
    if isinstance(greedy, Sequence) and not isinstance(greedy, (str, bytes)):
        for item in greedy:
            if not isinstance(item, Mapping):
                continue
            material = str(item.get("material", item.get("preset_id", "unknown")))
            steps = item.get("steps", [])
            ordered = [
                str(step.get("probe", "unknown"))
                for step in steps
                if isinstance(step, Mapping)
            ] if isinstance(steps, Sequence) and not isinstance(steps, (str, bytes)) else []
            lines.append(f"- {material}: " + " → ".join(ordered))
    if lines[-1] == "":
        lines.append("- 順序を計算できませんでした。")

    lines.extend(
        (
            "",
            "## 出力",
            "",
            f"- `{RESULT_NAME}`: 全case、校正、fingerprint、cause間距離",
            f"- `{CSV_NAME}`: 原因判定表",
            f"- `{EXPERIMENT_CSV_NAME}`: 実験用のflatな依存性・形態判定表",
            "- `mechanism_fingerprint_heatmap.png`: probe依存fingerprint",
            "- `mechanism_separability.png`: cause間距離とgreedy probe順",
            "- `mechanism_morphology_examples.png`: native/deposit壁・底形態指標",
            "",
            "温度/HF/寸法は主にprimary matrix、rinse delay/wall affinityはpost-HF depositの"
            "stage-resolved指標で解釈します。近接causeや校正不良caseは判定保留にしてください。",
            "",
        )
    )
    return "\n".join(lines)


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        config = _config(args.mode, args.workers)
    except ValueError as exc:
        parser.error(str(exc))

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    requested = _requested_case_count(config)
    print(
        f"mechanism-discrimination {args.mode}: {requested} requested cases, "
        f"{config.parallel_workers} workers",
        flush=True,
    )

    payload = run_mechanism_discrimination(config)
    payload["execution"] = {
        "mode": args.mode,
        "requested_case_count_before_execution": requested,
        "native_threads_per_worker": 1,
    }
    # The visualization accepts scalar morphology rows via the generic cases
    # alias.  Keep one centre-condition example per cause/material rather than
    # duplicating the complete probe table in the JSON.
    payload["cases"] = _representative_cases(payload)

    result_path = output_dir / RESULT_NAME
    # Persist the expensive strict-finite result before plotting so a rendering
    # failure cannot discard a completed multicore calculation.
    save_mechanism_discrimination_json(payload, result_path)

    csv_path = _write_diagnosis_csv(payload, output_dir / CSV_NAME)
    experiment_csv_path = _write_experimental_decision_csv(
        payload, output_dir / EXPERIMENT_CSV_NAME
    )

    from mechanism_discrimination_visualization import (  # noqa: E402
        plot_mechanism_discrimination_visualizations,
    )

    figures = plot_mechanism_discrimination_visualizations(
        result_path,
        output_dir,
        dpi=300,
    )
    readme_path = output_dir / README_NAME
    readme_path.write_text(_readme(payload, args.mode), encoding="utf-8")
    payload["artifacts"] = {
        "results_json": result_path.name,
        "cause_diagnosis_table_csv": csv_path.name,
        "experimental_cause_decision_table_csv": experiment_csv_path.name,
        "readme_ja": readme_path.name,
        **{key: Path(value).name for key, value in figures.items()},
    }
    save_mechanism_discrimination_json(payload, result_path)

    quality = payload.get("quality_summary", {})
    assert isinstance(quality, Mapping)
    print(
        f"done: successful={quality.get('successful_case_count', 0)}, "
        f"failed={quality.get('failed_case_count', 0)}, "
        f"calibrated={quality.get('calibrations_within_0p10_burden', 0)}/"
        f"{quality.get('calibration_count', 0)}",
        flush=True,
    )
    return payload


if __name__ == "__main__":
    main()

from __future__ import annotations

import json
import math
import tempfile
import unittest
from pathlib import Path

from persistent_deposit_sweep import (
    AFS_WATER_SOLUBILITY_MOL_M3,
    PersistentDepositSweepConfig,
    afs_solubility_from_hf_mol_m3,
    run_persistent_deposit_sweep,
)
from run_persistent_deposit_sweep import main


SIN_PRESET = "sin_barcellona_b_0p55wt"


def coarse_config(**overrides: object) -> PersistentDepositSweepConfig:
    """Return a fast case that still advances the real 2-D front solver."""
    values: dict[str, object] = {
        "geometries": ("10_8_180",),
        "presets": (SIN_PRESET,),
        "grid_spacing_nm": 5.0,
        "reservoir_height_nm": 5.0,
        "target_remaining_gap_fill_fraction": 0.90,
        "maximum_time_over_planar_clear": 0.08,
        "requested_steps_per_planar_clear": 4,
        "cumulative_capture_fractions": (0.01,),
        "solution_bulk_temperature_K": 295.0,
        "substrate_backside_temperature_K": 320.0,
        "allow_partial_primary_for_sensitivity": True,
        "parallel_workers": 1,
    }
    values.update(overrides)
    return PersistentDepositSweepConfig(**values)


class PersistentDepositSweepTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = run_persistent_deposit_sweep(coarse_config())
        cls.case = cls.payload["cases"][0]
        cls.branches = {
            branch["branch_id"]: branch for branch in cls.case["branches"]
        }

    def test_afs_solubility_fit_uses_mol_per_m3_and_rejects_bad_inputs(self) -> None:
        self.assertAlmostEqual(
            afs_solubility_from_hf_mol_m3(0.0),
            AFS_WATER_SOLUBILITY_MOL_M3,
        )
        # Frayret fit at 5 M HF: 0.0017*5^2 - 0.0578*5 + 1.19 M.
        self.assertAlmostEqual(
            afs_solubility_from_hf_mol_m3(5_000.0),
            943.5,
        )
        for invalid in (-1.0, math.nan, math.inf):
            with self.subTest(invalid=invalid):
                with self.assertRaisesRegex(ValueError, "non-negative"):
                    afs_solubility_from_hf_mol_m3(invalid)

    def test_config_normalizes_capture_fractions_and_validates_scope(self) -> None:
        normalized = coarse_config(
            cumulative_capture_fractions=(0.10, 0.01, 0.10)
        )
        self.assertEqual(normalized.cumulative_capture_fractions, (0.01, 0.10))

        invalid_updates = (
            ({"geometries": ()}, "cannot be empty"),
            ({"geometries": ("missing",)}, "unknown geometries"),
            ({"presets": ("missing",)}, "unknown presets"),
            ({"grid_spacing_nm": 0.0}, "finite and positive"),
            ({"maximum_fractional_front_change": 1.01}, "cannot exceed one"),
            ({"target_remaining_gap_fill_fraction": 1.0}, "below one"),
            ({"requested_steps_per_planar_clear": 0}, "must be positive"),
            ({"cumulative_capture_fractions": (0.0,)}, r"within \(0, 1\]"),
            ({"parallel_workers": 0}, "positive integer"),
        )
        for updates, message in invalid_updates:
            with self.subTest(updates=updates):
                with self.assertRaisesRegex(ValueError, message):
                    coarse_config(**updates)

    def test_real_case_schema_records_null_wet_route_and_independent_temperatures(self) -> None:
        payload = self.payload
        case = self.case
        primary = case["primary_HF"]

        self.assertEqual(payload["schema_version"], 1)
        self.assertFalse(payload["calibrated_deposit_kinetics"])
        self.assertEqual(payload["summary"]["case_count"], 1)
        self.assertEqual(case["case_id"], f"10_8_180__{SIN_PRESET}")
        self.assertEqual(case["material"], "SiN")
        self.assertEqual(case["boundary_temperatures_K"]["solution_bulk"], 295.0)
        self.assertEqual(case["boundary_temperatures_K"]["substrate_backside"], 320.0)
        self.assertFalse(
            case["boundary_temperatures_K"]["kinetic_temperature_correction_applied"]
        )
        self.assertGreater(primary["steps"], 0)
        self.assertGreater(primary["maximum_product_mol_m3"], 0.0)
        self.assertAlmostEqual(
            primary["generation_to_actual_removal_ratio"], 1.0
        )
        self.assertLess(primary["maximum_saturation_ratio"], 1.0)
        self.assertEqual(primary["wet_deposit"]["total_inventory_native"], 0.0)
        self.assertTrue(
            payload["summary"][
                "literature_csat_wet_precipitation_is_null_in_all_cases"
            ]
        )
        self.assertEqual(len(case["branches"]), 6)
        self.assertTrue(case["convergence"]["reactant"])
        self.assertTrue(case["convergence"]["product"])
        self.assertTrue(case["convergence"]["wet_precipitation_active_set"])

        map_data = case["representative_2d_map"]
        self.assertEqual(
            map_data["branch_id"], "wall_selective__meniscus_capture_0p01"
        )
        collector = map_data["deposit"]
        lengths = {key: len(values) for key, values in collector.items()}
        self.assertEqual(len(set(lengths.values())), 1)
        self.assertGreater(next(iter(lengths.values())), 0)

    def test_immediate_rinse_meniscus_capture_and_post_wet_are_monotonic(self) -> None:
        immediate = self.branches["uniform_affinity__immediate_DI_before_dry"]
        endpoint = self.branches["uniform_affinity__endpoint_solution_dry"]
        meniscus = self.branches["uniform_affinity__meniscus_capture_0p01"]

        immediate_inventory = immediate["before_post_wet"]["total_inventory_native"]
        endpoint_inventory = endpoint["before_post_wet"]["total_inventory_native"]
        meniscus_inventory = meniscus["before_post_wet"]["total_inventory_native"]
        self.assertEqual(immediate_inventory, 0.0)
        self.assertGreater(endpoint_inventory, immediate_inventory)
        self.assertGreater(meniscus_inventory, endpoint_inventory)

        post = meniscus["post_treatment_endpoints"]
        totals = {
            key: value["final_deposit"]["total_inventory_native"]
            for key, value in post.items()
        }
        self.assertAlmostEqual(totals["no_post_wet"], meniscus_inventory)
        self.assertLess(totals["second_WET_30s"], totals["DI_30s_after_dry"])
        self.assertLess(totals["DI_30s_after_dry"], totals["HF_control_30s"])
        self.assertLess(totals["HF_control_30s"], totals["no_post_wet"])
        for endpoint_data in post.values():
            dissolution = endpoint_data["dissolution"]
            self.assertGreaterEqual(dissolution["removed_inventory_native"], 0.0)
            self.assertGreaterEqual(
                endpoint_data["final_deposit"]["total_inventory_native"], 0.0
            )

    def test_wall_selective_affinity_redistributes_but_does_not_create_inventory(self) -> None:
        uniform = self.branches["uniform_affinity__meniscus_capture_0p01"]
        selective = self.branches["wall_selective__meniscus_capture_0p01"]
        uniform_deposit = uniform["before_post_wet"]
        selective_deposit = selective["before_post_wet"]

        self.assertAlmostEqual(
            uniform_deposit["total_inventory_native"],
            selective_deposit["total_inventory_native"],
        )
        self.assertGreaterEqual(
            selective_deposit["wall_fraction_of_deposit"],
            uniform_deposit["wall_fraction_of_deposit"],
        )
        self.assertLessEqual(
            selective_deposit["bottom_fraction_of_deposit"],
            uniform_deposit["bottom_fraction_of_deposit"],
        )

    def test_cli_writes_plain_json_and_representative_figure(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "deposit.json"
            figure = Path(directory) / "deposit.png"
            payload = main(
                [
                    "--geometry", "10_8_180",
                    "--preset", SIN_PRESET,
                    "--grid-spacing-nm", "5",
                    "--reservoir-height-nm", "5",
                    "--target-remaining", "0.9",
                    "--maximum-clear-time", "0.08",
                    "--steps-per-clear", "4",
                    "--capture-fraction", "0.01",
                    "--solution-temperature-k", "294",
                    "--substrate-temperature-k", "322",
                    "--allow-partial-primary",
                    "--workers", "1",
                    "--output", str(output),
                    "--figure", str(figure),
                ]
            )
            raw = output.read_text(encoding="utf-8")
            saved = json.loads(raw)
            self.assertEqual(saved, payload)
            self.assertNotIn("NaN", raw)
            self.assertNotIn("Infinity", raw)
            self.assertTrue(figure.is_file())
            self.assertGreater(figure.stat().st_size, 0)
            self.assertEqual(figure.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")
            temperatures = saved["cases"][0]["boundary_temperatures_K"]
            self.assertEqual(temperatures["solution_bulk"], 294.0)
            self.assertEqual(temperatures["substrate_backside"], 322.0)


if __name__ == "__main__":
    unittest.main()

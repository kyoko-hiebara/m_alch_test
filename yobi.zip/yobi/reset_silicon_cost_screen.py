"""Does the reset-cycle recommendation survive when each reset spends Si?

The decay-robust recipe screen ranked recipes by worst-case residue
removal and credited the chemical reset step with zero intrinsic removal,
calling that conservative.  For the substrate the sign is opposite: every
oxidising wet reset (O3-DIW, SC1, SPM) grows a self-limiting chemical
oxide on every silicon surface the liquid reaches, and the following HF
pulse strips it.  The silicon is spent at oxidation time -- the strip only
carries it away -- so each reset consumes a fixed depth of the surface the
recipe is preparing for epitaxy, and a recipe that wins on residue removal
can lose on the surface it leaves behind.

This screen prices that cost.  Removal numbers are taken unchanged from
``pulsed_recipe_screen`` (worst case across the four decay-law x cause
scenarios); the new axis is cumulative silicon recession,
``n_resets x (Vm(Si)/Vm(SiO2)) x t_ox``, swept over the assumed
self-limiting oxide thickness because no wet chemical-oxide thickness has
been measured for this process.  Recipes are re-ranked under explicit
silicon budgets, and the marginal price of finer pulsing is reported as
nm of silicon per extra nm of residue removed.

No serial strip dead time is charged: the reset oxide grows on silicon
walls, not on top of the bottom residue, so the post-reset pulse attacks
residue and wall oxide in parallel, and the transport null model already
shows HF supply is not the bottleneck.  What the strip does cost is
silicon, which is exactly what is counted here.

**Boundaries.**  The oxide thickness per reset is an assumed band
(0.5--1.5 nm) covering commonly reported self-limiting wet chemical
oxides, not a measured value.  Full regrowth every cycle is taken (the
recession-maximising choice), zero direct silicon etch by the reset
liquid itself is taken (optimistic; SC1 has a finite silicon etch rate),
and the residue-side credit of the reset (full state reset, zero
intrinsic removal) is inherited unchanged from the recipe screen.  The
fused-silica density is the recession-maximising choice within the
oxide-density uncertainty: chemical oxides are usually less dense, which
would lower the consumed-silicon ratio.  Recession applies per reset a
silicon surface actually sees: in the fixed trench geometry (device
dimensions are a constraint, not a lever) silicon walls above a bottom
residue see every reset, while the silicon under the pad is shielded
until clear, so recession is reported per number of resets seen and the
headline full-exposure value is the wall-side worst case.  Spacer
pull-back by the same oxidise-strip mechanism is the subject of the
material-maximin follow-up, not priced here.  Roughness, pitting, and
epitaxy quality are not modelled.  Nothing here is a process recipe.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any, Mapping, Sequence

from pulsed_recipe_screen import (
    ETCH,
    EXCHANGE,
    RESET,
    Recipe,
    RecipeOutcome,
    cycles_to_clear,
    evaluate_recipes,
)


SCHEMA_VERSION = "reset-silicon-cost-screen/v1"
MODEL_NOTICE = (
    "Prices the silicon consumed by oxidising reset steps: each reset "
    "grows a self-limiting chemical oxide on exposed silicon and the next "
    "HF pulse strips it, so recession = n_resets x (Vm(Si)/Vm(SiO2)) x "
    "t_ox. The oxide thickness is an assumed 0.5-1.5 nm band, not a "
    "measured value; removal numbers are inherited unchanged from "
    "pulsed_recipe_screen. Recession is the wall-side full-exposure worst "
    "case; silicon under the residue is shielded until clear. Not a "
    "process recipe."
)

# Declared constants for the consumed-silicon ratio.  Standard handbook
# room-temperature values; the derived ratio moves by ~2% across quoted
# density ranges, negligible against the 3x oxide-thickness band swept
# below.  The fused-silica density is the recession-maximising choice:
# less dense chemical oxides would give a smaller ratio.
SILICON_MOLAR_MASS_G_MOL = 28.0855
SILICON_DENSITY_G_CM3 = 2.329
AMORPHOUS_SIO2_MOLAR_MASS_G_MOL = 60.0843
AMORPHOUS_SIO2_DENSITY_G_CM3 = 2.196

DEFAULT_OXIDE_THICKNESSES_NM = (0.5, 1.0, 1.5)
DEFAULT_SILICON_BUDGETS_NM = (0.5, 1.0, 2.0)
DEFAULT_PAD_THICKNESSES_NM = (1.0, 2.0, 3.0, 5.0)
DEFAULT_MATCHED_ACTIVE_TIME_S = 180.0

# The structural chain along which pulsing gets finer at matched active
# etch time; used for the marginal nm-Si-per-nm-residue table.
MARGINAL_CHAIN = (
    "continuous_180s",
    "cycle_3x60s_reset",
    "cycle_6x30s_reset",
)


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def _finite_nonnegative(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    return number


def silicon_per_oxide_thickness_ratio() -> float:
    """Thickness of silicon consumed per unit thickness of oxide grown.

    The molar-volume ratio ``Vm(Si) / Vm(SiO2)``; approximately 0.44,
    the standard oxidation bookkeeping value.
    """

    silicon_molar_volume = SILICON_MOLAR_MASS_G_MOL / SILICON_DENSITY_G_CM3
    oxide_molar_volume = (
        AMORPHOUS_SIO2_MOLAR_MASS_G_MOL / AMORPHOUS_SIO2_DENSITY_G_CM3
    )
    return silicon_molar_volume / oxide_molar_volume


@dataclass(frozen=True)
class ResetOxidationAssumptions:
    """Declared per-reset oxidation assumptions (none of them measured)."""

    oxide_thickness_nm: float = 1.0
    regrowth_completeness: float = 1.0
    direct_silicon_etch_nm_per_reset: float = 0.0

    def __post_init__(self) -> None:
        _finite_positive("oxide_thickness_nm", self.oxide_thickness_nm)
        completeness = float(self.regrowth_completeness)
        if not math.isfinite(completeness) or not 0.0 < completeness <= 1.0:
            raise ValueError("regrowth_completeness must be within (0, 1]")
        _finite_nonnegative(
            "direct_silicon_etch_nm_per_reset",
            self.direct_silicon_etch_nm_per_reset,
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def per_reset_recession_nm(
    assumptions: ResetOxidationAssumptions,
) -> float:
    """Silicon depth consumed by one oxidise-and-strip reset event."""

    return (
        silicon_per_oxide_thickness_ratio()
        * assumptions.oxide_thickness_nm
        * assumptions.regrowth_completeness
        + assumptions.direct_silicon_etch_nm_per_reset
    )


def recession_after_resets_nm(
    reset_count: int, assumptions: ResetOxidationAssumptions
) -> float:
    """Cumulative recession of a surface that saw ``reset_count`` resets."""

    count = int(reset_count)
    if count < 0:
        raise ValueError("reset_count must be non-negative")
    return count * per_reset_recession_nm(assumptions)


def count_recipe_events(recipe: Recipe) -> dict[str, Any]:
    """Reset / exchange counts and the epi-relevant last-step check."""

    kinds = [kind for kind, _ in recipe.steps]
    for kind in kinds:
        if kind not in (ETCH, EXCHANGE, RESET):
            raise ValueError(f"unknown step kind: {kind}")
    return {
        "n_reset_events": kinds.count(RESET),
        "n_exchange_events": kinds.count(EXCHANGE),
        # A recipe ending in a reset would hand epitaxy a chemical oxide;
        # every default recipe ends HF-last and this flag proves it.
        "ends_hf_last": bool(kinds) and kinds[-1] == ETCH,
    }


def _thickness_key(oxide_thickness_nm: float) -> str:
    return f"{oxide_thickness_nm:g}"


def price_recipes(
    *,
    outcomes: Sequence[RecipeOutcome] | None = None,
    oxide_thicknesses_nm: Sequence[float] = DEFAULT_OXIDE_THICKNESSES_NM,
) -> list[dict[str, Any]]:
    """Removal (inherited) and silicon recession (new) for every recipe."""

    priced: list[dict[str, Any]] = []
    for outcome in outcomes if outcomes is not None else evaluate_recipes():
        events = count_recipe_events(outcome.recipe)
        recession: dict[str, float] = {}
        removal_per_silicon: dict[str, float | None] = {}
        for thickness in oxide_thicknesses_nm:
            assumptions = ResetOxidationAssumptions(
                oxide_thickness_nm=thickness
            )
            loss = recession_after_resets_nm(
                events["n_reset_events"], assumptions
            )
            key = _thickness_key(thickness)
            recession[key] = loss
            removal_per_silicon[key] = (
                outcome.worst_case_nm() / loss if loss > 0.0 else None
            )
        priced.append(
            {
                **outcome.to_dict(),
                **events,
                "recession_free": events["n_reset_events"] == 0,
                "full_exposure_recession_nm": recession,
                "worst_case_removal_per_silicon_nm": removal_per_silicon,
            }
        )
    return priced


def budget_ranking(
    priced: Sequence[Mapping[str, Any]],
    *,
    oxide_thicknesses_nm: Sequence[float] = DEFAULT_OXIDE_THICKNESSES_NM,
    budgets_nm: Sequence[float | None] = DEFAULT_SILICON_BUDGETS_NM,
    matched_active_time_s: float = DEFAULT_MATCHED_ACTIVE_TIME_S,
) -> list[dict[str, Any]]:
    """Best worst-case removal under a silicon budget, matched active time.

    ``None`` in ``budgets_nm`` means an unlimited budget and reproduces
    the original screen's ranking.  Only recipes with the matched active
    etch time compete, so the statement stays about structure, not about
    spending more HF time.
    """

    matched = [
        row
        for row in priced
        if math.isclose(
            float(row["active_etch_time_s"]), float(matched_active_time_s)
        )
    ]
    if not matched:
        raise ValueError(
            "no recipes at the matched active etch time "
            f"{matched_active_time_s!r}"
        )
    rows: list[dict[str, Any]] = []
    for thickness in oxide_thicknesses_nm:
        key = _thickness_key(thickness)
        for budget in budgets_nm:
            if budget is not None:
                _finite_positive("budget_nm", budget)
            eligible = [
                row
                for row in matched
                if budget is None
                or row["full_exposure_recession_nm"][key] <= budget + 1e-12
            ]
            excluded = [
                {
                    "recipe": row["name"],
                    "full_exposure_recession_nm": (
                        row["full_exposure_recession_nm"][key]
                    ),
                }
                for row in matched
                if row not in eligible
            ]
            best_removal = max(
                row["worst_case_nm"] for row in eligible
            )
            winners = sorted(
                (
                    row["name"]
                    for row in eligible
                    if math.isclose(row["worst_case_nm"], best_removal)
                ),
                key=lambda name: next(
                    row["wall_time_s"]
                    for row in matched
                    if row["name"] == name
                ),
            )
            rows.append(
                {
                    "oxide_thickness_nm": float(thickness),
                    "silicon_budget_nm": (
                        None if budget is None else float(budget)
                    ),
                    "winners": winners,
                    "winner_worst_case_removal_nm": best_removal,
                    "excluded": excluded,
                }
            )
    return rows


def marginal_costs(
    priced: Sequence[Mapping[str, Any]],
    *,
    oxide_thicknesses_nm: Sequence[float] = DEFAULT_OXIDE_THICKNESSES_NM,
    chain: Sequence[str] = MARGINAL_CHAIN,
) -> list[dict[str, Any]]:
    """nm of silicon per extra nm of residue removed along the chain."""

    by_name = {row["name"]: row for row in priced}
    missing = [name for name in chain if name not in by_name]
    if missing:
        raise ValueError(f"chain recipes missing from priced set: {missing}")
    rows: list[dict[str, Any]] = []
    for coarse_name, fine_name in zip(chain, chain[1:]):
        coarse = by_name[coarse_name]
        fine = by_name[fine_name]
        removal_gain = fine["worst_case_nm"] - coarse["worst_case_nm"]
        silicon_costs: dict[str, float] = {}
        ratios: dict[str, float | None] = {}
        for thickness in oxide_thicknesses_nm:
            key = _thickness_key(thickness)
            cost = (
                fine["full_exposure_recession_nm"][key]
                - coarse["full_exposure_recession_nm"][key]
            )
            silicon_costs[key] = cost
            ratios[key] = (
                cost / removal_gain if removal_gain > 0.0 else None
            )
        rows.append(
            {
                "from_recipe": coarse_name,
                "to_recipe": fine_name,
                "worst_case_removal_gain_nm": removal_gain,
                "extra_reset_events": (
                    fine["n_reset_events"] - coarse["n_reset_events"]
                ),
                "extra_recession_nm": silicon_costs,
                "silicon_nm_per_residue_nm": ratios,
            }
        )
    return rows


def clear_cycles_with_recession(
    *,
    pad_thicknesses_nm: Sequence[float] = DEFAULT_PAD_THICKNESSES_NM,
    oxide_thicknesses_nm: Sequence[float] = DEFAULT_OXIDE_THICKNESSES_NM,
    pulse_duration_s: float = 60.0,
) -> list[dict[str, Any]]:
    """The clear-cycle table with its wall-side silicon price attached.

    ``cycles_to_clear`` interleaves resets between pulses, so ``N`` pulses
    carry ``N - 1`` resets.  The recession shown is for silicon exposed
    from the start (walls); silicon under the pad is shielded until clear
    and then pays one full reset recession per margin cycle, which is why
    the per-margin-cycle cost is listed separately.
    """

    rows: list[dict[str, Any]] = []
    for pad in pad_thicknesses_nm:
        base = cycles_to_clear(
            pad_thickness_nm=pad, pulse_duration_s=pulse_duration_s
        )
        reset_events = base["cycles_needed_worst_case"] - 1
        recession: dict[str, float] = {}
        margin_cost: dict[str, float] = {}
        for thickness in oxide_thicknesses_nm:
            assumptions = ResetOxidationAssumptions(
                oxide_thickness_nm=thickness
            )
            key = _thickness_key(thickness)
            recession[key] = recession_after_resets_nm(
                reset_events, assumptions
            )
            margin_cost[key] = per_reset_recession_nm(assumptions)
        rows.append(
            {
                **base,
                "reset_events": reset_events,
                "wall_full_exposure_recession_nm": recession,
                "cleared_bottom_recession_per_margin_cycle_nm": margin_cost,
            }
        )
    return rows


def build_report(
    *,
    oxide_thicknesses_nm: Sequence[float] = DEFAULT_OXIDE_THICKNESSES_NM,
    budgets_nm: Sequence[float] = DEFAULT_SILICON_BUDGETS_NM,
    pad_thicknesses_nm: Sequence[float] = DEFAULT_PAD_THICKNESSES_NM,
) -> dict[str, Any]:
    """Silicon-priced re-ranking of the decay-robust recipe screen."""

    for thickness in oxide_thicknesses_nm:
        _finite_positive("oxide_thickness_nm", thickness)
    priced = price_recipes(oxide_thicknesses_nm=oxide_thicknesses_nm)
    ranked = sorted(
        priced, key=lambda row: row["worst_case_nm"], reverse=True
    )
    ratio = silicon_per_oxide_thickness_ratio()
    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "constants": {
            "silicon_molar_mass_g_mol": SILICON_MOLAR_MASS_G_MOL,
            "silicon_density_g_cm3": SILICON_DENSITY_G_CM3,
            "amorphous_sio2_molar_mass_g_mol": (
                AMORPHOUS_SIO2_MOLAR_MASS_G_MOL
            ),
            "amorphous_sio2_density_g_cm3": AMORPHOUS_SIO2_DENSITY_G_CM3,
            "silicon_per_oxide_thickness_ratio": ratio,
            "provenance_note": (
                "standard handbook room-temperature densities; the "
                "derived ratio moves ~2% across quoted density ranges, "
                "negligible against the 3x oxide-thickness band. The "
                "fused-silica density maximises the ratio, so recession "
                "is not underestimated by the density choice."
            ),
        },
        "assumptions": {
            "oxide_thickness_band_nm": [
                float(value) for value in oxide_thicknesses_nm
            ],
            "oxide_thickness_status": (
                "assumed band for self-limiting wet chemical oxides "
                "(O3-DIW, SC1, SPM); no measured value for this process"
            ),
            "regrowth_completeness": 1.0,
            "regrowth_note": (
                "full self-limiting regrowth every cycle; the "
                "recession-maximising choice"
            ),
            "direct_silicon_etch_nm_per_reset": 0.0,
            "direct_etch_note": (
                "optimistic; SC1 has a finite silicon etch rate, "
                "O3-DIW near zero. Parameter exposed, default zero."
            ),
            "residue_side_credit": (
                "inherited unchanged from pulsed_recipe_screen: full "
                "state reset, zero intrinsic removal"
            ),
            "serial_strip_dead_time": (
                "not charged: the reset oxide grows on silicon walls, "
                "not on the bottom residue, so the post-reset pulse "
                "attacks both in parallel and HF supply is not the "
                "bottleneck (transport null)"
            ),
        },
        "per_reset_recession_nm": {
            _thickness_key(thickness): per_reset_recession_nm(
                ResetOxidationAssumptions(oxide_thickness_nm=thickness)
            )
            for thickness in oxide_thicknesses_nm
        },
        "recipes_ranked_by_worst_case": ranked,
        "budget_ranking": budget_ranking(
            priced,
            oxide_thicknesses_nm=oxide_thicknesses_nm,
            budgets_nm=(*budgets_nm, None),
        ),
        "marginal_costs": marginal_costs(
            priced, oxide_thicknesses_nm=oxide_thicknesses_nm
        ),
        "clear_cycles_with_recession": clear_cycles_with_recession(
            pad_thicknesses_nm=pad_thicknesses_nm,
            oxide_thicknesses_nm=oxide_thicknesses_nm,
        ),
        "exposure_resolution": {
            "formula": "recession_nm = resets_seen x per_reset_recession_nm",
            "note": (
                "walls above a bottom residue see every reset; silicon "
                "under the pad is shielded until clear, so the headline "
                "full-exposure value is the wall-side worst case"
            ),
        },
    }


__all__ = [
    "AMORPHOUS_SIO2_DENSITY_G_CM3",
    "AMORPHOUS_SIO2_MOLAR_MASS_G_MOL",
    "DEFAULT_MATCHED_ACTIVE_TIME_S",
    "DEFAULT_OXIDE_THICKNESSES_NM",
    "DEFAULT_PAD_THICKNESSES_NM",
    "DEFAULT_SILICON_BUDGETS_NM",
    "MARGINAL_CHAIN",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "SILICON_DENSITY_G_CM3",
    "SILICON_MOLAR_MASS_G_MOL",
    "ResetOxidationAssumptions",
    "budget_ranking",
    "build_report",
    "clear_cycles_with_recession",
    "count_recipe_events",
    "marginal_costs",
    "per_reset_recession_nm",
    "price_recipes",
    "recession_after_resets_nm",
    "silicon_per_oxide_thickness_ratio",
]

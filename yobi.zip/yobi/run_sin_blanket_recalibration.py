#!/usr/bin/env python3
"""Recalibrate the SiN bottom-pad screen with a measured blanket time series."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Mapping, Sequence

from measured_blanket_clock import (
    MeasuredBottomPadConfig,
    load_blanket_time_series_csv,
    run_measured_bottom_pad_screen,
    save_measured_bottom_pad_csv,
)


RESULT_NAME = "sin_blanket_recalibration.json"
CSV_NAME = "sin_bottom_pad_comparison.csv"
FIGURE_NAME = "sin_blanket_recalibration.png"
README_NAME = "README_JA.md"
MANIFEST_NAME = "manifest_sha256.json"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Use a cumulative SiN blanket series as a piecewise-linear "
            "bottom-pad clock and compare it with scalar linear clocks."
        )
    )
    parser.add_argument(
        "--input-csv",
        type=Path,
        default=Path("inputs/sin_blanket_user_20260728.csv"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/sin_blanket_recalibration_20260728"),
    )
    parser.add_argument(
        "--no-figure",
        action="store_true",
        help="skip the three-panel comparison figure",
    )
    return parser


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _save_json(payload: Mapping[str, object], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def _case(
    payload: Mapping[str, object],
    *,
    thickness_nm: float,
    local_factor: float,
) -> Mapping[str, object]:
    return next(
        item
        for item in payload["cases"]
        if item["geometry_id"] == payload["config"]["geometry_ids"][0]
        and abs(
            float(item["initial_bottom_pad_thickness_nm"]) - thickness_nm
        )
        < 1.0e-12
        and abs(float(item["bottom_local_rate_factor"]) - local_factor)
        < 1.0e-12
    )


def _checkpoint(
    case: Mapping[str, object],
    time_s: float,
) -> Mapping[str, object]:
    return next(
        item
        for item in case["checkpoints"]
        if abs(float(item["exposure_time_s"]) - time_s) < 1.0e-12
    )


def _local_factor_thresholds(
    payload: Mapping[str, object],
    *,
    thickness_nm: float,
    time_s: float,
) -> dict[str, float]:
    series_points = payload["source_series"]["points"]
    measured = {
        float(point["time_s"]): float(point["etch_amount_nm"])
        for point in series_points
    }
    etch_nm = measured[time_s]
    detection = float(payload["config"]["residue_detection_threshold_nm"])
    return {
        "any_residue_if_factor_below": thickness_nm / etch_nm,
        "detectable_residue_if_factor_below": (
            max(0.0, thickness_nm - detection) / etch_nm
        ),
    }


def write_readme(
    payload: Mapping[str, object],
    path: Path,
    *,
    input_path: Path,
) -> Path:
    analysis = payload["analysis"]
    intervals = analysis["interval_rates"]
    origin_fit = analysis["origin_constrained_linear_fit"]
    unconstrained = analysis["unconstrained_linear_fit"]
    one_nm = _case(payload, thickness_nm=1.0, local_factor=1.0)
    two_nm = _case(payload, thickness_nm=2.0, local_factor=1.0)
    threshold_120 = _local_factor_thresholds(
        payload, thickness_nm=1.0, time_s=120.0
    )
    threshold_180 = _local_factor_thresholds(
        payload, thickness_nm=1.0, time_s=180.0
    )
    lines = [
        "# SiN blanket実測によるHF-only bottom-pad再校正",
        "",
        "既存の文献prior結果は上書きせず、ユーザー提供の累積SiN blanket値を"
        "別clockとして評価したものです。",
        "",
        "## 入力",
        "",
        "| time [s] | cumulative etch [nm] | status |",
        "|---:|---:|---|",
        *[
            (
                f"| {float(point['time_s']):g} | "
                f"{float(point['etch_amount_nm']):.4f} | "
                f"{point['point_kind']} |"
            )
            for point in payload["source_series"]["points"]
        ],
        "",
        "0秒点は累積量の原点として仮定した値で、独立測定ではありません。"
        "30秒値も0–60秒間の区分線形補間です。",
        "",
        "## 線形性",
        "",
        "| interval [s] | rate [nm/min] |",
        "|---|---:|",
        *[
            (
                f"| {float(row['start_time_s']):g}–"
                f"{float(row['end_time_s']):g} | "
                f"{float(row['interval_rate_nm_min']):.4f} |"
            )
            for row in intervals
        ],
        "",
        f"最終区間速度は初期区間の"
        f"{100.0 * float(analysis['last_to_first_interval_rate_ratio']):.1f}%"
        "です。一定速度は検証されていません。",
        "",
        f"- 原点通過fit: {float(origin_fit['slope_nm_min']):.5f} nm/min",
        f"- centered R²: {float(origin_fit['centered_r_squared']):.5f}",
        f"- 最大残差: {float(origin_fit['maximum_absolute_residual_nm']):.5f} nm",
        f"- interceptありfit: slope "
        f"{float(unconstrained['slope_nm_min']):.5f} nm/min, intercept "
        f"{float(unconstrained['intercept_nm']):.5f} nm",
        "",
        "interceptありfitは0秒で非ゼロとなるため、calibration clockには"
        "採用していません。中央予測は実測点間の区分線形累積量です。",
        "",
        "## 1 nm bottom pad、local factor ×1",
        "",
        "| HF time [s] | empirical残膜 [nm] | 原点線形fit [nm] | "
        "文献0.08 nm/min [nm] |",
        "|---:|---:|---:|---:|",
        *[
            (
                f"| {time_s:g} | "
                f"{float(_checkpoint(one_nm, time_s)['empirical_piecewise']['remaining_thickness_nm']):.4f} | "
                f"{float(_checkpoint(one_nm, time_s)['origin_linear_comparison']['remaining_thickness_nm']):.4f} | "
                f"{float(_checkpoint(one_nm, time_s)['literature_linear_comparison']['remaining_thickness_nm']):.4f} |"
            )
            for time_s in (30.0, 60.0, 120.0, 180.0)
        ],
        "",
        f"実測clockでの1 nm clear時間は"
        f"{float(one_nm['empirical_clear_time_s']):.2f}秒です。"
        "したがって30–60秒残渣は初期1 nm膜だけでも説明できますが、"
        "120秒以降の残渣には追加条件が必要です。",
        "",
        f"- 120秒で1 nmが少しでも残る条件: local factor < "
        f"{threshold_120['any_residue_if_factor_below']:.3f}",
        f"- 120秒で0.05 nm超残る条件: local factor < "
        f"{threshold_120['detectable_residue_if_factor_below']:.3f}",
        f"- 180秒で1 nmが少しでも残る条件: local factor < "
        f"{threshold_180['any_residue_if_factor_below']:.3f}",
        f"- 180秒で0.05 nm超残る条件: local factor < "
        f"{threshold_180['detectable_residue_if_factor_below']:.3f}",
        "",
        "## 初期膜厚の影響",
        "",
        f"2 nm padは120秒後に"
        f"{float(_checkpoint(two_nm, 120.0)['empirical_piecewise']['remaining_thickness_nm']):.4f} nm、"
        f"180秒後にも"
        f"{float(_checkpoint(two_nm, 180.0)['empirical_piecewise']['remaining_thickness_nm']):.4f} nm残ります。",
        "よって120–180秒残渣を判断するには、HF前のbottom膜厚測定が依然として"
        "最重要です。",
        "",
        "## 解釈境界",
        "",
        "- HF濃度、液温、wafer lot、成膜法、測定不確かさは未入力です。",
        "- 減速傾向だけからpassivation、reactant depletion、表面変換を"
        "識別できません。",
        "- 180秒を超える外挿は行っていません。",
        "- local factorはbottom反応低下のscreening変数で、実測値ではありません。",
        "- primary graph-KMCのscalar overrideは、温度・不確かさ不足と"
        "time-dependent clockのため未適用です。",
        "",
        "## 成果物",
        "",
        f"- `{RESULT_NAME}`: fit、区分速度、全bottom-pad case",
        f"- `{CSV_NAME}`: 0.5/1/2/5 nm、local factor 1/0.3/0.1",
        f"- `{FIGURE_NAME}`: 実測clock比較図",
        f"- `{MANIFEST_NAME}`: 入力を含むSHA-256",
        f"- 入力: `{input_path}`",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def plot_recalibration(
    payload: Mapping[str, object],
    path: Path,
) -> Path:
    import matplotlib

    matplotlib.use("Agg", force=True)
    import matplotlib.pyplot as plt
    import numpy as np

    points = payload["source_series"]["points"]
    measured_t = np.asarray(
        [float(point["time_s"]) for point in points], dtype=float
    )
    measured_y = np.asarray(
        [float(point["etch_amount_nm"]) for point in points], dtype=float
    )
    origin_rate = float(
        payload["analysis"]["origin_constrained_linear_fit"][
            "slope_nm_min"
        ]
    )
    literature_rate = float(
        payload["calibration_comparison"][
            "literature_comparison_rate_nm_min"
        ]
    )
    dense_t = np.linspace(0.0, 180.0, 361)
    piecewise_y = np.interp(dense_t, measured_t, measured_y)
    origin_y = origin_rate * dense_t / 60.0
    literature_y = literature_rate * dense_t / 60.0

    fig, axes = plt.subplots(1, 3, figsize=(14.5, 4.5))
    ax = axes[0]
    ax.plot(dense_t, piecewise_y, label="empirical piecewise", linewidth=2.4)
    ax.plot(dense_t, origin_y, label="origin linear fit", linestyle="--")
    ax.plot(dense_t, literature_y, label="literature 0.08", linestyle=":")
    ax.scatter(measured_t[1:], measured_y[1:], zorder=4, label="user data")
    ax.scatter(
        measured_t[:1],
        measured_y[:1],
        facecolors="none",
        edgecolors="black",
        zorder=4,
        label="assumed origin",
    )
    ax.set_title("A  SiN blanket clock")
    ax.set_xlabel("HF time (s)")
    ax.set_ylabel("Cumulative etch (nm)")
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8)

    ax = axes[1]
    interval_rows = payload["analysis"]["interval_rates"]
    labels = [
        f"{float(row['start_time_s']):g}–{float(row['end_time_s']):g}"
        for row in interval_rows
    ]
    rates = [
        float(row["interval_rate_nm_min"]) for row in interval_rows
    ]
    ax.bar(labels, rates, color=("#2878B5", "#F28522", "#4CAF50"))
    ax.axhline(
        origin_rate,
        color="black",
        linestyle="--",
        linewidth=1.2,
        label=f"origin fit {origin_rate:.3f}",
    )
    ax.axhline(
        literature_rate,
        color="#C62828",
        linestyle=":",
        linewidth=1.6,
        label=f"literature {literature_rate:.2f}",
    )
    ax.set_title("B  Interval-rate decline")
    ax.set_xlabel("Interval (s)")
    ax.set_ylabel("Rate (nm/min)")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(fontsize=8)

    ax = axes[2]
    empirical_one = np.maximum(0.0, 1.0 - piecewise_y)
    empirical_two = np.maximum(0.0, 2.0 - piecewise_y)
    origin_one = np.maximum(0.0, 1.0 - origin_y)
    literature_one = np.maximum(0.0, 1.0 - literature_y)
    ax.plot(
        dense_t,
        empirical_one,
        linewidth=2.4,
        label="1 nm empirical",
    )
    ax.plot(
        dense_t,
        empirical_two,
        linewidth=2.0,
        label="2 nm empirical",
    )
    ax.plot(
        dense_t,
        origin_one,
        linestyle="--",
        label="1 nm origin fit",
    )
    ax.plot(
        dense_t,
        literature_one,
        linestyle=":",
        label="1 nm literature",
    )
    ax.axhline(0.05, color="grey", linewidth=1.0, alpha=0.7)
    ax.set_title("C  Fully wetted bottom pad (factor 1)")
    ax.set_xlabel("HF time (s)")
    ax.set_ylabel("Remaining thickness (nm)")
    ax.set_ylim(bottom=0.0)
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8)

    fig.suptitle(
        "SiN blanket recalibration: measured cumulative clock vs literature",
        fontsize=14,
        fontweight="bold",
    )
    fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.94))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return path


def _write_manifest(
    output_dir: Path,
    names: Sequence[str],
    *,
    input_path: Path,
) -> Path:
    payload = {
        "algorithm": "sha256",
        "files": {
            name: {
                "sha256": _sha256(output_dir / name),
                "size_bytes": (output_dir / name).stat().st_size,
            }
            for name in names
            if (output_dir / name).is_file()
        },
        "inputs": {
            str(input_path): {
                "sha256": _sha256(input_path),
                "size_bytes": input_path.stat().st_size,
            }
        },
    }
    return _save_json(payload, output_dir / MANIFEST_NAME)


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    series = load_blanket_time_series_csv(args.input_csv)
    payload = run_measured_bottom_pad_screen(
        series,
        MeasuredBottomPadConfig(),
    )
    payload["input_artifact"] = {
        "path": str(args.input_csv),
        "sha256": _sha256(args.input_csv),
    }
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    _save_json(payload, output_dir / RESULT_NAME)
    save_measured_bottom_pad_csv(payload, output_dir / CSV_NAME)
    write_readme(
        payload,
        output_dir / README_NAME,
        input_path=args.input_csv,
    )
    names = [RESULT_NAME, CSV_NAME, README_NAME]
    if not args.no_figure:
        plot_recalibration(payload, output_dir / FIGURE_NAME)
        names.append(FIGURE_NAME)
    _write_manifest(output_dir, names, input_path=args.input_csv)
    return payload


if __name__ == "__main__":
    main()

from __future__ import annotations

import unittest

import numpy as np

from plot_thermomechanical_detachment_geometry import (
    FigureScenario,
    calculate_detachment_fields,
    interface_resistance_profile,
)


class GeometryDetachmentFigureTests(unittest.TestCase):
    def setUp(self) -> None:
        self.scenario = FigureScenario(interface_points=101)
        self.fields = calculate_detachment_fields(self.scenario)

    def test_interface_resistance_is_central_low_edge_high(self) -> None:
        x = np.array(
            [
                -0.5 * self.scenario.residue_width_nm,
                0.0,
                0.5 * self.scenario.residue_width_nm,
            ]
        )
        profile = interface_resistance_profile(self.scenario, x)
        self.assertAlmostEqual(
            profile[0], self.scenario.edge_interface_resistance_m2K_W
        )
        self.assertAlmostEqual(
            profile[2], self.scenario.edge_interface_resistance_m2K_W
        )
        self.assertAlmostEqual(
            profile[1],
            self.scenario.centre_interface_resistance_m2K_W,
            delta=1.0e-18,
        )

    def test_tstar_is_in_liquid_water_screening_range(self) -> None:
        self.assertGreater(self.fields.substrate_temperature_K, 298.15)
        self.assertLessEqual(self.fields.substrate_temperature_K, 373.15)

    def test_edge_energy_ratio_reaches_one(self) -> None:
        self.assertAlmostEqual(
            float(np.max(self.fields.energy_to_fracture_ratio)),
            1.0,
            places=9,
        )

    def test_energy_hotspots_are_at_both_edges(self) -> None:
        ratio = self.fields.energy_to_fracture_ratio
        self.assertAlmostEqual(float(ratio[0]), float(ratio[-1]), places=12)
        self.assertGreater(float(ratio[0]), 20.0 * float(ratio[len(ratio) // 2]))
        self.assertGreater(float(self.fields.x_nm[self.fields.edge_index()]), 0.0)

    def test_edge_temperature_and_stress_match_inverse_anchor(self) -> None:
        edge = self.fields.edge_index()
        self.assertAlmostEqual(
            float(self.fields.substrate_residue_delta_K[edge]),
            48.19395717805611,
            places=7,
        )
        self.assertAlmostEqual(
            float(self.fields.biaxial_stress_Pa[edge] / 1.0e6),
            39.264063297965735,
            places=7,
        )


if __name__ == "__main__":
    unittest.main()

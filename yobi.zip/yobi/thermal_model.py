"""Quasi-steady thermal-resistance model for a moving trench etch front.

The model is deliberately one-dimensional.  Heat can leave the horizontal
solid--liquid front through two parallel branches:

* upward through the etched, liquid-filled part of the tapered trench to the
  independently controlled solution bulk; and
* downward through the remaining gap fill, substrate, and backside contact to
  the independently controlled substrate backside.

All calculations use SI units.  Because :class:`TaperedTrench2D` represents a
2-D cross-section, resistances are reported *per unit out-of-plane span* in
``K m / W`` and heat rates in ``W / m``.  This removes the need to invent a
trench length; their product is still a temperature difference in kelvin.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from etch_process import ThermalBoundaryConditions
from trench_geometry import TaperedTrench2D


NM_TO_M = 1.0e-9


def _finite_positive(name: str, value: float) -> None:
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


def _finite_nonnegative(name: str, value: float) -> None:
    if not math.isfinite(value) or value < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")


def inverse_width_integral(
    geometry: TaperedTrench2D,
    start_depth_m: float,
    end_depth_m: float,
) -> float:
    """Return ``integral(start, end) dz / width(z)`` for a tapered trench.

    Both depth arguments are in metres.  The returned integral is
    dimensionless.  The logarithmic expression is exact for the linear taper
    and falls back to the constant-width expression for a vertical trench.
    """

    start = float(start_depth_m)
    end = float(end_depth_m)
    if not math.isfinite(start) or not math.isfinite(end):
        raise ValueError("depth bounds must be finite")

    height = geometry.depth_nm * NM_TO_M
    tolerance = max(1.0e-15, 1.0e-9 * height)
    if start < -tolerance or end > height + tolerance or end < start - tolerance:
        raise ValueError(
            f"depth interval must satisfy 0 <= start <= end <= {height:g} m"
        )
    start = min(max(start, 0.0), height)
    end = min(max(end, start), height)
    if end == start:
        return 0.0

    top_width = geometry.top_width_nm * NM_TO_M
    bottom_width = geometry.bottom_width_nm * NM_TO_M
    width_change = top_width - bottom_width
    if abs(width_change) <= 1.0e-14 * top_width:
        return (end - start) / top_width

    taper_slope = width_change / height
    start_width = top_width - taper_slope * start
    end_width = top_width - taper_slope * end
    return math.log(start_width / end_width) / taper_slope


@dataclass(frozen=True)
class ThermalResistanceParameters:
    """Material and external resistances for the two thermal branches.

    ``*_resistance_m2K_W`` fields are area-normalised contact resistances.
    ``effective_substrate_width_m`` is the lateral width assigned to one
    trench in the substrate/contact calculation.  ``None`` uses the trench
    bottom width, which is a conservative narrow-column approximation; a
    pitch or independently calibrated spreading width can be supplied instead.
    """

    liquid_thermal_conductivity_W_mK: float = 0.60
    fill_thermal_conductivity_W_mK: float = 1.0
    substrate_thermal_conductivity_W_mK: float = 130.0
    substrate_thickness_m: float = 500.0e-6
    solution_boundary_resistance_m2K_W: float = 0.0
    fill_substrate_contact_resistance_m2K_W: float = 0.0
    backside_contact_resistance_m2K_W: float = 1.0e-6
    effective_substrate_width_m: float | None = None

    def __post_init__(self) -> None:
        for name in (
            "liquid_thermal_conductivity_W_mK",
            "fill_thermal_conductivity_W_mK",
            "substrate_thermal_conductivity_W_mK",
        ):
            _finite_positive(name, float(getattr(self, name)))
        for name in (
            "substrate_thickness_m",
            "solution_boundary_resistance_m2K_W",
            "fill_substrate_contact_resistance_m2K_W",
            "backside_contact_resistance_m2K_W",
        ):
            _finite_nonnegative(name, float(getattr(self, name)))
        if self.effective_substrate_width_m is not None:
            _finite_positive(
                "effective_substrate_width_m",
                float(self.effective_substrate_width_m),
            )


@dataclass(frozen=True)
class ThermalResistanceBreakdown:
    """Thermal resistances per unit out-of-plane span, in ``K m / W``."""

    front_depth_m: float
    front_width_m: float
    solution_boundary_K_m_W: float
    liquid_conduction_K_m_W: float
    fill_conduction_K_m_W: float
    fill_substrate_contact_K_m_W: float
    substrate_conduction_K_m_W: float
    backside_contact_K_m_W: float

    @property
    def liquid_total_K_m_W(self) -> float:
        return self.solution_boundary_K_m_W + self.liquid_conduction_K_m_W

    @property
    def solid_total_K_m_W(self) -> float:
        return (
            self.fill_conduction_K_m_W
            + self.fill_substrate_contact_K_m_W
            + self.substrate_conduction_K_m_W
            + self.backside_contact_K_m_W
        )


@dataclass(frozen=True)
class InterfaceThermalState:
    """Temperature and branch heat rates at the moving interface."""

    interface_temperature_K: float
    reaction_heat_flux_W_m2: float
    reaction_heat_rate_W_m: float
    heat_to_solution_W_m: float
    heat_to_substrate_W_m: float
    resistances: ThermalResistanceBreakdown

    @property
    def energy_balance_residual_W_m(self) -> float:
        return (
            self.heat_to_solution_W_m
            + self.heat_to_substrate_W_m
            - self.reaction_heat_rate_W_m
        )


@dataclass(frozen=True)
class ThermalResistanceModel:
    """Evaluate the local interface temperature for a front depth."""

    geometry: TaperedTrench2D
    parameters: ThermalResistanceParameters = ThermalResistanceParameters()

    @property
    def trench_depth_m(self) -> float:
        return self.geometry.depth_nm * NM_TO_M

    def _clipped_depth_m(self, front_depth_m: float) -> float:
        depth = float(front_depth_m)
        if not math.isfinite(depth):
            raise ValueError("front_depth_m must be finite")
        tolerance = max(1.0e-15, self.trench_depth_m * 1.0e-9)
        if depth < -tolerance or depth > self.trench_depth_m + tolerance:
            raise ValueError(
                f"front_depth_m must be within [0, {self.trench_depth_m:g}]"
            )
        return min(max(depth, 0.0), self.trench_depth_m)

    def resistances(self, front_depth_m: float) -> ThermalResistanceBreakdown:
        """Return both branch resistances at ``front_depth_m``."""

        depth = self._clipped_depth_m(front_depth_m)
        p = self.parameters
        top_width = self.geometry.top_width_nm * NM_TO_M
        bottom_width = self.geometry.bottom_width_nm * NM_TO_M
        front_width = float(
            self.geometry.width_at_depth_nm(depth / NM_TO_M)
        ) * NM_TO_M
        substrate_width = (
            bottom_width
            if p.effective_substrate_width_m is None
            else p.effective_substrate_width_m
        )

        return ThermalResistanceBreakdown(
            front_depth_m=depth,
            front_width_m=front_width,
            solution_boundary_K_m_W=(
                p.solution_boundary_resistance_m2K_W / top_width
            ),
            liquid_conduction_K_m_W=(
                inverse_width_integral(self.geometry, 0.0, depth)
                / p.liquid_thermal_conductivity_W_mK
            ),
            fill_conduction_K_m_W=(
                inverse_width_integral(self.geometry, depth, self.trench_depth_m)
                / p.fill_thermal_conductivity_W_mK
            ),
            fill_substrate_contact_K_m_W=(
                p.fill_substrate_contact_resistance_m2K_W / bottom_width
            ),
            substrate_conduction_K_m_W=(
                p.substrate_thickness_m
                / (p.substrate_thermal_conductivity_W_mK * substrate_width)
            ),
            backside_contact_K_m_W=(
                p.backside_contact_resistance_m2K_W / substrate_width
            ),
        )

    def evaluate(
        self,
        front_depth_m: float,
        boundary_conditions: ThermalBoundaryConditions,
        *,
        reaction_heat_flux_W_m2: float = 0.0,
    ) -> InterfaceThermalState:
        """Compute the steady interface temperature and branch heat rates.

        A positive ``reaction_heat_flux_W_m2`` denotes heat generated at the
        interface.  A negative value denotes an endothermic heat sink.  The
        local reaction heat rate per span is the flux times the local front
        width.
        """

        heat_flux = float(reaction_heat_flux_W_m2)
        if not math.isfinite(heat_flux):
            raise ValueError("reaction_heat_flux_W_m2 must be finite")

        resistance = self.resistances(front_depth_m)
        liquid_resistance = resistance.liquid_total_K_m_W
        solid_resistance = resistance.solid_total_K_m_W
        liquid_temperature = boundary_conditions.solution_bulk_temperature_K
        solid_temperature = boundary_conditions.substrate_backside_temperature_K
        heat_rate = heat_flux * resistance.front_width_m

        if liquid_resistance == 0.0 and solid_resistance == 0.0:
            if not math.isclose(
                liquid_temperature,
                solid_temperature,
                rel_tol=0.0,
                abs_tol=1.0e-12,
            ):
                raise ValueError(
                    "zero resistance to two different boundary temperatures is "
                    "physically inconsistent"
                )
            interface_temperature = liquid_temperature
            heat_to_liquid = 0.5 * heat_rate
            heat_to_solid = heat_rate - heat_to_liquid
        elif liquid_resistance == 0.0:
            interface_temperature = liquid_temperature
            heat_to_solid = (
                interface_temperature - solid_temperature
            ) / solid_resistance
            heat_to_liquid = heat_rate - heat_to_solid
        elif solid_resistance == 0.0:
            interface_temperature = solid_temperature
            heat_to_liquid = (
                interface_temperature - liquid_temperature
            ) / liquid_resistance
            heat_to_solid = heat_rate - heat_to_liquid
        else:
            liquid_conductance = 1.0 / liquid_resistance
            solid_conductance = 1.0 / solid_resistance
            interface_temperature = (
                liquid_conductance * liquid_temperature
                + solid_conductance * solid_temperature
                + heat_rate
            ) / (liquid_conductance + solid_conductance)
            heat_to_liquid = (
                interface_temperature - liquid_temperature
            ) / liquid_resistance
            heat_to_solid = (
                interface_temperature - solid_temperature
            ) / solid_resistance

        if not math.isfinite(interface_temperature) or interface_temperature <= 0.0:
            raise ValueError(
                "thermal network produced a non-physical interface temperature"
            )

        return InterfaceThermalState(
            interface_temperature_K=interface_temperature,
            reaction_heat_flux_W_m2=heat_flux,
            reaction_heat_rate_W_m=heat_rate,
            heat_to_solution_W_m=heat_to_liquid,
            heat_to_substrate_W_m=heat_to_solid,
            resistances=resistance,
        )

    def interface_temperature_K(
        self,
        front_depth_m: float,
        boundary_conditions: ThermalBoundaryConditions,
        *,
        reaction_heat_flux_W_m2: float = 0.0,
    ) -> float:
        """Convenience wrapper returning only the interface temperature."""

        return self.evaluate(
            front_depth_m,
            boundary_conditions,
            reaction_heat_flux_W_m2=reaction_heat_flux_W_m2,
        ).interface_temperature_K

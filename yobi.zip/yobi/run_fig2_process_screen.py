#!/usr/bin/env python3
"""Run the Kawarazaki Fig. 2 blanket-equivalent process screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from fig2_process_screen import (
    DEFAULT_TARGET_ENDPOINT_IDS,
    Fig2ProcessScreenConfig,
    run_fig2_process_screen,
    save_fig2_process_screen_json,
)
from literature_parameters import KAWARAZAKI_2024_FIG2_ENDPOINTS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Compare dHF-only clearing time with fixed ozone/dHF cycle count "
            "and paired blanket SiN loss. This is not a process recipe."
        )
    )
    parser.add_argument(
        "--endpoint",
        choices=tuple(
            endpoint_id
            for endpoint_id, endpoint in (
                KAWARAZAKI_2024_FIG2_ENDPOINTS.items()
            )
            if endpoint.material != "SiN"
        ),
        action="append",
        help="repeat to select target films (default: all non-SiN films)",
    )
    parser.add_argument(
        "--residual-thickness-nm",
        type=float,
        action="append",
        help="repeat to select residual thicknesses (default: 0.5,1,2,5,10)",
    )
    parser.add_argument(
        "--reported-cycle-range-max",
        type=int,
        default=3,
        help="largest source-supported cycle count (default: 3)",
    )
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config = Fig2ProcessScreenConfig(
        target_endpoint_ids=tuple(
            dict.fromkeys(args.endpoint or DEFAULT_TARGET_ENDPOINT_IDS)
        ),
        residual_thicknesses_nm=tuple(
            dict.fromkeys(
                args.residual_thickness_nm
                or (0.5, 1.0, 2.0, 5.0, 10.0)
            )
        ),
        reported_cycle_range_max=args.reported_cycle_range_max,
    )
    payload = run_fig2_process_screen(config)
    if args.output is None:
        print(
            json.dumps(
                payload,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
                allow_nan=False,
            )
        )
    else:
        save_fig2_process_screen_json(payload, args.output)
        print(f"JSON: {args.output}")
    return payload


if __name__ == "__main__":
    main()

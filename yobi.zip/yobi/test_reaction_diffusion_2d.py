from __future__ import annotations

import unittest

import numpy as np

from reaction_diffusion_2d import (
    CartesianGrid2D,
    TopBoundaryCondition,
    connected_to_top,
    diffusion_inventory_balance,
    interface_average_on_solid,
    solve_quasi_steady_diffusion,
)
from trench_geometry import TaperedTrench2D


class ReactionDiffusion2DTests(unittest.TestCase):
    def setUp(self) -> None:
        self.geometry = TaperedTrench2D("toy", 8.0, 6.0, 20.0)
        self.grid = CartesianGrid2D.from_geometry(
            self.geometry,
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
        )

    def opened_channel(self) -> tuple[np.ndarray, np.ndarray]:
        cavity_rows = np.flatnonzero(self.grid.depth_nm > 0.0)
        open_rows = cavity_rows[:3]
        channel = np.zeros(self.grid.shape, dtype=bool)
        for row in open_rows:
            in_cavity = np.flatnonzero(self.grid.cavity_mask[row])
            channel[row, in_cavity[len(in_cavity) // 2]] = True
        liquid = self.grid.reservoir_mask | channel
        solid = self.grid.cavity_mask & ~channel
        return liquid, solid

    def test_grid_represents_reservoir_and_tapered_cavity(self) -> None:
        self.assertEqual(self.grid.shape, (12, 7))
        self.assertFalse(np.any(self.grid.reservoir_mask & self.grid.cavity_mask))
        cavity_widths = np.count_nonzero(self.grid.cavity_mask, axis=1)
        positive_rows = cavity_widths[cavity_widths > 0]
        self.assertGreater(len(positive_rows), 0)
        self.assertGreaterEqual(positive_rows[0], positive_rows[-1])
        self.assertAlmostEqual(self.grid.dz_nm, 2.0)

    def test_connected_to_top_rejects_isolated_pocket(self) -> None:
        mask = np.zeros((6, 6), dtype=bool)
        mask[0:3, 1] = True
        mask[4, 4] = True
        connected = connected_to_top(mask)
        self.assertTrue(np.all(connected[0:3, 1]))
        self.assertFalse(connected[4, 4])

    def test_dirichlet_no_reaction_gives_uniform_field(self) -> None:
        liquid, solid = self.opened_channel()
        result = solve_quasi_steady_diffusion(
            self.grid,
            liquid,
            solid,
            diffusivity_nm2_s=100.0,
            top_boundary=TopBoundaryCondition(1.25),
        )
        self.assertTrue(result.converged)
        np.testing.assert_allclose(
            result.field[result.connected_liquid_mask], 1.25, atol=2.0e-4
        )
        self.assertEqual(
            np.count_nonzero(result.connected_liquid_mask), np.count_nonzero(liquid)
        )

    def test_tiny_sink_is_resolved_against_huge_dirichlet_rhs(self) -> None:
        grid = CartesianGrid2D(
            geometry=TaperedTrench2D("two-cell", 2.0, 2.0, 1.0),
            lateral_nm=np.array([-0.5, 0.5]),
            depth_nm=np.array([-0.5, 0.5]),
            dx_nm=1.0,
            dz_nm=1.0,
            reservoir_mask=np.array([[True, True], [False, False]]),
            cavity_mask=np.array([[False, False], [True, True]]),
        )
        bulk_value = 1.0e12
        diffusivity = 1.0
        sink_velocity = 1.0e-5
        result = solve_quasi_steady_diffusion(
            grid,
            grid.reservoir_mask,
            grid.cavity_mask,
            diffusivity_nm2_s=diffusivity,
            top_boundary=TopBoundaryCondition(bulk_value),
            interface_sink_velocity_nm_s=sink_velocity,
            relative_tolerance=1.0e-4,
            absolute_tolerance=0.0,
            direct_fallback=False,
        )

        top_conductance = 2.0 * diffusivity
        expected = top_conductance * bulk_value / (
            top_conductance + sink_velocity
        )
        active_values = result.field[result.connected_liquid_mask]
        top_inflow = top_conductance * float(
            np.sum(bulk_value - active_values)
        )
        sink_loss = sink_velocity * float(np.sum(active_values))

        self.assertTrue(result.converged)
        self.assertGreater(result.iterations, 0)
        np.testing.assert_allclose(active_values, expected, rtol=1.0e-12, atol=0.0)
        self.assertAlmostEqual(
            top_inflow,
            sink_loss,
            delta=1.0e-9 * sink_loss,
        )
        self.assertLess(result.relative_residual, 1.0e-9)

    def test_surface_sink_and_robin_top_lower_reactant(self) -> None:
        liquid, solid = self.opened_channel()
        dirichlet = solve_quasi_steady_diffusion(
            self.grid,
            liquid,
            solid,
            diffusivity_nm2_s=30.0,
            top_boundary=TopBoundaryCondition(1.0),
            interface_sink_velocity_nm_s=8.0,
        )
        robin = solve_quasi_steady_diffusion(
            self.grid,
            liquid,
            solid,
            diffusivity_nm2_s=30.0,
            top_boundary=TopBoundaryCondition(
                1.0, kind="robin", transfer_velocity_nm_s=1.0
            ),
            interface_sink_velocity_nm_s=8.0,
        )
        self.assertTrue(dirichlet.converged)
        self.assertTrue(robin.converged)
        self.assertGreaterEqual(np.min(dirichlet.field), 0.0)
        self.assertLess(
            float(np.mean(robin.field[robin.connected_liquid_mask])),
            float(np.mean(dirichlet.field[dirichlet.connected_liquid_mask])),
        )
        interface_value = interface_average_on_solid(
            dirichlet.field, dirichlet.connected_liquid_mask, solid
        )
        self.assertGreater(np.count_nonzero(interface_value), 0)
        self.assertLess(np.max(interface_value), 1.0)

    def test_interface_source_produces_nonnegative_product(self) -> None:
        liquid, solid = self.opened_channel()
        source = np.zeros(self.grid.shape)
        source[solid] = 2.0
        result = solve_quasi_steady_diffusion(
            self.grid,
            liquid,
            solid,
            diffusivity_nm2_s=50.0,
            top_boundary=TopBoundaryCondition(0.0),
            interface_source_flux=source,
            bulk_decay_per_s=0.05,
        )
        self.assertTrue(result.converged)
        self.assertGreater(np.max(result.field), 0.0)
        self.assertGreaterEqual(np.min(result.field), 0.0)
        self.assertTrue(np.all(result.field[~result.connected_liquid_mask] == 0.0))
        balance = diffusion_inventory_balance(
            self.grid,
            result,
            solid,
            diffusivity_nm2_s=50.0,
            top_boundary=TopBoundaryCondition(0.0),
            interface_source_flux=source,
            bulk_decay_per_s=0.05,
        )
        self.assertGreater(balance.surface_source_rate, 0.0)
        self.assertGreater(balance.top_outflow_rate, 0.0)
        self.assertGreater(balance.bulk_decay_rate, 0.0)
        self.assertLess(balance.relative_error, 1.0e-4)

    def test_spatial_bulk_decay_closes_inventory_and_lowers_local_field(self) -> None:
        liquid, solid = self.opened_channel()
        source = np.zeros(self.grid.shape)
        source[solid] = 2.0
        baseline = solve_quasi_steady_diffusion(
            self.grid,
            liquid,
            solid,
            diffusivity_nm2_s=50.0,
            top_boundary=TopBoundaryCondition(0.0),
            interface_source_flux=source,
        )
        decay = np.zeros(self.grid.shape)
        channel_cells = np.argwhere(liquid & self.grid.cavity_mask)
        target = tuple(channel_cells[np.argmax(channel_cells[:, 0])])
        decay[target] = 2.0
        result = solve_quasi_steady_diffusion(
            self.grid,
            liquid,
            solid,
            diffusivity_nm2_s=50.0,
            top_boundary=TopBoundaryCondition(0.0),
            interface_source_flux=source,
            bulk_decay_per_s=decay,
        )

        self.assertTrue(result.converged)
        self.assertLess(result.field[target], baseline.field[target])
        balance = diffusion_inventory_balance(
            self.grid,
            result,
            solid,
            diffusivity_nm2_s=50.0,
            top_boundary=TopBoundaryCondition(0.0),
            interface_source_flux=source,
            bulk_decay_per_s=decay,
        )
        expected_decay_rate = float(
            np.sum(decay * result.field) * self.grid.cell_area_nm2
        )
        self.assertAlmostEqual(balance.bulk_decay_rate, expected_decay_rate)
        self.assertGreater(balance.bulk_decay_rate, 0.0)
        self.assertLess(balance.relative_error, 1.0e-4)

    def test_permissive_direct_fallback_recovers_from_tiny_iteration_limit(self) -> None:
        liquid, solid = self.opened_channel()
        result = solve_quasi_steady_diffusion(
            self.grid,
            liquid,
            solid,
            diffusivity_nm2_s=20.0,
            top_boundary=TopBoundaryCondition(1.0),
            interface_sink_velocity_nm_s=10.0,
            relative_tolerance=1.0e-12,
            max_iterations=1,
        )
        self.assertTrue(result.used_direct_fallback)
        self.assertTrue(result.converged)
        self.assertLess(result.relative_residual, 1.0e-10)


if __name__ == "__main__":
    unittest.main()

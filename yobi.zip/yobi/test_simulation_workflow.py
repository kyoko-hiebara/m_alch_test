from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from run_gapfill_models import main
from simulation_workflow import (
    ScreeningConfig,
    build_process,
    kmc_event_flux_to_velocity_nm_s,
    run_screening_workflow,
)


class SimulationWorkflowTests(unittest.TestCase):
    def test_both_standard_geometries_preserve_process_invariants(self) -> None:
        expected = {
            "10_10_180": (10.0, 10.0, 180.0),
            "7_7_170": (7.0, 7.0, 170.0),
        }
        for name, dimensions in expected.items():
            with self.subTest(geometry=name):
                config = ScreeningConfig(
                    geometry=name,
                    material="SiOCN",
                    solution_bulk_temperature_K=291.0,
                    substrate_backside_temperature_K=333.0,
                    duration_s=0.1,
                    grid_spacing_nm=5.0,
                    reservoir_height_nm=5.0,
                    kmc_sites=4,
                    kmc_max_events=2,
                )
                process = build_process(config)
                self.assertEqual(
                    (
                        process.geometry.top_width_nm,
                        process.geometry.bottom_width_nm,
                        process.geometry.depth_nm,
                    ),
                    dimensions,
                )
                self.assertEqual(
                    process.thermal_bc.solution_bulk_temperature_K, 291.0
                )
                self.assertEqual(
                    process.thermal_bc.substrate_backside_temperature_K, 333.0
                )
                restored = type(process).from_json(process.to_json())
                self.assertEqual(restored, process)
                payload = run_screening_workflow(
                    config, ("thermal", "continuum_2d")
                )
                result_2d = payload["results"]["continuum_2d"]
                self.assertTrue(result_2d["initial_condition"]["fully_gap_filled"])
                self.assertEqual(
                    result_2d["initial_condition"]["liquid_cells_in_trench"], 0
                )
                self.assertLess(result_2d["remaining_mass_fraction"], 1.0)

    def test_seeded_full_workflow_is_reproducible(self) -> None:
        config = ScreeningConfig(
            geometry="7_4p5_170",
            material="SiN",
            duration_s=0.1,
            grid_spacing_nm=5.0,
            reservoir_height_nm=5.0,
            random_seed=123,
            kmc_sites=6,
            kmc_max_events=8,
        )
        first = run_screening_workflow(config)
        second = run_screening_workflow(config)
        self.assertEqual(first, second)
        self.assertEqual(first["results"]["kmc"]["seed"], 123)
        wet = first["results"]["wet_sequence"]["hf_then_second_wet"]
        for step in wet["steps"]:
            self.assertNotEqual(
                step["solution_temperature_K"],
                step["substrate_temperature_K"],
            )

    def test_cli_writes_plain_json_with_explicit_temperatures(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "screening.json"
            payload = main(
                [
                    "--mode",
                    "thermal",
                    "--geometry",
                    "10_8_180",
                    "--material",
                    "SiOCN",
                    "--solution-temperature-k",
                    "290",
                    "--substrate-temperature-k",
                    "340",
                    "--output",
                    str(output),
                ]
            )
            saved = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(saved, payload)
            self.assertEqual(
                saved["process"]["solution"]["bulk_temperature_K"], 290.0
            )
            self.assertEqual(
                saved["process"]["substrate"]["backside_temperature_K"],
                340.0,
            )
            self.assertFalse(saved["calibrated"])

    def test_kmc_flux_to_velocity_mapping(self) -> None:
        self.assertAlmostEqual(
            kmc_event_flux_to_velocity_nm_s(20.0, 10, 0.3), 0.6
        )
        with self.assertRaises(ValueError):
            kmc_event_flux_to_velocity_nm_s(-1.0, 10, 0.3)

    def test_kmc_full_exhaustion_does_not_select_roundoff_rate(self) -> None:
        # This seed used to leave only a ~2.5e-15 Fenwick accumulation after
        # every slot reached zero, then fail by selecting a zero-rate event.
        config = ScreeningConfig(
            geometry="10_8_180",
            material="SiN",
            random_seed=32,
            kmc_sites=24,
            kmc_max_events=500,
        )
        result = run_screening_workflow(config, ("kmc",))["results"]["kmc"]
        self.assertEqual(result["stop_reason"], "no_events")
        self.assertEqual(result["final_state_counts"], {"removed": 24})

    def test_continuum_workflow_exposes_wetting_and_solution_gas_temperature(self) -> None:
        config = ScreeningConfig(
            geometry="10_8_180",
            duration_s=0.1,
            grid_spacing_nm=5.0,
            reservoir_height_nm=5.0,
            solution_bulk_temperature_K=291.0,
            substrate_backside_temperature_K=333.0,
            wetting_enabled=True,
            wetting_new_void_filling_mode="capillary",
            advancing_contact_angle_deg=60.0,
            entrance_wetting_delay_s=1.0,
        )
        result = run_screening_workflow(
            config, ("continuum_2d",)
        )["results"]["continuum_2d"]

        self.assertTrue(result["wetting"]["parameters"]["enabled"])
        self.assertEqual(
            result["wetting"]["parameters"]["gas_temperature_K"],
            291.0,
        )
        self.assertEqual(
            result["wetting"]["final_diagnostics"]["time_s"],
            0.1,
        )
        with self.assertRaisesRegex(ValueError, "require.*capillary"):
            ScreeningConfig(
                wetting_enabled=True,
                entrance_wetting_delay_s=1.0,
            )


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env python3
"""Static figures for primary-HF endpoint calibration payloads.

The preferred input schema is ``trench-primary-hf-endpoint/v1`` from
``primary_hf_endpoint.py``.  The public functions also accept a JSON path so
saved calculations can be rendered without importing or rerunning the model.

The three figures answer separate questions:

* how the original GAP FILL disappears in physical time relative to the
  planar blanket-rate reference;
* when the 10, 5 and 1 percent remaining targets are reached, with censored
  (not-reached) runs shown explicitly; and
* where original GAP FILL remains at 300 s and at the exact 1 percent event
  crossing for one representative seed per geometry/material/scenario.

The trench cross-sections use physical nanometre coordinates.  Their
horizontal direction is deliberately enlarged on the page because the
physical aspect ratios are about 17--24; every mask panel states that it is
not an equal-aspect rendering.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np


plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = [
    "Hiragino Sans",
    "Noto Sans JP",
    "YuGothic",
    "Arial",
    "DejaVu Sans",
    "Liberation Sans",
]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42


SCREENING_NOTICE = (
    "Literature-prior calibration only — absolute time follows the supplied "
    "blanket WER; trench cross-section data have not yet been fitted.\n"
    "Do not use these figures as a process recipe."
)

_STYLE = {
    "font.size": 8.0,
    "axes.titlesize": 9.0,
    "axes.labelsize": 8.0,
    "axes.linewidth": 0.7,
    "xtick.labelsize": 7.0,
    "ytick.labelsize": 7.0,
    "legend.fontsize": 6.7,
    "legend.frameon": False,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
}

_SCENARIO_COLORS = {
    "transport_only": "#3274A1",
    "passivation_hypothesis": "#C44E52",
}
_FALLBACK_COLORS = (
    "#3274A1",
    "#C44E52",
    "#55A868",
    "#8172B3",
    "#CCB974",
    "#64B5CD",
)
_SEED_LINESTYLES = ("-", "--", "-.", ":")
_TARGETS = (0.10, 0.05, 0.01)
_TARGET_COLORS = {
    0.10: "#4C78A8",
    0.05: "#F28E2B",
    0.01: "#B84A5A",
}
_MASK_CMAP = ListedColormap(("#D8DCE1", "#E8F4F8", "#B64755"))


def _load_payload(
    value: Mapping[str, Any] | str | Path,
) -> Mapping[str, Any]:
    if isinstance(value, (str, Path)):
        payload = json.loads(Path(value).read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("primary-HF endpoint JSON must contain a mapping")
        return payload
    if not isinstance(value, Mapping):
        raise TypeError("expected a mapping or a JSON path")
    return value


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _sequence(value: Any) -> list[Any]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return list(value)
    return []


def _number(value: Any) -> float | None:
    if value is None or isinstance(value, (bool, np.bool_)):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _cases(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    raw = payload.get("cases", [])
    if isinstance(raw, Mapping):
        result: list[Mapping[str, Any]] = []
        for case_id, item in raw.items():
            if not isinstance(item, Mapping):
                continue
            row = dict(item)
            row.setdefault("case_id", str(case_id))
            result.append(row)
        return result
    return [item for item in _sequence(raw) if isinstance(item, Mapping)]


def _successful_cases(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    result = []
    for case in _cases(payload):
        if case.get("status", "ok") != "ok":
            continue
        validity = _mapping(case.get("result_validity"))
        if validity and validity.get("level") != "valid":
            continue
        result.append(case)
    return result


def _destination(path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def _finish(
    figure: plt.Figure,
    output_path: str | Path,
    *,
    dpi: int,
    bottom: float = 0.18,
) -> Path:
    if not isinstance(dpi, int) or isinstance(dpi, bool) or dpi < 1:
        plt.close(figure)
        raise ValueError("dpi must be a positive integer")
    figure.text(
        0.5,
        0.006,
        SCREENING_NOTICE,
        ha="center",
        va="bottom",
        fontsize=6.2,
        color="0.32",
        wrap=True,
    )
    figure.subplots_adjust(bottom=bottom)
    destination = _destination(output_path)
    figure.savefig(destination, dpi=dpi, bbox_inches="tight")
    plt.close(figure)
    return destination


def _no_data(
    output_path: str | Path,
    *,
    title: str,
    message: str,
    dpi: int,
) -> Path:
    with plt.rc_context(_STYLE):
        figure, axis = plt.subplots(figsize=(7.6, 3.4))
        axis.set_axis_off()
        axis.text(
            0.5,
            0.59,
            "No reported endpoint data",
            ha="center",
            va="center",
            fontsize=15,
            fontweight="semibold",
        )
        axis.text(
            0.5,
            0.40,
            message,
            ha="center",
            va="center",
            transform=axis.transAxes,
            color="0.35",
            wrap=True,
        )
        figure.suptitle(title, y=0.94, fontsize=11)
        return _finish(figure, output_path, dpi=dpi)


def _scenario(case: Mapping[str, Any]) -> str:
    return str(case.get("scenario", "unknown"))


def _scenario_label(case: Mapping[str, Any]) -> str:
    label = case.get("scenario_label_ja")
    if label is not None:
        return str(label)
    return {
        "transport_only": "transport only",
        "passivation_hypothesis": "product + passivation",
    }.get(_scenario(case), _scenario(case).replace("_", " "))


def _scenario_color(name: str, scenario_order: Sequence[str]) -> str:
    if name in _SCENARIO_COLORS:
        return _SCENARIO_COLORS[name]
    try:
        index = list(scenario_order).index(name)
    except ValueError:
        index = 0
    return _FALLBACK_COLORS[index % len(_FALLBACK_COLORS)]


def _panel_key(case: Mapping[str, Any]) -> tuple[str, str, str]:
    return (
        str(case.get("geometry_id", "unknown geometry")),
        str(case.get("preset_id", "unknown preset")),
        str(case.get("material", "unknown material")),
    )


def _panel_title(key: tuple[str, str, str]) -> str:
    geometry, preset, material = key
    return f"{geometry} · {material}\n{preset}"


def _valid_trace(
    case: Mapping[str, Any],
) -> tuple[np.ndarray, np.ndarray] | None:
    trace = _mapping(case.get("trace"))
    raw_time = _sequence(trace.get("physical_time_s"))
    raw_fraction = _sequence(trace.get("remaining_fraction"))
    if not raw_time or len(raw_time) != len(raw_fraction):
        return None
    try:
        time = np.asarray(raw_time, dtype=float)
        fraction = np.asarray(raw_fraction, dtype=float)
    except (TypeError, ValueError):
        return None
    valid = np.isfinite(time) & np.isfinite(fraction) & (time >= 0.0)
    time = time[valid]
    fraction = fraction[valid]
    if time.size == 0:
        return None
    order = np.argsort(time, kind="stable")
    return time[order], np.clip(fraction[order], 0.0, 1.0)


def _planar_clear_time(case: Mapping[str, Any]) -> float | None:
    return _number(_mapping(case.get("planar_reference")).get("planar_clear_time_s"))


def plot_primary_hf_remaining_curves(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot original-GAP-FILL remaining fraction against physical time."""

    payload = _load_payload(payload_or_path)
    cases = [
        case
        for case in _successful_cases(payload)
        if _valid_trace(case) is not None
    ]
    if not cases:
        return _no_data(
            output_path,
            title="Primary-HF original GAP FILL trajectory",
            message=(
                "Expected successful cases[*].trace with physical_time_s and "
                "remaining_fraction arrays."
            ),
            dpi=dpi,
        )

    panel_keys = list(dict.fromkeys(_panel_key(case) for case in cases))
    scenario_order = list(dict.fromkeys(_scenario(case) for case in cases))
    column_count = min(2, len(panel_keys))
    row_count = int(math.ceil(len(panel_keys) / column_count))
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(
            row_count,
            column_count,
            figsize=(6.0 * column_count, 3.65 * row_count),
            squeeze=False,
        )
        legend_items: dict[str, Line2D] = {}
        for panel_index, key in enumerate(panel_keys):
            axis = axes.flat[panel_index]
            subset = [case for case in cases if _panel_key(case) == key]
            replicate_values = sorted(
                {
                    int(case.get("replicate_index", 0))
                    for case in subset
                    if isinstance(case.get("replicate_index", 0), (int, np.integer))
                }
            )
            replicate_style = {
                value: _SEED_LINESTYLES[index % len(_SEED_LINESTYLES)]
                for index, value in enumerate(replicate_values)
            }
            maximum_time_s = 0.0
            for case in subset:
                valid_trace = _valid_trace(case)
                if valid_trace is None:
                    continue
                time_s, fraction = valid_trace
                maximum_time_s = max(maximum_time_s, float(np.max(time_s)))
                scenario = _scenario(case)
                color = _scenario_color(scenario, scenario_order)
                replicate = int(case.get("replicate_index", 0))
                seed = case.get("seed", replicate)
                label = f"{_scenario_label(case)} · seed {seed}"
                line, = axis.plot(
                    time_s / 60.0,
                    fraction,
                    color=color,
                    linestyle=replicate_style.get(replicate, "-"),
                    linewidth=1.45,
                    alpha=0.88,
                    drawstyle="steps-post",
                    label=label,
                )
                legend_items.setdefault(label, line)

            clear_times = [
                value
                for value in (_planar_clear_time(case) for case in subset)
                if value is not None and value > 0.0
            ]
            if clear_times:
                planar_clear_s = float(np.median(clear_times))
                reference_end_s = max(maximum_time_s, planar_clear_s)
                reference_time_s = np.asarray(
                    [0.0, planar_clear_s, reference_end_s], dtype=float
                )
                reference_fraction = np.maximum(
                    1.0 - reference_time_s / planar_clear_s, 0.0
                )
                reference, = axis.plot(
                    reference_time_s / 60.0,
                    reference_fraction,
                    color="0.18",
                    linestyle=(0, (2, 2)),
                    linewidth=1.25,
                    label="planar blanket reference",
                    zorder=1,
                )
                axis.axvline(
                    planar_clear_s / 60.0,
                    color="0.55",
                    linestyle=":",
                    linewidth=0.8,
                    zorder=0,
                )
                legend_items.setdefault("planar blanket reference", reference)
                maximum_time_s = max(maximum_time_s, planar_clear_s)

            if maximum_time_s >= 300.0:
                axis.axvline(
                    5.0,
                    color="#E19C24",
                    linewidth=0.85,
                    linestyle=(0, (5, 3)),
                    zorder=0,
                )
                axis.text(
                    5.0,
                    1.015,
                    "300 s",
                    ha="center",
                    va="bottom",
                    color="#A66B00",
                    fontsize=6.4,
                    clip_on=False,
                )
            for target in _TARGETS:
                axis.axhline(
                    target,
                    color=_TARGET_COLORS[target],
                    linewidth=0.45,
                    alpha=0.30,
                    zorder=0,
                )
            axis.set_title(_panel_title(key))
            axis.set_xlabel("Physical time (min)")
            axis.set_ylabel("Original GAP FILL remaining")
            axis.set_ylim(-0.015, 1.055)
            axis.set_xlim(left=0.0)
            axis.grid(color="0.91", linewidth=0.45)
            axis.spines["top"].set_visible(False)
            axis.spines["right"].set_visible(False)

        for axis in axes.flat[len(panel_keys) :]:
            axis.set_visible(False)
        figure.suptitle(
            "Primary-HF removal trajectory after blanket-clock calibration",
            y=0.995,
            fontsize=11.2,
        )
        if legend_items:
            figure.legend(
                legend_items.values(),
                legend_items.keys(),
                loc="upper center",
                bbox_to_anchor=(0.5, 0.965),
                ncol=min(5, len(legend_items)),
            )
        figure.tight_layout(rect=(0.02, 0.18, 0.99, 0.91), h_pad=2.0, w_pad=1.4)
        return _finish(figure, output_path, dpi=dpi)


def _endpoint_for_target(
    case: Mapping[str, Any], target: float
) -> Mapping[str, Any] | None:
    for endpoint in _sequence(case.get("endpoints")):
        if not isinstance(endpoint, Mapping):
            continue
        reported = _number(endpoint.get("target_remaining_fraction"))
        if reported is not None and math.isclose(
            reported, target, rel_tol=0.0, abs_tol=1.0e-9
        ):
            return endpoint
    return None


def _censor_time_s(case: Mapping[str, Any]) -> float | None:
    planar = _mapping(case.get("planar_reference"))
    value = _number(planar.get("maximum_simulated_physical_time_s"))
    if value is not None and value > 0.0:
        return value
    final_state = _mapping(case.get("final_state"))
    value = _number(final_state.get("requested_physical_time_s"))
    return value if value is not None and value > 0.0 else None


def _stratum_key(case: Mapping[str, Any]) -> tuple[str, str, str, str]:
    return (
        str(case.get("geometry_id", "unknown geometry")),
        str(case.get("preset_id", "unknown preset")),
        str(case.get("material", "unknown material")),
        _scenario(case),
    )


def _stratum_label(
    key: tuple[str, str, str, str],
    example: Mapping[str, Any],
) -> str:
    geometry, preset, material, _scenario_name = key
    return f"{geometry} · {material} · {_scenario_label(example)}\n{preset}"


def plot_primary_hf_endpoint_times(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Compare 10/5/1 percent endpoint times and show censored runs."""

    payload = _load_payload(payload_or_path)
    cases = _successful_cases(payload)
    strata = list(dict.fromkeys(_stratum_key(case) for case in cases))
    has_endpoint = any(
        _endpoint_for_target(case, target) is not None
        for case in cases
        for target in _TARGETS
    )
    if not strata or not has_endpoint:
        return _no_data(
            output_path,
            title="Primary-HF endpoint time comparison",
            message=(
                "Expected successful cases[*].endpoints for remaining-fraction "
                "targets 0.10, 0.05 and 0.01."
            ),
            dpi=dpi,
        )

    scenario_order = list(dict.fromkeys(_scenario(case) for case in cases))
    all_plot_times_min: list[float] = []
    for case in cases:
        for target in _TARGETS:
            endpoint = _endpoint_for_target(case, target)
            time_s = (
                _number(endpoint.get("endpoint_physical_time_s"))
                if endpoint is not None and bool(endpoint.get("reached"))
                else _censor_time_s(case)
            )
            if time_s is not None and time_s > 0.0:
                all_plot_times_min.append(time_s / 60.0)
    if not all_plot_times_min:
        return _no_data(
            output_path,
            title="Primary-HF endpoint time comparison",
            message="Endpoint records exist, but contain no finite physical or censor times.",
            dpi=dpi,
        )

    maximum_time = max(all_plot_times_min)
    minimum_positive = min(all_plot_times_min)
    use_log = maximum_time / minimum_positive >= 30.0
    has_clock_uncertainty = False
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(
            1,
            len(_TARGETS),
            figsize=(13.2, max(4.2, 0.72 * len(strata) + 2.3)),
            sharey=True,
            squeeze=False,
        )
        y_values = np.arange(len(strata), dtype=float)
        examples = {
            key: next(case for case in cases if _stratum_key(case) == key)
            for key in strata
        }
        for target_index, target in enumerate(_TARGETS):
            axis = axes[0, target_index]
            for y, key in zip(y_values, strata, strict=True):
                subset = [case for case in cases if _stratum_key(case) == key]
                color = _scenario_color(key[3], scenario_order)
                offsets = (
                    np.linspace(-0.10, 0.10, len(subset))
                    if len(subset) > 1
                    else np.asarray([0.0])
                )
                reached_times: list[float] = []
                not_reached = 0
                for offset, case in zip(offsets, subset, strict=True):
                    endpoint = _endpoint_for_target(case, target)
                    reached = (
                        endpoint is not None
                        and bool(endpoint.get("reached"))
                        and _number(endpoint.get("endpoint_physical_time_s"))
                        is not None
                    )
                    if reached:
                        time_min = (
                            float(endpoint["endpoint_physical_time_s"]) / 60.0
                        )
                        reached_times.append(time_min)
                        uncertainty = _mapping(
                            endpoint.get(
                                "blanket_rate_uncertainty_interval"
                            )
                        )
                        uncertainty_low = _number(
                            uncertainty.get("lower_physical_time_s")
                        )
                        uncertainty_high = _number(
                            uncertainty.get("upper_physical_time_s")
                        )
                        if (
                            uncertainty_low is not None
                            and uncertainty_high is not None
                        ):
                            has_clock_uncertainty = True
                            axis.hlines(
                                y + offset,
                                uncertainty_low / 60.0,
                                uncertainty_high / 60.0,
                                color=color,
                                linewidth=3.8,
                                alpha=0.24,
                                zorder=1,
                            )
                        axis.scatter(
                            time_min,
                            y + offset,
                            s=28,
                            color=color,
                            edgecolor="white",
                            linewidth=0.4,
                            zorder=3,
                        )
                    else:
                        not_reached += 1
                        censor_s = _censor_time_s(case)
                        if censor_s is not None:
                            axis.scatter(
                                censor_s / 60.0,
                                y + offset,
                                marker=">",
                                s=40,
                                facecolor="white",
                                edgecolor=color,
                                linewidth=1.25,
                                zorder=3,
                            )
                if reached_times:
                    median = float(np.median(reached_times))
                    low = min(reached_times)
                    high = max(reached_times)
                    axis.hlines(
                        y,
                        low,
                        high,
                        color=color,
                        linewidth=2.2,
                        alpha=0.45,
                        zorder=2,
                    )
                    axis.scatter(
                        median,
                        y,
                        marker="|",
                        s=115,
                        color="0.08",
                        linewidth=1.4,
                        zorder=4,
                    )
                if not_reached:
                    axis.text(
                        0.985,
                        y,
                        f"not reached {not_reached}/{len(subset)}",
                        transform=axis.get_yaxis_transform(),
                        ha="right",
                        va="center",
                        fontsize=6.2,
                        color="#8A3137",
                        bbox={
                            "boxstyle": "round,pad=0.12",
                            "facecolor": "white",
                            "edgecolor": "none",
                            "alpha": 0.78,
                        },
                    )
            axis.set_title(f"Target remaining = {target:.0%}")
            axis.set_xlabel("Physical endpoint time (min)")
            axis.grid(axis="x", color="0.91", linewidth=0.45)
            axis.spines["top"].set_visible(False)
            axis.spines["right"].set_visible(False)
            if use_log:
                axis.set_xscale("log")
            else:
                axis.set_xlim(left=0.0)

        axes[0, 0].set_yticks(y_values)
        axes[0, 0].set_yticklabels(
            [_stratum_label(key, examples[key]) for key in strata]
        )
        axes[0, 0].invert_yaxis()
        legend_handles = [
                Line2D(
                    [],
                    [],
                    marker="o",
                    linestyle="none",
                    color="0.25",
                    markerfacecolor="0.25",
                    label="reached (seed)",
                ),
                Line2D(
                    [],
                    [],
                    marker=">",
                    linestyle="none",
                    color="#8A3137",
                    markerfacecolor="white",
                    label="not reached at simulated limit",
                ),
                Line2D(
                    [],
                    [],
                    marker="|",
                    markersize=11,
                    linestyle="-",
                    color="0.2",
                    label="median and seed range",
                ),
        ]
        if has_clock_uncertainty:
            legend_handles.append(
                Line2D(
                    [],
                    [],
                    linestyle="-",
                    linewidth=4,
                    alpha=0.28,
                    color="0.25",
                    label="blanket-WER input range (clock only)",
                )
            )
        figure.legend(
            handles=legend_handles,
            loc="upper center",
            bbox_to_anchor=(0.5, 0.965),
            ncol=len(legend_handles),
        )
        figure.suptitle(
            "Exact discrete primary-HF endpoint crossings",
            y=0.995,
            fontsize=11.2,
        )
        figure.tight_layout(rect=(0.02, 0.19, 0.99, 0.92), w_pad=1.0)
        return _finish(figure, output_path, dpi=dpi)


def _snapshot_array(
    snapshot: Mapping[str, Any],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None:
    try:
        x_nm = np.asarray(_sequence(snapshot.get("x_nm")), dtype=float)
        depth_nm = np.asarray(_sequence(snapshot.get("depth_nm")), dtype=float)
        cavity = np.asarray(snapshot.get("cavity_mask"), dtype=bool)
        remaining = np.asarray(
            snapshot.get("remaining_original_gap_fill_mask"), dtype=bool
        )
    except (TypeError, ValueError):
        return None
    if (
        x_nm.ndim != 1
        or depth_nm.ndim != 1
        or x_nm.size < 1
        or depth_nm.size < 1
        or cavity.shape != (depth_nm.size, x_nm.size)
        or remaining.shape != cavity.shape
        or not np.all(np.isfinite(x_nm))
        or not np.all(np.isfinite(depth_nm))
    ):
        return None
    return x_nm, depth_nm, cavity, remaining


def _snapshot_for_label(
    case: Mapping[str, Any], kind: str
) -> Mapping[str, Any] | None:
    snapshots = [
        item
        for item in _sequence(case.get("snapshots"))
        if isinstance(item, Mapping)
    ]
    if kind == "fixed_300s":
        for snapshot in snapshots:
            label = str(snapshot.get("label", ""))
            time_s = _number(snapshot.get("physical_time_s"))
            if label == "fixed_300s" or (
                label.startswith("fixed_")
                and time_s is not None
                and math.isclose(time_s, 300.0, rel_tol=0.0, abs_tol=1.0e-6)
            ):
                return snapshot
        for snapshot in snapshots:
            time_s = _number(snapshot.get("physical_time_s"))
            if time_s is not None and math.isclose(
                time_s, 300.0, rel_tol=0.0, abs_tol=1.0e-6
            ):
                return snapshot
        return None
    if kind == "target_1pct":
        for snapshot in snapshots:
            if str(snapshot.get("label", "")) == "target_1pct":
                return snapshot
        endpoint = _endpoint_for_target(case, 0.01)
        endpoint_time = (
            _number(endpoint.get("endpoint_physical_time_s"))
            if endpoint is not None and bool(endpoint.get("reached"))
            else None
        )
        if endpoint_time is not None:
            for snapshot in snapshots:
                time_s = _number(snapshot.get("physical_time_s"))
                if time_s is not None and math.isclose(
                    time_s,
                    endpoint_time,
                    rel_tol=1.0e-10,
                    abs_tol=1.0e-6,
                ):
                    return snapshot
    return None


def _edges_from_centres(values: np.ndarray) -> np.ndarray:
    if values.size == 1:
        return np.asarray([values[0] - 0.5, values[0] + 0.5], dtype=float)
    differences = np.diff(values)
    inner = values[:-1] + 0.5 * differences
    return np.concatenate(
        (
            [values[0] - 0.5 * differences[0]],
            inner,
            [values[-1] + 0.5 * differences[-1]],
        )
    )


def _representative_cases(
    cases: Sequence[Mapping[str, Any]],
) -> list[Mapping[str, Any]]:
    # One seed per geometry/material/scenario.  Prefer a run containing both
    # requested snapshots, then choose the lowest replicate/seed deterministically.
    grouped: dict[tuple[str, str, str], list[Mapping[str, Any]]] = {}
    order: list[tuple[str, str, str]] = []
    for case in cases:
        key = (
            str(case.get("geometry_id", "unknown geometry")),
            str(case.get("material", "unknown material")),
            _scenario(case),
        )
        if key not in grouped:
            grouped[key] = []
            order.append(key)
        grouped[key].append(case)

    selected = []
    for key in order:
        options = grouped[key]

        def rank(case: Mapping[str, Any]) -> tuple[int, int, int]:
            fixed = _snapshot_for_label(case, "fixed_300s") is not None
            target = _snapshot_for_label(case, "target_1pct") is not None
            replicate = int(case.get("replicate_index", 0))
            seed = int(case.get("seed", replicate))
            return (-(int(fixed) + int(target)), replicate, seed)

        selected.append(min(options, key=rank))
    return selected


def _plot_mask(
    axis: plt.Axes,
    snapshot: Mapping[str, Any],
) -> bool:
    arrays = _snapshot_array(snapshot)
    if arrays is None:
        return False
    x_nm, depth_nm, cavity, remaining = arrays
    state = np.zeros(cavity.shape, dtype=np.uint8)
    state[cavity] = 1
    state[remaining] = 2
    axis.pcolormesh(
        _edges_from_centres(x_nm),
        _edges_from_centres(depth_nm),
        state,
        cmap=_MASK_CMAP,
        vmin=-0.5,
        vmax=2.5,
        shading="flat",
        rasterized=True,
    )
    axis.set_xlim(float(np.min(_edges_from_centres(x_nm))), float(np.max(_edges_from_centres(x_nm))))
    axis.set_ylim(
        float(np.max(_edges_from_centres(depth_nm))),
        float(np.min(_edges_from_centres(depth_nm))),
    )
    axis.axhline(0.0, color="0.25", linewidth=0.55, linestyle=":")
    axis.set_aspect("auto")
    axis.grid(False)
    return True


def _mask_case_label(case: Mapping[str, Any]) -> str:
    return (
        f"{case.get('geometry_id', 'unknown')} · "
        f"{case.get('material', 'unknown')} · {_scenario_label(case)}\n"
        f"seed {case.get('seed', case.get('replicate_index', '?'))}"
    )


def plot_primary_hf_representative_masks(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot representative 300 s and 1 percent endpoint trench masks."""

    payload = _load_payload(payload_or_path)
    cases = _representative_cases(_successful_cases(payload))
    if not cases or not any(
        _snapshot_array(snapshot) is not None
        for case in cases
        for snapshot in _sequence(case.get("snapshots"))
        if isinstance(snapshot, Mapping)
    ):
        return _no_data(
            output_path,
            title="Representative primary-HF trench masks",
            message=(
                "Expected cases[*].snapshots with x_nm, depth_nm, cavity_mask "
                "and remaining_original_gap_fill_mask."
            ),
            dpi=dpi,
        )

    row_count = len(cases)
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(
            row_count,
            3,
            figsize=(11.6, max(4.6, 2.55 * row_count + 1.7)),
            squeeze=False,
            gridspec_kw={"width_ratios": (1.65, 4.0, 4.0)},
        )
        for row, case in enumerate(cases):
            label_axis = axes[row, 0]
            label_axis.set_axis_off()
            label_axis.text(
                0.98,
                0.5,
                _mask_case_label(case),
                transform=label_axis.transAxes,
                ha="right",
                va="center",
                fontsize=7.1,
            )
            fixed = _snapshot_for_label(case, "fixed_300s")
            target = _snapshot_for_label(case, "target_1pct")
            for column, (snapshot, kind) in enumerate(
                ((fixed, "300 s"), (target, "1% endpoint")),
                start=1,
            ):
                axis = axes[row, column]
                plotted = snapshot is not None and _plot_mask(axis, snapshot)
                if plotted:
                    time_s = _number(snapshot.get("physical_time_s"))
                    title = kind
                    if time_s is not None:
                        title += f" · {time_s / 60.0:.2f} min"
                    axis.set_title(title, fontsize=8.3)
                else:
                    axis.set_axis_off()
                    endpoint = _endpoint_for_target(case, 0.01)
                    explicitly_unreached = (
                        kind == "1% endpoint"
                        and endpoint is not None
                        and not bool(endpoint.get("reached"))
                    )
                    message = (
                        "1% endpoint not reached\nwithin simulated horizon"
                        if explicitly_unreached
                        else f"{kind} snapshot not reported"
                    )
                    axis.text(
                        0.5,
                        0.50,
                        message,
                        ha="center",
                        va="center",
                        transform=axis.transAxes,
                        color="#8A3137" if explicitly_unreached else "0.38",
                        fontsize=8.2,
                    )
                if row == row_count - 1 and plotted:
                    axis.set_xlabel("Lateral position x (nm)")
                if column == 1 and plotted:
                    axis.set_ylabel("Depth z (nm)")

        figure.legend(
            handles=(
                Patch(facecolor=_MASK_CMAP(0), edgecolor="0.5", label="outside trench"),
                Patch(facecolor=_MASK_CMAP(1), edgecolor="0.5", label="removed / liquid-accessible"),
                Patch(facecolor=_MASK_CMAP(2), edgecolor="0.5", label="original GAP FILL remaining"),
            ),
            loc="upper center",
            bbox_to_anchor=(0.5, 0.925),
            ncol=3,
        )
        figure.suptitle(
            "Representative primary-HF cross-sections",
            y=0.998,
            fontsize=10.8,
        )
        figure.text(
            0.5,
            0.960,
            "Horizontal direction enlarged for visibility; x and z ticks are "
            "physical nm (non-equal display aspect)",
            ha="center",
            va="top",
            fontsize=7.4,
            color="0.28",
        )
        figure.tight_layout(rect=(0.05, 0.16, 0.99, 0.84), h_pad=1.35, w_pad=1.15)
        return _finish(figure, output_path, dpi=dpi)


def plot_primary_hf_endpoint_visualizations(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_directory: str | Path,
    *,
    dpi: int = 300,
) -> dict[str, Path]:
    """Write the three standard primary-HF endpoint PNG figures."""

    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    return {
        "primary_hf_remaining_curves": plot_primary_hf_remaining_curves(
            payload_or_path,
            directory / "primary_hf_remaining_curves.png",
            dpi=dpi,
        ),
        "primary_hf_endpoint_times": plot_primary_hf_endpoint_times(
            payload_or_path,
            directory / "primary_hf_endpoint_times.png",
            dpi=dpi,
        ),
        "primary_hf_representative_masks": plot_primary_hf_representative_masks(
            payload_or_path,
            directory / "primary_hf_representative_masks.png",
            dpi=dpi,
        ),
    }


__all__ = [
    "SCREENING_NOTICE",
    "plot_primary_hf_endpoint_times",
    "plot_primary_hf_endpoint_visualizations",
    "plot_primary_hf_remaining_curves",
    "plot_primary_hf_representative_masks",
]

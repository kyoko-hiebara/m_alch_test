from __future__ import annotations

import csv
import json
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from calibrated_wet_sequence import (
    BRANCH_ACCESSIBLE_FIXED,
    BRANCH_ACCESSIBLE_SCALED,
    BRANCH_ALL_PHYSICAL,
    BRANCH_ALL_PHYSICAL_SCALED,
    CalibratedWetSequenceConfig,
    run_calibrated_wet_sequence,
    save_calibrated_wet_sequence_csv,
    save_calibrated_wet_sequence_json,
)
from run_calibrated_wet_sequence import config_for_mode, quality_exit_code


SIN_PRESET = "sin_barcellona_b_0p55wt"


def coarse_config(**updates: object) -> CalibratedWetSequenceConfig:
    values: dict[str, object] = {
        "geometries": ("10_10_180",),
        "presets": (SIN_PRESET,),
        "scenarios": ("transport_only",),
        "replicate_seeds": (17,),
        "primary_target_remaining_fraction": 0.5,
        "grid_spacing_nm": 20.0,
        "reservoir_height_nm": 20.0,
        "lateral_margin_nm": 0.0,
        "maximum_planar_clear_time_multiplier": 1.5,
        "primary_sync_steps": 4,
        "maximum_events": 5_000,
        "parallel_workers": 1,
        "coupon_width_nm": 40.0,
        "coupon_depth_nm": 60.0,
        "coupon_maximum_events": 5_000,
        "surface_profile_bins": 6,
    }
    values.update(updates)
    return CalibratedWetSequenceConfig(**values)


def assert_finite_tree(testcase: unittest.TestCase, value: object) -> None:
    if isinstance(value, float):
        testcase.assertTrue(math.isfinite(value))
    elif isinstance(value, dict):
        for item in value.values():
            assert_finite_tree(testcase, item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            assert_finite_tree(testcase, item)


class CalibratedWetSequenceConfigTests(unittest.TestCase):
    def test_validation_and_mode_temperatures(self) -> None:
        with self.assertRaisesRegex(ValueError, "collector_branches"):
            coarse_config(collector_branches=("unknown",))
        with self.assertRaisesRegex(ValueError, "duplicates"):
            coarse_config(replicate_seeds=(1, 1))
        quick = config_for_mode(
            "quick",
            1,
            liquid_temperature_K=290.0,
            substrate_temperature_K=330.0,
        )
        self.assertEqual(quick.solution_temperature_K, 290.0)
        self.assertEqual(quick.substrate_temperature_K, 330.0)
        self.assertEqual(quick.geometries, ("10_10_180", "7_7_170"))


class CalibratedWetSequenceRealRunTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = run_calibrated_wet_sequence(coarse_config())

    def test_live_endpoint_executes_four_paired_branches(self) -> None:
        quality = self.payload["quality_summary"]
        self.assertEqual(quality["successful_coupon_runs"], 1)
        self.assertEqual(quality["executed_downstream_strata"], 1)
        self.assertEqual(quality["skipped_censored_strata"], 0)
        self.assertEqual(quality["failed_primary_strata"], 0)
        self.assertEqual(quality["successful_branch_cases"], 4)
        self.assertEqual(quality["mass_balance_failure_cases"], 0)
        self.assertEqual(quality["fixed_inventory_pair_mismatch_count"], 0)
        self.assertEqual(quality_exit_code(quality), 0)
        endpoint_times = {
            case["primary_endpoint"]["endpoint_physical_time_s"]
            for case in self.payload["cases"]
        }
        removed_counts = {
            case["lineage"]["removed_count_at_endpoint"]
            for case in self.payload["cases"]
        }
        self.assertEqual(len(endpoint_times), 1)
        self.assertEqual(len(removed_counts), 1)
        self.assertTrue(
            all(
                case["lineage"]["restart_state_basis"]
                == "live_in_memory_TrenchKMCOutcome"
                for case in self.payload["cases"]
            )
        )

    def test_fixed_inventory_and_area_scaled_hypotheses_are_separate(self) -> None:
        cases = {
            case["collector_branch_id"]: case
            for case in self.payload["cases"]
        }
        upper_fixed = cases[BRANCH_ALL_PHYSICAL]
        lower_fixed = cases[BRANCH_ACCESSIBLE_FIXED]
        upper_scaled = cases[BRANCH_ALL_PHYSICAL_SCALED]
        lower_scaled = cases[BRANCH_ACCESSIBLE_SCALED]
        upper_inventory = upper_fixed["final_metrics"][
            "drydown_total_deposit_inventory_native"
        ]
        self.assertAlmostEqual(
            lower_fixed["final_metrics"][
                "drydown_total_deposit_inventory_native"
            ],
            upper_inventory,
        )
        self.assertAlmostEqual(
            upper_scaled["final_metrics"][
                "drydown_total_deposit_inventory_native"
            ],
            upper_inventory,
        )
        access_fraction = lower_scaled["collector_branch"][
            "accessible_weighted_contact_fraction"
        ]
        self.assertLess(access_fraction, 1.0)
        self.assertAlmostEqual(
            lower_scaled["final_metrics"][
                "drydown_total_deposit_inventory_native"
            ]
            / upper_inventory,
            access_fraction,
        )
        self.assertEqual(
            lower_fixed["collector_branch"]["unassigned_precursor_fraction"],
            0.0,
        )
        self.assertGreater(
            lower_scaled["collector_branch"][
                "unassigned_precursor_fraction"
            ],
            0.0,
        )
        self.assertEqual(
            upper_fixed["collector_branch"]["paired_branch_id"],
            lower_fixed["collector_branch"]["paired_branch_id"],
        )
        self.assertEqual(
            upper_scaled["collector_branch"]["paired_branch_id"],
            lower_scaled["collector_branch"]["paired_branch_id"],
        )

    def test_accessible_branch_deposit_support_and_stage_schema(self) -> None:
        case = next(
            item
            for item in self.payload["cases"]
            if item["collector_branch_id"] == BRANCH_ACCESSIBLE_FIXED
        )
        enabled = np.asarray(
            case["collector_branch"]["eligible_collector_mask"],
            dtype=bool,
        )
        dry = case["stages"]["drydown_endpoint"]
        wall = np.asarray(
            dry["spatial"]["wall_deposit_thickness_nm"], dtype=float
        )
        bottom = np.asarray(
            dry["spatial"]["bottom_deposit_thickness_nm"], dtype=float
        )
        self.assertTrue(np.all((wall + bottom > 0.0) <= enabled))
        times = [
            case["stages"][name]["cumulative_physical_time_s"]
            for name in (
                "hf_endpoint",
                "rinse_endpoint",
                "drydown_endpoint",
                "second_wet_endpoint",
            )
        ]
        self.assertEqual(times, sorted(times))
        for stage in case["stages"].values():
            self.assertIn("matrix", stage)
            self.assertIn("deposit_diagnostics", stage)
            self.assertIn("residue_components", stage)
            self.assertIn("mass_balance", stage)
            self.assertIn("spatial", stage)
            self.assertTrue(stage["mass_balance"]["closed"])
        components = dry["residue_components"]
        self.assertAlmostEqual(
            components["combined"][
                "fraction_of_discrete_initial_gap_fill_area"
            ],
            components["original_gap_fill"][
                "fraction_of_discrete_initial_gap_fill_area"
            ]
            + components["post_hf_deposit"][
                "fraction_of_discrete_initial_gap_fill_area"
            ],
        )

    def test_second_wet_uses_explicit_provisional_physical_clock(self) -> None:
        case = self.payload["cases"][0]
        clock = case["second_wet_clock"]
        primary_scale = case["primary_endpoint"]["clock_calibration"][
            "physical_seconds_per_model_second"
        ]
        self.assertAlmostEqual(
            clock["physical_matrix_rate_per_s"],
            clock["native_primary_site_rate_per_model_s"] / primary_scale,
        )
        self.assertFalse(clock["second_wet_independently_calibrated"])
        self.assertTrue(clock["source_graph_time_excluded_from_stage_clock"])

    def test_strict_json_and_csv_round_trip(self) -> None:
        assert_finite_tree(self, self.payload)
        json.dumps(self.payload, allow_nan=False)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            json_path = save_calibrated_wet_sequence_json(
                self.payload, root / "result.json"
            )
            csv_path = save_calibrated_wet_sequence_csv(
                self.payload, root / "result.csv"
            )
            loaded = json.loads(json_path.read_text(encoding="utf-8"))
            with csv_path.open(encoding="utf-8", newline="") as stream:
                rows = list(csv.DictReader(stream))
        self.assertEqual(
            loaded["schema_version"], "trench-calibrated-wet-sequence/v1"
        )
        self.assertEqual(len(rows), 4)
        self.assertIn("capture_policy", rows[0])

    def test_censored_primary_is_retained_but_post_hf_is_not_fabricated(self) -> None:
        payload = run_calibrated_wet_sequence(
            coarse_config(
                primary_target_remaining_fraction=0.0,
                maximum_planar_clear_time_multiplier=1.0e-6,
            )
        )
        self.assertEqual(
            payload["quality_summary"]["skipped_censored_strata"], 1
        )
        self.assertEqual(
            payload["quality_summary"]["successful_branch_cases"], 0
        )
        self.assertEqual(payload["cases"], [])
        self.assertEqual(payload["strata"][0]["status"], "skipped")
        self.assertIn("right_censored", payload["strata"][0]["skip_reason"])

    def test_serial_and_two_workers_preserve_order_and_values(self) -> None:
        serial = run_calibrated_wet_sequence(
            coarse_config(replicate_seeds=(17, 19), parallel_workers=1)
        )
        parallel = run_calibrated_wet_sequence(
            coarse_config(replicate_seeds=(17, 19), parallel_workers=2)
        )
        self.assertEqual(
            [item["stratum_id"] for item in serial["strata"]],
            [item["stratum_id"] for item in parallel["strata"]],
        )
        self.assertEqual(
            serial["coupon_calibrations"],
            parallel["coupon_calibrations"],
        )
        self.assertEqual(serial["strata"], parallel["strata"])
        self.assertEqual(serial["cases"], parallel["cases"])
        self.assertEqual(
            serial["paired_branch_contrasts"],
            parallel["paired_branch_contrasts"],
        )
        self.assertEqual(serial["aggregates"], parallel["aggregates"])
        self.assertEqual(serial["quality_summary"], parallel["quality_summary"])


if __name__ == "__main__":
    unittest.main()

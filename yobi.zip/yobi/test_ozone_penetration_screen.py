from __future__ import annotations

import json
import math
import tempfile
import unittest
from pathlib import Path

from ozone_penetration_screen import (
    OzonePenetrationConfig,
    concentration_fraction_at_depth,
    run_ozone_penetration_screen,
    save_ozone_penetration_json,
)


class OzonePenetrationScreenTests(unittest.TestCase):
    def test_phi_one_matches_closed_form(self) -> None:
        payload = run_ozone_penetration_screen(
            OzonePenetrationConfig(
                geometry_names=("10_10_180",),
                thiele_moduli=(0.0, 1.0),
                effective_diffusivity_m2_s=1.0e-5,
            )
        )
        zero, one = payload["cases"][0]["sweep"]
        self.assertEqual(zero["bottom_concentration_fraction"], 1.0)
        self.assertEqual(zero["depth_average_concentration_fraction"], 1.0)
        self.assertAlmostEqual(
            one["bottom_concentration_fraction"],
            1.0 / math.cosh(1.0),
            places=12,
        )
        self.assertAlmostEqual(
            one["depth_average_concentration_fraction"],
            math.tanh(1.0),
            places=12,
        )
        self.assertAlmostEqual(
            one["surface_velocity_over_diffusivity_m_inv"],
            154320.98765432098,
            places=6,
        )
        self.assertAlmostEqual(
            one["equivalent_surface_reaction_velocity_m_s"],
            1.543209876543,
            places=12,
        )
        self.assertTrue(
            payload["quality"]["bottom_delivery_monotonic_with_phi"]
        )
        self.assertTrue(payload["quality"]["opening_boundary_exact"])
        transient = payload["cases"][0]["transient_check"]
        self.assertTrue(transient["steady_state_screen_passes"])
        self.assertGreater(transient["fourier_number"], 10.0)

    def test_profile_boundary_and_delivery_threshold(self) -> None:
        self.assertAlmostEqual(
            concentration_fraction_at_depth(2.0, 0.0),
            1.0,
            places=12,
        )
        self.assertAlmostEqual(
            concentration_fraction_at_depth(2.0, 1.0),
            1.0 / math.cosh(2.0),
            places=12,
        )
        payload = run_ozone_penetration_screen(
            OzonePenetrationConfig(
                geometry_names=("7_7_170",),
                thiele_moduli=(1.0,),
                bottom_delivery_targets=(0.5,),
            )
        )
        threshold = payload["cases"][0]["bottom_delivery_thresholds"][0]
        self.assertAlmostEqual(
            threshold["maximum_thiele_modulus"],
            math.acosh(2.0),
            places=12,
        )

    def test_validation_and_strict_json_round_trip(self) -> None:
        with self.assertRaisesRegex(ValueError, "straight geometry"):
            OzonePenetrationConfig(geometry_names=("10_8_180",))
        with self.assertRaisesRegex(ValueError, "non-negative"):
            OzonePenetrationConfig(thiele_moduli=(-0.1,))
        with self.assertRaisesRegex(ValueError, "finite and positive"):
            OzonePenetrationConfig(effective_diffusivity_m2_s=0.0)
        with self.assertRaisesRegex(ValueError, "finite and positive"):
            OzonePenetrationConfig(exposure_duration_s=0.0)

        payload = run_ozone_penetration_screen()
        with tempfile.TemporaryDirectory() as directory:
            path = save_ozone_penetration_json(
                payload,
                Path(directory) / "ozone.json",
            )
            saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(
            saved["schema_version"],
            "ozone-slit-penetration-screen/v1",
        )
        self.assertEqual(len(saved["cases"]), 2)
        self.assertIsNone(
            saved["cases"][0]["transient_check"][
                "steady_state_screen_passes"
            ]
        )


if __name__ == "__main__":
    unittest.main()

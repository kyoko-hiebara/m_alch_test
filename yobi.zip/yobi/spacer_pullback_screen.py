"""Can a cyclic wet reset clear the residue without eating the spacer?

The reset-silicon screen priced what the oxidising reset spends on the
silicon substrate.  This screen prices the other protected surface: the
inner spacer.  The same oxidise-and-strip mechanism that removes a
carbon-containing residue also attacks the spacer, and both the residue
material and the spacer material are unknown to this project -- each is
one of the films Kawarazaki et al. (2024) measured (SiN, SiOCN C:5%,
SiCN C:22%, SiCN C:40%).  If they happen to be the *same* material,
chemical selectivity is exactly one and only geometric shielding can
protect the spacer; if they differ, the Fig. 2 pairs give per-cycle
selectivities up to ~60x.  Which world we are in is a composition
measurement nobody has made, so this screen takes the maximin route:
evaluate every (residue, spacer) candidate pair and ask whether any
recommendation survives the full matrix.

Per cycle and per material the removal is ``dhf_only + epsilon x
(ozone-enabled increment)``, both bars from the stored Fig. 2 endpoints.
``epsilon`` is the efficiency of the *wet* reset relative to the dry
240 C ozone-bake anchor: no wet measurement exists, so it is a swept
assumption, applied uniformly to every material.  Cycle counts to clear
a residue pad, spacer pull-back ``N x per_cycle(spacer) x shielding``,
and the silicon recession rider from the reset-silicon screen are then
tabulated against declared spacer budgets.  Everything stays on the
Kawarazaki clock; nothing is mixed with the measured-blanket clock of
the decay screens, because the films and the dHF differ.

**Boundaries.**  The Fig. 2 bars are raster digitizations with a 0.05 nm
resolution; per-cycle values inherit that band, cells whose feasibility
flips inside the band are flagged fragile, and the SiN and SiCN C:22%
dHF-only bars sit at the resolution floor, so their worst-case cycle
counts are unbounded.  The dry-bake anchor is the only measured cycle
datum -- a wet O3-DIW/SC1 reset has no measured per-cycle value, which
is exactly why ``epsilon`` is swept instead of asserted.  Shielding is a
bare geometric factor standing in for the unresolved spacer-pocket
transport problem (the fixed device geometry is not a lever), and the
spacer budget is a device number this project does not know.  Blanket
values are applied to a trench.  Cycle-count linearity is carried beyond
the reported 3-cycle window.  Nothing here is a process recipe.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from literature_parameters import (
    KAWARAZAKI_2024_FIG2_ENDPOINTS,
    LiteratureCyclicEtchEndpoint,
)
from reset_silicon_cost_screen import (
    ResetOxidationAssumptions,
    per_reset_recession_nm,
)


SCHEMA_VERSION = "spacer-pullback-maximin-screen/v1"
MODEL_NOTICE = (
    "Maximin over unknown residue and spacer materials, both drawn from "
    "the four Kawarazaki Fig. 2 films. Per-cycle removal is dhf_only + "
    "epsilon x ozone increment with epsilon the unmeasured wet-reset "
    "efficiency relative to the dry 240 C bake anchor. Spacer pull-back "
    "is N x per_cycle(spacer) x shielding; shielding stands in for the "
    "unresolved pocket-transport problem and the spacer budget is not "
    "known to this project. Same-material pairs have chemical "
    "selectivity exactly one. Stays on the Kawarazaki clock. Not a "
    "process recipe."
)

DEFAULT_MATERIAL_KEYS = tuple(KAWARAZAKI_2024_FIG2_ENDPOINTS)
DEFAULT_RESIDUE_THICKNESSES_NM = (1.0, 2.0, 3.0)
DEFAULT_SPACER_BUDGETS_NM = (0.3, 0.5, 1.0)
DEFAULT_SHIELDING_FACTORS = (1.0, 0.3, 0.1)
DEFAULT_WET_RESET_EFFICIENCIES = (0.3, 1.0)
DEFAULT_OXIDE_THICKNESS_NM = 1.0
MAXIMUM_CYCLES = 500


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def _efficiency(value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or not 0.0 <= number <= 1.0:
        raise ValueError("wet_reset_efficiency must be within [0, 1]")
    return number


def _endpoint(key: str) -> LiteratureCyclicEtchEndpoint:
    try:
        return KAWARAZAKI_2024_FIG2_ENDPOINTS[key]
    except KeyError as exc:
        choices = ", ".join(KAWARAZAKI_2024_FIG2_ENDPOINTS)
        raise ValueError(
            f"unknown material key {key!r}; choose from {choices}"
        ) from exc


def per_cycle_removal_nm(
    key: str, *, wet_reset_efficiency: float
) -> dict[str, float]:
    """Per-cycle removal for one film at one wet-reset efficiency.

    ``central = dhf_only + epsilon x increment`` is a convex combination
    of the two digitized bars, so the raster band collapses to plus or
    minus one resolution step, clipped at zero.
    """

    efficiency = _efficiency(wet_reset_efficiency)
    endpoint = _endpoint(key)
    central = (
        endpoint.dhf_only_etch_amount_nm
        + efficiency * endpoint.ozone_enabled_increment_nm_per_cycle
    )
    resolution = endpoint.digitization_resolution_nm
    return {
        "central": central,
        "low": max(0.0, central - resolution),
        "high": central + resolution,
        "resolution_nm": resolution,
    }


def cycles_to_clear_residue(
    key: str,
    *,
    thickness_nm: float,
    wet_reset_efficiency: float,
    maximum_cycles: int = MAXIMUM_CYCLES,
) -> dict[str, Any]:
    """Cycles to clear a residue pad on the Kawarazaki clock.

    The worst-case count uses the raster-low per-cycle value; when that
    value is zero (bars at the resolution floor) the count is unbounded
    and reported as ``None``, mirroring the process-screen language that
    those films' clear times cannot be bounded from Fig. 2.
    """

    thickness = _finite_positive("thickness_nm", thickness_nm)
    removal = per_cycle_removal_nm(
        key, wet_reset_efficiency=wet_reset_efficiency
    )

    def _count(per_cycle: float) -> int | None:
        if per_cycle <= 0.0:
            return None
        cycles = math.ceil(thickness / per_cycle)
        return cycles if cycles <= int(maximum_cycles) else None

    return {
        "material": key,
        "thickness_nm": thickness,
        "per_cycle_removal_nm": removal,
        "cycles_central": _count(removal["central"]),
        "cycles_worst_raster": _count(removal["low"]),
        "worst_case_unbounded_within_resolution": removal["low"] <= 0.0,
    }


def selectivity_matrix(
    *,
    wet_reset_efficiency: float,
    material_keys: Sequence[str] = DEFAULT_MATERIAL_KEYS,
) -> list[dict[str, Any]]:
    """Per-cycle selectivity residue/spacer for every candidate pair.

    Same-material pairs are exactly one by construction -- the chemical
    route offers the spacer no protection there.  Band edges divide the
    adverse raster corners and are ``None`` when the spacer bar can
    reach zero inside the band.
    """

    removals = {
        key: per_cycle_removal_nm(
            key, wet_reset_efficiency=wet_reset_efficiency
        )
        for key in material_keys
    }
    rows: list[dict[str, Any]] = []
    for residue_key in material_keys:
        for spacer_key in material_keys:
            residue = removals[residue_key]
            spacer = removals[spacer_key]
            rows.append(
                {
                    "residue": residue_key,
                    "spacer": spacer_key,
                    "same_material": residue_key == spacer_key,
                    "selectivity_central": (
                        residue["central"] / spacer["central"]
                    ),
                    "selectivity_low": (
                        residue["low"] / spacer["high"]
                        if spacer["high"] > 0.0
                        else None
                    ),
                    "selectivity_high": (
                        residue["high"] / spacer["low"]
                        if spacer["low"] > 0.0
                        else None
                    ),
                }
            )
    return rows


def pullback_feasibility(
    *,
    residue_thickness_nm: float,
    spacer_budget_nm: float,
    shielding_factor: float,
    wet_reset_efficiency: float,
    material_keys: Sequence[str] = DEFAULT_MATERIAL_KEYS,
    oxide_thickness_nm: float = DEFAULT_OXIDE_THICKNESS_NM,
) -> list[dict[str, Any]]:
    """Every (residue, spacer) pair under one declared condition set.

    Feasibility at central values gates the maximin verdict; a cell
    whose verdict flips between the central and adverse raster corners
    is flagged fragile rather than silently trusted.  The silicon
    recession rider charges one oxidation per cycle at the reset-screen
    centre assumption.
    """

    budget = _finite_positive("spacer_budget_nm", spacer_budget_nm)
    shielding = float(shielding_factor)
    if not math.isfinite(shielding) or not 0.0 < shielding <= 1.0:
        raise ValueError("shielding_factor must be within (0, 1]")
    recession_per_cycle = per_reset_recession_nm(
        ResetOxidationAssumptions(oxide_thickness_nm=oxide_thickness_nm)
    )
    rows: list[dict[str, Any]] = []
    for residue_key in material_keys:
        clearing = cycles_to_clear_residue(
            residue_key,
            thickness_nm=residue_thickness_nm,
            wet_reset_efficiency=wet_reset_efficiency,
        )
        for spacer_key in material_keys:
            spacer = per_cycle_removal_nm(
                spacer_key, wet_reset_efficiency=wet_reset_efficiency
            )
            cycles = clearing["cycles_central"]
            cycles_adverse = clearing["cycles_worst_raster"]
            pullback = (
                None
                if cycles is None
                else cycles * spacer["central"] * shielding
            )
            pullback_adverse = (
                None
                if cycles_adverse is None
                else cycles_adverse * spacer["high"] * shielding
            )
            feasible = pullback is not None and pullback <= budget + 1e-12
            feasible_adverse = (
                pullback_adverse is not None
                and pullback_adverse <= budget + 1e-12
            )
            rows.append(
                {
                    "residue": residue_key,
                    "spacer": spacer_key,
                    "same_material": residue_key == spacer_key,
                    "cycles_central": cycles,
                    "cycles_worst_raster": cycles_adverse,
                    "spacer_pullback_nm": pullback,
                    "spacer_pullback_adverse_nm": pullback_adverse,
                    "silicon_recession_nm": (
                        None
                        if cycles is None
                        else cycles * recession_per_cycle
                    ),
                    "feasible": feasible,
                    "feasible_adverse": feasible_adverse,
                    "fragile_within_raster": feasible != feasible_adverse,
                    "required_shielding_max": (
                        None
                        if cycles is None or spacer["central"] <= 0.0
                        else budget / (cycles * spacer["central"])
                    ),
                }
            )
    return rows


def maximin_verdict(
    rows: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Is the cyclic wet reset recommendable blind to both materials?

    The verdict is over material identity at central raster values; the
    per-cell fragile flag carries the raster caveat.  The diagonal is
    reported separately because same-material pairs are the structural
    worst case that no chemistry can fix.
    """

    feasible = [row for row in rows if row["feasible"]]
    infeasible = [row for row in rows if not row["feasible"]]
    diagonal = [row for row in rows if row["same_material"]]
    diagonal_feasible = [row for row in diagonal if row["feasible"]]
    per_residue: dict[str, list[str]] = {}
    for row in rows:
        if row["feasible"]:
            per_residue.setdefault(row["residue"], []).append(
                row["spacer"]
            )
    return {
        "pair_count": len(rows),
        "feasible_pair_count": len(feasible),
        "blind_recommendable": not infeasible,
        "diagonal_feasible_count": len(diagonal_feasible),
        "diagonal_pair_count": len(diagonal),
        "infeasible_pairs": [
            {"residue": row["residue"], "spacer": row["spacer"]}
            for row in infeasible
        ],
        "feasible_spacers_if_residue_known": per_residue,
        "fragile_pair_count": sum(
            1 for row in rows if row["fragile_within_raster"]
        ),
    }


def build_report(
    *,
    residue_thicknesses_nm: Sequence[float] = (
        DEFAULT_RESIDUE_THICKNESSES_NM
    ),
    spacer_budgets_nm: Sequence[float] = DEFAULT_SPACER_BUDGETS_NM,
    shielding_factors: Sequence[float] = DEFAULT_SHIELDING_FACTORS,
    wet_reset_efficiencies: Sequence[float] = (
        DEFAULT_WET_RESET_EFFICIENCIES
    ),
) -> dict[str, Any]:
    """Material-maximin spacer-pullback screen over the declared sweeps."""

    for thickness in residue_thicknesses_nm:
        _finite_positive("residue_thickness_nm", thickness)
    for budget in spacer_budgets_nm:
        _finite_positive("spacer_budget_nm", budget)
    per_cycle_tables = {
        f"{efficiency:g}": {
            key: per_cycle_removal_nm(
                key, wet_reset_efficiency=efficiency
            )
            for key in DEFAULT_MATERIAL_KEYS
        }
        for efficiency in wet_reset_efficiencies
    }
    conditions: list[dict[str, Any]] = []
    for efficiency in wet_reset_efficiencies:
        for thickness in residue_thicknesses_nm:
            for budget in spacer_budgets_nm:
                for shielding in shielding_factors:
                    rows = pullback_feasibility(
                        residue_thickness_nm=thickness,
                        spacer_budget_nm=budget,
                        shielding_factor=shielding,
                        wet_reset_efficiency=efficiency,
                    )
                    conditions.append(
                        {
                            "wet_reset_efficiency": float(efficiency),
                            "residue_thickness_nm": float(thickness),
                            "spacer_budget_nm": float(budget),
                            "shielding_factor": float(shielding),
                            "pairs": rows,
                            "verdict": maximin_verdict(rows),
                        }
                    )
    blind_conditions = [
        {
            key: condition[key]
            for key in (
                "wet_reset_efficiency",
                "residue_thickness_nm",
                "spacer_budget_nm",
                "shielding_factor",
            )
        }
        for condition in conditions
        if condition["verdict"]["blind_recommendable"]
    ]
    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "material_candidates": list(DEFAULT_MATERIAL_KEYS),
        "clock_note": (
            "all quantities stay on the Kawarazaki Fig. 2 clock (0.15% "
            "dHF, 30 s bars, dry 240 C ozone bake anchor); nothing is "
            "mixed with the measured-blanket clock of the decay screens"
        ),
        "assumptions": {
            "wet_reset_efficiencies": [
                float(value) for value in wet_reset_efficiencies
            ],
            "wet_reset_note": (
                "no wet per-cycle measurement exists; epsilon scales the "
                "dry-bake ozone increment uniformly across materials"
            ),
            "shielding_factors": [
                float(value) for value in shielding_factors
            ],
            "shielding_note": (
                "bare geometric factor standing in for the unresolved "
                "spacer-pocket transport problem; 1.0 is the fully "
                "exposed worst case"
            ),
            "spacer_budgets_nm": [
                float(value) for value in spacer_budgets_nm
            ],
            "spacer_budget_note": (
                "device allowance unknown to this project; swept, not "
                "asserted"
            ),
            "cycle_linearity_note": (
                "per-cycle linearity carried beyond the reported "
                "3-cycle window"
            ),
        },
        "per_cycle_removal_nm": per_cycle_tables,
        "selectivity_matrices": {
            f"{efficiency:g}": selectivity_matrix(
                wet_reset_efficiency=efficiency
            )
            for efficiency in wet_reset_efficiencies
        },
        "conditions": conditions,
        "blind_recommendable_conditions": blind_conditions,
        "discriminating_measurement": {
            "name": "residue composition versus the spacer film",
            "prediction": (
                "a same-material pair caps chemical selectivity at one "
                "and leaves geometric shielding as the only protection; "
                "a differing pair opens per-cycle selectivities up to "
                "the Fig. 2 spread. One composition measurement of the "
                "residue collapses the matrix to a single row"
            ),
        },
    }


__all__ = [
    "DEFAULT_MATERIAL_KEYS",
    "DEFAULT_OXIDE_THICKNESS_NM",
    "DEFAULT_RESIDUE_THICKNESSES_NM",
    "DEFAULT_SHIELDING_FACTORS",
    "DEFAULT_SPACER_BUDGETS_NM",
    "DEFAULT_WET_RESET_EFFICIENCIES",
    "MAXIMUM_CYCLES",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "build_report",
    "cycles_to_clear_residue",
    "maximin_verdict",
    "per_cycle_removal_nm",
    "pullback_feasibility",
    "selectivity_matrix",
]

from __future__ import annotations

import math
import unittest

from measured_decay_fit import fit_laws, load_series
from pulsed_recipe_screen import (
    HYPOTHESIS_LIQUID,
    HYPOTHESIS_SURFACE,
    Recipe,
    build_report,
    cycles_to_clear,
    default_recipes,
    dominance,
    evaluate_recipes,
    simulate_recipe,
)


def _law(name: str):
    return next(law for law in fit_laws(*load_series()) if law.name == name)


def _recipe(name: str):
    return next(r for r in default_recipes() if r.name == name)


class ContinuousBaselineTests(unittest.TestCase):
    def test_continuous_180s_reproduces_the_measured_endpoint(self) -> None:
        """The simulator must agree with the data it was fitted to."""

        for law_name, delta in (("saturating", 0.02), ("logarithmic", 0.03)):
            removed = simulate_recipe(
                _recipe("continuous_180s"), _law(law_name), HYPOTHESIS_LIQUID
            )
            self.assertAlmostEqual(removed, 1.4277, delta=delta, msg=law_name)

    def test_hypothesis_is_irrelevant_without_resets(self) -> None:
        """A continuous etch has no reset events to disagree about."""

        for law_name in ("saturating", "logarithmic"):
            law = _law(law_name)
            recipe = _recipe("continuous_600s")
            self.assertEqual(
                simulate_recipe(recipe, law, HYPOTHESIS_LIQUID),
                simulate_recipe(recipe, law, HYPOTHESIS_SURFACE),
            )

    def test_etching_longer_saturates(self) -> None:
        """The futility control: 3.3x the time buys far less than 3.3x."""

        law = _law("saturating")
        base = simulate_recipe(_recipe("continuous_180s"), law, HYPOTHESIS_LIQUID)
        longer = simulate_recipe(
            _recipe("continuous_600s"), law, HYPOTHESIS_LIQUID
        )
        self.assertLess(longer / base, 1.6)


class SplitEtchTests(unittest.TestCase):
    def test_split_beats_continuous_under_a_liquid_cause(self) -> None:
        """The 34.9% margin the split experiment would measure."""

        law = _law("saturating")
        split = simulate_recipe(
            _recipe("split_3x60s_exchange"), law, HYPOTHESIS_LIQUID
        )
        cont = simulate_recipe(_recipe("continuous_180s"), law, HYPOTHESIS_LIQUID)
        # three fresh-curve pulses of the fitted law (0.6510 each; the fitted
        # fresh value differs from the measured interpolation 0.6418)
        fresh = simulate_recipe(
            Recipe(name="one", description="", steps=(("etch", 60.0),)),
            law,
            HYPOTHESIS_LIQUID,
        )
        self.assertAlmostEqual(split, 3 * fresh, places=9)
        self.assertGreater(split / cont, 1.30)

    def test_split_ties_continuous_under_a_surface_cause(self) -> None:
        """Exchanges do nothing to a converted surface."""

        for law_name in ("saturating", "logarithmic"):
            law = _law(law_name)
            split = simulate_recipe(
                _recipe("split_3x60s_exchange"), law, HYPOTHESIS_SURFACE
            )
            cont = simulate_recipe(
                _recipe("continuous_180s"), law, HYPOTHESIS_SURFACE
            )
            self.assertAlmostEqual(split, cont, places=9, msg=law_name)

    def test_finer_splitting_removes_more_under_a_liquid_cause(self) -> None:
        law = _law("saturating")
        three = simulate_recipe(
            _recipe("split_3x60s_exchange"), law, HYPOTHESIS_LIQUID
        )
        six = simulate_recipe(
            _recipe("split_6x30s_exchange"), law, HYPOTHESIS_LIQUID
        )
        self.assertGreater(six, three)


class ChemicalResetTests(unittest.TestCase):
    def test_reset_cycles_are_hypothesis_independent(self) -> None:
        """The property that makes them the robust choice."""

        for law_name in ("saturating", "logarithmic"):
            law = _law(law_name)
            recipe = _recipe("cycle_3x60s_reset")
            self.assertAlmostEqual(
                simulate_recipe(recipe, law, HYPOTHESIS_LIQUID),
                simulate_recipe(recipe, law, HYPOTHESIS_SURFACE),
                places=12,
            )

    def test_reset_matches_split_under_the_liquid_hypothesis(self) -> None:
        """When the cause is liquid-side, chemistry buys nothing extra."""

        law = _law("saturating")
        self.assertAlmostEqual(
            simulate_recipe(
                _recipe("cycle_3x60s_reset"), law, HYPOTHESIS_LIQUID
            ),
            simulate_recipe(
                _recipe("split_3x60s_exchange"), law, HYPOTHESIS_LIQUID
            ),
            places=12,
        )


class RankingTests(unittest.TestCase):
    def test_reset_cycles_rank_first_among_matched_active_time(self) -> None:
        """continuous_600s spends 3.3x the HF time, so it competes separately."""

        outcomes = [
            o
            for o in evaluate_recipes()
            if math.isclose(o.recipe.active_etch_time_s(), 180.0)
        ]
        ranked = sorted(
            outcomes, key=lambda o: o.worst_case_nm(), reverse=True
        )
        self.assertIn("reset", ranked[0].recipe.name)

    def test_180s_of_cycles_nearly_matches_600s_continuous(self) -> None:
        """The efficiency headline: cycles buy back a 3.3x time extension."""

        outcomes = {o.recipe.name: o for o in evaluate_recipes()}
        cycles = outcomes["cycle_6x30s_reset"].worst_case_nm()
        long_cont = outcomes["continuous_600s"].worst_case_nm()
        self.assertGreater(cycles / long_cont, 0.95)

    def test_continuous_180_is_dominated_by_the_reset_cycle(self) -> None:
        """Same active time, never worse, sometimes better."""

        table = {row["recipe"]: row for row in dominance(evaluate_recipes())}
        self.assertFalse(table["continuous_180s"]["undominated"])
        self.assertIn(
            "cycle_3x60s_reset", table["continuous_180s"]["dominated_by"]
        )

    def test_reset_cycles_are_undominated(self) -> None:
        table = {row["recipe"]: row for row in dominance(evaluate_recipes())}
        self.assertTrue(table["cycle_6x30s_reset"]["undominated"])

    def test_dominance_only_compares_equal_active_time(self) -> None:
        """continuous_600s must not be judged against 180 s recipes."""

        table = {row["recipe"]: row for row in dominance(evaluate_recipes())}
        self.assertTrue(table["continuous_600s"]["undominated"])


class ClearCycleTests(unittest.TestCase):
    def test_thick_pads_are_only_reachable_with_reset_cycles(self) -> None:
        result = cycles_to_clear(pad_thickness_nm=3.0)
        self.assertFalse(
            result["continuous_equivalent_reachable"]["saturating"]
        )
        self.assertTrue(result["feasible_within_maximum"])

    def test_cycle_count_uses_the_worst_law(self) -> None:
        result = cycles_to_clear(pad_thickness_nm=2.0)
        worst = min(result["per_cycle_removal_nm"].values())
        self.assertEqual(
            result["cycles_needed_worst_case"], math.ceil(2.0 / worst)
        )

    def test_one_nm_pad_needs_two_cycles(self) -> None:
        """0.6418 nm per fresh 60 s pulse -> two cycles for 1 nm."""

        result = cycles_to_clear(pad_thickness_nm=1.0)
        self.assertEqual(result["cycles_needed_worst_case"], 2)

    def test_rejects_nonpositive_thickness(self) -> None:
        with self.assertRaises(ValueError):
            cycles_to_clear(pad_thickness_nm=0.0)


class ReportTests(unittest.TestCase):
    def test_report_covers_four_scenarios(self) -> None:
        report = build_report()
        self.assertEqual(len(report["scenarios"]), 4)

    def test_reset_assumptions_are_declared(self) -> None:
        assumptions = build_report()["reset_step_assumptions"]
        self.assertEqual(assumptions["intrinsic_removal_nm"], 0.0)
        self.assertIn("conservative", assumptions["note"])

    def test_recipe_validation_rejects_unknown_steps(self) -> None:
        bad = Recipe(name="bad", description="", steps=(("boil", 10.0),))
        with self.assertRaises(ValueError):
            simulate_recipe(bad, _law("saturating"), HYPOTHESIS_LIQUID)

    def test_unknown_hypothesis_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            simulate_recipe(
                _recipe("continuous_180s"), _law("saturating"), "psychic"
            )


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import unittest

from literature_parameters import KAWARAZAKI_2024_FIG2_ENDPOINTS
from spacer_pullback_screen import (
    build_report,
    cycles_to_clear_residue,
    maximin_verdict,
    per_cycle_removal_nm,
    pullback_feasibility,
    selectivity_matrix,
)


C22 = "kawarazaki_sicn_c22"
C40 = "kawarazaki_sicn_c40"
C5 = "kawarazaki_siocn_c5"
SIN = "kawarazaki_sin_reference"


def _pair(rows, residue: str, spacer: str):
    return next(
        row
        for row in rows
        if row["residue"] == residue and row["spacer"] == spacer
    )


class PerCycleRemovalTests(unittest.TestCase):
    def test_zero_efficiency_is_the_dhf_only_bar(self) -> None:
        """epsilon = 0 must collapse to plain dHF pulsing."""

        for key, endpoint in KAWARAZAKI_2024_FIG2_ENDPOINTS.items():
            removal = per_cycle_removal_nm(key, wet_reset_efficiency=0.0)
            self.assertAlmostEqual(
                removal["central"],
                endpoint.dhf_only_etch_amount_nm,
                places=12,
                msg=key,
            )

    def test_full_efficiency_is_the_dry_bake_anchor(self) -> None:
        """epsilon = 1 must reproduce the paired ozone+dHF bar."""

        for key, endpoint in KAWARAZAKI_2024_FIG2_ENDPOINTS.items():
            removal = per_cycle_removal_nm(key, wet_reset_efficiency=1.0)
            self.assertAlmostEqual(
                removal["central"],
                endpoint.ozone_then_dhf_etch_amount_nm,
                places=12,
                msg=key,
            )

    def test_raster_band_is_one_step_clipped_at_zero(self) -> None:
        removal = per_cycle_removal_nm(SIN, wet_reset_efficiency=1.0)
        self.assertEqual(removal["low"], 0.0)
        self.assertAlmostEqual(removal["high"], 0.09, places=12)

    def test_ozone_does_nothing_for_the_sin_reference(self) -> None:
        """Fig. 2 shows the same 0.04 nm in both SiN arms."""

        weak = per_cycle_removal_nm(SIN, wet_reset_efficiency=0.3)
        strong = per_cycle_removal_nm(SIN, wet_reset_efficiency=1.0)
        self.assertEqual(weak["central"], strong["central"])

    def test_invalid_inputs_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            per_cycle_removal_nm(C22, wet_reset_efficiency=1.5)
        with self.assertRaises(ValueError):
            per_cycle_removal_nm("phantom", wet_reset_efficiency=1.0)


class CyclesToClearTests(unittest.TestCase):
    def test_two_nm_pad_cycle_counts_at_the_dry_anchor(self) -> None:
        """The material spread 1 -> 50 is the point of the screen."""

        expected = {C22: 1, C40: 3, C5: 4, SIN: 50}
        for key, cycles in expected.items():
            result = cycles_to_clear_residue(
                key, thickness_nm=2.0, wet_reset_efficiency=1.0
            )
            self.assertEqual(result["cycles_central"], cycles, key)

    def test_resolution_floor_films_are_unbounded_worst_case(self) -> None:
        """SiN sits at the raster floor; its clear time has no bound."""

        result = cycles_to_clear_residue(
            SIN, thickness_nm=1.0, wet_reset_efficiency=1.0
        )
        self.assertIsNone(result["cycles_worst_raster"])
        self.assertTrue(result["worst_case_unbounded_within_resolution"])

    def test_cycle_cap_reports_none(self) -> None:
        result = cycles_to_clear_residue(
            SIN,
            thickness_nm=1.0,
            wet_reset_efficiency=1.0,
            maximum_cycles=10,
        )
        self.assertIsNone(result["cycles_central"])

    def test_rejects_nonpositive_thickness(self) -> None:
        with self.assertRaises(ValueError):
            cycles_to_clear_residue(
                C22, thickness_nm=0.0, wet_reset_efficiency=1.0
            )


class SelectivityMatrixTests(unittest.TestCase):
    def test_diagonal_selectivity_is_exactly_one(self) -> None:
        """Same material: no chemical protection, by construction."""

        rows = selectivity_matrix(wet_reset_efficiency=1.0)
        for row in rows:
            if row["same_material"]:
                self.assertEqual(row["selectivity_central"], 1.0)

    def test_best_pair_reaches_the_fig2_spread(self) -> None:
        rows = selectivity_matrix(wet_reset_efficiency=1.0)
        best = _pair(rows, C22, SIN)
        self.assertAlmostEqual(
            best["selectivity_central"], 2.47 / 0.04, places=9
        )

    def test_floor_spacer_has_no_upper_selectivity_bound(self) -> None:
        """A spacer bar that can reach zero gives an unbounded ratio."""

        rows = selectivity_matrix(wet_reset_efficiency=1.0)
        best = _pair(rows, C22, SIN)
        self.assertIsNone(best["selectivity_high"])
        self.assertAlmostEqual(
            best["selectivity_low"], 2.42 / 0.09, places=9
        )


class PullbackFeasibilityTests(unittest.TestCase):
    def test_known_fast_residue_with_sin_spacer_is_feasible(self) -> None:
        """The off-diagonal cell a composition measurement could buy."""

        rows = pullback_feasibility(
            residue_thickness_nm=2.0,
            spacer_budget_nm=0.3,
            shielding_factor=1.0,
            wet_reset_efficiency=1.0,
        )
        row = _pair(rows, C22, SIN)
        self.assertTrue(row["feasible"])
        self.assertAlmostEqual(row["spacer_pullback_nm"], 0.04, places=12)

    def test_every_diagonal_pair_fails_fully_exposed(self) -> None:
        """Clearing T nm of residue costs the spacer ~T nm when shared."""

        rows = pullback_feasibility(
            residue_thickness_nm=2.0,
            spacer_budget_nm=1.0,
            shielding_factor=1.0,
            wet_reset_efficiency=1.0,
        )
        for row in rows:
            if row["same_material"]:
                self.assertFalse(row["feasible"], row["residue"])

    def test_slow_residue_fast_spacer_is_the_killer_corner(self) -> None:
        """residue SiN x spacer C22 fails even at shielding 0.1."""

        rows = pullback_feasibility(
            residue_thickness_nm=2.0,
            spacer_budget_nm=1.0,
            shielding_factor=0.1,
            wet_reset_efficiency=1.0,
        )
        row = _pair(rows, SIN, C22)
        self.assertFalse(row["feasible"])
        self.assertGreater(row["spacer_pullback_nm"], 10.0)

    def test_raster_fragile_cell_is_flagged(self) -> None:
        """residue C5 x spacer SiN flips inside one raster step."""

        rows = pullback_feasibility(
            residue_thickness_nm=2.0,
            spacer_budget_nm=0.3,
            shielding_factor=1.0,
            wet_reset_efficiency=1.0,
        )
        row = _pair(rows, C5, SIN)
        self.assertTrue(row["feasible"])
        self.assertFalse(row["feasible_adverse"])
        self.assertTrue(row["fragile_within_raster"])

    def test_required_shielding_reports_the_diagonal_budget(self) -> None:
        rows = pullback_feasibility(
            residue_thickness_nm=2.0,
            spacer_budget_nm=1.0,
            shielding_factor=1.0,
            wet_reset_efficiency=1.0,
        )
        row = _pair(rows, SIN, SIN)
        self.assertAlmostEqual(
            row["required_shielding_max"], 1.0 / (50 * 0.04), places=9
        )

    def test_silicon_rider_charges_one_oxidation_per_cycle(self) -> None:
        rows = pullback_feasibility(
            residue_thickness_nm=2.0,
            spacer_budget_nm=1.0,
            shielding_factor=1.0,
            wet_reset_efficiency=1.0,
        )
        row = _pair(rows, C40, SIN)
        self.assertEqual(row["cycles_central"], 3)
        self.assertAlmostEqual(
            row["silicon_recession_nm"], 3 * 0.4407, delta=0.001
        )

    def test_invalid_condition_values_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            pullback_feasibility(
                residue_thickness_nm=2.0,
                spacer_budget_nm=0.0,
                shielding_factor=1.0,
                wet_reset_efficiency=1.0,
            )
        with self.assertRaises(ValueError):
            pullback_feasibility(
                residue_thickness_nm=2.0,
                spacer_budget_nm=1.0,
                shielding_factor=0.0,
                wet_reset_efficiency=1.0,
            )


class MaximinVerdictTests(unittest.TestCase):
    def _rows(self):
        return pullback_feasibility(
            residue_thickness_nm=2.0,
            spacer_budget_nm=1.0,
            shielding_factor=0.1,
            wet_reset_efficiency=1.0,
        )

    def test_blind_recommendation_fails(self) -> None:
        verdict = maximin_verdict(self._rows())
        self.assertFalse(verdict["blind_recommendable"])
        self.assertIn(
            {"residue": SIN, "spacer": C22}, verdict["infeasible_pairs"]
        )

    def test_known_residue_rows_are_reported(self) -> None:
        """The value of one composition measurement, made explicit."""

        verdict = maximin_verdict(self._rows())
        known = verdict["feasible_spacers_if_residue_known"]
        self.assertIn(SIN, known[C22])

    def test_pair_bookkeeping_is_complete(self) -> None:
        verdict = maximin_verdict(self._rows())
        self.assertEqual(verdict["pair_count"], 16)
        self.assertEqual(verdict["diagonal_pair_count"], 4)


class ReportTests(unittest.TestCase):
    def test_no_default_condition_is_blind_recommendable(self) -> None:
        """The headline: the material matrix cannot be ignored."""

        report = build_report()
        self.assertEqual(report["blind_recommendable_conditions"], [])

    def test_report_declares_the_clock_and_assumptions(self) -> None:
        report = build_report()
        self.assertIn("Kawarazaki", report["clock_note"])
        assumptions = report["assumptions"]
        self.assertIn("no wet per-cycle", assumptions["wet_reset_note"])
        self.assertIn("swept", assumptions["spacer_budget_note"])
        self.assertIn("3-cycle", assumptions["cycle_linearity_note"])

    def test_report_covers_the_declared_sweeps(self) -> None:
        report = build_report()
        self.assertEqual(len(report["conditions"]), 2 * 3 * 3 * 3)
        self.assertEqual(len(report["material_candidates"]), 4)

    def test_report_rejects_bad_sweeps(self) -> None:
        with self.assertRaises(ValueError):
            build_report(residue_thicknesses_nm=(0.0,))
        with self.assertRaises(ValueError):
            build_report(spacer_budgets_nm=(-1.0,))


if __name__ == "__main__":
    unittest.main()

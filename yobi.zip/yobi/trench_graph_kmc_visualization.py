#!/usr/bin/env python3
"""Diagnostic figures for the real-dimension continuum/graph-KMC model.

The routines accept either live :class:`trench_graph_kmc.TrenchKMCOutcome`
objects or the ordinary mappings written by a parameter sweep.  Coordinates
on phase maps are physical nanometres; the lateral coordinate is transformed
only for display so that a 7--10 nm trench remains visible beside its
170--180 nm depth.

These are mechanism-screening plots.  One graph site is normally one
approximately 1 nm continuum cell, not an atom, and the kinetic coefficients
are deliberately uncalibrated.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np


MESOSCOPIC_KMC_CAVEAT = (
    "Mechanism-screening model: each graph site is an approximately 1 nm "
    "mesoscopic voxel, not an atom; KMC rates are uncalibrated. Horizontal "
    "coordinates in trench maps are visually expanded while tick labels "
    "remain physical nanometres."
)


_STYLE = {
    "font.size": 8.5,
    "axes.titlesize": 9.5,
    "axes.labelsize": 8.5,
    "axes.linewidth": 0.75,
    "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5,
    "legend.fontsize": 7.2,
    "figure.facecolor": "white",
    "axes.facecolor": "#fafbfc",
    "savefig.facecolor": "white",
}

_STATE_COLORS = {
    "removed": (0.66, 0.86, 0.94, 0.24),
    "intact": (0.39, 0.42, 0.46, 0.96),
    "activated": (0.04, 0.55, 0.51, 0.96),
    "hydrolyzed_silanol": (0.16, 0.45, 0.78, 0.98),
    "fluorinated": (0.47, 0.30, 0.72, 0.98),
    "passivated": (0.94, 0.55, 0.12, 0.98),
    "deposit": (0.70, 0.12, 0.48, 1.0),
}

_STATE_CODE = {
    "removed": 0,
    "buried": 1,
    "intact": 1,
    "activated": 2,
    "hydrolyzed_silanol": 3,
    "fluorinated": 4,
    "passivated": 5,
}

_EVENT_COLORS = {
    "activate": "#2878b5",
    "passivate": "#e89023",
    "depassivate": "#c2a51a",
    "remove": "#228b60",
    "hydrolyze": "#2878b5",
    "fluorinate_intact": "#7554a3",
    "fluorinate_silanol": "#9467bd",
    "remove_hydrolyzed": "#187f68",
    "remove_fluorinated": "#195f48",
    "precipitate": "#b02a78",
    "dissolve_deposit": "#7554a3",
    "reattach": "#c44e52",
}

_EVENT_MARKERS = {
    "activate": "o",
    "passivate": "s",
    "depassivate": "P",
    "remove": "v",
    "hydrolyze": "h",
    "fluorinate_intact": "^",
    "fluorinate_silanol": "<",
    "remove_hydrolyzed": "*",
    "remove_fluorinated": "X",
    "precipitate": "D",
    "dissolve_deposit": "X",
    "reattach": ">",
}

_REGION_NAME_BY_CODE = {0: "top", 1: "sidewall", 2: "bottom", 3: "core"}

_GEOMETRY_SHORT_LABELS = {
    "10_10_180": "10 × 180 nm (straight)",
    "7_7_170": "7 × 170 nm (straight)",
    "10_8_180": "10→8 × 180 nm",
    "7_4p5_170": "7→4.5 × 170 nm",
}

_SCENARIO_SHORT_LABELS = {
    "baseline": "Local-field baseline",
    "neighbor_dependence": "Neighbour dependence",
    "passivation_cluster": "Passivation clusters",
    "precipitation_reattachment": "Precipitation / reattachment",
    "combined": "Combined mechanisms",
    "outcome": "Coupled outcome",
}


@dataclass(frozen=True)
class _CaseView:
    case_id: str
    title: str
    geometry_id: str
    scenario_id: str
    seed: int | None
    x_nm: np.ndarray
    depth_nm: np.ndarray
    hf_field: np.ndarray
    liquid_mask: np.ndarray
    cavity_mask: np.ndarray
    sites: tuple[Mapping[str, Any], ...]
    summary: Mapping[str, Any]
    sync_history: tuple[Mapping[str, Any], ...]
    event_locations: tuple[Mapping[str, Any], ...]


def _load_payload(value: Mapping[str, Any] | str | Path) -> Mapping[str, Any]:
    if isinstance(value, (str, Path)):
        loaded = json.loads(Path(value).read_text(encoding="utf-8"))
        if not isinstance(loaded, Mapping):
            raise ValueError("visualization JSON must contain a mapping")
        return loaded
    if not isinstance(value, Mapping):
        raise TypeError("expected a mapping or a JSON path")
    return value


def _panel_label(axis: plt.Axes, label: str) -> None:
    axis.text(
        -0.11,
        1.06,
        label,
        transform=axis.transAxes,
        fontsize=11,
        fontweight="bold",
        ha="left",
        va="top",
    )


def _centres_to_edges(values: np.ndarray) -> np.ndarray:
    centres = np.asarray(values, dtype=float)
    if centres.ndim != 1 or centres.size == 0:
        raise ValueError("grid coordinates must be non-empty one-dimensional arrays")
    if centres.size == 1:
        return np.asarray((centres[0] - 0.5, centres[0] + 0.5))
    differences = np.diff(centres)
    if np.any(differences <= 0.0):
        raise ValueError("grid coordinates must increase strictly")
    edges = np.empty(centres.size + 1, dtype=float)
    edges[1:-1] = 0.5 * (centres[:-1] + centres[1:])
    edges[0] = centres[0] - 0.5 * differences[0]
    edges[-1] = centres[-1] + 0.5 * differences[-1]
    return edges


def _as_site_records(value: Any) -> tuple[Mapping[str, Any], ...]:
    if value is None:
        return ()
    if isinstance(value, Mapping):
        if "records" in value:
            return _as_site_records(value["records"])
        columns = dict(value)
        lengths: list[int] = []
        for column in columns.values():
            if isinstance(column, (str, bytes)) or np.asarray(column).ndim == 0:
                continue
            lengths.append(len(column))
        if not lengths:
            return ()
        if len(set(lengths)) != 1:
            raise ValueError("columnar site arrays must have equal lengths")
        records: list[dict[str, Any]] = []
        for index in range(lengths[0]):
            row: dict[str, Any] = {}
            for key, column in columns.items():
                array = np.asarray(column)
                item = array.item() if array.ndim == 0 else array[index]
                row[str(key)] = item.item() if isinstance(item, np.generic) else item
            records.append(row)
        return tuple(records)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        records = []
        for item in value:
            if not isinstance(item, Mapping):
                raise ValueError("each site record must be a mapping")
            records.append(dict(item))
        return tuple(records)
    raise ValueError("sites must be a record sequence or columnar mapping")


def _reshape_field(value: Any, shape: tuple[int, int], *, boolean: bool) -> np.ndarray:
    if value is None:
        return np.zeros(shape, dtype=bool if boolean else float)
    array = np.asarray(value, dtype=bool if boolean else float)
    if array.shape == shape:
        return array.copy()
    if array.shape == (shape[1], shape[0]):
        return array.T.copy()
    if array.size == shape[0] * shape[1]:
        return array.reshape(shape).copy()
    raise ValueError(f"field shape {array.shape} cannot be mapped to grid {shape}")


def _record_coordinate(record: Mapping[str, Any], key: str, fallback: str) -> float:
    if key in record:
        return float(record[key])
    if fallback in record:
        return float(record[fallback])
    raise ValueError(f"site record is missing {key!r}/{fallback!r}")


def _site_type(record: Mapping[str, Any]) -> str:
    value = record.get("site_type", record.get("type"))
    if value is not None:
        return str(value).lower()
    if float(record.get("collector_flag", 0.0)) > 0.5:
        return "collector"
    if str(record.get("state", "")) in {"collector", "deposit"}:
        return "collector"
    return "matrix"


def _live_outcome_view(value: Any, *, case_id: str = "outcome") -> _CaseView:
    layout = value.layout
    graph = value.graph
    frame = value.final_frame
    grid = layout.grid
    sites: list[dict[str, Any]] = []
    for site_id in (*layout.matrix_site_ids, *layout.collector_site_ids):
        site = graph.sites[site_id]
        attributes = site.attributes
        code = int(round(attributes.get("region_code", 3.0)))
        sites.append(
            {
                "site_id": site_id,
                "x_nm": float(attributes["x_nm"]),
                "depth_nm": float(attributes["depth_nm"]),
                "row": int(round(attributes["row"])),
                "column": int(round(attributes["column"])),
                "site_type": (
                    "collector" if attributes.get("collector_flag", 0.0) > 0.5 else "matrix"
                ),
                "material": site.material,
                "region": _REGION_NAME_BY_CODE.get(code, "core"),
                "state": site.state,
                "hf_activity": float(attributes.get("hf_activity", 0.0)),
                "hf2_activity": float(attributes.get("hf2_activity", 0.0)),
                "fluoride_activity": float(
                    attributes.get("fluoride_activity", 0.0)
                ),
                "protonated_site_fraction": float(
                    attributes.get("protonated_site_fraction", 0.0)
                ),
                "product_activity": float(attributes.get("product_activity", 0.0)),
                "temperature_K": float(attributes.get("temperature_K", np.nan)),
                "wet_exposed": float(attributes.get("wet_exposed", 0.0)),
            }
        )
    geometry = grid.geometry
    return _CaseView(
        case_id=case_id,
        title=f"{geometry.name} | seed {value.seed}",
        geometry_id=str(geometry.name),
        scenario_id="outcome",
        seed=int(value.seed),
        x_nm=np.asarray(grid.lateral_nm, dtype=float),
        depth_nm=np.asarray(grid.depth_nm, dtype=float),
        hf_field=np.asarray(frame.hf_field, dtype=float),
        liquid_mask=np.asarray(frame.liquid_mask, dtype=bool),
        cavity_mask=np.asarray(grid.cavity_mask, dtype=bool),
        sites=tuple(sites),
        summary=dict(value.summary()),
        sync_history=tuple(dict(item) for item in value.sync_history),
        event_locations=tuple(dict(item) for item in value.event_locations),
    )


def _lookup_label(root: Mapping[str, Any], group: str, item_id: str) -> str:
    items = root.get(group, {})
    if isinstance(items, Mapping):
        item = items.get(item_id)
        if isinstance(item, Mapping):
            explicit = item.get("label")
            if explicit is not None:
                return str(explicit)
    if group == "geometries":
        return _GEOMETRY_SHORT_LABELS.get(item_id, item_id)
    if group == "scenarios":
        return _SCENARIO_SHORT_LABELS.get(item_id, item_id)
    return item_id


def _mapping_case_view(
    value: Mapping[str, Any],
    *,
    root: Mapping[str, Any],
    default_case_id: str,
) -> _CaseView:
    snapshot_raw = value.get("snapshot", value)
    if not isinstance(snapshot_raw, Mapping):
        raise ValueError("case snapshot must be a mapping")
    snapshot = snapshot_raw
    grid_raw = snapshot.get("grid", {})
    grid = grid_raw if isinstance(grid_raw, Mapping) else {}
    fields_raw = snapshot.get("fields", {})
    fields = fields_raw if isinstance(fields_raw, Mapping) else {}
    sites = _as_site_records(snapshot.get("sites", value.get("sites")))

    x_value = grid.get("x_nm", grid.get("lateral_nm"))
    depth_value = grid.get("z_nm", grid.get("depth_nm"))
    if x_value is None:
        x_candidates = sorted(
            {
                _record_coordinate(record, "x_nm", "lateral_nm")
                for record in sites
                if _site_type(record) == "matrix"
            }
        )
        x_value = x_candidates
    if depth_value is None:
        depth_candidates = sorted(
            {
                _record_coordinate(record, "depth_nm", "z_nm")
                for record in sites
                if _site_type(record) == "matrix"
            }
        )
        depth_value = depth_candidates
    x_nm = np.asarray(x_value, dtype=float)
    depth_nm = np.asarray(depth_value, dtype=float)
    if x_nm.ndim != 1 or depth_nm.ndim != 1 or not x_nm.size or not depth_nm.size:
        raise ValueError("snapshot needs non-empty one-dimensional x/depth coordinates")
    shape = (depth_nm.size, x_nm.size)
    hf_field = _reshape_field(
        fields.get("hf", fields.get("hf_field", snapshot.get("hf_field"))),
        shape,
        boolean=False,
    )
    liquid_value = fields.get("liquid_mask", snapshot.get("liquid_mask"))
    liquid_mask = _reshape_field(liquid_value, shape, boolean=True)
    cavity_value = fields.get(
        "cavity_mask", grid.get("cavity_mask", snapshot.get("cavity_mask"))
    )
    cavity_mask = _reshape_field(cavity_value, shape, boolean=True)

    if cavity_value is None:
        for record in sites:
            if _site_type(record) != "matrix":
                continue
            row = record.get("row")
            column = record.get("column", record.get("col"))
            if row is None or column is None:
                x = _record_coordinate(record, "x_nm", "lateral_nm")
                depth = _record_coordinate(record, "depth_nm", "z_nm")
                row = int(np.argmin(np.abs(depth_nm - depth)))
                column = int(np.argmin(np.abs(x_nm - x)))
            cavity_mask[int(row), int(column)] = True
    if liquid_value is None:
        liquid_mask = np.isfinite(hf_field) & (hf_field > 0.0)

    case_id = str(value.get("case_id", default_case_id))
    geometry_id = str(value.get("geometry_id", snapshot.get("geometry_id", "geometry")))
    scenario_id = str(value.get("scenario_id", snapshot.get("scenario_id", "scenario")))
    geometry_label = _lookup_label(root, "geometries", geometry_id)
    scenario_label = _lookup_label(root, "scenarios", scenario_id)
    seed_raw = value.get("seed")
    seed = int(seed_raw) if seed_raw is not None else None
    title = f"{geometry_label} | {scenario_label}"
    if seed is not None:
        title += f" | seed {seed}"
    summary = value.get("summary", {})
    sync = value.get("sync_history", snapshot.get("sync_history", ()))
    events = value.get("event_locations", snapshot.get("event_locations", ()))
    if not isinstance(summary, Mapping):
        summary = {}
    return _CaseView(
        case_id=case_id,
        title=title,
        geometry_id=geometry_id,
        scenario_id=scenario_id,
        seed=seed,
        x_nm=x_nm,
        depth_nm=depth_nm,
        hf_field=hf_field,
        liquid_mask=liquid_mask,
        cavity_mask=cavity_mask,
        sites=sites,
        summary=dict(summary),
        sync_history=tuple(dict(item) for item in sync),
        event_locations=tuple(dict(item) for item in events),
    )


def _is_live_outcome(value: Any) -> bool:
    return all(hasattr(value, name) for name in ("layout", "graph", "final_frame", "summary"))


def _case_views(value: Any) -> list[_CaseView]:
    if _is_live_outcome(value):
        return [_live_outcome_view(value)]
    if isinstance(value, (str, Path)):
        value = _load_payload(value)
    if isinstance(value, Mapping):
        root = value
        raw_cases = value.get("cases")
        if isinstance(raw_cases, Sequence) and not isinstance(raw_cases, (str, bytes)):
            return [
                (
                    _live_outcome_view(case, case_id=f"case_{index}")
                    if _is_live_outcome(case)
                    else _mapping_case_view(
                        case,
                        root=root,
                        default_case_id=f"case_{index}",
                    )
                )
                for index, case in enumerate(raw_cases)
            ]
        if "snapshot" in value or "sync_history" in value or "event_locations" in value:
            return [_mapping_case_view(value, root=value, default_case_id="case")]
        views: list[_CaseView] = []
        for key, item in value.items():
            if _is_live_outcome(item):
                live = _live_outcome_view(item, case_id=str(key))
                views.append(
                    _CaseView(**{**live.__dict__, "title": str(key)})
                )
            elif isinstance(item, Mapping) and (
                "snapshot" in item or "sync_history" in item or "event_locations" in item
            ):
                views.append(
                    _mapping_case_view(item, root=value, default_case_id=str(key))
                )
        if views:
            return views
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        views = []
        for index, item in enumerate(value):
            if _is_live_outcome(item):
                views.append(_live_outcome_view(item, case_id=f"case_{index}"))
            elif isinstance(item, Mapping):
                views.append(
                    _mapping_case_view(item, root={}, default_case_id=f"case_{index}")
                )
            else:
                raise TypeError("case sequence contains an unsupported object")
        return views
    raise TypeError("could not find trench-KMC outcomes/cases to visualize")


def _state_grid(case: _CaseView) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    state = np.full((case.depth_nm.size, case.x_nm.size), np.nan, dtype=float)
    deposit_x: list[float] = []
    deposit_depth: list[float] = []
    for record in case.sites:
        site_state = str(record.get("state", ""))
        site_type = _site_type(record)
        x = _record_coordinate(record, "x_nm", "lateral_nm")
        depth = _record_coordinate(record, "depth_nm", "z_nm")
        if site_type == "collector":
            if site_state == "deposit":
                deposit_x.append(x)
                deposit_depth.append(depth)
            continue
        code = _STATE_CODE.get(site_state)
        if code is None:
            continue
        row_raw = record.get("row")
        column_raw = record.get("column", record.get("col"))
        row = int(row_raw) if row_raw is not None else int(np.argmin(np.abs(case.depth_nm - depth)))
        column = (
            int(column_raw)
            if column_raw is not None
            else int(np.argmin(np.abs(case.x_nm - x)))
        )
        if 0 <= row < state.shape[0] and 0 <= column < state.shape[1]:
            state[row, column] = float(code)
    return state, np.asarray(deposit_x), np.asarray(deposit_depth)


def plot_trench_kmc_phase_maps(
    outcomes_or_payload: Any,
    output_path: str | Path,
    *,
    x_visual_expansion: float = 10.0,
    max_panels: int | None = None,
    dpi: int = 220,
) -> Path:
    """Plot final continuum fields and KMC residue at actual trench coordinates."""

    if not math.isfinite(x_visual_expansion) or x_visual_expansion <= 0.0:
        raise ValueError("x_visual_expansion must be finite and positive")
    cases = _case_views(outcomes_or_payload)
    if max_panels is not None:
        if max_panels < 1:
            raise ValueError("max_panels must be positive")
        cases = cases[:max_panels]
    if not cases:
        raise ValueError("there are no phase-map cases")

    hf_values = [
        case.hf_field[case.liquid_mask & np.isfinite(case.hf_field)]
        for case in cases
    ]
    finite_hf = np.concatenate([values for values in hf_values if values.size]) if any(
        values.size for values in hf_values
    ) else np.asarray((0.0, 1.0))
    hf_min = min(0.0, float(np.min(finite_hf)))
    hf_max = float(np.max(finite_hf))
    if hf_max <= hf_min:
        hf_max = hf_min + 1.0
    hf_norm = Normalize(hf_min, hf_max)

    geometry_ids = list(dict.fromkeys(case.geometry_id for case in cases))
    scenario_ids = list(dict.fromkeys(case.scenario_id for case in cases))
    rectangular = len(cases) == len(geometry_ids) * len(scenario_ids)
    column_count = (
        len(scenario_ids)
        if rectangular and 1 <= len(scenario_ids) <= 5
        else min(4, len(cases))
    )
    row_count = int(math.ceil(len(cases) / column_count))
    state_cmap = ListedColormap(
        [
            _STATE_COLORS["removed"],
            _STATE_COLORS["intact"],
            _STATE_COLORS["activated"],
            _STATE_COLORS["hydrolyzed_silanol"],
            _STATE_COLORS["fluorinated"],
            _STATE_COLORS["passivated"],
        ]
    )
    state_norm = BoundaryNorm(np.arange(-0.5, 6.5, 1.0), state_cmap.N)

    with plt.rc_context(_STYLE):
        figure, axes_array = plt.subplots(
            row_count,
            column_count,
            figsize=(3.15 * column_count + 0.8, 4.65 * row_count + 0.65),
            squeeze=False,
        )
        axes = list(axes_array.ravel())
        hf_image = None
        for index, (axis, case) in enumerate(zip(axes, cases, strict=False)):
            x_edges = _centres_to_edges(case.x_nm) * x_visual_expansion
            depth_edges = _centres_to_edges(case.depth_nm)
            hf_masked = np.ma.masked_where(
                ~case.liquid_mask | ~np.isfinite(case.hf_field), case.hf_field
            )
            hf_image = axis.pcolormesh(
                x_edges,
                depth_edges,
                hf_masked,
                cmap="Blues",
                norm=hf_norm,
                shading="flat",
                rasterized=True,
                zorder=0,
            )
            state, deposit_x, deposit_depth = _state_grid(case)
            axis.pcolormesh(
                x_edges,
                depth_edges,
                np.ma.masked_invalid(state),
                cmap=state_cmap,
                norm=state_norm,
                shading="flat",
                rasterized=True,
                zorder=2,
            )
            if np.any(case.cavity_mask) and not np.all(case.cavity_mask):
                axis.contour(
                    case.x_nm * x_visual_expansion,
                    case.depth_nm,
                    case.cavity_mask.astype(float),
                    levels=(0.5,),
                    colors=("#25282c",),
                    linewidths=0.55,
                    zorder=3,
                )
            if deposit_x.size:
                axis.scatter(
                    deposit_x * x_visual_expansion,
                    deposit_depth,
                    s=9,
                    marker="D",
                    color=_STATE_COLORS["deposit"],
                    edgecolor="white",
                    linewidth=0.35,
                    zorder=5,
                )
            summary = case.summary
            remaining = summary.get("remaining_fraction")
            deposit_count = summary.get("deposit_count")
            subtitle = []
            if remaining is not None:
                subtitle.append(f"remaining {100.0 * float(remaining):.1f}%")
            if deposit_count is not None:
                subtitle.append(f"deposits {int(deposit_count)}")
            scenario_title = _SCENARIO_SHORT_LABELS.get(
                case.scenario_id,
                case.scenario_id.replace("_", " "),
            )
            axis.set_title(
                scenario_title
                + ("\n" + ", ".join(subtitle) if subtitle else "")
            )
            physical_left = float(x_edges[0] / x_visual_expansion)
            physical_right = float(x_edges[-1] / x_visual_expansion)
            physical_ticks = np.linspace(physical_left, physical_right, 5)
            axis.set_xticks(
                physical_ticks * x_visual_expansion,
                [f"{value:.1f}" for value in physical_ticks],
            )
            axis.set_xlabel(f"lateral x (nm; display ×{x_visual_expansion:g})")
            if index % column_count == 0:
                geometry_title = _GEOMETRY_SHORT_LABELS.get(
                    case.geometry_id, case.geometry_id
                )
                axis.set_ylabel(f"{geometry_title}\ndepth z (nm)")
            axis.set_ylim(depth_edges[-1], depth_edges[0])
            axis.set_aspect("equal", adjustable="box")
            axis.grid(False)
            _panel_label(axis, chr(ord("A") + index))
        for axis in axes[len(cases) :]:
            axis.set_visible(False)

        if hf_image is not None:
            colorbar = figure.colorbar(
                hf_image,
                ax=axes[: len(cases)],
                orientation="horizontal",
                fraction=0.025,
                pad=0.10,
                aspect=45,
            )
            colorbar.set_label("local continuum HF concentration (model units)")
        present_states = {
            str(record.get("state", ""))
            for case in cases
            for record in case.sites
            if _site_type(record) == "matrix"
        }
        legend = [
            Patch(
                facecolor=_STATE_COLORS["intact"],
                label="buried / intact GAP-FILL",
            ),
            Patch(
                facecolor=_STATE_COLORS["activated"],
                label="activated GAP-FILL",
            ),
        ]
        if "hydrolyzed_silanol" in present_states:
            legend.append(
                Patch(
                    facecolor=_STATE_COLORS["hydrolyzed_silanol"],
                    label="hydrolyzed / silanol intermediate",
                )
            )
        if "fluorinated" in present_states:
            legend.append(
                Patch(
                    facecolor=_STATE_COLORS["fluorinated"],
                    label="fluorinated intermediate",
                )
            )
        legend.extend(
            [
                Patch(
                    facecolor=_STATE_COLORS["passivated"],
                    label="passivated residue",
                ),
                Patch(
                    facecolor=_STATE_COLORS["removed"],
                    edgecolor="#75b9d3",
                    label="removed site / liquid",
                ),
                Line2D(
                    (),
                    (),
                    marker="D",
                    linestyle="none",
                    color=_STATE_COLORS["deposit"],
                    markeredgecolor="white",
                    label="wall/floor deposit",
                ),
            ]
        )
        figure.legend(
            handles=legend,
            loc="upper center",
            bbox_to_anchor=(0.5, 0.995),
            ncol=min(3 if column_count == 1 else 5, len(legend)),
            frameon=False,
        )
        figure.text(
            0.5,
            0.008,
            MESOSCOPIC_KMC_CAVEAT,
            ha="center",
            va="bottom",
            fontsize=7.2,
            color="0.32",
        )
        figure.subplots_adjust(
            left=0.075,
            right=0.965,
            top=0.91,
            bottom=0.17,
            wspace=0.30,
            hspace=0.30,
        )
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        figure.savefig(destination, dpi=dpi, bbox_inches="tight")
        plt.close(figure)
    return destination


def _ordered_ids(payload: Mapping[str, Any], key: str, cases: Sequence[_CaseView]) -> list[str]:
    order_key = "geometry_order" if key == "geometries" else "scenario_order"
    declared_order = payload.get(order_key)
    if isinstance(declared_order, Sequence) and not isinstance(
        declared_order, (str, bytes)
    ):
        values = [str(item) for item in declared_order]
        if values:
            return values
    declared = payload.get(key, {})
    if isinstance(declared, Mapping) and declared:
        return [str(item) for item in declared]
    attribute = "geometry_id" if key == "geometries" else "scenario_id"
    result: list[str] = []
    for case in cases:
        item = str(getattr(case, attribute))
        if item not in result:
            result.append(item)
    return result


def _mean_and_sd(values: Sequence[float]) -> tuple[float, float]:
    finite = np.asarray([value for value in values if math.isfinite(float(value))], dtype=float)
    if not finite.size:
        return float("nan"), float("nan")
    return float(np.mean(finite)), float(np.std(finite, ddof=1)) if finite.size > 1 else 0.0


def _summary_fraction(summary: Mapping[str, Any], numerator: str, denominator: str) -> float:
    if numerator not in summary or denominator not in summary:
        return float("nan")
    denominator_value = float(summary[denominator])
    return float(summary[numerator]) / denominator_value if denominator_value > 0.0 else 0.0


def _metric_matrix(
    cases: Sequence[_CaseView],
    geometries: Sequence[str],
    scenarios: Sequence[str],
    getter,
) -> tuple[np.ndarray, np.ndarray]:
    mean = np.full((len(geometries), len(scenarios)), np.nan)
    sd = np.full_like(mean, np.nan)
    for row, geometry in enumerate(geometries):
        for column, scenario in enumerate(scenarios):
            values = [
                float(getter(case.summary))
                for case in cases
                if case.geometry_id == geometry and case.scenario_id == scenario
            ]
            mean[row, column], sd[row, column] = _mean_and_sd(values)
    return mean, sd


def _annotated_heatmap(
    axis: plt.Axes,
    values: np.ndarray,
    deviations: np.ndarray,
    *,
    row_labels: Sequence[str],
    column_labels: Sequence[str],
    title: str,
    colorbar_label: str,
    percent: bool,
) -> Any:
    finite = values[np.isfinite(values)]
    if finite.size:
        vmin = min(0.0, float(np.min(finite)))
        vmax = float(np.max(finite))
        if vmax <= vmin:
            vmax = vmin + 1.0
    else:
        vmin, vmax = 0.0, 1.0
    cmap = plt.get_cmap("YlOrRd").with_extremes(bad="#eceff1")
    image = axis.imshow(np.ma.masked_invalid(values), cmap=cmap, vmin=vmin, vmax=vmax, aspect="auto")
    for row in range(values.shape[0]):
        for column in range(values.shape[1]):
            value = values[row, column]
            if not math.isfinite(value):
                text = "–"
            else:
                scale = 100.0 if percent else 1.0
                suffix = "%" if percent else ""
                text = f"{scale * value:.1f}{suffix}"
                deviation = deviations[row, column]
                if math.isfinite(deviation) and deviation > 0.0:
                    text += f"\n±{scale * deviation:.1f}"
            rgba = image.cmap(image.norm(value)) if math.isfinite(value) else (0.9, 0.9, 0.9, 1.0)
            luminance = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
            axis.text(column, row, text, ha="center", va="center", fontsize=7.4, color="black" if luminance > 0.55 else "white")
    axis.set_xticks(np.arange(len(column_labels)), column_labels, rotation=25, ha="right")
    axis.set_yticks(np.arange(len(row_labels)), row_labels)
    axis.set_xlabel("mechanism scenario")
    axis.set_ylabel("trench geometry")
    axis.set_title(title)
    colorbar = axis.figure.colorbar(image, ax=axis, fraction=0.046, pad=0.035)
    colorbar.set_label(colorbar_label)
    return image


def _phase_metric(
    payload: Mapping[str, Any], geometry_id: str, metric: str
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    phase_map = payload.get("phase_map")
    if not isinstance(phase_map, Mapping):
        raise ValueError("payload contains no explicit phase_map")
    axes = phase_map.get("axes")
    by_geometry = phase_map.get("by_geometry")
    if not isinstance(axes, Mapping) or not isinstance(by_geometry, Mapping):
        raise ValueError("phase_map needs axes and by_geometry mappings")
    entry = by_geometry.get(geometry_id)
    if not isinstance(entry, Mapping):
        raise ValueError(f"phase_map has no geometry {geometry_id!r}")
    metrics = entry.get("metrics")
    if not isinstance(metrics, Mapping) or metric not in metrics:
        raise ValueError(f"phase_map geometry {geometry_id!r} lacks metric {metric!r}")
    hf_scale = np.asarray(axes.get("hf_scale", ()), dtype=float)
    retention = np.asarray(axes.get("retention_strength_scale", ()), dtype=float)
    if hf_scale.ndim != 1 or retention.ndim != 1 or not hf_scale.size or not retention.size:
        raise ValueError("phase_map axes must be non-empty one-dimensional arrays")
    values = np.asarray(metrics[metric], dtype=float)
    order = tuple(entry.get("dimension_order", ("retention_strength_scale", "hf_scale")))
    if order == ("hf_scale", "retention_strength_scale"):
        values = values.T
    elif order != ("retention_strength_scale", "hf_scale"):
        raise ValueError(f"unsupported phase-map dimension order {order!r}")
    if values.shape != (retention.size, hf_scale.size):
        raise ValueError(
            f"phase metric shape {values.shape} does not match "
            f"({retention.size}, {hf_scale.size})"
        )
    return hf_scale, retention, values


def _explicit_phase_panel(
    axis: plt.Axes,
    *,
    hf_scale: np.ndarray,
    retention: np.ndarray,
    residue: np.ndarray,
    deposit_fraction: np.ndarray,
    geometry_label: str,
    norm: Normalize,
    residue_name: str = "bottom",
    residue_code: str = "B",
) -> Any:
    cmap = plt.get_cmap("magma_r").with_extremes(bad="#eceff1")
    image = axis.imshow(
        np.ma.masked_invalid(residue),
        cmap=cmap,
        norm=norm,
        origin="lower",
        aspect="auto",
    )
    for row in range(residue.shape[0]):
        for column in range(residue.shape[1]):
            residue_value = residue[row, column]
            deposit = deposit_fraction[row, column]
            if not math.isfinite(residue_value):
                text = "–"
                color = "black"
            else:
                text = (
                    f"{residue_code} {100.0 * residue_value:.1f}%\n"
                    f"D {100.0 * deposit:.1f}%"
                )
                rgba = image.cmap(image.norm(residue_value))
                luminance = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
                color = "black" if luminance > 0.55 else "white"
            axis.text(column, row, text, ha="center", va="center", fontsize=7.5, color=color)
    axis.set_xticks(np.arange(hf_scale.size), [f"{value:g}" for value in hf_scale])
    axis.set_yticks(np.arange(retention.size), [f"{value:g}" for value in retention])
    axis.set_xlabel("bulk HF scale")
    axis.set_ylabel("retention-strength scale")
    axis.set_title(
        f"HF × retention phase map — {geometry_label}\n"
        f"cell: {residue_name} residue {residue_code} / persistent deposit D"
    )
    colorbar = axis.figure.colorbar(image, ax=axis, fraction=0.046, pad=0.035)
    colorbar.set_label(f"{residue_name} remaining fraction")
    return image


def plot_trench_kmc_sensitivity_summary(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 220,
) -> Path:
    """Plot geometry/scenario phase maps and region/cluster sensitivities."""

    payload = _load_payload(payload_or_path)
    cases = _case_views(payload)
    geometries = _ordered_ids(payload, "geometries", cases)
    scenarios = _ordered_ids(payload, "scenarios", cases)
    if not geometries or not scenarios:
        raise ValueError("sensitivity payload must contain geometries and scenarios")
    geometry_labels = [_lookup_label(payload, "geometries", item) for item in geometries]
    scenario_labels = [_lookup_label(payload, "scenarios", item) for item in scenarios]

    remaining, remaining_sd = _metric_matrix(
        cases, geometries, scenarios, lambda summary: float(summary.get("remaining_fraction", np.nan))
    )
    deposit, deposit_sd = _metric_matrix(
        cases,
        geometries,
        scenarios,
        lambda summary: _summary_fraction(summary, "deposit_count", "collector_site_count"),
    )

    region_names = ("top", "sidewall", "bottom", "core")
    region_means = np.full((len(region_names), len(scenarios)), np.nan)
    region_sd = np.full_like(region_means, np.nan)
    for region_index, region in enumerate(region_names):
        for scenario_index, scenario in enumerate(scenarios):
            values = []
            for case in cases:
                if case.scenario_id != scenario:
                    continue
                region_metrics = case.summary.get("region_metrics", {})
                if isinstance(region_metrics, Mapping) and isinstance(region_metrics.get(region), Mapping):
                    value = region_metrics[region].get("remaining_fraction")
                    if value is not None:
                        values.append(float(value))
            region_means[region_index, scenario_index], region_sd[region_index, scenario_index] = _mean_and_sd(values)

    cluster_labels = ("passivation cluster", "deposit cluster")
    cluster_values = np.full((2, len(scenarios)), np.nan)
    cluster_sd = np.full_like(cluster_values, np.nan)
    for scenario_index, scenario in enumerate(scenarios):
        passivation_values = [
            _summary_fraction(case.summary, "largest_passivation_cluster", "matrix_site_count")
            for case in cases
            if case.scenario_id == scenario
        ]
        deposit_values = [
            _summary_fraction(case.summary, "largest_deposit_cluster", "collector_site_count")
            for case in cases
            if case.scenario_id == scenario
        ]
        cluster_values[0, scenario_index], cluster_sd[0, scenario_index] = _mean_and_sd(passivation_values)
        cluster_values[1, scenario_index], cluster_sd[1, scenario_index] = _mean_and_sd(deposit_values)

    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(2, 2, figsize=(13.2, 8.4))
        if isinstance(payload.get("phase_map"), Mapping):
            phase_specs: list[tuple[str, str, str, str]] = []
            if len(geometries) >= 2:
                phase_specs = [
                    (geometries[0], "bottom_remaining_fraction", "bottom", "B"),
                    (geometries[1], "bottom_remaining_fraction", "bottom", "B"),
                ]
            else:
                phase_specs = [
                    (geometries[0], "bottom_remaining_fraction", "bottom", "B"),
                    (geometries[0], "sidewall_remaining_fraction", "sidewall", "S"),
                ]
            phase_values: list[tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = []
            for geometry, metric, _, _ in phase_specs:
                hf_scale, retention, residue_values = _phase_metric(
                    payload, geometry, metric
                )
                _, _, deposit_values = _phase_metric(
                    payload, geometry, "deposit_fraction"
                )
                phase_values.append(
                    (hf_scale, retention, residue_values, deposit_values)
                )
            finite_parts = [
                item[2][np.isfinite(item[2])]
                for item in phase_values
                if np.any(np.isfinite(item[2]))
            ]
            finite_phase = (
                np.concatenate(finite_parts)
                if finite_parts
                else np.asarray((0.0, 1.0))
            )
            phase_min = min(0.0, float(np.min(finite_phase)))
            phase_max = float(np.max(finite_phase))
            if phase_max <= phase_min:
                phase_max = phase_min + 1.0
            phase_norm = Normalize(phase_min, phase_max)
            for index, (axis, spec, data) in enumerate(
                zip(axes[0], phase_specs, phase_values, strict=True)
            ):
                geometry, _, residue_name, residue_code = spec
                hf_scale, retention, residue_values, deposit_values = data
                _explicit_phase_panel(
                    axis,
                    hf_scale=hf_scale,
                    retention=retention,
                    residue=residue_values,
                    deposit_fraction=deposit_values,
                    geometry_label=_lookup_label(payload, "geometries", geometry),
                    norm=phase_norm,
                    residue_name=residue_name,
                    residue_code=residue_code,
                )
                _panel_label(axis, "A" if index == 0 else "B")
        else:
            _annotated_heatmap(
                axes[0, 0],
                remaining,
                remaining_sd,
                row_labels=geometry_labels,
                column_labels=scenario_labels,
                title="Final GAP-FILL residue phase map",
                colorbar_label="remaining matrix fraction",
                percent=True,
            )
            _panel_label(axes[0, 0], "A")
            _annotated_heatmap(
                axes[0, 1],
                deposit,
                deposit_sd,
                row_labels=geometry_labels,
                column_labels=scenario_labels,
                title="Persistent wall/floor deposit phase map",
                colorbar_label="deposit / collector sites",
                percent=True,
            )
            _panel_label(axes[0, 1], "B")

        positions = np.arange(len(scenarios), dtype=float)
        width = 0.18
        region_colors = ("#4c78a8", "#72b7b2", "#f2a541", "#8f7aae")
        for index, (region, color) in enumerate(zip(region_names, region_colors, strict=True)):
            offset = (index - 1.5) * width
            axes[1, 0].bar(
                positions + offset,
                100.0 * region_means[index],
                width=width,
                yerr=100.0 * region_sd[index],
                capsize=2,
                color=color,
                label=region,
                linewidth=0,
            )
        axes[1, 0].set_xticks(positions, scenario_labels, rotation=25, ha="right")
        axes[1, 0].set_ylabel("remaining matrix in region (%)")
        axes[1, 0].set_title("Where residue persists")
        axes[1, 0].grid(axis="y", color="0.88", linewidth=0.65)
        axes[1, 0].legend(frameon=False, ncol=2)
        _panel_label(axes[1, 0], "C")

        cluster_colors = ("#e89023", "#b02a78")
        cluster_width = 0.34
        for index, (label, color) in enumerate(zip(cluster_labels, cluster_colors, strict=True)):
            offset = (index - 0.5) * cluster_width
            axes[1, 1].bar(
                positions + offset,
                100.0 * cluster_values[index],
                width=cluster_width,
                yerr=100.0 * cluster_sd[index],
                capsize=2,
                color=color,
                label=label,
                linewidth=0,
            )
        axes[1, 1].set_xticks(positions, scenario_labels, rotation=25, ha="right")
        axes[1, 1].set_ylabel("largest cluster / available sites (%)")
        axes[1, 1].set_title("Passivation and redeposition clustering")
        axes[1, 1].grid(axis="y", color="0.88", linewidth=0.65)
        axes[1, 1].legend(frameon=False)
        finite_clusters = cluster_values[np.isfinite(cluster_values)]
        if not finite_clusters.size or float(np.max(finite_clusters)) <= 0.0:
            axes[1, 1].set_ylim(0.0, 1.0)
        _panel_label(axes[1, 1], "D")

        figure.text(0.5, 0.008, MESOSCOPIC_KMC_CAVEAT, ha="center", va="bottom", fontsize=7.3, color="0.32")
        figure.subplots_adjust(left=0.075, right=0.96, bottom=0.16, top=0.94, wspace=0.34, hspace=0.42)
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        figure.savefig(destination, dpi=dpi, bbox_inches="tight")
        plt.close(figure)
    return destination


def _one_case_view(value: Any) -> _CaseView:
    cases = _case_views(value)
    if not cases:
        raise ValueError("there is no representative KMC case")
    return cases[0]


def plot_trench_kmc_event_history(
    outcome_or_case: Any,
    output_path: str | Path,
    *,
    dpi: int = 220,
) -> Path:
    """Plot sync occupancy/fields and event history for one coupled run."""

    case = _one_case_view(outcome_or_case)
    history = sorted(case.sync_history, key=lambda item: float(item.get("time_s", 0.0)))
    events = sorted(case.event_locations, key=lambda item: float(item.get("time_s", 0.0)))
    if not history:
        raise ValueError("representative case contains no synchronization history")
    times = np.asarray([float(item.get("time_s", 0.0)) for item in history])
    state_names_list = ["buried", "intact", "activated"]
    for state in ("hydrolyzed_silanol", "fluorinated"):
        if any(
            float(item.get("state_counts", {}).get(state, 0.0)) > 0.0
            for item in history
        ):
            state_names_list.append(state)
    state_names_list.extend(("passivated", "removed"))
    state_names = tuple(state_names_list)
    state_series = np.asarray(
        [
            [float(item.get("state_counts", {}).get(state, 0.0)) for item in history]
            for state in state_names
        ]
    )
    totals = np.sum(state_series, axis=0)
    fractions = np.divide(state_series, totals, out=np.zeros_like(state_series), where=totals > 0.0)

    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(2, 2, figsize=(13.0, 8.0))
        history_state_colors = {
            "buried": "#71767b",
            "intact": "#a0a4a8",
            "activated": _STATE_COLORS["activated"],
            "hydrolyzed_silanol": _STATE_COLORS["hydrolyzed_silanol"],
            "fluorinated": _STATE_COLORS["fluorinated"],
            "passivated": _STATE_COLORS["passivated"],
            "removed": "#9ed5e7",
        }
        state_colors = tuple(
            history_state_colors[state] for state in state_names
        )
        axes[0, 0].stackplot(times, 100.0 * fractions, labels=state_names, colors=state_colors, linewidth=0)
        axes[0, 0].set_xlim(times.min(), max(times.max(), times.min() + 1.0e-9))
        axes[0, 0].set_ylim(0.0, 100.0)
        axes[0, 0].set_xlabel("coupling time (s)")
        axes[0, 0].set_ylabel("matrix-site occupancy (%)")
        axes[0, 0].set_title("KMC matrix state at continuum synchronization")
        axes[0, 0].legend(frameon=False, ncol=3, loc="upper center")
        _panel_label(axes[0, 0], "A")

        hf_mean = np.asarray([float(item.get("hf_interface_mean", np.nan)) for item in history])
        hf_min = np.asarray([float(item.get("hf_interface_min", np.nan)) for item in history])
        product_mean = np.asarray([float(item.get("product_interface_mean", np.nan)) for item in history])
        axes[0, 1].plot(times, hf_mean, "o-", color="#2878b5", markersize=3.0, linewidth=1.2, label="mean HF")
        axes[0, 1].plot(times, hf_min, "--", color="#6baed6", linewidth=1.1, label="minimum HF")
        axes[0, 1].set_xlabel("coupling time (s)")
        axes[0, 1].set_ylabel("HF concentration (model units)", color="#2878b5")
        axes[0, 1].tick_params(axis="y", labelcolor="#2878b5")
        product_axis = axes[0, 1].twinx()
        product_axis.plot(times, product_mean, "s-", color="#b02a78", markersize=2.8, linewidth=1.1, label="mean product")
        product_axis.set_ylabel("product concentration (model units)", color="#b02a78")
        product_axis.tick_params(axis="y", labelcolor="#b02a78")
        handles_left, labels_left = axes[0, 1].get_legend_handles_labels()
        handles_right, labels_right = product_axis.get_legend_handles_labels()
        axes[0, 1].legend(handles_left + handles_right, labels_left + labels_right, frameon=False, loc="best")
        axes[0, 1].set_title("Fields passed from 2D continuum to KMC sites")
        axes[0, 1].grid(axis="x", color="0.9", linewidth=0.6)
        _panel_label(axes[0, 1], "B")

        event_names: list[str] = []
        for event in events:
            name = str(event.get("event_name", "event"))
            if name not in event_names:
                event_names.append(name)
        if events:
            event_times = np.asarray([float(item.get("time_s", 0.0)) for item in events])
            for name in event_names:
                cumulative = np.cumsum([str(item.get("event_name", "event")) == name for item in events])
                axes[1, 0].step(event_times, cumulative, where="post", color=_EVENT_COLORS.get(name, "0.35"), linewidth=1.25, label=name)
            axes[1, 0].set_yscale("symlog", linthresh=1.0)
            axes[1, 0].legend(frameon=False, ncol=2)
        else:
            axes[1, 0].text(0.5, 0.5, "no KMC events", transform=axes[1, 0].transAxes, ha="center", va="center", color="0.4")
        axes[1, 0].set_xlabel("KMC time (s)")
        axes[1, 0].set_ylabel("cumulative event count")
        axes[1, 0].set_title("Event competition")
        axes[1, 0].grid(color="0.9", linewidth=0.6)
        _panel_label(axes[1, 0], "C")

        spatial_events = [item for item in events if "depth_nm" in item]
        if spatial_events:
            for name in event_names:
                selected = [item for item in spatial_events if str(item.get("event_name", "event")) == name]
                if not selected:
                    continue
                axes[1, 1].scatter(
                    [float(item.get("time_s", 0.0)) for item in selected],
                    [float(item["depth_nm"]) for item in selected],
                    s=12,
                    marker=_EVENT_MARKERS.get(name, "o"),
                    color=_EVENT_COLORS.get(name, "0.35"),
                    edgecolors="none",
                    alpha=0.65,
                    label=name,
                    rasterized=True,
                )
            axes[1, 1].invert_yaxis()
            axes[1, 1].legend(frameon=False, ncol=2)
        else:
            axes[1, 1].text(0.5, 0.5, "event locations unavailable", transform=axes[1, 1].transAxes, ha="center", va="center", color="0.4")
        axes[1, 1].set_xlabel("KMC time (s)")
        axes[1, 1].set_ylabel("event depth z (nm)")
        axes[1, 1].set_title("Where events occur along the trench")
        axes[1, 1].grid(color="0.9", linewidth=0.6)
        _panel_label(axes[1, 1], "D")

        summary = case.summary
        remaining = summary.get("remaining_fraction")
        deposits = summary.get("deposit_count")
        header = case.title
        details = []
        if remaining is not None:
            details.append(f"final residue {100.0 * float(remaining):.1f}%")
        if deposits is not None:
            details.append(f"persistent deposits {int(deposits)}")
        if details:
            header += " — " + ", ".join(details)
        figure.suptitle(header, fontsize=11, y=0.985)
        figure.text(0.5, 0.008, MESOSCOPIC_KMC_CAVEAT, ha="center", va="bottom", fontsize=7.3, color="0.32")
        figure.subplots_adjust(left=0.075, right=0.93, bottom=0.12, top=0.91, wspace=0.38, hspace=0.36)
        destination = Path(output_path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        figure.savefig(destination, dpi=dpi, bbox_inches="tight")
        plt.close(figure)
    return destination


__all__ = [
    "MESOSCOPIC_KMC_CAVEAT",
    "plot_trench_kmc_event_history",
    "plot_trench_kmc_phase_maps",
    "plot_trench_kmc_sensitivity_summary",
]

from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from kawarazaki_fig3_plateau_screen import (
    Fig3DigitizedSeries,
    build_fig3_plateau_screen,
    save_fig3_plateau_screen_json,
)
from run_kawarazaki_fig3_plateau_screen import main


class KawarazakiFig3PlateauScreenTests(unittest.TestCase):
    def setUp(self) -> None:
        self.payload = build_fig3_plateau_screen()

    def test_only_four_nonzero_measured_times_are_encoded(self) -> None:
        times = self.payload["experimental_context"]["ozone_bake"][
            "measured_bake_times_s"
        ]
        self.assertEqual(times, [15, 30, 60, 120])
        self.assertNotIn(0, times)
        for material in self.payload["materials"]:
            measurement_times = [
                row["bake_time_s"] for row in material["measurements"]
            ]
            self.assertEqual(measurement_times, times)
            self.assertTrue(
                all(
                    not row["is_interpolated"]
                    and not row["is_extrapolated"]
                    for row in material["measurements"]
                )
            )
        digitization = self.payload["digitization"]
        self.assertTrue(digitization["zero_second_marker_in_source_raster"])
        self.assertFalse(
            digitization["zero_second_marker_encoded_as_measurement"]
        )

    def test_digitized_values_and_labels_are_preserved(self) -> None:
        expected = {
            "sicn_c22": ("SiCN(C:22%)", [2.50, 2.92, 2.93, 2.96]),
            "sicn_c40": ("SiCN(C:40%)", [0.68, 0.84, 0.75, 0.84]),
            "siocn_c5": ("SiOCN(C:5%)", [0.52, 0.60, 0.51, 0.52]),
        }
        self.assertEqual(
            {material["material_id"] for material in self.payload["materials"]},
            set(expected),
        )
        for material in self.payload["materials"]:
            label, values = expected[material["material_id"]]
            self.assertEqual(material["figure_label"], label)
            self.assertEqual(
                [
                    row["etch_amount_nm_per_cycle"]
                    for row in material["measurements"]
                ],
                values,
            )
            self.assertIn("not disclosed", material["carbon_percent_basis"])

        digitization = self.payload["digitization"]
        self.assertTrue(digitization["values_are_approximate"])
        self.assertEqual(
            digitization["per_point_readout_tolerance_nm"],
            0.05,
        )
        self.assertFalse(
            digitization["readout_tolerance_is_experimental_uncertainty"]
        )
        self.assertEqual(
            self.payload["source"]["official_figure_sha256"],
            "eb0aae0412e849b341ed399a3bdc887018bf6d4ab57ea8f81af35c5f8a113faa",
        )

    def test_post_30_s_diagnostics_are_descriptive_only(self) -> None:
        diagnostics = {
            material["material_id"]: material["diagnostics"]
            for material in self.payload["materials"]
        }
        self.assertEqual(
            diagnostics["sicn_c22"]["tail_span_nm_per_cycle"],
            0.04,
        )
        self.assertEqual(
            diagnostics["sicn_c40"]["tail_span_nm_per_cycle"],
            0.09,
        )
        self.assertEqual(
            diagnostics["siocn_c5"]["tail_span_nm_per_cycle"],
            0.09,
        )
        self.assertEqual(
            diagnostics["sicn_c22"][
                "tail_endpoint_change_30_to_120_nm_per_cycle"
            ],
            0.04,
        )
        self.assertEqual(
            diagnostics["sicn_c40"][
                "tail_endpoint_change_30_to_120_nm_per_cycle"
            ],
            0.0,
        )
        self.assertEqual(
            diagnostics["siocn_c5"][
                "tail_endpoint_change_30_to_120_nm_per_cycle"
            ],
            -0.08,
        )
        for diagnostic in diagnostics.values():
            self.assertEqual(
                diagnostic["tail_window_measured_times_s"],
                [30, 60, 120],
            )
            self.assertTrue(
                diagnostic[
                    "post_30_s_span_within_pairwise_readout_tolerance"
                ]
            )
            self.assertFalse(diagnostic["plateau_proven"])

        constraints = self.payload["analysis_constraints"]
        self.assertFalse(constraints["kinetic_model_fitted"])
        self.assertFalse(constraints["interpolation_performed"])
        self.assertFalse(constraints["extrapolation_performed"])
        self.assertFalse(constraints["plateau_onset_estimated"])
        self.assertFalse(constraints["cycle_linearity_evaluated"])
        self.assertFalse(
            constraints["fig2_fig3_shared_30_s_endpoint_calibrated"]
        )

    def test_cross_panel_30_s_mismatch_blocks_shared_calibration(self) -> None:
        warning = self.payload["cross_panel_warning"]
        self.assertFalse(
            warning["fig2_and_fig3_30_s_values_are_identical"]
        )
        self.assertFalse(
            warning[
                "panels_numerically_mergeable_without_missing_condition_resolution"
            ]
        )
        examples = {
            row["material_id"]: row
            for row in warning["approximate_raster_examples"]
        }
        self.assertEqual(examples["sicn_c22"]["fig3_30_s_nm_per_cycle"], 2.92)
        self.assertEqual(
            examples["sicn_c22"]["fig2_30_s_ozone_then_dhf_nm"],
            2.47,
        )
        self.assertIn("Do not merge", warning["warning"])

    def test_series_validation_rejects_invalid_inputs(self) -> None:
        with self.assertRaisesRegex(ValueError, "must match"):
            Fig3DigitizedSeries(
                material_id="bad",
                material="SiCN",
                figure_label="bad",
                nominal_carbon_percent=1.0,
                etch_amount_nm_per_cycle=(1.0,),
            )
        with self.assertRaisesRegex(ValueError, "non-negative"):
            Fig3DigitizedSeries(
                material_id="bad",
                material="SiCN",
                figure_label="bad",
                nominal_carbon_percent=1.0,
                etch_amount_nm_per_cycle=(1.0, 1.0, -1.0, 1.0),
            )

    def test_strict_json_round_trip_and_nan_rejection(self) -> None:
        json.dumps(self.payload, allow_nan=False)
        with tempfile.TemporaryDirectory() as directory:
            path = save_fig3_plateau_screen_json(
                self.payload,
                Path(directory) / "nested" / "fig3.json",
            )
            saved = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(
                saved["schema_version"],
                "kawarazaki-fig3-plateau-screen/v1",
            )
            self.assertEqual(len(saved["materials"]), 3)
            with self.assertRaises(ValueError):
                save_fig3_plateau_screen_json(
                    {"invalid": float("nan")},
                    Path(directory) / "nan.json",
                )

    def test_cli_writes_requested_output(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "result.json"
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                exit_code = main(["--output", str(output)])
            self.assertEqual(exit_code, 0)
            self.assertTrue(output.is_file())
            cli_summary = json.loads(stdout.getvalue())
            saved = json.loads(output.read_text(encoding="utf-8"))
        self.assertEqual(cli_summary["output"], str(output))
        self.assertEqual(cli_summary["measured_bake_times_s"], [15, 30, 60, 120])
        self.assertEqual(
            saved["source"]["doi"],
            "10.1149/MA2024-02312265mtgabs",
        )


if __name__ == "__main__":
    unittest.main()

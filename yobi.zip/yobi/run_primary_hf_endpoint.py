#!/usr/bin/env python3
"""Run literature/blanket-anchored primary-HF endpoint calculations."""

from __future__ import annotations

import argparse
from dataclasses import replace
import os
from pathlib import Path


for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ[_thread_variable] = "1"


from literature_parameters import LITERATURE_ETCH_PRESETS  # noqa: E402
from literature_sweep import nominal_preset_names  # noqa: E402
from primary_hf_endpoint import (  # noqa: E402
    PrimaryHFEndpointConfig,
    load_blanket_rate_csv,
    run_primary_hf_endpoint_calibration,
    save_primary_hf_endpoint_csv,
    save_primary_hf_endpoint_json,
)


RESULT_NAME = "primary_hf_endpoint_results.json"
CSV_NAME = "primary_hf_endpoint_table.csv"
README_NAME = "README_JA.md"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Calibrate the native trench graph-KMC clock with a same-law "
            "blanket coupon, anchor it to film WER, and calculate exact "
            "primary-HF matrix-removal endpoints."
        )
    )
    parser.add_argument(
        "--mode",
        choices=("smoke", "quick", "full"),
        default="quick",
        help=(
            "smoke=one coarse SiN check; quick=two target geometries, nominal "
            "SiN/SiOCN, two seeds; full=all six literature films, five seeds"
        ),
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="trench worker processes; 0 selects up to eight automatically",
    )
    parser.add_argument(
        "--blanket-csv",
        type=Path,
        default=None,
        help=(
            "optional measured blanket inputs with preset_id,rate_nm_min,"
            "measurement_temperature_K and optional uncertainty_nm_min,"
            "source_note columns"
        ),
    )
    parser.add_argument(
        "--preset",
        choices=tuple(LITERATURE_ETCH_PRESETS),
        action="append",
        help=(
            "repeat to override the mode's film selection; enables the "
            "provisional Kawarazaki SiCN/SiOCN 30 s linearized priors"
        ),
    )
    parser.add_argument(
        "--liquid-temperature-K",
        type=float,
        default=298.15,
        help="HF-solution bulk temperature; independent of substrate",
    )
    parser.add_argument(
        "--substrate-temperature-K",
        type=float,
        default=298.15,
        help="substrate backside temperature; independent of solution",
    )
    parser.add_argument(
        "--passivation-strength-scale",
        type=float,
        default=1.0,
        help=(
            "multiplies the passivation generation rate; sweep this across "
            "runs to obtain the residue-versus-passivation-strength curve"
        ),
    )
    parser.add_argument(
        "--maximum-planar-clear-time-multiplier",
        type=float,
        default=None,
        help=(
            "physical time budget in planar clear times; the default keeps a "
            "decelerating passivated trench from being right-censored"
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/primary_hf_endpoint"),
        help="directory for strict JSON, flat endpoint CSV, README and PNGs",
    )
    return parser


def config_for_mode(
    mode: str,
    workers: int = 0,
    *,
    liquid_temperature_K: float = 298.15,
    substrate_temperature_K: float = 298.15,
    passivation_strength_scale: float = 1.0,
    maximum_planar_clear_time_multiplier: float | None = None,
) -> PrimaryHFEndpointConfig:
    if workers < 0:
        raise ValueError("workers must be zero or positive")
    common = {
        "solution_temperature_K": liquid_temperature_K,
        "substrate_temperature_K": substrate_temperature_K,
        "parallel_workers": 1,
        "passivation_strength_scale": passivation_strength_scale,
    }
    if maximum_planar_clear_time_multiplier is not None:
        common["maximum_planar_clear_time_multiplier"] = (
            maximum_planar_clear_time_multiplier
        )
    if mode == "smoke":
        config = PrimaryHFEndpointConfig(
            geometries=("10_10_180",),
            presets=("sin_barcellona_b_0p55wt",),
            replicate_seeds=(271828,),
            grid_spacing_nm=20.0,
            reservoir_height_nm=20.0,
            lateral_margin_nm=0.0,
            primary_sync_steps=6,
            maximum_events=5_000,
            coupon_width_nm=40.0,
            coupon_depth_nm=60.0,
            coupon_maximum_events=5_000,
            trace_points=40,
            **common,
        )
    elif mode == "quick":
        config = PrimaryHFEndpointConfig(
            replicate_seeds=(271828, 314159),
            grid_spacing_nm=1.7,
            primary_sync_steps=60,
            trace_points=160,
            **common,
        )
    elif mode == "full":
        config = PrimaryHFEndpointConfig(
            presets=tuple(sorted(nominal_preset_names())) + (
                "sin_barcellona_a_0p55wt",
                "sin_barcellona_c_0p55wt",
                "siocn_fujitsu_4a_100to1",
                "siocn_fujitsu_4d_100to1",
            ),
            replicate_seeds=(271828, 314159, 161803, 141421, 173205),
            grid_spacing_nm=1.4,
            primary_sync_steps=90,
            maximum_events=120_000,
            coupon_width_nm=28.0,
            coupon_depth_nm=56.0,
            coupon_maximum_events=30_000,
            trace_points=220,
            **common,
        )
    else:
        raise ValueError("mode must be smoke, quick or full")
    requested = (
        len(config.geometries)
        * len(config.presets)
        * len(config.scenarios)
        * len(config.replicate_seeds)
    )
    resolved = (
        min(8, os.cpu_count() or 1, requested)
        if workers == 0
        else min(workers, requested)
    )
    return replace(config, parallel_workers=max(1, resolved))


def _target_summary(payload: dict[str, object]) -> list[str]:
    lines = []
    aggregates = payload.get("aggregates", [])
    for row in aggregates if isinstance(aggregates, list) else []:
        if not isinstance(row, dict):
            continue
        one_percent = next(
            (
                item
                for item in row.get("endpoint_summaries", [])
                if abs(float(item["target_remaining_fraction"]) - 0.01) < 1.0e-12
            ),
            None,
        )
        if one_percent is None:
            continue
        summary = one_percent["physical_time_s"]
        median = summary.get("median")
        display = "未到達" if median is None else f"{float(median) / 60.0:.1f} min"
        uncertainty = one_percent.get(
            "blanket_rate_uncertainty_time_s", {}
        )
        uncertainty_low = uncertainty.get(
            "median_lower_physical_time_s"
        )
        uncertainty_high = uncertainty.get(
            "median_upper_physical_time_s"
        )
        uncertainty_display = (
            ""
            if uncertainty_low is None or uncertainty_high is None
            else (
                " (WER入力範囲 "
                f"{float(uncertainty_low) / 60.0:.1f}–"
                f"{float(uncertainty_high) / 60.0:.1f} min; clock-only)"
            )
        )
        fixed_rows = row.get("fixed_time_summaries", [])
        fixed_300 = next(
            (
                item
                for item in fixed_rows
                if abs(float(item["physical_time_s"]) - 300.0) < 1.0e-12
            ),
            None,
        )
        remaining_300 = (
            None
            if fixed_300 is None
            else fixed_300["remaining_fraction"].get("median")
        )
        bottom_clear = row.get("regional_clear_summaries", {}).get(
            "bottom", {}
        ).get("physical_time_s", {}).get("median")
        bottom_display = (
            "未到達"
            if bottom_clear is None
            else f"{float(bottom_clear) / 60.0:.1f} min"
        )
        final_remaining = row.get("final_remaining_fraction", {}).get("median")
        remaining_display = (
            "n/a"
            if remaining_300 is None
            else f"{100.0 * float(remaining_300):.1f}%"
        )
        final_display = (
            "n/a"
            if final_remaining is None
            else f"{100.0 * float(final_remaining):.1f}%"
        )
        lines.append(
            f"- {row['geometry_id']} / {row['material']} / "
            f"{row['scenario_label_ja']}: 300 s残存 {remaining_display}; "
            f"全体1% {display}{uncertainty_display}; "
            f"bottom clear {bottom_display}; "
            f"最大時間後 {final_display} "
            f"({one_percent['reached_replicates']}/"
            f"{one_percent['requested_replicates']} seeds)"
        )
    return lines


def write_readme(payload: dict[str, object], path: Path) -> Path:
    quality = payload["quality_summary"]
    time_budget_multiplier = float(
        payload["config"]["maximum_planar_clear_time_multiplier"]
    )
    lines = [
        "# 一次HF終点校正",
        "",
        "同じtrench用graph-KMC event則でblanket couponを計算し、"
        "そのnative front速度を文献または実測blanket WERへ規格化した結果です。",
        "",
        f"- 校正状態: `{payload['calibration_status']['level']}`",
        f"- coupon成功: {quality['successful_coupon_runs']}/"
        f"{quality['expected_coupon_runs']}",
        f"- trench実行完了: {quality['successful_trench_runs']}/"
        f"{quality['expected_trench_runs']}",
        f"- 数値的に有効: {quality['valid_trench_runs']}",
        f"- event上限によるpartial: {quality['partial_trench_runs']}",
        f"- 非収束によるinvalid: {quality['invalid_trench_runs']}",
        f"- 例外失敗: {quality['failed_trench_runs']}",
        f"- HF非収束: {quality['hf_nonconverged_runs']}",
        f"- product非収束: {quality['product_nonconverged_runs']}",
        f"- event上限到達: {quality['maximum_event_budget_runs']}",
        "",
        "## 1%元膜残存endpoint",
        "",
        *_target_summary(payload),
        "",
        "## 解釈境界",
        "",
        "- KMCは輸送・生成物・passivationによる相対遅延を与えます。",
        "- 絶対速度はblanket WERから与え、旧1 s^-1 clockをprocess秒として使いません。",
        "- WERの±値は相対trajectoryを固定したclock-only範囲です。信頼区間ではありません。",
        "- 実測blanket CSVでは測定温度を必須とし、温度不明の暗黙補正は行いません。",
        "- `transport_only`は生成物阻害なし、`passivation_hypothesis`は未校正仮説です。",
        (
            "- 上表の最大時間は各膜・形状のplanar clear timeの"
            f"{time_budget_multiplier:g}倍です。"
        ),
        "- 元GAP FILL残存とdry-down析出物は別成分です。この計算は一次HF元膜だけを扱います。",
        "- Si/liner損失、CD損失、粗さを含まないためrecipe限界ではありません。",
        "",
        "## 成果物",
        "",
        f"- `{RESULT_NAME}`: 全入力、coupon校正、seed別trajectory、終点",
        f"- `{CSV_NAME}`: target別の平坦表",
        "- `primary_hf_remaining_curves.png`: 元膜残率–物理時間",
        "- `primary_hf_endpoint_times.png`: 10/5/1%終点時間",
        "- `primary_hf_representative_masks.png`: 300 sと1%終点断面",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def quality_exit_code(quality: dict[str, object]) -> int:
    """Return nonzero when any requested run is failed, invalid or partial."""

    incomplete = sum(
        int(quality.get(key, 0))
        for key in (
            "failed_coupon_runs",
            "failed_trench_runs",
            "invalid_trench_runs",
            "partial_trench_runs",
        )
    )
    return 0 if incomplete == 0 else 1


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    config = config_for_mode(
        args.mode,
        args.workers,
        liquid_temperature_K=args.liquid_temperature_K,
        substrate_temperature_K=args.substrate_temperature_K,
        passivation_strength_scale=args.passivation_strength_scale,
        maximum_planar_clear_time_multiplier=(
            args.maximum_planar_clear_time_multiplier
        ),
    )
    if args.preset:
        config = replace(
            config,
            presets=tuple(dict.fromkeys(args.preset)),
        )
    if args.blanket_csv is not None:
        overrides = load_blanket_rate_csv(args.blanket_csv)
        unselected = set(overrides).difference(config.presets)
        if unselected:
            raise ValueError(
                "blanket CSV contains presets outside this mode: "
                f"{sorted(unselected)}"
            )
        config = replace(config, blanket_rate_inputs=overrides)

    payload = run_primary_hf_endpoint_calibration(config)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    # Persist the expensive numerical result before optional rendering.
    json_path = save_primary_hf_endpoint_json(
        payload, args.output_dir / RESULT_NAME
    )
    csv_path = save_primary_hf_endpoint_csv(
        payload, args.output_dir / CSV_NAME
    )

    from primary_hf_endpoint_visualization import (
        plot_primary_hf_endpoint_visualizations,
    )

    figures = plot_primary_hf_endpoint_visualizations(payload, args.output_dir)
    payload["artifacts"] = {
        **{key: path.name for key, path in figures.items()},
        "endpoint_csv": csv_path.name,
        "readme": README_NAME,
    }
    readme_path = write_readme(payload, args.output_dir / README_NAME)
    json_path = save_primary_hf_endpoint_json(payload, json_path)
    quality = payload["quality_summary"]
    print(f"mode: {args.mode}")
    print(f"calibration status: {payload['calibration_status']['level']}")
    print(
        "coupons: "
        f"{quality['successful_coupon_runs']}/{quality['expected_coupon_runs']}"
    )
    print(
        "trench executions: "
        f"{quality['successful_trench_runs']}/{quality['expected_trench_runs']}"
    )
    print(
        "valid/partial/invalid: "
        f"{quality['valid_trench_runs']}/"
        f"{quality['partial_trench_runs']}/"
        f"{quality['invalid_trench_runs']}"
    )
    print(f"JSON: {json_path}")
    print(f"CSV: {csv_path}")
    print(f"README: {readme_path}")
    for key, path in figures.items():
        print(f"{key}: {path}")
    return quality_exit_code(quality)


if __name__ == "__main__":
    raise SystemExit(main())

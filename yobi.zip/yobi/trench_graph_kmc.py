"""Real-dimension continuum/graph-KMC coupling for GAP-FILL trench removal.

The graph is deliberately mesoscopic: one matrix site represents one Cartesian
continuum cell (normally about 1 nm by 1 nm), not one atom.  All GAP-FILL cells
are created up front.  Only cells touching connected liquid are initially
reactive; removing one cell exposes the actual four-connected next layer.

The ownership split is strict:

* the continuum owns liquid connectivity and local HF/product/temperature;
* graph KMC owns matrix removal, passivation and persistent wall deposits;
* the continuum front is reconstructed from KMC states and is never advanced
  independently.

The kinetic coefficients are screening parameters.  They are not calibrated
absolute SiN/SiCN/SiOCN chemistry and should later be replaced by experimental or
atomistic barrier distributions without changing the coupling topology.
"""

from __future__ import annotations

import math
from collections import Counter, deque
from dataclasses import asdict, dataclass, field
from typing import Iterable, Mapping

import numpy as np

from etch_process import ThermalBoundaryConditions
from graph_kmc import (
    AmorphousGraph,
    EventContext,
    EventRecord,
    EventTemplate,
    GraphKMC,
    GraphSite,
)
from literature_parameters import HF_DIFFUSIVITY_298_NM2_S
from reaction_diffusion_2d import (
    CartesianGrid2D,
    TopBoundaryCondition,
    connected_to_top,
    interface_face_length_on_solid,
    solve_quasi_steady_diffusion,
)
from spatial_etchability import (
    SpatialEtchabilityField,
    SpatialEtchabilityParameters,
)
from thermal_model import NM_TO_M, ThermalResistanceModel
from wetting_2d import WettingParameters, WettingState2D


BASE_MATRIX_STATES = ("buried", "intact", "activated", "passivated", "removed")
INTERMEDIATE_MATRIX_STATES = ("hydrolyzed_silanol", "fluorinated")
MATRIX_STATES = (
    "buried",
    "intact",
    "activated",
    *INTERMEDIATE_MATRIX_STATES,
    "passivated",
    "removed",
)
COLLECTOR_STATES = ("collector", "deposit")
REACTIVE_MATRIX_STATES = (
    "intact",
    "activated",
    *INTERMEDIATE_MATRIX_STATES,
    "passivated",
)
MATRIX_REMOVAL_EVENT_NAMES = frozenset(
    {"remove", "remove_hydrolyzed", "remove_fluorinated"}
)

REGION_TOP = 0
REGION_SIDEWALL = 1
REGION_BOTTOM = 2
REGION_CORE = 3
REGION_NAMES = {
    REGION_TOP: "top",
    REGION_SIDEWALL: "sidewall",
    REGION_BOTTOM: "bottom",
    REGION_CORE: "core",
}


def _finite_positive(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


def _finite_nonnegative(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")


@dataclass(frozen=True)
class TrenchGraphConfig:
    """Spatial discretisation and region tagging for the finite graph."""

    top_region_depth_nm: float = 10.0
    bottom_region_depth_nm: float = 20.0
    sidewall_region_width_nm: float = 1.1
    maximum_sites: int = 2_000
    material: str = "SiN"

    def __post_init__(self) -> None:
        for name in (
            "top_region_depth_nm",
            "bottom_region_depth_nm",
            "sidewall_region_width_nm",
        ):
            _finite_nonnegative(name, getattr(self, name))
        if not isinstance(self.maximum_sites, int) or self.maximum_sites < 1:
            raise ValueError("maximum_sites must be a positive integer")
        if not self.material:
            raise ValueError("material must not be empty")


@dataclass(frozen=True)
class ContinuumCouplingParameters:
    """Quasi-steady field solve and operator-splitting controls."""

    hf_bulk_concentration: float = 1.0
    hf_diffusivity_nm2_s: float = HF_DIFFUSIVITY_298_NM2_S
    hf_interface_sink_velocity_nm_s: float = 4.0e4
    product_diffusivity_nm2_s: float = 7.0e8
    product_interface_source_flux: float = 8.0e3
    product_bulk_decay_per_s: float = 0.25
    hf_reference_concentration: float = 1.0
    product_reference_concentration: float = 0.02
    solution_temperature_K: float = 298.15
    substrate_temperature_K: float = 298.15
    reaction_heat_flux_W_m2: float = 0.0
    macro_time_step_s: float = 1.0
    total_time_s: float = 20.0
    maximum_events: int = 20_000
    relative_tolerance: float = 1.0e-5
    absolute_tolerance: float = 1.0e-10
    maximum_iterations: int = 600
    target_remaining_fraction: float | None = None

    def __post_init__(self) -> None:
        for name in (
            "hf_bulk_concentration",
            "hf_diffusivity_nm2_s",
            "hf_interface_sink_velocity_nm_s",
            "product_diffusivity_nm2_s",
            "hf_reference_concentration",
            "product_reference_concentration",
            "solution_temperature_K",
            "substrate_temperature_K",
            "macro_time_step_s",
        ):
            _finite_positive(name, getattr(self, name))
        for name in (
            "product_interface_source_flux",
            "product_bulk_decay_per_s",
            "total_time_s",
            "absolute_tolerance",
        ):
            _finite_nonnegative(name, getattr(self, name))
        if not math.isfinite(self.reaction_heat_flux_W_m2):
            raise ValueError("reaction_heat_flux_W_m2 must be finite")
        if self.target_remaining_fraction is not None:
            target = float(self.target_remaining_fraction)
            if not math.isfinite(target) or not 0.0 <= target < 1.0:
                raise ValueError(
                    "target_remaining_fraction must be finite and lie within [0, 1)"
                )
            object.__setattr__(self, "target_remaining_fraction", target)
        if self.relative_tolerance <= 0.0:
            raise ValueError("relative_tolerance must be positive")
        if self.maximum_iterations < 1 or self.maximum_events < 0:
            raise ValueError("iteration/event limits are invalid")

    @property
    def thermal_boundary_conditions(self) -> ThermalBoundaryConditions:
        return ThermalBoundaryConditions(
            solution_bulk_temperature_K=self.solution_temperature_K,
            substrate_backside_temperature_K=self.substrate_temperature_K,
        )


@dataclass(frozen=True)
class TrenchKMCParameters:
    """Uncalibrated local rate law used for mechanism screening."""

    reference_temperature_K: float = 298.15
    activation_rate_s: float = 2.2
    removal_rate_s: float = 1.0
    passivation_rate_s: float = 0.26
    depassivation_rate_s: float = 0.08
    precipitation_rate_s: float = 0.05
    deposit_dissolution_rate_s: float = 0.025
    reattachment_rate_s: float = 0.035
    activation_energy_eV: float = 0.18
    removal_energy_eV: float = 0.24
    depassivation_energy_eV: float = 0.12
    hf_half_activity: float = 0.18
    product_half_activity: float = 0.40
    product_inhibition_strength: float = 2.0
    removed_neighbour_boost: float = 0.45
    passivation_cluster_boost: float = 0.9
    cluster_stabilization: float = 0.7
    deposit_cluster_boost: float = 0.5
    reattachment_bottom_bias: float = 1.0
    top_rate_factor: float = 1.0
    sidewall_rate_factor: float = 0.80
    bottom_rate_factor: float = 0.58
    core_rate_factor: float = 0.92

    def __post_init__(self) -> None:
        for name in (
            "reference_temperature_K",
            "hf_half_activity",
            "product_half_activity",
            "top_rate_factor",
            "sidewall_rate_factor",
            "bottom_rate_factor",
            "core_rate_factor",
        ):
            _finite_positive(name, getattr(self, name))
        for name in (
            "activation_rate_s",
            "removal_rate_s",
            "passivation_rate_s",
            "depassivation_rate_s",
            "precipitation_rate_s",
            "deposit_dissolution_rate_s",
            "reattachment_rate_s",
            "activation_energy_eV",
            "removal_energy_eV",
            "depassivation_energy_eV",
            "product_inhibition_strength",
            "removed_neighbour_boost",
            "passivation_cluster_boost",
            "cluster_stabilization",
            "deposit_cluster_boost",
            "reattachment_bottom_bias",
        ):
            _finite_nonnegative(name, getattr(self, name))


@dataclass(frozen=True)
class ArrheniusRateSpec:
    """Explicit absolute-rate anchor plus an activation energy.

    Exactly one absolute-rate convention is required:

    * ``reference_rate_s`` is the pseudo-first-order rate at
      ``reference_temperature_K`` and uses a reference-normalized Arrhenius
      temperature factor; or
    * ``prefactor_per_s`` is an explicit Arrhenius prefactor and evaluates
      ``prefactor * exp(-Ea / kBT)``.

    This deliberately rejects a barrier-only specification.  Atomistic
    screening results are never discovered or mapped automatically.
    """

    activation_energy_eV: float
    reference_rate_s: float | None = None
    prefactor_per_s: float | None = None
    reference_temperature_K: float = 298.15
    provenance: str = "explicit_manual_input"

    def __post_init__(self) -> None:
        _finite_nonnegative("activation_energy_eV", self.activation_energy_eV)
        _finite_positive(
            "reference_temperature_K", self.reference_temperature_K
        )
        supplied = (
            self.reference_rate_s is not None,
            self.prefactor_per_s is not None,
        )
        if sum(supplied) != 1:
            raise ValueError(
                "exactly one of reference_rate_s or prefactor_per_s is required"
            )
        if self.reference_rate_s is not None:
            _finite_nonnegative("reference_rate_s", self.reference_rate_s)
        if self.prefactor_per_s is not None:
            _finite_nonnegative("prefactor_per_s", self.prefactor_per_s)
        provenance = str(self.provenance).strip()
        if not provenance:
            raise ValueError("provenance must be a non-empty explicit label")
        object.__setattr__(self, "provenance", provenance)

    @property
    def rate_mode(self) -> str:
        return (
            "reference_rate"
            if self.reference_rate_s is not None
            else "explicit_prefactor"
        )

    def rate_at_temperature(self, temperature_K: float) -> float:
        _finite_positive("temperature_K", temperature_K)
        if self.reference_rate_s is not None:
            return float(self.reference_rate_s) * _arrhenius_factor(
                self.activation_energy_eV,
                float(temperature_K),
                self.reference_temperature_K,
            )
        assert self.prefactor_per_s is not None
        exponent = -self.activation_energy_eV / (
            _BOLTZMANN_EV_K * float(temperature_K)
        )
        return float(self.prefactor_per_s) * math.exp(max(exponent, -745.0))

    def to_dict(self) -> dict[str, object]:
        return {
            "rate_mode": self.rate_mode,
            "activation_energy_eV": self.activation_energy_eV,
            "reference_rate_s": self.reference_rate_s,
            "prefactor_per_s": self.prefactor_per_s,
            "reference_temperature_K": self.reference_temperature_K,
            "provenance": self.provenance,
        }


@dataclass(frozen=True)
class SpeciesActivitySpec:
    """Explicit multiplicative activities for an ionic reaction channel.

    The continuum currently supplies only total HF.  Local ``hf2_activity``,
    ``fluoride_activity`` and ``protonated_site_fraction`` therefore remain
    opt-in graph-site attributes with zero-valued fallbacks.  Nonzero reaction
    rates require an explicit order for each factor to be used.
    """

    total_hf_order: float = 0.0
    hf2_order: float = 0.0
    fluoride_order: float = 0.0
    protonated_site_order: float = 0.0
    hf2_half_activity: float = 1.0
    fluoride_half_activity: float = 1.0
    pseudo_first_order: bool = False

    def __post_init__(self) -> None:
        for name in (
            "total_hf_order",
            "hf2_order",
            "fluoride_order",
            "protonated_site_order",
        ):
            _finite_nonnegative(name, getattr(self, name))
        for name in ("hf2_half_activity", "fluoride_half_activity"):
            _finite_positive(name, getattr(self, name))
        has_activity_order = any(
            getattr(self, name) > 0.0
            for name in (
                "total_hf_order",
                "hf2_order",
                "fluoride_order",
                "protonated_site_order",
            )
        )
        if not has_activity_order and not self.pseudo_first_order:
            raise ValueError(
                "species activity requires a nonzero order or an explicit "
                "pseudo_first_order=True declaration"
            )

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class MaterialIntermediateKinetics:
    """Opt-in state-resolved chemistry for one exact ``GraphSite.material``.

    Hydrolysis and fluorination create persistent chemical intermediates; they
    do not remove a mesoscopic matrix site.  Removal from each intermediate is
    a separate event with its own absolute-rate anchor and activity driver.
    """

    material: str
    hydrolysis: ArrheniusRateSpec | None = None
    direct_fluorination: ArrheniusRateSpec | None = None
    silanol_fluorination: ArrheniusRateSpec | None = None
    hydrolyzed_removal: ArrheniusRateSpec | None = None
    fluorinated_removal: ArrheniusRateSpec | None = None
    hydrolysis_activity: SpeciesActivitySpec | None = None
    direct_fluorination_activity: SpeciesActivitySpec | None = None
    silanol_fluorination_activity: SpeciesActivitySpec | None = None
    hydrolyzed_removal_activity: SpeciesActivitySpec | None = None
    fluorinated_removal_activity: SpeciesActivitySpec | None = None

    def __post_init__(self) -> None:
        material = str(self.material).strip()
        if not material:
            raise ValueError("material must be a non-empty exact label")
        object.__setattr__(self, "material", material)
        for name in (
            "hydrolysis",
            "direct_fluorination",
            "silanol_fluorination",
            "hydrolyzed_removal",
            "fluorinated_removal",
        ):
            value = getattr(self, name)
            if value is not None and not isinstance(value, ArrheniusRateSpec):
                raise TypeError(f"{name} must be ArrheniusRateSpec or None")
        for name in (
            "hydrolysis",
            "direct_fluorination",
            "silanol_fluorination",
            "hydrolyzed_removal",
            "fluorinated_removal",
        ):
            activity_name = f"{name}_activity"
            rate = getattr(self, name)
            activity = getattr(self, activity_name)
            if (
                name != "hydrolysis"
                and rate is not None
                and activity is None
            ):
                raise ValueError(
                    f"{activity_name} is required when {name} is enabled"
                )
            if activity is not None and not isinstance(
                activity, SpeciesActivitySpec
            ):
                raise TypeError(
                    f"{activity_name} must be SpeciesActivitySpec or None"
                )

    def to_dict(self) -> dict[str, object]:
        rates = {}
        for name in (
            "hydrolysis",
            "direct_fluorination",
            "silanol_fluorination",
            "hydrolyzed_removal",
            "fluorinated_removal",
        ):
            value = getattr(self, name)
            rates[name] = None if value is None else value.to_dict()
        activities = {}
        for name in (
            "hydrolysis_activity",
            "direct_fluorination_activity",
            "silanol_fluorination_activity",
            "hydrolyzed_removal_activity",
            "fluorinated_removal_activity",
        ):
            value = getattr(self, name)
            activities[name] = (
                None if value is None else value.to_dict()
            )
        return {
            "material": self.material,
            **rates,
            **activities,
        }


@dataclass(frozen=True)
class IntermediateStateKMCParameters:
    """Explicit opt-in container for material-resolved intermediate events."""

    enabled: bool = False
    materials: tuple[MaterialIntermediateKinetics, ...] = field(
        default_factory=tuple
    )
    water_activity: float = 1.0
    hf2_activity: float = 0.0
    fluoride_activity: float = 0.0
    protonated_site_fraction: float = 0.0

    def __post_init__(self) -> None:
        materials = tuple(self.materials)
        for item in materials:
            if not isinstance(item, MaterialIntermediateKinetics):
                raise TypeError(
                    "materials must contain MaterialIntermediateKinetics"
                )
        labels = [item.material for item in materials]
        if len(labels) != len(set(labels)):
            raise ValueError("intermediate material labels must be unique")
        if self.enabled and not materials:
            raise ValueError(
                "enabled intermediate chemistry requires a material definition"
            )
        _finite_nonnegative("water_activity", self.water_activity)
        _finite_nonnegative("hf2_activity", self.hf2_activity)
        _finite_nonnegative("fluoride_activity", self.fluoride_activity)
        if (
            not math.isfinite(float(self.protonated_site_fraction))
            or not 0.0 <= float(self.protonated_site_fraction) <= 1.0
        ):
            raise ValueError(
                "protonated_site_fraction must be finite and within [0, 1]"
            )
        object.__setattr__(self, "materials", materials)

    def material_map(self) -> dict[str, MaterialIntermediateKinetics]:
        return {item.material: item for item in self.materials}

    def to_dict(self) -> dict[str, object]:
        return {
            "enabled": self.enabled,
            "water_activity": self.water_activity,
            "unresolved_species_activity_defaults": {
                "hf2_activity": self.hf2_activity,
                "fluoride_activity": self.fluoride_activity,
                "protonated_site_fraction": (
                    self.protonated_site_fraction
                ),
            },
            "mapping_policy": "explicit_manual_only",
            "automatic_screening_result_mapping": False,
            "materials": {
                item.material: item.to_dict() for item in self.materials
            },
        }


@dataclass(frozen=True)
class SecondWetKMCParameters:
    """Monotonic graph-KMC rates for a fixed-duration second-WET stage.

    ``common_rate_multiplier`` scales both matrix removal and collector-deposit
    dissolution.  Matrix removal additionally retains the static material-rate
    factor stored on each matrix site; activation, passivation, precipitation
    and reattachment are deliberately absent from this stage.
    """

    duration_s: float = 30.0
    common_rate_multiplier: float = 1.0
    matrix_removal_rate_s: float = 1.0
    deposit_dissolution_rate_s: float = 0.025

    def __post_init__(self) -> None:
        for name in (
            "duration_s",
            "common_rate_multiplier",
            "matrix_removal_rate_s",
            "deposit_dissolution_rate_s",
        ):
            _finite_nonnegative(name, getattr(self, name))


@dataclass(frozen=True)
class TrenchGraphLayout:
    """Immutable mapping between continuum cells and fixed KMC sites."""

    grid: CartesianGrid2D
    matrix_site_ids: tuple[int, ...]
    collector_site_ids: tuple[int, ...]
    site_by_cell: Mapping[tuple[int, int], int]
    cell_by_site: Mapping[int, tuple[int, int]]
    exposure_neighbours: Mapping[int, tuple[int, ...]]
    collector_by_support: Mapping[int, int]
    support_by_collector: Mapping[int, int]
    collector_neighbours: Mapping[int, tuple[int, ...]]

    @property
    def site_count(self) -> int:
        return len(self.matrix_site_ids) + len(self.collector_site_ids)

    @property
    def matrix_site_count(self) -> int:
        return len(self.matrix_site_ids)

    @property
    def collector_site_count(self) -> int:
        return len(self.collector_site_ids)


@dataclass(frozen=True)
class ContinuumKMCFrame:
    """One synchronized continuum field snapshot sampled by KMC."""

    time_s: float
    solid_mask: np.ndarray
    liquid_mask: np.ndarray
    gas_mask: np.ndarray
    interface_mask: np.ndarray
    hf_field: np.ndarray
    product_field: np.ndarray
    hf_at_solid: np.ndarray
    product_at_solid: np.ndarray
    interface_temperature_K: np.ndarray
    wet_face_length_nm: np.ndarray
    wet_face_count: np.ndarray
    hf_converged: bool
    product_converged: bool
    hf_relative_residual: float
    product_relative_residual: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.time_s) or self.time_s < 0.0:
            raise ValueError("frame time_s must be finite and non-negative")
        shape = np.asarray(self.solid_mask).shape
        if len(shape) != 2:
            raise ValueError("frame arrays must be two-dimensional")
        for name in (
            "liquid_mask",
            "gas_mask",
            "interface_mask",
            "hf_field",
            "product_field",
            "hf_at_solid",
            "product_at_solid",
            "interface_temperature_K",
            "wet_face_length_nm",
            "wet_face_count",
        ):
            value = np.asarray(getattr(self, name))
            if value.shape != shape:
                raise ValueError(f"{name} must match the frame shape")
            if value.dtype != bool and np.any(~np.isfinite(value)):
                raise ValueError(f"{name} must be finite")
        if np.any(np.asarray(self.solid_mask) & np.asarray(self.liquid_mask)):
            raise ValueError("solid and liquid masks must be disjoint")


@dataclass(frozen=True)
class TrenchKMCOutcome:
    """Serializable coupled-run result plus final field for plotting."""

    graph: AmorphousGraph
    layout: TrenchGraphLayout
    final_frame: ContinuumKMCFrame
    sync_history: tuple[Mapping[str, object], ...]
    event_log: tuple[EventRecord, ...]
    event_locations: tuple[Mapping[str, object], ...]
    stop_reason: str
    total_time_s: float
    seed: int
    target_remaining_fraction: float | None = None
    target_crossing_before_fraction: float | None = None
    target_crossing_after_fraction: float | None = None

    def summary(self) -> dict[str, object]:
        metrics = trench_residue_metrics(self.graph, self.layout)
        result = {
            "stop_reason": self.stop_reason,
            "time_s": self.total_time_s,
            "seed": self.seed,
            "event_count": len(self.event_log),
            "event_counts": dict(Counter(item.event_name for item in self.event_log)),
            **metrics,
        }
        if self.target_remaining_fraction is not None:
            result.update(
                {
                    "target_remaining_fraction": self.target_remaining_fraction,
                    "target_reached": (
                        self.stop_reason == "remaining_fraction_target"
                    ),
                    "target_crossing_before_fraction": (
                        self.target_crossing_before_fraction
                    ),
                    "target_crossing_after_fraction": (
                        self.target_crossing_after_fraction
                    ),
                }
            )
        return result


@dataclass(frozen=True)
class SecondWetKMCOutcome:
    """Result of continuing an existing trench graph through second-WET.

    Event times are relative to the beginning of the second-WET stage.
    ``time_s`` always reaches the requested fixed duration, including when no
    propensity remains.  ``total_time_s`` adds an inherited primary-stage time
    when the source was :class:`TrenchKMCOutcome`.
    """

    graph: AmorphousGraph
    layout: TrenchGraphLayout
    event_log: tuple[EventRecord, ...]
    stop_reason: str
    time_s: float
    duration_s: float
    source_time_s: float
    seed: int
    parameters: SecondWetKMCParameters
    before_metrics: Mapping[str, object]
    after_metrics: Mapping[str, object]

    @property
    def event_count(self) -> int:
        return len(self.event_log)

    @property
    def total_time_s(self) -> float:
        return self.source_time_s + self.time_s

    def summary(self) -> dict[str, object]:
        before_removed = int(
            dict(self.before_metrics.get("state_counts", {})).get("removed", 0)
        )
        after_removed = int(
            dict(self.after_metrics.get("state_counts", {})).get("removed", 0)
        )
        before_deposit = int(self.before_metrics.get("deposit_count", 0))
        after_deposit = int(self.after_metrics.get("deposit_count", 0))
        return {
            "stop_reason": self.stop_reason,
            "time_s": self.time_s,
            "duration_s": self.duration_s,
            "source_time_s": self.source_time_s,
            "total_time_s": self.total_time_s,
            "seed": self.seed,
            "event_count": self.event_count,
            "event_counts": dict(
                Counter(record.event_name for record in self.event_log)
            ),
            "matrix_removed_count": after_removed - before_removed,
            "deposit_dissolved_count": before_deposit - after_deposit,
            "before_metrics": dict(self.before_metrics),
            "after_metrics": dict(self.after_metrics),
        }


_DIRECTIONS = ((-1, 0), (1, 0), (0, -1), (0, 1))


def _boundary_flags(
    cavity: np.ndarray, row: int, col: int
) -> tuple[bool, bool]:
    n_rows, n_cols = cavity.shape
    left_out = col == 0 or not cavity[row, col - 1]
    right_out = col + 1 == n_cols or not cavity[row, col + 1]
    sidewall = bool(left_out or right_out)
    below_out = row + 1 == n_rows or not cavity[row + 1, col]
    any_below_cavity = bool(np.any(cavity[row + 1 :, col])) if row + 1 < n_rows else False
    floor = bool(below_out and not any_below_cavity)
    return sidewall, floor


def build_trench_graph(
    grid: CartesianGrid2D,
    config: TrenchGraphConfig = TrenchGraphConfig(),
    *,
    spatial_etchability_parameters: SpatialEtchabilityParameters | None = None,
) -> tuple[AmorphousGraph, TrenchGraphLayout]:
    """Build all matrix layers and persistent sidewall/floor collectors.

    Static depth/sidewall/floor film quality is evaluated once on the
    continuum grid and stored on every matrix site.  The default canonical
    parameters produce an exactly unit ``material_rate_factor``.
    """

    cavity = np.asarray(grid.cavity_mask, dtype=bool)
    spatial_etchability = SpatialEtchabilityField.build(
        grid,
        spatial_etchability_parameters,
    )
    cells = list(zip(*np.nonzero(cavity), strict=True))
    sites: list[GraphSite] = []
    site_by_cell: dict[tuple[int, int], int] = {}
    cell_by_site: dict[int, tuple[int, int]] = {}
    exposure_neighbours: dict[int, tuple[int, ...]] = {}
    boundary_by_site: dict[int, tuple[bool, bool]] = {}

    for site_id, (row_raw, col_raw) in enumerate(cells):
        row, col = int(row_raw), int(col_raw)
        site_by_cell[(row, col)] = site_id
        cell_by_site[site_id] = (row, col)
        sidewall, floor = _boundary_flags(cavity, row, col)
        boundary_by_site[site_id] = (sidewall, floor)
        depth = float(grid.depth_nm[row])
        top_flag = depth <= config.top_region_depth_nm
        bottom_flag = (
            grid.geometry.depth_nm - depth <= config.bottom_region_depth_nm
        )
        local_half_width = 0.5 * float(
            grid.geometry.width_at_depth_nm(
                min(max(depth, 0.0), grid.geometry.depth_nm)
            )
        )
        wall_distance = max(local_half_width - abs(float(grid.lateral_nm[col])), 0.0)
        wall_zone = sidewall or wall_distance <= config.sidewall_region_width_nm
        if bottom_flag:
            region_code = REGION_BOTTOM
        elif wall_zone:
            region_code = REGION_SIDEWALL
        elif top_flag:
            region_code = REGION_TOP
        else:
            region_code = REGION_CORE
        top_exposed = False
        if row > 0:
            top_exposed = bool(grid.reservoir_mask[row - 1, col])
        sites.append(
            GraphSite(
                site_id=site_id,
                state="intact" if top_exposed else "buried",
                material=config.material,
                attributes={
                    "matrix_flag": 1.0,
                    "collector_flag": 0.0,
                    "row": float(row),
                    "column": float(col),
                    "x_nm": float(grid.lateral_nm[col]),
                    "depth_nm": depth,
                    "top_flag": float(top_flag),
                    "sidewall_flag": float(wall_zone),
                    "bottom_flag": float(bottom_flag),
                    "boundary_sidewall_flag": float(sidewall),
                    "boundary_floor_flag": float(floor),
                    "region_code": float(region_code),
                    "depth_material_rate_factor": float(
                        spatial_etchability.depth_factor[row, col]
                    ),
                    "sidewall_material_rate_factor": float(
                        spatial_etchability.sidewall_factor[row, col]
                    ),
                    "floor_material_rate_factor": float(
                        spatial_etchability.floor_factor[row, col]
                    ),
                    "material_rate_factor": float(
                        spatial_etchability.combined_factor[row, col]
                    ),
                    "hf_activity": 0.0,
                    "product_activity": 0.0,
                    "temperature_K": 298.15,
                    "wet_exposed": float(top_exposed),
                    "wet_face_count": float(top_exposed),
                    "support_site_id": -1.0,
                },
            )
        )

    matrix_edges: set[tuple[int, int]] = set()
    for (row, col), site_id in site_by_cell.items():
        neighbours: list[int] = []
        for drow, dcol in _DIRECTIONS:
            other = site_by_cell.get((row + drow, col + dcol))
            if other is not None:
                neighbours.append(other)
                matrix_edges.add(tuple(sorted((site_id, other))))
        exposure_neighbours[site_id] = tuple(sorted(neighbours))

    collector_by_support: dict[int, int] = {}
    support_by_collector: dict[int, int] = {}
    next_site_id = len(sites)
    for support_id in range(len(cells)):
        sidewall, floor = boundary_by_site[support_id]
        if not (sidewall or floor):
            continue
        row, col = cell_by_site[support_id]
        support = sites[support_id]
        collector_id = next_site_id
        next_site_id += 1
        collector_by_support[support_id] = collector_id
        support_by_collector[collector_id] = support_id
        sites.append(
            GraphSite(
                site_id=collector_id,
                state="collector",
                material="surface_product",
                attributes={
                    "matrix_flag": 0.0,
                    "collector_flag": 1.0,
                    "row": float(row),
                    "column": float(col),
                    "x_nm": support.attributes["x_nm"],
                    "depth_nm": support.attributes["depth_nm"],
                    "top_flag": support.attributes["top_flag"],
                    "sidewall_flag": float(sidewall),
                    "bottom_flag": float(floor),
                    "boundary_sidewall_flag": float(sidewall),
                    "boundary_floor_flag": float(floor),
                    "region_code": float(
                        REGION_BOTTOM if floor else REGION_SIDEWALL
                    ),
                    "hf_activity": 0.0,
                    "product_activity": 0.0,
                    "temperature_K": 298.15,
                    "wet_exposed": 0.0,
                    "wet_face_count": 0.0,
                    "support_site_id": float(support_id),
                },
            )
        )

    collector_neighbours: dict[int, tuple[int, ...]] = {}
    collector_edges: set[tuple[int, int]] = set()
    collectors_by_cell = {
        cell_by_site[support]: collector
        for support, collector in collector_by_support.items()
    }
    for support_id, collector_id in collector_by_support.items():
        row, col = cell_by_site[support_id]
        neighbours: set[int] = set()
        for drow in (-1, 0, 1):
            for dcol in (-1, 0, 1):
                if drow == 0 and dcol == 0:
                    continue
                other = collectors_by_cell.get((row + drow, col + dcol))
                if other is not None:
                    neighbours.add(other)
                    collector_edges.add(tuple(sorted((collector_id, other))))
        collector_neighbours[collector_id] = tuple(sorted(neighbours))

    support_edges = {
        tuple(sorted((support, collector)))
        for support, collector in collector_by_support.items()
    }
    if len(sites) > config.maximum_sites:
        raise ValueError(
            f"trench graph requires {len(sites)} sites, exceeding "
            f"maximum_sites={config.maximum_sites}"
        )
    graph = AmorphousGraph(
        sites,
        sorted(matrix_edges | support_edges | collector_edges),
    )
    layout = TrenchGraphLayout(
        grid=grid,
        matrix_site_ids=tuple(range(len(cells))),
        collector_site_ids=tuple(range(len(cells), len(sites))),
        site_by_cell=dict(site_by_cell),
        cell_by_site=dict(cell_by_site),
        exposure_neighbours=dict(exposure_neighbours),
        collector_by_support=dict(collector_by_support),
        support_by_collector=dict(support_by_collector),
        collector_neighbours=dict(collector_neighbours),
    )
    return graph, layout


def _face_weighted_average_on_solid(
    grid: CartesianGrid2D,
    field: np.ndarray,
    liquid: np.ndarray,
    solid: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Map adjacent liquid values to solid using physical face lengths."""

    values = np.asarray(field, dtype=float)
    total = np.zeros(grid.shape, dtype=float)
    weight = np.zeros(grid.shape, dtype=float)
    count = np.zeros(grid.shape, dtype=np.int16)
    faces = (
        (slice(1, None), slice(None), slice(None, -1), slice(None), grid.dx_nm),
        (slice(None, -1), slice(None), slice(1, None), slice(None), grid.dx_nm),
        (slice(None), slice(1, None), slice(None), slice(None, -1), grid.dz_nm),
        (slice(None), slice(None, -1), slice(None), slice(1, None), grid.dz_nm),
    )
    for sr, sc, lr, lc, face_length in faces:
        valid = solid[sr, sc] & liquid[lr, lc]
        destination_total = total[sr, sc]
        destination_weight = weight[sr, sc]
        destination_count = count[sr, sc]
        source = values[lr, lc]
        destination_total[valid] += source[valid] * face_length
        destination_weight[valid] += face_length
        destination_count[valid] += 1
    average = np.zeros(grid.shape, dtype=float)
    np.divide(total, weight, out=average, where=weight > 0.0)
    return average, count


def solid_mask_from_graph(
    graph: AmorphousGraph, layout: TrenchGraphLayout
) -> np.ndarray:
    """Reconstruct the GAP-FILL mask; deposits remain boundary particles."""

    result = np.zeros(layout.grid.shape, dtype=bool)
    for site_id in layout.matrix_site_ids:
        if graph.sites[site_id].state != "removed":
            result[layout.cell_by_site[site_id]] = True
    return result


def solve_continuum_frame(
    graph: AmorphousGraph,
    layout: TrenchGraphLayout,
    parameters: ContinuumCouplingParameters,
    *,
    time_s: float,
    liquid_mask_override: np.ndarray | None = None,
    gas_mask_override: np.ndarray | None = None,
) -> ContinuumKMCFrame:
    """Solve field-only continuum transport for the current KMC morphology."""

    grid = layout.grid
    solid = solid_mask_from_graph(graph, layout)
    open_domain = np.asarray(grid.reservoir_mask | (grid.cavity_mask & ~solid))
    if liquid_mask_override is None:
        if gas_mask_override is not None:
            raise ValueError("gas_mask_override requires liquid_mask_override")
        liquid = connected_to_top(open_domain)
        gas = open_domain & ~liquid
    else:
        liquid = np.asarray(liquid_mask_override, dtype=bool)
        if liquid.shape != grid.shape:
            raise ValueError("liquid_mask_override must match the grid")
        if gas_mask_override is None:
            gas = open_domain & ~liquid
        else:
            gas = np.asarray(gas_mask_override, dtype=bool)
            if gas.shape != grid.shape:
                raise ValueError("gas_mask_override must match the grid")
        if np.any((liquid | gas) & ~open_domain):
            raise ValueError("wetting masks must remain inside the open domain")
        if np.any(liquid & gas):
            raise ValueError("liquid and gas masks must be disjoint")
        if np.any(open_domain & ~(liquid | gas)):
            raise ValueError("liquid/gas masks must partition the open domain")
        if not np.array_equal(liquid, connected_to_top(liquid)):
            raise ValueError("liquid override must remain top-connected")
    wet_face_length = interface_face_length_on_solid(grid, liquid, solid)
    interface = solid & (wet_face_length > 0.0)

    hf_result = solve_quasi_steady_diffusion(
        grid,
        liquid,
        solid,
        diffusivity_nm2_s=parameters.hf_diffusivity_nm2_s,
        top_boundary=TopBoundaryCondition(parameters.hf_bulk_concentration),
        interface_sink_velocity_nm_s=parameters.hf_interface_sink_velocity_nm_s,
        relative_tolerance=parameters.relative_tolerance,
        absolute_tolerance=parameters.absolute_tolerance,
        max_iterations=parameters.maximum_iterations,
    )
    product_result = solve_quasi_steady_diffusion(
        grid,
        liquid,
        solid,
        diffusivity_nm2_s=parameters.product_diffusivity_nm2_s,
        top_boundary=TopBoundaryCondition(0.0),
        interface_source_flux=(
            parameters.product_interface_source_flux * interface.astype(float)
        ),
        bulk_decay_per_s=parameters.product_bulk_decay_per_s,
        relative_tolerance=parameters.relative_tolerance,
        absolute_tolerance=parameters.absolute_tolerance,
        max_iterations=parameters.maximum_iterations,
    )
    hf_at_solid, wet_face_count = _face_weighted_average_on_solid(
        grid, hf_result.field, liquid, solid
    )
    product_at_solid, product_face_count = _face_weighted_average_on_solid(
        grid, product_result.field, liquid, solid
    )
    if not np.array_equal(wet_face_count, product_face_count):
        raise RuntimeError("reactant and product interface mappings disagree")

    thermal_model = ThermalResistanceModel(grid.geometry)
    temperatures = np.empty(grid.shape, dtype=float)
    bc = parameters.thermal_boundary_conditions
    for row, depth_nm in enumerate(grid.depth_nm):
        clipped_depth_nm = min(max(float(depth_nm), 0.0), grid.geometry.depth_nm)
        temperatures[row, :] = thermal_model.interface_temperature_K(
            clipped_depth_nm * NM_TO_M,
            bc,
            reaction_heat_flux_W_m2=parameters.reaction_heat_flux_W_m2,
        )

    return ContinuumKMCFrame(
        time_s=float(time_s),
        solid_mask=solid,
        liquid_mask=liquid,
        gas_mask=gas,
        interface_mask=interface,
        hf_field=hf_result.field,
        product_field=product_result.field,
        hf_at_solid=hf_at_solid,
        product_at_solid=product_at_solid,
        interface_temperature_K=temperatures,
        wet_face_length_nm=wet_face_length,
        wet_face_count=wet_face_count,
        hf_converged=hf_result.converged,
        product_converged=product_result.converged,
        hf_relative_residual=hf_result.relative_residual,
        product_relative_residual=product_result.relative_residual,
    )


def apply_continuum_frame(
    kmc: GraphKMC,
    layout: TrenchGraphLayout,
    frame: ContinuumKMCFrame,
    parameters: ContinuumCouplingParameters,
) -> None:
    """Pass local HF, product, temperature and wet exposure to every site."""

    affected: list[int] = []
    for site_id in layout.matrix_site_ids:
        site = kmc.graph.sites[site_id]
        row, col = layout.cell_by_site[site_id]
        interface = bool(frame.interface_mask[row, col])
        if interface and site.state == "buried":
            site.state = "intact"
        site.attributes["wet_exposed"] = float(
            interface and site.state != "removed"
        )
        site.attributes["wet_face_count"] = float(frame.wet_face_count[row, col])
        site.attributes["hf_activity"] = (
            float(frame.hf_at_solid[row, col])
            / parameters.hf_reference_concentration
        )
        site.attributes["product_activity"] = (
            float(frame.product_at_solid[row, col])
            / parameters.product_reference_concentration
        )
        site.attributes["temperature_K"] = float(
            frame.interface_temperature_K[row, col]
        )
        affected.append(site_id)

    for collector_id in layout.collector_site_ids:
        site = kmc.graph.sites[collector_id]
        support_id = layout.support_by_collector[collector_id]
        row, col = layout.cell_by_site[support_id]
        support_removed = kmc.graph.sites[support_id].state == "removed"
        exposed = support_removed and bool(frame.liquid_mask[row, col])
        site.attributes["wet_exposed"] = float(exposed)
        site.attributes["wet_face_count"] = float(exposed)
        site.attributes["hf_activity"] = (
            float(frame.hf_field[row, col]) / parameters.hf_reference_concentration
            if exposed
            else 0.0
        )
        site.attributes["product_activity"] = (
            float(frame.product_field[row, col])
            / parameters.product_reference_concentration
            if exposed
            else 0.0
        )
        site.attributes["temperature_K"] = float(
            frame.interface_temperature_K[row, col]
        )
        affected.append(collector_id)
    kmc.refresh_sites(affected, expand=True)


_BOLTZMANN_EV_K = 8.617333262145e-5


def _arrhenius_factor(energy_eV: float, temperature_K: float, reference_K: float) -> float:
    if energy_eV == 0.0:
        return 1.0
    exponent = -energy_eV / _BOLTZMANN_EV_K * (
        1.0 / temperature_K - 1.0 / reference_K
    )
    return math.exp(min(max(exponent, -50.0), 50.0))


def _region_factor(context: EventContext, p: TrenchKMCParameters) -> float:
    code = int(round(context.site.attributes["region_code"]))
    return {
        REGION_TOP: p.top_rate_factor,
        REGION_SIDEWALL: p.sidewall_rate_factor,
        REGION_BOTTOM: p.bottom_rate_factor,
        REGION_CORE: p.core_rate_factor,
    }.get(code, 1.0)


def _matrix_neighbours(context: EventContext) -> list[GraphSite]:
    return [site for site in context.neighbours if site.attributes["matrix_flag"] > 0.5]


def _collector_neighbours(context: EventContext) -> list[GraphSite]:
    return [site for site in context.neighbours if site.attributes["collector_flag"] > 0.5]


def _remove_matrix_site(
    context: EventContext,
    layout: TrenchGraphLayout,
    *,
    newly_exposed_are_wet: bool,
) -> tuple[int, ...]:
    """Remove one matrix site and expose only its actual graph neighbours."""

    site = context.site
    site.state = "removed"
    site.attributes["wet_exposed"] = 0.0
    site.attributes["wet_face_count"] = 0.0
    changed = {context.site_id}
    for other_id in layout.exposure_neighbours[context.site_id]:
        other = context.graph.sites[other_id]
        if other.state == "buried":
            other.state = "intact"
            other.attributes["wet_exposed"] = float(newly_exposed_are_wet)
            other.attributes["wet_face_count"] = float(newly_exposed_are_wet)
            if newly_exposed_are_wet:
                for key in ("hf_activity", "product_activity", "temperature_K"):
                    other.attributes[key] = site.attributes[key]
            else:
                other.attributes["hf_activity"] = 0.0
                other.attributes["product_activity"] = 0.0
            changed.add(other_id)
    collector_id = layout.collector_by_support.get(context.site_id)
    if collector_id is not None:
        collector = context.graph.sites[collector_id]
        collector.attributes["wet_exposed"] = float(newly_exposed_are_wet)
        collector.attributes["wet_face_count"] = float(newly_exposed_are_wet)
        if newly_exposed_are_wet:
            for key in ("hf_activity", "product_activity", "temperature_K"):
                collector.attributes[key] = site.attributes[key]
        else:
            collector.attributes["hf_activity"] = 0.0
            collector.attributes["product_activity"] = 0.0
        changed.add(collector_id)
    return tuple(sorted(changed))


def build_trench_kmc(
    graph: AmorphousGraph,
    layout: TrenchGraphLayout,
    parameters: TrenchKMCParameters = TrenchKMCParameters(),
    *,
    intermediate_parameters: IntermediateStateKMCParameters | None = None,
    seed: int = 0,
    newly_exposed_are_wet: bool = True,
) -> GraphKMC:
    """Attach neighbour-, cluster- and deposition-dependent KMC events.

    The default ``intermediate_parameters=None`` constructs exactly the legacy
    seven-event model.  Material-specific hydrolysis/fluorination states are
    added only when an explicitly enabled configuration is supplied.
    """

    intermediate = (
        IntermediateStateKMCParameters()
        if intermediate_parameters is None
        else intermediate_parameters
    )
    if not isinstance(intermediate, IntermediateStateKMCParameters):
        raise TypeError(
            "intermediate_parameters must be IntermediateStateKMCParameters"
        )
    intermediate_by_material = intermediate.material_map()

    def wet_matrix(context: EventContext) -> bool:
        return (
            context.site.attributes["matrix_flag"] > 0.5
            and context.site.attributes["wet_exposed"] > 0.5
        )

    def hf_saturation(context: EventContext) -> float:
        activity = max(context.site.attributes["hf_activity"], 0.0)
        return activity / (parameters.hf_half_activity + activity)

    def product_saturation(context: EventContext) -> float:
        activity = max(context.site.attributes["product_activity"], 0.0)
        return activity / (parameters.product_half_activity + activity)

    def passivated_neighbours(context: EventContext) -> int:
        return sum(site.state == "passivated" for site in _matrix_neighbours(context))

    def removed_neighbours(context: EventContext) -> int:
        return sum(site.state == "removed" for site in _matrix_neighbours(context))

    def activation_rate(context: EventContext) -> float:
        temperature = context.site.attributes["temperature_K"]
        exposed_faces = max(context.site.attributes["wet_face_count"], 1.0)
        return (
            parameters.activation_rate_s
            * hf_saturation(context)
            * _arrhenius_factor(
                parameters.activation_energy_eV,
                temperature,
                parameters.reference_temperature_K,
            )
            * _region_factor(context, parameters)
            * (1.0 + 0.12 * (exposed_faces - 1.0))
        )

    def passivation_rate(context: EventContext) -> float:
        return (
            parameters.passivation_rate_s
            * product_saturation(context)
            * (1.0 + parameters.passivation_cluster_boost * passivated_neighbours(context))
        )

    def depassivation_rate(context: EventContext) -> float:
        temperature = context.site.attributes["temperature_K"]
        cluster = 1.0 + parameters.cluster_stabilization * passivated_neighbours(context)
        return (
            parameters.depassivation_rate_s
            * hf_saturation(context)
            * _arrhenius_factor(
                parameters.depassivation_energy_eV,
                temperature,
                parameters.reference_temperature_K,
            )
            / cluster
        )

    def removal_rate(context: EventContext) -> float:
        temperature = context.site.attributes["temperature_K"]
        product = max(context.site.attributes["product_activity"], 0.0)
        neighbour_factor = 1.0 + parameters.removed_neighbour_boost * removed_neighbours(context)
        inhibition = 1.0 / (1.0 + parameters.product_inhibition_strength * product)
        material_rate_factor = context.site.attributes.get(
            "material_rate_factor", 1.0
        )
        return (
            parameters.removal_rate_s
            * hf_saturation(context)
            * inhibition
            * neighbour_factor
            * _arrhenius_factor(
                parameters.removal_energy_eV,
                temperature,
                parameters.reference_temperature_K,
            )
            * _region_factor(context, parameters)
            * material_rate_factor
        )

    def intermediate_kinetics(
        context: EventContext,
    ) -> MaterialIntermediateKinetics | None:
        return intermediate_by_material.get(context.site.material)

    def intermediate_enabled(
        context: EventContext,
        rate_name: str,
    ) -> bool:
        material = intermediate_kinetics(context)
        return (
            intermediate.enabled
            and wet_matrix(context)
            and material is not None
            and getattr(material, rate_name) is not None
        )

    def water_activity(context: EventContext) -> float:
        return max(
            float(
                context.site.attributes.get(
                    "water_activity", intermediate.water_activity
                )
            ),
            0.0,
        )

    def species_activity_factor(
        context: EventContext,
        activity: SpeciesActivitySpec,
    ) -> float:
        hf2 = max(
            float(
                context.site.attributes.get(
                    "hf2_activity", intermediate.hf2_activity
                )
            ),
            0.0,
        )
        fluoride = max(
            float(
                context.site.attributes.get(
                    "fluoride_activity", intermediate.fluoride_activity
                )
            ),
            0.0,
        )
        protonated = min(
            max(
                float(
                    context.site.attributes.get(
                        "protonated_site_fraction",
                        intermediate.protonated_site_fraction,
                    )
                ),
                0.0,
            ),
            1.0,
        )
        result = 1.0
        if activity.total_hf_order > 0.0:
            result *= hf_saturation(context) ** activity.total_hf_order
        if activity.hf2_order > 0.0:
            result *= (
                hf2 / (activity.hf2_half_activity + hf2)
            ) ** activity.hf2_order
        if activity.fluoride_order > 0.0:
            result *= (
                fluoride
                / (activity.fluoride_half_activity + fluoride)
            ) ** activity.fluoride_order
        if activity.protonated_site_order > 0.0:
            result *= protonated ** activity.protonated_site_order
        return result

    def intermediate_rate(
        context: EventContext,
        rate_name: str,
        *,
        water_driven: bool = False,
        removal: bool = False,
    ) -> float:
        material = intermediate_kinetics(context)
        if material is None:
            return 0.0
        rate_spec = getattr(material, rate_name)
        if rate_spec is None:
            return 0.0
        temperature = context.site.attributes["temperature_K"]
        rate = rate_spec.rate_at_temperature(temperature)
        if water_driven:
            rate *= water_activity(context)
        activity_spec = getattr(material, f"{rate_name}_activity")
        if activity_spec is not None:
            rate *= species_activity_factor(context, activity_spec)
        elif not water_driven:
            return 0.0
        rate *= _region_factor(context, parameters)
        if not removal:
            exposed_faces = max(
                context.site.attributes["wet_face_count"], 1.0
            )
            return rate * (1.0 + 0.12 * (exposed_faces - 1.0))
        product = max(context.site.attributes["product_activity"], 0.0)
        inhibition = 1.0 / (
            1.0 + parameters.product_inhibition_strength * product
        )
        neighbour_factor = (
            1.0
            + parameters.removed_neighbour_boost
            * removed_neighbours(context)
        )
        material_rate_factor = context.site.attributes.get(
            "material_rate_factor", 1.0
        )
        return (
            rate
            * inhibition
            * neighbour_factor
            * material_rate_factor
        )

    def remove_action(context: EventContext, _: np.random.Generator) -> Iterable[int]:
        return _remove_matrix_site(
            context,
            layout,
            newly_exposed_are_wet=newly_exposed_are_wet,
        )

    def wet_collector(context: EventContext) -> bool:
        return (
            context.site.attributes["collector_flag"] > 0.5
            and context.site.attributes["wet_exposed"] > 0.5
        )

    def deposit_neighbours(context: EventContext) -> int:
        return sum(site.state == "deposit" for site in _collector_neighbours(context))

    def precipitation_rate(context: EventContext) -> float:
        return (
            parameters.precipitation_rate_s
            * product_saturation(context)
            * (1.0 + parameters.deposit_cluster_boost * deposit_neighbours(context))
        )

    def deposit_dissolution_rate(context: EventContext) -> float:
        return parameters.deposit_dissolution_rate_s * hf_saturation(context)

    def reattachment_enabled(context: EventContext) -> bool:
        if not wet_collector(context):
            return False
        return any(
            site.state == "collector" and site.attributes["wet_exposed"] > 0.5
            for site in _collector_neighbours(context)
        )

    def reattachment_rate(context: EventContext) -> float:
        targets = [
            site
            for site in _collector_neighbours(context)
            if site.state == "collector" and site.attributes["wet_exposed"] > 0.5
        ]
        if not targets:
            return 0.0
        bottom_preference = max(site.attributes["bottom_flag"] for site in targets)
        return parameters.reattachment_rate_s * (
            1.0 + parameters.reattachment_bottom_bias * bottom_preference
        )

    def reattachment_action(
        context: EventContext, rng: np.random.Generator
    ) -> Iterable[int]:
        candidates = [
            site
            for site in _collector_neighbours(context)
            if site.state == "collector" and site.attributes["wet_exposed"] > 0.5
        ]
        if not candidates:
            return (context.site_id,)
        weights = np.asarray(
            [
                1.0
                + parameters.reattachment_bottom_bias * site.attributes["bottom_flag"]
                + parameters.deposit_cluster_boost
                * sum(
                    context.graph.sites[other].state == "deposit"
                    for other in context.graph.neighbors(site.site_id)
                )
                for site in candidates
            ],
            dtype=float,
        )
        target = candidates[int(rng.choice(len(candidates), p=weights / weights.sum()))]
        context.site.state = "collector"
        target.state = "deposit"
        return (context.site_id, target.site_id)

    templates: list[EventTemplate] = [
        EventTemplate(
            "activate",
            "intact",
            "activated",
            activation_rate,
            enabled=wet_matrix,
            dependency_radius=1,
        ),
        EventTemplate(
            "passivate",
            "activated",
            "passivated",
            passivation_rate,
            enabled=wet_matrix,
            dependency_radius=1,
        ),
        EventTemplate(
            "depassivate",
            "passivated",
            "activated",
            depassivation_rate,
            enabled=wet_matrix,
            dependency_radius=1,
        ),
        EventTemplate(
            "remove",
            "activated",
            None,
            removal_rate,
            enabled=wet_matrix,
            action=remove_action,
            dependency_radius=1,
        ),
    ]
    if intermediate.enabled:
        if any(item.hydrolysis is not None for item in intermediate.materials):
            templates.append(
                EventTemplate(
                    "hydrolyze",
                    "intact",
                    "hydrolyzed_silanol",
                    lambda context: intermediate_rate(
                        context,
                        "hydrolysis",
                        water_driven=True,
                    ),
                    enabled=lambda context: intermediate_enabled(
                        context, "hydrolysis"
                    ),
                    dependency_radius=1,
                )
            )
        if any(
            item.direct_fluorination is not None
            for item in intermediate.materials
        ):
            templates.append(
                EventTemplate(
                    "fluorinate_intact",
                    "intact",
                    "fluorinated",
                    lambda context: intermediate_rate(
                        context,
                        "direct_fluorination",
                    ),
                    enabled=lambda context: intermediate_enabled(
                        context, "direct_fluorination"
                    ),
                    dependency_radius=1,
                )
            )
        if any(
            item.silanol_fluorination is not None
            for item in intermediate.materials
        ):
            templates.append(
                EventTemplate(
                    "fluorinate_silanol",
                    "hydrolyzed_silanol",
                    "fluorinated",
                    lambda context: intermediate_rate(
                        context,
                        "silanol_fluorination",
                    ),
                    enabled=lambda context: intermediate_enabled(
                        context, "silanol_fluorination"
                    ),
                    dependency_radius=1,
                )
            )
        if any(
            item.hydrolyzed_removal is not None
            for item in intermediate.materials
        ):
            templates.append(
                EventTemplate(
                    "remove_hydrolyzed",
                    "hydrolyzed_silanol",
                    None,
                    lambda context: intermediate_rate(
                        context,
                        "hydrolyzed_removal",
                        removal=True,
                    ),
                    enabled=lambda context: intermediate_enabled(
                        context, "hydrolyzed_removal"
                    ),
                    action=remove_action,
                    dependency_radius=1,
                )
            )
        if any(
            item.fluorinated_removal is not None
            for item in intermediate.materials
        ):
            templates.append(
                EventTemplate(
                    "remove_fluorinated",
                    "fluorinated",
                    None,
                    lambda context: intermediate_rate(
                        context,
                        "fluorinated_removal",
                        removal=True,
                    ),
                    enabled=lambda context: intermediate_enabled(
                        context, "fluorinated_removal"
                    ),
                    action=remove_action,
                    dependency_radius=1,
                )
            )
    templates.extend(
        [
            EventTemplate(
                "precipitate",
                "collector",
                "deposit",
                precipitation_rate,
                enabled=wet_collector,
                dependency_radius=1,
            ),
            EventTemplate(
                "dissolve_deposit",
                "deposit",
                "collector",
                deposit_dissolution_rate,
                enabled=wet_collector,
                dependency_radius=1,
            ),
            EventTemplate(
                "reattach",
                "deposit",
                None,
                reattachment_rate,
                enabled=reattachment_enabled,
                action=reattachment_action,
                dependency_radius=1,
            ),
        ]
    )
    return GraphKMC(graph, templates, seed=seed, copy_graph=True)


def _prepare_second_wet_graph(
    graph: AmorphousGraph,
    layout: TrenchGraphLayout,
) -> AmorphousGraph:
    """Copy a carried graph and re-wet its top-connected open domain."""

    prepared = graph.copy()
    solid = solid_mask_from_graph(prepared, layout)
    open_domain = np.asarray(
        layout.grid.reservoir_mask
        | (layout.grid.cavity_mask & ~solid),
        dtype=bool,
    )
    liquid = connected_to_top(open_domain)
    wet_face_length = interface_face_length_on_solid(
        layout.grid,
        liquid,
        solid,
    )
    interface = solid & (wet_face_length > 0.0)

    for site_id in layout.matrix_site_ids:
        site = prepared.sites[site_id]
        row, col = layout.cell_by_site[site_id]
        exposed = bool(interface[row, col]) and site.state != "removed"
        if exposed and site.state == "buried":
            site.state = "intact"
        site.attributes["wet_exposed"] = float(exposed)
        site.attributes["wet_face_count"] = float(exposed)

    for collector_id in layout.collector_site_ids:
        collector = prepared.sites[collector_id]
        support_id = layout.support_by_collector[collector_id]
        row, col = layout.cell_by_site[support_id]
        exposed = (
            prepared.sites[support_id].state == "removed"
            and bool(liquid[row, col])
        )
        collector.attributes["wet_exposed"] = float(exposed)
        collector.attributes["wet_face_count"] = float(exposed)
    return prepared


def run_second_wet_stage(
    source: TrenchKMCOutcome | AmorphousGraph,
    layout: TrenchGraphLayout | None = None,
    *,
    parameters: SecondWetKMCParameters = SecondWetKMCParameters(),
    seed: int = 0,
) -> SecondWetKMCOutcome:
    """Continue a graph/outcome through a fixed-duration second-WET stage.

    The input graph is never mutated.  Remaining exposed matrix states,
    including opt-in hydrolyzed/silanol and fluorinated intermediates, are
    removed directly, exposing the real next graph layer.  Exposed collector
    deposits dissolve monotonically.  Both event families use
    ``parameters.common_rate_multiplier`` and no other primary-HF event is
    active.
    """

    if not isinstance(seed, int) or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    if isinstance(source, TrenchKMCOutcome):
        if layout is not None and layout is not source.layout:
            raise ValueError(
                "layout must be omitted when source is TrenchKMCOutcome"
            )
        resolved_layout = source.layout
        source_graph = source.graph
        source_time_s = float(source.total_time_s)
    elif isinstance(source, AmorphousGraph):
        if layout is None:
            raise ValueError("layout is required when source is an AmorphousGraph")
        resolved_layout = layout
        source_graph = source
        source_time_s = 0.0
    else:
        raise TypeError("source must be TrenchKMCOutcome or AmorphousGraph")

    prepared = _prepare_second_wet_graph(source_graph, resolved_layout)
    before_metrics = trench_residue_metrics(prepared, resolved_layout)

    def wet_matrix(context: EventContext) -> bool:
        return (
            context.site.attributes["matrix_flag"] > 0.5
            and context.site.attributes["wet_exposed"] > 0.5
        )

    def matrix_removal_rate(context: EventContext) -> float:
        return (
            parameters.common_rate_multiplier
            * parameters.matrix_removal_rate_s
            * context.site.attributes.get("material_rate_factor", 1.0)
        )

    def remove_action(
        context: EventContext,
        _: np.random.Generator,
    ) -> Iterable[int]:
        return _remove_matrix_site(
            context,
            resolved_layout,
            newly_exposed_are_wet=True,
        )

    def wet_deposit(context: EventContext) -> bool:
        return (
            context.site.attributes["collector_flag"] > 0.5
            and context.site.attributes["wet_exposed"] > 0.5
        )

    templates = (
        EventTemplate(
            "second_wet_remove",
            REACTIVE_MATRIX_STATES,
            None,
            matrix_removal_rate,
            enabled=wet_matrix,
            action=remove_action,
            dependency_radius=1,
        ),
        EventTemplate(
            "second_wet_dissolve_deposit",
            "deposit",
            "collector",
            (
                parameters.common_rate_multiplier
                * parameters.deposit_dissolution_rate_s
            ),
            enabled=wet_deposit,
            dependency_radius=1,
        ),
    )
    kmc = GraphKMC(prepared, templates, seed=seed, copy_graph=True)
    horizon = parameters.duration_s
    stop_reason = "duration"
    while kmc.time_s < horizon:
        if kmc.total_rate_s <= 0.0:
            stop_reason = "no_events"
            kmc.time_s = horizon
            break
        record = kmc.step(horizon_time_s=horizon)
        if record is None:
            if kmc.time_s < horizon:
                kmc.time_s = horizon
            break

    after_metrics = trench_residue_metrics(kmc.graph, resolved_layout)
    return SecondWetKMCOutcome(
        graph=kmc.graph.copy(),
        layout=resolved_layout,
        event_log=tuple(kmc.event_log),
        stop_reason=stop_reason,
        time_s=kmc.time_s,
        duration_s=parameters.duration_s,
        source_time_s=source_time_s,
        seed=seed,
        parameters=parameters,
        before_metrics=dict(before_metrics),
        after_metrics=dict(after_metrics),
    )


def _largest_component(
    graph: AmorphousGraph,
    site_ids: Iterable[int],
    state: str,
) -> int:
    allowed = {site_id for site_id in site_ids if graph.sites[site_id].state == state}
    largest = 0
    while allowed:
        root = allowed.pop()
        queue = deque((root,))
        size = 1
        while queue:
            current = queue.popleft()
            for other in graph.neighbors(current):
                if other in allowed:
                    allowed.remove(other)
                    queue.append(other)
                    size += 1
        largest = max(largest, size)
    return largest


def trench_residue_metrics(
    graph: AmorphousGraph, layout: TrenchGraphLayout
) -> dict[str, object]:
    """Summarize remaining GAP-FILL and persistent wall/floor deposits."""

    matrix_counts = Counter(graph.sites[site_id].state for site_id in layout.matrix_site_ids)
    collector_counts = Counter(
        graph.sites[site_id].state for site_id in layout.collector_site_ids
    )
    material_metrics: dict[str, dict[str, object]] = {}
    matrix_materials = sorted(
        {graph.sites[site_id].material for site_id in layout.matrix_site_ids}
    )
    for material in matrix_materials:
        ids = [
            site_id
            for site_id in layout.matrix_site_ids
            if graph.sites[site_id].material == material
        ]
        counts = Counter(graph.sites[site_id].state for site_id in ids)
        removed_count = counts.get("removed", 0)
        material_metrics[material] = {
            "site_count": len(ids),
            "state_counts": dict(counts),
            "removed_fraction": removed_count / len(ids) if ids else 0.0,
            "remaining_fraction": (
                (len(ids) - removed_count) / len(ids) if ids else 0.0
            ),
        }
    region: dict[str, dict[str, float | int]] = {}
    for code, name in REGION_NAMES.items():
        ids = [
            site_id
            for site_id in layout.matrix_site_ids
            if int(round(graph.sites[site_id].attributes["region_code"])) == code
        ]
        remaining = sum(graph.sites[site_id].state != "removed" for site_id in ids)
        passivated = sum(graph.sites[site_id].state == "passivated" for site_id in ids)
        region[name] = {
            "site_count": len(ids),
            "remaining_count": remaining,
            "remaining_fraction": remaining / len(ids) if ids else 0.0,
            "passivated_count": passivated,
        }
    removed = matrix_counts.get("removed", 0)
    return {
        "matrix_site_count": layout.matrix_site_count,
        "collector_site_count": layout.collector_site_count,
        "state_counts": dict(matrix_counts),
        "collector_state_counts": dict(collector_counts),
        "material_metrics": material_metrics,
        "removed_fraction": removed / layout.matrix_site_count,
        "remaining_fraction": (
            layout.matrix_site_count - removed
        ) / layout.matrix_site_count,
        "region_metrics": region,
        "largest_passivation_cluster": _largest_component(
            graph, layout.matrix_site_ids, "passivated"
        ),
        "deposit_count": collector_counts.get("deposit", 0),
        "largest_deposit_cluster": _largest_component(
            graph, layout.collector_site_ids, "deposit"
        ),
    }


def _sync_record(
    kmc: GraphKMC,
    layout: TrenchGraphLayout,
    frame: ContinuumKMCFrame,
    sync_index: int,
) -> dict[str, object]:
    metrics = trench_residue_metrics(kmc.graph, layout)
    interface = np.asarray(frame.interface_mask, dtype=bool)
    hf_values = frame.hf_at_solid[interface]
    product_values = frame.product_at_solid[interface]
    return {
        "sync_index": sync_index,
        "time_s": kmc.time_s,
        "event_count": len(kmc.event_log),
        "total_rate_s": kmc.total_rate_s,
        "hf_interface_mean": float(np.mean(hf_values)) if hf_values.size else 0.0,
        "hf_interface_min": float(np.min(hf_values)) if hf_values.size else 0.0,
        "product_interface_mean": (
            float(np.mean(product_values)) if product_values.size else 0.0
        ),
        "interface_site_count": int(np.count_nonzero(interface)),
        "liquid_cavity_cell_count": int(
            np.count_nonzero(frame.liquid_mask & layout.grid.cavity_mask)
        ),
        "gas_cavity_cell_count": int(
            np.count_nonzero(frame.gas_mask & layout.grid.cavity_mask)
        ),
        "hf_converged": frame.hf_converged,
        "product_converged": frame.product_converged,
        "hf_relative_residual": frame.hf_relative_residual,
        "product_relative_residual": frame.product_relative_residual,
        **metrics,
    }


def run_coupled_trench_kmc(
    grid: CartesianGrid2D,
    *,
    graph_config: TrenchGraphConfig = TrenchGraphConfig(),
    spatial_etchability_parameters: SpatialEtchabilityParameters | None = None,
    coupling_parameters: ContinuumCouplingParameters = ContinuumCouplingParameters(),
    kmc_parameters: TrenchKMCParameters = TrenchKMCParameters(),
    intermediate_parameters: IntermediateStateKMCParameters | None = None,
    wetting_parameters: WettingParameters | None = None,
    initial_graph: AmorphousGraph | None = None,
    initial_layout: TrenchGraphLayout | None = None,
    seed: int = 0,
) -> TrenchKMCOutcome:
    """Run deterministic field synchronizations around exact local SSA steps.

    When ``initial_graph`` and ``initial_layout`` are both given, the run
    continues from that carried state instead of building a fresh full-fill
    graph: the graph is copied and its top-connected open domain re-wetted,
    exactly as for a second-WET continuation.  The layout must be the one the
    carried graph was built with (same grid and graph configuration).
    """

    if (initial_graph is None) != (initial_layout is None):
        raise ValueError(
            "initial_graph and initial_layout must be provided together"
        )
    if initial_graph is not None:
        base_graph = _prepare_second_wet_graph(initial_graph, initial_layout)
        layout = initial_layout
    else:
        base_graph, layout = build_trench_graph(
            grid,
            graph_config,
            spatial_etchability_parameters=spatial_etchability_parameters,
        )
    sync_history: list[Mapping[str, object]] = []
    event_locations: list[Mapping[str, object]] = []
    stop_reason = "total_time"
    target_crossing_before_fraction: float | None = None
    target_crossing_after_fraction: float | None = None
    sync_index = 0
    wetting_state = (
        None
        if wetting_parameters is None or not wetting_parameters.enabled
        else WettingState2D(grid, wetting_parameters)
    )
    instant_wetting = wetting_state is None or (
        wetting_parameters is not None
        and wetting_parameters.new_void_filling_mode == "liquid_inherited"
    )
    kmc = build_trench_kmc(
        base_graph,
        layout,
        kmc_parameters,
        intermediate_parameters=intermediate_parameters,
        seed=seed,
        newly_exposed_are_wet=instant_wetting,
    )
    remaining_matrix_count = sum(
        kmc.graph.sites[site_id].state != "removed"
        for site_id in layout.matrix_site_ids
    )
    target_remaining_count = (
        None
        if coupling_parameters.target_remaining_fraction is None
        else math.floor(
            coupling_parameters.target_remaining_fraction
            * layout.matrix_site_count
            + 1.0e-12
        )
    )

    def coupled_frame() -> ContinuumKMCFrame:
        if wetting_state is None:
            return solve_continuum_frame(
                kmc.graph,
                layout,
                coupling_parameters,
                time_s=kmc.time_s,
            )
        solid = solid_mask_from_graph(kmc.graph, layout)
        open_domain = np.asarray(
            grid.reservoir_mask | (grid.cavity_mask & ~solid)
        )
        update = wetting_state.update(
            open_domain,
            max(0.0, kmc.time_s - wetting_state.time_s),
        )
        return solve_continuum_frame(
            kmc.graph,
            layout,
            coupling_parameters,
            time_s=kmc.time_s,
            liquid_mask_override=update.liquid_mask,
            gas_mask_override=update.gas_mask,
        )

    while kmc.time_s < coupling_parameters.total_time_s:
        frame = coupled_frame()
        apply_continuum_frame(kmc, layout, frame, coupling_parameters)
        sync_history.append(_sync_record(kmc, layout, frame, sync_index))
        if all(
            kmc.graph.sites[site_id].state == "removed"
            for site_id in layout.matrix_site_ids
        ):
            stop_reason = "matrix_cleared"
            break
        if len(kmc.event_log) >= coupling_parameters.maximum_events:
            stop_reason = "maximum_events"
            break

        horizon = min(
            kmc.time_s + coupling_parameters.macro_time_step_s,
            coupling_parameters.total_time_s,
        )
        force_wetting_sync = False
        while kmc.time_s < horizon:
            if len(kmc.event_log) >= coupling_parameters.maximum_events:
                stop_reason = "maximum_events"
                break
            record = kmc.step(horizon_time_s=horizon)
            if record is None:
                # GraphKMC intentionally does not advance on zero propensity.
                # The continuum coupling clock must still reach its next sync.
                if kmc.time_s < horizon:
                    kmc.time_s = horizon
                break
            site = kmc.graph.sites[record.site_id]
            location: dict[str, object] = {
                "event_number": record.event_number,
                "time_s": record.time_s,
                "event_name": record.event_name,
                "site_id": record.site_id,
                "x_nm": site.attributes["x_nm"],
                "depth_nm": site.attributes["depth_nm"],
                "region_code": int(round(site.attributes["region_code"])),
                "old_state": record.old_state,
                "new_state": record.new_state,
            }
            if record.event_name == "reattach":
                target_ids = [
                    changed_id
                    for changed_id in record.changed_sites
                    if changed_id != record.site_id
                    and kmc.graph.sites[changed_id].state == "deposit"
                ]
                if target_ids:
                    target = kmc.graph.sites[target_ids[0]]
                    location.update(
                        target_site_id=target_ids[0],
                        target_x_nm=target.attributes["x_nm"],
                        target_depth_nm=target.attributes["depth_nm"],
                    )
            event_locations.append(location)
            if record.event_name in MATRIX_REMOVAL_EVENT_NAMES:
                before_fraction = (
                    remaining_matrix_count / layout.matrix_site_count
                )
                remaining_matrix_count -= 1
                after_fraction = (
                    remaining_matrix_count / layout.matrix_site_count
                )
                if (
                    target_remaining_count is not None
                    and remaining_matrix_count <= target_remaining_count
                ):
                    target_crossing_before_fraction = before_fraction
                    target_crossing_after_fraction = after_fraction
                    stop_reason = "remaining_fraction_target"
                    break
            if (
                wetting_state is not None
                and wetting_parameters is not None
                and wetting_parameters.gas_nucleation_enabled
                and not wetting_state.diagnostics.bottom_gas_pocket_active
                and record.event_name in MATRIX_REMOVAL_EVENT_NAMES
                and float(site.attributes["depth_nm"])
                >= wetting_parameters.bottom_gas_activation_depth_fraction
                * layout.grid.geometry.depth_nm
            ):
                # Synchronize exactly when the advancing dissolution front
                # first reaches the prescribed pocket-nucleation depth.  If
                # we waited for the next fixed macro horizon, a fast KMC front
                # could clear the entire trench before the gas state exists.
                force_wetting_sync = True
                break
        if stop_reason in {"maximum_events", "remaining_fraction_target"}:
            break
        if force_wetting_sync:
            sync_index += 1
            continue
        sync_index += 1

    final_frame = coupled_frame()
    apply_continuum_frame(kmc, layout, final_frame, coupling_parameters)
    final_sync = _sync_record(kmc, layout, final_frame, sync_index)
    if sync_history and math.isclose(
        float(sync_history[-1]["time_s"]),
        kmc.time_s,
        rel_tol=0.0,
        abs_tol=1.0e-12,
    ):
        sync_history[-1] = final_sync
    else:
        sync_history.append(final_sync)
    return TrenchKMCOutcome(
        graph=kmc.graph.copy(),
        layout=layout,
        final_frame=final_frame,
        sync_history=tuple(sync_history),
        event_log=tuple(kmc.event_log),
        event_locations=tuple(event_locations),
        stop_reason=stop_reason,
        total_time_s=kmc.time_s,
        seed=seed,
        target_remaining_fraction=(
            coupling_parameters.target_remaining_fraction
        ),
        target_crossing_before_fraction=target_crossing_before_fraction,
        target_crossing_after_fraction=target_crossing_after_fraction,
    )


def parameters_to_dict(
    graph_config: TrenchGraphConfig,
    coupling: ContinuumCouplingParameters,
    kinetics: TrenchKMCParameters,
    wetting: WettingParameters | None = None,
    spatial_etchability_parameters: SpatialEtchabilityParameters | None = None,
    intermediate_parameters: IntermediateStateKMCParameters | None = None,
) -> dict[str, object]:
    """Return strict-JSON-friendly configuration dictionaries."""

    payload: dict[str, object] = {
        "graph": asdict(graph_config),
        "coupling": asdict(coupling),
        "kinetics": asdict(kinetics),
        "wetting": None if wetting is None else wetting.to_dict(),
        "spatial_etchability": (
            spatial_etchability_parameters or SpatialEtchabilityParameters()
        ).to_dict(),
    }
    if intermediate_parameters is not None:
        if not isinstance(
            intermediate_parameters, IntermediateStateKMCParameters
        ):
            raise TypeError(
                "intermediate_parameters must be IntermediateStateKMCParameters"
            )
        payload["intermediate_kinetics"] = intermediate_parameters.to_dict()
    return payload


__all__ = [
    "ArrheniusRateSpec",
    "BASE_MATRIX_STATES",
    "COLLECTOR_STATES",
    "ContinuumCouplingParameters",
    "ContinuumKMCFrame",
    "INTERMEDIATE_MATRIX_STATES",
    "IntermediateStateKMCParameters",
    "MATRIX_STATES",
    "MATRIX_REMOVAL_EVENT_NAMES",
    "MaterialIntermediateKinetics",
    "REGION_BOTTOM",
    "REGION_CORE",
    "REGION_NAMES",
    "REGION_SIDEWALL",
    "REGION_TOP",
    "SecondWetKMCOutcome",
    "SecondWetKMCParameters",
    "SpeciesActivitySpec",
    "TrenchGraphConfig",
    "TrenchGraphLayout",
    "TrenchKMCOutcome",
    "TrenchKMCParameters",
    "apply_continuum_frame",
    "build_trench_graph",
    "build_trench_kmc",
    "parameters_to_dict",
    "run_coupled_trench_kmc",
    "run_second_wet_stage",
    "solid_mask_from_graph",
    "solve_continuum_frame",
    "trench_residue_metrics",
]

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from nonuniform_residue_sweep import (
    NonuniformSweepConfig,
    get_spatial_scenario,
    run_nonuniform_case,
    run_nonuniform_sweep,
)
from run_nonuniform_residue_sweep import main


class NonuniformResidueSweepTests(unittest.TestCase):
    def coarse_config(self, **overrides) -> NonuniformSweepConfig:
        values = {
            "geometries": ("10_8_180",),
            "presets": ("sin_barcellona_b_0p55wt",),
            "scenarios": ("uniform",),
            "target_remaining_fractions": (0.50,),
            "grid_spacing_nm": 5.0,
            "reservoir_height_nm": 5.0,
            "maximum_uniform_clear_time_multiplier": 3.0,
        }
        values.update(overrides)
        return NonuniformSweepConfig(**values)

    def test_spatial_scenarios_are_explicit_hypotheses(self) -> None:
        uniform = get_spatial_scenario("uniform")
        wall = get_spatial_scenario("wall_layer")
        self.assertEqual(uniform.parameters.sidewall_rate_factor, 1.0)
        self.assertLess(wall.parameters.sidewall_rate_factor, 1.0)
        self.assertIn("not a measured", get_spatial_scenario("depth_slow").assumption)
        with self.assertRaises(ValueError):
            get_spatial_scenario("unknown")

    def test_coarse_case_reaches_equal_removal_checkpoint(self) -> None:
        config = self.coarse_config()
        case = run_nonuniform_case(
            "10_8_180", "sin_barcellona_b_0p55wt", "uniform", config
        )
        self.assertTrue(case["all_targets_reached"])
        checkpoint = case["checkpoints"][0]
        self.assertTrue(checkpoint["reached"])
        self.assertLessEqual(checkpoint["achieved_remaining_fraction"], 0.50)
        residue = checkpoint["residue"]
        self.assertLess(residue["classified_area_balance_relative_error"], 1.0e-12)
        self.assertAlmostEqual(residue["left_right_asymmetry"], 0.0)
        self.assertTrue(case["convergence"]["reactant"])
        self.assertTrue(case["convergence"]["product"])
        self.assertTrue(case["convergence"]["nonlinear"])

    def test_wall_hypothesis_enriches_near_wall_residue_at_equal_removal(self) -> None:
        common = dict(
            geometries=("10_8_180",),
            presets=("sin_barcellona_b_0p55wt",),
            target_remaining_fractions=(0.10,),
            grid_spacing_nm=1.0,
            reservoir_height_nm=5.0,
            maximum_uniform_clear_time_multiplier=8.0,
        )
        uniform_config = NonuniformSweepConfig(
            **common,
            scenarios=("uniform",),
        )
        wall_config = NonuniformSweepConfig(
            **common,
            scenarios=("wall_layer",),
        )
        uniform = run_nonuniform_case(
            "10_8_180", "sin_barcellona_b_0p55wt", "uniform", uniform_config
        )["checkpoints"][0]
        wall = run_nonuniform_case(
            "10_8_180", "sin_barcellona_b_0p55wt", "wall_layer", wall_config
        )["checkpoints"][0]
        self.assertTrue(uniform["reached"])
        self.assertTrue(wall["reached"])
        self.assertGreater(
            wall["residue"]["sidewall_region"]["fraction_of_total_remaining"],
            uniform["residue"]["sidewall_region"]["fraction_of_total_remaining"],
        )
        self.assertLess(
            wall["residue"]["mean_sidewall_distance_nm"],
            uniform["residue"]["mean_sidewall_distance_nm"],
        )

    def test_parallel_case_order_matches_requested_cartesian_product(self) -> None:
        config = self.coarse_config(
            geometries=("10_8_180", "7_4p5_170"),
            scenarios=("uniform", "depth_slow"),
            parallel_workers=2,
        )
        payload = run_nonuniform_sweep(config)
        self.assertEqual(
            [case["case_id"] for case in payload["cases"]],
            [
                "10_8_180__sin_barcellona_b_0p55wt__uniform",
                "10_8_180__sin_barcellona_b_0p55wt__depth_slow",
                "7_4p5_170__sin_barcellona_b_0p55wt__uniform",
                "7_4p5_170__sin_barcellona_b_0p55wt__depth_slow",
            ],
        )
        self.assertEqual(payload["parallel_execution"]["effective_workers"], 2)

    def test_cli_writes_plain_json_and_keeps_temperatures_separate(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "nonuniform.json"
            payload = main(
                [
                    "--geometry",
                    "7_4p5_170",
                    "--preset",
                    "siocn_fujitsu_4b_100to1",
                    "--scenario",
                    "uniform",
                    "--target-remaining",
                    "0.5",
                    "--grid-spacing-nm",
                    "5",
                    "--reservoir-height-nm",
                    "5",
                    "--maximum-uniform-clear-multiplier",
                    "3",
                    "--solution-temperature-k",
                    "295",
                    "--substrate-temperature-k",
                    "320",
                    "--workers",
                    "1",
                    "--output",
                    str(output),
                ]
            )
            saved = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(saved, payload)
            config = saved["config"]
            self.assertEqual(config["solution_bulk_temperature_K"], 295.0)
            self.assertEqual(config["substrate_backside_temperature_K"], 320.0)
            self.assertFalse(saved["calibrated_spatial_factors"])


if __name__ == "__main__":
    unittest.main()

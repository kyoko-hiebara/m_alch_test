#!/usr/bin/env python3
"""Compare trench-KMC morphology at a matched etch extent, not a matched time.

``run_trench_kmc_sweep.py`` stops every case at the same native clock time.
The KMC rates are per site, so a finer mesh removes a similar *front area* per
unit time while the site count grows as 1/mesh^2.  The remaining *fraction* at
a fixed time therefore falls with mesh refinement and never converges: the same
baseline case reads 18.0% at 1.05 nm, 36.5% at 0.7 nm and 45.5% at 0.55 nm.

Morphology comparisons between mechanisms are only meaningful at a matched
extent of etch.  This reads the saved ``sync_history`` of each case and reports
the region-resolved residue at a chosen removed fraction, interpolating between
the two bracketing synchronisation points.  Nothing is recomputed.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable, Mapping, Sequence


SCHEMA_VERSION = "trench-kmc-matched-extent/v1"
DEFAULT_REMOVED_FRACTION = 0.5
REGIONS = ("sidewall", "bottom", "core", "top")


def _load_json(path: Path) -> dict[str, object]:
    def reject(value: str) -> None:
        raise ValueError(f"non-standard JSON value {value!r}")

    payload = json.loads(path.read_text(encoding="utf-8"), parse_constant=reject)
    if not isinstance(payload, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return payload


def _interpolate(low: float, high: float, weight: float) -> float:
    return low + (high - low) * weight


def sample_at_removed_fraction(
    history: Sequence[Mapping[str, object]],
    removed_fraction: float,
) -> dict[str, object] | None:
    """Return the region metrics when the case first reaches an extent.

    ``None`` means the case never reached the requested extent, which is a
    result about the case and not a value to substitute for.
    """

    if not 0.0 < removed_fraction < 1.0:
        raise ValueError("removed_fraction must lie strictly within (0, 1)")
    ordered = sorted(history, key=lambda item: int(item["sync_index"]))
    previous: Mapping[str, object] | None = None
    for record in ordered:
        current = float(record["removed_fraction"])
        if current >= removed_fraction:
            if previous is None:
                weight = 0.0
                low = record
            else:
                low = previous
                span = current - float(previous["removed_fraction"])
                weight = (
                    (removed_fraction - float(previous["removed_fraction"])) / span
                    if span > 0.0
                    else 0.0
                )
            high = record
            regions: dict[str, float] = {}
            for name in REGIONS:
                low_metrics = (low.get("region_metrics") or {}).get(name)
                high_metrics = (high.get("region_metrics") or {}).get(name)
                if not isinstance(low_metrics, Mapping) or not isinstance(
                    high_metrics, Mapping
                ):
                    continue
                regions[name] = _interpolate(
                    float(low_metrics["remaining_fraction"]),
                    float(high_metrics["remaining_fraction"]),
                    weight,
                )
            return {
                "reached": True,
                "removed_fraction": removed_fraction,
                "time_s": _interpolate(
                    float(low["time_s"]), float(high["time_s"]), weight
                ),
                "deposit_count": _interpolate(
                    float(low["deposit_count"]),
                    float(high["deposit_count"]),
                    weight,
                ),
                "region_remaining_fraction": regions,
                "bracketing_sync_indices": [
                    int(low["sync_index"]),
                    int(high["sync_index"]),
                ],
            }
        previous = record
    final = ordered[-1] if ordered else None
    return {
        "reached": False,
        "removed_fraction": removed_fraction,
        "maximum_removed_fraction": (
            float(final["removed_fraction"]) if final is not None else None
        ),
        "reason": "the case stopped before reaching this extent",
    }


def analyse_sweep(
    result_path: Path,
    *,
    removed_fraction: float = DEFAULT_REMOVED_FRACTION,
    case_group: str = "mechanism",
) -> dict[str, object]:
    """Re-read one saved sweep and report morphology at a matched extent."""

    payload = _load_json(result_path)
    cases = payload.get("cases")
    if not isinstance(cases, list):
        raise ValueError(f"{result_path} has no cases list")
    config = payload.get("config")
    mesh = None
    if isinstance(config, Mapping):
        sweep = config.get("sweep")
        if isinstance(sweep, Mapping):
            mesh = sweep.get("grid_spacing_nm")
    records: list[dict[str, object]] = []
    for case in cases:
        if not isinstance(case, Mapping) or case.get("case_group") != case_group:
            continue
        history = case.get("sync_history")
        if not isinstance(history, list) or not history:
            continue
        summary = case.get("summary")
        sample = sample_at_removed_fraction(history, removed_fraction)
        records.append(
            {
                "case_id": case.get("case_id"),
                "geometry_id": case.get("geometry_id"),
                "scenario_id": case.get("scenario_id"),
                "seed": case.get("seed"),
                "matrix_site_count": (
                    int(summary["matrix_site_count"])
                    if isinstance(summary, Mapping)
                    else None
                ),
                "final_removed_fraction": (
                    float(summary["removed_fraction"])
                    if isinstance(summary, Mapping)
                    else None
                ),
                "matched_extent": sample,
            }
        )
    reached = [item for item in records if item["matched_extent"]["reached"]]
    return {
        "schema_version": SCHEMA_VERSION,
        "notice": (
            "Morphology at a matched removed fraction. A fixed native clock is "
            "not mesh invariant for this sweep, so fixed-time residue "
            "fractions cannot be compared between meshes."
        ),
        "source_result": str(result_path.resolve()),
        "grid_spacing_nm": mesh,
        "removed_fraction": removed_fraction,
        "case_count": len(records),
        "reached_count": len(reached),
        "records": records,
    }


def compare_meshes(
    result_paths: Sequence[Path],
    *,
    removed_fraction: float = DEFAULT_REMOVED_FRACTION,
) -> dict[str, object]:
    """Line up the same cases from several meshes at one matched extent."""

    studies = [
        analyse_sweep(path, removed_fraction=removed_fraction)
        for path in result_paths
    ]
    series: dict[str, dict[str, object]] = {}
    for study in studies:
        mesh = study["grid_spacing_nm"]
        for record in study["records"]:
            key = f"{record['geometry_id']} / {record['scenario_id']}"
            entry = series.setdefault(key, {"points": []})
            sample = record["matched_extent"]
            entry["points"].append(
                {
                    "grid_spacing_nm": mesh,
                    "matrix_site_count": record["matrix_site_count"],
                    "reached": sample["reached"],
                    "sidewall_remaining_fraction": (
                        sample["region_remaining_fraction"].get("sidewall")
                        if sample["reached"]
                        else None
                    ),
                    "bottom_remaining_fraction": (
                        sample["region_remaining_fraction"].get("bottom")
                        if sample["reached"]
                        else None
                    ),
                    "time_s": sample.get("time_s"),
                }
            )
    for entry in series.values():
        entry["points"].sort(
            key=lambda item: -float(item["grid_spacing_nm"] or 0.0)
        )
        walls = [
            float(point["sidewall_remaining_fraction"])
            for point in entry["points"]
            if point["reached"] and point["sidewall_remaining_fraction"] is not None
        ]
        entry["sidewall_spread"] = (
            max(walls) - min(walls) if len(walls) > 1 else None
        )
    return {
        "schema_version": SCHEMA_VERSION,
        "removed_fraction": removed_fraction,
        "meshes_nm": [study["grid_spacing_nm"] for study in studies],
        "series": series,
    }


def readme_lines(comparison: Mapping[str, object]) -> Iterable[str]:
    yield "# 除去率を揃えたtrench KMC形態比較"
    yield ""
    yield (
        "固定native時間ではmeshを細かくするほど残存率が上がり収束しません。"
        "KMCのrateはsiteごとで、除去はfront面積律速なのに対し全site数は"
        "`1/mesh^2`で増えるためです。ここでは**除去率を揃えて**比較します。"
    )
    yield ""
    yield f"- 揃えた除去率: {float(comparison['removed_fraction']):.0%}"
    yield (
        "- mesh: "
        + ", ".join(f"{value:g}" for value in comparison["meshes_nm"] if value)
        + " nm"
    )
    yield ""
    yield "| 系列 | mesh | sites | sidewall残存 | bottom残存 | 到達時刻 |"
    yield "|---|---:|---:|---:|---:|---:|"
    for key, entry in sorted(comparison["series"].items()):
        for point in entry["points"]:
            if not point["reached"]:
                yield (
                    f"| `{key}` | {point['grid_spacing_nm']:g} nm "
                    f"| {point['matrix_site_count']} | 未到達 | 未到達 | — |"
                )
                continue
            yield (
                f"| `{key}` | {point['grid_spacing_nm']:g} nm "
                f"| {point['matrix_site_count']} "
                f"| {point['sidewall_remaining_fraction']:.1%} "
                f"| {point['bottom_remaining_fraction']:.1%} "
                f"| {point['time_s']:.0f} s |"
            )
    yield ""
    yield "## meshによる sidewall残存の振れ幅"
    yield ""
    yield "| 系列 | 振れ幅 |"
    yield "|---|---:|"
    for key, entry in sorted(comparison["series"].items()):
        spread = entry["sidewall_spread"]
        yield f"| `{key}` | {'—' if spread is None else f'{spread:.1%}'} |"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path, nargs="+")
    parser.add_argument(
        "--removed-fraction",
        type=float,
        default=DEFAULT_REMOVED_FRACTION,
    )
    parser.add_argument("--output-dir", type=Path, default=None)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    comparison = compare_meshes(
        arguments.results, removed_fraction=arguments.removed_fraction
    )
    text = "\n".join(readme_lines(comparison))
    if arguments.output_dir is not None:
        arguments.output_dir.mkdir(parents=True, exist_ok=True)
        target = arguments.output_dir / "matched_extent_results.json"
        temporary = target.with_suffix(target.suffix + ".tmp")
        temporary.write_text(
            json.dumps(comparison, indent=1, sort_keys=True, allow_nan=False),
            encoding="utf-8",
        )
        temporary.replace(target)
        (arguments.output_dir / "README_JA.md").write_text(
            text + "\n", encoding="utf-8"
        )
        print(target)
    print(text)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

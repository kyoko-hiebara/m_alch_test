from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from wetting_sweep import (
    WETTING_SWEEP_NOTICE,
    WettingSweepConfig,
    plot_wetting_phase_maps,
    plot_wetting_summary,
    run_wetting_sweep,
)


class WettingSweepTests(unittest.TestCase):
    """Short coarse-grid contract tests for the wetting screening sweep."""

    @classmethod
    def setUpClass(cls) -> None:
        # One real geometry on a deliberately coarse grid keeps this suite fast
        # while still exercising the coupled front, transport, wetting, probe,
        # ordering, strict-JSON, and plotting paths together.
        cls.config = WettingSweepConfig(
            geometries=("10_8_180",),
            scenarios=("combined_adverse", "baseline_inherited_liquid"),
            grid_spacing_nm=5.0,
            probe_grid_spacing_nm=2.0,
            reservoir_height_nm=5.0,
            maximum_etch_velocity_nm_s=20.0,
            maximum_time_over_planar_clear=0.05,
            maximum_fractional_front_change=1.0,
            contact_angles_deg=(60.0, 120.0),
            probe_samples=7,
            maximum_probe_displacement_nm=20.0,
            solution_bulk_temperature_K=291.25,
            substrate_backside_temperature_K=333.75,
            # Process startup dominates this two-case smoke calculation.  The
            # production ProcessPool uses executor.map, whose ordering contract
            # is checked below using the same explicitly non-default case order.
            parallel_workers=1,
        )
        cls.payload = run_wetting_sweep(cls.config)

    def test_final_phase_maps_form_a_strict_partition(self) -> None:
        for case in self.payload["coupled_cases"]:
            with self.subTest(scenario=case["scenario"]):
                phase_map = case["final_phase_map"]
                cavity = np.asarray(phase_map["cavity_mask"], dtype=bool)
                solid_fraction = np.asarray(
                    phase_map["solid_fraction"], dtype=float
                )
                liquid = np.asarray(phase_map["liquid_mask"], dtype=bool)
                gas = np.asarray(phase_map["gas_mask"], dtype=bool)
                bottom_gas = np.asarray(
                    phase_map["bottom_gas_mask"], dtype=bool
                )

                solid = cavity & (solid_fraction > 1.0e-12)
                open_void = cavity & ~solid
                trench_liquid = cavity & liquid

                np.testing.assert_array_equal(trench_liquid | gas, open_void)
                self.assertFalse(np.any(trench_liquid & gas))
                self.assertFalse(np.any(solid & (trench_liquid | gas)))
                self.assertFalse(np.any(gas & ~cavity))
                self.assertFalse(np.any(bottom_gas & ~gas))

                cell_area_nm2 = (
                    float(case["grid"]["dx_nm"])
                    * float(case["grid"]["dz_nm"])
                )
                outcome = case["outcome"]
                self.assertAlmostEqual(
                    float(outcome["open_void_area_nm2"]),
                    np.count_nonzero(open_void) * cell_area_nm2,
                    places=12,
                )
                self.assertAlmostEqual(
                    float(outcome["wetted_area_nm2"]),
                    np.count_nonzero(trench_liquid) * cell_area_nm2,
                    places=12,
                )
                self.assertAlmostEqual(
                    float(outcome["gas_area_nm2"]),
                    np.count_nonzero(gas) * cell_area_nm2,
                    places=12,
                )
                self.assertLessEqual(
                    float(outcome["phase_partition_relative_error"]),
                    1.0e-12,
                )

        self.assertLessEqual(
            float(
                self.payload["summary"][
                    "largest_phase_partition_relative_error"
                ]
            ),
            1.0e-12,
        )

    def test_coupled_cases_explicitly_preserve_fully_filled_initial_state(self) -> None:
        self.assertIn("fully GAP-FILLED initial condition", WETTING_SWEEP_NOTICE)
        self.assertFalse(
            self.payload["open_trench_probe"][
                "is_coupled_gapfill_initial_condition"
            ]
        )
        for case in self.payload["coupled_cases"]:
            with self.subTest(scenario=case["scenario"]):
                initial = case["initial_condition"]
                self.assertIs(initial["fully_gap_filled"], True)
                self.assertEqual(initial["initial_gas_area_nm2"], 0.0)
                self.assertEqual(
                    initial["initial_liquid_area_in_trench_nm2"], 0.0
                )

    def test_solution_and_substrate_temperatures_remain_independent(self) -> None:
        expected_solution = self.config.solution_bulk_temperature_K
        expected_substrate = self.config.substrate_backside_temperature_K
        self.assertNotEqual(expected_solution, expected_substrate)
        self.assertEqual(
            self.payload["config"]["solution_bulk_temperature_K"],
            expected_solution,
        )
        self.assertEqual(
            self.payload["config"]["substrate_backside_temperature_K"],
            expected_substrate,
        )
        for case in self.payload["coupled_cases"]:
            with self.subTest(scenario=case["scenario"]):
                temperatures = case["temperatures"]
                self.assertEqual(
                    temperatures["solution_bulk_temperature_K"],
                    expected_solution,
                )
                self.assertEqual(
                    temperatures["substrate_backside_temperature_K"],
                    expected_substrate,
                )
                self.assertIs(temperatures["independently_configurable"], True)

    def test_open_probe_invades_below_90_degrees_but_not_above(self) -> None:
        probes = {
            float(case["contact_angle_deg"]): case
            for case in self.payload["open_trench_probe"]["cases"]
        }
        wetting = probes[60.0]
        nonwetting = probes[120.0]

        wet_depth = np.asarray(wetting["contact_line_depth_nm"], dtype=float)
        dry_depth = np.asarray(nonwetting["contact_line_depth_nm"], dtype=float)
        self.assertGreater(wet_depth[-1], wet_depth[0])
        self.assertTrue(np.all(np.diff(wet_depth) >= -1.0e-12))
        self.assertGreater(wetting["capillary_pressure_top_Pa"], 0.0)
        self.assertIsNotNone(
            wetting["constant_bottom_width_washburn_time_s"]
        )

        np.testing.assert_allclose(dry_depth, 0.0, atol=0.0, rtol=0.0)
        np.testing.assert_allclose(
            nonwetting["wetted_fraction_of_open_void"],
            0.0,
            atol=0.0,
            rtol=0.0,
        )
        self.assertLess(nonwetting["capillary_pressure_top_Pa"], 0.0)
        self.assertIsNone(
            nonwetting["constant_bottom_width_washburn_time_s"]
        )

    def test_case_order_and_strict_json_are_preserved(self) -> None:
        expected = [
            (geometry, scenario)
            for geometry in self.config.geometries
            for scenario in self.config.scenarios
        ]
        actual = [
            (case["geometry_name"], case["scenario"])
            for case in self.payload["coupled_cases"]
        ]
        self.assertEqual(actual, expected)
        parallel = self.payload["parallel_execution"]
        self.assertEqual(parallel["requested_workers"], 1)
        self.assertEqual(parallel["effective_workers"], 1)
        self.assertIs(parallel["case_order_preserved"], True)
        self.assertTrue(json.dumps(self.payload, allow_nan=False))

    def test_summary_and_phase_map_pngs_are_generated(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            summary = output / "wetting_summary.png"
            phases = output / "wetting_phase_maps.png"
            plot_wetting_summary(self.payload, str(summary))
            plot_wetting_phase_maps(self.payload, str(phases))

            for path in (summary, phases):
                with self.subTest(path=path.name):
                    self.assertTrue(path.is_file())
                    self.assertGreater(path.stat().st_size, 1_024)
                    self.assertEqual(path.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")


if __name__ == "__main__":
    unittest.main()

"""Persistent wall/floor deposit phase for the two-dimensional trench model.

The phase is deliberately separate from the original GAP FILL level set.
Deposited material therefore remains after SiN/SiCN/SiOCN has dissolved and can be
removed only by an explicit rinse or second-WET dissolution operation.

Two formation routes are represented:

* optional heterogeneous precipitation from a supersaturated *wet* product
  field, coupled back to the product PDE as a conservative sink; and
* post-HF dry-down/meniscus capture of a specified retained product inventory.

The second route is important because the available Si3N4/HF experiment
attributes salt particles primarily to drying concentration, while immediate
flowing-DI rinse prevents detectable particles.  Neither route hard-blocks a
grid cell in this first sub-grid model; equivalent deposit thickness and
validity flags are reported instead.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass

import numpy as np

from reaction_diffusion_2d import CartesianGrid2D
from spatial_etchability import boundary_contact_fields


NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN = 1.0e-27


@dataclass(frozen=True)
class DepositParameters:
    """Material and attachment inputs for a persistent deposit phase.

    Concentration uses mol/m3 of the represented deposit precursor.  For the
    SiN literature case this may be interpreted as AFS-like
    ``(NH4)2SiF6``.  SiOCN requires a separately calibrated generic species.
    """

    species_name: str = "generic_deposit"
    saturation_concentration_mol_m3: float = 1_190.0
    attachment_velocity_nm_s: float = 0.0
    wall_affinity: float = 1.0
    bottom_affinity: float = 1.0
    deposit_molar_density_mol_m3: float = 1.0 / 8.908e-5
    precipitation_yield_mol_deposit_per_mol_product: float = 1.0
    active_set_relative_tolerance: float = 1.0e-4
    maximum_active_set_iterations: int = 8
    subgrid_warning_thickness_over_cell: float = 0.5
    coverage_reference_thickness_nm: float = 0.30
    deposit_molar_mass_kg_mol: float | None = None

    def __post_init__(self) -> None:
        if not self.species_name:
            raise ValueError("deposit species_name cannot be empty")
        for name in (
            "saturation_concentration_mol_m3",
            "deposit_molar_density_mol_m3",
            "precipitation_yield_mol_deposit_per_mol_product",
            "active_set_relative_tolerance",
            "subgrid_warning_thickness_over_cell",
            "coverage_reference_thickness_nm",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.deposit_molar_mass_kg_mol is not None:
            molar_mass = float(self.deposit_molar_mass_kg_mol)
            if not math.isfinite(molar_mass) or molar_mass <= 0.0:
                raise ValueError(
                    "deposit_molar_mass_kg_mol must be finite and positive "
                    "when supplied"
                )
        for name in ("wall_affinity", "bottom_affinity"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")
        if self.wall_affinity + self.bottom_affinity <= 0.0:
            raise ValueError("at least one deposit affinity must be positive")
        if self.precipitation_yield_mol_deposit_per_mol_product > 1.0:
            raise ValueError(
                "precipitation yield cannot exceed one for the dissolved-Si "
                "equivalent product definition"
            )
        if (
            not math.isfinite(self.attachment_velocity_nm_s)
            or self.attachment_velocity_nm_s < 0.0
        ):
            raise ValueError(
                "attachment_velocity_nm_s must be finite and non-negative"
            )
        if (
            not isinstance(self.maximum_active_set_iterations, int)
            or self.maximum_active_set_iterations < 1
        ):
            raise ValueError(
                "maximum_active_set_iterations must be a positive integer"
            )

    @property
    def wet_precipitation_enabled(self) -> bool:
        return self.attachment_velocity_nm_s > 0.0

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class DepositDiagnostics:
    species_name: str
    total_inventory_native: float
    wall_inventory_native: float
    bottom_inventory_native: float
    total_mol_per_nm_span: float
    equivalent_cross_section_area_nm2: float
    fraction_of_initial_gap_fill_area: float
    wall_fraction_of_deposit: float
    bottom_fraction_of_deposit: float
    mean_wall_thickness_nm: float
    maximum_wall_thickness_nm: float
    mean_bottom_thickness_nm: float
    maximum_bottom_thickness_nm: float
    maximum_thickness_over_grid_spacing: float
    subgrid_validity_warning: bool
    wall_coated_length_nm: float
    bottom_coated_length_nm: float
    depth_centroid_nm: float | None
    upper_middle_lower_inventory_fraction: tuple[float, float, float]
    # A two-dimensional calculation represents a one-nanometre
    # out-of-plane span.  Multiplying each contact length by that span gives
    # the physical collector area used by the areal diagnostics below.
    wall_available_contact_area_nm2_for_1nm_span: float = 0.0
    bottom_available_contact_area_nm2_for_1nm_span: float = 0.0
    total_available_contact_area_nm2_for_1nm_span: float = 0.0
    wall_inventory_density_native_per_nm2: float = 0.0
    bottom_inventory_density_native_per_nm2: float = 0.0
    total_inventory_density_native_per_nm2: float = 0.0
    wall_areal_inventory_mol_m2: float = 0.0
    bottom_areal_inventory_mol_m2: float = 0.0
    total_areal_inventory_mol_m2: float = 0.0
    total_mean_thickness_nm: float = 0.0
    wall_geometric_coverage_fraction: float = 0.0
    bottom_geometric_coverage_fraction: float = 0.0
    total_geometric_coverage_fraction: float = 0.0
    # Poisson sub-monolayer coverage proxy, 1-exp(-thickness/t_ref).  Unlike
    # the legacy coated-length flag it changes continuously with inventory.
    wall_continuous_coverage_fraction: float = 0.0
    bottom_continuous_coverage_fraction: float = 0.0
    total_continuous_coverage_fraction: float = 0.0
    wall_mean_layer_equivalents: float = 0.0
    bottom_mean_layer_equivalents: float = 0.0
    total_mean_layer_equivalents: float = 0.0
    wall_mass_kg_per_nm_span: float | None = None
    bottom_mass_kg_per_nm_span: float | None = None
    total_mass_kg_per_nm_span: float | None = None

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["upper_middle_lower_inventory_fraction"] = list(
            self.upper_middle_lower_inventory_fraction
        )
        return result


@dataclass(frozen=True)
class DepositFormationResult:
    route: str
    retained_product_inventory_native: float
    remaining_dissolved_product_inventory_native: float
    precipitable_product_inventory_native: float
    available_product_inventory_native: float
    nondeposit_product_inventory_native: float
    precipitated_inventory_native: float
    wall_attached_inventory_native: float
    bottom_attached_inventory_native: float
    solute_retention_fraction: float
    liquid_retention_fraction: float
    precipitation_yield: float
    diagnostics: DepositDiagnostics

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["diagnostics"] = self.diagnostics.to_dict()
        return result


@dataclass(frozen=True)
class DepositDissolutionResult:
    duration_s: float
    wall_rate_s: float
    bottom_rate_s: float
    before_inventory_native: float
    removed_inventory_native: float
    after_inventory_native: float
    diagnostics: DepositDiagnostics

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["diagnostics"] = self.diagnostics.to_dict()
        return result


class PersistentDepositPhase2D:
    """Wall/floor-attached inventory that survives original-film removal."""

    def __init__(
        self,
        grid: CartesianGrid2D,
        parameters: DepositParameters | None = None,
    ) -> None:
        self.grid = grid
        self.parameters = parameters or DepositParameters()
        self.wall_contact_length_nm, self.bottom_contact_length_nm = (
            self._build_collector_lengths()
        )
        self.wall_inventory_native = np.zeros(grid.shape, dtype=float)
        self.bottom_inventory_native = np.zeros(grid.shape, dtype=float)
        self._collector_mask = self.collector_mask()
        if not np.any(self._collector_mask):
            raise ValueError("trench grid contains no enabled deposit collector")

    def _build_collector_lengths(self) -> tuple[np.ndarray, np.ndarray]:
        # Reuse the same discrete Si contacts as residue-topology analysis.
        # In particular, floor capture occurs only on the physical terminal
        # face; it is not moved upward into an arbitrary near-bottom band.
        contacts = boundary_contact_fields(self.grid)
        return (
            contacts.sidewall_contact_length_nm.copy(),
            contacts.bottom_contact_length_nm.copy(),
        )

    def collector_mask(
        self,
        access_mask: np.ndarray | None = None,
        *,
        include_wall: bool = True,
        include_bottom: bool = True,
    ) -> np.ndarray:
        """Return enabled physical collectors within an optional access mask.

        With no ``access_mask``, the result represents the all-physical-face
        accessibility upper bound.  Passing a primary-HF liquid-access mask
        returns the corresponding wall/floor subset without changing any
        captured-inventory scalar.  A face with zero affinity remains disabled
        even when it is physically present.

        The returned Boolean array is independent of the supplied mask and can
        therefore be retained by a caller as a stage-specific collector basis.
        """

        enabled = np.zeros(self.grid.shape, dtype=bool)
        if include_wall and self.parameters.wall_affinity > 0.0:
            enabled |= self.wall_contact_length_nm > 0.0
        if include_bottom and self.parameters.bottom_affinity > 0.0:
            enabled |= self.bottom_contact_length_nm > 0.0
        enabled &= self.grid.cavity_mask
        if access_mask is not None:
            access = np.asarray(access_mask, dtype=bool)
            if access.shape != self.grid.shape:
                raise ValueError("access_mask must match deposit grid")
            enabled &= access
        return enabled

    def _map_inventory_to_nearest_collectors(
        self,
        inventory_field: np.ndarray,
        enabled_collector_mask: np.ndarray | None = None,
    ) -> np.ndarray:
        """Map cell inventory symmetrically to equidistant nearest faces."""
        inventory = np.asarray(inventory_field, dtype=float)
        if inventory.shape != self.grid.shape:
            raise ValueError("inventory field must match deposit grid")
        enabled = self._collector_mask.copy()
        if enabled_collector_mask is not None:
            supplied = np.asarray(enabled_collector_mask, dtype=bool)
            if supplied.shape != self.grid.shape:
                raise ValueError("enabled collector mask must match deposit grid")
            enabled &= supplied
        if np.any(inventory > 0.0) and not np.any(enabled):
            raise ValueError("positive inventory has no exposed deposit collector")
        collector_rows, collector_cols = np.nonzero(enabled)
        collector_weights = self._weighted_collector_length_nm()[
            collector_rows, collector_cols
        ]
        mapped = np.zeros(self.grid.shape, dtype=float)
        source_rows, source_cols = np.nonzero(inventory > 0.0)
        for row, col in zip(source_rows, source_cols, strict=True):
            distance_squared = (
                ((collector_rows - row) * self.grid.dz_nm) ** 2
                + ((collector_cols - col) * self.grid.dx_nm) ** 2
            )
            minimum = float(np.min(distance_squared))
            nearest = np.isclose(
                distance_squared,
                minimum,
                rtol=0.0,
                atol=1.0e-12 * max(1.0, minimum),
            )
            weights = collector_weights[nearest]
            weights = weights / float(np.sum(weights))
            np.add.at(
                mapped,
                (collector_rows[nearest], collector_cols[nearest]),
                inventory[row, col] * weights,
            )
        return mapped

    @property
    def total_inventory_native_field(self) -> np.ndarray:
        return self.wall_inventory_native + self.bottom_inventory_native

    @property
    def wall_thickness_nm(self) -> np.ndarray:
        result = np.zeros(self.grid.shape, dtype=float)
        np.divide(
            self.wall_inventory_native,
            self.parameters.deposit_molar_density_mol_m3
            * self.wall_contact_length_nm,
            out=result,
            where=self.wall_contact_length_nm > 0.0,
        )
        return result

    @property
    def bottom_thickness_nm(self) -> np.ndarray:
        result = np.zeros(self.grid.shape, dtype=float)
        np.divide(
            self.bottom_inventory_native,
            self.parameters.deposit_molar_density_mol_m3
            * self.bottom_contact_length_nm,
            out=result,
            where=self.bottom_contact_length_nm > 0.0,
        )
        return result

    def _weighted_collector_length_nm(self) -> np.ndarray:
        return (
            self.parameters.wall_affinity * self.wall_contact_length_nm
            + self.parameters.bottom_affinity * self.bottom_contact_length_nm
        )

    def wet_attachment_decay_field_s(
        self,
        liquid_mask: np.ndarray,
        active_mask: np.ndarray | None = None,
    ) -> np.ndarray:
        liquid = np.asarray(liquid_mask, dtype=bool)
        if liquid.shape != self.grid.shape:
            raise ValueError("liquid_mask must match deposit grid")
        enabled = liquid & self.grid.cavity_mask & self._collector_mask
        if active_mask is not None:
            active = np.asarray(active_mask, dtype=bool)
            if active.shape != self.grid.shape:
                raise ValueError("active_mask must match deposit grid")
            enabled &= active
        result = np.zeros(self.grid.shape, dtype=float)
        result[enabled] = (
            self.parameters.attachment_velocity_nm_s
            * self._weighted_collector_length_nm()[enabled]
            / self.grid.cell_area_nm2
        )
        return result

    def wet_active_mask(
        self,
        product_concentration: np.ndarray,
        liquid_mask: np.ndarray,
        previous_active_mask: np.ndarray | None = None,
    ) -> np.ndarray:
        product = np.asarray(product_concentration, dtype=float)
        liquid = np.asarray(liquid_mask, dtype=bool)
        if product.shape != self.grid.shape or liquid.shape != self.grid.shape:
            raise ValueError("product and liquid fields must match deposit grid")
        if np.any(~np.isfinite(product)) or np.any(product < 0.0):
            raise ValueError("product concentration must be finite and non-negative")
        enabled = liquid & self.grid.cavity_mask & self._collector_mask
        tolerance = self.parameters.active_set_relative_tolerance
        saturation = self.parameters.saturation_concentration_mol_m3
        active = enabled & (product > saturation * (1.0 + tolerance))
        if previous_active_mask is not None:
            previous = np.asarray(previous_active_mask, dtype=bool)
            if previous.shape != self.grid.shape:
                raise ValueError("previous_active_mask must match deposit grid")
            active |= (
                enabled
                & previous
                & (product >= saturation * (1.0 - tolerance))
            )
        return active

    def wet_precipitation_rate_native_field(
        self,
        product_concentration: np.ndarray,
        liquid_mask: np.ndarray,
        active_mask: np.ndarray | None = None,
    ) -> np.ndarray:
        product = np.asarray(product_concentration, dtype=float)
        active = (
            self.wet_active_mask(product, liquid_mask)
            if active_mask is None
            else np.asarray(active_mask, dtype=bool)
        )
        excess = np.maximum(
            product - self.parameters.saturation_concentration_mol_m3,
            0.0,
        )
        decay = self.wet_attachment_decay_field_s(liquid_mask, active)
        return (
            decay
            * excess
            * self.grid.cell_area_nm2
            * self.parameters.precipitation_yield_mol_deposit_per_mol_product
        )

    def wet_product_capture_rate_native_field(
        self,
        product_concentration: np.ndarray,
        liquid_mask: np.ndarray,
        active_mask: np.ndarray | None = None,
    ) -> np.ndarray:
        """Return precursor loss that actually becomes attached deposit."""
        product = np.asarray(product_concentration, dtype=float)
        active = (
            self.wet_active_mask(product, liquid_mask)
            if active_mask is None
            else np.asarray(active_mask, dtype=bool)
        )
        excess = np.maximum(
            product - self.parameters.saturation_concentration_mol_m3,
            0.0,
        )
        decay = self.wet_attachment_decay_field_s(liquid_mask, active)
        return (
            decay
            * excess
            * self.grid.cell_area_nm2
            * self.parameters.precipitation_yield_mol_deposit_per_mol_product
        )

    def _split_and_add_collector_inventory(
        self,
        inventory_at_collectors: np.ndarray,
    ) -> tuple[float, float]:
        inventory = np.asarray(inventory_at_collectors, dtype=float)
        if inventory.shape != self.grid.shape:
            raise ValueError("collector inventory must match deposit grid")
        if np.any(~np.isfinite(inventory)) or np.any(inventory < 0.0):
            raise ValueError("collector inventory must be finite and non-negative")
        wall_weight = (
            self.parameters.wall_affinity * self.wall_contact_length_nm
        )
        bottom_weight = (
            self.parameters.bottom_affinity * self.bottom_contact_length_nm
        )
        total_weight = wall_weight + bottom_weight
        unsupported = (inventory > 0.0) & (total_weight <= 0.0)
        if np.any(unsupported):
            raise ValueError("inventory was assigned to a disabled collector")
        wall_share = np.divide(
            wall_weight,
            total_weight,
            out=np.zeros_like(total_weight),
            where=total_weight > 0.0,
        )
        wall_added = inventory * wall_share
        bottom_added = np.where(total_weight > 0.0, inventory - wall_added, 0.0)
        self.wall_inventory_native += wall_added
        self.bottom_inventory_native += bottom_added
        return float(np.sum(wall_added)), float(np.sum(bottom_added))

    def accumulate_wet_precipitation(
        self,
        product_concentration: np.ndarray,
        liquid_mask: np.ndarray,
        duration_s: float,
        active_mask: np.ndarray | None = None,
    ) -> DepositFormationResult:
        if not math.isfinite(duration_s) or duration_s <= 0.0:
            raise ValueError("duration_s must be finite and positive")
        deposit_rate = self.wet_product_capture_rate_native_field(
            product_concentration,
            liquid_mask,
            active_mask,
        )
        yield_value = (
            self.parameters.precipitation_yield_mol_deposit_per_mol_product
        )
        inventory = deposit_rate * duration_s
        precipitated = float(np.sum(inventory))
        available_product = precipitated / yield_value
        wall_added, bottom_added = self._split_and_add_collector_inventory(
            inventory
        )
        total = wall_added + bottom_added
        return DepositFormationResult(
            route="wet_supersaturation",
            retained_product_inventory_native=available_product,
            remaining_dissolved_product_inventory_native=0.0,
            precipitable_product_inventory_native=available_product,
            available_product_inventory_native=available_product,
            nondeposit_product_inventory_native=max(
                0.0, available_product - total
            ),
            precipitated_inventory_native=total,
            wall_attached_inventory_native=wall_added,
            bottom_attached_inventory_native=bottom_added,
            solute_retention_fraction=1.0,
            liquid_retention_fraction=1.0,
            precipitation_yield=yield_value,
            diagnostics=self.diagnostics(),
        )

    def precipitate_during_drydown(
        self,
        product_concentration: np.ndarray,
        liquid_mask: np.ndarray,
        *,
        solute_retention_fraction: float,
        liquid_retention_fraction: float,
        additional_trapped_inventory_native: float = 0.0,
        collector_access_mask: np.ndarray | None = None,
    ) -> DepositFormationResult:
        """Concentrate retained dissolved product and attach precipitate.

        ``liquid_retention_fraction`` is the remaining liquid volume divided by
        its pre-drain value.  At zero it represents complete dry-down, so all
        retained product above the route yield is assigned to collectors.
        ``additional_trapped_inventory_native`` can represent a calibrated
        meniscus-retained fraction of cumulative etch product not contained in
        the instantaneous quasi-steady concentration field.

        ``collector_access_mask`` restricts allocation without changing the
        retained or additional trapped inventory.  This permits a same-capture
        comparison between all physical wall/floor collectors and only the
        collectors that were liquid-accessible at a primary-HF endpoint.
        """

        for name, value in (
            ("solute_retention_fraction", solute_retention_fraction),
            ("liquid_retention_fraction", liquid_retention_fraction),
        ):
            if not math.isfinite(value) or not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must lie within [0, 1]")
        if (
            not math.isfinite(additional_trapped_inventory_native)
            or additional_trapped_inventory_native < 0.0
        ):
            raise ValueError(
                "additional_trapped_inventory_native must be non-negative"
            )
        if (
            additional_trapped_inventory_native > 0.0
            and liquid_retention_fraction > 0.0
        ):
            raise ValueError(
                "additional trapped inventory is defined as fully dry-down-"
                "precipitable and therefore requires zero liquid retention"
            )
        product = np.asarray(product_concentration, dtype=float)
        liquid = np.asarray(liquid_mask, dtype=bool)
        if product.shape != self.grid.shape or liquid.shape != self.grid.shape:
            raise ValueError("product and liquid fields must match deposit grid")
        if np.any(~np.isfinite(product)) or np.any(product < 0.0):
            raise ValueError("product concentration must be finite and non-negative")

        trench_liquid = liquid & self.grid.cavity_mask
        retained_concentration = solute_retention_fraction * product
        equilibrium_capacity = (
            self.parameters.saturation_concentration_mol_m3
            * liquid_retention_fraction
        )
        precipitable = np.maximum(
            retained_concentration - equilibrium_capacity,
            0.0,
        )
        precipitable_inventory = (
            precipitable * self.grid.cell_area_nm2
        )
        precipitable_inventory[~trench_liquid] = 0.0
        available = float(np.sum(precipitable_inventory))
        retained_from_field = float(
            np.sum(retained_concentration[trench_liquid])
            * self.grid.cell_area_nm2
        )
        collector_access = trench_liquid.copy()
        if collector_access_mask is not None:
            supplied_access = np.asarray(collector_access_mask, dtype=bool)
            if supplied_access.shape != self.grid.shape:
                raise ValueError(
                    "collector_access_mask must match deposit grid"
                )
            collector_access &= supplied_access
        exposed_collectors = self.collector_mask(collector_access)
        collector_inventory = self._map_inventory_to_nearest_collectors(
            precipitable_inventory,
            exposed_collectors,
        )

        if additional_trapped_inventory_native > 0.0:
            weights = self._weighted_collector_length_nm() * exposed_collectors
            weight_sum = float(np.sum(weights))
            if weight_sum <= 0.0:
                raise RuntimeError("deposit collector has zero total affinity")
            collector_inventory += (
                additional_trapped_inventory_native * weights / weight_sum
            )
            available += additional_trapped_inventory_native
        retained_total = retained_from_field + additional_trapped_inventory_native
        remaining_dissolved = max(0.0, retained_total - available)

        yield_value = (
            self.parameters.precipitation_yield_mol_deposit_per_mol_product
        )
        collector_inventory *= yield_value
        wall_added, bottom_added = self._split_and_add_collector_inventory(
            collector_inventory
        )
        total = wall_added + bottom_added
        return DepositFormationResult(
            route="post_HF_drydown",
            retained_product_inventory_native=retained_total,
            remaining_dissolved_product_inventory_native=remaining_dissolved,
            precipitable_product_inventory_native=available,
            available_product_inventory_native=available,
            nondeposit_product_inventory_native=max(0.0, available - total),
            precipitated_inventory_native=total,
            wall_attached_inventory_native=wall_added,
            bottom_attached_inventory_native=bottom_added,
            solute_retention_fraction=solute_retention_fraction,
            liquid_retention_fraction=liquid_retention_fraction,
            precipitation_yield=yield_value,
            diagnostics=self.diagnostics(),
        )

    def dissolve(
        self,
        duration_s: float,
        *,
        wall_rate_s: float,
        bottom_rate_s: float | None = None,
    ) -> DepositDissolutionResult:
        if not math.isfinite(duration_s) or duration_s < 0.0:
            raise ValueError("duration_s must be finite and non-negative")
        resolved_bottom = wall_rate_s if bottom_rate_s is None else bottom_rate_s
        for name, value in (
            ("wall_rate_s", wall_rate_s),
            ("bottom_rate_s", resolved_bottom),
        ):
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")
        before = float(np.sum(self.total_inventory_native_field))
        self.wall_inventory_native *= math.exp(-wall_rate_s * duration_s)
        self.bottom_inventory_native *= math.exp(-resolved_bottom * duration_s)
        after = float(np.sum(self.total_inventory_native_field))
        return DepositDissolutionResult(
            duration_s=duration_s,
            wall_rate_s=wall_rate_s,
            bottom_rate_s=resolved_bottom,
            before_inventory_native=before,
            removed_inventory_native=max(0.0, before - after),
            after_inventory_native=after,
            diagnostics=self.diagnostics(),
        )

    def diagnostics(self) -> DepositDiagnostics:
        wall_inventory = float(np.sum(self.wall_inventory_native))
        bottom_inventory = float(np.sum(self.bottom_inventory_native))
        total = wall_inventory + bottom_inventory
        wall_thickness = self.wall_thickness_nm
        bottom_thickness = self.bottom_thickness_nm
        wall_length = float(np.sum(self.wall_contact_length_nm))
        bottom_length = float(np.sum(self.bottom_contact_length_nm))
        total_length = wall_length + bottom_length
        # For the represented 1 nm out-of-plane span, contact area in nm2 is
        # numerically equal to contact length in nm.  Keep distinct names in
        # the serialized diagnostics so callers do not accidentally treat a
        # 2-D length as a 3-D area.
        wall_area = wall_length
        bottom_area = bottom_length
        total_area = total_length
        mean_wall = (
            wall_inventory
            / (self.parameters.deposit_molar_density_mol_m3 * wall_length)
            if wall_length > 0.0
            else 0.0
        )
        mean_bottom = (
            bottom_inventory
            / (self.parameters.deposit_molar_density_mol_m3 * bottom_length)
            if bottom_length > 0.0
            else 0.0
        )
        mean_total = (
            total
            / (self.parameters.deposit_molar_density_mol_m3 * total_length)
            if total_length > 0.0
            else 0.0
        )
        maximum_thickness = max(
            float(np.max(wall_thickness, initial=0.0)),
            float(np.max(bottom_thickness, initial=0.0)),
        )
        minimum_cell = min(self.grid.dx_nm, self.grid.dz_nm)
        thickness_ratio = maximum_thickness / minimum_cell

        inventory_field = self.total_inventory_native_field
        positive = inventory_field > 0.0
        if np.any(positive) and total > 0.0:
            centroid = float(
                np.sum(inventory_field * self.grid.depth_mesh_nm) / total
            )
        else:
            centroid = None
        thirds = []
        for low, high in ((0.0, 1.0 / 3.0), (1.0 / 3.0, 2.0 / 3.0), (2.0 / 3.0, 1.0)):
            mask = (
                self.grid.depth_mesh_nm >= low * self.grid.geometry.depth_nm
            ) & (
                self.grid.depth_mesh_nm
                < high * self.grid.geometry.depth_nm
                + (1.0e-12 if high == 1.0 else 0.0)
            )
            thirds.append(
                float(np.sum(inventory_field[mask]) / total)
                if total > 0.0
                else 0.0
            )
        reporting_threshold = 1.0e-12
        wall_coated_length = float(
            np.sum(
                self.wall_contact_length_nm[
                    wall_thickness > reporting_threshold
                ]
            )
        )
        bottom_coated_length = float(
            np.sum(
                self.bottom_contact_length_nm[
                    bottom_thickness > reporting_threshold
                ]
            )
        )
        total_coated_length = wall_coated_length + bottom_coated_length

        reference_thickness = self.parameters.coverage_reference_thickness_nm
        wall_local_coverage = -np.expm1(-wall_thickness / reference_thickness)
        bottom_local_coverage = -np.expm1(
            -bottom_thickness / reference_thickness
        )
        wall_continuous_coverage = (
            float(np.sum(wall_local_coverage * self.wall_contact_length_nm))
            / wall_length
            if wall_length > 0.0
            else 0.0
        )
        bottom_continuous_coverage = (
            float(np.sum(bottom_local_coverage * self.bottom_contact_length_nm))
            / bottom_length
            if bottom_length > 0.0
            else 0.0
        )
        total_continuous_coverage = (
            (
                wall_continuous_coverage * wall_length
                + bottom_continuous_coverage * bottom_length
            )
            / total_length
            if total_length > 0.0
            else 0.0
        )

        # Native inventory is concentration[mol/m3] * cross-sectional
        # area[nm2].  For a 1 nm span, division by collector area and the
        # 1e-9 conversion gives a physical mol/m2 areal inventory.
        wall_density = wall_inventory / wall_area if wall_area > 0.0 else 0.0
        bottom_density = (
            bottom_inventory / bottom_area if bottom_area > 0.0 else 0.0
        )
        total_density = total / total_area if total_area > 0.0 else 0.0
        wall_mol_per_nm_span = (
            wall_inventory * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN
        )
        bottom_mol_per_nm_span = (
            bottom_inventory * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN
        )
        molar_mass = self.parameters.deposit_molar_mass_kg_mol
        wall_mass = (
            wall_mol_per_nm_span * molar_mass
            if molar_mass is not None
            else None
        )
        bottom_mass = (
            bottom_mol_per_nm_span * molar_mass
            if molar_mass is not None
            else None
        )
        total_mass = (
            wall_mass + bottom_mass
            if wall_mass is not None and bottom_mass is not None
            else None
        )
        return DepositDiagnostics(
            species_name=self.parameters.species_name,
            total_inventory_native=total,
            wall_inventory_native=wall_inventory,
            bottom_inventory_native=bottom_inventory,
            total_mol_per_nm_span=(
                total * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN
            ),
            equivalent_cross_section_area_nm2=(
                total / self.parameters.deposit_molar_density_mol_m3
            ),
            fraction_of_initial_gap_fill_area=(
                total
                / self.parameters.deposit_molar_density_mol_m3
                / self.grid.geometry.area_nm2
            ),
            wall_fraction_of_deposit=(wall_inventory / total if total else 0.0),
            bottom_fraction_of_deposit=(
                bottom_inventory / total if total else 0.0
            ),
            mean_wall_thickness_nm=mean_wall,
            maximum_wall_thickness_nm=float(
                np.max(wall_thickness, initial=0.0)
            ),
            mean_bottom_thickness_nm=mean_bottom,
            maximum_bottom_thickness_nm=float(
                np.max(bottom_thickness, initial=0.0)
            ),
            maximum_thickness_over_grid_spacing=thickness_ratio,
            subgrid_validity_warning=(
                thickness_ratio
                >= self.parameters.subgrid_warning_thickness_over_cell
            ),
            wall_coated_length_nm=wall_coated_length,
            bottom_coated_length_nm=bottom_coated_length,
            depth_centroid_nm=centroid,
            upper_middle_lower_inventory_fraction=tuple(thirds),  # type: ignore[arg-type]
            wall_available_contact_area_nm2_for_1nm_span=wall_area,
            bottom_available_contact_area_nm2_for_1nm_span=bottom_area,
            total_available_contact_area_nm2_for_1nm_span=total_area,
            wall_inventory_density_native_per_nm2=wall_density,
            bottom_inventory_density_native_per_nm2=bottom_density,
            total_inventory_density_native_per_nm2=total_density,
            wall_areal_inventory_mol_m2=wall_density * 1.0e-9,
            bottom_areal_inventory_mol_m2=bottom_density * 1.0e-9,
            total_areal_inventory_mol_m2=total_density * 1.0e-9,
            total_mean_thickness_nm=mean_total,
            wall_geometric_coverage_fraction=(
                wall_coated_length / wall_length if wall_length > 0.0 else 0.0
            ),
            bottom_geometric_coverage_fraction=(
                bottom_coated_length / bottom_length
                if bottom_length > 0.0
                else 0.0
            ),
            total_geometric_coverage_fraction=(
                total_coated_length / total_length
                if total_length > 0.0
                else 0.0
            ),
            wall_continuous_coverage_fraction=wall_continuous_coverage,
            bottom_continuous_coverage_fraction=bottom_continuous_coverage,
            total_continuous_coverage_fraction=total_continuous_coverage,
            wall_mean_layer_equivalents=mean_wall / reference_thickness,
            bottom_mean_layer_equivalents=mean_bottom / reference_thickness,
            total_mean_layer_equivalents=mean_total / reference_thickness,
            wall_mass_kg_per_nm_span=wall_mass,
            bottom_mass_kg_per_nm_span=bottom_mass,
            total_mass_kg_per_nm_span=total_mass,
        )

    def copy(self) -> "PersistentDepositPhase2D":
        copied = PersistentDepositPhase2D(self.grid, self.parameters)
        copied.wall_inventory_native[:] = self.wall_inventory_native
        copied.bottom_inventory_native[:] = self.bottom_inventory_native
        return copied


__all__ = [
    "DepositDiagnostics",
    "DepositDissolutionResult",
    "DepositFormationResult",
    "DepositParameters",
    "NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN",
    "PersistentDepositPhase2D",
]

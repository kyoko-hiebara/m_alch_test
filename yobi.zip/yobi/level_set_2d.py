"""Monotonic, conservative interface retreat for GAP FILL dissolution.

The moving front is represented by a cell solid fraction together with a
reinitialised signed-distance field.  Only solid cells sharing a face with the
top-connected liquid may dissolve.  This conservative front tracking is less
geometrically elaborate than a high-order level-set method, but it preserves
area, cannot nucleate remote liquid pockets, and is robust on the deliberately
coarse grids used by the prototype model.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import ndimage

from reaction_diffusion_2d import (
    CartesianGrid2D,
    connected_to_top,
    interface_face_length_on_solid,
)


@dataclass(frozen=True)
class FrontDiagnostics:
    time_s: float
    geometric_cavity_area_nm2: float
    initial_solid_area_nm2: float
    initial_area_discretization_relative_error: float
    remaining_solid_area_nm2: float
    dissolved_area_nm2: float
    remaining_mass_fraction: float
    dissolved_mass_fraction: float
    interface_length_nm: float
    liquid_area_in_trench_nm2: float
    liquid_cells_in_trench: int
    solid_cells: int
    remaining_mass_g_per_nm_length: float | None
    dissolved_mass_g_per_nm_length: float | None


@dataclass(frozen=True)
class FrontStepResult:
    requested_dt_s: float
    applied_dt_s: float
    requested_dissolved_area_nm2: float
    dissolved_area_nm2: float
    newly_liquid_cells: int
    mass_balance_relative_error: float
    diagnostics: FrontDiagnostics
    newly_opened_cells: int = 0


class MonotonicLevelSet2D:
    """Cell-conservative signed-distance front constrained to the trench."""

    def __init__(
        self,
        grid: CartesianGrid2D,
        *,
        solid_density_g_cm3: float | None = None,
        removal_tolerance: float = 1.0e-12,
    ) -> None:
        if solid_density_g_cm3 is not None and (
            not math.isfinite(solid_density_g_cm3) or solid_density_g_cm3 <= 0.0
        ):
            raise ValueError("solid_density_g_cm3 must be finite and positive")
        if not math.isfinite(removal_tolerance) or not 0.0 <= removal_tolerance < 1.0:
            raise ValueError("removal_tolerance must lie in [0, 1)")
        self.grid = grid
        self.solid_density_g_cm3 = solid_density_g_cm3
        self.removal_tolerance = removal_tolerance
        self.solid_fraction = grid.cavity_mask.astype(float)
        self.initial_solid_area_nm2 = float(
            np.sum(self.solid_fraction) * grid.cell_area_nm2
        )
        if self.initial_solid_area_nm2 <= 0.0:
            raise ValueError("the grid contains no GAP FILL cells")
        self.time_s = 0.0
        self.signed_distance_nm = self._signed_distance()

    @property
    def solid_mask(self) -> np.ndarray:
        return self.grid.cavity_mask & (
            self.solid_fraction > self.removal_tolerance
        )

    @property
    def open_void_mask(self) -> np.ndarray:
        """Reservoir plus fully removed cavity cells, irrespective of phase."""

        removed_cavity = self.grid.cavity_mask & ~self.solid_mask
        return self.grid.reservoir_mask | removed_cavity

    @property
    def candidate_liquid_mask(self) -> np.ndarray:
        """Backward-compatible alias for the instant-fill open-void mask."""

        return self.open_void_mask

    @property
    def liquid_mask(self) -> np.ndarray:
        """Top-connected reservoir and dissolved trench cells only."""
        return connected_to_top(self.candidate_liquid_mask)

    def _resolved_liquid_mask(
        self, liquid_mask: np.ndarray | None
    ) -> np.ndarray:
        if liquid_mask is None:
            return self.liquid_mask
        supplied = np.asarray(liquid_mask, dtype=bool)
        if supplied.shape != self.grid.shape:
            raise ValueError("liquid_mask must match the grid")
        if np.any(supplied & ~self.open_void_mask):
            raise ValueError("liquid_mask must be contained in the open void")
        return connected_to_top(supplied)

    def interface_face_length_for(
        self, liquid_mask: np.ndarray | None = None
    ) -> np.ndarray:
        """Liquid-contact length for the requested wet phase."""

        liquid = self._resolved_liquid_mask(liquid_mask)
        return interface_face_length_on_solid(
            self.grid, liquid, self.solid_mask
        )

    def interface_mask_for(
        self, liquid_mask: np.ndarray | None = None
    ) -> np.ndarray:
        return self.interface_face_length_for(liquid_mask) > 0.0

    @property
    def interface_face_length_nm(self) -> np.ndarray:
        return self.interface_face_length_for()

    @property
    def interface_mask(self) -> np.ndarray:
        return self.interface_mask_for()

    def _signed_distance(self) -> np.ndarray:
        """Positive in GAP FILL and negative outside its current binary mask."""
        solid = self.solid_mask
        sampling = (self.grid.dz_nm, self.grid.dx_nm)
        if not np.any(solid):
            return np.full(self.grid.shape, -min(sampling), dtype=float)
        inside = ndimage.distance_transform_edt(solid, sampling=sampling)
        outside = ndimage.distance_transform_edt(~solid, sampling=sampling)
        return inside - outside

    def stable_time_step_s(
        self,
        normal_velocity_nm_s: float | np.ndarray,
        *,
        maximum_fractional_change: float = 0.1,
        liquid_mask: np.ndarray | None = None,
    ) -> float:
        """Return a step limiting the largest interface-cell area change."""
        if (
            not math.isfinite(maximum_fractional_change)
            or not 0.0 < maximum_fractional_change <= 1.0
        ):
            raise ValueError("maximum_fractional_change must lie in (0, 1]")
        velocity = np.broadcast_to(
            np.asarray(normal_velocity_nm_s, dtype=float), self.grid.shape
        )
        if np.any(~np.isfinite(velocity)) or np.any(velocity < 0.0):
            raise ValueError("normal velocity must be finite and non-negative")
        area_rate = velocity * self.interface_face_length_for(liquid_mask)
        active = area_rate > 0.0
        if not np.any(active):
            return math.inf
        # A partially consumed interface cell may contain less material than
        # the nominal fractional-change allowance.  Limit against that actual
        # remainder so ``advance`` never clips an over-request.  Besides front
        # accuracy, this keeps time-integrated interfacial product generation
        # consistent with the material that was truly removed.
        allowable_fraction = np.minimum(
            maximum_fractional_change,
            self.solid_fraction,
        )
        stable_by_cell = np.full(self.grid.shape, math.inf, dtype=float)
        stable_by_cell[active] = (
            allowable_fraction[active]
            * self.grid.cell_area_nm2
            / area_rate[active]
        )
        return float(np.min(stable_by_cell))

    def diagnostics(
        self, liquid_mask: np.ndarray | None = None
    ) -> FrontDiagnostics:
        remaining_area = float(
            np.sum(self.solid_fraction) * self.grid.cell_area_nm2
        )
        dissolved_area = max(0.0, self.initial_solid_area_nm2 - remaining_area)
        remaining_fraction = float(
            np.clip(remaining_area / self.initial_solid_area_nm2, 0.0, 1.0)
        )
        liquid = self._resolved_liquid_mask(liquid_mask)
        liquid_in_trench = liquid & self.grid.cavity_mask
        interface_length = float(
            np.sum(self.interface_face_length_for(liquid))
        )
        remaining_mass = None
        dissolved_mass = None
        if self.solid_density_g_cm3 is not None:
            # One square nanometre of cross-section times one nanometre of
            # out-of-plane length is 1e-21 cm^3.
            remaining_mass = self.solid_density_g_cm3 * remaining_area * 1.0e-21
            dissolved_mass = self.solid_density_g_cm3 * dissolved_area * 1.0e-21
        return FrontDiagnostics(
            time_s=self.time_s,
            geometric_cavity_area_nm2=self.grid.geometry.area_nm2,
            initial_solid_area_nm2=self.initial_solid_area_nm2,
            initial_area_discretization_relative_error=abs(
                self.initial_solid_area_nm2 - self.grid.geometry.area_nm2
            )
            / self.grid.geometry.area_nm2,
            remaining_solid_area_nm2=remaining_area,
            dissolved_area_nm2=dissolved_area,
            remaining_mass_fraction=remaining_fraction,
            dissolved_mass_fraction=1.0 - remaining_fraction,
            interface_length_nm=interface_length,
            liquid_area_in_trench_nm2=float(
                np.count_nonzero(liquid_in_trench) * self.grid.cell_area_nm2
            ),
            liquid_cells_in_trench=int(np.count_nonzero(liquid_in_trench)),
            solid_cells=int(np.count_nonzero(self.solid_mask)),
            remaining_mass_g_per_nm_length=remaining_mass,
            dissolved_mass_g_per_nm_length=dissolved_mass,
        )

    def advance(
        self,
        normal_velocity_nm_s: float | np.ndarray,
        dt_s: float,
        *,
        liquid_mask: np.ndarray | None = None,
    ) -> FrontStepResult:
        """Advance exposed cells without allowing solid re-growth.

        Callers should normally restrict ``dt_s`` with
        :meth:`stable_time_step_s`.  If a larger step is supplied, removal is
        capped at the material remaining in each currently exposed cell; the
        excess is not teleported into the next solid layer.
        """
        if not math.isfinite(dt_s) or dt_s <= 0.0:
            raise ValueError("dt_s must be finite and positive")
        velocity = np.broadcast_to(
            np.asarray(normal_velocity_nm_s, dtype=float), self.grid.shape
        )
        if np.any(~np.isfinite(velocity)) or np.any(velocity < 0.0):
            raise ValueError("normal velocity must be finite and non-negative")

        # Preserve the cellwise state so a small final removal is not recovered
        # by subtracting two nearly equal, trench-scale area totals below.
        # The latter loses several significant digits once only a tiny sliver
        # of material remains.
        before_solid_fraction = self.solid_fraction.copy()
        before_open_void = self.open_void_mask.copy()
        before_liquid = self._resolved_liquid_mask(liquid_mask).copy()
        face_length = self.interface_face_length_for(before_liquid)
        requested_area_by_cell = velocity * face_length * dt_s
        requested_fraction = requested_area_by_cell / self.grid.cell_area_nm2
        requested_fraction = np.where(
            face_length > 0.0, requested_fraction, 0.0
        )
        removed_fraction = np.minimum(requested_fraction, self.solid_fraction)
        self.solid_fraction -= removed_fraction
        self.solid_fraction = np.clip(self.solid_fraction, 0.0, 1.0)
        self.solid_fraction[
            self.solid_fraction <= self.removal_tolerance
        ] = 0.0
        # Cells outside the physical cavity are immutable Si, never GAP FILL.
        self.solid_fraction[~self.grid.cavity_mask] = 0.0
        self.time_s += dt_s
        self.signed_distance_nm = self._signed_distance()

        realized_removed_fraction = (
            before_solid_fraction - self.solid_fraction
        )
        dissolved = max(
            0.0,
            float(
                np.sum(realized_removed_fraction, dtype=np.longdouble)
                * np.longdouble(self.grid.cell_area_nm2)
            ),
        )
        accounted = float(
            np.sum(removed_fraction, dtype=np.longdouble)
            * np.longdouble(self.grid.cell_area_nm2)
        )
        balance_scale = max(dissolved, accounted, 1.0e-30)
        balance_error = abs(dissolved - accounted) / balance_scale
        after_liquid = (
            self.liquid_mask
            if liquid_mask is None
            else connected_to_top(before_liquid & self.open_void_mask)
        )
        newly_liquid = int(
            np.count_nonzero(
                after_liquid & self.grid.cavity_mask & ~before_liquid
            )
        )
        newly_opened = int(
            np.count_nonzero(
                self.open_void_mask
                & self.grid.cavity_mask
                & ~before_open_void
            )
        )
        return FrontStepResult(
            requested_dt_s=dt_s,
            applied_dt_s=dt_s,
            requested_dissolved_area_nm2=float(np.sum(requested_area_by_cell)),
            dissolved_area_nm2=dissolved,
            newly_liquid_cells=newly_liquid,
            mass_balance_relative_error=float(balance_error),
            diagnostics=self.diagnostics(liquid_mask=after_liquid),
            newly_opened_cells=newly_opened,
        )

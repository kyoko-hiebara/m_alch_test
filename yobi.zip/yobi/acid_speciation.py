"""Strong-acid (H2SO4) addition to dilute HF: 25 degC speciation screen.

The repository already converts a dilute HF weight percent into the Hamer--Wu
25 degC equilibrium composition (``literature_parameters``).  That table is for
HF in water only, so it cannot answer what happens when a strong acid is mixed
in.  This module extends it *without introducing an independent equilibrium
data set*: the two HF equilibrium constants are recovered from the same
tabulated rows, and only the bisulfate constant is brought in from outside.

Equilibria at 25 degC (molality basis, per kg of solvent):

    HF          <-> H+ + F-        Ka1   (thermodynamic, activity basis)
    HF + F-     <-> HF2-           K2    (concentration quotient)
    HSO4-       <-> H+ + SO4(2-)   Ka2   (thermodynamic, activity basis)
    H2SO4       ->  H+ + HSO4-     complete

Singly-charged activity coefficients use a Davies form,

    log10 gamma(z) = -A z^2 (sqrt(I) / (1 + sqrt(I)) - b I),

with ``A = 0.5092`` at 25 degC.  ``Ka1`` and ``b`` are fitted to the tabulated
rows; ``K2`` is taken as a concentration quotient because the table itself
shows it constant to 5e-4 relative across the whole range (one singly-charged
species on each side, so the coefficients cancel).  Recovering ``Ka1`` this way
returns ``pKa1 = 3.167``, which is the accepted aqueous HF value -- that
agreement is a consistency check on the extraction, not an input.

**This is a solution-chemistry screen, not an etch-rate prediction.**  It
reports how the concentration of each candidate reactive species moves when a
strong acid is added.  Converting that into an etch rate requires a rate law,
and the competing rate laws disagree in *sign*; ``relative_rate_response``
returns all of them side by side rather than selecting one.  Sulfate/fluoride
complexation, HF oligomers above the tabulated range, viscosity and diffusivity
changes, temperatures other than 25 degC, and any surface process are outside
this model.

The tabulated support ends at ionic strength ``0.032 mol/kg``.  Process-relevant
H2SO4 additions exceed it, so results above that are labelled ``extrapolated``
and are reported through two activity models whose spread is the stated
uncertainty band.  Above ``MAXIMUM_IONIC_STRENGTH`` the fitted Davies form is
demonstrably non-monotone and the calculation is refused rather than reported.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass

import numpy as np
from scipy.optimize import brentq, least_squares

from literature_parameters import (
    HF_MOLAR_MASS_KG_MOL,
    WATER_DENSITY_298_KG_M3,
    _BIFLUORIDE_TABLE,
    _FLUORIDE_TABLE,
    _HF_MOLALITY_TABLE,
    _NEUTRAL_HF_TABLE,
)


SCHEMA_VERSION = "hf-strong-acid-speciation-screen/v1"
MODEL_NOTICE = (
    "25 degC aqueous HF + strong-acid speciation screen. The HF acidity "
    "constant, the bifluoride quotient and the Davies parameter are recovered "
    "from the Hamer-Wu table already used by literature_parameters; only the "
    "bisulfate constant is external. This returns species concentrations and "
    "the response of competing candidate rate laws, not an etch rate. "
    "Sulfate-fluoride complexation, viscosity and diffusivity changes, HF "
    "oligomers, non-298.15 K operation, and every surface process are outside "
    "the model. Additions that carry the ionic strength past the tabulated "
    "support are labelled extrapolated and bracketed by two activity models."
)

# Debye--Huckel A for water at 25 degC, (kg/mol)^(1/2).
DEBYE_HUCKEL_A_298 = 0.5092

# Second acidity constant of sulfuric acid at 25 degC (activity basis).  This
# is the one constant not recoverable from the HF table, so it is declared
# separately and carried into the output metadata.
BISULFATE_KA2_298 = 1.02e-2
BISULFATE_SOURCE = (
    "HSO4- second acidity constant at 25 degC, pKa2 = 1.99; standard aqueous "
    "value, external to the Hamer-Wu HF table"
)

# Ionic strength of the most concentrated tabulated row.  Beyond this the
# activity model is extrapolated.
TABULATED_MAXIMUM_IONIC_STRENGTH = 0.032

# The fitted Davies form folds back (fluoride stops decreasing with added
# acid) above this.  Refuse rather than report a turning point that is an
# artefact of extrapolating a two-parameter fit.
MAXIMUM_IONIC_STRENGTH = 0.30

_SUPPORT_WITHIN = "within_tabulated_support"
_SUPPORT_EXTRAPOLATED = "extrapolated_beyond_tabulated_support"


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def _finite_nonnegative(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    return number


@dataclass(frozen=True)
class ActivityModel:
    """Davies-form activity model for singly-charged ions at 25 degC."""

    name: str
    davies_b: float
    hf_acidity_constant: float
    bifluoride_quotient: float
    maximum_table_residual: float
    fitted_from_table: bool

    def excess_term(self, ionic_strength_mol_kg: float) -> float:
        """Return ``sqrt(I)/(1+sqrt(I)) - b I``."""

        strength = _finite_nonnegative(
            "ionic_strength_mol_kg", ionic_strength_mol_kg
        )
        root = math.sqrt(strength)
        return root / (1.0 + root) - self.davies_b * strength

    def log10_gamma(self, charge: int, ionic_strength_mol_kg: float) -> float:
        return (
            -DEBYE_HUCKEL_A_298
            * float(charge) ** 2
            * self.excess_term(ionic_strength_mol_kg)
        )

    def hf_quotient(self, ionic_strength_mol_kg: float) -> float:
        """Concentration quotient ``[H+][F-]/[HF]`` at this ionic strength.

        ``HF`` is neutral, so only the two singly-charged products carry an
        activity coefficient.
        """

        excess = self.excess_term(ionic_strength_mol_kg)
        return self.hf_acidity_constant * 10.0 ** (
            2.0 * DEBYE_HUCKEL_A_298 * excess
        )

    def bisulfate_quotient(self, ionic_strength_mol_kg: float) -> float:
        """Concentration quotient ``[H+][SO4(2-)]/[HSO4-]``.

        Charges are ``+1``, ``-2`` and ``-1``, so the coefficient ratio is
        ``gamma(1)^-1 gamma(2)^-1 gamma(1)``, i.e. a ``4 A`` exponent.
        """

        excess = self.excess_term(ionic_strength_mol_kg)
        return BISULFATE_KA2_298 * 10.0 ** (
            4.0 * DEBYE_HUCKEL_A_298 * excess
        )

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _balanced_table() -> tuple[np.ndarray, ...]:
    """Return the tabulated rows rescaled to conserve analytical fluorine.

    ``literature_parameters`` applies the same sub-0.01% rescaling before use,
    so the constants must be extracted from the rescaled rows to stay
    consistent with the speciation the rest of the repository already uses.
    """

    molality = np.asarray(_HF_MOLALITY_TABLE, dtype=float)
    neutral = np.asarray(_NEUTRAL_HF_TABLE, dtype=float)
    fluoride = np.asarray(_FLUORIDE_TABLE, dtype=float)
    bifluoride = np.asarray(_BIFLUORIDE_TABLE, dtype=float)
    scale = molality / (neutral + fluoride + 2.0 * bifluoride)
    return (
        molality,
        neutral * scale,
        fluoride * scale,
        bifluoride * scale,
    )


def _fit_activity_model(
    *,
    name: str,
    fixed_davies_b: float | None,
) -> ActivityModel:
    """Recover ``Ka1`` (and optionally ``b``) from the tabulated rows."""

    molality, neutral, fluoride, bifluoride = _balanced_table()
    # Pure HF: charge neutrality with OH- neglected, as in the existing
    # converter.  For 1:1 ions the ionic strength equals the proton molality.
    proton = fluoride + bifluoride
    strength = proton
    quotient = proton * fluoride / neutral

    def residual(parameters: np.ndarray) -> np.ndarray:
        log_ka = float(parameters[0])
        davies_b = (
            float(fixed_davies_b)
            if fixed_davies_b is not None
            else float(parameters[1])
        )
        root = np.sqrt(strength)
        excess = root / (1.0 + root) - davies_b * strength
        gamma_squared = (
            10.0 ** (-DEBYE_HUCKEL_A_298 * excess)
        ) ** 2
        return np.log(quotient * gamma_squared) - log_ka

    guess = (
        np.asarray([math.log(6.8e-4)], dtype=float)
        if fixed_davies_b is not None
        else np.asarray([math.log(6.8e-4), 0.3], dtype=float)
    )
    solution = least_squares(residual, guess)
    log_ka = float(solution.x[0])
    davies_b = (
        float(fixed_davies_b)
        if fixed_davies_b is not None
        else float(solution.x[1])
    )
    max_residual = float(
        np.max(np.abs(np.exp(residual(solution.x)) - 1.0))
    )

    # The bifluoride association quotient is constant across the table to
    # within 5e-4 relative, so it is carried as a concentration quotient.
    association = bifluoride / (neutral * fluoride)
    return ActivityModel(
        name=name,
        davies_b=davies_b,
        hf_acidity_constant=math.exp(log_ka),
        bifluoride_quotient=float(np.mean(association)),
        maximum_table_residual=max_residual,
        fitted_from_table=fixed_davies_b is None,
    )


def table_fitted_activity_model() -> ActivityModel:
    """Both ``Ka1`` and the Davies ``b`` fitted to the table."""

    return _fit_activity_model(name="table_fitted_b", fixed_davies_b=None)


def conventional_davies_activity_model() -> ActivityModel:
    """``Ka1`` fitted with the Davies ``b`` held at its conventional 0.3.

    The tabulated ionic strengths span only ``0.0024--0.032 mol/kg``, so the
    two fitted parameters are strongly correlated and ``b`` is poorly
    determined.  Holding ``b`` at the conventional value gives a second, equally
    defensible extrapolation; the spread between the two is reported as the
    uncertainty band rather than quoting either alone.
    """

    return _fit_activity_model(name="conventional_davies_b", fixed_davies_b=0.3)


def bifluoride_quotient_spread() -> float:
    """Relative spread of ``K2`` across the tabulated rows."""

    _, neutral, fluoride, bifluoride = _balanced_table()
    association = bifluoride / (neutral * fluoride)
    return float(association.max() / association.min() - 1.0)


@dataclass(frozen=True)
class AcidifiedSpeciation:
    """25 degC composition of a dilute HF solution with added strong acid."""

    analytical_fluorine_mol_kg: float
    added_sulfuric_acid_mol_kg: float
    activity_model: str
    proton_mol_kg: float
    neutral_hf_mol_kg: float
    fluoride_mol_kg: float
    bifluoride_mol_kg: float
    bisulfate_mol_kg: float
    sulfate_mol_kg: float
    ionic_strength_mol_kg: float
    ph: float
    support_status: str
    fluorine_balance_residual: float
    charge_balance_residual: float

    def to_dict(self) -> dict[str, object]:
        return asdict(self)

    def in_mol_m3(
        self,
        *,
        solvent_density_kg_m3: float = WATER_DENSITY_298_KG_M3,
    ) -> dict[str, float]:
        """Convert molalities to mol/m3 for the continuum boundary values.

        The dilute-solution convention of ``literature_parameters`` is kept:
        the solvent mass per cubic metre is used as the conversion factor.
        """

        density = _finite_positive(
            "solvent_density_kg_m3", solvent_density_kg_m3
        )
        return {
            "neutral_hf_mol_m3": self.neutral_hf_mol_kg * density,
            "fluoride_mol_m3": self.fluoride_mol_kg * density,
            "bifluoride_mol_m3": self.bifluoride_mol_kg * density,
            "hydronium_mol_m3": self.proton_mol_kg * density,
            "analytical_fluorine_mol_m3": (
                self.analytical_fluorine_mol_kg * density
            ),
        }


def _species_at(
    proton: float,
    ionic_strength: float,
    fluorine_total: float,
    sulfur_total: float,
    model: ActivityModel,
) -> tuple[float, float, float, float, float]:
    """Return ``(F-, HF, HF2-, HSO4-, SO4(2-))`` at fixed ``H+`` and ``I``.

    With ``H+`` and ``I`` fixed, the fluorine balance is a quadratic in
    ``[F-]``; the positive root is taken in a form that stays accurate when the
    bifluoride term is small.
    """

    quotient = model.hf_quotient(ionic_strength)
    bisulfate_quotient = model.bisulfate_quotient(ionic_strength)
    quadratic = 2.0 * model.bifluoride_quotient * proton / quotient
    linear = proton / quotient + 1.0
    if quadratic > 0.0:
        fluoride = (2.0 * fluorine_total) / (
            linear + math.sqrt(linear * linear + 4.0 * quadratic * fluorine_total)
        )
    else:
        fluoride = fluorine_total / linear
    neutral = proton * fluoride / quotient
    bifluoride = model.bifluoride_quotient * neutral * fluoride
    if sulfur_total > 0.0:
        sulfate = sulfur_total * bisulfate_quotient / (
            bisulfate_quotient + proton
        )
        bisulfate = sulfur_total * proton / (bisulfate_quotient + proton)
    else:
        sulfate = 0.0
        bisulfate = 0.0
    return fluoride, neutral, bifluoride, bisulfate, sulfate


def solve_acidified_speciation(
    *,
    analytical_fluorine_mol_kg: float,
    added_sulfuric_acid_mol_kg: float = 0.0,
    activity_model: ActivityModel | None = None,
    maximum_iterations: int = 200,
    ionic_strength_tolerance: float = 1.0e-13,
) -> AcidifiedSpeciation:
    """Solve the coupled HF / bisulfate equilibrium at 25 degC.

    The charge-balance residual is monotone in ``[H+]`` at fixed ionic
    strength, so an inner bracketed root solve is nested inside a damped
    fixed-point iteration on the ionic strength.
    """

    fluorine_total = _finite_positive(
        "analytical_fluorine_mol_kg", analytical_fluorine_mol_kg
    )
    sulfur_total = _finite_nonnegative(
        "added_sulfuric_acid_mol_kg", added_sulfuric_acid_mol_kg
    )
    model = activity_model or table_fitted_activity_model()

    strength = max(1.0e-6, 0.5 * (0.1 * fluorine_total + 3.0 * sulfur_total))
    proton = strength
    for _ in range(int(maximum_iterations)):

        def charge_residual(log_proton: float) -> float:
            trial = math.exp(log_proton)
            fluoride, _, bifluoride, bisulfate, sulfate = _species_at(
                trial, strength, fluorine_total, sulfur_total, model
            )
            return trial - (
                fluoride + bifluoride + bisulfate + 2.0 * sulfate
            )

        proton = math.exp(
            brentq(
                charge_residual,
                math.log(1.0e-12),
                math.log(50.0),
                xtol=1.0e-15,
                rtol=8.9e-16,
            )
        )
        fluoride, neutral, bifluoride, bisulfate, sulfate = _species_at(
            proton, strength, fluorine_total, sulfur_total, model
        )
        updated = 0.5 * (
            proton + fluoride + bifluoride + bisulfate + 4.0 * sulfate
        )
        if abs(updated - strength) <= ionic_strength_tolerance * max(
            1.0, updated
        ):
            strength = updated
            break
        strength = 0.5 * strength + 0.5 * updated
    else:
        raise RuntimeError(
            "ionic-strength iteration did not converge; the requested "
            "composition is outside the usable range of this screen"
        )

    if strength > MAXIMUM_IONIC_STRENGTH:
        raise ValueError(
            f"ionic strength {strength:.4g} mol/kg exceeds the "
            f"{MAXIMUM_IONIC_STRENGTH:g} mol/kg limit of this screen; the "
            "fitted Davies form is non-monotone beyond it and the result "
            "would be an extrapolation artefact rather than a prediction"
        )

    fluoride, neutral, bifluoride, bisulfate, sulfate = _species_at(
        proton, strength, fluorine_total, sulfur_total, model
    )
    return AcidifiedSpeciation(
        analytical_fluorine_mol_kg=fluorine_total,
        added_sulfuric_acid_mol_kg=sulfur_total,
        activity_model=model.name,
        proton_mol_kg=proton,
        neutral_hf_mol_kg=neutral,
        fluoride_mol_kg=fluoride,
        bifluoride_mol_kg=bifluoride,
        bisulfate_mol_kg=bisulfate,
        sulfate_mol_kg=sulfate,
        ionic_strength_mol_kg=strength,
        ph=-math.log10(proton),
        support_status=(
            _SUPPORT_WITHIN
            if strength <= TABULATED_MAXIMUM_IONIC_STRENGTH
            else _SUPPORT_EXTRAPOLATED
        ),
        fluorine_balance_residual=(
            (neutral + fluoride + 2.0 * bifluoride) / fluorine_total - 1.0
        ),
        charge_balance_residual=(
            proton - (fluoride + bifluoride + bisulfate + 2.0 * sulfate)
        ),
    )


def weight_percent_to_fluorine_molality(hf_weight_percent: float) -> float:
    """Analytical fluorine molality of a dilute HF solution."""

    percent = _finite_positive("hf_weight_percent", hf_weight_percent)
    if percent >= 100.0:
        raise ValueError("hf_weight_percent must be below 100")
    mass_fraction = percent / 100.0
    return mass_fraction / HF_MOLAR_MASS_KG_MOL / (1.0 - mass_fraction)


SULFURIC_ACID_MOLAR_MASS_KG_MOL = 0.098079


def sulfuric_weight_percent_to_molality(weight_percent: float) -> float:
    """Added-H2SO4 molality from its weight percent of the solution."""

    percent = _finite_nonnegative("weight_percent", weight_percent)
    if percent >= 100.0:
        raise ValueError("weight_percent must be below 100")
    mass_fraction = percent / 100.0
    return (
        mass_fraction
        / SULFURIC_ACID_MOLAR_MASS_KG_MOL
        / (1.0 - mass_fraction)
    )


def sulfuric_molality_to_weight_percent(molality_mol_kg: float) -> float:
    """Inverse of :func:`sulfuric_weight_percent_to_molality`."""

    molality = _finite_nonnegative("molality_mol_kg", molality_mol_kg)
    mass_per_kg_solvent = molality * SULFURIC_ACID_MOLAR_MASS_KG_MOL
    return 100.0 * mass_per_kg_solvent / (1.0 + mass_per_kg_solvent)


# --- candidate rate laws -------------------------------------------------
#
# These are the rate laws the graph-KMC ``SpeciesActivitySpec`` can already
# express (total HF, bifluoride, fluoride, protonated site fraction).  They are
# listed together because they predict *opposite signs* for added strong acid,
# which is what makes the plant observation informative.  None of them is
# selected here.

RATE_LAW_KEYS = (
    "neutral_hf",
    "bifluoride",
    "fluoride",
    "proton_assisted_hf",
)


def protonated_site_fraction(
    proton_mol_kg: float,
    surface_protonation_constant_kg_mol: float,
) -> float:
    """Langmuir surface protonation fraction ``K[H+] / (1 + K[H+])``.

    ``K`` is not known for these films.  It is swept rather than assumed: the
    first-order and saturated limits bracket every possible proton dependence,
    and a plant response that is only weakly sensitive to added acid implies
    either a small proton order or a surface already close to saturation.
    """

    proton = _finite_nonnegative("proton_mol_kg", proton_mol_kg)
    constant = _finite_nonnegative(
        "surface_protonation_constant_kg_mol",
        surface_protonation_constant_kg_mol,
    )
    product = constant * proton
    return product / (1.0 + product)


def relative_rate_response(
    reference: AcidifiedSpeciation,
    acidified: AcidifiedSpeciation,
    *,
    surface_protonation_constants_kg_mol: tuple[float, ...] = (0.1, 1.0, 10.0),
) -> dict[str, object]:
    """Rate ratio of ``acidified`` to ``reference`` under each candidate law.

    Every law is first order in its own species so that the comparison is
    between mechanisms rather than between fitted orders.  The proton-assisted
    law is reported once per swept surface constant.
    """

    if reference.activity_model != acidified.activity_model:
        raise ValueError(
            "reference and acidified speciation must use the same activity "
            "model; comparing across models mixes the uncertainty band into "
            "the mechanism response"
        )
    response: dict[str, object] = {
        "neutral_hf": acidified.neutral_hf_mol_kg / reference.neutral_hf_mol_kg,
        "bifluoride": (
            acidified.bifluoride_mol_kg / reference.bifluoride_mol_kg
        ),
        "fluoride": acidified.fluoride_mol_kg / reference.fluoride_mol_kg,
    }
    proton_assisted: dict[str, float] = {}
    for constant in surface_protonation_constants_kg_mol:
        numerator = acidified.neutral_hf_mol_kg * protonated_site_fraction(
            acidified.proton_mol_kg, constant
        )
        denominator = reference.neutral_hf_mol_kg * protonated_site_fraction(
            reference.proton_mol_kg, constant
        )
        proton_assisted[f"K={constant:g}"] = numerator / denominator
    response["proton_assisted_hf"] = proton_assisted
    response["predicted_sign"] = {
        "neutral_hf": _sign_label(float(response["neutral_hf"])),
        "bifluoride": _sign_label(float(response["bifluoride"])),
        "fluoride": _sign_label(float(response["fluoride"])),
        "proton_assisted_hf": _sign_label(
            min(proton_assisted.values())
        ),
    }
    return response


def _sign_label(ratio: float, *, tolerance: float = 0.10) -> str:
    if ratio > 1.0 + tolerance:
        return "faster"
    if ratio < 1.0 - tolerance:
        return "slower"
    return "within_10_percent"


__all__ = [
    "BISULFATE_KA2_298",
    "BISULFATE_SOURCE",
    "DEBYE_HUCKEL_A_298",
    "MAXIMUM_IONIC_STRENGTH",
    "MODEL_NOTICE",
    "RATE_LAW_KEYS",
    "SCHEMA_VERSION",
    "SULFURIC_ACID_MOLAR_MASS_KG_MOL",
    "TABULATED_MAXIMUM_IONIC_STRENGTH",
    "AcidifiedSpeciation",
    "ActivityModel",
    "bifluoride_quotient_spread",
    "conventional_davies_activity_model",
    "protonated_site_fraction",
    "relative_rate_response",
    "solve_acidified_speciation",
    "sulfuric_molality_to_weight_percent",
    "sulfuric_weight_percent_to_molality",
    "table_fitted_activity_model",
    "weight_percent_to_fluorine_molality",
]

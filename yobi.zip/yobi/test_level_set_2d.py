from __future__ import annotations

import math
import unittest

import numpy as np

from level_set_2d import MonotonicLevelSet2D
from reaction_diffusion_2d import CartesianGrid2D, connected_to_top
from trench_geometry import TaperedTrench2D


class LevelSet2DTests(unittest.TestCase):
    def setUp(self) -> None:
        geometry = TaperedTrench2D("toy", 8.0, 6.0, 20.0)
        self.grid = CartesianGrid2D.from_geometry(
            geometry,
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
        )
        self.front = MonotonicLevelSet2D(
            self.grid, solid_density_g_cm3=3.0
        )

    def test_initial_state_is_fully_filled_and_signed(self) -> None:
        self.assertTrue(np.all(self.front.solid_fraction[self.grid.cavity_mask] == 1.0))
        self.assertFalse(np.any(self.front.liquid_mask & self.grid.cavity_mask))
        self.assertTrue(np.all(self.front.signed_distance_nm[self.front.solid_mask] > 0.0))
        self.assertTrue(
            np.all(self.front.signed_distance_nm[self.grid.reservoir_mask] < 0.0)
        )
        diagnostics = self.front.diagnostics()
        self.assertEqual(diagnostics.dissolved_area_nm2, 0.0)
        self.assertEqual(diagnostics.remaining_mass_fraction, 1.0)
        self.assertIsNotNone(diagnostics.remaining_mass_g_per_nm_length)
        self.assertGreater(diagnostics.geometric_cavity_area_nm2, 0.0)
        self.assertGreaterEqual(
            diagnostics.initial_area_discretization_relative_error, 0.0
        )

    def test_constant_velocity_removes_only_exposed_top_cells(self) -> None:
        before_solid = self.front.solid_mask.copy()
        stable = self.front.stable_time_step_s(
            1.0, maximum_fractional_change=1.0
        )
        self.assertAlmostEqual(stable, 2.0)
        result = self.front.advance(1.0, stable)
        self.assertGreater(result.newly_liquid_cells, 0)
        self.assertEqual(
            result.newly_opened_cells,
            result.newly_liquid_cells,
        )
        self.assertGreater(result.dissolved_area_nm2, 0.0)
        self.assertLess(result.mass_balance_relative_error, 1.0e-12)
        removed = before_solid & ~self.front.solid_mask
        self.assertTrue(np.all(removed <= self.grid.cavity_mask))
        self.assertTrue(np.array_equal(self.front.liquid_mask, connected_to_top(self.front.liquid_mask)))

    def test_small_removal_mass_balance_avoids_global_area_cancellation(self) -> None:
        result = self.front.advance(1.0, 1.0e-5)

        self.assertAlmostEqual(
            result.dissolved_area_nm2,
            result.requested_dissolved_area_nm2,
            places=12,
        )
        self.assertLess(result.mass_balance_relative_error, 1.0e-10)

    def test_interior_velocity_cannot_nucleate_liquid(self) -> None:
        velocity = np.zeros(self.grid.shape)
        deepest_row = np.flatnonzero(self.grid.cavity_mask)[-1] // self.grid.shape[1]
        column = np.flatnonzero(self.grid.cavity_mask[deepest_row])[0]
        velocity[deepest_row, column] = 100.0
        before = self.front.solid_fraction.copy()
        result = self.front.advance(velocity, 1.0)
        np.testing.assert_array_equal(self.front.solid_fraction, before)
        self.assertEqual(result.newly_liquid_cells, 0)
        self.assertEqual(result.dissolved_area_nm2, 0.0)

    def test_stable_step_respects_material_left_in_a_partial_cell(self) -> None:
        interface = self.front.interface_mask
        row, column = np.argwhere(interface)[0]
        self.front.solid_fraction[row, column] = 0.25

        stable = self.front.stable_time_step_s(
            1.0, maximum_fractional_change=0.75
        )
        face_length = self.front.interface_face_length_nm[row, column]
        expected = (
            0.25 * self.grid.cell_area_nm2 / face_length
        )

        self.assertAlmostEqual(stable, expected)
        result = self.front.advance(1.0, stable)
        self.assertAlmostEqual(
            result.requested_dissolved_area_nm2,
            result.dissolved_area_nm2,
        )

    def test_area_and_uniform_density_mass_diagnostics_are_monotonic(self) -> None:
        areas = [self.front.diagnostics().remaining_solid_area_nm2]
        masses = [self.front.diagnostics().remaining_mass_g_per_nm_length]
        for _ in range(4):
            self.front.advance(1.0, 0.5)
            diagnostics = self.front.diagnostics()
            areas.append(diagnostics.remaining_solid_area_nm2)
            masses.append(diagnostics.remaining_mass_g_per_nm_length)
        self.assertTrue(all(first >= second for first, second in zip(areas, areas[1:])))
        self.assertTrue(all(first >= second for first, second in zip(masses, masses[1:])))
        expected = 3.0 * areas[-1] * 1.0e-21
        self.assertAlmostEqual(masses[-1], expected)
        self.assertAlmostEqual(
            self.front.diagnostics().dissolved_mass_fraction,
            1.0 - areas[-1] / areas[0],
        )

    def test_supplied_dry_void_cannot_expose_or_remove_solid(self) -> None:
        # First create one fully open cavity layer with the legacy instant-fill
        # rule, then deliberately retain liquid only in the reservoir.
        stable = self.front.stable_time_step_s(
            1.0, maximum_fractional_change=1.0
        )
        self.front.advance(1.0, stable)
        dry_phase = self.grid.reservoir_mask.copy()
        before = self.front.solid_fraction.copy()

        self.assertFalse(np.any(self.front.interface_mask_for(dry_phase)))
        self.assertTrue(
            math.isinf(
                self.front.stable_time_step_s(10.0, liquid_mask=dry_phase)
            )
        )
        result = self.front.advance(10.0, 1.0, liquid_mask=dry_phase)

        np.testing.assert_array_equal(self.front.solid_fraction, before)
        self.assertEqual(result.dissolved_area_nm2, 0.0)
        self.assertEqual(result.newly_opened_cells, 0)


if __name__ == "__main__":
    unittest.main()

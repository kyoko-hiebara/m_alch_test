#!/usr/bin/env python3
"""Run the provisional Kawarazaki Fig. 2 dual-channel blanket model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from literature_parameters import KAWARAZAKI_2024_FIG2_ENDPOINTS
from ozone_dhf_linear_model import (
    OzoneDHFLinearConfig,
    run_ozone_dhf_linear_model,
    save_ozone_dhf_linear_json,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Linearly scale Kawarazaki Fig. 2 dHF-only 30 s endpoints and "
            "fixed ozone/dHF cycle endpoints. This is not a process recipe."
        )
    )
    parser.add_argument(
        "--endpoint",
        choices=tuple(KAWARAZAKI_2024_FIG2_ENDPOINTS),
        action="append",
        help="repeat to select films (default: all four Fig. 2 films)",
    )
    parser.add_argument(
        "--dhf-duration-s",
        type=float,
        action="append",
        help="repeat to select dHF-only prediction times (default: 30, 60, 120)",
    )
    parser.add_argument(
        "--cycles",
        type=int,
        action="append",
        help="repeat to select fixed ozone/dHF cycle counts (default: 1, 2, 3)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="optional strict JSON output path",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config = OzoneDHFLinearConfig(
        endpoint_ids=tuple(
            dict.fromkeys(
                args.endpoint or tuple(KAWARAZAKI_2024_FIG2_ENDPOINTS)
            )
        ),
        dhf_only_durations_s=tuple(
            dict.fromkeys(args.dhf_duration_s or (30.0, 60.0, 120.0))
        ),
        cycle_counts=tuple(dict.fromkeys(args.cycles or (1, 2, 3))),
    )
    payload = run_ozone_dhf_linear_model(config)
    if args.output is None:
        print(
            json.dumps(
                payload,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
                allow_nan=False,
            )
        )
    else:
        save_ozone_dhf_linear_json(payload, args.output)
        print(f"JSON: {args.output}")
    return payload


if __name__ == "__main__":
    main()

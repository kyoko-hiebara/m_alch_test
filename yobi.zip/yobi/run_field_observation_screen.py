#!/usr/bin/env python3
"""Screen the two plant observations that came without measured data.

Two things are reported to help a little on the trench-bottom residue:
adding H2SO4 to the dHF, and heating the wafer from the backside.  Neither
came with numbers, but both are mechanism-discriminating, and both can be
screened at the continuum level before any MLIP work:

* H2SO4 shifts the HF speciation.  The candidate rate laws that the graph-KMC
  ``SpeciesActivitySpec`` can already express predict *opposite signs* for that
  shift, so the direction of the plant effect selects among them.
* A backside heater raises the reaction-front temperature by an amount set by
  two unconstrained resistances.  The rate response is a ratio, so it needs no
  absolute-rate anchor and is usable while ``rate_spec_ready = 0``.

This runner produces both screens plus the joint decision table.  It is a
screening calculation, not a recipe: no clearance time, residue amount, or
operating condition follows from it.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Mapping, Sequence

from acid_speciation import (
    BISULFATE_KA2_298,
    BISULFATE_SOURCE,
    MAXIMUM_IONIC_STRENGTH,
    TABULATED_MAXIMUM_IONIC_STRENGTH,
    AcidifiedSpeciation,
    bifluoride_quotient_spread,
    conventional_davies_activity_model,
    relative_rate_response,
    solve_acidified_speciation,
    sulfuric_molality_to_weight_percent,
    table_fitted_activity_model,
    weight_percent_to_fluorine_molality,
)
from acid_speciation import MODEL_NOTICE as ACID_NOTICE
from acid_speciation import SCHEMA_VERSION as ACID_SCHEMA
from thermal_path_screen import (
    ACCEPTED_BARRIER_EV,
    TRANSPORT_APPARENT_BARRIER_EV,
    coupling_efficiency_for_rate_ratio,
    coupling_efficiency_to_rate_ratio,
    evaluate_thermal_path,
)
from thermal_path_screen import MODEL_NOTICE as THERMAL_NOTICE
from thermal_path_screen import SCHEMA_VERSION as THERMAL_SCHEMA


SCHEMA_VERSION = "field-observation-continuum-screen/v1"
RESULT_NAME = "field_observation_screen.json"
SPECIATION_CSV_NAME = "acid_speciation_sweep.csv"
RATE_LAW_CSV_NAME = "rate_law_discrimination.csv"
THERMAL_CSV_NAME = "backside_heater_thermal_path.csv"
FIGURE_NAME = "field_observation_screen.png"
README_NAME = "README_JA.md"
MANIFEST_NAME = "manifest_sha256.json"

DEFAULT_SULFURIC_MOL_KG = (0.0, 0.003, 0.01, 0.03, 0.05, 0.08, 0.10)
DEFAULT_SUBSTRATE_WIDTHS_M = (
    1.0e-8,
    3.0e-8,
    1.0e-7,
    3.0e-7,
    1.0e-6,
    3.0e-6,
    1.0e-5,
    1.0e-4,
    1.0e-3,
)
DEFAULT_OBSERVED_RATIOS = (1.1, 1.2, 1.5, 2.0, 3.0, 5.0)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Continuum-level screen of the H2SO4 addition and backside-heater "
            "plant observations."
        )
    )
    parser.add_argument(
        "--hf-weight-percent",
        type=float,
        default=0.55,
        help=(
            "dHF strength for the speciation sweep. The plant '1:100' label "
            "cannot be converted without the stock concentration, so the "
            "literature 0.55 wt%% preset is the default (default: 0.55)"
        ),
    )
    parser.add_argument(
        "--sulfuric-mol-kg",
        type=float,
        action="append",
        default=None,
        help="added H2SO4 molality; repeatable",
    )
    parser.add_argument(
        "--geometry",
        default="10_10_180",
        help="straight trench preset for the thermal path (default: 10_10_180)",
    )
    parser.add_argument(
        "--solution-temperature-K",
        type=float,
        default=298.15,
    )
    parser.add_argument(
        "--backside-temperature-K",
        type=float,
        default=323.15,
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/field_observation_screen_20260728"),
    )
    parser.add_argument(
        "--no-figure",
        action="store_true",
        help="skip PNG generation",
    )
    return parser


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _save_json(payload: Mapping[str, object], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def _save_csv(
    rows: Sequence[Mapping[str, object]],
    fieldnames: Sequence[str],
    path: Path,
) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(fieldnames))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    return path


def run_acid_screen(
    *,
    hf_weight_percent: float,
    sulfuric_molalities: Sequence[float],
) -> dict[str, object]:
    """Speciation and candidate-rate-law response versus added H2SO4."""

    fluorine = weight_percent_to_fluorine_molality(hf_weight_percent)
    models = {
        "table_fitted_b": table_fitted_activity_model(),
        "conventional_davies_b": conventional_davies_activity_model(),
    }
    sweeps: dict[str, list[dict[str, object]]] = {}
    responses: dict[str, list[dict[str, object]]] = {}
    refused: list[dict[str, object]] = []

    for label, model in models.items():
        baseline: AcidifiedSpeciation | None = None
        sweep_rows: list[dict[str, object]] = []
        response_rows: list[dict[str, object]] = []
        for sulfuric in sulfuric_molalities:
            try:
                solved = solve_acidified_speciation(
                    analytical_fluorine_mol_kg=fluorine,
                    added_sulfuric_acid_mol_kg=sulfuric,
                    activity_model=model,
                )
            except ValueError as error:
                refused.append(
                    {
                        "activity_model": label,
                        "added_sulfuric_acid_mol_kg": sulfuric,
                        "reason": str(error),
                    }
                )
                continue
            if baseline is None:
                baseline = solved
            sweep_rows.append(solved.to_dict())
            if sulfuric > 0.0:
                response_rows.append(
                    {
                        "added_sulfuric_acid_mol_kg": sulfuric,
                        "added_sulfuric_acid_weight_percent": (
                            sulfuric_molality_to_weight_percent(sulfuric)
                        ),
                        "support_status": solved.support_status,
                        **relative_rate_response(baseline, solved),
                    }
                )
        sweeps[label] = sweep_rows
        responses[label] = response_rows

    return {
        "schema_version": ACID_SCHEMA,
        "model_notice": ACID_NOTICE,
        "hf_weight_percent": hf_weight_percent,
        "analytical_fluorine_mol_kg": fluorine,
        "activity_models": {
            label: model.to_dict() for label, model in models.items()
        },
        "external_constants": {
            "bisulfate_ka2_298": BISULFATE_KA2_298,
            "bisulfate_source": BISULFATE_SOURCE,
        },
        "bifluoride_quotient_relative_spread": bifluoride_quotient_spread(),
        "tabulated_maximum_ionic_strength": TABULATED_MAXIMUM_IONIC_STRENGTH,
        "maximum_ionic_strength": MAXIMUM_IONIC_STRENGTH,
        "speciation": sweeps,
        "rate_law_response": responses,
        "refused_cases": refused,
    }


def run_thermal_screen(
    *,
    geometry_name: str,
    substrate_widths_m: Sequence[float],
    solution_temperature_K: float,
    backside_temperature_K: float,
    observed_ratios: Sequence[float],
) -> dict[str, object]:
    """Coupling efficiency sweep plus the inverse reading of an observation."""

    cases = [
        evaluate_thermal_path(
            geometry_name=geometry_name,
            effective_substrate_width_m=width,
            solution_bulk_temperature_K=solution_temperature_K,
            substrate_backside_temperature_K=backside_temperature_K,
        ).to_dict()
        for width in substrate_widths_m
    ]

    energies = dict(ACCEPTED_BARRIER_EV)
    energies["transport_limited_null"] = TRANSPORT_APPARENT_BARRIER_EV
    saturated = {
        key: coupling_efficiency_to_rate_ratio(
            1.0,
            value,
            solution_bulk_temperature_K=solution_temperature_K,
            substrate_backside_temperature_K=backside_temperature_K,
        )
        for key, value in energies.items()
    }
    inverse: list[dict[str, object]] = []
    for ratio in observed_ratios:
        row: dict[str, object] = {"observed_rate_ratio": ratio}
        for key, value in energies.items():
            efficiency = coupling_efficiency_for_rate_ratio(
                ratio,
                value,
                solution_bulk_temperature_K=solution_temperature_K,
                substrate_backside_temperature_K=backside_temperature_K,
            )
            row[key] = efficiency
        inverse.append(row)

    return {
        "schema_version": THERMAL_SCHEMA,
        "model_notice": THERMAL_NOTICE,
        "geometry_name": geometry_name,
        "solution_bulk_temperature_K": solution_temperature_K,
        "substrate_backside_temperature_K": backside_temperature_K,
        "activation_energies_eV": energies,
        "sweep": cases,
        "maximum_rate_ratio_at_full_coupling": saturated,
        "required_coupling_efficiency": inverse,
    }


def build_decision_table(
    acid: Mapping[str, object],
    thermal: Mapping[str, object],
) -> list[dict[str, object]]:
    """What each plant observation would resolve, and what it cannot."""

    saturated = thermal["maximum_rate_ratio_at_full_coupling"]
    transport_ceiling = float(saturated["transport_limited_null"])
    return [
        {
            "observation": "H2SO4 addition helps",
            "resolves": (
                "selects among the candidate rate laws by sign: only a "
                "proton-assisted law predicts faster"
            ),
            "excluded_if_true": (
                "bifluoride-controlled removal, which this screen predicts "
                "gets slower with added strong acid"
            ),
            "does_not_resolve": (
                "whether the acid speeds matrix removal or instead dissolves "
                "a post-HF deposit; a no-dry control separates those"
            ),
            "measurement_needed": (
                "residue ratio with and without H2SO4 at otherwise identical "
                "recipe; a ratio, so no absolute metrology is required"
            ),
        },
        {
            "observation": "backside heater helps",
            "resolves": (
                "reaction versus transport control, without an absolute-rate "
                "anchor, because the prefactor cancels in a rate ratio"
            ),
            "excluded_if_true": (
                "transport control is excluded outright by any improvement "
                f"above {transport_ceiling:.2f}x, which is the ceiling at "
                "perfect thermal coupling"
            ),
            "does_not_resolve": (
                "the thermal coupling efficiency and the activation energy "
                "separately; the observation constrains their combination"
            ),
            "measurement_needed": (
                "residue ratio at two backside settings plus the bath "
                "temperature, so the applied overheat is known"
            ),
        },
    ]


def _plot(payload: Mapping[str, object], path: Path) -> Path | None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return None

    acid = payload["acid_speciation_screen"]
    thermal = payload["backside_heater_screen"]
    figure, axes = plt.subplots(2, 2, figsize=(13.5, 9.5))

    # (a) speciation versus added acid, both activity models
    axis = axes[0][0]
    for label, style in (
        ("table_fitted_b", "-"),
        ("conventional_davies_b", "--"),
    ):
        rows = acid["speciation"][label]
        acid_axis = [row["added_sulfuric_acid_mol_kg"] for row in rows]
        for key, colour in (
            ("neutral_hf_mol_kg", "tab:blue"),
            ("fluoride_mol_kg", "tab:orange"),
            ("bifluoride_mol_kg", "tab:green"),
        ):
            axis.plot(
                acid_axis,
                [row[key] for row in rows],
                style,
                color=colour,
                label=f"{key.replace('_mol_kg', '')} ({label})",
            )
    axis.set_yscale("log")
    axis.set_xlabel("added H2SO4 [mol/kg]")
    axis.set_ylabel("molality [mol/kg]")
    axis.set_title("(a) HF speciation versus added strong acid")
    axis.legend(fontsize=6, ncol=2)
    axis.grid(alpha=0.3)

    # (b) candidate rate-law response
    axis = axes[0][1]
    rows = acid["rate_law_response"]["table_fitted_b"]
    acid_axis = [row["added_sulfuric_acid_mol_kg"] for row in rows]
    axis.plot(
        acid_axis, [row["neutral_hf"] for row in rows], "o-", label="neutral HF"
    )
    axis.plot(
        acid_axis,
        [row["bifluoride"] for row in rows],
        "s-",
        label="bifluoride",
    )
    for key in ("K=0.1", "K=1", "K=10"):
        axis.plot(
            acid_axis,
            [row["proton_assisted_hf"][key] for row in rows],
            "^--",
            label=f"proton-assisted {key}",
        )
    axis.axhline(1.0, color="black", linewidth=0.8)
    axis.set_yscale("log")
    axis.set_xlabel("added H2SO4 [mol/kg]")
    axis.set_ylabel("rate relative to dHF alone")
    axis.set_title("(b) candidate rate laws disagree in sign")
    axis.legend(fontsize=7)
    axis.grid(alpha=0.3)

    # (c) thermal coupling efficiency
    axis = axes[1][0]
    sweep = thermal["sweep"]
    widths = [row["effective_substrate_width_m"] for row in sweep]
    axis.semilogx(
        widths,
        [row["coupling_efficiency"] for row in sweep],
        "o-",
        color="tab:red",
    )
    axis.axvline(
        1.0e-8,
        color="grey",
        linestyle=":",
        label="thermal_model default (trench width)",
    )
    axis.set_xlabel("effective substrate width [m]")
    axis.set_ylabel("coupling efficiency eta")
    axis.set_title("(c) fraction of backside overheat reaching the front")
    axis.legend(fontsize=7)
    axis.grid(alpha=0.3)

    # (d) inverse reading
    axis = axes[1][1]
    inverse = thermal["required_coupling_efficiency"]
    ratios = [row["observed_rate_ratio"] for row in inverse]
    for key in (
        "si_o_c_water_trimer_hydrolysis",
        "si_n_hydrolysis",
        "si_o_c_hydrolysis",
        "transport_limited_null",
    ):
        values = [row[key] for row in inverse]
        drawn = [
            (ratio, value)
            for ratio, value in zip(ratios, values)
            if value is not None
        ]
        if drawn:
            axis.plot(
                [item[0] for item in drawn],
                [item[1] for item in drawn],
                "o-",
                label=key,
            )
    ceiling = float(
        thermal["maximum_rate_ratio_at_full_coupling"]["transport_limited_null"]
    )
    axis.axvline(
        ceiling,
        color="black",
        linestyle="--",
        label=f"transport ceiling {ceiling:.2f}x",
    )
    axis.set_xlabel("observed improvement factor")
    axis.set_ylabel("coupling efficiency eta required")
    axis.set_title("(d) inverse reading of a plant observation")
    axis.legend(fontsize=7)
    axis.grid(alpha=0.3)

    figure.suptitle(
        "Continuum screen of the H2SO4 and backside-heater observations "
        "(screening only, not a recipe)"
    )
    figure.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(path, dpi=150)
    plt.close(figure)
    return path


def _write_manifest(output_dir: Path, names: Sequence[str]) -> Path:
    payload = {
        "algorithm": "sha256",
        "outputs": {
            name: {"sha256": _sha256(output_dir / name)}
            for name in names
            if (output_dir / name).exists()
        },
    }
    return _save_json(payload, output_dir / MANIFEST_NAME)


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    sulfuric = tuple(
        args.sulfuric_mol_kg
        if args.sulfuric_mol_kg
        else DEFAULT_SULFURIC_MOL_KG
    )
    if 0.0 not in sulfuric:
        sulfuric = (0.0,) + sulfuric
    sulfuric = tuple(sorted(set(sulfuric)))

    acid = run_acid_screen(
        hf_weight_percent=args.hf_weight_percent,
        sulfuric_molalities=sulfuric,
    )
    thermal = run_thermal_screen(
        geometry_name=args.geometry,
        substrate_widths_m=DEFAULT_SUBSTRATE_WIDTHS_M,
        solution_temperature_K=args.solution_temperature_K,
        backside_temperature_K=args.backside_temperature_K,
        observed_ratios=DEFAULT_OBSERVED_RATIOS,
    )
    payload: dict[str, object] = {
        "schema_version": SCHEMA_VERSION,
        "claim_boundary": {
            "is_process_recipe": False,
            "is_experimental_evidence": False,
            "absolute_rate_anchor_required": False,
            "absolute_rate_anchor_reason": (
                "every reported quantity is a ratio or a species "
                "concentration, so the missing attempt frequency does not "
                "enter"
            ),
            "plant_observations_are_qualitative": True,
            "plant_observation_note": (
                "the H2SO4 and backside-heater effects were reported as "
                "'slightly better' without magnitudes, so this screen states "
                "what each magnitude would resolve rather than fitting one"
            ),
        },
        "acid_speciation_screen": acid,
        "backside_heater_screen": thermal,
        "decision_table": build_decision_table(acid, thermal),
    }

    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    _save_json(payload, output_dir / RESULT_NAME)

    speciation_rows = [
        {"activity_model": label, **row}
        for label, rows in acid["speciation"].items()
        for row in rows
    ]
    _save_csv(
        speciation_rows,
        list(speciation_rows[0].keys()),
        output_dir / SPECIATION_CSV_NAME,
    )

    rate_rows = []
    for label, rows in acid["rate_law_response"].items():
        for row in rows:
            flat = {
                "activity_model": label,
                "added_sulfuric_acid_mol_kg": row["added_sulfuric_acid_mol_kg"],
                "support_status": row["support_status"],
                "neutral_hf": row["neutral_hf"],
                "bifluoride": row["bifluoride"],
                "fluoride": row["fluoride"],
            }
            for key, value in row["proton_assisted_hf"].items():
                flat[f"proton_assisted_{key}"] = value
            for key, value in row["predicted_sign"].items():
                flat[f"sign_{key}"] = value
            rate_rows.append(flat)
    _save_csv(
        rate_rows, list(rate_rows[0].keys()), output_dir / RATE_LAW_CSV_NAME
    )

    thermal_rows = []
    for row in thermal["sweep"]:
        flat = {
            key: value
            for key, value in row.items()
            if key != "rate_ratios"
        }
        for key, value in row["rate_ratios"].items():
            flat[f"rate_ratio_{key}"] = value
        thermal_rows.append(flat)
    _save_csv(
        thermal_rows,
        list(thermal_rows[0].keys()),
        output_dir / THERMAL_CSV_NAME,
    )

    names = [
        RESULT_NAME,
        SPECIATION_CSV_NAME,
        RATE_LAW_CSV_NAME,
        THERMAL_CSV_NAME,
    ]
    if not args.no_figure:
        if _plot(payload, output_dir / FIGURE_NAME) is not None:
            names.append(FIGURE_NAME)
    if (output_dir / README_NAME).exists():
        names.append(README_NAME)
    _write_manifest(output_dir, names)
    return payload


if __name__ == "__main__":
    result = main()
    acid = result["acid_speciation_screen"]
    thermal = result["backside_heater_screen"]
    print(f"activity models: {sorted(acid['activity_models'])}")
    print(f"speciation points: {len(acid['speciation']['table_fitted_b'])}")
    print(f"refused cases: {len(acid['refused_cases'])}")
    ceiling = thermal["maximum_rate_ratio_at_full_coupling"][
        "transport_limited_null"
    ]
    print(f"transport-limited ceiling at full coupling: {ceiling:.3f}x")

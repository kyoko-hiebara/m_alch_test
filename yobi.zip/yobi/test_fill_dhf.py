from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

import build_trench
import fill_dhf


ROOT = Path(__file__).resolve().parent


class FillDHFTests(unittest.TestCase):
    def make_trench(self, path: Path, *extra: str) -> None:
        args = build_trench.build_parser().parse_args(
            [
                "--si", str(ROOT / "si_8atom.xyz"),
                "--sin", str(ROOT / "SiN_56atom.xyz"),
                "--substrate-thickness", "24",
                "--trench-depth", "12",
                "--trench-width", "16",
                "--structure-depth", "16",
                "--sidewall-thickness", "6",
                "--vacuum", "5",
                *extra,
                "-o", str(path),
            ]
        )
        build_trench.build(args)

    def parse_filler(self, input_path: Path, output_path: Path, *extra: str):
        return fill_dhf.build_parser().parse_args(
            [
                str(input_path),
                "--hf-wt-percent", "5",
                "--fill-depth", "10",
                "--molecule-count", "20",
                "--seed", "123",
                "--restarts", "1",
                "-o", str(output_path),
                *extra,
            ]
        )

    @staticmethod
    def property_values(structure: fill_dhf.ExtendedXYZ, name: str) -> list[str]:
        offset, spec = fill_dhf.property_offsets(structure.properties)[name]
        if spec.count != 1:
            raise AssertionError(f"{name} is not scalar")
        return [row[offset] for row in structure.rows]

    @staticmethod
    def assert_no_external_collisions(structure: fill_dhf.ExtendedXYZ) -> None:
        groups = np.asarray(FillDHFTests.property_values(structure, "group"))
        mol_ids = np.asarray(
            [int(value) for value in FillDHFTests.property_values(structure, "mol_id")]
        )
        fluid = np.flatnonzero(np.isin(groups, ["H2O", "HF"]))
        lengths = np.diag(structure.cell)
        for first in fluid:
            delta = structure.positions - structure.positions[first]
            delta[:, 0] -= np.rint(delta[:, 0] / lengths[0]) * lengths[0]
            delta[:, 1] -= np.rint(delta[:, 1] / lengths[1]) * lengths[1]
            distances = np.linalg.norm(delta, axis=1)
            for second in range(len(structure.positions)):
                if second == first or (
                    mol_ids[first] > 0 and mol_ids[first] == mol_ids[second]
                ):
                    continue
                cutoff = fill_dhf.pair_cutoff(
                    str(structure.species[first]), str(structure.species[second])
                )
                if distances[second] < cutoff - 1.0e-7:
                    raise AssertionError(
                        f"collision {first}-{second}: {distances[second]} < {cutoff}"
                    )

    def test_composition_uses_mass_fraction(self) -> None:
        self.assertEqual(fill_dhf.choose_hf_count(20, 5.0), 1)
        self.assertAlmostEqual(
            fill_dhf.realized_wt_percent(19, 1), 5.5220886757, places=9
        )
        composition = fill_dhf.plan_composition(3000.0, 1.0, 0.997, None)
        self.assertGreater(composition.total_molecules, 0)
        self.assertAlmostEqual(composition.actual_density, 0.997, delta=0.01)

    def test_linked_cell_detects_xy_seam_without_z_wrapping(self) -> None:
        index = fill_dhf.LinkedCell(10.0, 10.0, 1.0)
        index.add_atom("O", np.asarray([0.2, 0.2, 1.0]))
        self.assertTrue(index.collides_atom("O", np.asarray([9.9, 0.2, 1.0])))
        self.assertTrue(index.collides_atom("O", np.asarray([0.2, 9.9, 1.0])))
        self.assertFalse(index.collides_atom("O", np.asarray([0.2, 0.2, 8.0])))

    def test_metadata_values_round_trip_safely(self) -> None:
        for value in ("plain", "a b", 'a"b', r"a\b", "a'b", ""):
            parsed, order = fill_dhf.parse_comment(fill_dhf.metadata_token("tag", value))
            self.assertEqual(order, ["tag"])
            self.assertEqual(parsed["tag"], value)

    def test_packing_cutoff_does_not_change_density_count(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "trench.xyz"
            self.make_trench(source, "--termination", "h")
            counts = []
            volumes = []
            for cutoff_scale in (0.8, 1.2):
                args = fill_dhf.build_parser().parse_args(
                    [
                        str(source),
                        "--hf-wt-percent", "1",
                        "--fill-depth", "10",
                        "--cutoff-scale", str(cutoff_scale),
                        "--dry-run",
                    ]
                )
                stats = fill_dhf.execute(args)
                counts.append((stats.requested_h2o, stats.requested_hf))
                volumes.append(stats.accessible_volume)
            self.assertEqual(counts[0], counts[1])
            self.assertAlmostEqual(volumes[0], volumes[1], places=12)

    def test_pack_is_deterministic_and_preserves_molecular_geometry(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            directory_path = Path(directory)
            source = directory_path / "trench.xyz"
            outputs = [directory_path / "dhf1.xyz", directory_path / "dhf2.xyz"]
            self.make_trench(source, "--termination", "h", "--termination-scope", "all")
            stats = []
            for output in outputs:
                args = self.parse_filler(source, output)
                stats.append(fill_dhf.execute(args))
            self.assertEqual(outputs[0].read_bytes(), outputs[1].read_bytes())
            self.assertEqual(stats[0].placed_h2o, 19)
            self.assertEqual(stats[0].placed_hf, 1)

            packed = fill_dhf.read_extended_xyz(outputs[0])
            groups = np.asarray(self.property_values(packed, "group"))
            mol_ids = np.asarray([int(value) for value in self.property_values(packed, "mol_id")])
            self.assertEqual(np.count_nonzero(groups == "H2O"), 57)
            self.assertEqual(np.count_nonzero(groups == "HF"), 2)
            self.assertTrue(np.all(mol_ids[~np.isin(groups, ["H2O", "HF"])] == 0))
            self.assertEqual(len(set(mol_ids[mol_ids > 0])), 20)

            geometry = fill_dhf.resolve_geometry(
                self.parse_filler(source, outputs[0]), fill_dhf.read_extended_xyz(source)
            )
            region = fill_dhf.LiquidRegion(geometry, 10.0, 0.0, "include")
            fluid = np.flatnonzero(np.isin(groups, ["H2O", "HF"]))
            self.assertTrue(all(region.contains(packed.positions[index]) for index in fluid))

            for molecule_id in sorted(set(mol_ids[mol_ids > 0])):
                indices = np.flatnonzero(mol_ids == molecule_id)
                molecule_group = groups[indices[0]]
                positions = packed.positions[indices]
                reference = positions[0]
                delta = positions - reference
                delta[:, 0] -= np.rint(delta[:, 0] / packed.cell[0, 0]) * packed.cell[0, 0]
                delta[:, 1] -= np.rint(delta[:, 1] / packed.cell[1, 1]) * packed.cell[1, 1]
                if molecule_group == "HF":
                    self.assertAlmostEqual(np.linalg.norm(delta[1]), fill_dhf.HF_BOND, places=7)
                else:
                    self.assertAlmostEqual(np.linalg.norm(delta[1]), fill_dhf.WATER_OH, places=7)
                    self.assertAlmostEqual(np.linalg.norm(delta[2]), fill_dhf.WATER_OH, places=7)
                    cosine = np.dot(delta[1], delta[2]) / (
                        np.linalg.norm(delta[1]) * np.linalg.norm(delta[2])
                    )
                    self.assertAlmostEqual(
                        np.degrees(np.arccos(np.clip(cosine, -1.0, 1.0))),
                        fill_dhf.WATER_ANGLE_DEGREES,
                        places=6,
                    )
            self.assert_no_external_collisions(packed)

    def test_reservoir_only_excludes_trench_and_extends_z_cell(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            directory_path = Path(directory)
            source = directory_path / "residue.xyz"
            output = directory_path / "reservoir.xyz"
            args = build_trench.build_parser().parse_args(
                [
                    "--si", str(ROOT / "si_8atom.xyz"),
                    "--sin", str(ROOT / "SiN_56atom.xyz"),
                    "--substrate-thickness", "40",
                    "--trench-depth", "25",
                    "--trench-width", "30",
                    "--structure-depth", "16",
                    "--sin-mode", "residue",
                    "--residue-coverage", "0.5",
                    "--residue-max-height", "1",
                    "--residue-min-atoms", "1",
                    "--phase-trials", "3",
                    "--seed", "6",
                    "-o", str(source),
                ]
            )
            build_trench.build(args)
            filler_args = fill_dhf.build_parser().parse_args(
                [
                    str(source),
                    "--hf-wt-percent", "2",
                    "--fill-depth", "50",
                    "--reservoir-height", "6",
                    "--trench-liquid", "exclude",
                    "--molecule-count", "12",
                    "--seed", "9",
                    "-o", str(output),
                ]
            )
            fill_dhf.execute(filler_args)
            dry = fill_dhf.read_extended_xyz(source)
            packed = fill_dhf.read_extended_xyz(output)
            geometry = fill_dhf.resolve_geometry(filler_args, dry)
            groups = np.asarray(self.property_values(packed, "group"))
            fluid = packed.positions[np.isin(groups, ["H2O", "HF"])]
            self.assertGreater(len(fluid), 0)
            self.assertTrue(np.all(fluid[:, 2] >= geometry.z_top - fill_dhf.TOL))
            self.assertGreaterEqual(
                packed.cell[2, 2], geometry.z_top + 6.0 + filler_args.top_vacuum
            )
            self.assertEqual(
                np.count_nonzero(groups == "SiN_residue"),
                np.count_nonzero(
                    np.asarray(self.property_values(dry, "group")) == "SiN_residue"
                ),
            )
            self.assert_no_external_collisions(packed)
            self.assertEqual(packed.metadata["dhf_fill_depth"], "50.00000000")
            self.assertEqual(packed.metadata["dhf_effective_fill_depth"], "0.00000000")

    def test_external_geometry_overrides_are_recorded_and_extra_properties_survive(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            directory_path = Path(directory)
            source = directory_path / "external.xyz"
            output = directory_path / "external_dhf.xyz"
            source.write_text(
                "1\n"
                'Lattice="20 0 0 0 20 0 0 0 20" '
                'Properties=foo:R:2:species:S:1:pos:R:3:flag:L:1 '
                'pbc="T T F" si_thickness=5 bottom_thickness=2 '
                'trench_depth=3 trench_width=2 sidewall_thickness=1 '
                'geometry_shift_y=0 geometry_shift_z=1\n'
                "1.25 2.50 Si 10 10 1 1\n",
                encoding="utf-8",
            )
            args = fill_dhf.build_parser().parse_args(
                [
                    str(source),
                    "--hf-wt-percent", "0",
                    "--fill-depth", "5",
                    "--molecule-count", "3",
                    "--trench-top-z", "15",
                    "--trench-floor-z", "5",
                    "--trench-y-left", "18",
                    "--trench-width", "4",
                    "--seed", "4",
                    "-o", str(output),
                ]
            )
            fill_dhf.execute(args)
            packed = fill_dhf.read_extended_xyz(output)
            self.assertEqual(packed.metadata["dhf_geometry_source"], "overrides")
            self.assertEqual(packed.metadata["dhf_geometry_trench_top_z"], "15.00000000")
            self.assertEqual(packed.metadata["dhf_geometry_trench_floor_z"], "5.00000000")
            self.assertEqual(packed.metadata["dhf_geometry_trench_y_left"], "18.00000000")
            self.assertEqual(packed.metadata["dhf_geometry_trench_width"], "4.00000000")
            self.assertNotIn("si_thickness", packed.metadata)
            self.assertNotIn("trench_width", packed.metadata)
            self.assertEqual(packed.properties[0], fill_dhf.PropertySpec("foo", "R", 2))
            self.assertEqual(packed.rows[0][:2], ["1.25", "2.50"])
            groups = np.asarray(self.property_values(packed, "group"))
            fluid = packed.positions[groups == "H2O"]
            geometry = fill_dhf.resolve_geometry(args, fill_dhf.read_extended_xyz(source))
            region = fill_dhf.LiquidRegion(geometry, 5.0, 0.0, "include")
            self.assertTrue(all(region.contains(position) for position in fluid))

    def test_invalid_periodicity_and_empty_exclusion_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            directory_path = Path(directory)
            source = directory_path / "trench.xyz"
            bad = directory_path / "bad.xyz"
            self.make_trench(source)
            text = source.read_text(encoding="utf-8").replace('pbc="T T F"', 'pbc="T F F"')
            bad.write_text(text, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, 'pbc="T T F"'):
                fill_dhf.read_extended_xyz(bad)

            args = self.parse_filler(
                source,
                directory_path / "none.xyz",
                "--trench-liquid", "exclude",
            )
            with self.assertRaisesRegex(ValueError, "reservoir-height"):
                fill_dhf.execute(args)


if __name__ == "__main__":
    unittest.main()

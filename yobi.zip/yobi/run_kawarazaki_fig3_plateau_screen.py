#!/usr/bin/env python3
"""Write the claim-safe Kawarazaki Figure 3 descriptive screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from kawarazaki_fig3_plateau_screen import (
    build_fig3_plateau_screen,
    save_fig3_plateau_screen_json,
)


DEFAULT_OUTPUT = Path(
    "results/kawarazaki_fig3_plateau_screen/fig3_plateau_screen.json"
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Save the measured-time-only descriptive plateau diagnostics "
            "digitized approximately from Kawarazaki et al. Figure 3. "
            "No kinetics are fitted and no values are extrapolated."
        )
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help="strict JSON output path",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    payload = build_fig3_plateau_screen()
    output = save_fig3_plateau_screen_json(payload, args.output)
    summary = {
        "output": str(output),
        "schema_version": payload["schema_version"],
        "material_count": payload["summary"]["material_count"],
        "measured_bake_times_s": payload["experimental_context"][
            "ozone_bake"
        ]["measured_bake_times_s"],
        "all_post_30_s_spans_within_pairwise_readout_tolerance": (
            payload["summary"][
                "all_post_30_s_spans_within_pairwise_readout_tolerance"
            ]
        ),
    }
    print(
        json.dumps(
            summary,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Backside-heater screen: how much of an applied wafer heat reaches the front.

``thermal_model`` already treats the solution bulk temperature and the wafer
backside temperature as two independent boundary conditions joined by parallel
thermal resistances.  Two of its parameters are not constrained by anything in
this repository, and both bias the answer the same way:

``effective_substrate_width_m``
    Defaults to the trench bottom width, i.e. the silicon is modelled as a
    column as wide as the trench.  A real wafer spreads heat laterally over a
    far larger area, so the default overstates the substrate-branch resistance
    and makes a backside heater look inert.

``solution_boundary_resistance_m2K_W``
    Defaults to zero, which pins the liquid branch to the bath temperature only
    a trench-depth away.  A real bath has a convective boundary layer, so the
    default understates the liquid-branch resistance and again makes a backside
    heater look inert.

Rather than pick values, this module keeps a dimensionless group primary, in
the same spirit as the ozone delivery screen:

    eta = (T_interface - T_bulk) / (T_backside - T_bulk)

is the fraction of the applied backside overheat that survives to the reaction
front.  ``eta`` runs from 0 (liquid pins the front to the bath) to 1 (front
follows the wafer).  Everything unconstrained is collapsed into it.

Because a rate ratio between two temperatures divides out the prefactor, this
screen answers the mechanism question *without* an absolute-rate anchor -- the
``rate_spec_ready = 0`` blocker on the atomistic line does not apply here.  A
transport-limited front and a reaction-limited front differ by more than an
order of magnitude in their response to the same heater, so a plant observation
of how much a backside heater helps constrains ``eta`` and the apparent
activation energy jointly.

**This does not predict a residue clearance time.**  It converts an applied
backside temperature into a front temperature and an Arrhenius rate ratio.  The
thermal properties are the ``thermal_model`` defaults, the geometry is a single
straight trench, no wafer-scale spreading calculation is performed, and the
liquid is assumed to stay at bath temperature far from the wafer.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass

from thermal_model import (
    TaperedTrench2D,
    ThermalBoundaryConditions,
    ThermalResistanceModel,
    ThermalResistanceParameters,
)
from trench_geometry import get_geometry_preset


SCHEMA_VERSION = "backside-heater-thermal-path-screen/v1"
MODEL_NOTICE = (
    "Quasi-steady two-branch thermal-resistance screen for a backside heater. "
    "The primary output is the dimensionless fraction of the applied backside "
    "overheat that reaches the reaction front, swept over the two "
    "unconstrained resistance parameters rather than assuming either. "
    "Arrhenius rate ratios are prefactor-free and therefore usable before the "
    "absolute-rate anchor exists, but they are ratios only: no clearance time, "
    "no residue amount, and no recipe follows from this screen. Wafer-scale "
    "lateral spreading, bath hydrodynamics, boiling, and the temperature "
    "dependence of HF speciation and diffusivity are not modelled."
)

BOLTZMANN_EV_PER_K = 8.617333262e-5

# Accepted UMA first-order-saddle barriers, from
# atomistic_barriers/results/graph_kmc_intermediate_event_prior.json.  These are
# potential-energy screening barriers without an absolute-rate anchor; only
# their *ratio* response to temperature is used here.  The water-trimer entry
# is the corrected 2026-07-29 strict-gate reaudit value
# (atomistic_barriers/results/barrier_reproduction_20260729/
# sella_direct_reaudit_strict_water_trimer.json), superseding the retired
# 1.0243 eV campaign value, which was produced at ts_fmax 0.2 -- a setting
# diagnosed as never performing a saddle search.  The saved
# results/field_observation_screen_20260728 snapshot predates the correction
# and keeps the retired value; its README documents the discrepancy instead
# of the snapshot being regenerated.
ACCEPTED_BARRIER_EV: dict[str, float] = {
    "si_o_c_water_trimer_hydrolysis": 0.8431133533886168,
    "si_n_hydrolysis": 1.2148,
    "si_o_c_hydrolysis": 1.3563,
    "si_c_fluorination": 1.6744,
}

# Apparent activation energy of aqueous diffusion near 25 degC, from the
# Stokes--Einstein temperature dependence of water viscosity.  Used as the
# transport-limited null, not as a fitted value.
TRANSPORT_APPARENT_BARRIER_EV = 0.17

_TRANSPORT_KEY = "transport_limited_null"


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def _finite_nonnegative(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    return number


def arrhenius_rate_ratio(
    activation_energy_eV: float,
    reference_temperature_K: float,
    elevated_temperature_K: float,
) -> float:
    """Return ``k(elevated) / k(reference)``.

    The prefactor cancels, which is why this screen can run before the
    atomistic line supplies an attempt frequency.
    """

    energy = _finite_nonnegative("activation_energy_eV", activation_energy_eV)
    reference = _finite_positive(
        "reference_temperature_K", reference_temperature_K
    )
    elevated = _finite_positive(
        "elevated_temperature_K", elevated_temperature_K
    )
    exponent = (
        energy
        / BOLTZMANN_EV_PER_K
        * (1.0 / reference - 1.0 / elevated)
    )
    return math.exp(exponent)


def required_activation_energy_eV(
    observed_rate_ratio: float,
    reference_temperature_K: float,
    elevated_temperature_K: float,
) -> float:
    """Invert ``arrhenius_rate_ratio`` for the apparent activation energy.

    This is the quantity a plant observation constrains: given how much the
    heater actually helped and how hot the front actually became, the apparent
    barrier follows without any absolute rate.
    """

    ratio = _finite_positive("observed_rate_ratio", observed_rate_ratio)
    reference = _finite_positive(
        "reference_temperature_K", reference_temperature_K
    )
    elevated = _finite_positive(
        "elevated_temperature_K", elevated_temperature_K
    )
    if math.isclose(reference, elevated, rel_tol=0.0, abs_tol=1.0e-12):
        raise ValueError(
            "reference and elevated temperatures must differ to invert a "
            "rate ratio"
        )
    inverse_difference = 1.0 / reference - 1.0 / elevated
    return math.log(ratio) * BOLTZMANN_EV_PER_K / inverse_difference


@dataclass(frozen=True)
class ThermalPathCase:
    """One point of the two-parameter thermal-path sweep."""

    geometry_name: str
    effective_substrate_width_m: float
    solution_boundary_resistance_m2K_W: float
    front_depth_nm: float
    solution_bulk_temperature_K: float
    substrate_backside_temperature_K: float
    interface_temperature_K: float
    interface_overheat_K: float
    coupling_efficiency: float
    liquid_branch_resistance_K_m_W: float
    solid_branch_resistance_K_m_W: float
    rate_ratios: dict[str, float]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def evaluate_thermal_path(
    *,
    geometry_name: str = "10_10_180",
    effective_substrate_width_m: float,
    solution_boundary_resistance_m2K_W: float = 0.0,
    front_depth_nm: float | None = None,
    solution_bulk_temperature_K: float = 298.15,
    substrate_backside_temperature_K: float = 323.15,
    activation_energies_eV: dict[str, float] | None = None,
) -> ThermalPathCase:
    """Evaluate the coupling efficiency and rate response at one sweep point.

    ``front_depth_nm`` defaults to the trench bottom, which is where the
    residue sits and where the backside branch is most favourable.
    """

    preset = get_geometry_preset(geometry_name)
    geometry = TaperedTrench2D(
        name=preset.name,
        top_width_nm=preset.top_width_nm,
        bottom_width_nm=preset.bottom_width_nm,
        depth_nm=preset.depth_nm,
    )
    width = _finite_positive(
        "effective_substrate_width_m", effective_substrate_width_m
    )
    boundary = _finite_nonnegative(
        "solution_boundary_resistance_m2K_W",
        solution_boundary_resistance_m2K_W,
    )
    bulk = _finite_positive(
        "solution_bulk_temperature_K", solution_bulk_temperature_K
    )
    backside = _finite_positive(
        "substrate_backside_temperature_K", substrate_backside_temperature_K
    )
    if backside <= bulk:
        raise ValueError(
            "substrate_backside_temperature_K must exceed "
            "solution_bulk_temperature_K for a backside-heater screen"
        )
    depth_nm = (
        float(preset.depth_nm) if front_depth_nm is None else float(front_depth_nm)
    )
    if not math.isfinite(depth_nm) or not 0.0 <= depth_nm <= preset.depth_nm:
        raise ValueError(
            "front_depth_nm must be finite and within the trench depth"
        )

    parameters = ThermalResistanceParameters(
        effective_substrate_width_m=width,
        solution_boundary_resistance_m2K_W=boundary,
    )
    model = ThermalResistanceModel(geometry, parameters)
    state = model.evaluate(
        depth_nm * 1.0e-9,
        ThermalBoundaryConditions(
            solution_bulk_temperature_K=bulk,
            substrate_backside_temperature_K=backside,
        ),
    )
    overheat = state.interface_temperature_K - bulk
    efficiency = overheat / (backside - bulk)

    energies = dict(activation_energies_eV or ACCEPTED_BARRIER_EV)
    energies.setdefault(_TRANSPORT_KEY, TRANSPORT_APPARENT_BARRIER_EV)
    ratios = {
        key: arrhenius_rate_ratio(
            value, bulk, state.interface_temperature_K
        )
        for key, value in energies.items()
    }
    breakdown = state.resistances
    return ThermalPathCase(
        geometry_name=preset.name,
        effective_substrate_width_m=width,
        solution_boundary_resistance_m2K_W=boundary,
        front_depth_nm=depth_nm,
        solution_bulk_temperature_K=bulk,
        substrate_backside_temperature_K=backside,
        interface_temperature_K=state.interface_temperature_K,
        interface_overheat_K=overheat,
        coupling_efficiency=efficiency,
        liquid_branch_resistance_K_m_W=breakdown.liquid_total_K_m_W,
        solid_branch_resistance_K_m_W=breakdown.solid_total_K_m_W,
        rate_ratios=ratios,
    )


def coupling_efficiency_to_rate_ratio(
    coupling_efficiency: float,
    activation_energy_eV: float,
    *,
    solution_bulk_temperature_K: float = 298.15,
    substrate_backside_temperature_K: float = 323.15,
) -> float:
    """Rate ratio implied by a coupling efficiency, bypassing the geometry.

    This is the form used for the inverse reading of a plant observation: the
    whole unconstrained thermal path is one number, so an observed improvement
    maps onto a curve in ``(eta, Ea)`` rather than onto a single value of
    either.
    """

    efficiency = float(coupling_efficiency)
    if not math.isfinite(efficiency) or not 0.0 <= efficiency <= 1.0:
        raise ValueError("coupling_efficiency must be finite and within [0, 1]")
    bulk = _finite_positive(
        "solution_bulk_temperature_K", solution_bulk_temperature_K
    )
    backside = _finite_positive(
        "substrate_backside_temperature_K", substrate_backside_temperature_K
    )
    front = bulk + efficiency * (backside - bulk)
    if math.isclose(front, bulk, rel_tol=0.0, abs_tol=1.0e-12):
        return 1.0
    return arrhenius_rate_ratio(activation_energy_eV, bulk, front)


def coupling_efficiency_for_rate_ratio(
    observed_rate_ratio: float,
    activation_energy_eV: float,
    *,
    solution_bulk_temperature_K: float = 298.15,
    substrate_backside_temperature_K: float = 323.15,
) -> float | None:
    """Coupling efficiency consistent with an observed improvement.

    Returns ``None`` when even perfect coupling cannot reach the observed
    ratio, which is itself informative: it rules the activation energy out.
    """

    ratio = _finite_positive("observed_rate_ratio", observed_rate_ratio)
    energy = _finite_positive(
        "activation_energy_eV", activation_energy_eV
    )
    bulk = _finite_positive(
        "solution_bulk_temperature_K", solution_bulk_temperature_K
    )
    backside = _finite_positive(
        "substrate_backside_temperature_K", substrate_backside_temperature_K
    )
    if ratio <= 1.0:
        return 0.0
    required = required_activation_energy_eV(ratio, bulk, backside)
    if required > energy:
        return None
    # Invert 1/T_front = 1/T_bulk - kB ln(ratio) / Ea for the front
    # temperature, then express it as a fraction of the applied overheat.
    inverse_front = (
        1.0 / bulk - math.log(ratio) * BOLTZMANN_EV_PER_K / energy
    )
    if inverse_front <= 0.0:
        return None
    front = 1.0 / inverse_front
    return (front - bulk) / (backside - bulk)


__all__ = [
    "ACCEPTED_BARRIER_EV",
    "BOLTZMANN_EV_PER_K",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "TRANSPORT_APPARENT_BARRIER_EV",
    "ThermalPathCase",
    "arrhenius_rate_ratio",
    "coupling_efficiency_for_rate_ratio",
    "coupling_efficiency_to_rate_ratio",
    "evaluate_thermal_path",
    "required_activation_energy_eV",
]

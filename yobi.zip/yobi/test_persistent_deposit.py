from __future__ import annotations

import math
import unittest
from dataclasses import replace

import numpy as np

from persistent_deposit import (
    NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN,
    DepositParameters,
    PersistentDepositPhase2D,
)
from reaction_diffusion_2d import CartesianGrid2D
from trench_geometry import TaperedTrench2D


class PersistentDepositPhase2DTests(unittest.TestCase):
    def setUp(self) -> None:
        self.geometry = TaperedTrench2D("toy", 8.0, 6.0, 20.0)
        self.grid = CartesianGrid2D.from_geometry(
            self.geometry,
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
        )
        self.parameters = DepositParameters(
            species_name="test_precipitate",
            saturation_concentration_mol_m3=10.0,
            attachment_velocity_nm_s=1.0,
            wall_affinity=2.0,
            bottom_affinity=3.0,
            deposit_molar_density_mol_m3=2.0,
            precipitation_yield_mol_deposit_per_mol_product=0.5,
            subgrid_warning_thickness_over_cell=0.5,
        )
        self.liquid = self.grid.cavity_mask.copy()

    def make_phase(self) -> PersistentDepositPhase2D:
        return PersistentDepositPhase2D(self.grid, self.parameters)

    def concentration_field(self, value: float) -> np.ndarray:
        return np.where(self.liquid, value, 0.0)

    def loaded_phase(self) -> PersistentDepositPhase2D:
        phase = self.make_phase()
        phase.precipitate_during_drydown(
            self.concentration_field(12.0),
            self.liquid,
            solute_retention_fraction=1.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=7.0,
        )
        return phase

    def test_wet_precipitation_is_zero_below_csat_and_positive_above_it(self) -> None:
        phase = self.make_phase()
        below = self.concentration_field(9.0)
        above = self.concentration_field(12.0)

        self.assertFalse(np.any(phase.wet_active_mask(below, self.liquid)))
        np.testing.assert_array_equal(
            phase.wet_precipitation_rate_native_field(below, self.liquid),
            np.zeros(self.grid.shape),
        )
        empty = phase.accumulate_wet_precipitation(
            below, self.liquid, duration_s=1.0
        )
        self.assertEqual(empty.precipitated_inventory_native, 0.0)

        active = phase.wet_active_mask(above, self.liquid)
        rate = phase.wet_precipitation_rate_native_field(above, self.liquid)
        collector = (
            phase.wall_contact_length_nm + phase.bottom_contact_length_nm
        ) > 0.0
        self.assertTrue(np.any(active))
        self.assertTrue(np.all(active <= collector))
        self.assertGreater(float(np.sum(rate)), 0.0)
        self.assertTrue(np.all(rate[~collector] == 0.0))

        duration_s = 2.5
        formed = phase.accumulate_wet_precipitation(
            above, self.liquid, duration_s=duration_s
        )
        expected = float(np.sum(rate)) * duration_s
        self.assertAlmostEqual(formed.precipitated_inventory_native, expected)
        self.assertAlmostEqual(
            formed.wall_attached_inventory_native
            + formed.bottom_attached_inventory_native,
            expected,
        )
        self.assertGreater(formed.wall_attached_inventory_native, 0.0)
        self.assertGreater(formed.bottom_attached_inventory_native, 0.0)

    def test_immediate_rinse_prevents_drydown_deposit_but_retained_solute_does_not(self) -> None:
        product = self.concentration_field(12.0)

        rinsed = self.make_phase()
        rinse_result = rinsed.precipitate_during_drydown(
            product,
            self.liquid,
            solute_retention_fraction=0.0,
            liquid_retention_fraction=0.0,
        )
        self.assertEqual(rinse_result.available_product_inventory_native, 0.0)
        self.assertEqual(rinse_result.precipitated_inventory_native, 0.0)
        self.assertEqual(rinsed.diagnostics().total_inventory_native, 0.0)

        dried = self.make_phase()
        dry_result = dried.precipitate_during_drydown(
            product,
            self.liquid,
            solute_retention_fraction=1.0,
            liquid_retention_fraction=0.0,
        )
        available = (
            12.0
            * float(np.count_nonzero(self.grid.cavity_mask))
            * self.grid.cell_area_nm2
        )
        expected_deposit = (
            available
            * self.parameters.precipitation_yield_mol_deposit_per_mol_product
        )
        self.assertAlmostEqual(
            dry_result.available_product_inventory_native, available
        )
        self.assertAlmostEqual(
            dry_result.precipitated_inventory_native, expected_deposit
        )
        self.assertAlmostEqual(
            dry_result.precipitated_inventory_native
            + dry_result.nondeposit_product_inventory_native,
            dry_result.precipitable_product_inventory_native,
        )
        self.assertGreater(dried.diagnostics().total_inventory_native, 0.0)

    def test_drydown_inventory_is_conserved_across_wall_and_bottom_collectors(self) -> None:
        phase = self.make_phase()
        product = self.concentration_field(12.0)
        trapped = 7.0
        result = phase.precipitate_during_drydown(
            product,
            self.liquid,
            solute_retention_fraction=1.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=trapped,
        )

        expected_available = (
            float(np.sum(product[self.grid.cavity_mask]))
            * self.grid.cell_area_nm2
            + trapped
        )
        expected_deposit = (
            expected_available
            * self.parameters.precipitation_yield_mol_deposit_per_mol_product
        )
        stored = phase.total_inventory_native_field
        collector = (
            phase.wall_contact_length_nm + phase.bottom_contact_length_nm
        ) > 0.0

        # The toy trench has wall/floor corner cells, so this also checks that
        # a corner inventory is split rather than counted twice.
        self.assertTrue(
            np.any(
                (phase.wall_contact_length_nm > 0.0)
                & (phase.bottom_contact_length_nm > 0.0)
            )
        )
        self.assertAlmostEqual(
            result.available_product_inventory_native, expected_available
        )
        self.assertAlmostEqual(
            result.precipitated_inventory_native, expected_deposit
        )
        self.assertAlmostEqual(
            result.wall_attached_inventory_native
            + result.bottom_attached_inventory_native,
            expected_deposit,
        )
        self.assertAlmostEqual(float(np.sum(stored)), expected_deposit)
        self.assertTrue(np.all(stored[~collector] == 0.0))
        self.assertTrue(np.all(stored >= 0.0))

    def test_first_order_dissolution_is_monotonic_and_nonnegative(self) -> None:
        phase = self.loaded_phase()
        wall_before = float(np.sum(phase.wall_inventory_native))
        bottom_before = float(np.sum(phase.bottom_inventory_native))
        total_before = wall_before + bottom_before

        first = phase.dissolve(
            3.0,
            wall_rate_s=0.2,
            bottom_rate_s=0.05,
        )
        expected_after = (
            wall_before * math.exp(-0.2 * 3.0)
            + bottom_before * math.exp(-0.05 * 3.0)
        )
        self.assertAlmostEqual(first.before_inventory_native, total_before)
        self.assertAlmostEqual(first.after_inventory_native, expected_after)
        self.assertAlmostEqual(
            first.removed_inventory_native, total_before - expected_after
        )
        self.assertLess(first.after_inventory_native, total_before)
        self.assertTrue(np.all(phase.wall_inventory_native >= 0.0))
        self.assertTrue(np.all(phase.bottom_inventory_native >= 0.0))

        second = phase.dissolve(3.0, wall_rate_s=0.2, bottom_rate_s=0.05)
        self.assertLess(second.after_inventory_native, first.after_inventory_native)
        unchanged = phase.dissolve(0.0, wall_rate_s=10.0)
        self.assertAlmostEqual(
            unchanged.after_inventory_native, second.after_inventory_native
        )

    def test_copy_has_independent_inventory_arrays(self) -> None:
        original = self.loaded_phase()
        copied = original.copy()
        original_wall = original.wall_inventory_native.copy()
        original_bottom = original.bottom_inventory_native.copy()

        self.assertFalse(
            np.shares_memory(
                original.wall_inventory_native, copied.wall_inventory_native
            )
        )
        self.assertFalse(
            np.shares_memory(
                original.bottom_inventory_native, copied.bottom_inventory_native
            )
        )
        copied.dissolve(10.0, wall_rate_s=1.0, bottom_rate_s=1.0)

        np.testing.assert_array_equal(
            original.wall_inventory_native, original_wall
        )
        np.testing.assert_array_equal(
            original.bottom_inventory_native, original_bottom
        )
        self.assertLess(
            copied.diagnostics().total_inventory_native,
            original.diagnostics().total_inventory_native,
        )

    def test_zero_affinity_never_hides_inventory_on_a_disabled_face(self) -> None:
        parameters = DepositParameters(
            saturation_concentration_mol_m3=10.0,
            wall_affinity=0.0,
            bottom_affinity=1.0,
            deposit_molar_density_mol_m3=2.0,
            precipitation_yield_mol_deposit_per_mol_product=1.0,
        )
        phase = PersistentDepositPhase2D(self.grid, parameters)
        formed = phase.precipitate_during_drydown(
            self.concentration_field(12.0),
            self.liquid,
            solute_retention_fraction=1.0,
            liquid_retention_fraction=0.0,
        )

        self.assertEqual(formed.wall_attached_inventory_native, 0.0)
        self.assertAlmostEqual(
            formed.bottom_attached_inventory_native,
            formed.precipitated_inventory_native,
        )
        self.assertAlmostEqual(
            np.sum(phase.bottom_inventory_native),
            formed.precipitated_inventory_native,
        )
        self.assertGreater(np.max(phase.bottom_thickness_nm), 0.0)

    def test_drydown_attaches_only_to_exposed_liquid_collectors(self) -> None:
        phase = self.make_phase()
        shallow_liquid = self.liquid & (self.grid.depth_mesh_nm < 8.0)
        phase.precipitate_during_drydown(
            np.zeros(self.grid.shape),
            shallow_liquid,
            solute_retention_fraction=0.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=10.0,
        )

        attached = phase.total_inventory_native_field > 0.0
        self.assertTrue(np.any(attached))
        self.assertTrue(np.all(attached <= shallow_liquid))
        self.assertEqual(np.sum(phase.bottom_inventory_native), 0.0)

    def test_collector_mask_exposes_all_faces_or_accessible_subset(self) -> None:
        phase = self.make_phase()
        all_collectors = phase.collector_mask()
        wall_collectors = phase.collector_mask(include_bottom=False)
        bottom_collectors = phase.collector_mask(include_wall=False)
        shallow_access = self.liquid & (self.grid.depth_mesh_nm < 8.0)
        accessible_collectors = phase.collector_mask(shallow_access)

        np.testing.assert_array_equal(
            all_collectors,
            wall_collectors | bottom_collectors,
        )
        self.assertTrue(np.any(bottom_collectors))
        self.assertTrue(np.any(accessible_collectors))
        self.assertTrue(np.all(accessible_collectors <= all_collectors))
        self.assertTrue(np.all(accessible_collectors <= shallow_access))
        self.assertFalse(np.any(accessible_collectors & bottom_collectors))
        self.assertLess(
            np.count_nonzero(accessible_collectors),
            np.count_nonzero(all_collectors),
        )

        retained = phase.collector_mask(shallow_access)
        shallow_access[:] = False
        self.assertTrue(np.any(retained))
        with self.assertRaisesRegex(ValueError, "access_mask"):
            phase.collector_mask(np.zeros((1, 1), dtype=bool))

    def test_same_capture_can_compare_all_face_and_access_limited_allocation(
        self,
    ) -> None:
        upper_bound = self.make_phase()
        lower_bound = self.make_phase()
        shallow_access = self.liquid & (self.grid.depth_mesh_nm < 8.0)
        captured = 10.0

        upper = upper_bound.precipitate_during_drydown(
            np.zeros(self.grid.shape),
            self.liquid,
            solute_retention_fraction=0.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=captured,
        )
        lower = lower_bound.precipitate_during_drydown(
            np.zeros(self.grid.shape),
            self.liquid,
            solute_retention_fraction=0.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=captured,
            collector_access_mask=shallow_access,
        )

        self.assertAlmostEqual(
            upper.available_product_inventory_native,
            lower.available_product_inventory_native,
        )
        self.assertAlmostEqual(
            upper.precipitated_inventory_native,
            lower.precipitated_inventory_native,
        )
        self.assertAlmostEqual(
            float(np.sum(upper_bound.total_inventory_native_field)),
            float(np.sum(lower_bound.total_inventory_native_field)),
        )
        lower_support = lower_bound.total_inventory_native_field > 0.0
        self.assertTrue(
            np.all(lower_support <= lower_bound.collector_mask(shallow_access))
        )
        self.assertGreater(
            float(np.sum(upper_bound.bottom_inventory_native)),
            0.0,
        )
        self.assertEqual(
            float(np.sum(lower_bound.bottom_inventory_native)),
            0.0,
        )
        with self.assertRaisesRegex(ValueError, "collector_access_mask"):
            self.make_phase().precipitate_during_drydown(
                np.zeros(self.grid.shape),
                self.liquid,
                solute_retention_fraction=0.0,
                liquid_retention_fraction=0.0,
                additional_trapped_inventory_native=captured,
                collector_access_mask=np.zeros((1, 1), dtype=bool),
            )

    def test_diagnostics_report_geometry_normalization_and_subgrid_warning(self) -> None:
        parameters = DepositParameters(
            species_name="diagnostic_species",
            saturation_concentration_mol_m3=10.0,
            deposit_molar_density_mol_m3=1.0,
            precipitation_yield_mol_deposit_per_mol_product=1.0,
            subgrid_warning_thickness_over_cell=0.5,
        )
        phase = PersistentDepositPhase2D(self.grid, parameters)
        empty = phase.diagnostics()
        self.assertIsNone(empty.depth_centroid_nm)
        self.assertFalse(empty.subgrid_validity_warning)
        self.assertEqual(empty.upper_middle_lower_inventory_fraction, (0.0, 0.0, 0.0))

        trapped = 1_000.0
        formation = phase.precipitate_during_drydown(
            np.zeros(self.grid.shape),
            self.liquid,
            solute_retention_fraction=0.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=trapped,
        )
        diagnostics = formation.diagnostics

        self.assertAlmostEqual(diagnostics.total_inventory_native, trapped)
        self.assertAlmostEqual(
            diagnostics.total_mol_per_nm_span,
            trapped * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN,
        )
        self.assertAlmostEqual(
            diagnostics.equivalent_cross_section_area_nm2, trapped
        )
        self.assertAlmostEqual(
            diagnostics.fraction_of_initial_gap_fill_area,
            trapped / self.geometry.area_nm2,
        )
        self.assertAlmostEqual(
            diagnostics.wall_fraction_of_deposit
            + diagnostics.bottom_fraction_of_deposit,
            1.0,
        )
        self.assertAlmostEqual(
            sum(diagnostics.upper_middle_lower_inventory_fraction), 1.0
        )
        self.assertIsNotNone(diagnostics.depth_centroid_nm)
        self.assertGreaterEqual(diagnostics.depth_centroid_nm or 0.0, 0.0)
        self.assertLessEqual(
            diagnostics.depth_centroid_nm or 0.0, self.geometry.depth_nm
        )
        self.assertGreater(diagnostics.wall_coated_length_nm, 0.0)
        self.assertGreater(diagnostics.bottom_coated_length_nm, 0.0)
        self.assertGreaterEqual(
            diagnostics.maximum_thickness_over_grid_spacing, 0.5
        )
        self.assertTrue(diagnostics.subgrid_validity_warning)

    def test_surface_diagnostics_are_contact_area_normalized_and_conservative(self) -> None:
        parameters = DepositParameters(
            species_name="mass_known_species",
            saturation_concentration_mol_m3=10.0,
            deposit_molar_density_mol_m3=2.0,
            precipitation_yield_mol_deposit_per_mol_product=1.0,
            coverage_reference_thickness_nm=0.5,
            deposit_molar_mass_kg_mol=0.10,
        )
        phase = PersistentDepositPhase2D(self.grid, parameters)
        wall_thickness_nm = 0.25
        bottom_thickness_nm = 1.0
        phase.wall_inventory_native[:] = (
            parameters.deposit_molar_density_mol_m3
            * wall_thickness_nm
            * phase.wall_contact_length_nm
        )
        phase.bottom_inventory_native[:] = (
            parameters.deposit_molar_density_mol_m3
            * bottom_thickness_nm
            * phase.bottom_contact_length_nm
        )

        diagnostics = phase.diagnostics()
        wall_area = float(np.sum(phase.wall_contact_length_nm))
        bottom_area = float(np.sum(phase.bottom_contact_length_nm))
        total_area = wall_area + bottom_area
        expected_wall = (
            parameters.deposit_molar_density_mol_m3
            * wall_thickness_nm
            * wall_area
        )
        expected_bottom = (
            parameters.deposit_molar_density_mol_m3
            * bottom_thickness_nm
            * bottom_area
        )
        expected_total = expected_wall + expected_bottom
        expected_total_thickness = (
            wall_thickness_nm * wall_area
            + bottom_thickness_nm * bottom_area
        ) / total_area

        self.assertAlmostEqual(
            diagnostics.wall_available_contact_area_nm2_for_1nm_span,
            wall_area,
        )
        self.assertAlmostEqual(
            diagnostics.bottom_available_contact_area_nm2_for_1nm_span,
            bottom_area,
        )
        self.assertAlmostEqual(
            diagnostics.total_available_contact_area_nm2_for_1nm_span,
            total_area,
        )
        self.assertAlmostEqual(
            diagnostics.wall_inventory_density_native_per_nm2,
            expected_wall / wall_area,
        )
        self.assertAlmostEqual(
            diagnostics.bottom_inventory_density_native_per_nm2,
            expected_bottom / bottom_area,
        )
        self.assertAlmostEqual(
            diagnostics.total_inventory_density_native_per_nm2,
            expected_total / total_area,
        )
        self.assertAlmostEqual(
            diagnostics.wall_areal_inventory_mol_m2,
            expected_wall / wall_area * 1.0e-9,
        )
        self.assertAlmostEqual(
            diagnostics.bottom_areal_inventory_mol_m2,
            expected_bottom / bottom_area * 1.0e-9,
        )
        self.assertAlmostEqual(
            diagnostics.total_inventory_density_native_per_nm2 * total_area,
            diagnostics.wall_inventory_density_native_per_nm2 * wall_area
            + diagnostics.bottom_inventory_density_native_per_nm2 * bottom_area,
        )
        self.assertAlmostEqual(diagnostics.total_inventory_native, expected_total)
        self.assertAlmostEqual(
            diagnostics.total_mean_thickness_nm,
            expected_total_thickness,
        )
        self.assertAlmostEqual(
            diagnostics.equivalent_cross_section_area_nm2,
            wall_thickness_nm * wall_area
            + bottom_thickness_nm * bottom_area,
        )

        expected_wall_coverage = 1.0 - math.exp(-0.25 / 0.5)
        expected_bottom_coverage = 1.0 - math.exp(-1.0 / 0.5)
        self.assertAlmostEqual(
            diagnostics.wall_continuous_coverage_fraction,
            expected_wall_coverage,
        )
        self.assertAlmostEqual(
            diagnostics.bottom_continuous_coverage_fraction,
            expected_bottom_coverage,
        )
        self.assertAlmostEqual(
            diagnostics.total_continuous_coverage_fraction,
            (
                expected_wall_coverage * wall_area
                + expected_bottom_coverage * bottom_area
            )
            / total_area,
        )
        self.assertEqual(diagnostics.wall_geometric_coverage_fraction, 1.0)
        self.assertEqual(diagnostics.bottom_geometric_coverage_fraction, 1.0)
        self.assertAlmostEqual(diagnostics.wall_mean_layer_equivalents, 0.5)
        self.assertAlmostEqual(diagnostics.bottom_mean_layer_equivalents, 2.0)
        self.assertAlmostEqual(
            diagnostics.total_mean_layer_equivalents,
            expected_total_thickness / 0.5,
        )

        expected_wall_mass = (
            expected_wall
            * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN
            * parameters.deposit_molar_mass_kg_mol
        )
        expected_bottom_mass = (
            expected_bottom
            * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN
            * parameters.deposit_molar_mass_kg_mol
        )
        self.assertAlmostEqual(
            diagnostics.wall_mass_kg_per_nm_span, expected_wall_mass
        )
        self.assertAlmostEqual(
            diagnostics.bottom_mass_kg_per_nm_span, expected_bottom_mass
        )
        self.assertAlmostEqual(
            diagnostics.total_mass_kg_per_nm_span,
            expected_wall_mass + expected_bottom_mass,
        )

    def test_drydown_capture_amount_is_independent_of_wall_affinity(self) -> None:
        product = self.concentration_field(12.0)
        low_affinity = PersistentDepositPhase2D(
            self.grid,
            replace(self.parameters, wall_affinity=0.1, bottom_affinity=1.0),
        )
        high_affinity = PersistentDepositPhase2D(
            self.grid,
            replace(self.parameters, wall_affinity=10.0, bottom_affinity=1.0),
        )

        low = low_affinity.precipitate_during_drydown(
            product,
            self.liquid,
            solute_retention_fraction=1.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=7.0,
        )
        high = high_affinity.precipitate_during_drydown(
            product,
            self.liquid,
            solute_retention_fraction=1.0,
            liquid_retention_fraction=0.0,
            additional_trapped_inventory_native=7.0,
        )

        self.assertAlmostEqual(
            low.available_product_inventory_native,
            high.available_product_inventory_native,
        )
        self.assertAlmostEqual(
            low.precipitated_inventory_native,
            high.precipitated_inventory_native,
        )
        self.assertAlmostEqual(
            low.wall_attached_inventory_native
            + low.bottom_attached_inventory_native,
            high.wall_attached_inventory_native
            + high.bottom_attached_inventory_native,
        )
        self.assertLess(
            low.diagnostics.wall_fraction_of_deposit,
            high.diagnostics.wall_fraction_of_deposit,
        )


if __name__ == "__main__":
    unittest.main()

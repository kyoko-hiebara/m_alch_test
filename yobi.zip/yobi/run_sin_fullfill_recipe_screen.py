#!/usr/bin/env python3
"""Run and serialize the SiN full-fill dHF/DIW/SC1/DIW control case."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Mapping, Sequence

from measured_blanket_clock import load_blanket_time_series_csv
from sin_fullfill_recipe_screen import (
    SiNFullFillRecipeConfig,
    run_sin_fullfill_recipe_screen,
    simulate_dhf_fullfill_front,
)


RESULT_NAME = "sin_fullfill_recipe_screen.json"
STAGE_CSV_NAME = "sin_fullfill_recipe_stages.csv"
SC1_CSV_NAME = "sin_fullfill_sc1_sensitivity.csv"
FIGURE_NAME = "sin_fullfill_recipe_screen.png"
README_NAME = "README_JA.md"
MANIFEST_NAME = "manifest_sha256.json"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Simulate a fully filled straight SiN trench through the "
            "measured-clock dHF stage and bound the uncalibrated SC1 stage."
        )
    )
    parser.add_argument(
        "--input-csv",
        type=Path,
        default=Path("inputs/sin_blanket_user_20260728.csv"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/sin_fullfill_recipe_20260728"),
    )
    parser.add_argument(
        "--geometry",
        default="10_10_180",
        help="straight trench preset (default: 10_10_180)",
    )
    parser.add_argument(
        "--no-figure",
        action="store_true",
        help="skip PNG generation",
    )
    return parser


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _save_json(payload: Mapping[str, object], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def _write_csv(
    rows: Sequence[Mapping[str, object]],
    path: Path,
) -> Path:
    if not rows:
        raise ValueError("cannot write an empty table")
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return path


def write_readme(
    payload: Mapping[str, object],
    path: Path,
    *,
    input_path: Path,
) -> Path:
    endpoint = payload["dhf_calibrated_endpoint"]
    geometry = payload["geometry"]
    stages = payload["stage_states"]
    sensitivity = payload["sc1_sensitivity"]
    ladder = payload["mesh_ladder"]
    lines = [
        "# SiN完全fill trench：dHF → DIW → SC1 → DIW",
        "",
        "## 結論",
        "",
        f"`{geometry['top_width_nm']:.0f} × {geometry['depth_nm']:.0f} nm`"
        "の直壁trenchを、void/seamのないSiNで完全に埋めたcontrolです。",
        f"dHF `{payload['config']['dhf_ratio_label']}` 20秒では、上面が"
        f" **{float(endpoint['top_retreat_nm']):.6f} nm** 後退します。",
        f"除去断面積は {float(endpoint['dissolved_cross_section_nm2']):.6f} "
        "nm²、",
        f"SiN全断面の **{100.0 * float(endpoint['removed_solid_fraction']):.5f}%** "
        "だけが除去され、",
        f"縦方向には {float(endpoint['remaining_vertical_fill_nm']):.6f} nm "
        "残ります。bottomは未露出です。",
        "",
        "DIW 60秒は「SiN母材を削らず、HFを即時quenchする」中央仮定なので、"
        "dHF直後と同じ形状です。",
        "一方、SC1 180秒・40℃は、このrepositoryに同条件のSiN速度校正が"
        "ないため、最終膜厚を確定していません。",
        "",
        "## 工程別の状態",
        "",
        "| stage | end [s] | status | quantified retreat [nm] | "
        "null branch [nm] |",
        "|---|---:|---|---:|---:|",
        *[
            (
                f"| {row['stage']} | {float(row['end_time_s']):.0f} | "
                f"{row['quantitative_status']} | "
                f"{'' if row['quantified_top_retreat_nm'] is None else f'{float(row['quantified_top_retreat_nm']):.6f}'} | "
                f"{float(row['null_branch_top_retreat_nm']):.6f} |"
            )
            for row in stages
        ],
        "",
        "`null branch`はSC1によるSiN除去を0と置いた参照線であり、"
        "最終工程のprocess predictionではありません。",
        "",
        "## SC1未校正感度",
        "",
        "SC1実効SiN速度を、dHF初期区間速度0.6418 nm/minとの比"
        "`α`で置きました。式は",
        "",
        "`total retreat = 0.213933 + 1.9254 × α [nm]`",
        "",
        "です。",
        "",
        "| α | assumed SC1 rate [nm/min] | total retreat [nm] | "
        "remaining vertical fill [nm] | removed [%] |",
        "|---:|---:|---:|---:|---:|",
        *[
            (
                f"| {float(row['alpha_SC1_to_initial_dHF_rate']):g} | "
                f"{float(row['SC1_rate_nm_min']):.6f} | "
                f"{float(row['total_top_retreat_after_SC1_nm']):.6f} | "
                f"{float(row['remaining_vertical_fill_nm']):.6f} | "
                f"{100.0 * float(row['removed_solid_fraction']):.5f} |"
            )
            for row in sensitivity
        ],
        "",
        "`α=1`も化学的な上限ではなく、広いstress caseです。SC1の確定値には"
        "使えません。",
        "",
        "## 数値確認",
        "",
        "20秒の後退量は0.5 nm未満なので、binary cellではなく"
        "`solid_fraction`を持つ保守的なsub-grid frontを使用しました。",
        "",
        "| nominal grid [nm] | actual dx [nm] | dz [nm] | "
        "retreat [nm] | closure error [nm] | max mass error |",
        "|---:|---:|---:|---:|---:|---:|",
        *[
            (
                f"| {float(row['nominal_grid_spacing_nm']):.3f} | "
                f"{float(row['actual_dx_nm']):.6f} | "
                f"{float(row['actual_dz_nm']):.6f} | "
                f"{float(row['equivalent_planar_retreat_nm']):.12f} | "
                f"{float(row['absolute_retreat_closure_error_nm']):.3e} | "
                f"{float(row['maximum_step_mass_balance_relative_error']):.3e} |"
            )
            for row in ladder
        ],
        "",
        "各meshでcavity面積を幾何面積に一致させ、除去量と質量収支を"
        "独立に確認しています。",
        "",
        "## このcontrolから言えること",
        "",
        "- 完全solid fillなら20秒のdHFは上面を約0.214 nm削るだけで、"
        "bottom residueを直接評価する工程にはなりません。",
        "- 内部voidがないため、この時点ではwetting、pinning、persistent gas、"
        "bottom局所速度差は作動しません。",
        "- measured blanket clockに未校正passivationを重ねると減速を"
        "二重計上し得るため、このcontrolでは追加していません。",
        "- dry工程がレシピにないのでdry-down再析出は無効です。最終観察前に"
        "spin dry等があるなら、その工程を追加する必要があります。",
        "- 実構造にcenter seam、keyhole、側壁沿いの連通voidがあれば別問題で、"
        "その形状を初期条件として与える必要があります。",
        "",
        "## 入力・校正境界",
        "",
        "- 20秒値は直接測定ではなく、仮定した(0秒, 0 nm)から"
        "60秒測定点までの線形補間です。",
        "- blanket値が同じdHF 1:100・比較可能なSiN膜・HF-only測定であることを"
        "仮定しています。",
        "- `1:100`はstock HF濃度と混合基準が不明なのでwt%へ換算していません。",
        "- SC1組成、bath age、SiN成膜条件、SC1-only WERが未入力です。",
        "- 次に必要な最小実験は、同一SiNのSC1-only 0/60/180秒、40℃です。",
        "",
        "## 成果物",
        "",
        f"- `{RESULT_NAME}`: 全設定、mesh ladder、工程状態、SC1感度",
        f"- `{STAGE_CSV_NAME}`: 工程別state table",
        f"- `{SC1_CSV_NAME}`: 未校正SC1感度table",
        f"- `{FIGURE_NAME}`: 全断面、上面zoom、recipe、SC1感度",
        f"- `{MANIFEST_NAME}`: 入力を含むSHA-256",
        f"- input: `{input_path}`",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def plot_recipe_screen(
    payload: Mapping[str, object],
    path: Path,
    *,
    input_path: Path,
) -> Path:
    import matplotlib

    matplotlib.use("Agg", force=True)
    import matplotlib.pyplot as plt
    import numpy as np

    config = SiNFullFillRecipeConfig(
        geometry_id=str(payload["config"]["geometry_id"]),
        dhf_ratio_label=str(payload["config"]["dhf_ratio_label"]),
        dhf_duration_s=float(payload["config"]["dhf_duration_s"]),
        diw1_duration_s=float(payload["config"]["diw1_duration_s"]),
        sc1_duration_s=float(payload["config"]["sc1_duration_s"]),
        sc1_temperature_C=float(payload["config"]["sc1_temperature_C"]),
        diw2_duration_s=float(payload["config"]["diw2_duration_s"]),
        nominal_grid_spacings_nm=tuple(
            float(value)
            for value in payload["config"]["nominal_grid_spacings_nm"]
        ),
        reservoir_height_nm=float(
            payload["config"]["reservoir_height_nm"]
        ),
        lateral_margin_nm=float(payload["config"]["lateral_margin_nm"]),
        maximum_fractional_change=float(
            payload["config"]["maximum_fractional_change"]
        ),
        sc1_rate_ratios_to_initial_dhf=tuple(
            float(value)
            for value in payload["config"][
                "sc1_rate_ratios_to_initial_dhf"
            ]
        ),
    )
    series = load_blanket_time_series_csv(input_path)
    front = simulate_dhf_fullfill_front(
        series,
        config,
        nominal_spacing_nm=min(config.nominal_grid_spacings_nm),
    )
    grid = front.grid
    solid = np.where(grid.cavity_mask, front.solid_fraction, np.nan)
    x_edges = np.concatenate(
        (
            grid.lateral_nm - 0.5 * grid.dx_nm,
            [grid.lateral_nm[-1] + 0.5 * grid.dx_nm],
        )
    )
    z_edges = np.concatenate(
        (
            grid.depth_nm - 0.5 * grid.dz_nm,
            [grid.depth_nm[-1] + 0.5 * grid.dz_nm],
        )
    )

    fig, axes = plt.subplots(2, 2, figsize=(13.5, 9.0))
    ax = axes[0, 0]
    starts = np.asarray([0.0, 20.0, 80.0, 260.0])
    widths = np.asarray([20.0, 60.0, 180.0, 60.0])
    labels = ("dHF", "DIW 1", "SC1", "DIW 2")
    colors = ("#D1495B", "#4C9FCE", "#F2B134", "#4C9FCE")
    for start, width, label, color in zip(
        starts, widths, labels, colors
    ):
        bars = ax.barh(
            [0],
            [width],
            left=[start],
            height=0.48,
            color=color,
            edgecolor="black",
            linewidth=0.8,
        )
        if label == "SC1":
            bars[0].set_hatch("//")
        ax.text(
            start + 0.5 * width,
            0.0,
            label,
            ha="center",
            va="center",
            fontsize=9,
        )
    ax.axvline(20.0, color="#8B1E2D", linestyle="--", linewidth=1.3)
    ax.text(
        20.0,
        0.36,
        "quantitative endpoint",
        ha="center",
        va="bottom",
        fontsize=8,
        color="#8B1E2D",
    )
    ax.text(
        170.0,
        -0.38,
        "SC1 geometry unresolved; hatch = sensitivity only",
        ha="center",
        va="top",
        fontsize=8,
    )
    ax.set_xlim(0.0, 320.0)
    ax.set_ylim(-0.65, 0.65)
    ax.set_yticks([])
    ax.set_xlabel("Cumulative recipe time (s)")
    ax.set_title("A  Recipe and claim boundary", loc="left")
    ax.grid(axis="x", alpha=0.2)

    ax = axes[0, 1]
    mesh = ax.pcolormesh(
        x_edges,
        z_edges,
        solid,
        shading="flat",
        cmap="viridis",
        vmin=0.0,
        vmax=1.0,
    )
    ax.set_xlim(
        -0.7 * float(payload["geometry"]["top_width_nm"]),
        0.7 * float(payload["geometry"]["top_width_nm"]),
    )
    ax.set_ylim(float(payload["geometry"]["depth_nm"]), 0.0)
    ax.set_aspect("auto")
    ax.set_xlabel("Lateral position (nm)")
    ax.set_ylabel("Depth (nm)")
    ax.set_title("B  Full SiN cross-section after dHF 20 s", loc="left")
    ax.text(
        0.02,
        0.02,
        "bottom intact",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=9,
        bbox={"facecolor": "white", "alpha": 0.75, "edgecolor": "none"},
    )

    ax = axes[1, 0]
    ax.pcolormesh(
        x_edges,
        z_edges,
        solid,
        shading="flat",
        cmap="viridis",
        vmin=0.0,
        vmax=1.0,
    )
    ax.set_xlim(
        -0.7 * float(payload["geometry"]["top_width_nm"]),
        0.7 * float(payload["geometry"]["top_width_nm"]),
    )
    ax.set_ylim(2.0, 0.0)
    ax.set_xlabel("Lateral position (nm)")
    ax.set_ylabel("Depth (nm)")
    retreat_nm = float(
        payload["dhf_calibrated_endpoint"]["top_retreat_nm"]
    )
    ax.axhline(
        retreat_nm,
        color="white",
        linestyle="--",
        linewidth=1.5,
    )
    ax.text(
        0.02,
        0.95,
        f"sub-grid top retreat = {retreat_nm:.4f} nm",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=9,
        color="white",
        bbox={"facecolor": "black", "alpha": 0.55, "edgecolor": "none"},
    )
    ax.set_title("C  Top 2 nm zoom (fractional solid)", loc="left")

    ax = axes[1, 1]
    sensitivity = payload["sc1_sensitivity"]
    alpha = [
        float(row["alpha_SC1_to_initial_dHF_rate"])
        for row in sensitivity
    ]
    retreat = [
        float(row["total_top_retreat_after_SC1_nm"])
        for row in sensitivity
    ]
    x = np.arange(len(alpha), dtype=float)
    bars = ax.bar(x, retreat, color="#F2B134", edgecolor="black")
    ax.axhline(
        retreat_nm,
        color="#D1495B",
        linestyle="--",
        linewidth=1.4,
        label="calibrated dHF-only",
    )
    for bar, value in zip(bars, retreat):
        ax.text(
            bar.get_x() + 0.5 * bar.get_width(),
            value,
            f"{value:.3f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )
    ax.set_xticks(x, [f"{value:g}" for value in alpha])
    ax.set_xlabel(r"$\alpha$ = SC1 rate / initial dHF rate")
    ax.set_ylabel("Total top retreat (nm)")
    ax.set_title("D  Uncalibrated SC1 sensitivity", loc="left")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(fontsize=8)
    ax.text(
        0.98,
        0.04,
        "not a process prediction",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=8,
        color="#8B1E2D",
    )

    colorbar = fig.colorbar(
        mesh,
        ax=axes[0, 1],
        fraction=0.046,
        pad=0.04,
    )
    colorbar.set_label("SiN solid fraction")
    fig.suptitle(
        "SiN full-fill control: only the dHF 20 s stage is calibrated",
        fontsize=14,
        fontweight="bold",
    )
    fig.subplots_adjust(
        left=0.08,
        right=0.93,
        bottom=0.08,
        top=0.91,
        wspace=0.28,
        hspace=0.32,
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=220, bbox_inches="tight")
    plt.close(fig)
    return path


def _write_manifest(
    output_dir: Path,
    names: Sequence[str],
    *,
    input_path: Path,
) -> Path:
    payload = {
        "algorithm": "sha256",
        "files": {
            name: {
                "sha256": _sha256(output_dir / name),
                "size_bytes": (output_dir / name).stat().st_size,
            }
            for name in names
            if (output_dir / name).is_file()
        },
        "inputs": {
            str(input_path): {
                "sha256": _sha256(input_path),
                "size_bytes": input_path.stat().st_size,
            }
        },
    }
    return _save_json(payload, output_dir / MANIFEST_NAME)


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config = SiNFullFillRecipeConfig(geometry_id=args.geometry)
    series = load_blanket_time_series_csv(args.input_csv)
    payload = run_sin_fullfill_recipe_screen(series, config)
    payload["input_artifact"] = {
        "path": str(args.input_csv),
        "sha256": _sha256(args.input_csv),
    }
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    _save_json(payload, output_dir / RESULT_NAME)
    _write_csv(payload["stage_states"], output_dir / STAGE_CSV_NAME)
    _write_csv(payload["sc1_sensitivity"], output_dir / SC1_CSV_NAME)
    write_readme(
        payload,
        output_dir / README_NAME,
        input_path=args.input_csv,
    )
    names = [RESULT_NAME, STAGE_CSV_NAME, SC1_CSV_NAME, README_NAME]
    if not args.no_figure:
        plot_recipe_screen(
            payload,
            output_dir / FIGURE_NAME,
            input_path=args.input_csv,
        )
        names.append(FIGURE_NAME)
    _write_manifest(output_dir, names, input_path=args.input_csv)
    return payload


if __name__ == "__main__":
    main()

"""Measured blanket time-series calibration for thin bottom-pad screening.

The central representation is the cumulative etch amount interpolated between
measured times.  It intentionally does not fit a passivation, depletion, or
surface-conversion mechanism to a short series without replicate uncertainty.
Linear fits are retained only as comparison clocks.
"""

from __future__ import annotations

import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from trench_geometry import GEOMETRY_PRESETS


SCHEMA_VERSION = "measured-blanket-clock/v1"


def _finite_nonnegative(name: str, value: float) -> float:
    result = float(value)
    if not math.isfinite(result) or result < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    return result


def _positive_tuple(name: str, values: Iterable[float]) -> tuple[float, ...]:
    result = tuple(float(value) for value in values)
    if not result or any(
        not math.isfinite(value) or value <= 0.0 for value in result
    ):
        raise ValueError(f"{name} must contain finite positive values")
    if len(set(result)) != len(result):
        raise ValueError(f"{name} cannot contain duplicates")
    return result


@dataclass(frozen=True)
class BlanketEtchPoint:
    time_s: float
    etch_amount_nm: float
    point_kind: str
    source_note: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "time_s", _finite_nonnegative("time_s", self.time_s)
        )
        object.__setattr__(
            self,
            "etch_amount_nm",
            _finite_nonnegative("etch_amount_nm", self.etch_amount_nm),
        )
        if self.point_kind not in {"assumed_origin", "user_measurement"}:
            raise ValueError("unknown blanket point_kind")
        if not self.source_note.strip():
            raise ValueError("source_note cannot be empty")


@dataclass(frozen=True)
class BlanketEtchTimeSeries:
    calibration_id: str
    material: str
    condition_note: str
    points: tuple[BlanketEtchPoint, ...]

    def __post_init__(self) -> None:
        if not self.calibration_id.strip() or not self.material.strip():
            raise ValueError("calibration_id and material cannot be empty")
        if not self.condition_note.strip():
            raise ValueError("condition_note cannot be empty")
        if len(self.points) < 3:
            raise ValueError("at least three cumulative etch points are required")
        times = [point.time_s for point in self.points]
        amounts = [point.etch_amount_nm for point in self.points]
        if any(right <= left for left, right in zip(times, times[1:])):
            raise ValueError("blanket times must be strictly increasing")
        if any(right < left for left, right in zip(amounts, amounts[1:])):
            raise ValueError("cumulative etch amount must be non-decreasing")
        if times[0] != 0.0 or amounts[0] != 0.0:
            raise ValueError("the cumulative series must include (0 s, 0 nm)")
        if self.points[0].point_kind != "assumed_origin":
            raise ValueError("the zero point must be labelled assumed_origin")

    @property
    def maximum_measured_time_s(self) -> float:
        return self.points[-1].time_s

    @property
    def maximum_measured_etch_nm(self) -> float:
        return self.points[-1].etch_amount_nm

    def to_dict(self) -> dict[str, object]:
        return {
            "calibration_id": self.calibration_id,
            "material": self.material,
            "condition_note": self.condition_note,
            "points": [asdict(point) for point in self.points],
            "maximum_measured_time_s": self.maximum_measured_time_s,
            "maximum_measured_etch_nm": self.maximum_measured_etch_nm,
        }


@dataclass(frozen=True)
class MeasuredBottomPadConfig:
    geometry_ids: tuple[str, ...] = ("10_10_180", "7_7_170")
    bottom_pad_thicknesses_nm: tuple[float, ...] = (0.5, 1.0, 2.0, 5.0)
    bottom_local_rate_factors: tuple[float, ...] = (1.0, 0.3, 0.1)
    exposure_times_s: tuple[float, ...] = (30.0, 60.0, 120.0, 180.0)
    literature_comparison_rate_nm_min: float = 0.08
    residue_detection_threshold_nm: float = 0.05

    def __post_init__(self) -> None:
        if not self.geometry_ids or set(self.geometry_ids).difference(
            GEOMETRY_PRESETS
        ):
            raise ValueError("geometry_ids must be a non-empty known selection")
        if len(set(self.geometry_ids)) != len(self.geometry_ids):
            raise ValueError("geometry_ids cannot contain duplicates")
        object.__setattr__(
            self,
            "bottom_pad_thicknesses_nm",
            _positive_tuple(
                "bottom_pad_thicknesses_nm",
                self.bottom_pad_thicknesses_nm,
            ),
        )
        factors = _positive_tuple(
            "bottom_local_rate_factors",
            self.bottom_local_rate_factors,
        )
        if any(value > 1.0 for value in factors):
            raise ValueError("bottom_local_rate_factors cannot exceed one")
        object.__setattr__(self, "bottom_local_rate_factors", factors)
        object.__setattr__(
            self,
            "exposure_times_s",
            _positive_tuple("exposure_times_s", self.exposure_times_s),
        )
        if (
            not math.isfinite(self.literature_comparison_rate_nm_min)
            or self.literature_comparison_rate_nm_min <= 0.0
        ):
            raise ValueError(
                "literature_comparison_rate_nm_min must be positive"
            )
        _finite_nonnegative(
            "residue_detection_threshold_nm",
            self.residue_detection_threshold_nm,
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for name in (
            "geometry_ids",
            "bottom_pad_thicknesses_nm",
            "bottom_local_rate_factors",
            "exposure_times_s",
        ):
            result[name] = list(result[name])
        return result


def load_blanket_time_series_csv(path: str | Path) -> BlanketEtchTimeSeries:
    source = Path(path)
    rows: list[dict[str, str]] = []
    with source.open(encoding="utf-8", newline="") as stream:
        for row_number, raw in enumerate(csv.DictReader(stream), start=2):
            row = {key: str(value or "").strip() for key, value in raw.items()}
            for required in (
                "calibration_id",
                "material",
                "time_s",
                "etch_amount_nm",
                "point_kind",
                "condition_note",
                "source_note",
            ):
                if not row.get(required):
                    raise ValueError(
                        f"{source}:{row_number}: {required} is required"
                    )
            rows.append(row)
    if not rows:
        raise ValueError("blanket time-series CSV contains no rows")
    calibration_ids = {row["calibration_id"] for row in rows}
    materials = {row["material"] for row in rows}
    condition_notes = {row["condition_note"] for row in rows}
    if (
        len(calibration_ids) != 1
        or len(materials) != 1
        or len(condition_notes) != 1
    ):
        raise ValueError(
            "one CSV must contain exactly one calibration/material/condition"
        )
    points = tuple(
        BlanketEtchPoint(
            time_s=float(row["time_s"]),
            etch_amount_nm=float(row["etch_amount_nm"]),
            point_kind=row["point_kind"],
            source_note=row["source_note"],
        )
        for row in rows
    )
    return BlanketEtchTimeSeries(
        calibration_id=next(iter(calibration_ids)),
        material=next(iter(materials)),
        condition_note=next(iter(condition_notes)),
        points=points,
    )


def _fit_metrics(
    observed: Sequence[float],
    predicted: Sequence[float],
) -> dict[str, object]:
    if len(observed) != len(predicted) or not observed:
        raise ValueError("observed and predicted must be equal non-empty series")
    residuals = [
        float(actual) - float(model)
        for actual, model in zip(observed, predicted)
    ]
    squared_error = sum(value * value for value in residuals)
    mean = sum(float(value) for value in observed) / len(observed)
    total_squared = sum((float(value) - mean) ** 2 for value in observed)
    return {
        "residuals_nm": residuals,
        "rmse_nm": math.sqrt(squared_error / len(observed)),
        "maximum_absolute_residual_nm": max(
            abs(value) for value in residuals
        ),
        "centered_r_squared": (
            None
            if total_squared == 0.0
            else 1.0 - squared_error / total_squared
        ),
    }


def analyze_blanket_time_series(
    series: BlanketEtchTimeSeries,
) -> dict[str, object]:
    times_min = [point.time_s / 60.0 for point in series.points]
    amounts_nm = [point.etch_amount_nm for point in series.points]
    interval_rows = []
    for left, right in zip(series.points, series.points[1:]):
        duration_min = (right.time_s - left.time_s) / 60.0
        rate = (right.etch_amount_nm - left.etch_amount_nm) / duration_min
        interval_rows.append(
            {
                "start_time_s": left.time_s,
                "end_time_s": right.time_s,
                "incremental_etch_nm": (
                    right.etch_amount_nm - left.etch_amount_nm
                ),
                "interval_rate_nm_min": rate,
            }
        )
    apparent_rows = [
        {
            "time_s": point.time_s,
            "etch_amount_nm": point.etch_amount_nm,
            "origin_averaged_rate_nm_min": (
                point.etch_amount_nm / (point.time_s / 60.0)
            ),
        }
        for point in series.points
        if point.time_s > 0.0
    ]

    denominator = sum(value * value for value in times_min)
    origin_slope = sum(
        time * amount for time, amount in zip(times_min, amounts_nm)
    ) / denominator
    origin_prediction = [origin_slope * value for value in times_min]
    origin_fit = {
        "equation": "etch_nm = slope_nm_min * time_min",
        "slope_nm_min": origin_slope,
        "intercept_nm": 0.0,
        **_fit_metrics(amounts_nm, origin_prediction),
    }

    mean_time = sum(times_min) / len(times_min)
    mean_amount = sum(amounts_nm) / len(amounts_nm)
    centered_denominator = sum(
        (value - mean_time) ** 2 for value in times_min
    )
    intercept_slope = sum(
        (time - mean_time) * (amount - mean_amount)
        for time, amount in zip(times_min, amounts_nm)
    ) / centered_denominator
    intercept = mean_amount - intercept_slope * mean_time
    intercept_prediction = [
        intercept + intercept_slope * value for value in times_min
    ]
    unconstrained_fit = {
        "equation": "etch_nm = intercept_nm + slope_nm_min * time_min",
        "slope_nm_min": intercept_slope,
        "intercept_nm": intercept,
        "physical_zero_origin_satisfied": abs(intercept) < 1.0e-12,
        "used_as_calibration_clock": False,
        **_fit_metrics(amounts_nm, intercept_prediction),
    }

    first_rate = float(interval_rows[0]["interval_rate_nm_min"])
    last_rate = float(interval_rows[-1]["interval_rate_nm_min"])
    return {
        "series": series.to_dict(),
        "interval_rates": interval_rows,
        "origin_averaged_rates": apparent_rows,
        "origin_constrained_linear_fit": origin_fit,
        "unconstrained_linear_fit": unconstrained_fit,
        "last_to_first_interval_rate_ratio": last_rate / first_rate,
        "first_to_last_interval_rate_reduction_fraction": (
            1.0 - last_rate / first_rate
        ),
        "constant_rate_validated": False,
        "reason_constant_rate_not_validated": (
            "interval rates decline and no replicate/metrology uncertainty "
            "was supplied; high cumulative-series R2 is not a kinetic test"
        ),
        "preferred_clock": (
            "piecewise-linear cumulative etch between supplied times"
        ),
        "mechanism_inferred_from_deceleration": False,
    }


def piecewise_cumulative_etch_nm(
    series: BlanketEtchTimeSeries,
    time_s: float,
) -> tuple[float | None, str]:
    requested = _finite_nonnegative("time_s", time_s)
    for point in series.points:
        if requested == point.time_s:
            return point.etch_amount_nm, point.point_kind
    if requested > series.maximum_measured_time_s:
        return None, "outside_measured_window"
    for left, right in zip(series.points, series.points[1:]):
        if left.time_s < requested < right.time_s:
            fraction = (
                (requested - left.time_s) / (right.time_s - left.time_s)
            )
            return (
                left.etch_amount_nm
                + fraction * (right.etch_amount_nm - left.etch_amount_nm),
                "piecewise_interpolated",
            )
    raise RuntimeError("requested time was not bracketed")


def piecewise_time_at_etch_amount_s(
    series: BlanketEtchTimeSeries,
    etch_amount_nm: float,
) -> float | None:
    target = _finite_nonnegative("etch_amount_nm", etch_amount_nm)
    if target == 0.0:
        return 0.0
    if target > series.maximum_measured_etch_nm:
        return None
    for left, right in zip(series.points, series.points[1:]):
        if target == left.etch_amount_nm:
            return left.time_s
        if left.etch_amount_nm < target <= right.etch_amount_nm:
            increment = right.etch_amount_nm - left.etch_amount_nm
            if increment == 0.0:
                return left.time_s
            fraction = (target - left.etch_amount_nm) / increment
            return left.time_s + fraction * (right.time_s - left.time_s)
    if target == series.points[-1].etch_amount_nm:
        return series.points[-1].time_s
    raise RuntimeError("requested etch amount was not bracketed")


def run_measured_bottom_pad_screen(
    series: BlanketEtchTimeSeries,
    config: MeasuredBottomPadConfig | None = None,
) -> dict[str, object]:
    resolved = MeasuredBottomPadConfig() if config is None else config
    analysis = analyze_blanket_time_series(series)
    origin_rate_nm_min = float(
        analysis["origin_constrained_linear_fit"]["slope_nm_min"]
    )
    literature_rate_nm_min = resolved.literature_comparison_rate_nm_min
    cases: list[dict[str, object]] = []
    for geometry_id in resolved.geometry_ids:
        geometry = GEOMETRY_PRESETS[geometry_id]
        for thickness_nm in resolved.bottom_pad_thicknesses_nm:
            for local_factor in resolved.bottom_local_rate_factors:
                target_blanket_etch_nm = thickness_nm / local_factor
                empirical_clear_s = piecewise_time_at_etch_amount_s(
                    series, target_blanket_etch_nm
                )
                origin_clear_s = (
                    60.0
                    * target_blanket_etch_nm
                    / origin_rate_nm_min
                )
                literature_clear_s = (
                    60.0
                    * target_blanket_etch_nm
                    / literature_rate_nm_min
                )
                checkpoints = []
                for exposure_s in resolved.exposure_times_s:
                    empirical_etch_nm, point_status = (
                        piecewise_cumulative_etch_nm(series, exposure_s)
                    )
                    if empirical_etch_nm is None:
                        empirical_row: dict[str, object] = {
                            "removed_thickness_nm": None,
                            "remaining_thickness_nm": None,
                            "remaining_fraction": None,
                            "detectable_at_threshold": None,
                            "status": point_status,
                        }
                    else:
                        removed_nm = local_factor * empirical_etch_nm
                        remaining_nm = max(0.0, thickness_nm - removed_nm)
                        empirical_row = {
                            "removed_thickness_nm": removed_nm,
                            "remaining_thickness_nm": remaining_nm,
                            "remaining_fraction": remaining_nm / thickness_nm,
                            "detectable_at_threshold": (
                                remaining_nm
                                > resolved.residue_detection_threshold_nm
                            ),
                            "status": point_status,
                        }
                    origin_removed_nm = (
                        local_factor
                        * origin_rate_nm_min
                        * exposure_s
                        / 60.0
                    )
                    literature_removed_nm = (
                        local_factor
                        * literature_rate_nm_min
                        * exposure_s
                        / 60.0
                    )
                    checkpoints.append(
                        {
                            "exposure_time_s": exposure_s,
                            "empirical_piecewise": empirical_row,
                            "origin_linear_comparison": {
                                "removed_thickness_nm": origin_removed_nm,
                                "remaining_thickness_nm": max(
                                    0.0,
                                    thickness_nm - origin_removed_nm,
                                ),
                            },
                            "literature_linear_comparison": {
                                "removed_thickness_nm": literature_removed_nm,
                                "remaining_thickness_nm": max(
                                    0.0,
                                    thickness_nm - literature_removed_nm,
                                ),
                            },
                        }
                    )
                cases.append(
                    {
                        "case_id": (
                            f"{geometry_id}__{series.calibration_id}__"
                            f"h{thickness_nm:g}__f{local_factor:g}"
                        ),
                        "geometry_id": geometry_id,
                        "bottom_width_nm": geometry.bottom_width_nm,
                        "depth_nm": geometry.depth_nm,
                        "material": series.material,
                        "initial_bottom_pad_thickness_nm": thickness_nm,
                        "bottom_local_rate_factor": local_factor,
                        "local_factor_interpretation": (
                            "multiplicative scaling of the cumulative blanket "
                            "removal; screening parameter, not measured"
                        ),
                        "empirical_clear_time_s": empirical_clear_s,
                        "empirical_clear_time_status": (
                            "within_measured_window"
                            if empirical_clear_s is not None
                            else "right_censored_at_measured_window"
                        ),
                        "empirical_right_censor_time_s": (
                            series.maximum_measured_time_s
                        ),
                        "origin_linear_clear_time_s": origin_clear_s,
                        "origin_linear_requires_extrapolation": (
                            origin_clear_s > series.maximum_measured_time_s
                        ),
                        "literature_linear_clear_time_s": literature_clear_s,
                        "checkpoints": checkpoints,
                    }
                )
    payload = {
        "schema_version": SCHEMA_VERSION,
        "model_name": "measured SiN blanket bottom-pad recalibration",
        "notice": (
            "Screening result, not a process recipe. Piecewise interpolation "
            "is empirical and no mechanism is inferred from deceleration."
        ),
        "source_series": series.to_dict(),
        "analysis": analysis,
        "config": resolved.to_dict(),
        "calibration_comparison": {
            "preferred": "empirical_piecewise_within_0_to_180_s",
            "origin_linear_rate_nm_min": origin_rate_nm_min,
            "literature_comparison_rate_nm_min": literature_rate_nm_min,
            "origin_linear_to_literature_rate_ratio": (
                origin_rate_nm_min / literature_rate_nm_min
            ),
            "primary_kmc_scalar_override_activated": False,
            "reason_not_activated": (
                "measurement temperature and uncertainty are missing, and "
                "the measured clock is time dependent"
            ),
        },
        "assumptions": {
            "zero_second_origin_is_assumed": True,
            "piecewise_interpolation_between_measurements": True,
            "extrapolation_beyond_180_s": False,
            "fully_wetted_bottom_pad": True,
            "local_factor_multiplies_cumulative_removal": True,
            "passivation_or_depletion_mechanism_fit": False,
        },
        "cases": cases,
    }
    json.dumps(payload, ensure_ascii=False, allow_nan=False)
    return payload


def save_measured_bottom_pad_csv(
    payload: Mapping[str, object],
    path: str | Path,
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for case in payload["cases"]:
        for checkpoint in case["checkpoints"]:
            empirical = checkpoint["empirical_piecewise"]
            origin = checkpoint["origin_linear_comparison"]
            literature = checkpoint["literature_linear_comparison"]
            rows.append(
                {
                    "case_id": case["case_id"],
                    "geometry_id": case["geometry_id"],
                    "initial_bottom_pad_thickness_nm": case[
                        "initial_bottom_pad_thickness_nm"
                    ],
                    "bottom_local_rate_factor": case[
                        "bottom_local_rate_factor"
                    ],
                    "exposure_time_s": checkpoint["exposure_time_s"],
                    "empirical_status": empirical["status"],
                    "empirical_removed_thickness_nm": empirical[
                        "removed_thickness_nm"
                    ],
                    "empirical_remaining_thickness_nm": empirical[
                        "remaining_thickness_nm"
                    ],
                    "origin_linear_remaining_thickness_nm": origin[
                        "remaining_thickness_nm"
                    ],
                    "literature_remaining_thickness_nm": literature[
                        "remaining_thickness_nm"
                    ],
                }
            )
    if not rows:
        raise ValueError("payload contains no bottom-pad checkpoints")
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=tuple(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return target


__all__ = [
    "BlanketEtchPoint",
    "BlanketEtchTimeSeries",
    "MeasuredBottomPadConfig",
    "SCHEMA_VERSION",
    "analyze_blanket_time_series",
    "load_blanket_time_series_csv",
    "piecewise_cumulative_etch_nm",
    "piecewise_time_at_etch_amount_s",
    "run_measured_bottom_pad_screen",
    "save_measured_bottom_pad_csv",
]

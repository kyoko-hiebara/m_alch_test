"""Mean-field chemistry at a locally resolved solid/liquid interface.

The continuum transport solver is responsible for supplying the *local*
interface temperature and solution state.  This module deliberately does not
average bulk-solution and substrate-backside temperatures.  Rates are expressed
as fractions of the initially represented surface inventory per second; a
length/area conversion belongs in the caller's geometry model.

The model is intentionally compact and parameterized.  It is useful for model
coupling, sensitivity studies, and calibration, but its defaults are not a wet
process recipe or a validated kinetic data set.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace
from enum import Enum
from typing import Mapping

import numpy as np
from scipy.integrate import solve_ivp

from numerical_settings import LOOSE_NUMERICS


GAS_CONSTANT_J_MOL_K = 8.31446261815324


class SurfaceMaterial(str, Enum):
    """Gap-fill material represented by a mean-field surface cell."""

    SIN = "SiN"
    SICN = "SiCN"
    SIOCN = "SiOCN"


class ReactionMode(str, Enum):
    """How reaction extent changes the represented solid inventory."""

    DIRECT_ETCH = "direct_etch"
    OXIDATIVE_CONVERSION = "oxidative_conversion"
    ETCH_CONVERTED = "etch_converted"
    RINSE = "rinse"


def _finite_nonnegative(name: str, value: float) -> float:
    value = float(value)
    if not math.isfinite(value) or value < 0.0:
        raise ValueError(f"{name} must be finite and nonnegative")
    return value


@dataclass(frozen=True)
class LocalInterfaceConditions:
    """Local state passed from a thermal/transport calculation.

    Activities are dimensionless.  Concentrations can use any consistent unit,
    provided the same unit is used for the reference concentrations in
    :class:`MeanFieldKineticParameters`.
    """

    temperature_K: float
    reactant_activity: float = 1.0
    product_activity: float = 0.0
    reactant_concentration: float = 1.0
    product_concentration: float = 0.0

    def __post_init__(self) -> None:
        temperature = float(self.temperature_K)
        if not math.isfinite(temperature) or temperature <= 0.0:
            raise ValueError("temperature_K must be finite and positive")
        for name in (
            "reactant_activity",
            "product_activity",
            "reactant_concentration",
            "product_concentration",
        ):
            _finite_nonnegative(name, getattr(self, name))


@dataclass(frozen=True)
class MeanFieldSurfaceState:
    """Bounded surface inventory and blocking coverages.

    ``material_coverage`` is the fraction of the initial solid inventory still
    present. ``converted_coverage`` is the subset converted to a fluoride-
    removable phase. Product and passivation coverages are interfacial site
    fractions and therefore share a unit-capacity constraint.
    """

    material_coverage: float = 1.0
    converted_coverage: float = 0.0
    product_coverage: float = 0.0
    passivation_coverage: float = 0.0

    def __post_init__(self) -> None:
        for name in (
            "material_coverage",
            "converted_coverage",
            "product_coverage",
            "passivation_coverage",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must lie in [0, 1]")
        if self.converted_coverage > self.material_coverage + 1.0e-12:
            raise ValueError("converted_coverage cannot exceed material_coverage")
        if self.product_coverage + self.passivation_coverage > 1.0 + 1.0e-12:
            raise ValueError(
                "product_coverage + passivation_coverage cannot exceed one"
            )

    @property
    def unconverted_coverage(self) -> float:
        return max(0.0, self.material_coverage - self.converted_coverage)

    @property
    def open_interfacial_fraction(self) -> float:
        return max(0.0, 1.0 - self.product_coverage - self.passivation_coverage)

    def clear_interfacial(self) -> "MeanFieldSurfaceState":
        """Clear adsorbed products/passivation while preserving solid history."""

        return replace(self, product_coverage=0.0, passivation_coverage=0.0)


@dataclass(frozen=True)
class MeanFieldKineticParameters:
    """Parameterized kinetic law; values must be calibrated for a real film.

    The reference rate is a first-order surface frequency.  Material factors
    describe relative reactivity only and do not imply transferability between
    deposited films with different H/C/O content or thermal history.
    """

    reaction_mode: ReactionMode | str = ReactionMode.DIRECT_ETCH
    rate_constant_ref_s: float = 1.0e-3
    reference_temperature_K: float = 298.15
    activation_energy_J_mol: float = 0.0
    reactant_activity_order: float = 1.0
    reactant_concentration_order: float = 0.0
    reactant_reference_concentration: float = 1.0
    product_reference_concentration: float = 1.0
    product_activity_inhibition: float = 0.0
    product_concentration_inhibition: float = 0.0
    product_blocking_weight: float = 1.0
    passivation_blocking_weight: float = 1.0
    product_yield: float = 0.0
    product_deposition_s: float = 0.0
    product_release_s: float = 0.0
    passivation_yield: float = 0.0
    passivation_formation_s: float = 0.0
    passivation_removal_s: float = 0.0
    material_rate_factors: Mapping[SurfaceMaterial | str, float] | None = None

    def __post_init__(self) -> None:
        try:
            mode = ReactionMode(self.reaction_mode)
        except ValueError as exc:
            raise ValueError(f"unknown reaction_mode {self.reaction_mode!r}") from exc
        object.__setattr__(self, "reaction_mode", mode)

        positive = ("reference_temperature_K", "reactant_reference_concentration", "product_reference_concentration")
        for name in positive:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        for name in (
            "rate_constant_ref_s",
            "activation_energy_J_mol",
            "reactant_activity_order",
            "reactant_concentration_order",
            "product_activity_inhibition",
            "product_concentration_inhibition",
            "product_blocking_weight",
            "passivation_blocking_weight",
            "product_yield",
            "product_deposition_s",
            "product_release_s",
            "passivation_yield",
            "passivation_formation_s",
            "passivation_removal_s",
        ):
            _finite_nonnegative(name, getattr(self, name))

        factors = self.material_rate_factors
        if factors is None:
            factors = {
                SurfaceMaterial.SIN: 1.0,
                SurfaceMaterial.SICN: 1.0,
                SurfaceMaterial.SIOCN: 1.0,
            }
        normalized: dict[SurfaceMaterial, float] = {}
        for material, factor in factors.items():
            try:
                key = SurfaceMaterial(material)
            except ValueError as exc:
                raise ValueError(f"unknown material factor key {material!r}") from exc
            normalized[key] = _finite_nonnegative(
                f"material_rate_factors[{key.value}]", factor
            )
        for material in SurfaceMaterial:
            normalized.setdefault(material, 1.0)
        object.__setattr__(self, "material_rate_factors", normalized)


@dataclass(frozen=True)
class SurfaceRate:
    """Instantaneous mean-field rate and its multiplicative components."""

    reaction_rate_coverage_s: float
    rate_constant_s: float
    reactive_coverage: float
    open_fraction: float
    reactant_factor: float
    inhibition_factor: float
    product_deposition_rate_s: float
    product_release_rate_s: float
    passivation_formation_rate_s: float
    passivation_removal_rate_s: float


@dataclass(frozen=True)
class SurfaceAdvanceResult:
    state: MeanFieldSurfaceState
    elapsed_s: float
    reaction_extent: float
    mean_reaction_rate_coverage_s: float
    initial_rate: SurfaceRate
    final_rate: SurfaceRate
    function_evaluations: int


class MeanFieldSurfaceChemistry:
    """Evaluate and integrate a bounded local surface chemistry model."""

    def __init__(self, parameters: MeanFieldKineticParameters):
        self.parameters = parameters

    def rate_constant_s(
        self,
        material: SurfaceMaterial | str,
        temperature_K: float,
    ) -> float:
        material = SurfaceMaterial(material)
        temperature = float(temperature_K)
        if not math.isfinite(temperature) or temperature <= 0.0:
            raise ValueError("temperature_K must be finite and positive")
        p = self.parameters
        exponent = -p.activation_energy_J_mol / GAS_CONSTANT_J_MOL_K * (
            1.0 / temperature - 1.0 / p.reference_temperature_K
        )
        # Avoid a floating-point overflow while retaining a very wide range.
        exponent = float(np.clip(exponent, -700.0, 700.0))
        return (
            p.rate_constant_ref_s
            * math.exp(exponent)
            * p.material_rate_factors[material]
        )

    def evaluate_rate(
        self,
        material: SurfaceMaterial | str,
        state: MeanFieldSurfaceState,
        conditions: LocalInterfaceConditions,
    ) -> SurfaceRate:
        material = SurfaceMaterial(material)
        p = self.parameters
        if p.reaction_mode in (
            ReactionMode.DIRECT_ETCH,
            ReactionMode.OXIDATIVE_CONVERSION,
        ):
            reactive_coverage = state.unconverted_coverage
        elif p.reaction_mode is ReactionMode.ETCH_CONVERTED:
            reactive_coverage = state.converted_coverage
        else:
            reactive_coverage = 0.0

        reactant_factor = (
            conditions.reactant_activity ** p.reactant_activity_order
            * (
                conditions.reactant_concentration
                / p.reactant_reference_concentration
            )
            ** p.reactant_concentration_order
        )
        inhibition = (
            1.0
            + p.product_activity_inhibition * conditions.product_activity
            + p.product_concentration_inhibition
            * conditions.product_concentration
            / p.product_reference_concentration
        )
        open_fraction = max(
            0.0,
            1.0
            - p.product_blocking_weight * state.product_coverage
            - p.passivation_blocking_weight * state.passivation_coverage,
        )
        rate_constant = self.rate_constant_s(material, conditions.temperature_K)
        reaction_rate = (
            rate_constant
            * reactive_coverage
            * open_fraction
            * reactant_factor
            / inhibition
        )
        site_capacity = state.open_interfacial_fraction
        product_driver = (
            conditions.product_activity
            + conditions.product_concentration / p.product_reference_concentration
        )
        product_deposition = p.product_deposition_s * product_driver * site_capacity
        product_release = (
            p.product_release_s
            * (1.0 + conditions.reactant_activity)
            * state.product_coverage
        )
        passivation_formation = (
            p.passivation_formation_s * product_driver * site_capacity
        )
        passivation_removal = (
            p.passivation_removal_s
            * (1.0 + reactant_factor)
            * state.passivation_coverage
        )
        return SurfaceRate(
            reaction_rate_coverage_s=reaction_rate,
            rate_constant_s=rate_constant,
            reactive_coverage=reactive_coverage,
            open_fraction=open_fraction,
            reactant_factor=reactant_factor,
            inhibition_factor=inhibition,
            product_deposition_rate_s=product_deposition,
            product_release_rate_s=product_release,
            passivation_formation_rate_s=passivation_formation,
            passivation_removal_rate_s=passivation_removal,
        )

    @staticmethod
    def _project(values: np.ndarray) -> MeanFieldSurfaceState:
        material = float(np.clip(values[0], 0.0, 1.0))
        converted = float(np.clip(values[1], 0.0, material))
        product = float(np.clip(values[2], 0.0, 1.0))
        passivation = float(np.clip(values[3], 0.0, 1.0))
        occupied = product + passivation
        if occupied > 1.0:
            product /= occupied
            passivation /= occupied
        return MeanFieldSurfaceState(
            material_coverage=material,
            converted_coverage=converted,
            product_coverage=product,
            passivation_coverage=passivation,
        )

    def _derivatives(
        self,
        material: SurfaceMaterial,
        conditions: LocalInterfaceConditions,
        values: np.ndarray,
    ) -> np.ndarray:
        state = self._project(values)
        p = self.parameters
        rates = self.evaluate_rate(material, state, conditions)
        reaction = rates.reaction_rate_coverage_s
        d_material = 0.0
        d_converted = 0.0
        if p.reaction_mode is ReactionMode.DIRECT_ETCH:
            d_material = -reaction
        elif p.reaction_mode is ReactionMode.OXIDATIVE_CONVERSION:
            d_converted = reaction
        elif p.reaction_mode is ReactionMode.ETCH_CONVERTED:
            d_material = -reaction
            d_converted = -reaction

        capacity = state.open_interfacial_fraction
        d_product = (
            p.product_yield * reaction * capacity
            + rates.product_deposition_rate_s
            - rates.product_release_rate_s
        )
        d_passivation = (
            p.passivation_yield * reaction * capacity
            + rates.passivation_formation_rate_s
            - rates.passivation_removal_rate_s
        )
        return np.asarray(
            [d_material, d_converted, d_product, d_passivation, reaction],
            dtype=float,
        )

    def advance(
        self,
        material: SurfaceMaterial | str,
        state: MeanFieldSurfaceState,
        conditions: LocalInterfaceConditions,
        duration_s: float,
        *,
        relative_tolerance: float = LOOSE_NUMERICS.nonlinear_relative_tolerance,
        absolute_tolerance: float = LOOSE_NUMERICS.linear_absolute_tolerance,
        maximum_step_s: float | None = LOOSE_NUMERICS.maximum_time_step_s,
    ) -> SurfaceAdvanceResult:
        """Advance with a stiff, positivity-projected mean-field integration."""

        material = SurfaceMaterial(material)
        duration = _finite_nonnegative("duration_s", duration_s)
        initial_rate = self.evaluate_rate(material, state, conditions)
        if duration == 0.0:
            return SurfaceAdvanceResult(
                state=state,
                elapsed_s=0.0,
                reaction_extent=0.0,
                mean_reaction_rate_coverage_s=0.0,
                initial_rate=initial_rate,
                final_rate=initial_rate,
                function_evaluations=0,
            )
        rtol = float(relative_tolerance)
        atol = float(absolute_tolerance)
        if not math.isfinite(rtol) or rtol <= 0.0:
            raise ValueError("relative_tolerance must be finite and positive")
        if not math.isfinite(atol) or atol <= 0.0:
            raise ValueError("absolute_tolerance must be finite and positive")
        max_step = math.inf if maximum_step_s is None else float(maximum_step_s)
        if max_step <= 0.0 or math.isnan(max_step):
            raise ValueError("maximum_step_s must be positive")

        y0 = np.asarray(
            [
                state.material_coverage,
                state.converted_coverage,
                state.product_coverage,
                state.passivation_coverage,
                0.0,
            ],
            dtype=float,
        )
        solution = solve_ivp(
            lambda _time, values: self._derivatives(material, conditions, values),
            (0.0, duration),
            y0,
            method="BDF",
            rtol=rtol,
            atol=atol,
            max_step=max_step,
        )
        if not solution.success:
            raise RuntimeError(f"surface chemistry integration failed: {solution.message}")
        final_values = solution.y[:, -1]
        final_state = self._project(final_values)
        extent = max(0.0, float(final_values[4]))
        final_rate = self.evaluate_rate(material, final_state, conditions)
        return SurfaceAdvanceResult(
            state=final_state,
            elapsed_s=duration,
            reaction_extent=extent,
            mean_reaction_rate_coverage_s=extent / duration,
            initial_rate=initial_rate,
            final_rate=final_rate,
            function_evaluations=int(solution.nfev),
        )


# Concise alias for callers that prefer a model-style name.
SurfaceChemistryModel = MeanFieldSurfaceChemistry


__all__ = [
    "GAS_CONSTANT_J_MOL_K",
    "LocalInterfaceConditions",
    "MeanFieldKineticParameters",
    "MeanFieldSurfaceChemistry",
    "MeanFieldSurfaceState",
    "ReactionMode",
    "SurfaceAdvanceResult",
    "SurfaceChemistryModel",
    "SurfaceMaterial",
    "SurfaceRate",
]

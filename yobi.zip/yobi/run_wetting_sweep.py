#!/usr/bin/env python3
"""CLI for contact-angle, meniscus, wetting-delay, and gas sensitivities."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS
from wetting_sweep import (
    SCENARIO_ORDER,
    WettingSweepConfig,
    plot_wetting_phase_maps,
    plot_wetting_summary,
    run_wetting_sweep,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run 2-D contact-angle, entrance-meniscus, wetting-delay, and "
            "seeded bottom-gas sensitivity cases. Wetting and gas parameters "
            "are uncalibrated hypotheses, not a wet-process recipe."
        )
    )
    parser.add_argument(
        "--geometry",
        choices=tuple(GEOMETRY_PRESETS),
        action="append",
        help="repeat to select geometries (default: both straight-wall standards)",
    )
    parser.add_argument(
        "--scenario",
        choices=SCENARIO_ORDER,
        action="append",
        help="repeat to select wetting/gas hypotheses (default: all)",
    )
    parser.add_argument(
        "--material",
        choices=("SiN", "SiCN", "SiOCN"),
        default="SiN",
    )
    parser.add_argument("--grid-spacing-nm", type=float, default=2.0)
    parser.add_argument("--probe-grid-spacing-nm", type=float, default=0.5)
    parser.add_argument("--reservoir-height-nm", type=float, default=4.0)
    parser.add_argument(
        "--maximum-etch-velocity-nm-s",
        type=float,
        default=4.0,
    )
    parser.add_argument(
        "--maximum-time-over-planar-clear",
        type=float,
        default=1.40,
    )
    parser.add_argument(
        "--maximum-fractional-front-change",
        type=float,
        default=0.80,
    )
    parser.add_argument(
        "--contact-angle-deg",
        type=float,
        action="append",
        help=(
            "open-trench probe contact angle; repeatable "
            "(default: 20, 60, 85, 95, 120 degree)"
        ),
    )
    parser.add_argument("--probe-samples", type=int, default=121)
    parser.add_argument(
        "--maximum-probe-displacement-nm",
        type=float,
        default=0.20,
    )
    parser.add_argument(
        "--solution-temperature-k",
        type=float,
        default=298.15,
        help="independent HF-solution bulk temperature [K]",
    )
    parser.add_argument(
        "--substrate-temperature-k",
        type=float,
        default=323.15,
        help="independent Si-substrate backside temperature [K]",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent geometry/scenario processes; 0 selects up to 4",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("wetting_sweep_results.json"),
    )
    parser.add_argument(
        "--summary-figure",
        type=Path,
        default=Path("wetting_summary.png"),
    )
    parser.add_argument(
        "--phase-figure",
        type=Path,
        default=Path("wetting_phase_maps.png"),
    )
    parser.add_argument(
        "--no-figure",
        action="store_true",
        help="skip both summary and phase-map figures",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    geometries = tuple(dict.fromkeys(args.geometry or DEFAULT_GEOMETRY_NAMES))
    scenarios = tuple(dict.fromkeys(args.scenario or SCENARIO_ORDER))
    contact_angles = tuple(
        dict.fromkeys(args.contact_angle_deg or (20.0, 60.0, 85.0, 95.0, 120.0))
    )
    case_count = len(geometries) * len(scenarios)
    if args.workers < 0:
        raise ValueError("workers must be zero or a positive integer")
    workers = (
        min(4, os.cpu_count() or 1, case_count)
        if args.workers == 0
        else min(args.workers, case_count)
    )
    payload = run_wetting_sweep(
        WettingSweepConfig(
            geometries=geometries,
            scenarios=scenarios,
            material=args.material,
            grid_spacing_nm=args.grid_spacing_nm,
            probe_grid_spacing_nm=args.probe_grid_spacing_nm,
            reservoir_height_nm=args.reservoir_height_nm,
            maximum_etch_velocity_nm_s=args.maximum_etch_velocity_nm_s,
            maximum_time_over_planar_clear=(
                args.maximum_time_over_planar_clear
            ),
            maximum_fractional_front_change=(
                args.maximum_fractional_front_change
            ),
            contact_angles_deg=contact_angles,
            probe_samples=args.probe_samples,
            maximum_probe_displacement_nm=(
                args.maximum_probe_displacement_nm
            ),
            solution_bulk_temperature_K=args.solution_temperature_k,
            substrate_backside_temperature_K=args.substrate_temperature_k,
            parallel_workers=workers,
        )
    )
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text + "\n", encoding="utf-8")
    if not args.no_figure:
        args.summary_figure.parent.mkdir(parents=True, exist_ok=True)
        args.phase_figure.parent.mkdir(parents=True, exist_ok=True)
        plot_wetting_summary(payload, str(args.summary_figure))
        plot_wetting_phase_maps(payload, str(args.phase_figure))
    return payload


if __name__ == "__main__":
    main()

"""Compact diagnostic figure for the HF-only bottom-residue screen."""

from __future__ import annotations

import math
from pathlib import Path
from typing import Mapping, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


_MATERIAL_LABELS = {
    "kawarazaki_sicn_c22_dhf0p15_linear30s": "SiCN C22",
    "kawarazaki_sicn_c40_dhf0p15_linear30s": "SiCN C40",
    "kawarazaki_siocn_c5_dhf0p15_linear30s": "SiOCN C5",
    "kawarazaki_sin_reference_dhf0p15_linear30s": "SiN",
}

_COLORS = {
    "SiCN C22": "#d62728",
    "SiCN C40": "#1f77b4",
    "SiOCN C5": "#2ca02c",
    "SiN": "#202020",
}


def _float(value: object, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default


def _blanket_panel(axis, payload: Mapping[str, object]) -> None:
    anchors = payload.get("blanket_anchors", [])
    labels = [
        _MATERIAL_LABELS.get(str(row["preset_id"]), str(row["material"]))
        for row in anchors
    ]
    values = [_float(row["central_rate_nm_min"]) for row in anchors]
    colors = [_COLORS.get(label, "#777777") for label in labels]
    positions = np.arange(len(labels))
    axis.bar(positions, values, color=colors, width=0.7)
    axis.set_xticks(positions, labels, rotation=20, ha="right")
    axis.set_ylabel("dHF-only rate (nm/min)")
    axis.set_title("A  Blanket chemical clock")
    axis.grid(axis="y", alpha=0.25)
    upper = max(values, default=1.0) * 1.16
    axis.set_ylim(0.0, upper)
    for x, value in zip(positions, values, strict=True):
        axis.text(
            x,
            value + 0.025 * upper,
            f"{value:.2f}",
            ha="center",
            fontsize=8,
        )


def _bottom_clear_panel(axis, payload: Mapping[str, object]) -> None:
    cases = payload["bottom_pad_burn_down"]["cases"]
    subset = [
        case
        for case in cases
        if math.isclose(
            _float(case["initial_bottom_pad_thickness_nm"]),
            1.0,
            abs_tol=1.0e-12,
        )
        and case["geometry_id"] == "10_10_180"
    ]
    factors = sorted(
        {
            _float(case["bottom_local_rate_factor"])
            for case in subset
        },
        reverse=True,
    )
    preset_ids = list(
        dict.fromkeys(str(case["preset_id"]) for case in subset)
    )
    labels = [
        _MATERIAL_LABELS.get(preset_id, preset_id)
        for preset_id in preset_ids
    ]
    positions = np.arange(len(labels))
    width = 0.22
    for index, factor in enumerate(factors):
        values = []
        for preset_id in preset_ids:
            match = next(
                case
                for case in subset
                if case["preset_id"] == preset_id
                and math.isclose(
                    _float(case["bottom_local_rate_factor"]),
                    factor,
                    abs_tol=1.0e-12,
                )
            )
            values.append(_float(match["central_clear_time_min"]))
        offset = (index - (len(factors) - 1) / 2.0) * width
        axis.bar(
            positions + offset,
            values,
            width=width,
            label=f"local rate x{factor:g}",
            alpha=0.85,
        )
    axis.set_yscale("log")
    axis.set_xticks(positions, labels, rotation=20, ha="right")
    axis.set_ylabel("1 nm bottom-pad clear time (min)")
    axis.set_title("B  Thickness / local-rate degeneracy")
    axis.legend(fontsize=7)
    axis.grid(axis="y", which="both", alpha=0.25)


def _wetting_panel(axis, payload: Mapping[str, object]) -> None:
    rows = payload["wetting_and_gas"]["summary"]
    scenarios = list(
        dict.fromkeys(str(row["scenario"]) for row in rows)
    )
    geometries = list(
        dict.fromkeys(str(row["geometry_id"]) for row in rows)
    )
    positions = np.arange(len(scenarios))
    width = 0.35
    for index, geometry in enumerate(geometries):
        values = [
            100.0
            * _float(
                next(
                    row["bottom_15pct_remaining_fraction"]
                    for row in rows
                    if row["scenario"] == scenario
                    and row["geometry_id"] == geometry
                )
            )
            for scenario in scenarios
        ]
        axis.bar(
            positions + (index - (len(geometries) - 1) / 2.0) * width,
            values,
            width=width,
            label=geometry.replace("_", "x"),
        )
    short = {
        "baseline_inherited_liquid": "full wet",
        "instant_hydrophilic_capillary": "hydrophilic",
        "entrance_delayed": "pinning",
        "bottom_gas_ideal_compression": "ideal gas",
        "bottom_gas_fixed_volume_bound": "persistent gas",
        "combined_adverse": "combined",
    }
    axis.set_xticks(
        positions,
        [short.get(name, name) for name in scenarios],
        rotation=28,
        ha="right",
    )
    axis.set_ylim(0.0, 108.0)
    axis.set_ylabel("Bottom 15% native residue (%)")
    axis.set_title("C  Wetting / gas hypotheses")
    axis.legend(fontsize=7)
    axis.grid(axis="y", alpha=0.25)


def _passivation_panel(axis, payload: Mapping[str, object]) -> None:
    by_time = payload["product_and_passivation"][
        "summary_at_absolute_time_s"
    ]
    rows = by_time.get("120", by_time.get("120.0", []))
    scenarios = list(
        dict.fromkeys(str(row["scenario"]) for row in rows)
    )
    scenarios = [scenario for scenario in scenarios if scenario != "null"]
    preset_ids = list(
        dict.fromkeys(str(row["preset_id"]) for row in rows)
    )
    x = np.arange(len(preset_ids))
    width = 0.18
    for scenario_index, scenario in enumerate(scenarios):
        ratios = []
        for preset_id in preset_ids:
            null_removed = []
            scenario_removed = []
            for row in rows:
                if row["preset_id"] != preset_id:
                    continue
                removed = 1.0 - _float(row["remaining_mass_fraction"], 1.0)
                if row["scenario"] == "null":
                    null_removed.append(removed)
                elif row["scenario"] == scenario:
                    scenario_removed.append(removed)
            denominator = float(np.median(null_removed)) if null_removed else 0.0
            numerator = (
                float(np.median(scenario_removed))
                if scenario_removed
                else 0.0
            )
            ratios.append(
                100.0 * numerator / denominator
                if denominator > 0.0
                else 0.0
            )
        offset = (scenario_index - (len(scenarios) - 1) / 2.0) * width
        axis.bar(
            x + offset,
            ratios,
            width=width,
            label=scenario.replace("_", " "),
        )
    axis.axhline(100.0, color="#444444", linewidth=0.8, linestyle="--")
    axis.set_xticks(
        x,
        [_MATERIAL_LABELS.get(preset, preset) for preset in preset_ids],
        rotation=20,
        ha="right",
    )
    axis.set_ylabel("Removal at 120 s / null (%)")
    axis.set_title("D  Product / passivation sensitivity")
    axis.legend(fontsize=6)
    axis.grid(axis="y", alpha=0.25)


def _drydown_panel(axis, payload: Mapping[str, object]) -> None:
    conditions = payload["rinse_and_dry_redeposition"]["post_hf_conditions"]

    def select(
        *,
        dry: bool,
        quench: bool,
        rinse_rate: float,
        drying_rate: float = 1.0 / 30.0,
    ) -> Mapping[str, object]:
        return next(
            condition
            for condition in conditions
            if bool(condition["dry_enabled"]) is dry
            and bool(condition["immediate_quench"]) is quench
            and math.isclose(
                _float(condition["rinse_exchange_rate_s"]),
                rinse_rate,
                abs_tol=1.0e-12,
            )
            and math.isclose(
                _float(condition["drying_rate_s"]),
                drying_rate,
                abs_tol=1.0e-12,
            )
        )

    selected = [
        ("no dry", select(dry=False, quench=False, rinse_rate=0.05)),
        ("no rinse", select(dry=True, quench=False, rinse_rate=0.0)),
        ("reference", select(dry=True, quench=False, rinse_rate=0.05)),
        ("immediate", select(dry=True, quench=True, rinse_rate=0.05)),
        ("high flow", select(dry=True, quench=False, rinse_rate=0.20)),
    ]
    values = [
        100.0 * _float(item["effective_capture_fraction_of_generated"])
        for _, item in selected
    ]
    axis.bar(
        np.arange(len(selected)),
        values,
        color=["#777777", "#d95f02", "#7570b3", "#1b9e77", "#66a61e"],
    )
    axis.set_xticks(
        np.arange(len(selected)),
        [label for label, _ in selected],
        rotation=25,
        ha="right",
    )
    axis.set_ylabel("Captured generated inventory (%)")
    axis.set_title("E  Rinse / dry redeposition closure")
    axis.grid(axis="y", alpha=0.25)


def _decision_panel(axis) -> None:
    axis.axis("off")
    axis.set_title("F  Stage-resolved discriminator", loc="left")
    lines = [
        "Wet HF endpoint: native film?",
        "  yes -> thickness/rate, wetting/gas, passivation",
        "  no  -> inspect after rinse/dry",
        "",
        "Appears only after dry?",
        "  yes -> redeposition branch",
        "",
        "Forced pre-wet removes it?",
        "  yes -> pinning / persistent gas",
        "",
        "Single endpoint cannot split",
        "thickness from local rate.",
    ]
    axis.text(
        0.02,
        0.96,
        "\n".join(lines),
        va="top",
        ha="left",
        family="monospace",
        fontsize=9,
        linespacing=1.25,
    )


def plot_hf_only_residue_screen(
    payload: Mapping[str, object],
    path: str | Path,
) -> Path:
    """Render a six-panel mechanism summary."""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    figure, axes = plt.subplots(2, 3, figsize=(14.5, 8.5))
    _blanket_panel(axes[0, 0], payload)
    _bottom_clear_panel(axes[0, 1], payload)
    _wetting_panel(axes[0, 2], payload)
    _passivation_panel(axes[1, 0], payload)
    _drydown_panel(axes[1, 1], payload)
    _decision_panel(axes[1, 2])
    figure.suptitle(
        "HF-only trench-bottom residue: calibrated clock and mechanism screens",
        fontsize=14,
        fontweight="bold",
    )
    figure.text(
        0.01,
        0.01,
        (
            "Blanket clock: Fig. 2 dHF-only central values. "
            "All mechanism coefficients beyond the clock are screening hypotheses."
        ),
        fontsize=8,
        color="#444444",
    )
    figure.tight_layout(rect=(0.0, 0.035, 1.0, 0.96))
    figure.savefig(target, dpi=180, bbox_inches="tight")
    plt.close(figure)
    return target


__all__ = ["plot_hf_only_residue_screen"]

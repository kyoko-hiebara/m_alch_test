"""Quasi-steady two-dimensional transport on a tapered-trench grid.

Coordinates are expressed in nanometres and seconds.  The first array axis is
depth (positive downwards) and the second is the lateral direction.  Only
liquid cells connected to the top reservoir participate in a solve; isolated
pockets are deliberately treated as no-flux regions.

The finite-volume equations use concentration units chosen by the caller.  A
surface transfer velocity therefore has units nm/s, while an interface source
flux has units ``concentration * nm/s``.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
from scipy import ndimage, sparse
from scipy.sparse import linalg as sparse_linalg

from numerical_settings import LOOSE_NUMERICS
from trench_geometry import TaperedTrench2D


FOUR_CONNECTED = np.asarray(
    [[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=np.int8
)


@dataclass(frozen=True)
class CartesianGrid2D:
    """Cell-centred Cartesian grid spanning a reservoir and one trench."""

    geometry: TaperedTrench2D
    lateral_nm: np.ndarray
    depth_nm: np.ndarray
    dx_nm: float
    dz_nm: float
    reservoir_mask: np.ndarray
    cavity_mask: np.ndarray

    def __post_init__(self) -> None:
        if self.lateral_nm.ndim != 1 or self.depth_nm.ndim != 1:
            raise ValueError("lateral_nm and depth_nm must be one-dimensional")
        if len(self.lateral_nm) < 2 or len(self.depth_nm) < 2:
            raise ValueError("grid needs at least two cells along each axis")
        for name in ("dx_nm", "dz_nm"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.reservoir_mask.shape != self.shape or self.cavity_mask.shape != self.shape:
            raise ValueError("grid masks must match (depth, lateral) grid shape")
        if np.any(self.reservoir_mask & self.cavity_mask):
            raise ValueError("reservoir and cavity masks must not overlap")

    @classmethod
    def from_geometry(
        cls,
        geometry: TaperedTrench2D,
        *,
        spacing_nm: float = 1.0,
        reservoir_height_nm: float = 10.0,
        lateral_margin_nm: float = 4.0,
    ) -> "CartesianGrid2D":
        """Construct a symmetric grid with the opening exactly at depth zero.

        The trench depth is divided into an integer number of rows, so the
        actual ``dz_nm`` may be slightly smaller than ``spacing_nm``.  This
        keeps the floor at the requested physical depth.
        """
        for name, value in (
            ("spacing_nm", spacing_nm),
            ("reservoir_height_nm", reservoir_height_nm),
        ):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if not math.isfinite(lateral_margin_nm) or lateral_margin_nm < 0.0:
            raise ValueError("lateral_margin_nm must be finite and non-negative")

        nz_trench = max(1, int(math.ceil(geometry.depth_nm / spacing_nm)))
        dz_nm = geometry.depth_nm / nz_trench
        nz_reservoir = max(1, int(math.ceil(reservoir_height_nm / dz_nm)))
        reservoir_depth = -(
            np.arange(nz_reservoir, 0, -1, dtype=float) - 0.5
        ) * dz_nm
        trench_depth = (np.arange(nz_trench, dtype=float) + 0.5) * dz_nm
        depth_nm = np.concatenate((reservoir_depth, trench_depth))

        domain_width = geometry.top_width_nm + 2.0 * lateral_margin_nm
        nx = max(2, int(math.ceil(domain_width / spacing_nm)))
        # An odd number places a cell centre on the symmetry plane.
        if nx % 2 == 0:
            nx += 1
        dx_nm = float(spacing_nm)
        lateral_nm = (np.arange(nx, dtype=float) - 0.5 * (nx - 1)) * dx_nm

        lateral_mesh, depth_mesh = np.meshgrid(
            lateral_nm, depth_nm, indexing="xy"
        )
        reservoir_mask = depth_mesh < 0.0
        cavity_mask = np.asarray(
            geometry.contains_nm(lateral_mesh, depth_mesh), dtype=bool
        )
        return cls(
            geometry=geometry,
            lateral_nm=lateral_nm,
            depth_nm=depth_nm,
            dx_nm=dx_nm,
            dz_nm=dz_nm,
            reservoir_mask=reservoir_mask,
            cavity_mask=cavity_mask,
        )

    @property
    def shape(self) -> tuple[int, int]:
        return (len(self.depth_nm), len(self.lateral_nm))

    @property
    def cell_area_nm2(self) -> float:
        return self.dx_nm * self.dz_nm

    @property
    def lateral_mesh_nm(self) -> np.ndarray:
        return np.broadcast_to(self.lateral_nm[None, :], self.shape)

    @property
    def depth_mesh_nm(self) -> np.ndarray:
        return np.broadcast_to(self.depth_nm[:, None], self.shape)


@dataclass(frozen=True)
class TopBoundaryCondition:
    """Dirichlet or film-transfer boundary at the top reservoir surface."""

    bulk_value: float
    kind: Literal["dirichlet", "robin"] = "dirichlet"
    transfer_velocity_nm_s: float | None = None

    def __post_init__(self) -> None:
        if not math.isfinite(self.bulk_value) or self.bulk_value < 0.0:
            raise ValueError("bulk_value must be finite and non-negative")
        if self.kind not in {"dirichlet", "robin"}:
            raise ValueError("top boundary kind must be 'dirichlet' or 'robin'")
        if self.kind == "robin":
            value = self.transfer_velocity_nm_s
            if value is None or not math.isfinite(value) or value <= 0.0:
                raise ValueError(
                    "a Robin boundary needs a finite positive transfer velocity"
                )


@dataclass(frozen=True)
class DiffusionSolveResult:
    field: np.ndarray
    connected_liquid_mask: np.ndarray
    converged: bool
    iterations: int
    relative_residual: float
    used_direct_fallback: bool


@dataclass(frozen=True)
class DiffusionInventoryBalance:
    """Integrated steady-state inventory balance for a solved field.

    Rates use the native two-dimensional units ``concentration * nm2 / s``
    per unit out-of-plane span.  ``rate_mol_s_per_nm_span`` converts those
    rates for a one-nanometre span when concentration is supplied in mol/m3.
    A positive top-boundary rate denotes outward transport to the bulk.
    """

    surface_source_rate: float
    volumetric_source_rate: float
    top_outflow_rate: float
    bulk_decay_rate: float
    residual_rate: float
    relative_error: float

    @staticmethod
    def rate_mol_s_per_nm_span(rate: float) -> float:
        return float(rate) * 1.0e-27


@dataclass(frozen=True)
class CoupledTransportResult:
    reactant: DiffusionSolveResult
    product: DiffusionSolveResult
    reactant_at_interface: np.ndarray
    product_at_interface: np.ndarray


def _as_grid_field(
    value: float | np.ndarray,
    shape: tuple[int, int],
    name: str,
    *,
    nonnegative: bool = True,
) -> np.ndarray:
    result = np.broadcast_to(np.asarray(value, dtype=float), shape)
    if np.any(~np.isfinite(result)):
        raise ValueError(f"{name} must contain only finite values")
    if nonnegative and np.any(result < 0.0):
        raise ValueError(f"{name} must be non-negative")
    return result


def connected_to_top(mask: np.ndarray) -> np.ndarray:
    """Keep four-connected components touching the first grid row."""
    mask = np.asarray(mask, dtype=bool)
    if mask.ndim != 2:
        raise ValueError("mask must be two-dimensional")
    labels, _ = ndimage.label(mask, structure=FOUR_CONNECTED)
    top_labels = np.unique(labels[0, :])
    top_labels = top_labels[top_labels != 0]
    if len(top_labels) == 0:
        return np.zeros_like(mask)
    return np.isin(labels, top_labels)


def interface_face_length_on_solid(
    grid: CartesianGrid2D,
    liquid_mask: np.ndarray,
    solid_mask: np.ndarray,
) -> np.ndarray:
    """Return liquid-contact face length associated with every solid cell."""
    liquid = np.asarray(liquid_mask, dtype=bool)
    solid = np.asarray(solid_mask, dtype=bool)
    if liquid.shape != grid.shape or solid.shape != grid.shape:
        raise ValueError("liquid and solid masks must match the grid")
    result = np.zeros(grid.shape, dtype=float)
    # Neighbours above/below share a lateral face of length dx.
    result[1:, :] += solid[1:, :] * liquid[:-1, :] * grid.dx_nm
    result[:-1, :] += solid[:-1, :] * liquid[1:, :] * grid.dx_nm
    # Neighbours left/right share a vertical face of length dz.
    result[:, 1:] += solid[:, 1:] * liquid[:, :-1] * grid.dz_nm
    result[:, :-1] += solid[:, :-1] * liquid[:, 1:] * grid.dz_nm
    return result


def interface_average_on_solid(
    field: np.ndarray,
    liquid_mask: np.ndarray,
    solid_mask: np.ndarray,
) -> np.ndarray:
    """Average adjacent liquid-cell values onto reactive solid cells."""
    values = np.asarray(field, dtype=float)
    liquid = np.asarray(liquid_mask, dtype=bool)
    solid = np.asarray(solid_mask, dtype=bool)
    if values.shape != liquid.shape or solid.shape != liquid.shape:
        raise ValueError("field and masks must have identical shapes")
    total = np.zeros_like(values)
    count = np.zeros(values.shape, dtype=np.int16)

    valid = solid[1:, :] & liquid[:-1, :]
    total[1:, :][valid] += values[:-1, :][valid]
    count[1:, :][valid] += 1
    valid = solid[:-1, :] & liquid[1:, :]
    total[:-1, :][valid] += values[1:, :][valid]
    count[:-1, :][valid] += 1
    valid = solid[:, 1:] & liquid[:, :-1]
    total[:, 1:][valid] += values[:, :-1][valid]
    count[:, 1:][valid] += 1
    valid = solid[:, :-1] & liquid[:, 1:]
    total[:, :-1][valid] += values[:, 1:][valid]
    count[:, :-1][valid] += 1

    result = np.zeros_like(values)
    np.divide(total, count, out=result, where=count > 0)
    return result


def _top_conductance(
    grid: CartesianGrid2D,
    diffusivity_nm2_s: float,
    boundary: TopBoundaryCondition,
) -> float:
    half_cell_resistance = 0.5 * grid.dz_nm / diffusivity_nm2_s
    if boundary.kind == "dirichlet":
        resistance = half_cell_resistance
    else:
        assert boundary.transfer_velocity_nm_s is not None
        resistance = half_cell_resistance + 1.0 / boundary.transfer_velocity_nm_s
    return grid.dx_nm / resistance


def diffusion_inventory_balance(
    grid: CartesianGrid2D,
    result: DiffusionSolveResult,
    reactive_solid_mask: np.ndarray,
    *,
    diffusivity_nm2_s: float,
    top_boundary: TopBoundaryCondition,
    interface_source_flux: float | np.ndarray = 0.0,
    volumetric_source_per_s: float | np.ndarray = 0.0,
    bulk_decay_per_s: float | np.ndarray = 0.0,
) -> DiffusionInventoryBalance:
    """Integrate source and loss terms for a quasi-steady solution.

    The diagnostic mirrors the finite-volume discretisation used by
    :func:`solve_quasi_steady_diffusion`, including the half-cell resistance
    at the top boundary.  It is intentionally independent of the iterative
    linear residual so physical inventory closure can be reported directly.
    """

    if not math.isfinite(diffusivity_nm2_s) or diffusivity_nm2_s <= 0.0:
        raise ValueError("diffusivity_nm2_s must be finite and positive")
    connected = np.asarray(result.connected_liquid_mask, dtype=bool)
    solid = np.asarray(reactive_solid_mask, dtype=bool)
    field = np.asarray(result.field, dtype=float)
    if connected.shape != grid.shape or solid.shape != grid.shape:
        raise ValueError("result and solid masks must match the grid")
    if field.shape != grid.shape or np.any(~np.isfinite(field)):
        raise ValueError("result field must be finite and match the grid")
    surface_source = _as_grid_field(
        interface_source_flux,
        grid.shape,
        "interface_source_flux",
    )
    volume_source = _as_grid_field(
        volumetric_source_per_s,
        grid.shape,
        "volumetric_source_per_s",
    )
    decay = _as_grid_field(
        bulk_decay_per_s,
        grid.shape,
        "bulk_decay_per_s",
    )
    face_length = interface_face_length_on_solid(grid, connected, solid)
    surface_rate = float(np.sum(surface_source * face_length))
    volume_rate = float(
        np.sum(volume_source[connected]) * grid.cell_area_nm2
    )
    top_connected = connected[0, :]
    top_g = _top_conductance(grid, diffusivity_nm2_s, top_boundary)
    top_outflow = float(
        top_g
        * np.sum(field[0, top_connected] - top_boundary.bulk_value)
    )
    decay_rate = float(
        np.sum(decay[connected] * field[connected]) * grid.cell_area_nm2
    )
    residual = surface_rate + volume_rate - top_outflow - decay_rate
    scale = max(
        abs(surface_rate) + abs(volume_rate),
        abs(top_outflow) + abs(decay_rate),
        np.finfo(float).tiny,
    )
    return DiffusionInventoryBalance(
        surface_source_rate=surface_rate,
        volumetric_source_rate=volume_rate,
        top_outflow_rate=top_outflow,
        bulk_decay_rate=decay_rate,
        residual_rate=residual,
        relative_error=abs(residual) / scale,
    )


def solve_quasi_steady_diffusion(
    grid: CartesianGrid2D,
    liquid_mask: np.ndarray,
    reactive_solid_mask: np.ndarray,
    *,
    diffusivity_nm2_s: float,
    top_boundary: TopBoundaryCondition,
    interface_sink_velocity_nm_s: float | np.ndarray = 0.0,
    interface_source_flux: float | np.ndarray = 0.0,
    volumetric_source_per_s: float | np.ndarray = 0.0,
    bulk_decay_per_s: float | np.ndarray = 0.0,
    relative_tolerance: float = LOOSE_NUMERICS.linear_relative_tolerance,
    absolute_tolerance: float = LOOSE_NUMERICS.linear_absolute_tolerance,
    max_iterations: int = LOOSE_NUMERICS.maximum_iterations,
    direct_fallback: bool = True,
) -> DiffusionSolveResult:
    """Solve a linear steady diffusion-reaction finite-volume system."""
    if not math.isfinite(diffusivity_nm2_s) or diffusivity_nm2_s <= 0.0:
        raise ValueError("diffusivity_nm2_s must be finite and positive")
    if relative_tolerance <= 0.0 or absolute_tolerance < 0.0:
        raise ValueError("solver tolerances must be non-negative with positive rtol")
    if max_iterations < 1:
        raise ValueError("max_iterations must be positive")

    liquid = np.asarray(liquid_mask, dtype=bool)
    solid = np.asarray(reactive_solid_mask, dtype=bool)
    if liquid.shape != grid.shape or solid.shape != grid.shape:
        raise ValueError("liquid and solid masks must match the grid")
    if np.any(liquid & solid):
        raise ValueError("liquid and reactive solid masks must not overlap")
    connected = connected_to_top(liquid)
    active_flat = np.flatnonzero(connected)
    result_field = np.zeros(grid.shape, dtype=float)
    if len(active_flat) == 0:
        return DiffusionSolveResult(
            field=result_field,
            connected_liquid_mask=connected,
            converged=True,
            iterations=0,
            relative_residual=0.0,
            used_direct_fallback=False,
        )

    sink = _as_grid_field(
        interface_sink_velocity_nm_s,
        grid.shape,
        "interface_sink_velocity_nm_s",
    )
    surface_source = _as_grid_field(
        interface_source_flux, grid.shape, "interface_source_flux"
    )
    volume_source = _as_grid_field(
        volumetric_source_per_s, grid.shape, "volumetric_source_per_s"
    )
    decay = _as_grid_field(
        bulk_decay_per_s, grid.shape, "bulk_decay_per_s"
    )

    index = np.full(grid.shape, -1, dtype=np.int64)
    index.flat[active_flat] = np.arange(len(active_flat), dtype=np.int64)
    matrix = sparse.lil_matrix((len(active_flat), len(active_flat)), dtype=float)
    rhs = np.zeros(len(active_flat), dtype=float)
    cell_area = grid.cell_area_nm2
    g_vertical = diffusivity_nm2_s * grid.dx_nm / grid.dz_nm
    g_horizontal = diffusivity_nm2_s * grid.dz_nm / grid.dx_nm
    top_g = _top_conductance(grid, diffusivity_nm2_s, top_boundary)
    directions = (
        (-1, 0, g_vertical, grid.dx_nm),
        (1, 0, g_vertical, grid.dx_nm),
        (0, -1, g_horizontal, grid.dz_nm),
        (0, 1, g_horizontal, grid.dz_nm),
    )

    n_rows, n_cols = grid.shape
    for row, col in zip(*np.unravel_index(active_flat, grid.shape), strict=True):
        local = int(index[row, col])
        diagonal = decay[row, col] * cell_area
        rhs[local] = volume_source[row, col] * cell_area
        if row == 0:
            diagonal += top_g
            rhs[local] += top_g * top_boundary.bulk_value
        for drow, dcol, conductance, face_length in directions:
            other_row = row + drow
            other_col = col + dcol
            if not (0 <= other_row < n_rows and 0 <= other_col < n_cols):
                continue
            if connected[other_row, other_col]:
                diagonal += conductance
                matrix[local, int(index[other_row, other_col])] -= conductance
            elif solid[other_row, other_col]:
                diagonal += sink[other_row, other_col] * face_length
                rhs[local] += surface_source[other_row, other_col] * face_length
        matrix[local, local] += diagonal

    matrix_csr = matrix.tocsr()
    diagonal = matrix_csr.diagonal()
    if np.any(diagonal <= 0.0):
        raise ValueError(
            "diffusion system is unanchored; add a top boundary, decay, or surface sink"
        )
    inverse_diagonal = 1.0 / diagonal
    preconditioner = sparse_linalg.LinearOperator(
        matrix_csr.shape, matvec=lambda vector: inverse_diagonal * vector
    )
    iteration_count = 0

    def count_iteration(_: np.ndarray) -> None:
        nonlocal iteration_count
        iteration_count += 1

    reference = np.full(len(active_flat), top_boundary.bulk_value, dtype=float)
    correction_rhs = rhs - matrix_csr @ reference
    correction, info = sparse_linalg.cg(
        matrix_csr,
        correction_rhs,
        x0=np.zeros(len(active_flat), dtype=float),
        rtol=relative_tolerance,
        atol=absolute_tolerance,
        maxiter=max_iterations,
        M=preconditioner,
        callback=count_iteration,
    )
    used_direct = False
    if info != 0 and direct_fallback:
        correction = sparse_linalg.spsolve(matrix_csr, correction_rhs)
        used_direct = True
    solution = reference + correction
    if np.any(~np.isfinite(solution)):
        raise RuntimeError("diffusion solver produced non-finite concentrations")
    # Roundoff can produce tiny negative concentrations in otherwise positive
    # finite-volume systems.
    clipped_solution = np.maximum(solution, 0.0)
    if np.any(clipped_solution != solution):
        # Only reconstruct the correction if clipping changed the solved field.
        # Otherwise, subtraction from a large reference can erase a genuinely
        # small correction and corrupt its residual diagnostic.
        correction = clipped_solution - reference
    solution = clipped_solution
    residual = matrix_csr @ correction - correction_rhs
    residual_scale = max(
        float(np.linalg.norm(correction_rhs)), absolute_tolerance, 1.0e-30
    )
    relative_residual = float(np.linalg.norm(residual) / residual_scale)
    converged = bool(
        relative_residual
        <= max(relative_tolerance, absolute_tolerance / residual_scale)
    )
    result_field.flat[active_flat] = solution
    return DiffusionSolveResult(
        field=result_field,
        connected_liquid_mask=connected,
        converged=converged,
        iterations=iteration_count,
        relative_residual=relative_residual,
        used_direct_fallback=used_direct,
    )


def solve_reactant_and_product(
    grid: CartesianGrid2D,
    liquid_mask: np.ndarray,
    reactive_solid_mask: np.ndarray,
    *,
    reactant_diffusivity_nm2_s: float,
    product_diffusivity_nm2_s: float,
    reactant_top_boundary: TopBoundaryCondition,
    product_top_boundary: TopBoundaryCondition,
    reactant_surface_transfer_nm_s: float | np.ndarray,
    product_interface_source_flux: float | np.ndarray,
    product_bulk_decay_per_s: float = 0.0,
    relative_tolerance: float = LOOSE_NUMERICS.linear_relative_tolerance,
    max_iterations: int = LOOSE_NUMERICS.maximum_iterations,
) -> CoupledTransportResult:
    """Convenience wrapper for reactant consumption and product generation."""
    reactant = solve_quasi_steady_diffusion(
        grid,
        liquid_mask,
        reactive_solid_mask,
        diffusivity_nm2_s=reactant_diffusivity_nm2_s,
        top_boundary=reactant_top_boundary,
        interface_sink_velocity_nm_s=reactant_surface_transfer_nm_s,
        relative_tolerance=relative_tolerance,
        max_iterations=max_iterations,
    )
    product = solve_quasi_steady_diffusion(
        grid,
        liquid_mask,
        reactive_solid_mask,
        diffusivity_nm2_s=product_diffusivity_nm2_s,
        top_boundary=product_top_boundary,
        interface_source_flux=product_interface_source_flux,
        bulk_decay_per_s=product_bulk_decay_per_s,
        relative_tolerance=relative_tolerance,
        max_iterations=max_iterations,
    )
    return CoupledTransportResult(
        reactant=reactant,
        product=product,
        reactant_at_interface=interface_average_on_solid(
            reactant.field,
            reactant.connected_liquid_mask,
            reactive_solid_mask,
        ),
        product_at_interface=interface_average_on_solid(
            product.field,
            product.connected_liquid_mask,
            reactive_solid_mask,
        ),
    )

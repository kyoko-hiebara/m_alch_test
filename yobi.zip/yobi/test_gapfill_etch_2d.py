from __future__ import annotations

import unittest

import numpy as np

from etch_process import EtchProcessConfig, ThermalBoundaryConditions
from gapfill_etch_2d import (
    GapFillEtch2D,
    PassivationParameters,
    SaturatingRateLaw,
    TransportParameters,
)
from numerical_settings import NumericalSettings
from persistent_deposit import DepositParameters
from spatial_etchability import SpatialEtchabilityParameters
from trench_geometry import GEOMETRY_PRESETS, TaperedTrench2D
from wetting_2d import WettingParameters


def make_process(geometry: TaperedTrench2D | None = None) -> EtchProcessConfig:
    return EtchProcessConfig(
        geometry=geometry or TaperedTrench2D("toy", 8.0, 6.0, 20.0),
        gap_fill_material="SiN",
        thermal_bc=ThermalBoundaryConditions(
            solution_bulk_temperature_K=298.15,
            substrate_backside_temperature_K=318.15,
        ),
    )


class GapFillEtch2DTests(unittest.TestCase):
    def settings(self) -> NumericalSettings:
        return NumericalSettings(
            maximum_fractional_state_change=0.5,
            maximum_time_step_s=10.0,
        )

    def test_driver_starts_with_full_gap_fill_and_reservoir_only(self) -> None:
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
        )
        self.assertTrue(np.all(model.front.solid_fraction[model.grid.cavity_mask] == 1.0))
        self.assertFalse(np.any(model.front.liquid_mask & model.grid.cavity_mask))
        self.assertTrue(np.all(model.front.liquid_mask[model.grid.reservoir_mask]))

    def test_zero_callable_rate_preserves_solid_but_returns_history(self) -> None:
        calls: list[int] = []

        def zero_rate(reactant, product, passivation, interface):
            calls.append(np.count_nonzero(interface))
            return np.zeros_like(reactant)

        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            rate_law=zero_rate,
            numerical_settings=self.settings(),
        )
        initial_area = model.front.diagnostics().remaining_solid_area_nm2
        result = model.run(2.0, time_step_s=1.0)
        self.assertEqual(len(result.history), 2)
        self.assertGreater(len(calls), 0)
        self.assertAlmostEqual(result.final_diagnostics.remaining_solid_area_nm2, initial_area)
        self.assertFalse(result.completed)

    def test_coupled_run_grows_liquid_and_records_fields(self) -> None:
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                reactant_diffusivity_nm2_s=100.0,
                product_diffusivity_nm2_s=60.0,
                reactant_surface_transfer_nm_s=2.0,
                product_yield_concentration=2.0,
                product_bulk_decay_per_s=0.1,
            ),
            passivation=PassivationParameters(
                formation_per_concentration_s=5.0,
                removal_per_s=0.02,
            ),
            numerical_settings=self.settings(),
        )
        initial_area = model.front.diagnostics().remaining_solid_area_nm2
        result = model.run(
            5.0, time_step_s=1.0, snapshot_every_steps=2
        )
        self.assertGreater(len(result.history), 0)
        self.assertGreater(len(result.snapshots), 2)
        self.assertLess(result.final_diagnostics.remaining_solid_area_nm2, initial_area)
        self.assertGreater(result.final_diagnostics.liquid_cells_in_trench, 0)
        self.assertTrue(all(entry.reactant_converged for entry in result.history))
        self.assertTrue(all(entry.product_converged for entry in result.history))
        self.assertTrue(
            all(
                entry.product_inventory_balance_relative_error < 1.0e-3
                for entry in result.history
            )
        )
        self.assertTrue(
            all(entry.product_surface_generation_rate > 0.0 for entry in result.history)
        )
        self.assertTrue(all(entry.nonlinear_converged for entry in result.history))
        self.assertTrue(all(entry.nonlinear_iterations >= 1 for entry in result.history))
        self.assertTrue(
            all(
                entry.nonlinear_relative_change
                <= model.numerics.nonlinear_relative_tolerance
                for entry in result.history
            )
        )
        final = result.snapshots[-1]
        self.assertGreater(np.max(final.reactant), 0.0)
        self.assertGreater(np.max(final.product), 0.0)
        self.assertGreater(np.max(final.passivation), 0.0)
        self.assertLessEqual(np.max(final.passivation), 1.0)
        self.assertTrue(
            all(
                first.remaining_solid_area_nm2 >= second.remaining_solid_area_nm2
                for first, second in zip(result.history, result.history[1:])
            )
        )
        # Snapshot arrays are copies rather than live views of the model state.
        self.assertTrue(np.all(result.snapshots[0].solid_fraction[model.grid.cavity_mask] == 1.0))

    def test_product_velocity_picard_iteration_converges(self) -> None:
        settings = NumericalSettings(
            nonlinear_relative_tolerance=1.0e-6,
            maximum_nonlinear_iterations=100,
            maximum_fractional_state_change=0.5,
            maximum_time_step_s=10.0,
        )
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                reactant_diffusivity_nm2_s=100.0,
                product_diffusivity_nm2_s=5.0,
                reactant_surface_transfer_nm_s=1.0,
                product_yield_concentration=20.0,
            ),
            rate_law=SaturatingRateLaw(
                maximum_velocity_nm_s=1.0,
                half_saturation=0.1,
                product_inhibition=10.0,
            ),
            numerical_settings=settings,
        )

        entry = model.step(0.1)

        self.assertTrue(entry.nonlinear_converged)
        self.assertGreater(entry.nonlinear_iterations, 1)
        self.assertLessEqual(
            entry.nonlinear_relative_change,
            settings.nonlinear_relative_tolerance,
        )
        self.assertTrue(np.all(np.isfinite(model.product_field)))

    def test_zero_product_problem_uses_exact_zero_solution(self) -> None:
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                product_bulk_concentration=0.0,
                product_yield_concentration=0.0,
            ),
            numerical_settings=self.settings(),
        )
        result = model._solve_product(np.ones(model.grid.shape))
        self.assertTrue(result.converged)
        self.assertEqual(result.iterations, 0)
        self.assertEqual(result.relative_residual, 0.0)
        self.assertFalse(result.used_direct_fallback)
        self.assertTrue(np.all(result.field == 0.0))

    def test_spatial_etchability_scales_rate_and_reactant_sink_together(self) -> None:
        def unit_rate(reactant, product, passivation, interface):
            return np.where(interface, 1.0, 0.0)

        model = GapFillEtch2D(
            make_process(),
            spacing_nm=1.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                reactant_surface_transfer_nm_s=3.0,
                product_yield_concentration=0.0,
            ),
            rate_law=unit_rate,
            spatial_etchability=SpatialEtchabilityParameters(
                sidewall_rate_factor=0.1,
                sidewall_influence_length_nm=1.0,
                bottom_rate_factor=0.5,
            ),
            numerical_settings=self.settings(),
        )
        factor = model.spatial_etchability.combined_factor
        np.testing.assert_allclose(
            model.reactant_surface_transfer_field_nm_s,
            3.0 * factor,
        )
        interface = model.front.interface_mask
        velocity = model._evaluate_rate(
            np.ones(model.grid.shape),
            np.zeros(model.grid.shape),
        )
        np.testing.assert_allclose(velocity[interface], factor[interface])
        columns = np.flatnonzero(interface[np.flatnonzero(np.any(interface, axis=1))[0]])
        row = int(np.flatnonzero(np.any(interface, axis=1))[0])
        centre = int(columns[len(columns) // 2])
        edge = int(columns[0])
        self.assertLess(velocity[row, edge], velocity[row, centre])
        result = model.run(0.1, time_step_s=0.1)
        self.assertIs(result.spatial_etchability, model.spatial_etchability)

    def test_dynamic_reactivity_can_scale_the_robin_sink(self) -> None:
        def modifier(product, passivation, interface):
            return np.where(interface, 1.0 - passivation, 1.0)

        model = GapFillEtch2D(
            make_process(),
            spacing_nm=1.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                reactant_surface_transfer_nm_s=4.0,
                product_yield_concentration=0.0,
            ),
            reactant_sink_modifier_law=modifier,
            numerical_settings=self.settings(),
        )
        interface = model.front.interface_mask
        model.passivation_field[interface] = 0.25
        dynamic = model.reactant_surface_transfer_for_current_state_nm_s()
        np.testing.assert_allclose(dynamic[interface], 3.0)
        np.testing.assert_allclose(
            dynamic[~interface],
            model.reactant_surface_transfer_field_nm_s[~interface],
        )

        def invalid_modifier(product, passivation, interface):
            return -np.ones(model.grid.shape)

        model.reactant_sink_modifier_law = invalid_modifier
        with self.assertRaises(ValueError):
            model.reactant_surface_transfer_for_current_state_nm_s()

    def test_product_velocity_iteration_exhaustion_returns_finite_state(self) -> None:
        settings = NumericalSettings(
            nonlinear_relative_tolerance=1.0e-12,
            maximum_nonlinear_iterations=1,
            maximum_fractional_state_change=0.5,
            maximum_time_step_s=10.0,
        )
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                reactant_diffusivity_nm2_s=100.0,
                product_diffusivity_nm2_s=1.0,
                reactant_surface_transfer_nm_s=1.0,
                product_yield_concentration=100.0,
            ),
            rate_law=SaturatingRateLaw(
                maximum_velocity_nm_s=1.0,
                half_saturation=0.1,
                product_inhibition=100.0,
            ),
            numerical_settings=settings,
        )

        entry = model.step(0.1)

        self.assertFalse(entry.nonlinear_converged)
        self.assertEqual(entry.nonlinear_iterations, 1)
        self.assertGreater(
            entry.nonlinear_relative_change,
            settings.nonlinear_relative_tolerance,
        )
        self.assertTrue(np.all(np.isfinite(model.product_field)))
        self.assertTrue(np.all(np.isfinite(model._last_velocity)))
        self.assertTrue(np.isfinite(entry.maximum_velocity_nm_s))

    def test_passivation_relaxation_limits_explicit_time_step(self) -> None:
        def zero_rate(reactant, product, passivation, interface):
            return np.zeros_like(reactant)

        settings = NumericalSettings(
            maximum_fractional_state_change=0.1,
            maximum_time_step_s=10.0,
        )
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                product_bulk_concentration=1.0,
                product_yield_concentration=0.0,
            ),
            passivation=PassivationParameters(
                formation_per_concentration_s=10.0,
                removal_per_s=5.0,
            ),
            rate_law=zero_rate,
            numerical_settings=settings,
        )

        entry = model.step(1.0)

        expected_rate = 15.0
        expected_dt = settings.maximum_fractional_state_change / expected_rate
        self.assertEqual(entry.time_step_limiter, "passivation")
        self.assertIsNone(entry.front_stable_dt_s)
        self.assertAlmostEqual(
            entry.maximum_passivation_relaxation_rate_s, expected_rate
        )
        self.assertAlmostEqual(entry.passivation_stable_dt_s, expected_dt)
        self.assertAlmostEqual(entry.dt_s, expected_dt)
        self.assertLessEqual(
            np.max(model.passivation_field),
            settings.maximum_fractional_state_change,
        )

    def test_wet_precipitation_sink_forms_a_separate_persistent_phase(self) -> None:
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            transport=TransportParameters(
                reactant_diffusivity_nm2_s=100.0,
                product_diffusivity_nm2_s=1.0,
                reactant_surface_transfer_nm_s=1.0,
                product_yield_concentration=100.0,
            ),
            rate_law=SaturatingRateLaw(
                maximum_velocity_nm_s=1.0,
                half_saturation=0.1,
                product_inhibition=0.0,
            ),
            deposit_parameters=DepositParameters(
                saturation_concentration_mol_m3=0.1,
                attachment_velocity_nm_s=10.0,
                deposit_molar_density_mol_m3=10.0,
                precipitation_yield_mol_deposit_per_mol_product=0.5,
                maximum_active_set_iterations=20,
            ),
            numerical_settings=self.settings(),
        )

        entries = [model.step(0.2) for _ in range(14)]
        entry = entries[-1]

        self.assertTrue(entry.wet_precipitation_converged)
        self.assertGreater(entry.product_precipitation_capture_rate, 0.0)
        self.assertAlmostEqual(
            entry.wet_deposit_formation_rate,
            entry.product_precipitation_capture_rate,
        )
        self.assertGreater(entry.deposit_total_inventory_native, 0.0)
        self.assertLess(entry.product_inventory_balance_relative_error, 1.0e-3)
        initial_deposit = entry.deposit_total_inventory_native
        model.front.solid_fraction[model.grid.cavity_mask] = 0.0
        self.assertAlmostEqual(
            model.deposit_phase.diagnostics().total_inventory_native,
            initial_deposit,
        )
        dissolved = model.dissolve_persistent_deposit(
            10.0, wall_rate_s=0.1
        )
        self.assertGreater(dissolved.removed_inventory_native, 0.0)
        self.assertLess(dissolved.after_inventory_native, initial_deposit)

    def test_both_required_geometries_run_on_coarse_grid(self) -> None:
        for geometry in GEOMETRY_PRESETS.values():
            with self.subTest(geometry=geometry.name):
                model = GapFillEtch2D(
                    make_process(geometry),
                    spacing_nm=5.0,
                    reservoir_height_nm=5.0,
                    lateral_margin_nm=2.0,
                    numerical_settings=self.settings(),
                )
                result = model.run(0.5, time_step_s=0.5)
                self.assertGreater(np.count_nonzero(model.grid.cavity_mask), 0)
                self.assertEqual(result.snapshots[0].time_s, 0.0)
                self.assertAlmostEqual(result.history[-1].time_s, 0.5)

    def test_default_wetting_state_reproduces_legacy_liquid_inheritance(self) -> None:
        common = dict(
            process=make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            numerical_settings=self.settings(),
        )
        legacy = GapFillEtch2D(**common)
        explicit = GapFillEtch2D(
            **common,
            wetting_parameters=WettingParameters(enabled=True),
        )

        legacy_result = legacy.run(5.0, time_step_s=1.0)
        explicit_result = explicit.run(5.0, time_step_s=1.0)

        np.testing.assert_allclose(
            explicit.front.solid_fraction,
            legacy.front.solid_fraction,
            rtol=0.0,
            atol=0.0,
        )
        self.assertEqual(
            [entry.dt_s for entry in explicit_result.history],
            [entry.dt_s for entry in legacy_result.history],
        )
        self.assertIsNotNone(explicit_result.final_wetting_diagnostics)
        self.assertIsNone(legacy_result.final_wetting_diagnostics)

    def test_entrance_delay_creates_dry_open_cells_and_suppresses_removal(self) -> None:
        baseline = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            numerical_settings=self.settings(),
        )
        delayed = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            wetting_parameters=WettingParameters(
                enabled=True,
                new_void_filling_mode="capillary",
                entrance_delay_s=100.0,
                maximum_contact_line_speed_nm_s=1.0,
            ),
            numerical_settings=self.settings(),
        )

        baseline_result = baseline.run(10.0, time_step_s=1.0)
        delayed_result = delayed.run(10.0, time_step_s=1.0)

        self.assertGreater(delayed_result.history[-1].gas_cells_in_trench, 0)
        self.assertTrue(delayed_result.history[-1].wetting_delay_active)
        self.assertLess(
            delayed_result.final_diagnostics.dissolved_area_nm2,
            baseline_result.final_diagnostics.dissolved_area_nm2,
        )
        final = delayed_result.snapshots[-1]
        self.assertFalse(np.any(final.liquid_mask & final.gas_mask))
        np.testing.assert_array_equal(
            (final.liquid_mask | final.gas_mask) & delayed.grid.cavity_mask,
            final.open_void_mask & delayed.grid.cavity_mask,
        )

    def test_new_void_does_not_receive_the_preceding_step_as_wetting_age(self) -> None:
        delay_s = 100.0
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            wetting_parameters=WettingParameters(
                enabled=True,
                new_void_filling_mode="capillary",
                entrance_delay_s=delay_s,
            ),
            numerical_settings=self.settings(),
        )

        for _ in range(20):
            entry = model.step(1.0)
            if entry.newly_opened_cells:
                break
        else:
            self.fail("test setup did not open a cavity cell")

        self.assertEqual(model.wetting_state.time_since_first_open_s, 0.0)
        self.assertAlmostEqual(
            model.wetting_diagnostics.wetting_delay_remaining_s,
            delay_s,
        )

    def test_bottom_gas_pocket_is_visible_and_excluded_from_transport(self) -> None:
        model = GapFillEtch2D(
            make_process(),
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
            wetting_parameters=WettingParameters(
                enabled=True,
                bottom_gas_pocket_seed_height_nm=4.0,
                bottom_gas_activation_depth_fraction=0.0,
                gas_compression_mode="none",
            ),
            numerical_settings=self.settings(),
        )

        result = model.run(5.0, time_step_s=1.0)
        final = result.snapshots[-1]

        self.assertIsNotNone(result.final_wetting_diagnostics)
        self.assertTrue(
            result.final_wetting_diagnostics.bottom_gas_pocket_active
        )
        self.assertGreater(np.count_nonzero(final.bottom_gas_mask), 0)
        self.assertTrue(np.all(final.reactant[final.gas_mask] == 0.0))
        self.assertTrue(np.all(final.product[final.gas_mask] == 0.0))
        self.assertLess(
            result.history[-1].phase_partition_relative_error, 1.0e-12
        )

    def test_wetting_substep_removes_requested_dt_dependence(self) -> None:
        def run(requested_dt_s: float) -> tuple[float, int]:
            model = GapFillEtch2D(
                make_process(),
                spacing_nm=2.0,
                reservoir_height_nm=4.0,
                lateral_margin_nm=2.0,
                wetting_parameters=WettingParameters(
                    enabled=True,
                    new_void_filling_mode="capillary",
                ),
                numerical_settings=self.settings(),
            )
            result = model.run(5.0, time_step_s=requested_dt_s)
            wetting_limited = sum(
                entry.time_step_limiter == "wetting"
                for entry in result.history
            )
            return result.final_diagnostics.dissolved_area_nm2, wetting_limited

        coarse_area, coarse_limits = run(1.0)
        fine_area, fine_limits = run(0.2)

        self.assertAlmostEqual(coarse_area, fine_area, places=7)
        self.assertGreater(coarse_limits, 0)
        self.assertGreater(fine_limits, 0)


if __name__ == "__main__":
    unittest.main()

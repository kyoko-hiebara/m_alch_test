from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from fig2_process_screen import (
    Fig2ProcessScreenConfig,
    run_fig2_process_screen,
    save_fig2_process_screen_json,
)


class Fig2ProcessScreenTests(unittest.TestCase):
    def test_c22_five_nm_screen_propagates_cycle_and_sin_cost(self) -> None:
        payload = run_fig2_process_screen(
            Fig2ProcessScreenConfig(
                target_endpoint_ids=("kawarazaki_sicn_c22",),
                residual_thicknesses_nm=(5.0,),
            )
        )
        case = payload["cases"][0]
        row = case["comparisons"][0]
        self.assertEqual(case["material"], "SiCN")
        self.assertAlmostEqual(row["dhf_only_clear_time_min"], 83.333333333333)
        self.assertEqual(row["minimum_fixed_cycles"], 3)
        self.assertAlmostEqual(row["target_predicted_total_etch_nm"], 7.41)
        self.assertAlmostEqual(row["target_clearance_margin_nm"], 2.41)
        self.assertAlmostEqual(row["target_paired_dhf_baseline_nm"], 0.09)
        self.assertAlmostEqual(row["target_ozone_enabled_increment_nm"], 7.32)
        self.assertAlmostEqual(row["sin_reference_predicted_loss_nm"], 0.12)
        self.assertAlmostEqual(
            row["dhf_only_sin_reference_loss_nm"],
            6.666666666667,
        )
        self.assertEqual(
            row["fixed_cycle_raster_resolution_sensitivity"][
                "minimum_cycles"
            ],
            2,
        )
        self.assertEqual(
            row["fixed_cycle_raster_resolution_sensitivity"][
                "maximum_cycles"
            ],
            3,
        )
        self.assertIsNone(
            row["dhf_only_raster_resolution_sensitivity"][
                "latest_clear_time_min"
            ]
        )
        self.assertAlmostEqual(
            row["cleared_target_thickness_to_sin_loss_ratio"],
            41.666666666667,
        )
        self.assertTrue(
            row["target_cycle_count_within_fig4_observed_range"]
        )
        self.assertFalse(row["target_cycle_count_extrapolated"])
        self.assertFalse(
            row["target_fixed_30s_sequence_directly_supported"]
        )
        self.assertTrue(
            row["target_fixed_30s_cycle_scaling_is_assumption"]
        )
        self.assertFalse(
            row["sin_reference_cycle_count_supported_by_source"]
        )
        self.assertTrue(row["sin_reference_cycle_count_extrapolated"])
        self.assertFalse(
            row["joint_target_and_sin_cycle_count_supported_by_source"]
        )
        self.assertTrue(payload["quality"]["strictly_algebraic_closure"])

    def test_c40_five_nm_requires_extrapolation(self) -> None:
        payload = run_fig2_process_screen(
            Fig2ProcessScreenConfig(
                target_endpoint_ids=("kawarazaki_sicn_c40",),
                residual_thicknesses_nm=(5.0,),
            )
        )
        row = payload["cases"][0]["comparisons"][0]
        self.assertAlmostEqual(row["dhf_only_clear_time_min"], 19.230769230769)
        self.assertEqual(row["minimum_fixed_cycles"], 8)
        self.assertAlmostEqual(row["target_predicted_total_etch_nm"], 5.6)
        self.assertAlmostEqual(row["sin_reference_predicted_loss_nm"], 0.32)
        self.assertEqual(
            row["fixed_cycle_raster_resolution_sensitivity"][
                "minimum_cycles"
            ],
            7,
        )
        self.assertEqual(
            row["fixed_cycle_raster_resolution_sensitivity"][
                "maximum_cycles"
            ],
            8,
        )
        self.assertFalse(
            row["target_cycle_count_within_fig4_observed_range"]
        )
        self.assertTrue(row["target_cycle_count_extrapolated"])

    def test_validation_and_strict_json_round_trip(self) -> None:
        with self.assertRaisesRegex(ValueError, "unknown target"):
            Fig2ProcessScreenConfig(target_endpoint_ids=("unknown",))
        with self.assertRaisesRegex(ValueError, "finite and positive"):
            Fig2ProcessScreenConfig(residual_thicknesses_nm=(0.0,))
        with self.assertRaisesRegex(ValueError, "must identify SiN"):
            Fig2ProcessScreenConfig(
                target_endpoint_ids=("kawarazaki_sin_reference",),
                sin_reference_endpoint_id="kawarazaki_sicn_c22",
            )

        payload = run_fig2_process_screen()
        with tempfile.TemporaryDirectory() as directory:
            path = save_fig2_process_screen_json(
                payload,
                Path(directory) / "screen.json",
            )
            saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(
            saved["schema_version"],
            "kawarazaki-fig2-process-screen/v1",
        )
        self.assertEqual(len(saved["cases"]), 3)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from literature_parameters import get_literature_preset
from product_passivation_sweep import (
    CoupledLiteratureInterfaceLaw,
    ProductPassivationSweepConfig,
    characteristic_product_concentration_mol_m3,
    run_product_passivation_case,
    run_product_passivation_sweep,
)
from run_product_passivation_sweep import main


class ProductPassivationSweepTests(unittest.TestCase):
    def config(self, scenario: str = "null", **updates) -> ProductPassivationSweepConfig:
        values = {
            "geometries": ("10_8_180",),
            "presets": ("sin_barcellona_b_0p55wt",),
            "scenarios": (scenario,),
            "target_remaining_fractions": (0.50,),
            "sample_time_over_planar_clear": (0.60,),
            "grid_spacing_nm": 5.0,
            "reservoir_height_nm": 5.0,
        }
        values.update(updates)
        return ProductPassivationSweepConfig(**values)

    def test_characteristic_product_scale_and_coupled_modifier(self) -> None:
        preset = get_literature_preset("sin_barcellona_b_0p55wt")
        scale = characteristic_product_concentration_mol_m3(preset, 180.0)
        self.assertGreater(scale, 0.0)
        law = CoupledLiteratureInterfaceLaw(0.1, 10.0, product_c50_mol_m3=2.0)
        interface = np.asarray([[True, False]])
        product = np.asarray([[2.0, 0.0]])
        passivation = np.asarray([[0.2, 0.0]])
        modifier = law.reactivity_modifier(product, passivation, interface)
        self.assertAlmostEqual(modifier[0, 0], 0.4)
        self.assertEqual(modifier[0, 1], 1.0)
        velocity = law(np.asarray([[10.0, 10.0]]), product, passivation, interface)
        self.assertAlmostEqual(velocity[0, 0], 0.04)
        self.assertEqual(velocity[0, 1], 0.0)

    def test_product_and_passivation_paths_are_exercised(self) -> None:
        product = run_product_passivation_case(
            "10_8_180",
            "sin_barcellona_b_0p55wt",
            "product_transport",
            self.config("product_transport"),
        )
        passivating = run_product_passivation_case(
            "10_8_180",
            "sin_barcellona_b_0p55wt",
            "reversible_passivation",
            self.config("reversible_passivation"),
        )
        self.assertGreater(product["maximum_product_mol_m3"], 0.0)
        self.assertEqual(product["maximum_passivation"], 0.0)
        self.assertGreater(passivating["maximum_product_mol_m3"], 0.0)
        self.assertGreater(passivating["maximum_passivation"], 0.0)
        self.assertTrue(passivating["convergence"]["reactant"])
        self.assertTrue(passivating["convergence"]["product"])
        self.assertTrue(passivating["convergence"]["nonlinear"])
        self.assertLess(
            passivating["convergence"][
                "maximum_product_inventory_balance_relative_error"
            ],
            1.0e-3,
        )
        self.assertTrue(
            passivating["inventory_scope"][
                "explicit_product_flux_balance_diagnostic"
            ]
        )

    def test_absolute_time_checkpoint_is_saved_alongside_normalized_time(
        self,
    ) -> None:
        case = run_product_passivation_case(
            "10_8_180",
            "sin_barcellona_b_0p55wt",
            "null",
            self.config("null", sample_times_s=(30.0,)),
        )
        absolute = case["absolute_time_checkpoints"][0]
        self.assertEqual(absolute["kind"], "time_s")
        self.assertEqual(absolute["requested_value"], 30.0)
        self.assertTrue(absolute["reached"])
        self.assertEqual(
            case["time_checkpoints"][0]["kind"],
            "time_over_planar_clear",
        )

    def test_parallel_order_is_stable(self) -> None:
        config = self.config(
            scenarios=("null", "product_transport"),
            parallel_workers=2,
        )
        payload = run_product_passivation_sweep(config)
        self.assertEqual(
            [case["scenario"]["key"] for case in payload["cases"]],
            ["null", "product_transport"],
        )
        self.assertEqual(payload["parallel_execution"]["effective_workers"], 2)

    def test_cli_plain_json_and_independent_temperatures(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "product.json"
            payload = main(
                [
                    "--geometry", "7_4p5_170",
                    "--preset", "siocn_fujitsu_4b_100to1",
                    "--scenario", "null",
                    "--target-remaining", "0.5",
                    "--sample-clear-time", "0.6",
                    "--sample-time-s", "30",
                    "--grid-spacing-nm", "5",
                    "--reservoir-height-nm", "5",
                    "--solution-temperature-k", "295",
                    "--substrate-temperature-k", "320",
                    "--workers", "1",
                    "--output", str(output),
                ]
            )
            saved = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(saved, payload)
            temperatures = saved["cases"][0]["boundary_temperatures_K"]
            self.assertEqual(temperatures["solution_bulk"], 295.0)
            self.assertEqual(temperatures["substrate_backside"], 320.0)
            self.assertFalse(
                saved["calibrated_product_or_passivation_parameters"]
            )
            self.assertEqual(
                saved["cases"][0]["absolute_time_checkpoints"][0][
                    "requested_value"
                ],
                30.0,
            )


if __name__ == "__main__":
    unittest.main()

"""Capillary wetting, entrance meniscus, and optional trapped-gas state.

The fully GAP-FILLED etch model starts with no cavity void.  A cell removed by
liquid-contact dissolution therefore inherits liquid by default.  Slow
capillary filling and a bottom gas pocket are available only as explicit
failure-mode hypotheses (post-dissolution dewetting, gas generation, or a
top-connected dry seam supplied by another caller); they are never created by
the default configuration.

The continuum closure is deliberately small:

* a two-dimensional slit Young--Laplace pressure,
  ``2 * gamma * cos(theta) / width``;
* tapered parallel-plate Poiseuille resistance for the contact-line speed;
* an empirical entrance-pinning delay and optional speed cap;
* an optional bottom-pocket gas inventory with ideal compression and an
  empirical first-order dissolution time.

Lengths exposed by the public API use nanometres, while pressure, viscosity,
surface tension, and the hydraulic calculation use SI internally.  At trench
widths of 4.5--10 nm this is a screening model, not a molecularly quantitative
wetting prediction.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Literal

import numpy as np

from reaction_diffusion_2d import CartesianGrid2D, connected_to_top


NM_TO_M = 1.0e-9
NM2_TO_M2 = 1.0e-18
GAS_CONSTANT_J_MOL_K = 8.31446261815324

NewVoidFillingMode = Literal["liquid_inherited", "capillary"]
GasCompressionMode = Literal["ideal", "none"]


@dataclass(frozen=True)
class WettingParameters:
    """Parameters for the optional wetting/gas state.

    ``new_void_filling_mode='liquid_inherited'`` is the physically consistent
    default for dissolution of an initially full GAP FILL.  ``'capillary'``
    means that newly opened cells are initially dry and must be invaded; this
    represents dewetting, gas generation, or an externally supplied
    top-connected dry seam.  Isolated closed seams need a separate gas model.

    A non-zero ``bottom_gas_pocket_seed_height_nm`` explicitly nucleates a
    pocket once the deepest open void reaches
    ``bottom_gas_activation_depth_fraction`` of the trench depth.  It is an
    uncalibrated failure-mode hypothesis, not a consequence of contact angle.
    """

    enabled: bool = False
    advancing_contact_angle_deg: float = 60.0
    surface_tension_N_m: float = 0.07197
    dynamic_viscosity_Pa_s: float = 0.89e-3
    reservoir_overpressure_Pa: float = 0.0
    entrance_pinning_pressure_Pa: float = 0.0
    entrance_delay_s: float = 0.0
    hydraulic_mobility_scale: float = 1.0
    maximum_contact_line_speed_nm_s: float | None = None
    new_void_filling_mode: NewVoidFillingMode = "liquid_inherited"
    bottom_gas_pocket_seed_height_nm: float = 0.0
    bottom_gas_activation_depth_fraction: float = 0.90
    gas_dissolution_time_s: float = math.inf
    gas_residual_fraction: float = 0.0
    gas_compression_mode: GasCompressionMode = "ideal"
    ambient_pressure_Pa: float = 101_325.0
    gas_temperature_K: float = 298.15
    gas_compressibility_factor: float = 1.0
    high_pressure_warning_threshold_Pa: float = 5.0e6

    def __post_init__(self) -> None:
        if not isinstance(self.enabled, bool):
            raise TypeError("enabled must be boolean")
        finite = (
            "advancing_contact_angle_deg",
            "surface_tension_N_m",
            "dynamic_viscosity_Pa_s",
            "reservoir_overpressure_Pa",
            "entrance_pinning_pressure_Pa",
            "entrance_delay_s",
            "hydraulic_mobility_scale",
            "bottom_gas_pocket_seed_height_nm",
            "bottom_gas_activation_depth_fraction",
            "gas_residual_fraction",
            "ambient_pressure_Pa",
            "gas_temperature_K",
            "gas_compressibility_factor",
            "high_pressure_warning_threshold_Pa",
        )
        for name in finite:
            if not math.isfinite(float(getattr(self, name))):
                raise ValueError(f"{name} must be finite")
        if not 0.0 <= self.advancing_contact_angle_deg <= 180.0:
            raise ValueError("advancing_contact_angle_deg must lie in [0, 180]")
        for name in (
            "surface_tension_N_m",
            "dynamic_viscosity_Pa_s",
            "ambient_pressure_Pa",
            "gas_temperature_K",
            "gas_compressibility_factor",
            "high_pressure_warning_threshold_Pa",
        ):
            if float(getattr(self, name)) <= 0.0:
                raise ValueError(f"{name} must be positive")
        for name in (
            "entrance_pinning_pressure_Pa",
            "entrance_delay_s",
            "hydraulic_mobility_scale",
            "bottom_gas_pocket_seed_height_nm",
        ):
            if float(getattr(self, name)) < 0.0:
                raise ValueError(f"{name} must be non-negative")
        speed = self.maximum_contact_line_speed_nm_s
        if speed is not None and (
            not math.isfinite(float(speed)) or float(speed) <= 0.0
        ):
            raise ValueError(
                "maximum_contact_line_speed_nm_s must be finite and positive"
            )
        if self.new_void_filling_mode not in {
            "liquid_inherited",
            "capillary",
        }:
            raise ValueError(
                "new_void_filling_mode must be 'liquid_inherited' or 'capillary'"
            )
        if self.new_void_filling_mode == "liquid_inherited":
            ineffective = []
            if self.entrance_delay_s > 0.0:
                ineffective.append("entrance_delay_s")
            if self.entrance_pinning_pressure_Pa > 0.0:
                ineffective.append("entrance_pinning_pressure_Pa")
            if self.maximum_contact_line_speed_nm_s is not None:
                ineffective.append("maximum_contact_line_speed_nm_s")
            if not math.isclose(
                self.hydraulic_mobility_scale,
                1.0,
                rel_tol=0.0,
                abs_tol=0.0,
            ):
                ineffective.append("hydraulic_mobility_scale")
            if ineffective:
                names = ", ".join(ineffective)
                raise ValueError(
                    f"{names} require new_void_filling_mode='capillary'"
                )
        if not 0.0 <= self.bottom_gas_activation_depth_fraction <= 1.0:
            raise ValueError(
                "bottom_gas_activation_depth_fraction must lie in [0, 1]"
            )
        if not 0.0 <= self.gas_residual_fraction <= 1.0:
            raise ValueError("gas_residual_fraction must lie in [0, 1]")
        tau = float(self.gas_dissolution_time_s)
        if math.isnan(tau) or tau <= 0.0:
            raise ValueError("gas_dissolution_time_s must be positive")
        if self.gas_compression_mode not in {"ideal", "none"}:
            raise ValueError("gas_compression_mode must be 'ideal' or 'none'")

    @property
    def gas_nucleation_enabled(self) -> bool:
        return self.bottom_gas_pocket_seed_height_nm > 0.0

    @property
    def is_failure_mode_hypothesis(self) -> bool:
        return (
            self.new_void_filling_mode == "capillary"
            or self.gas_nucleation_enabled
            or self.entrance_delay_s > 0.0
            or self.entrance_pinning_pressure_Pa > 0.0
            or self.maximum_contact_line_speed_nm_s is not None
        )

    def to_dict(self) -> dict[str, object]:
        values = asdict(self)
        values["gas_dissolution_time_s"] = (
            None if math.isinf(self.gas_dissolution_time_s)
            else self.gas_dissolution_time_s
        )
        values["gas_nucleation_enabled"] = self.gas_nucleation_enabled
        values["is_failure_mode_hypothesis"] = (
            self.is_failure_mode_hypothesis
        )
        return values


@dataclass(frozen=True)
class WettingDiagnostics:
    time_s: float
    maximum_open_depth_nm: float
    contact_line_depth_nm: float
    meniscus_center_depth_nm: float
    capillary_pressure_Pa: float
    hydraulic_driving_pressure_Pa: float
    contact_line_speed_nm_s: float
    wetting_delay_active: bool
    wetting_delay_remaining_s: float
    open_void_area_nm2: float
    wetted_area_nm2: float
    gas_area_nm2: float
    wetted_fraction_of_open_void: float
    bottom_gas_pocket_active: bool
    target_bottom_gas_area_nm2: float
    represented_bottom_gas_area_nm2: float
    gas_area_quantization_error_nm2: float
    gas_subgrid_representation_warning: bool
    gas_pressure_Pa: float
    gas_inventory_mol_per_m_span: float
    high_pressure_model_warning: bool
    phase_partition_relative_error: float
    newly_opened_cells: int
    newly_wetted_cells: int
    newly_gas_cells: int


@dataclass(frozen=True)
class WettingUpdateResult:
    liquid_mask: np.ndarray
    gas_mask: np.ndarray
    bottom_gas_mask: np.ndarray
    meniscus_depth_profile_nm: np.ndarray
    diagnostics: WettingDiagnostics


def slit_capillary_pressure_Pa(
    width_nm: float,
    contact_angle_deg: float,
    surface_tension_N_m: float,
) -> float:
    """Return ``p_gas - p_liquid`` for a two-dimensional slit meniscus."""

    for name, value in (
        ("width_nm", width_nm),
        ("surface_tension_N_m", surface_tension_N_m),
    ):
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be finite and positive")
    if not math.isfinite(contact_angle_deg) or not 0.0 <= contact_angle_deg <= 180.0:
        raise ValueError("contact_angle_deg must lie in [0, 180]")
    theta = math.radians(contact_angle_deg)
    return 2.0 * surface_tension_N_m * math.cos(theta) / (
        width_nm * NM_TO_M
    )


def slit_lucas_washburn_time_s(
    depth_nm: float,
    width_nm: float,
    contact_angle_deg: float,
    surface_tension_N_m: float,
    dynamic_viscosity_Pa_s: float,
) -> float:
    """Constant-width, gas-free slit Lucas--Washburn time.

    The relation is ``h^2 = gamma*w*cos(theta)*t/(3*mu)``.  A non-wetting
    angle returns infinity in the absence of externally applied pressure.
    """

    for name, value in (
        ("depth_nm", depth_nm),
        ("width_nm", width_nm),
        ("surface_tension_N_m", surface_tension_N_m),
        ("dynamic_viscosity_Pa_s", dynamic_viscosity_Pa_s),
    ):
        if not math.isfinite(value) or value <= 0.0:
            raise ValueError(f"{name} must be finite and positive")
    if not math.isfinite(contact_angle_deg) or not 0.0 <= contact_angle_deg <= 180.0:
        raise ValueError("contact_angle_deg must lie in [0, 180]")
    cosine = math.cos(math.radians(contact_angle_deg))
    if cosine <= 0.0:
        return math.inf
    return (
        3.0
        * dynamic_viscosity_Pa_s
        * (depth_nm * NM_TO_M) ** 2
        / (surface_tension_N_m * width_nm * NM_TO_M * cosine)
    )


class WettingState2D:
    """Mutable wet/liquid/gas partition on a fixed tapered-trench grid."""

    def __init__(
        self,
        grid: CartesianGrid2D,
        parameters: WettingParameters,
    ) -> None:
        self.grid = grid
        self.parameters = parameters
        self.time_s = 0.0
        self.time_since_first_open_s = 0.0
        self._has_seen_open_void = False
        self.contact_line_depth_nm = 0.0
        self._last_contact_line_speed_nm_s = 0.0
        self._last_capillary_pressure_Pa = self._capillary_pressure(0.0)
        self._last_driving_pressure_Pa = 0.0
        self._gas_pocket_activation_time_s: float | None = None
        self._gas_equivalent_area_at_ambient_nm2 = 0.0
        self._gas_seed_area_nm2 = 0.0
        self._gas_pressure_Pa = parameters.ambient_pressure_Pa
        self._target_bottom_gas_area_nm2 = 0.0
        self.liquid_mask = grid.reservoir_mask.copy()
        self.gas_mask = np.zeros(grid.shape, dtype=bool)
        self.bottom_gas_mask = np.zeros(grid.shape, dtype=bool)
        self.meniscus_depth_profile_nm = np.zeros(
            len(grid.lateral_nm), dtype=float
        )
        self._previous_open_void_mask = grid.reservoir_mask.copy()
        self._last_diagnostics = self._diagnostics(
            self._previous_open_void_mask,
            newly_opened_cells=0,
            newly_wetted_cells=0,
            newly_gas_cells=0,
        )

    @property
    def diagnostics(self) -> WettingDiagnostics:
        return self._last_diagnostics

    def _width_nm(self, depth_nm: float) -> float:
        depth = float(np.clip(depth_nm, 0.0, self.grid.geometry.depth_nm))
        return float(self.grid.geometry.width_at_depth_nm(depth))

    def _capillary_pressure(self, depth_nm: float) -> float:
        return slit_capillary_pressure_Pa(
            self._width_nm(depth_nm),
            self.parameters.advancing_contact_angle_deg,
            self.parameters.surface_tension_N_m,
        )

    def _maximum_open_depth_nm(self, open_void_mask: np.ndarray) -> float:
        cavity_open = open_void_mask & self.grid.cavity_mask
        if not np.any(cavity_open):
            return 0.0
        return float(
            np.max(self.grid.depth_mesh_nm[cavity_open])
            + 0.5 * self.grid.dz_nm
        )

    def _maximum_cavity_depth_by_column_nm(self) -> np.ndarray:
        result = np.zeros(len(self.grid.lateral_nm), dtype=float)
        for column in range(len(result)):
            rows = np.flatnonzero(self.grid.cavity_mask[:, column])
            if rows.size:
                result[column] = min(
                    self.grid.geometry.depth_nm,
                    float(self.grid.depth_nm[rows[-1]] + 0.5 * self.grid.dz_nm),
                )
        return result

    def meniscus_profile_nm(self, contact_line_depth_nm: float) -> np.ndarray:
        """Circular-arc meniscus depth versus lateral coordinate.

        The contact line lies on the tapered wall at ``contact_line_depth_nm``.
        Columns outside the local contact chord are already bounded by a
        shallower wall and are therefore filled to their cavity depth.
        """

        depth = float(
            np.clip(contact_line_depth_nm, 0.0, self.grid.geometry.depth_nm)
        )
        width = self._width_nm(depth)
        half_width = 0.5 * width
        x = np.abs(self.grid.lateral_nm)
        max_depth = self._maximum_cavity_depth_by_column_nm()
        profile = np.minimum(depth, max_depth)
        theta = math.radians(self.parameters.advancing_contact_angle_deg)
        cosine = math.cos(theta)
        if abs(cosine) < 1.0e-12:
            return np.clip(profile, 0.0, self.grid.geometry.depth_nm)
        inside = x <= half_width + 1.0e-12
        radius = width / (2.0 * abs(cosine))
        root = np.sqrt(np.maximum(radius * radius - x[inside] ** 2, 0.0))
        arc = depth + math.copysign(1.0, cosine) * (
            root - radius * math.sin(theta)
        )
        profile[inside] = arc
        return np.clip(profile, 0.0, self.grid.geometry.depth_nm)

    def _capillary_wet_mask(
        self,
        open_void_mask: np.ndarray,
        contact_line_depth_nm: float,
    ) -> tuple[np.ndarray, np.ndarray]:
        profile = self.meniscus_profile_nm(contact_line_depth_nm)
        cavity_wet = (
            self.grid.cavity_mask
            & (self.grid.depth_mesh_nm <= profile[None, :] + 1.0e-12)
        )
        mask = connected_to_top(
            (self.grid.reservoir_mask | cavity_wet) & open_void_mask
        )
        return mask, profile

    def _tapered_hydraulic_resistance_per_span_m2(
        self, depth_nm: float
    ) -> float:
        """Return ``integral_0^h dz / w(z)^3`` in ``1/m^2``."""

        h = max(depth_nm, 0.5 * self.grid.dz_nm) * NM_TO_M
        h = min(h, self.grid.geometry.depth_nm * NM_TO_M)
        w0 = self.grid.geometry.top_width_nm * NM_TO_M
        wb = self.grid.geometry.bottom_width_nm * NM_TO_M
        total_h = self.grid.geometry.depth_nm * NM_TO_M
        slope = (w0 - wb) / total_h
        if abs(slope) < np.finfo(float).eps:
            return h / (w0**3)
        wh = max(w0 - slope * h, wb)
        return (1.0 / (2.0 * slope)) * (1.0 / wh**2 - 1.0 / w0**2)

    def _hydraulic_speed_nm_s(self, depth_nm: float) -> tuple[float, float, float]:
        parameters = self.parameters
        capillary = self._capillary_pressure(depth_nm)
        drive = (
            parameters.reservoir_overpressure_Pa
            + capillary
            - parameters.entrance_pinning_pressure_Pa
        )
        if drive <= 0.0 or parameters.hydraulic_mobility_scale == 0.0:
            return 0.0, capillary, drive
        width_m = self._width_nm(depth_nm) * NM_TO_M
        resistance = self._tapered_hydraulic_resistance_per_span_m2(depth_nm)
        speed_m_s = drive / (
            12.0
            * parameters.dynamic_viscosity_Pa_s
            * width_m
            * resistance
        )
        speed_nm_s = (
            speed_m_s / NM_TO_M * parameters.hydraulic_mobility_scale
        )
        if parameters.maximum_contact_line_speed_nm_s is not None:
            speed_nm_s = min(
                speed_nm_s,
                parameters.maximum_contact_line_speed_nm_s,
            )
        return max(0.0, float(speed_nm_s)), capillary, drive

    def hydraulic_contact_line_state(
        self, depth_nm: float
    ) -> tuple[float, float, float]:
        """Return speed, capillary pressure, and net driving pressure.

        This read-only helper exposes the same tapered-slit closure used by
        :meth:`update`, primarily so diagnostic sweeps can choose a time step
        from a maximum allowed contact-line displacement.
        """

        if not math.isfinite(depth_nm):
            raise ValueError("depth_nm must be finite")
        depth = float(np.clip(depth_nm, 0.0, self.grid.geometry.depth_nm))
        return self._hydraulic_speed_nm_s(depth)

    def _validated_open_void(self, open_void_mask: np.ndarray) -> np.ndarray:
        raw = np.asarray(open_void_mask, dtype=bool)
        if raw.shape != self.grid.shape:
            raise ValueError("open_void_mask must match the grid")
        if np.any(self.grid.reservoir_mask & ~raw):
            raise ValueError("the top reservoir must always be open")
        connected = connected_to_top(raw)
        if np.any(raw & ~connected):
            raise ValueError(
                "open_void_mask must be top-connected; isolated seams require "
                "a separate gas-transport model"
            )
        return raw

    def stable_time_step_s(
        self,
        open_void_mask: np.ndarray,
        *,
        maximum_contact_line_displacement_nm: float,
        maximum_fractional_gas_change: float,
    ) -> float:
        """Limit explicit wetting motion and empirical gas-inventory decay."""

        for name, value in (
            (
                "maximum_contact_line_displacement_nm",
                maximum_contact_line_displacement_nm,
            ),
            ("maximum_fractional_gas_change", maximum_fractional_gas_change),
        ):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if maximum_fractional_gas_change > 1.0:
            raise ValueError("maximum_fractional_gas_change cannot exceed one")
        open_void = self._validated_open_void(open_void_mask)
        candidates: list[float] = []
        if (
            self.parameters.new_void_filling_mode == "capillary"
            and np.any(open_void & self.grid.cavity_mask)
        ):
            delay_remaining = max(
                0.0,
                self.parameters.entrance_delay_s
                - self.time_since_first_open_s,
            )
            if delay_remaining > 0.0:
                candidates.append(delay_remaining)
            else:
                maximum_open_depth = self._maximum_open_depth_nm(open_void)
                if self.contact_line_depth_nm < maximum_open_depth:
                    speed, _, _ = self._hydraulic_speed_nm_s(
                        self.contact_line_depth_nm
                    )
                    if speed > 0.0:
                        candidates.append(
                            maximum_contact_line_displacement_nm / speed
                        )
        tau = self.parameters.gas_dissolution_time_s
        minimum_inventory = (
            self.parameters.gas_residual_fraction * self._gas_seed_area_nm2
        )
        if (
            self._gas_pocket_activation_time_s is not None
            and math.isfinite(tau)
            and self._gas_equivalent_area_at_ambient_nm2
            > minimum_inventory + np.finfo(float).eps
            and maximum_fractional_gas_change < 1.0
        ):
            candidates.append(
                -tau * math.log1p(-maximum_fractional_gas_change)
            )
        return min(candidates, default=math.inf)

    def _advance_contact_line(
        self,
        maximum_open_depth_nm: float,
        active_dt_s: float,
    ) -> None:
        if active_dt_s <= 0.0 or maximum_open_depth_nm <= 0.0:
            self._last_contact_line_speed_nm_s = 0.0
            self._last_capillary_pressure_Pa = self._capillary_pressure(
                self.contact_line_depth_nm
            )
            self._last_driving_pressure_Pa = (
                self.parameters.reservoir_overpressure_Pa
                + self._last_capillary_pressure_Pa
                - self.parameters.entrance_pinning_pressure_Pa
            )
            return
        speed, capillary, drive = self._hydraulic_speed_nm_s(
            self.contact_line_depth_nm
        )
        self._last_contact_line_speed_nm_s = speed
        self._last_capillary_pressure_Pa = capillary
        self._last_driving_pressure_Pa = drive
        self.contact_line_depth_nm = min(
            maximum_open_depth_nm,
            self.contact_line_depth_nm + speed * active_dt_s,
        )

    def _seed_gas_area_nm2(
        self,
        open_void_mask: np.ndarray,
        maximum_open_depth_nm: float,
    ) -> float:
        seed_height = self.parameters.bottom_gas_pocket_seed_height_nm
        lower_bound = max(0.0, maximum_open_depth_nm - seed_height)
        seed_mask = (
            open_void_mask
            & self.grid.cavity_mask
            & (self.grid.depth_mesh_nm >= lower_bound - 0.5 * self.grid.dz_nm)
        )
        return float(np.count_nonzero(seed_mask) * self.grid.cell_area_nm2)

    def _maybe_activate_bottom_gas(
        self,
        open_void_mask: np.ndarray,
        maximum_open_depth_nm: float,
    ) -> None:
        parameters = self.parameters
        if (
            self._gas_pocket_activation_time_s is not None
            or not parameters.gas_nucleation_enabled
        ):
            return
        threshold = (
            parameters.bottom_gas_activation_depth_fraction
            * self.grid.geometry.depth_nm
        )
        if maximum_open_depth_nm + 1.0e-12 < threshold:
            return
        seed_area = self._seed_gas_area_nm2(
            open_void_mask, maximum_open_depth_nm
        )
        if seed_area <= 0.0:
            return
        self._gas_pocket_activation_time_s = self.time_s
        self._gas_seed_area_nm2 = seed_area
        self._gas_equivalent_area_at_ambient_nm2 = seed_area

    def _update_gas_inventory(self, dt_s: float) -> None:
        if self._gas_pocket_activation_time_s is None:
            self._target_bottom_gas_area_nm2 = 0.0
            self._gas_pressure_Pa = self.parameters.ambient_pressure_Pa
            return
        parameters = self.parameters
        if math.isfinite(parameters.gas_dissolution_time_s):
            decay = math.exp(-dt_s / parameters.gas_dissolution_time_s)
            minimum = parameters.gas_residual_fraction * self._gas_seed_area_nm2
            self._gas_equivalent_area_at_ambient_nm2 = max(
                minimum,
                self._gas_equivalent_area_at_ambient_nm2 * decay,
            )
        drive_for_compression = max(0.0, self._last_driving_pressure_Pa)
        if parameters.gas_compression_mode == "ideal":
            self._gas_pressure_Pa = (
                parameters.ambient_pressure_Pa + drive_for_compression
            )
        else:
            self._gas_pressure_Pa = parameters.ambient_pressure_Pa
        self._target_bottom_gas_area_nm2 = (
            self._gas_equivalent_area_at_ambient_nm2
            * parameters.ambient_pressure_Pa
            / self._gas_pressure_Pa
        )

    def _bottom_pocket_mask_for_area(
        self,
        open_void_mask: np.ndarray,
        target_area_nm2: float,
    ) -> tuple[np.ndarray, float, np.ndarray]:
        open_cavity = open_void_mask & self.grid.cavity_mask
        if target_area_nm2 <= 0.0 or not np.any(open_cavity):
            profile = self.meniscus_profile_nm(self.contact_line_depth_nm)
            return np.zeros(self.grid.shape, dtype=bool), self.contact_line_depth_nm, profile
        maximum_open_depth = self._maximum_open_depth_nm(open_void_mask)
        low = 0.0
        high = maximum_open_depth
        best_mask = open_cavity.copy()
        best_profile = self.meniscus_profile_nm(0.0)
        # Gas area decreases monotonically as the contact line moves down.
        for _ in range(52):
            middle = 0.5 * (low + high)
            profile = self.meniscus_profile_nm(middle)
            gas = open_cavity & (
                self.grid.depth_mesh_nm > profile[None, :] + 1.0e-12
            )
            area = float(np.count_nonzero(gas) * self.grid.cell_area_nm2)
            best_mask = gas
            best_profile = profile
            if area > target_area_nm2:
                low = middle
            else:
                high = middle
        boundary_depth = high
        profile = self.meniscus_profile_nm(boundary_depth)
        gas = open_cavity & (
            self.grid.depth_mesh_nm > profile[None, :] + 1.0e-12
        )
        if (
            not np.any(gas)
            and target_area_nm2 >= 0.5 * self.grid.cell_area_nm2
        ):
            # The phase mask is boolean, so use nearest-cell rounding.  A
            # target below half a cell is represented as zero instead of
            # forcing a permanent one-cell blockage as gas dissolves.
            depths = np.where(open_cavity, self.grid.depth_mesh_nm, -math.inf)
            index = np.unravel_index(int(np.argmax(depths)), depths.shape)
            gas[index] = True
        return gas, boundary_depth, profile

    def _gas_inventory_mol_per_m_span(self) -> float:
        if self._target_bottom_gas_area_nm2 <= 0.0:
            return 0.0
        return (
            self._gas_pressure_Pa
            * self._target_bottom_gas_area_nm2
            * NM2_TO_M2
            / (
                self.parameters.gas_compressibility_factor
                * GAS_CONSTANT_J_MOL_K
                * self.parameters.gas_temperature_K
            )
        )

    def _diagnostics(
        self,
        open_void_mask: np.ndarray,
        *,
        newly_opened_cells: int,
        newly_wetted_cells: int,
        newly_gas_cells: int,
    ) -> WettingDiagnostics:
        open_cavity = open_void_mask & self.grid.cavity_mask
        wet_cavity = self.liquid_mask & self.grid.cavity_mask
        gas_cavity = self.gas_mask & self.grid.cavity_mask
        open_area = float(np.count_nonzero(open_cavity) * self.grid.cell_area_nm2)
        wet_area = float(np.count_nonzero(wet_cavity) * self.grid.cell_area_nm2)
        gas_area = float(np.count_nonzero(gas_cavity) * self.grid.cell_area_nm2)
        scale = max(open_area, wet_area + gas_area, self.grid.cell_area_nm2)
        partition_error = abs(open_area - wet_area - gas_area) / scale
        center = len(self.grid.lateral_nm) // 2
        center_depth = float(self.meniscus_depth_profile_nm[center])
        delay_remaining = max(
            0.0,
            self.parameters.entrance_delay_s - self.time_since_first_open_s,
        )
        represented_bottom_gas_area_nm2 = float(
            np.count_nonzero(self.bottom_gas_mask) * self.grid.cell_area_nm2
        )
        gas_area_quantization_error_nm2 = abs(
            represented_bottom_gas_area_nm2
            - self._target_bottom_gas_area_nm2
        )
        return WettingDiagnostics(
            time_s=self.time_s,
            maximum_open_depth_nm=self._maximum_open_depth_nm(open_void_mask),
            contact_line_depth_nm=float(self.contact_line_depth_nm),
            meniscus_center_depth_nm=center_depth,
            capillary_pressure_Pa=float(self._last_capillary_pressure_Pa),
            hydraulic_driving_pressure_Pa=float(
                self._last_driving_pressure_Pa
            ),
            contact_line_speed_nm_s=float(
                self._last_contact_line_speed_nm_s
            ),
            wetting_delay_active=(
                self._has_seen_open_void and delay_remaining > 0.0
            ),
            wetting_delay_remaining_s=delay_remaining,
            open_void_area_nm2=open_area,
            wetted_area_nm2=wet_area,
            gas_area_nm2=gas_area,
            wetted_fraction_of_open_void=(
                wet_area / open_area if open_area > 0.0 else 1.0
            ),
            bottom_gas_pocket_active=(
                self._gas_pocket_activation_time_s is not None
                and self._target_bottom_gas_area_nm2 > 0.0
            ),
            target_bottom_gas_area_nm2=float(
                self._target_bottom_gas_area_nm2
            ),
            represented_bottom_gas_area_nm2=(
                represented_bottom_gas_area_nm2
            ),
            gas_area_quantization_error_nm2=(
                gas_area_quantization_error_nm2
            ),
            gas_subgrid_representation_warning=(
                gas_area_quantization_error_nm2
                > 0.5 * self.grid.cell_area_nm2 + 1.0e-12
            ),
            gas_pressure_Pa=float(self._gas_pressure_Pa),
            gas_inventory_mol_per_m_span=self._gas_inventory_mol_per_m_span(),
            high_pressure_model_warning=(
                self._gas_pressure_Pa
                > self.parameters.high_pressure_warning_threshold_Pa
            ),
            phase_partition_relative_error=float(partition_error),
            newly_opened_cells=newly_opened_cells,
            newly_wetted_cells=newly_wetted_cells,
            newly_gas_cells=newly_gas_cells,
        )

    def update(
        self,
        open_void_mask: np.ndarray,
        dt_s: float,
    ) -> WettingUpdateResult:
        """Advance wetting and return a strict open/liquid/gas partition."""

        if not math.isfinite(dt_s) or dt_s < 0.0:
            raise ValueError("dt_s must be finite and non-negative")
        open_void = self._validated_open_void(open_void_mask)
        previous_liquid = self.liquid_mask.copy()
        previous_gas = self.gas_mask.copy()
        previous_open = self._previous_open_void_mask.copy()
        newly_open = open_void & ~previous_open
        newly_opened_cells = int(
            np.count_nonzero(newly_open & self.grid.cavity_mask)
        )

        open_cavity = open_void & self.grid.cavity_mask
        maximum_open_depth = self._maximum_open_depth_nm(open_void)
        before_open_clock = self.time_since_first_open_s
        if np.any(open_cavity):
            if not self._has_seen_open_void:
                self._has_seen_open_void = True
            self.time_since_first_open_s += dt_s
        self.time_s += dt_s
        after_open_clock = self.time_since_first_open_s
        active_before = max(
            0.0, before_open_clock - self.parameters.entrance_delay_s
        )
        active_after = max(
            0.0, after_open_clock - self.parameters.entrance_delay_s
        )
        active_dt = max(0.0, active_after - active_before)

        if self.parameters.new_void_filling_mode == "liquid_inherited":
            inherited = connected_to_top(open_void)
            self.contact_line_depth_nm = max(
                self.contact_line_depth_nm, maximum_open_depth
            )
            self._last_contact_line_speed_nm_s = 0.0
            self._last_capillary_pressure_Pa = self._capillary_pressure(
                self.contact_line_depth_nm
            )
            self._last_driving_pressure_Pa = (
                self.parameters.reservoir_overpressure_Pa
                + self._last_capillary_pressure_Pa
                - self.parameters.entrance_pinning_pressure_Pa
            )
            liquid_candidate = inherited
            self.meniscus_depth_profile_nm = self.meniscus_profile_nm(
                self.contact_line_depth_nm
            )
        else:
            self._advance_contact_line(maximum_open_depth, active_dt)
            if maximum_open_depth <= 0.0:
                # No cavity exists yet in a fully GAP-FILLED initial state, so
                # an entrance arc inside the still-solid film has no physical
                # meaning.  Keep the reservoir wet and report zero depth.
                liquid_candidate = self.grid.reservoir_mask.copy()
                self.meniscus_depth_profile_nm.fill(0.0)
            else:
                capillary_mask, profile = self._capillary_wet_mask(
                    open_void, self.contact_line_depth_nm
                )
                # Capillary invasion is monotonic until explicit pocket
                # nucleation.
                liquid_candidate = connected_to_top(
                    open_void & (previous_liquid | capillary_mask)
                )
                self.meniscus_depth_profile_nm = profile

        self._maybe_activate_bottom_gas(open_void, maximum_open_depth)
        self._update_gas_inventory(dt_s)
        bottom_gas, pocket_boundary, pocket_profile = (
            self._bottom_pocket_mask_for_area(
                open_void, self._target_bottom_gas_area_nm2
            )
        )
        if np.any(bottom_gas):
            liquid_candidate &= ~bottom_gas
            self.contact_line_depth_nm = min(
                self.contact_line_depth_nm, pocket_boundary
            )
            self.meniscus_depth_profile_nm = np.minimum(
                self.meniscus_depth_profile_nm, pocket_profile
            )
        self.bottom_gas_mask = bottom_gas
        self.liquid_mask = connected_to_top(
            liquid_candidate | self.grid.reservoir_mask
        )
        self.liquid_mask &= open_void
        self.gas_mask = open_void & self.grid.cavity_mask & ~self.liquid_mask

        if np.any(self.liquid_mask & self.gas_mask):
            raise RuntimeError("liquid and gas masks overlap")
        if np.any((self.liquid_mask | self.gas_mask) & ~open_void):
            raise RuntimeError("wetting phases escaped the open void")
        if np.any(self.grid.reservoir_mask & ~self.liquid_mask):
            raise RuntimeError("reservoir lost liquid connectivity")

        newly_wetted_cells = int(
            np.count_nonzero(
                self.liquid_mask
                & self.grid.cavity_mask
                & ~previous_liquid
            )
        )
        newly_gas_cells = int(
            np.count_nonzero(self.gas_mask & ~previous_gas)
        )
        self._previous_open_void_mask = open_void.copy()
        self._last_diagnostics = self._diagnostics(
            open_void,
            newly_opened_cells=newly_opened_cells,
            newly_wetted_cells=newly_wetted_cells,
            newly_gas_cells=newly_gas_cells,
        )
        return WettingUpdateResult(
            liquid_mask=self.liquid_mask.copy(),
            gas_mask=self.gas_mask.copy(),
            bottom_gas_mask=self.bottom_gas_mask.copy(),
            meniscus_depth_profile_nm=(
                self.meniscus_depth_profile_nm.copy()
            ),
            diagnostics=self._last_diagnostics,
        )


__all__ = [
    "GasCompressionMode",
    "NewVoidFillingMode",
    "WettingDiagnostics",
    "WettingParameters",
    "WettingState2D",
    "WettingUpdateResult",
    "slit_capillary_pressure_Pa",
    "slit_lucas_washburn_time_s",
]

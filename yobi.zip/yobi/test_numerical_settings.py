from __future__ import annotations

import dataclasses
import unittest

from numerical_settings import LOOSE_NUMERICS, NumericalSettings


class NumericalSettingsTests(unittest.TestCase):
    def test_defaults_are_intentionally_permissive(self) -> None:
        self.assertGreaterEqual(LOOSE_NUMERICS.linear_relative_tolerance, 1.0e-4)
        self.assertGreaterEqual(LOOSE_NUMERICS.nonlinear_relative_tolerance, 1.0e-3)
        self.assertGreaterEqual(LOOSE_NUMERICS.mass_balance_relative_tolerance, 1.0e-2)
        self.assertGreaterEqual(LOOSE_NUMERICS.maximum_fractional_state_change, 0.05)

    def test_invalid_limits_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            dataclasses.replace(LOOSE_NUMERICS, maximum_iterations=0)
        with self.assertRaises(ValueError):
            NumericalSettings(minimum_time_step_s=2.0, maximum_time_step_s=1.0)


if __name__ == "__main__":
    unittest.main()

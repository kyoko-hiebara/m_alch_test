"""Can the spacer pocket physically deliver the shielding sigma <= 0.3?

The spacer-pullback maximin screen showed that same-material and
carbon-on-carbon (residue, spacer) pairs are wet-feasible only behind a
geometric shielding factor sigma of 0.1--0.3.  That screen treated sigma
as a free knob.  This screen asks whether any physical mechanism in a
wet process can actually produce it at pocket dimensions, using the
repository's own transport machinery: the slit Thiele modulus of the
ozone penetration screen (``phi = d sqrt(2 k_s / (w D))``,
``sigma = sech(phi)``) with the Robin surface-transfer velocities the
literature presets already carry.

The answer is no, with orders of magnitude to spare, and the reason is
structural rather than numerical.  Steady-state diffusive shielding
requires the chemistry to consume reactant faster than diffusion can
refill a 1--5 nm x 2--20 nm pocket, and diffusion at that scale refills
in microseconds.  Inverting the same formula: a chemistry strong enough
to be shielded (sigma = 0.3) at the most shieldable corner of the sweep
would have to remove a blanket film at ~10^3--10^5 nm/min -- thousands
of times the fastest usable rate in the cohort.  **A wet chemistry slow
enough to control is too slow to shield; one fast enough to shield is
too fast to use.**  The two requirements exclude each other at fixed,
undisclosed-but-nanometric pocket dimensions, so the sweep locates
reality instead of proposing geometry changes (device dimensions are a
constraint, not a lever).

The only remaining candidate is exclusion -- the pocket simply not
filling with liquid.  That mechanism is a knife edge at contact angle
90 degrees: below it, capillary pressure at nm widths reaches tens of
MPa and floods the pocket to >95% against trapped ideal gas; only above
90 degrees does entry stop, and the commonly reported water contact
angles of H-terminated silicon (~70--90 degrees) sit below the
threshold.  Worse, the exclusion defends against the wrong step: the
oxidising reset re-hydroxylates the pocket walls, so the HF pulse that
follows every reset -- the step that removes the oxidised spacer
surface -- always sees a hydrophilic, flooded pocket.  The cyclic
recipe defeats its own only shielding mechanism, and trapped gas is
additionally transient against dissolution.

With sigma pinned at ~1, the maximin matrix collapses to its
fully-exposed column: the only (residue, spacer) cell feasible across
every swept condition is a fast carbon-rich residue against a SiN
spacer.  Combined with the field's own prior that the residue contains
carbon, the wet-cyclic decision reduces to one question: **does the
spacer film contain carbon?**

**Boundaries.**  Steady-state, straight dead-end slit, first-order wall
sink; the wall-sink topology overstates consumption (pocket walls are
silicon, near-inert in dHF) and therefore overstates shielding -- the
conclusion survives its own most favourable reading.  Robin velocities
inherit every provisional assumption of the Kawarazaki presets; the
cyclic-allocated velocity charges the whole per-cycle removal to the
30 s dHF pulse, again the shielding-maximising reading.  The capillary
model is the parallel-plate entry pressure against trapped ideal gas
with no dissolution, no dynamics, and no line pinning.  Contact angles
are literature ranges, not measurements of these walls.  Pocket
dimensions are swept covering bounds, not disclosed device values.
Nothing here is a process recipe.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from literature_parameters import (
    HF_DIFFUSIVITY_298_NM2_S,
    KAWARAZAKI_2024_FIG2_ENDPOINTS,
    get_literature_preset,
)
from ozone_penetration_screen import concentration_fraction_at_depth
from spacer_pullback_screen import maximin_verdict, pullback_feasibility


SCHEMA_VERSION = "spacer-pocket-shielding-screen/v1"
MODEL_NOTICE = (
    "Asks whether any wet mechanism can produce the shielding sigma <= "
    "0.3 that the spacer-pullback maximin requires. Steady-state slit "
    "transport with the repository's Robin velocities gives sigma ~ 1 "
    "with 4+ orders of margin; the inverted requirement corresponds to "
    "blanket rates of 10^3-10^5 nm/min, incompatible with a usable "
    "chemistry. Capillary exclusion is a knife edge at contact angle 90 "
    "deg that the oxidising reset itself defeats by re-hydroxylating "
    "the walls. Sigma is therefore pinned at ~1 and the maximin matrix "
    "collapses to its fully-exposed column. Not a process recipe."
)

WATER_SURFACE_TENSION_N_M = 0.07197
"""25 C water surface tension; matches the wetting_2d default."""

AMBIENT_PRESSURE_PA = 101325.0
"""Standard atmosphere; the trapped-gas reference pressure."""

DEFAULT_THROAT_WIDTHS_NM = (1.0, 2.0, 3.0, 5.0)
DEFAULT_POCKET_DEPTHS_NM = (2.0, 5.0, 10.0, 20.0)
DEFAULT_SIGMA_TARGETS = (0.3, 0.1)
DEFAULT_CONTACT_ANGLES_DEG = (0.0, 40.0, 70.0, 80.0, 85.0, 90.0, 95.0, 110.0)
DEFAULT_MARGIN_MULTIPLIER = 1000.0

# Fig. 2 endpoint keys mapped to the literature presets that carry their
# Robin surface-transfer velocities.
ENDPOINT_TO_PRESET = {
    "kawarazaki_sicn_c22": "kawarazaki_sicn_c22_dhf0p15_linear30s",
    "kawarazaki_sicn_c40": "kawarazaki_sicn_c40_dhf0p15_linear30s",
    "kawarazaki_siocn_c5": "kawarazaki_siocn_c5_dhf0p15_linear30s",
    "kawarazaki_sin_reference": (
        "kawarazaki_sin_reference_dhf0p15_linear30s"
    ),
}


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def surface_transfer_basis(endpoint_key: str) -> dict[str, float]:
    """dHF-only and cyclic-allocated Robin velocities for one film.

    The cyclic value scales the preset velocity by the ratio of the
    full per-cycle removal to the dHF-only bar, charging everything to
    the 30 s dHF pulse -- the shielding-maximising declared reading.
    """

    try:
        preset_key = ENDPOINT_TO_PRESET[endpoint_key]
    except KeyError as exc:
        choices = ", ".join(ENDPOINT_TO_PRESET)
        raise ValueError(
            f"unknown endpoint key {endpoint_key!r}; choose from {choices}"
        ) from exc
    endpoint = KAWARAZAKI_2024_FIG2_ENDPOINTS[endpoint_key]
    preset = get_literature_preset(preset_key)
    dhf_only = preset.first_order_surface_transfer_nm_s()
    cyclic_factor = (
        endpoint.ozone_then_dhf_etch_amount_nm
        / endpoint.dhf_only_etch_amount_nm
    )
    return {
        "preset_key": preset_key,
        "dhf_only_nm_s": dhf_only,
        "cyclic_allocation_factor": cyclic_factor,
        "cyclic_nm_s": dhf_only * cyclic_factor,
        "blanket_rate_nm_min": preset.planar_rate_nm_min,
        "cyclic_blanket_rate_nm_min": (
            preset.planar_rate_nm_min * cyclic_factor
        ),
    }


def transport_shielding(
    *,
    throat_width_nm: float,
    pocket_depth_nm: float,
    surface_transfer_nm_s: float,
) -> dict[str, float]:
    """Steady-state shielding for one pocket and one Robin velocity.

    ``sigma_wall_sink`` has both slit walls consuming (overstates
    consumption for silicon walls, hence overstates shielding);
    ``sigma_end_face`` has only the spacer face consuming.  The truth
    lies between the two, and both sit at ~1.
    """

    width = _finite_positive("throat_width_nm", throat_width_nm)
    depth = _finite_positive("pocket_depth_nm", pocket_depth_nm)
    velocity = _finite_positive(
        "surface_transfer_nm_s", surface_transfer_nm_s
    )
    phi = depth * math.sqrt(
        2.0 * velocity / (width * HF_DIFFUSIVITY_298_NM2_S)
    )
    damkohler = velocity * depth / HF_DIFFUSIVITY_298_NM2_S
    return {
        "throat_width_nm": width,
        "pocket_depth_nm": depth,
        "surface_transfer_nm_s": velocity,
        "thiele_modulus": phi,
        "sigma_wall_sink": concentration_fraction_at_depth(phi, 1.0),
        "damkohler_end_face": damkohler,
        "sigma_end_face": 1.0 / (1.0 + damkohler),
    }


def required_surface_transfer_nm_s(
    *,
    throat_width_nm: float,
    pocket_depth_nm: float,
    sigma_target: float,
) -> float:
    """Robin velocity a chemistry would need for the target shielding.

    Inverts the wall-sink form (the easier target of the two bounds):
    ``phi = arccosh(1 / sigma)``, ``k_s = phi^2 w D / (2 d^2)``.
    """

    width = _finite_positive("throat_width_nm", throat_width_nm)
    depth = _finite_positive("pocket_depth_nm", pocket_depth_nm)
    sigma = float(sigma_target)
    if not math.isfinite(sigma) or not 0.0 < sigma < 1.0:
        raise ValueError("sigma_target must be within (0, 1)")
    phi = math.acosh(1.0 / sigma)
    return (
        phi * phi * width * HF_DIFFUSIVITY_298_NM2_S / (2.0 * depth * depth)
    )


def capillary_entry(
    *,
    throat_width_nm: float,
    contact_angle_deg: float,
) -> dict[str, float]:
    """Parallel-plate entry pressure and trapped-gas dry residual.

    A dead-end pocket holds gas at ambient pressure; liquid enters
    until the compressed gas balances ambient plus capillary pressure,
    leaving ``P0 / (P0 + Pc)`` of the length dry.  At or above 90
    degrees there is no entry drive and the pocket stays dry -- the
    knife edge this screen reports, which the oxidising reset defeats
    by re-hydroxylating the walls.
    """

    width = _finite_positive("throat_width_nm", throat_width_nm)
    angle = float(contact_angle_deg)
    if not math.isfinite(angle) or not 0.0 <= angle <= 180.0:
        raise ValueError(
            "contact_angle_deg must be finite and within [0, 180]"
        )
    cosine = math.cos(math.radians(angle))
    # cos(90 deg) carries float dust (~6e-17); clamp so the knife edge
    # sits exactly at ninety degrees instead of on rounding noise.
    if abs(cosine) < 1.0e-12:
        cosine = 0.0
    entry_pressure = (
        2.0 * WATER_SURFACE_TENSION_N_M * cosine / (width * 1.0e-9)
    )
    if entry_pressure > 0.0:
        dry_residual = AMBIENT_PRESSURE_PA / (
            AMBIENT_PRESSURE_PA + entry_pressure
        )
        floods = True
    else:
        dry_residual = 1.0
        floods = False
    return {
        "throat_width_nm": width,
        "contact_angle_deg": angle,
        "entry_pressure_MPa": entry_pressure / 1.0e6,
        "liquid_enters": floods,
        "dry_residual_fraction": dry_residual,
    }


def fully_exposed_verdicts(
    *,
    residue_thicknesses_nm: Sequence[float] = (1.0, 2.0, 3.0),
    spacer_budgets_nm: Sequence[float] = (0.3, 0.5, 1.0),
    wet_reset_efficiencies: Sequence[float] = (0.3, 1.0),
) -> dict[str, Any]:
    """The maximin matrix re-evaluated at sigma = 1 (pocket floods).

    With shielding unavailable, only the fully-exposed column of the
    spacer-pullback screen remains; this lists the surviving pairs per
    condition and their intersection across all conditions.
    """

    conditions: list[dict[str, Any]] = []
    survivor_sets: list[set[tuple[str, str]]] = []
    for efficiency in wet_reset_efficiencies:
        for thickness in residue_thicknesses_nm:
            for budget in spacer_budgets_nm:
                rows = pullback_feasibility(
                    residue_thickness_nm=thickness,
                    spacer_budget_nm=budget,
                    shielding_factor=1.0,
                    wet_reset_efficiency=efficiency,
                )
                survivors = [
                    (row["residue"], row["spacer"])
                    for row in rows
                    if row["feasible"]
                ]
                survivor_sets.append(set(survivors))
                conditions.append(
                    {
                        "wet_reset_efficiency": float(efficiency),
                        "residue_thickness_nm": float(thickness),
                        "spacer_budget_nm": float(budget),
                        "surviving_pairs": [
                            {"residue": residue, "spacer": spacer}
                            for residue, spacer in survivors
                        ],
                        "verdict": maximin_verdict(rows),
                    }
                )
    intersection = set.intersection(*survivor_sets)
    return {
        "shielding_factor": 1.0,
        "conditions": conditions,
        "pairs_surviving_every_condition": [
            {"residue": residue, "spacer": spacer}
            for residue, spacer in sorted(intersection)
        ],
        "carbon_prior_note": (
            "with the field prior that the residue contains carbon, the "
            "SiN-residue row is excluded and the wet-cyclic decision "
            "reduces to whether the spacer film contains carbon: a SiN "
            "spacer survives broadly, carbon-bearing spacers survive "
            "only in loose corners"
        ),
    }


def build_report(
    *,
    throat_widths_nm: Sequence[float] = DEFAULT_THROAT_WIDTHS_NM,
    pocket_depths_nm: Sequence[float] = DEFAULT_POCKET_DEPTHS_NM,
    sigma_targets: Sequence[float] = DEFAULT_SIGMA_TARGETS,
    contact_angles_deg: Sequence[float] = DEFAULT_CONTACT_ANGLES_DEG,
    margin_multiplier: float = DEFAULT_MARGIN_MULTIPLIER,
) -> dict[str, Any]:
    """Transport, inversion, wetting knife edge, and the sigma=1 verdict."""

    _finite_positive("margin_multiplier", margin_multiplier)
    bases = {
        key: surface_transfer_basis(key) for key in ENDPOINT_TO_PRESET
    }
    strongest_key = max(
        bases, key=lambda key: bases[key]["cyclic_nm_s"]
    )
    strongest = bases[strongest_key]

    transport_rows: list[dict[str, Any]] = []
    minimum_sigma = 1.0
    for endpoint_key, basis in bases.items():
        for label, velocity in (
            ("dhf_only", basis["dhf_only_nm_s"]),
            ("cyclic_allocated", basis["cyclic_nm_s"]),
        ):
            for width in throat_widths_nm:
                for depth in pocket_depths_nm:
                    row = transport_shielding(
                        throat_width_nm=width,
                        pocket_depth_nm=depth,
                        surface_transfer_nm_s=velocity,
                    )
                    row["film"] = endpoint_key
                    row["basis"] = label
                    minimum_sigma = min(
                        minimum_sigma, row["sigma_wall_sink"]
                    )
                    transport_rows.append(row)

    most_shieldable = transport_shielding(
        throat_width_nm=min(throat_widths_nm),
        pocket_depth_nm=max(pocket_depths_nm),
        surface_transfer_nm_s=strongest["cyclic_nm_s"] * margin_multiplier,
    )

    inversion_rows: list[dict[str, Any]] = []
    for sigma in sigma_targets:
        for width in throat_widths_nm:
            for depth in pocket_depths_nm:
                required = required_surface_transfer_nm_s(
                    throat_width_nm=width,
                    pocket_depth_nm=depth,
                    sigma_target=sigma,
                )
                ratio = required / strongest["cyclic_nm_s"]
                inversion_rows.append(
                    {
                        "sigma_target": float(sigma),
                        "throat_width_nm": float(width),
                        "pocket_depth_nm": float(depth),
                        "required_surface_transfer_nm_s": required,
                        "ratio_over_strongest_cyclic": ratio,
                        "implied_blanket_rate_nm_min": (
                            strongest["cyclic_blanket_rate_nm_min"] * ratio
                        ),
                    }
                )
    easiest = min(
        inversion_rows, key=lambda row: row["ratio_over_strongest_cyclic"]
    )

    wetting_rows = [
        capillary_entry(
            throat_width_nm=width, contact_angle_deg=angle
        )
        for width in throat_widths_nm
        for angle in contact_angles_deg
    ]

    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "constants": {
            "hf_diffusivity_nm2_s": HF_DIFFUSIVITY_298_NM2_S,
            "water_surface_tension_N_m": WATER_SURFACE_TENSION_N_M,
            "ambient_pressure_Pa": AMBIENT_PRESSURE_PA,
            "provenance_note": (
                "diffusivity and Robin velocities from "
                "literature_parameters (Noulty-Leaist 25 C, Kawarazaki "
                "presets); surface tension matches the wetting_2d "
                "default; ambient pressure is the standard atmosphere"
            ),
        },
        "pocket_sweep_note": (
            "throat and depth are covering bounds for an undisclosed, "
            "fixed device geometry; the sweep locates reality, it does "
            "not propose geometry changes"
        ),
        "surface_transfer_basis": bases,
        "strongest_basis": {"film": strongest_key, **strongest},
        "transport_shielding": transport_rows,
        "shielding_floor": {
            "minimum_sigma_wall_sink": minimum_sigma,
            "note": (
                "the smallest shielding across every film, basis, and "
                "pocket dimension; 1 - sigma stays below ~1e-3"
            ),
            "margin_case": {
                "multiplier": float(margin_multiplier),
                **most_shieldable,
            },
        },
        "required_chemistry_inversion": {
            "rows": inversion_rows,
            "easiest_case": easiest,
            "incompatibility_note": (
                "even the easiest corner needs a Robin velocity "
                f"{easiest['ratio_over_strongest_cyclic']:.0f}x the "
                "strongest cyclic-allocated value, i.e. a blanket rate "
                f"of {easiest['implied_blanket_rate_nm_min']:.0f} "
                "nm/min; a chemistry slow enough to control cannot "
                "shield, one fast enough to shield cannot be used"
            ),
        },
        "capillary_exclusion": {
            "rows": wetting_rows,
            "knife_edge_note": (
                "exclusion requires contact angle >= 90 deg; commonly "
                "reported H-terminated silicon water contact angles "
                "(~70-90 deg, literature range, not a measurement of "
                "these walls) sit below the threshold, and below it "
                "nm-scale capillary pressure floods the pocket to >95% "
                "against trapped ideal gas"
            ),
            "reset_defeats_exclusion_note": (
                "the oxidising reset re-hydroxylates the pocket walls, "
                "so the HF pulse after every reset sees a hydrophilic "
                "flooded pocket; the cyclic recipe defeats its own "
                "only shielding mechanism, and trapped gas is "
                "additionally transient against dissolution"
            ),
        },
        "fully_exposed_verdicts": fully_exposed_verdicts(),
    }


__all__ = [
    "AMBIENT_PRESSURE_PA",
    "DEFAULT_CONTACT_ANGLES_DEG",
    "DEFAULT_MARGIN_MULTIPLIER",
    "DEFAULT_POCKET_DEPTHS_NM",
    "DEFAULT_SIGMA_TARGETS",
    "DEFAULT_THROAT_WIDTHS_NM",
    "ENDPOINT_TO_PRESET",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "WATER_SURFACE_TENSION_N_M",
    "build_report",
    "capillary_entry",
    "fully_exposed_verdicts",
    "required_surface_transfer_nm_s",
    "surface_transfer_basis",
    "transport_shielding",
]

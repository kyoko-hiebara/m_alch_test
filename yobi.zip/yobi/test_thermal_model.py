from __future__ import annotations

import math
import unittest

from etch_process import ThermalBoundaryConditions
from thermal_model import (
    ThermalResistanceModel,
    ThermalResistanceParameters,
    inverse_width_integral,
)
from trench_geometry import TaperedTrench2D, get_geometry_preset


class ThermalResistanceModelTests(unittest.TestCase):
    @staticmethod
    def make_constant_width_model() -> ThermalResistanceModel:
        geometry = TaperedTrench2D(
            name="constant",
            top_width_nm=10.0,
            bottom_width_nm=10.0,
            depth_nm=100.0,
        )
        return ThermalResistanceModel(
            geometry,
            ThermalResistanceParameters(
                liquid_thermal_conductivity_W_mK=2.0,
                fill_thermal_conductivity_W_mK=4.0,
                substrate_thermal_conductivity_W_mK=10.0,
                substrate_thickness_m=20.0e-9,
                solution_boundary_resistance_m2K_W=1.0e-8,
                fill_substrate_contact_resistance_m2K_W=2.0e-8,
                backside_contact_resistance_m2K_W=3.0e-8,
                effective_substrate_width_m=10.0e-9,
            ),
        )

    def test_exact_resistance_breakdown_and_weighted_temperature(self) -> None:
        model = self.make_constant_width_model()
        depth = 40.0e-9
        resistance = model.resistances(depth)
        self.assertAlmostEqual(resistance.solution_boundary_K_m_W, 1.0)
        self.assertAlmostEqual(resistance.liquid_conduction_K_m_W, 2.0)
        self.assertAlmostEqual(resistance.fill_conduction_K_m_W, 1.5)
        self.assertAlmostEqual(resistance.fill_substrate_contact_K_m_W, 2.0)
        self.assertAlmostEqual(resistance.substrate_conduction_K_m_W, 0.2)
        self.assertAlmostEqual(resistance.backside_contact_K_m_W, 3.0)
        self.assertAlmostEqual(resistance.liquid_total_K_m_W, 3.0)
        self.assertAlmostEqual(resistance.solid_total_K_m_W, 6.7)

        boundary = ThermalBoundaryConditions(
            solution_bulk_temperature_K=300.0,
            substrate_backside_temperature_K=330.0,
        )
        state = model.evaluate(depth, boundary)
        expected = (300.0 / 3.0 + 330.0 / 6.7) / (1.0 / 3.0 + 1.0 / 6.7)
        self.assertAlmostEqual(state.interface_temperature_K, expected)
        self.assertGreater(state.interface_temperature_K, 300.0)
        self.assertLess(state.interface_temperature_K, 330.0)
        self.assertAlmostEqual(state.energy_balance_residual_W_m, 0.0, places=12)

    def test_reaction_heat_raises_temperature_and_closes_energy_balance(self) -> None:
        model = self.make_constant_width_model()
        boundary = ThermalBoundaryConditions(300.0, 330.0)
        depth = 40.0e-9
        cold = model.evaluate(depth, boundary)
        hot = model.evaluate(
            depth,
            boundary,
            reaction_heat_flux_W_m2=1.0e8,
        )
        total_conductance = 1.0 / 3.0 + 1.0 / 6.7
        heat_per_span = 1.0e8 * 10.0e-9
        self.assertAlmostEqual(
            hot.interface_temperature_K - cold.interface_temperature_K,
            heat_per_span / total_conductance,
        )
        self.assertAlmostEqual(hot.reaction_heat_rate_W_m, heat_per_span)
        self.assertAlmostEqual(hot.energy_balance_residual_W_m, 0.0, places=12)

    def test_taper_resistances_move_between_branches_with_front_depth(self) -> None:
        geometry = get_geometry_preset("10_8_180")
        model = ThermalResistanceModel(
            geometry,
            ThermalResistanceParameters(
                substrate_thickness_m=0.0,
                backside_contact_resistance_m2K_W=1.0e-8,
            ),
        )
        top = model.resistances(0.0)
        middle = model.resistances(90.0e-9)
        bottom = model.resistances(180.0e-9)
        self.assertEqual(top.liquid_conduction_K_m_W, 0.0)
        self.assertEqual(bottom.fill_conduction_K_m_W, 0.0)
        self.assertLess(top.liquid_conduction_K_m_W, middle.liquid_conduction_K_m_W)
        self.assertLess(middle.liquid_conduction_K_m_W, bottom.liquid_conduction_K_m_W)
        self.assertGreater(top.fill_conduction_K_m_W, middle.fill_conduction_K_m_W)
        self.assertGreater(middle.fill_conduction_K_m_W, bottom.fill_conduction_K_m_W)
        expected_shape = math.log(10.0 / 8.0) / (10.0 - 8.0) * 180.0
        self.assertAlmostEqual(
            inverse_width_integral(geometry, 0.0, 180.0e-9),
            expected_shape,
        )

    def test_equal_external_temperatures_give_same_interface_temperature(self) -> None:
        model = self.make_constant_width_model()
        boundary = ThermalBoundaryConditions(315.0, 315.0)
        for depth in (0.0, 25.0e-9, 100.0e-9):
            self.assertAlmostEqual(
                model.interface_temperature_K(depth, boundary),
                315.0,
            )

    def test_invalid_inputs_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            ThermalResistanceParameters(liquid_thermal_conductivity_W_mK=0.0)
        with self.assertRaises(ValueError):
            ThermalResistanceParameters(backside_contact_resistance_m2K_W=-1.0)
        with self.assertRaises(ValueError):
            ThermalResistanceParameters(effective_substrate_width_m=math.nan)
        model = self.make_constant_width_model()
        boundary = ThermalBoundaryConditions(300.0, 310.0)
        with self.assertRaises(ValueError):
            model.evaluate(-1.0e-9, boundary)
        with self.assertRaises(ValueError):
            model.evaluate(101.0e-9, boundary)
        with self.assertRaises(ValueError):
            model.evaluate(50.0e-9, boundary, reaction_heat_flux_W_m2=math.inf)


if __name__ == "__main__":
    unittest.main()

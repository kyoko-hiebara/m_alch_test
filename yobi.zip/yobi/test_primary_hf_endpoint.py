from __future__ import annotations

import csv
import json
import math
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

import primary_hf_endpoint as endpoint_module
from literature_parameters import get_literature_preset
from primary_hf_endpoint import (
    BlanketRateInput,
    PrimaryHFEndpointConfig,
    endpoint_from_removal_events,
    literature_blanket_input,
    load_blanket_rate_csv,
    run_blanket_coupon,
    run_calibrated_primary_hf_to_endpoint,
    run_primary_hf_endpoint_calibration,
    save_primary_hf_endpoint_csv,
    save_primary_hf_endpoint_json,
)
from primary_hf_endpoint import _scenario_kinetics
from run_primary_hf_endpoint import config_for_mode, quality_exit_code
from trench_graph_kmc import TrenchKMCParameters


SIN_PRESET = "sin_barcellona_b_0p55wt"
SICN_C22_PRESET = "kawarazaki_sicn_c22_dhf0p15_linear30s"
COARSE_KINETICS = TrenchKMCParameters()


def coarse_config(**updates: object) -> PrimaryHFEndpointConfig:
    values: dict[str, object] = {
        "geometries": ("10_10_180",),
        "presets": (SIN_PRESET,),
        "scenarios": ("transport_only",),
        "replicate_seeds": (17,),
        "target_remaining_fractions": (0.5, 0.1, 0.0),
        "fixed_probe_times_s": (300.0,),
        "grid_spacing_nm": 20.0,
        "reservoir_height_nm": 20.0,
        "lateral_margin_nm": 0.0,
        "maximum_planar_clear_time_multiplier": 1.5,
        "primary_sync_steps": 4,
        "maximum_events": 5_000,
        "parallel_workers": 1,
        "coupon_width_nm": 40.0,
        "coupon_depth_nm": 60.0,
        "coupon_maximum_events": 5_000,
        "trace_points": 20,
    }
    values.update(updates)
    return PrimaryHFEndpointConfig(**values)


def assert_finite_tree(testcase: unittest.TestCase, value: object) -> None:
    if isinstance(value, float):
        testcase.assertTrue(math.isfinite(value))
    elif isinstance(value, dict):
        for item in value.values():
            assert_finite_tree(testcase, item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            assert_finite_tree(testcase, item)


class EndpointSelectorTests(unittest.TestCase):
    def test_discrete_crossing_keeps_previous_and_achieved_fractions(self) -> None:
        events = [{"time_s": float(index)} for index in range(1, 9)]
        endpoint = endpoint_from_removal_events(
            events,
            matrix_site_count=10,
            target_remaining_fraction=0.45,
            physical_seconds_per_model_second=4.0,
        )
        self.assertTrue(endpoint["reached"])
        self.assertEqual(endpoint["endpoint_model_time_s"], 6.0)
        self.assertEqual(endpoint["endpoint_physical_time_s"], 24.0)
        self.assertGreater(endpoint["previous_remaining_fraction"], 0.45)
        self.assertLessEqual(endpoint["achieved_remaining_fraction"], 0.45)
        self.assertEqual(endpoint["discrete_fraction_resolution"], 0.1)

    def test_unreached_target_is_explicit_and_has_null_time(self) -> None:
        endpoint = endpoint_from_removal_events(
            [{"time_s": 1.0}],
            matrix_site_count=10,
            target_remaining_fraction=0.1,
            physical_seconds_per_model_second=2.0,
        )
        self.assertFalse(endpoint["reached"])
        self.assertIsNone(endpoint["endpoint_model_time_s"])
        self.assertIsNone(endpoint["endpoint_physical_time_s"])
        self.assertEqual(endpoint["achieved_remaining_fraction"], 0.9)

    def test_integer_site_threshold_avoids_float_delayed_crossing(self) -> None:
        events = [{"time_s": float(index)} for index in range(1, 476)]
        endpoint = endpoint_from_removal_events(
            events,
            matrix_site_count=500,
            target_remaining_fraction=0.05,
            physical_seconds_per_model_second=1.0,
        )
        self.assertTrue(endpoint["reached"])
        self.assertEqual(endpoint["removed_count_at_endpoint"], 475)
        self.assertEqual(endpoint["required_removed_count"], 475)
        self.assertEqual(endpoint["achieved_remaining_fraction"], 0.05)


class EndpointConfigTests(unittest.TestCase):
    def test_validation_rejects_bad_target_and_duplicate_seed(self) -> None:
        with self.assertRaisesRegex(ValueError, "target_remaining_fraction"):
            coarse_config(target_remaining_fractions=(1.0,))
        with self.assertRaisesRegex(ValueError, "duplicates"):
            coarse_config(replicate_seeds=(1, 1))
        with self.assertRaisesRegex(ValueError, "geometries.*duplicates"):
            coarse_config(geometries=("10_10_180", "10_10_180"))
        with self.assertRaisesRegex(ValueError, "presets.*duplicates"):
            coarse_config(presets=(SIN_PRESET, SIN_PRESET))

    def test_synchronization_steps_hold_resolution_as_the_budget_grows(
        self,
    ) -> None:
        narrow = coarse_config(
            maximum_planar_clear_time_multiplier=3.0,
            primary_sync_steps=60,
        )
        wide = coarse_config(
            maximum_planar_clear_time_multiplier=200.0,
            primary_sync_steps=60,
        )

        # The legacy pairing of a 3x budget with 60 steps is reproduced, and a
        # wider budget buys more steps instead of a coarser macro step.
        self.assertEqual(narrow.synchronization_steps(), 60)
        self.assertEqual(wide.synchronization_steps(), 4000)
        self.assertEqual(
            wide.synchronization_steps()
            / wide.maximum_planar_clear_time_multiplier,
            narrow.synchronization_steps()
            / narrow.maximum_planar_clear_time_multiplier,
        )

    def test_default_budget_is_wide_enough_for_a_decelerating_trench(
        self,
    ) -> None:
        # A passivated trench keeps etching for tens of planar clear times; a
        # 3x budget censored every passivation replicate.
        self.assertGreaterEqual(
            PrimaryHFEndpointConfig().maximum_planar_clear_time_multiplier,
            100.0,
        )

    def test_passivation_strength_scale_moves_only_the_generation_rate(
        self,
    ) -> None:
        base = _scenario_kinetics(
            COARSE_KINETICS,
            "passivation_hypothesis",
        )
        stronger = _scenario_kinetics(
            COARSE_KINETICS,
            "passivation_hypothesis",
            passivation_strength_scale=4.0,
        )

        self.assertAlmostEqual(
            stronger.passivation_rate_s,
            4.0 * base.passivation_rate_s,
        )
        self.assertAlmostEqual(
            stronger.depassivation_rate_s,
            base.depassivation_rate_s,
        )
        with self.assertRaisesRegex(ValueError, "passivation_strength_scale"):
            _scenario_kinetics(
                COARSE_KINETICS,
                "passivation_hypothesis",
                passivation_strength_scale=0.0,
            )

    def test_transport_only_ignores_the_passivation_strength_scale(
        self,
    ) -> None:
        base = _scenario_kinetics(COARSE_KINETICS, "transport_only")
        scaled = _scenario_kinetics(
            COARSE_KINETICS,
            "transport_only",
            passivation_strength_scale=4.0,
        )

        self.assertEqual(base, scaled)

    def test_modes_keep_solution_and_substrate_temperatures_independent(self) -> None:
        quick = config_for_mode(
            "quick",
            1,
            liquid_temperature_K=290.0,
            substrate_temperature_K=330.0,
        )
        self.assertEqual(quick.solution_temperature_K, 290.0)
        self.assertEqual(quick.substrate_temperature_K, 330.0)
        self.assertEqual(quick.geometries, ("10_10_180", "7_7_170"))

    def test_blanket_csv_retains_unknown_uncertainty_as_none(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "blanket.csv"
            path.write_text(
                "preset_id,rate_nm_min,uncertainty_nm_min,"
                "measurement_temperature_K,source_note\n"
                f"{SIN_PRESET},2.5,,310.0,same-lot blanket\n",
                encoding="utf-8",
            )
            values = load_blanket_rate_csv(path)
        self.assertEqual(values[SIN_PRESET].rate_nm_min, 2.5)
        self.assertIsNone(values[SIN_PRESET].uncertainty_nm_min)
        self.assertEqual(values[SIN_PRESET].source_kind, "experimental_blanket")
        self.assertEqual(values[SIN_PRESET].measurement_temperature_K, 310.0)

    def test_digitized_single_endpoint_remains_a_literature_prior(self) -> None:
        anchor = literature_blanket_input(SICN_C22_PRESET)
        preset = get_literature_preset(SICN_C22_PRESET)
        self.assertEqual(anchor.source_kind, "literature_prior")
        self.assertEqual(anchor.rate_nm_min, 0.06)
        self.assertIsNone(anchor.measurement_temperature_K)
        self.assertEqual(preset.material, "SiCN")
        self.assertEqual(preset.transport_hf_weight_percent, 0.15)
        self.assertIn("30 s", preset.rate_evidence)
        self.assertIn("provisional linearity", preset.extrapolation_caveat)

    def test_experimental_blanket_requires_measurement_temperature(self) -> None:
        with self.assertRaisesRegex(ValueError, "measurement_temperature_K"):
            BlanketRateInput(
                preset_id=SIN_PRESET,
                rate_nm_min=2.5,
                uncertainty_nm_min=None,
                source_kind="experimental_blanket",
                source_note="same lot",
            )

    def test_coupon_zero_percent_start_is_time_zero(self) -> None:
        coupon = run_blanket_coupon(
            get_literature_preset(SIN_PRESET),
            TrenchKMCParameters(
                activation_rate_s=1.0e4,
                removal_rate_s=1.0e4,
            ),
            seed=11,
            spacing_nm=2.0,
            width_nm=4.0,
            depth_nm=4.0,
            start_removed_fraction=0.0,
            end_removed_fraction=0.5,
            maximum_events=100,
        )
        self.assertEqual(coupon["measurement_start_model_time_s"], 0.0)
        self.assertEqual(
            coupon["measurement_achieved_start_removed_fraction"], 0.0
        )


class EndpointRealRunTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = run_primary_hf_endpoint_calibration(coarse_config())

    def test_coupon_and_trench_runs_close_without_hidden_failures(self) -> None:
        quality = self.payload["quality_summary"]
        self.assertEqual(quality["successful_coupon_runs"], 1)
        self.assertEqual(quality["failed_coupon_runs"], 0)
        self.assertEqual(quality["successful_trench_runs"], 1)
        self.assertEqual(quality["failed_trench_runs"], 0)
        case = self.payload["cases"][0]
        self.assertTrue(case["convergence"]["all_hf_synchronizations"])
        self.assertTrue(case["convergence"]["all_product_synchronizations"])
        self.assertGreater(
            case["clock_calibration"]["physical_seconds_per_model_second"], 0.0
        )

    def test_endpoint_crossings_and_fixed_time_use_physical_clock(self) -> None:
        case = self.payload["cases"][0]
        endpoints = case["endpoints"]
        reached_times = [
            endpoint["endpoint_physical_time_s"]
            for endpoint in endpoints
            if endpoint["reached"]
        ]
        self.assertEqual(reached_times, sorted(reached_times))
        for endpoint in endpoints:
            if not endpoint["reached"]:
                continue
            self.assertGreater(
                endpoint["previous_remaining_fraction"],
                endpoint["target_remaining_fraction"],
            )
            self.assertLessEqual(
                endpoint["achieved_remaining_fraction"],
                endpoint["target_remaining_fraction"],
            )
            self.assertIn("bottom", endpoint["region_metrics_at_endpoint"])
            self.assertIn("sidewall", endpoint["region_metrics_at_endpoint"])
            region_removed = sum(
                item["removed_count"]
                for item in endpoint["region_metrics_at_endpoint"].values()
            )
            self.assertEqual(
                region_removed, endpoint["removed_count_at_endpoint"]
            )
        fixed = case["fixed_time_probes"][0]
        self.assertEqual(fixed["requested_physical_time_s"], 300.0)
        self.assertGreater(fixed["remaining_fraction"], 0.0)
        self.assertEqual(
            set(case["regional_clear_endpoints"]), {"sidewall", "bottom"}
        )

    def test_literature_prior_and_component_boundary_are_explicit(self) -> None:
        self.assertEqual(
            self.payload["calibration_status"]["level"], "literature_prior"
        )
        self.assertFalse(
            self.payload["calibration_status"]["trench_cross_section_fitted"]
        )
        anchor = self.payload["blanket_inputs"][SIN_PRESET]
        self.assertEqual(anchor["rate_nm_min"], 2.2)
        self.assertEqual(anchor["uncertainty_nm_min"], 0.2)
        self.assertIn("No Si/liner loss", self.payload["model_limitations"]["recipe_boundary"])

    def test_blanket_rate_uncertainty_is_propagated_as_clock_only(self) -> None:
        endpoint = next(
            item for item in self.payload["cases"][0]["endpoints"]
            if item["reached"]
        )
        interval = endpoint["blanket_rate_uncertainty_interval"]
        self.assertLess(
            interval["lower_physical_time_s"],
            endpoint["endpoint_physical_time_s"],
        )
        self.assertGreater(
            interval["upper_physical_time_s"],
            endpoint["endpoint_physical_time_s"],
        )
        self.assertFalse(interval["relative_trajectory_rerun"])
        aggregate = self.payload["aggregates"][0]["endpoint_summaries"][0]
        self.assertEqual(
            aggregate["blanket_rate_uncertainty_time_s"]["count"], 1
        )

    def test_live_handoff_stops_at_exact_observed_endpoint(self) -> None:
        config = coarse_config(target_remaining_fractions=(0.5,))
        handoff = run_calibrated_primary_hf_to_endpoint(
            geometry_id="10_10_180",
            preset_id=SIN_PRESET,
            scenario="transport_only",
            replicate_index=0,
            seed=17,
            config=config,
            coupon=self.payload["coupon_calibrations"][0],
            target_remaining_fraction=0.5,
        )
        self.assertEqual(
            handoff.outcome.stop_reason, "remaining_fraction_target"
        )
        self.assertEqual(handoff.validity["level"], "valid")
        self.assertTrue(handoff.validity["downstream_eligible"])
        self.assertEqual(
            handoff.endpoint["observation_status"], "observed"
        )
        self.assertLessEqual(
            handoff.outcome.summary()["remaining_fraction"], 0.5
        )
        self.assertGreater(
            handoff.product_inventory[
                "cumulative_generated_si_equivalent_inventory_native"
            ],
            0.0,
        )
        self.assertFalse(
            handoff.product_inventory[
                "instantaneous_endpoint_field_is_cumulative_mass_balance"
            ]
        )
        json.dumps(handoff.serializable_summary(), allow_nan=False)

    def test_live_handoff_rejects_mismatched_coupon(self) -> None:
        coupon = {
            **self.payload["coupon_calibrations"][0],
            "preset_id": "deliberately_wrong_coupon",
        }
        with self.assertRaisesRegex(ValueError, "coupon preset_id"):
            run_calibrated_primary_hf_to_endpoint(
                geometry_id="10_10_180",
                preset_id=SIN_PRESET,
                scenario="transport_only",
                replicate_index=0,
                seed=17,
                config=coarse_config(target_remaining_fractions=(0.5,)),
                coupon=coupon,
                target_remaining_fraction=0.5,
            )

    def test_censored_handoff_fails_closed_for_downstream(self) -> None:
        config = coarse_config(
            target_remaining_fractions=(0.0,),
            maximum_planar_clear_time_multiplier=1.0e-6,
        )
        handoff = run_calibrated_primary_hf_to_endpoint(
            geometry_id="10_10_180",
            preset_id=SIN_PRESET,
            scenario="transport_only",
            replicate_index=0,
            seed=17,
            config=config,
            coupon=self.payload["coupon_calibrations"][0],
            target_remaining_fraction=0.0,
        )
        self.assertEqual(
            handoff.endpoint["observation_status"], "right_censored"
        )
        self.assertFalse(handoff.validity["downstream_eligible"])
        with self.assertRaisesRegex(RuntimeError, "not downstream-eligible"):
            handoff.require_downstream_eligible()

    def test_strict_json_and_flat_csv_round_trip(self) -> None:
        assert_finite_tree(self, self.payload)
        json.dumps(self.payload, allow_nan=False)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            json_path = save_primary_hf_endpoint_json(
                self.payload, root / "result.json"
            )
            csv_path = save_primary_hf_endpoint_csv(
                self.payload, root / "endpoint.csv"
            )
            loaded = json.loads(json_path.read_text(encoding="utf-8"))
            json_text = json_path.read_text(encoding="utf-8")
            with csv_path.open(encoding="utf-8", newline="") as stream:
                rows = list(csv.DictReader(stream))
        self.assertEqual(loaded["schema_version"], self.payload["schema_version"])
        self.assertTrue(json_text.endswith("\n"))
        self.assertEqual(len(rows), 3)
        self.assertIn("endpoint_physical_time_s", rows[0])

    def test_measured_blanket_override_changes_status_not_identity(self) -> None:
        measured = BlanketRateInput(
            preset_id=SIN_PRESET,
            rate_nm_min=2.5,
            uncertainty_nm_min=0.1,
            source_kind="experimental_blanket",
            source_note="same lot",
            measurement_temperature_K=310.0,
        )
        payload = run_primary_hf_endpoint_calibration(
            coarse_config(blanket_rate_inputs={SIN_PRESET: measured})
        )
        self.assertEqual(
            payload["calibration_status"]["level"], "blanket_calibrated"
        )
        self.assertEqual(payload["cases"][0]["material"], "SiN")
        self.assertEqual(
            payload["cases"][0]["blanket_anchor"]["source_kind"],
            "experimental_blanket",
        )
        self.assertEqual(
            payload["coupon_calibrations"][0]["environment_temperature_K"],
            310.0,
        )
        baseline_coupling = self.payload["cases"][0]["model_parameters"][
            "coupling_native_clock"
        ]
        measured_coupling = payload["cases"][0]["model_parameters"][
            "coupling_native_clock"
        ]
        self.assertAlmostEqual(
            measured_coupling["hf_interface_sink_velocity_nm_s"]
            / baseline_coupling["hf_interface_sink_velocity_nm_s"],
            2.5 / 2.2,
        )
        self.assertAlmostEqual(
            measured_coupling["product_interface_source_flux"]
            / baseline_coupling["product_interface_source_flux"],
            2.5 / 2.2,
        )

    def test_sicn_linearized_prior_runs_without_aliasing_to_siocn(self) -> None:
        payload = run_primary_hf_endpoint_calibration(
            coarse_config(presets=(SICN_C22_PRESET,))
        )
        case = payload["cases"][0]
        self.assertEqual(case["material"], "SiCN")
        self.assertEqual(case["blanket_anchor"]["rate_nm_min"], 0.06)
        self.assertEqual(
            case["model_parameters"][
                "derived_conditions_before_clock_calibration"
            ]["nominal_hf_weight_percent"],
            0.15,
        )
        self.assertEqual(
            case["blanket_anchor"]["source_kind"],
            "literature_prior",
        )

    def test_fixed_probe_beyond_horizon_is_explicitly_censored(self) -> None:
        payload = run_primary_hf_endpoint_calibration(
            coarse_config(
                fixed_probe_times_s=(1.0e9,),
                maximum_planar_clear_time_multiplier=0.25,
            )
        )
        probe = payload["cases"][0]["fixed_time_probes"][0]
        self.assertFalse(probe["within_simulated_horizon"])
        self.assertTrue(probe["censored_at_simulation_horizon"])
        self.assertLess(
            probe["evaluated_physical_time_s"],
            probe["requested_physical_time_s"],
        )
        self.assertFalse(
            any(
                snapshot["label"].startswith("fixed_")
                for snapshot in payload["cases"][0]["snapshots"]
            )
        )

    def test_event_budget_run_is_partial_and_not_aggregated_as_final(self) -> None:
        payload = run_primary_hf_endpoint_calibration(
            coarse_config(maximum_events=1)
        )
        case = payload["cases"][0]
        quality = payload["quality_summary"]
        self.assertEqual(case["status"], "ok")
        self.assertEqual(case["result_validity"]["level"], "partial")
        self.assertFalse(case["result_validity"]["aggregate_eligible"])
        self.assertEqual(quality["partial_trench_runs"], 1)
        self.assertEqual(quality["valid_trench_runs"], 0)
        self.assertEqual(
            payload["aggregates"][0]["final_remaining_fraction"]["count"], 0
        )
        self.assertNotEqual(quality_exit_code(quality), 0)

    def test_nonconverged_run_is_invalid_and_excluded(self) -> None:
        real_run = endpoint_module.run_coupled_trench_kmc

        def nonconverged(*args: object, **kwargs: object) -> object:
            outcome = real_run(*args, **kwargs)
            history = tuple(
                {**dict(item), "hf_converged": False}
                for item in outcome.sync_history
            )
            return replace(outcome, sync_history=history)

        with patch.object(
            endpoint_module,
            "run_coupled_trench_kmc",
            side_effect=nonconverged,
        ):
            payload = run_primary_hf_endpoint_calibration(coarse_config())
        case = payload["cases"][0]
        self.assertEqual(case["result_validity"]["level"], "invalid")
        self.assertEqual(payload["quality_summary"]["invalid_trench_runs"], 1)
        self.assertEqual(
            payload["aggregates"][0]["endpoint_summaries"][0][
                "physical_time_s"
            ]["count"],
            0,
        )

    def test_serial_and_two_workers_preserve_case_order_and_endpoints(self) -> None:
        serial = run_primary_hf_endpoint_calibration(
            coarse_config(replicate_seeds=(17, 19), parallel_workers=1)
        )
        parallel = run_primary_hf_endpoint_calibration(
            coarse_config(replicate_seeds=(17, 19), parallel_workers=2)
        )
        self.assertEqual(
            [case["case_id"] for case in serial["cases"]],
            [case["case_id"] for case in parallel["cases"]],
        )
        self.assertEqual(
            [case["endpoints"] for case in serial["cases"]],
            [case["endpoints"] for case in parallel["cases"]],
        )


if __name__ == "__main__":
    unittest.main()

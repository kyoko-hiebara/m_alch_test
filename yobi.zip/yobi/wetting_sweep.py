"""Two-dimensional wetting/gas sensitivity sweep for fully filled trenches.

The coupled cases preserve the real initial condition: every trench cell is
GAP-FILL solid and the HF reservoir is above the opening.  Newly removed void
inherits liquid in the baseline.  Capillary dry cells, entrance pinning, and a
seeded bottom gas pocket are explicit failure-mode hypotheses and are labelled
as such in every result.

An open-trench diagnostic is also included.  It isolates the Young--Laplace /
tapered-Poiseuille wetting closure from dissolution and should not be confused
with the initial state of the coupled GAP-FILL calculation.
"""

from __future__ import annotations

import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from typing import Mapping

import numpy as np

from etch_process import EtchProcessConfig, ThermalBoundaryConditions
from gapfill_etch_2d import (
    GapFillEtch2D,
    PassivationParameters,
    SaturatingRateLaw,
    TransportParameters,
)
from numerical_settings import NumericalSettings
from reaction_diffusion_2d import CartesianGrid2D
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS, get_geometry_preset
from wetting_2d import (
    WettingParameters,
    WettingState2D,
    slit_capillary_pressure_Pa,
    slit_lucas_washburn_time_s,
)


WETTING_SWEEP_NOTICE = (
    "Uncalibrated mechanism sensitivity, not a wet-process recipe. The fully "
    "GAP-FILLED initial condition contains no gas. Capillary dry void and the "
    "seeded bottom pocket explicitly represent dewetting, a pre-existing seam, "
    "or gas generation after dissolution. Contact angle, pinning delay, gas "
    "nucleation, gas loss, and the continuum closure require calibration."
)

SCENARIO_ORDER = (
    "baseline_inherited_liquid",
    "instant_hydrophilic_capillary",
    "entrance_delayed",
    "bottom_gas_ideal_compression",
    "bottom_gas_fixed_volume_bound",
    "combined_adverse",
)


@dataclass(frozen=True)
class WettingSweepConfig:
    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    scenarios: tuple[str, ...] = SCENARIO_ORDER
    material: str = "SiN"
    grid_spacing_nm: float = 2.0
    probe_grid_spacing_nm: float = 0.5
    reservoir_height_nm: float = 4.0
    maximum_etch_velocity_nm_s: float = 4.0
    maximum_time_over_planar_clear: float = 1.40
    maximum_fractional_front_change: float = 0.80
    contact_angles_deg: tuple[float, ...] = (20.0, 60.0, 85.0, 95.0, 120.0)
    probe_samples: int = 121
    maximum_probe_displacement_nm: float = 0.20
    solution_bulk_temperature_K: float = 298.15
    substrate_backside_temperature_K: float = 323.15
    parallel_workers: int = 1

    def __post_init__(self) -> None:
        unknown_geometries = set(self.geometries).difference(GEOMETRY_PRESETS)
        unknown_scenarios = set(self.scenarios).difference(SCENARIO_ORDER)
        if not self.geometries or unknown_geometries:
            raise ValueError(
                f"unknown or empty geometry selection: {sorted(unknown_geometries)}"
            )
        if not self.scenarios or unknown_scenarios:
            raise ValueError(
                f"unknown or empty scenario selection: {sorted(unknown_scenarios)}"
            )
        if self.material not in {"SiN", "SiCN", "SiOCN"}:
            raise ValueError("material must be SiN, SiCN, or SiOCN")
        for name in (
            "grid_spacing_nm",
            "probe_grid_spacing_nm",
            "reservoir_height_nm",
            "maximum_etch_velocity_nm_s",
            "maximum_time_over_planar_clear",
            "maximum_fractional_front_change",
            "maximum_probe_displacement_nm",
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.maximum_fractional_front_change > 1.0:
            raise ValueError("maximum_fractional_front_change cannot exceed one")
        angles = tuple(float(value) for value in self.contact_angles_deg)
        if not angles or any(
            not math.isfinite(value) or not 0.0 <= value <= 180.0
            for value in angles
        ):
            raise ValueError("contact angles must lie in [0, 180]")
        object.__setattr__(self, "contact_angles_deg", angles)
        if not isinstance(self.probe_samples, int) or self.probe_samples < 2:
            raise ValueError("probe_samples must be an integer >= 2")
        if not isinstance(self.parallel_workers, int) or self.parallel_workers < 1:
            raise ValueError("parallel_workers must be a positive integer")

    def to_dict(self) -> dict[str, object]:
        values = asdict(self)
        values["geometries"] = list(self.geometries)
        values["scenarios"] = list(self.scenarios)
        values["contact_angles_deg"] = list(self.contact_angles_deg)
        return values


def _scenario(
    name: str,
    *,
    geometry_name: str,
    config: WettingSweepConfig,
) -> tuple[WettingParameters, str]:
    geometry = get_geometry_preset(geometry_name)
    nominal_clear_s = geometry.depth_nm / config.maximum_etch_velocity_nm_s
    common: dict[str, object] = {
        "enabled": True,
        "gas_temperature_K": config.solution_bulk_temperature_K,
    }
    if name == "baseline_inherited_liquid":
        return (
            WettingParameters(
                enabled=False,
                gas_temperature_K=config.solution_bulk_temperature_K,
            ),
            "reference: every newly dissolved cell inherits the contacting liquid",
        )
    if name == "instant_hydrophilic_capillary":
        return (
            WettingParameters(
                **common,
                new_void_filling_mode="capillary",
                advancing_contact_angle_deg=30.0,
            ),
            "dry-new-void hypothesis with hydrophilic, unpinned capillary invasion",
        )
    if name == "entrance_delayed":
        return (
            WettingParameters(
                **common,
                new_void_filling_mode="capillary",
                advancing_contact_angle_deg=60.0,
                entrance_delay_s=0.08 * nominal_clear_s,
                maximum_contact_line_speed_nm_s=(
                    0.30 * config.maximum_etch_velocity_nm_s
                ),
            ),
            "explicit entrance pinning/dewetting delay with a capped contact-line speed",
        )
    if name == "bottom_gas_ideal_compression":
        return (
            WettingParameters(
                **common,
                advancing_contact_angle_deg=60.0,
                bottom_gas_pocket_seed_height_nm=0.12 * geometry.depth_nm,
                bottom_gas_activation_depth_fraction=0.80,
                gas_compression_mode="ideal",
            ),
            "seeded deep gas after 80% opening, compressed as an ideal gas",
        )
    if name == "bottom_gas_fixed_volume_bound":
        return (
            WettingParameters(
                **common,
                advancing_contact_angle_deg=60.0,
                bottom_gas_pocket_seed_height_nm=0.12 * geometry.depth_nm,
                bottom_gas_activation_depth_fraction=0.80,
                gas_dissolution_time_s=0.50 * nominal_clear_s,
                gas_residual_fraction=0.25,
                gas_compression_mode="none",
            ),
            "upper-bound pocket volume with empirical gas loss and a 25% residual",
        )
    if name == "combined_adverse":
        return (
            WettingParameters(
                **common,
                new_void_filling_mode="capillary",
                advancing_contact_angle_deg=85.0,
                entrance_delay_s=0.08 * nominal_clear_s,
                maximum_contact_line_speed_nm_s=(
                    0.20 * config.maximum_etch_velocity_nm_s
                ),
                bottom_gas_pocket_seed_height_nm=0.12 * geometry.depth_nm,
                bottom_gas_activation_depth_fraction=0.72,
                gas_dissolution_time_s=nominal_clear_s,
                gas_residual_fraction=0.25,
                gas_compression_mode="none",
            ),
            "combined high-angle, entrance-delay, slow-invasion and seeded-gas bound",
        )
    raise ValueError(f"unknown wetting scenario {name!r}")


def _process(config: WettingSweepConfig, geometry_name: str) -> EtchProcessConfig:
    return EtchProcessConfig(
        geometry=get_geometry_preset(geometry_name),
        gap_fill_material=config.material,
        thermal_bc=ThermalBoundaryConditions(
            solution_bulk_temperature_K=config.solution_bulk_temperature_K,
            substrate_backside_temperature_K=(
                config.substrate_backside_temperature_K
            ),
        ),
    )


def _downsample_history(history: tuple[object, ...]) -> list[dict[str, object]]:
    if not history:
        return []
    stride = max(1, len(history) // 150)
    selected = list(history[::stride])
    if selected[-1] is not history[-1]:
        selected.append(history[-1])
    return [
        {
            "time_s": float(entry.time_s),
            "remaining_mass_fraction": float(entry.remaining_solid_area_nm2),
            "open_void_area_nm2": float(entry.open_void_area_nm2),
            "wetted_area_nm2": float(entry.wetted_area_nm2),
            "gas_area_nm2": float(entry.gas_area_nm2),
            "contact_line_depth_nm": float(entry.contact_line_depth_nm),
            "meniscus_center_depth_nm": float(
                entry.meniscus_center_depth_nm
            ),
            "capillary_pressure_Pa": float(entry.capillary_pressure_Pa),
            "gas_pressure_Pa": float(entry.gas_pressure_Pa),
            "bottom_gas_pocket_active": bool(
                entry.bottom_gas_pocket_active
            ),
        }
        for entry in selected
    ]


def _phase_map(model: GapFillEtch2D) -> dict[str, object]:
    snapshot = model.snapshot()
    return {
        "x_nm": model.grid.lateral_nm.tolist(),
        "depth_nm": model.grid.depth_nm.tolist(),
        "cavity_mask": model.grid.cavity_mask.astype(int).tolist(),
        "solid_fraction": snapshot.solid_fraction.tolist(),
        "liquid_mask": snapshot.liquid_mask.astype(int).tolist(),
        "gas_mask": snapshot.gas_mask.astype(int).tolist(),
        "bottom_gas_mask": snapshot.bottom_gas_mask.astype(int).tolist(),
        "meniscus_depth_profile_nm": (
            snapshot.meniscus_depth_profile_nm.tolist()
        ),
    }


def run_coupled_wetting_case(
    geometry_name: str,
    scenario_name: str,
    config: WettingSweepConfig,
) -> dict[str, object]:
    process = _process(config, geometry_name)
    wetting, interpretation = _scenario(
        scenario_name, geometry_name=geometry_name, config=config
    )
    settings = NumericalSettings(
        linear_relative_tolerance=1.0e-4,
        linear_absolute_tolerance=1.0e-8,
        nonlinear_relative_tolerance=5.0e-3,
        steady_state_relative_tolerance=1.0e-3,
        mass_balance_relative_tolerance=5.0e-2,
        maximum_iterations=500,
        maximum_nonlinear_iterations=30,
        maximum_fractional_state_change=(
            config.maximum_fractional_front_change
        ),
        minimum_time_step_s=1.0e-9,
        maximum_time_step_s=1.0,
    )
    model = GapFillEtch2D(
        process,
        spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=max(config.grid_spacing_nm, 2.0),
        transport=TransportParameters(
            reactant_diffusivity_nm2_s=1.0e6,
            product_diffusivity_nm2_s=1.0e6,
            reactant_bulk_concentration=1.0,
            reactant_surface_transfer_nm_s=20.0,
            product_bulk_concentration=0.0,
            product_yield_concentration=0.0,
            product_bulk_decay_per_s=0.0,
        ),
        passivation=PassivationParameters(),
        rate_law=SaturatingRateLaw(
            maximum_velocity_nm_s=config.maximum_etch_velocity_nm_s,
            half_saturation=0.01,
            product_inhibition=0.0,
        ),
        wetting_parameters=wetting,
        numerical_settings=settings,
    )
    initial_area_nm2 = model.front.initial_solid_area_nm2
    nominal_clear_s = (
        process.geometry.depth_nm / config.maximum_etch_velocity_nm_s
    )
    total_time_s = config.maximum_time_over_planar_clear * nominal_clear_s
    result = model.run(
        total_time_s,
        time_step_s=min(1.0, nominal_clear_s / 40.0),
        snapshot_every_steps=25,
        max_steps=5000,
    )
    remaining = model.front.solid_fraction
    cavity = model.grid.cavity_mask
    bottom_zone = cavity & (
        model.grid.depth_mesh_nm >= 0.85 * process.geometry.depth_nm
    )
    local_half_width = 0.5 * process.geometry.width_at_depth_nm(
        np.clip(
            model.grid.depth_mesh_nm,
            0.0,
            process.geometry.depth_nm,
        )
    )
    wall_zone = cavity & (
        local_half_width - np.abs(model.grid.lateral_mesh_nm)
        <= 1.25 * model.grid.dx_nm
    )

    def zone_fraction(mask: np.ndarray) -> float:
        if not np.any(mask):
            return 0.0
        return float(np.mean(remaining[mask]))

    wet_diag = result.final_wetting_diagnostics
    history = _downsample_history(result.history)
    for entry in history:
        entry["remaining_mass_fraction"] = (
            float(entry["remaining_mass_fraction"]) / initial_area_nm2
        )
    return {
        "geometry_name": geometry_name,
        "geometry": process.geometry.to_dict(),
        "material": config.material,
        "scenario": scenario_name,
        "scenario_interpretation": interpretation,
        "initial_condition": {
            "fully_gap_filled": True,
            "initial_gas_area_nm2": 0.0,
            "initial_liquid_area_in_trench_nm2": 0.0,
        },
        "temperatures": {
            "solution_bulk_temperature_K": (
                config.solution_bulk_temperature_K
            ),
            "substrate_backside_temperature_K": (
                config.substrate_backside_temperature_K
            ),
            "independently_configurable": True,
            "kinetic_temperature_correction_in_this_sweep": False,
        },
        "wetting_parameters": wetting.to_dict(),
        "grid": {
            "shape": list(model.grid.shape),
            "dx_nm": model.grid.dx_nm,
            "dz_nm": model.grid.dz_nm,
            "initial_area_discretization_relative_error": (
                result.final_diagnostics.initial_area_discretization_relative_error
            ),
        },
        "timing": {
            "nominal_planar_clear_time_s": nominal_clear_s,
            "requested_end_time_s": total_time_s,
            "actual_end_time_s": result.final_diagnostics.time_s,
            "steps": len(result.history),
        },
        "outcome": {
            "completed": result.completed,
            "remaining_mass_fraction": (
                result.final_diagnostics.remaining_mass_fraction
            ),
            "dissolved_mass_fraction": (
                result.final_diagnostics.dissolved_mass_fraction
            ),
            "bottom_15pct_remaining_fraction": zone_fraction(bottom_zone),
            "near_wall_remaining_fraction": zone_fraction(wall_zone),
            "open_void_area_nm2": (
                wet_diag.open_void_area_nm2
                if wet_diag is not None
                else result.final_diagnostics.liquid_area_in_trench_nm2
            ),
            "wetted_area_nm2": (
                wet_diag.wetted_area_nm2
                if wet_diag is not None
                else result.final_diagnostics.liquid_area_in_trench_nm2
            ),
            "gas_area_nm2": wet_diag.gas_area_nm2 if wet_diag else 0.0,
            "contact_line_depth_nm": (
                wet_diag.contact_line_depth_nm
                if wet_diag is not None
                else process.geometry.depth_nm
            ),
            "gas_pressure_Pa": (
                wet_diag.gas_pressure_Pa if wet_diag is not None else 0.0
            ),
            "high_pressure_model_warning": (
                wet_diag.high_pressure_model_warning
                if wet_diag is not None
                else False
            ),
            "gas_subgrid_representation_warning": (
                wet_diag.gas_subgrid_representation_warning
                if wet_diag is not None
                else False
            ),
            "gas_area_quantization_error_nm2": (
                wet_diag.gas_area_quantization_error_nm2
                if wet_diag is not None
                else 0.0
            ),
            "phase_partition_relative_error": (
                wet_diag.phase_partition_relative_error
                if wet_diag is not None
                else 0.0
            ),
        },
        "history": history,
        "final_phase_map": _phase_map(model),
    }


def _case_worker(
    arguments: tuple[str, str, WettingSweepConfig]
) -> dict[str, object]:
    return run_coupled_wetting_case(*arguments)


def _initialise_worker() -> None:
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[name] = "1"


def _advance_probe_to(
    state: WettingState2D,
    open_void_mask: np.ndarray,
    target_time_s: float,
    maximum_displacement_nm: float,
) -> None:
    tolerance = 1.0e-14 * max(target_time_s, 1.0e-12)
    while state.time_s < target_time_s - tolerance:
        remaining = target_time_s - state.time_s
        speed, _, _ = state.hydraulic_contact_line_state(
            state.contact_line_depth_nm
        )
        if speed <= 0.0 or state.contact_line_depth_nm >= state.grid.geometry.depth_nm:
            state.update(open_void_mask, remaining)
            return
        displacement_limited = maximum_displacement_nm / speed
        dt_s = min(remaining, displacement_limited)
        if dt_s <= 0.0 or not math.isfinite(dt_s):
            raise RuntimeError("open-trench probe produced an invalid time step")
        state.update(open_void_mask, dt_s)


def run_open_trench_probe(
    config: WettingSweepConfig,
) -> dict[str, object]:
    cases: list[dict[str, object]] = []
    for geometry_name in config.geometries:
        geometry = get_geometry_preset(geometry_name)
        finite_estimates = [
            slit_lucas_washburn_time_s(
                geometry.depth_nm,
                geometry.bottom_width_nm,
                angle,
                0.07197,
                0.89e-3,
            )
            for angle in config.contact_angles_deg
            if angle < 90.0
        ]
        total_time_s = 2.5 * max(finite_estimates, default=1.0e-6)
        grid = CartesianGrid2D.from_geometry(
            geometry,
            spacing_nm=config.probe_grid_spacing_nm,
            reservoir_height_nm=max(2.0, config.probe_grid_spacing_nm),
            lateral_margin_nm=config.probe_grid_spacing_nm,
        )
        open_void = grid.reservoir_mask | grid.cavity_mask
        sample_times = np.linspace(0.0, total_time_s, config.probe_samples)
        for angle in config.contact_angles_deg:
            parameters = WettingParameters(
                enabled=True,
                new_void_filling_mode="capillary",
                advancing_contact_angle_deg=angle,
            )
            state = WettingState2D(grid, parameters)
            state.update(open_void, 0.0)
            depths: list[float] = []
            centers: list[float] = []
            wetted_fractions: list[float] = []
            for target in sample_times:
                _advance_probe_to(
                    state,
                    open_void,
                    float(target),
                    config.maximum_probe_displacement_nm,
                )
                depths.append(state.diagnostics.contact_line_depth_nm)
                centers.append(state.diagnostics.meniscus_center_depth_nm)
                wetted_fractions.append(
                    state.diagnostics.wetted_fraction_of_open_void
                )
            estimate = slit_lucas_washburn_time_s(
                geometry.depth_nm,
                geometry.bottom_width_nm,
                angle,
                parameters.surface_tension_N_m,
                parameters.dynamic_viscosity_Pa_s,
            )
            cases.append(
                {
                    "geometry_name": geometry_name,
                    "contact_angle_deg": angle,
                    "time_s": sample_times.tolist(),
                    "contact_line_depth_nm": depths,
                    "meniscus_center_depth_nm": centers,
                    "wetted_fraction_of_open_void": wetted_fractions,
                    "constant_bottom_width_washburn_time_s": (
                        estimate if math.isfinite(estimate) else None
                    ),
                    "capillary_pressure_top_Pa": slit_capillary_pressure_Pa(
                        geometry.top_width_nm,
                        angle,
                        parameters.surface_tension_N_m,
                    ),
                    "capillary_pressure_bottom_Pa": (
                        slit_capillary_pressure_Pa(
                            geometry.bottom_width_nm,
                            angle,
                            parameters.surface_tension_N_m,
                        )
                    ),
                }
            )
    return {
        "model": "open-trench tapered-slit wetting diagnostic",
        "is_coupled_gapfill_initial_condition": False,
        "purpose": (
            "isolate contact angle and entrance-meniscus dynamics from solid removal"
        ),
        "surface_tension_N_m": 0.07197,
        "dynamic_viscosity_Pa_s": 0.89e-3,
        "cases": cases,
    }


def _summary(cases: list[dict[str, object]]) -> dict[str, object]:
    largest_partition_error = max(
        (
            float(case["outcome"]["phase_partition_relative_error"])
            for case in cases
        ),
        default=0.0,
    )
    gas_cases = [
        case
        for case in cases
        if float(case["outcome"]["gas_area_nm2"]) > 0.0
    ]
    worst_bottom = max(
        cases,
        key=lambda case: float(
            case["outcome"]["bottom_15pct_remaining_fraction"]
        ),
        default=None,
    )
    return {
        "case_count": len(cases),
        "largest_phase_partition_relative_error": largest_partition_error,
        "cases_with_final_gas": len(gas_cases),
        "high_pressure_warning_cases": sum(
            bool(case["outcome"]["high_pressure_model_warning"])
            for case in cases
        ),
        "worst_bottom_residue_case": (
            {
                "geometry_name": worst_bottom["geometry_name"],
                "scenario": worst_bottom["scenario"],
                "bottom_15pct_remaining_fraction": worst_bottom["outcome"][
                    "bottom_15pct_remaining_fraction"
                ],
            }
            if worst_bottom is not None
            else None
        ),
        "screening_conclusion": (
            "Compare wetting times against etch time first. A persistent dry or "
            "gas-limited residue requires explicit pinning, dewetting, a seam, "
            "gas generation, or a calibrated mass-transfer limitation."
        ),
    }


def run_wetting_sweep(
    config: WettingSweepConfig | None = None,
) -> dict[str, object]:
    resolved = config or WettingSweepConfig()
    inputs = [
        (geometry, scenario, resolved)
        for geometry in resolved.geometries
        for scenario in resolved.scenarios
    ]
    workers = min(resolved.parallel_workers, len(inputs))
    if workers == 1:
        cases = [_case_worker(arguments) for arguments in inputs]
    else:
        variables = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
        previous = {name: os.environ.get(name) for name in variables}
        for name in variables:
            os.environ[name] = "1"
        try:
            with ProcessPoolExecutor(
                max_workers=workers,
                initializer=_initialise_worker,
            ) as executor:
                cases = list(executor.map(_case_worker, inputs))
        finally:
            for name, value in previous.items():
                if value is None:
                    os.environ.pop(name, None)
                else:
                    os.environ[name] = value
    return {
        "schema_version": 1,
        "model": "2-D contact angle, entrance meniscus, wetting delay and gas pocket",
        "notice": WETTING_SWEEP_NOTICE,
        "calibrated": False,
        "config": resolved.to_dict(),
        "phase_definition": {
            "solid": "remaining GAP FILL; partial cells are retained as solid_fraction",
            "liquid": "top-connected HF phase used by transport and front motion",
            "gas": "open cavity excluded from transport and front motion",
            "bottom_gas": "subset created by the explicit seeded-pocket model",
        },
        "parameter_classification": {
            "literature_or_standard_closure": [
                "water surface tension and viscosity near 298 K",
                "Young-Laplace slit pressure",
                "parallel-plate Poiseuille resistance",
                "ideal-gas compression option",
            ],
            "uncalibrated_hypotheses": [
                "in-situ advancing contact angle on actual SiN/SiCN/SiOCN residue",
                "entrance delay and pinning pressure",
                "contact-line speed cap",
                "gas-pocket nucleation depth and seed height",
                "gas dissolution time and residual fraction",
                "fixed-volume gas upper bound",
            ],
        },
        "literature_sources": {
            "Washburn_1921": "https://doi.org/10.1103/PhysRev.17.273",
            "HF_treated_Si_rich_SiN_contact_angle": "https://doi.org/10.1021/ja0483746",
            "nanometre_slit_dynamic_contact_angle_MD": "https://doi.org/10.1063/5.0329359",
            "closed_end_capillary_gas_dissolution": "https://doi.org/10.1088/1674-1056/27/2/024701",
        },
        "parallel_execution": {
            "requested_workers": resolved.parallel_workers,
            "effective_workers": workers,
            "case_order_preserved": True,
        },
        "open_trench_probe": run_open_trench_probe(resolved),
        "coupled_cases": cases,
        "summary": _summary(cases),
    }


def _phase_array(case: Mapping[str, object]) -> tuple[np.ndarray, ...]:
    phase_map = case["final_phase_map"]
    cavity = np.asarray(phase_map["cavity_mask"], dtype=bool)
    solid = np.asarray(phase_map["solid_fraction"], dtype=float)
    liquid = np.asarray(phase_map["liquid_mask"], dtype=bool)
    gas = np.asarray(phase_map["gas_mask"], dtype=bool)
    phase = np.full(cavity.shape, np.nan, dtype=float)
    phase[cavity & (solid > 1.0e-12)] = 0.0
    phase[cavity & liquid] = 1.0
    phase[cavity & gas] = 2.0
    return (
        np.asarray(phase_map["x_nm"], dtype=float),
        np.asarray(phase_map["depth_nm"], dtype=float),
        phase,
        np.asarray(phase_map["meniscus_depth_profile_nm"], dtype=float),
    )


def _draw_phase_map(axis, case: Mapping[str, object], *, title: str) -> None:
    from matplotlib.colors import ListedColormap

    x, depth, phase, meniscus = _phase_array(case)
    horizontal_exaggeration = 10.0
    axis.pcolormesh(
        horizontal_exaggeration * x,
        depth,
        np.ma.masked_invalid(phase),
        cmap=ListedColormap(["#6b7280", "#3182bd", "#f59e0b"]),
        vmin=-0.5,
        vmax=2.5,
        shading="nearest",
    )
    geometry = case["geometry"]
    half_top = 0.5 * float(geometry["top_width_nm"])
    half_bottom = 0.5 * float(geometry["bottom_width_nm"])
    trench_depth = float(geometry["depth_nm"])
    axis.plot(
        horizontal_exaggeration
        * np.asarray([-half_top, -half_bottom, half_bottom, half_top]),
        [0.0, trench_depth, trench_depth, 0.0],
        color="0.15",
        linewidth=0.8,
    )
    if bool(case["wetting_parameters"]["enabled"]):
        dz_nm = float(np.median(np.diff(depth))) if depth.size > 1 else 1.0
        cavity_depth_by_column = np.max(
            np.where(np.isfinite(phase), depth[:, None], -math.inf),
            axis=0,
        )
        visible_meniscus = np.where(
            meniscus < cavity_depth_by_column - 0.25 * dz_nm,
            meniscus,
            np.nan,
        )
        axis.plot(
            horizontal_exaggeration * x,
            visible_meniscus,
            color="#00bcd4",
            linewidth=1.0,
            alpha=0.9,
        )
    axis.set_title(title, fontsize=8)
    axis.set_xlabel("x (nm; horizontal ×10)")
    axis.set_ylabel("depth (nm)")
    axis.set_xlim(-6.0 * half_top * horizontal_exaggeration / 5.0,
                  6.0 * half_top * horizontal_exaggeration / 5.0)
    axis.set_xticks(
        horizontal_exaggeration * np.asarray([-half_top, 0.0, half_top]),
        labels=[f"{-half_top:g}", "0", f"{half_top:g}"],
    )
    axis.set_ylim(trench_depth, 0.0)


def plot_wetting_phase_maps(
    payload: Mapping[str, object], output_path: str
) -> None:
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    cases = list(payload["coupled_cases"])
    geometries = list(dict.fromkeys(case["geometry_name"] for case in cases))
    scenarios = list(dict.fromkeys(case["scenario"] for case in cases))
    figure, axes = plt.subplots(
        len(geometries),
        len(scenarios),
        figsize=(2.15 * len(scenarios), 4.0 * len(geometries)),
        squeeze=False,
        constrained_layout=True,
    )
    lookup = {
        (case["geometry_name"], case["scenario"]): case for case in cases
    }
    for row, geometry in enumerate(geometries):
        for column, scenario in enumerate(scenarios):
            case = lookup[(geometry, scenario)]
            residual = 100.0 * float(
                case["outcome"]["remaining_mass_fraction"]
            )
            _draw_phase_map(
                axes[row, column],
                case,
                title=f"{geometry}\n{scenario}\nresidual={residual:.1f}%",
            )
    figure.legend(
        handles=[
            Patch(color="#6b7280", label="GAP FILL solid"),
            Patch(color="#3182bd", label="HF liquid"),
            Patch(color="#f59e0b", label="dry/gas open void"),
            Patch(color="#00bcd4", label="meniscus"),
        ],
        loc="outside lower center",
        ncol=4,
        frameon=False,
    )
    figure.suptitle(
        "Coupled full-GAP-FILL wetting scenarios (horizontal scale ×10)",
        fontsize=11,
    )
    figure.savefig(output_path, dpi=220)
    plt.close(figure)


def plot_wetting_summary(
    payload: Mapping[str, object], output_path: str
) -> None:
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    cases = list(payload["coupled_cases"])
    probes = list(payload["open_trench_probe"]["cases"])
    geometries = list(dict.fromkeys(case["geometry_name"] for case in cases))
    scenarios = list(dict.fromkeys(case["scenario"] for case in cases))
    figure, axes = plt.subplots(
        2, 3, figsize=(12.0, 8.4), constrained_layout=True
    )
    for panel, geometry in enumerate(geometries[:2]):
        candidates = [
            case
            for case in cases
            if case["geometry_name"] == geometry
        ]
        case = max(
            candidates,
            key=lambda item: (
                float(item["outcome"]["gas_area_nm2"]),
                float(item["outcome"]["remaining_mass_fraction"]),
            ),
        )
        _draw_phase_map(
            axes.flat[panel],
            case,
            title=(
                f"{chr(65 + panel)}  {geometry}: {case['scenario']}\n"
                f"remaining={100*float(case['outcome']['remaining_mass_fraction']):.1f}%"
            ),
        )

    axis = axes.flat[2]
    colours = plt.cm.viridis(
        np.linspace(0.08, 0.92, len(payload["config"]["contact_angles_deg"]))
    )
    colour_by_angle = {
        float(angle): colour
        for angle, colour in zip(
            payload["config"]["contact_angles_deg"], colours, strict=True
        )
    }
    for probe in probes:
        angle = float(probe["contact_angle_deg"])
        geometry = get_geometry_preset(str(probe["geometry_name"]))
        axis.plot(
            1.0e6 * np.asarray(probe["time_s"], dtype=float),
            np.asarray(probe["contact_line_depth_nm"], dtype=float)
            / geometry.depth_nm,
            color=colour_by_angle[angle],
            linestyle="-" if geometry.name == geometries[0] else "--",
            linewidth=1.2,
            label=(
                f"θ={angle:g}°"
                if geometry.name == geometries[0]
                else None
            ),
        )
    axis.set_title("C  Open-trench capillary probe")
    axis.set_xlabel("time (µs)")
    axis.set_ylabel("contact-line depth / H")
    axis.set_ylim(-0.02, 1.04)
    axis.legend(fontsize=7, ncol=2, frameon=False)
    axis.text(
        0.02,
        0.04,
        f"solid={geometries[0]}, dashed={geometries[-1]}",
        transform=axis.transAxes,
        fontsize=7,
    )

    axis = axes.flat[3]
    for geometry_name in geometries:
        selected = [
            probe for probe in probes if probe["geometry_name"] == geometry_name
        ]
        axis.plot(
            [float(probe["contact_angle_deg"]) for probe in selected],
            [
                1.0e-6 * float(probe["capillary_pressure_bottom_Pa"])
                for probe in selected
            ],
            marker="o",
            label=geometry_name,
        )
    axis.axhline(0.0, color="0.4", linewidth=0.8)
    axis.axvline(90.0, color="0.65", linewidth=0.8, linestyle=":")
    axis.set_title("D  Bottom Young–Laplace pressure")
    axis.set_xlabel("advancing contact angle (degree)")
    axis.set_ylabel("capillary pressure (MPa)")
    axis.legend(fontsize=7, frameon=False)

    axis = axes.flat[4]
    for case in cases:
        if "gas" not in str(case["scenario"]) and case["scenario"] != "combined_adverse":
            continue
        history = case["history"]
        if not history:
            continue
        nominal = float(case["timing"]["nominal_planar_clear_time_s"])
        initial_area = 0.5 * (
            float(case["geometry"]["top_width_nm"])
            + float(case["geometry"]["bottom_width_nm"])
        ) * float(case["geometry"]["depth_nm"])
        axis.plot(
            [float(item["time_s"]) / nominal for item in history],
            [float(item["gas_area_nm2"]) / initial_area for item in history],
            label=f"{case['geometry_name']} | {case['scenario']}",
            linewidth=1.1,
        )
    axis.set_title("E  Explicit gas/dry area history")
    axis.set_xlabel("time / nominal planar clear time")
    axis.set_ylabel("gas area / initial GAP FILL area")
    axis.legend(fontsize=6, frameon=False)

    axis = axes.flat[5]
    width = 0.36
    positions = np.arange(len(scenarios), dtype=float)
    for index, geometry in enumerate(geometries):
        selected = {
            case["scenario"]: case
            for case in cases
            if case["geometry_name"] == geometry
        }
        values = [
            100.0
            * float(selected[name]["outcome"]["bottom_15pct_remaining_fraction"])
            for name in scenarios
        ]
        axis.bar(
            positions + (index - 0.5 * (len(geometries) - 1)) * width,
            values,
            width=width,
            label=geometry,
        )
    axis.set_title("F  Bottom-zone residue")
    axis.set_ylabel("remaining solid in bottom 15% (%)")
    axis.set_xticks(positions, [name.replace("_", "\n") for name in scenarios])
    axis.tick_params(axis="x", labelsize=6)
    axis.legend(fontsize=7, frameon=False)

    figure.legend(
        handles=[
            Patch(color="#6b7280", label="GAP FILL solid"),
            Patch(color="#3182bd", label="HF liquid"),
            Patch(color="#f59e0b", label="dry/gas void"),
            Patch(color="#00bcd4", label="meniscus"),
        ],
        loc="outside lower center",
        ncol=4,
        frameon=False,
    )
    figure.suptitle(
        "2-D wetting / meniscus / bottom-gas screening\n"
        "Gas nucleation and delayed dry void are explicit uncalibrated hypotheses",
        fontsize=11,
    )
    figure.savefig(output_path, dpi=220)
    plt.close(figure)


__all__ = [
    "SCENARIO_ORDER",
    "WETTING_SWEEP_NOTICE",
    "WettingSweepConfig",
    "plot_wetting_phase_maps",
    "plot_wetting_summary",
    "run_coupled_wetting_case",
    "run_open_trench_probe",
    "run_wetting_sweep",
]

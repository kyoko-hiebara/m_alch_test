"""Configuration and initial phase map for continuum GAP FILL etching.

The initial trench volume is always completely occupied by SiN, SiCN, or SiOCN.
HF solution initially exists only above the opening.  The liquid domain inside
the trench must therefore be created later by a moving-interface solver.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping

import numpy as np

from trench_geometry import TaperedTrench2D


FULLY_GAP_FILLED = "fully_gap_filled"
RESERVOIR_ONLY = "reservoir_only"
BOUNDARY_CONDITIONS_ONLY = "boundary_conditions_only"


class GapFillMaterial(str, Enum):
    SIN = "SiN"
    SICN = "SiCN"
    SIOCN = "SiOCN"


class InitialPhase(str, Enum):
    HF_RESERVOIR = "HF_RESERVOIR"
    GAP_FILL_SOLID = "GAP_FILL_SOLID"
    SI = "SI"


@dataclass(frozen=True)
class ThermalBoundaryConditions:
    """Independent external thermal boundary conditions."""

    solution_bulk_temperature_K: float
    substrate_backside_temperature_K: float

    def __post_init__(self) -> None:
        for field_name in (
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
        ):
            value = float(getattr(self, field_name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{field_name} must be finite and positive")

    def to_dict(self) -> dict[str, float]:
        return {
            "solution_bulk_temperature_K": self.solution_bulk_temperature_K,
            "substrate_backside_temperature_K": self.substrate_backside_temperature_K,
        }


@dataclass(frozen=True)
class EtchProcessConfig:
    geometry: TaperedTrench2D
    gap_fill_material: GapFillMaterial | str
    thermal_bc: ThermalBoundaryConditions
    initial_condition: str = FULLY_GAP_FILLED
    initial_solution_domain: str = RESERVOIR_ONLY
    thermal_model: str = BOUNDARY_CONDITIONS_ONLY

    def __post_init__(self) -> None:
        try:
            material = GapFillMaterial(self.gap_fill_material)
        except ValueError as exc:
            choices = ", ".join(item.value for item in GapFillMaterial)
            raise ValueError(f"gap_fill_material must be one of {choices}") from exc
        object.__setattr__(self, "gap_fill_material", material)
        if self.initial_condition != FULLY_GAP_FILLED:
            raise ValueError(
                f"initial_condition must be {FULLY_GAP_FILLED!r}; partial fill is unsupported"
            )
        if self.initial_solution_domain != RESERVOIR_ONLY:
            raise ValueError(
                f"initial_solution_domain must be {RESERVOIR_ONLY!r}; "
                "HF cannot initially occupy the solid-filled trench"
            )
        if self.thermal_model != BOUNDARY_CONDITIONS_ONLY:
            raise ValueError(
                f"thermal_model must currently be {BOUNDARY_CONDITIONS_ONLY!r}"
            )

    def initial_phase_map(
        self,
        lateral_nm: float | np.ndarray,
        depth_nm: float | np.ndarray,
    ) -> str | np.ndarray:
        """Classify points in the t=0 continuum cross-section.

        Negative depth is the HF reservoir above the opening.  The complete
        trapezoid is solid GAP FILL for 0 <= depth <= H.  Everything else is Si.
        """
        lateral, depth = np.broadcast_arrays(
            np.asarray(lateral_nm, dtype=float),
            np.asarray(depth_nm, dtype=float),
        )
        if np.any(~np.isfinite(lateral)) or np.any(~np.isfinite(depth)):
            raise ValueError("coordinates must contain only finite values")
        result = np.full(lateral.shape, InitialPhase.SI.value, dtype="<U16")
        result[depth < 0.0] = InitialPhase.HF_RESERVOIR.value
        inside_fill = self.geometry.contains_nm(lateral, depth)
        result[inside_fill] = InitialPhase.GAP_FILL_SOLID.value
        if result.ndim == 0:
            return str(result.item())
        return result

    def reaction_temperature_K(self) -> float:
        """Refuse to invent an interface temperature before thermal coupling."""
        raise RuntimeError(
            "reaction temperature is the local solid-liquid interface temperature; "
            "solve a thermal-resistance or conjugate heat-transfer model before "
            "evaluating temperature-dependent reaction rates"
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "geometry": self.geometry.to_dict(),
            "gap_fill": {
                "material": self.gap_fill_material.value,
                "initial_condition": self.initial_condition,
            },
            "solution": {
                "initial_domain": self.initial_solution_domain,
                "bulk_temperature_K": self.thermal_bc.solution_bulk_temperature_K,
            },
            "substrate": {
                "backside_temperature_K": (
                    self.thermal_bc.substrate_backside_temperature_K
                ),
            },
            "thermal_model": self.thermal_model,
        }

    def to_json(self, *, indent: int | None = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)

    @classmethod
    def from_dict(cls, values: Mapping[str, Any]) -> "EtchProcessConfig":
        geometry_values = values["geometry"]
        gap_fill = values["gap_fill"]
        solution = values["solution"]
        substrate = values["substrate"]
        return cls(
            geometry=TaperedTrench2D.from_dict(geometry_values),
            gap_fill_material=str(gap_fill["material"]),
            thermal_bc=ThermalBoundaryConditions(
                solution_bulk_temperature_K=float(solution["bulk_temperature_K"]),
                substrate_backside_temperature_K=float(
                    substrate["backside_temperature_K"]
                ),
            ),
            initial_condition=str(gap_fill["initial_condition"]),
            initial_solution_domain=str(solution["initial_domain"]),
            thermal_model=str(values["thermal_model"]),
        )

    @classmethod
    def from_json(cls, text: str) -> "EtchProcessConfig":
        values = json.loads(text)
        if not isinstance(values, dict):
            raise ValueError("process JSON must contain an object")
        return cls.from_dict(values)

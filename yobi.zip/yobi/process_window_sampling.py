"""Reproducible screening designs and sensitivity statistics for WET models.

The parameter ranges in this module are deliberately broad *screening*
ranges.  They are not calibrated process windows, equipment set-points, or a
wet-process recipe.  A favourable simulated class must be checked against
measured film chemistry, tool constraints, material compatibility, and fab
safety rules before it can inform an experiment.

The public API is intentionally independent of multiprocessing.  Sobol points
are generated once in a deterministic design order; workers may consume those
rows in any scheduling order without changing the design or its case IDs.
Returned structures contain only plain JSON-compatible Python values.
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, is_dataclass
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from scipy.stats import qmc, rankdata


SCREENING_NOTICE = (
    "Uncalibrated mechanism-screening design only; not a process recipe or "
    "qualified operating window."
)

TRANSFORMS = ("linear", "log", "log1p")
BOUNDS_SETS = ("quick", "full")


@dataclass(frozen=True)
class ParameterDefinition:
    """One independent coordinate of the process-window design.

    ``log`` is used for strictly positive multiplicative coordinates.
    ``log1p`` supports a physically meaningful zero while still allocating
    more resolution near the lower end.  ``control_values`` may lie outside
    the continuous Sobol bounds; this is used for the exact zero-capture
    control alongside a positive logarithmic dry-down range.
    """

    name: str
    label: str
    unit: str
    quick_bounds: tuple[float, float]
    full_bounds: tuple[float, float]
    transform: str
    reference_value: float
    description: str
    control_values: tuple[float, ...] = ()

    def __post_init__(self) -> None:
        if not self.name or not self.label:
            raise ValueError("parameter name and label cannot be empty")
        if self.transform not in TRANSFORMS:
            raise ValueError(f"transform must be one of {TRANSFORMS}")
        for bounds_name in ("quick_bounds", "full_bounds"):
            bounds = tuple(float(value) for value in getattr(self, bounds_name))
            if len(bounds) != 2 or any(not math.isfinite(value) for value in bounds):
                raise ValueError(f"{bounds_name} must contain two finite values")
            if bounds[0] >= bounds[1]:
                raise ValueError(f"{bounds_name} must be strictly increasing")
            if self.transform == "log" and bounds[0] <= 0.0:
                raise ValueError("log-transformed bounds must be strictly positive")
            if self.transform == "log1p" and bounds[0] < 0.0:
                raise ValueError("log1p-transformed bounds must be non-negative")
            object.__setattr__(self, bounds_name, bounds)
        qlo, qhi = self.quick_bounds
        flo, fhi = self.full_bounds
        if qlo < flo or qhi > fhi:
            raise ValueError("full_bounds must enclose quick_bounds")
        reference = float(self.reference_value)
        if not math.isfinite(reference) or not flo <= reference <= fhi:
            raise ValueError("reference_value must be finite and inside full bounds")
        object.__setattr__(self, "reference_value", reference)
        controls = tuple(float(value) for value in self.control_values)
        if any(not math.isfinite(value) for value in controls):
            raise ValueError("control values must be finite")
        object.__setattr__(self, "control_values", controls)

    def bounds(self, bounds_set: str) -> tuple[float, float]:
        """Return quick or full continuous sampling bounds."""

        key = str(bounds_set).lower()
        if key == "quick":
            return self.quick_bounds
        if key == "full":
            return self.full_bounds
        raise ValueError(f"bounds_set must be one of {BOUNDS_SETS}")

    def map_unit_interval(self, value: float, bounds_set: str) -> float:
        """Map a value in [0, 1] through this parameter's transform."""

        unit_value = float(value)
        if not math.isfinite(unit_value) or not 0.0 <= unit_value <= 1.0:
            raise ValueError("Sobol coordinate must lie within [0, 1]")
        low, high = self.bounds(bounds_set)
        if self.transform == "linear":
            mapped = low + unit_value * (high - low)
        elif self.transform == "log":
            mapped = math.exp(
                math.log(low) + unit_value * (math.log(high) - math.log(low))
            )
        else:
            mapped = math.expm1(
                math.log1p(low)
                + unit_value * (math.log1p(high) - math.log1p(low))
            )
        # Make endpoint behaviour exact and keep roundoff inside the contract.
        if unit_value == 0.0:
            return low
        if unit_value == 1.0:
            return high
        return min(max(float(mapped), low), high)

    def contains(
        self,
        value: float,
        bounds_set: str,
        *,
        allow_controls: bool = True,
    ) -> bool:
        number = float(value)
        if not math.isfinite(number):
            return False
        low, high = self.bounds(bounds_set)
        return low <= number <= high or (
            allow_controls and number in self.control_values
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["quick_bounds"] = list(self.quick_bounds)
        result["full_bounds"] = list(self.full_bounds)
        result["control_values"] = list(self.control_values)
        return result


# The ranges intentionally cover hypotheses wider than current defaults.  The
# strongest asymmetry and retention tails belong in the full design, while the
# quick design concentrates on plausible near-baseline behaviour for code and
# mechanism checks.  Only hf_bulk_scale is later converted to physical wt% and
# speciation; temperatures remain independent boundary inputs.
_DEFAULT_PARAMETER_DEFINITIONS = (
    ParameterDefinition(
        "hf_bulk_scale",
        "bulk HF concentration scale",
        "relative",
        (0.60, 1.40),
        (0.25, 1.70),
        "log",
        1.0,
        "Multiplier on the nominal literature-preset analytical HF content.",
    ),
    ParameterDefinition(
        "liquid_temperature_K",
        "liquid temperature",
        "K",
        (288.15, 328.15),
        (278.15, 353.15),
        "linear",
        298.15,
        "Solution-bulk thermal boundary; independent of substrate temperature.",
    ),
    ParameterDefinition(
        "substrate_temperature_K",
        "substrate temperature",
        "K",
        (293.15, 353.15),
        (278.15, 373.15),
        "linear",
        323.15,
        "Substrate-backside thermal boundary; independent of liquid temperature.",
    ),
    ParameterDefinition(
        "depth_quality_factor",
        "bottom-to-top depth quality factor",
        "relative rate",
        (0.40, 1.30),
        (0.10, 2.00),
        "log",
        1.0,
        "Multiplicative bottom-versus-top as-deposited etchability coordinate.",
    ),
    ParameterDefinition(
        "wall_quality_factor",
        "sidewall film quality factor",
        "relative rate",
        (0.25, 1.25),
        (0.03, 2.00),
        "log",
        0.80,
        "Multiplicative etchability adjacent to the trench sidewalls.",
    ),
    ParameterDefinition(
        "floor_quality_factor",
        "floor film quality factor",
        "relative rate",
        (0.15, 1.10),
        (0.01, 2.00),
        "log",
        0.58,
        "Multiplicative etchability at the terminal trench floor.",
    ),
    ParameterDefinition(
        "product_inhibition_strength",
        "product inhibition strength",
        "dimensionless",
        (0.50, 6.00),
        (0.00, 30.00),
        "log1p",
        2.0,
        "Coefficient multiplying the local dissolved-product inhibition term.",
    ),
    ParameterDefinition(
        "passivation_generation_rate_s",
        "passivation generation rate",
        "s^-1",
        (0.05, 0.80),
        (0.00, 3.00),
        "log1p",
        0.26,
        "Local product-assisted passivation frequency before field factors.",
    ),
    ParameterDefinition(
        "passivation_release_rate_s",
        "passivation release rate",
        "s^-1",
        (0.02, 0.30),
        (0.001, 1.00),
        "log",
        0.08,
        "Local depassivation frequency before field and cluster factors.",
    ),
    ParameterDefinition(
        "rinse_delay_s",
        "delay before rinse",
        "s",
        (0.00, 60.0),
        (0.00, 900.0),
        "log1p",
        0.0,
        "Post-HF wet hold used by the frozen-endpoint-field screening branch.",
    ),
    ParameterDefinition(
        "wall_affinity",
        "wall-to-floor attachment affinity",
        "relative",
        (0.50, 5.00),
        (0.05, 30.0),
        "log",
        1.0,
        "Relative allocation weight for deposit attachment to sidewalls.",
    ),
    ParameterDefinition(
        "drydown_capture_fraction",
        "dry-down product capture fraction",
        "fraction",
        (1.0e-4, 0.10),
        (1.0e-6, 0.50),
        "log",
        0.01,
        "Net fraction of cumulative generated product captured during dry-down.",
        control_values=(0.0,),
    ),
    ParameterDefinition(
        "second_wet_rate_multiplier",
        "second-WET rate multiplier",
        "relative",
        (0.20, 2.00),
        (0.00, 10.0),
        "log1p",
        0.70,
        "Multiplier on the uncalibrated second-WET reference removal rate.",
    ),
)


def default_parameter_definitions() -> tuple[ParameterDefinition, ...]:
    """Return the immutable 13-coordinate default screening definition."""

    return _DEFAULT_PARAMETER_DEFINITIONS


def parameter_grid_values(
    definition: ParameterDefinition,
    levels: int,
    bounds_set: str = "quick",
) -> list[float]:
    """Return transform-aware grid values including both requested bounds."""

    if not isinstance(definition, ParameterDefinition):
        raise TypeError("definition must be a ParameterDefinition")
    if not isinstance(levels, int) or isinstance(levels, bool) or levels < 2:
        raise ValueError("levels must be an integer of at least two")
    return [
        float(definition.map_unit_interval(float(value), bounds_set))
        for value in np.linspace(0.0, 1.0, levels)
    ]


def _validate_definitions(
    definitions: Sequence[ParameterDefinition] | None,
) -> tuple[ParameterDefinition, ...]:
    resolved = tuple(
        default_parameter_definitions() if definitions is None else definitions
    )
    if not resolved or any(
        not isinstance(item, ParameterDefinition) for item in resolved
    ):
        raise TypeError("definitions must contain ParameterDefinition objects")
    names = tuple(item.name for item in resolved)
    if len(set(names)) != len(names):
        raise ValueError("parameter names must be unique")
    return resolved


def _sobol_unit_points(dimension: int, n: int, seed: int) -> np.ndarray:
    # random_base2 retains the balance guarantee and avoids scipy's warning for
    # arbitrary n.  Slicing the deterministic prefix keeps any requested n.
    power = int(math.ceil(math.log2(n))) if n > 1 else 0
    engine = qmc.Sobol(d=dimension, scramble=True, seed=seed)
    return np.asarray(engine.random_base2(power)[:n], dtype=float)


def generate_sobol_design(
    n: int,
    seed: int,
    *,
    bounds_set: str = "quick",
    definitions: Sequence[ParameterDefinition] | None = None,
    include_zero_capture_control: bool = True,
    workers: int = 1,
) -> list[dict[str, object]]:
    """Return a scrambled-Sobol design in a stable, worker-neutral order.

    ``n`` is the number of Sobol points.  When
    ``include_zero_capture_control`` is true, one additional reference row is
    prepended with ``drydown_capture_fraction == 0``.  The control is separate
    because the continuous dry-down coordinate is sampled logarithmically over
    strictly positive values.

    ``workers`` is validated but deliberately does not enter point generation,
    IDs, or ordering.  It is accepted so callers can construct a design before
    choosing serial or multiprocessing execution without branching logic.
    """

    if not isinstance(n, int) or isinstance(n, bool) or n < 1:
        raise ValueError("n must be a positive integer")
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    if not isinstance(workers, int) or isinstance(workers, bool) or workers < 1:
        raise ValueError("workers must be a positive integer")
    del workers  # scheduling is intentionally outside the design definition
    key = str(bounds_set).lower()
    if key not in BOUNDS_SETS:
        raise ValueError(f"bounds_set must be one of {BOUNDS_SETS}")
    resolved = _validate_definitions(definitions)
    points = _sobol_unit_points(len(resolved), n, seed)

    rows: list[dict[str, object]] = []
    capture = next(
        (item for item in resolved if item.name == "drydown_capture_fraction"),
        None,
    )
    if include_zero_capture_control:
        if capture is None or 0.0 not in capture.control_values:
            raise ValueError(
                "zero-capture control requires drydown_capture_fraction with "
                "0 in control_values"
            )
        parameters = {item.name: float(item.reference_value) for item in resolved}
        parameters[capture.name] = 0.0
        rows.append(
            {
                "design_index": 0,
                "case_id": "zero_capture_control",
                "design_role": "zero_capture_control",
                "sobol_index": None,
                **parameters,
            }
        )

    offset = len(rows)
    for sobol_index, point in enumerate(points):
        parameters = {
            definition.name: definition.map_unit_interval(
                float(point[index]), key
            )
            for index, definition in enumerate(resolved)
        }
        rows.append(
            {
                "design_index": offset + sobol_index,
                "case_id": f"sobol_{sobol_index:06d}",
                "design_role": "sobol",
                "sobol_index": sobol_index,
                **parameters,
            }
        )
    return to_plain_data(rows)  # type: ignore[return-value]


@dataclass(frozen=True)
class ClassificationThresholds:
    """Numerical, not experimental, residue thresholds for phase-map labels."""

    matrix_clear_fraction: float = 0.005
    deposit_clear_fraction: float = 0.01
    region_flag_fraction: float = 0.02
    region_flag_min_sites: int = 2
    # ``region_flag_min_sites`` is spatial support, which belongs in the
    # region flag and not in the severity magnitude.  Folding an absolute site
    # count into the severity makes it scale as 1/mesh^2, so the bottom-versus-
    # wall comparison flips with the mesh at unchanged physics: at 1.4 nm the
    # count term binds for the smaller bottom region and hands the label to the
    # wall, while at 1.05 nm and finer the fraction binds for both.  Set this
    # to True only to reproduce results saved before 2026-07-25.
    severity_uses_site_count: bool = False

    def __post_init__(self) -> None:
        for name in (
            "matrix_clear_fraction",
            "deposit_clear_fraction",
            "region_flag_fraction",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or not 0.0 < value <= 1.0:
                raise ValueError(f"{name} must lie within (0, 1]")
            object.__setattr__(self, name, value)
        if (
            not isinstance(self.region_flag_min_sites, int)
            or isinstance(self.region_flag_min_sites, bool)
            or self.region_flag_min_sites < 1
        ):
            raise ValueError("region_flag_min_sites must be a positive integer")

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


CLASSIFICATION_ORDER = (
    "complete_removal",
    "bottom_residue",
    "wall_residue",
    "deposit_residue",
)
CLASSIFICATION_CODES = {
    name: index for index, name in enumerate(CLASSIFICATION_ORDER)
}
CLASSIFICATION_JA = {
    "complete_removal": "完全除去",
    "bottom_residue": "底残り",
    "wall_residue": "壁残り",
    "deposit_residue": "析出残り",
}
PRIMARY_CLASSIFICATION_ORDER = (
    "complete_removal",
    "bottom_residue",
    "wall_residue",
    "precipitation_residue",
)
PRIMARY_CLASSIFICATION_CODES = {
    name: index for index, name in enumerate(PRIMARY_CLASSIFICATION_ORDER)
}


def _finite_fraction(name: str, value: object) -> float:
    number = float(value)
    if not math.isfinite(number) or not 0.0 <= number <= 1.0:
        raise ValueError(f"{name} must be finite and lie within [0, 1]")
    return number


def _nonnegative_count(name: str, value: object) -> int:
    number = float(value)
    if not math.isfinite(number) or number < 0.0 or not number.is_integer():
        raise ValueError(f"{name} must be a non-negative integer")
    return int(number)


def _first_present(mapping: Mapping[str, Any], names: Iterable[str]) -> Any | None:
    for name in names:
        if name in mapping:
            return mapping[name]
    return None


def _region_values(
    root: Mapping[str, Any], region_name: str
) -> tuple[Any | None, Any | None]:
    direct_fraction = _first_present(
        root,
        (f"{region_name}_remaining_fraction", f"{region_name}_fraction"),
    )
    direct_count = _first_present(
        root,
        (f"{region_name}_remaining_count", f"{region_name}_count"),
    )
    if direct_fraction is not None and direct_count is not None:
        return direct_fraction, direct_count

    region_metrics = root.get("region_metrics")
    if isinstance(region_metrics, Mapping):
        aliases = (region_name, "sidewall") if region_name == "wall" else (region_name,)
        for alias in aliases:
            region = region_metrics.get(alias)
            if isinstance(region, Mapping):
                fraction = _first_present(
                    region, ("remaining_fraction", "remaining_matrix_fraction")
                )
                count = _first_present(
                    region, ("remaining_count", "remaining_matrix_count")
                )
                if fraction is not None and count is not None:
                    return fraction, count

    surface = root.get("surface_residue")
    if isinstance(surface, Mapping):
        aliases = (region_name, "sidewall") if region_name == "wall" else (region_name,)
        for alias in aliases:
            region = surface.get(alias)
            if isinstance(region, Mapping):
                fraction = _first_present(
                    region, ("remaining_matrix_fraction", "remaining_fraction")
                )
                count = _first_present(
                    region, ("remaining_matrix_count", "remaining_count")
                )
                if fraction is not None and count is not None:
                    return fraction, count
    return direct_fraction, direct_count


def classify_residue(
    metrics: Mapping[str, Any],
    *,
    thresholds: ClassificationThresholds = ClassificationThresholds(),
) -> dict[str, object]:
    """Assign one of four exclusive labels while retaining coexistence flags.

    Matrix residue has precedence over attached deposit residue.  For a matrix
    failure, bottom and wall severities are normalized to the common 2% and
    two-site region flag; a tie is deliberately assigned to ``bottom_residue``.
    This keeps the bottom-risk class conservative while ``coexist`` and
    ``mixed`` preserve mechanisms hidden by the exclusive display label.
    """

    if not isinstance(metrics, Mapping):
        raise TypeError("metrics must be a mapping")
    nested = metrics.get("summary")
    root = nested if isinstance(nested, Mapping) else metrics

    matrix_raw = _first_present(
        root, ("matrix_remaining_fraction", "remaining_fraction")
    )
    if matrix_raw is None:
        raise KeyError("matrix_remaining_fraction or remaining_fraction is required")
    matrix_fraction = _finite_fraction("matrix_remaining_fraction", matrix_raw)

    deposit_raw = _first_present(
        root, ("deposit_collector_fraction", "deposit_fraction")
    )
    if deposit_raw is None:
        deposit_count_raw = root.get("deposit_count")
        collector_count_raw = root.get("collector_site_count")
        if deposit_count_raw is None or collector_count_raw is None:
            raise KeyError(
                "deposit_collector_fraction, deposit_fraction, or deposit/collector "
                "counts are required"
            )
        deposit_count = _nonnegative_count("deposit_count", deposit_count_raw)
        collector_count = _nonnegative_count(
            "collector_site_count", collector_count_raw
        )
        deposit_raw = deposit_count / collector_count if collector_count else 0.0
    deposit_fraction = _finite_fraction("deposit_collector_fraction", deposit_raw)

    bottom_fraction_raw, bottom_count_raw = _region_values(root, "bottom")
    wall_fraction_raw, wall_count_raw = _region_values(root, "wall")
    if bottom_fraction_raw is None or bottom_count_raw is None:
        raise KeyError("bottom remaining fraction and count are required")
    if wall_fraction_raw is None or wall_count_raw is None:
        raise KeyError("wall/sidewall remaining fraction and count are required")
    bottom_fraction = _finite_fraction(
        "bottom_remaining_fraction", bottom_fraction_raw
    )
    wall_fraction = _finite_fraction("wall_remaining_fraction", wall_fraction_raw)
    bottom_count = _nonnegative_count("bottom_remaining_count", bottom_count_raw)
    wall_count = _nonnegative_count("wall_remaining_count", wall_count_raw)

    matrix_residue = matrix_fraction > thresholds.matrix_clear_fraction
    deposit_residue = deposit_fraction > thresholds.deposit_clear_fraction
    bottom_flag = (
        bottom_fraction >= thresholds.region_flag_fraction
        and bottom_count >= thresholds.region_flag_min_sites
    )
    wall_flag = (
        wall_fraction >= thresholds.region_flag_fraction
        and wall_count >= thresholds.region_flag_min_sites
    )

    # Spatial support is a gate, not a magnitude: a one-cell speck is excluded
    # by the region flag above, after which severity is the dimensionless
    # within-region fraction.  Mixing an absolute site count into the magnitude
    # made the comparison mesh dependent.
    if thresholds.severity_uses_site_count:
        bottom_severity = min(
            bottom_fraction / thresholds.region_flag_fraction,
            bottom_count / thresholds.region_flag_min_sites,
        )
        wall_severity = min(
            wall_fraction / thresholds.region_flag_fraction,
            wall_count / thresholds.region_flag_min_sites,
        )
    else:
        bottom_severity = (
            bottom_fraction / thresholds.region_flag_fraction
            if bottom_flag
            else 0.0
        )
        wall_severity = (
            wall_fraction / thresholds.region_flag_fraction
            if wall_flag
            else 0.0
        )
    matrix_score = matrix_fraction / thresholds.matrix_clear_fraction
    deposit_score = deposit_fraction / thresholds.deposit_clear_fraction
    score = max(matrix_score, deposit_score, bottom_severity, wall_severity)

    if matrix_residue:
        classification = (
            "bottom_residue"
            if bottom_severity >= wall_severity
            else "wall_residue"
        )
    elif deposit_residue:
        classification = "deposit_residue"
    else:
        classification = "complete_removal"
    primary_class = (
        "precipitation_residue"
        if classification == "deposit_residue"
        else classification
    )

    result = {
        "classification": classification,
        "classification_code": CLASSIFICATION_CODES[classification],
        "classification_ja": CLASSIFICATION_JA[classification],
        "primary_class": primary_class,
        "primary_class_code": PRIMARY_CLASSIFICATION_CODES[primary_class],
        "classification_aliases": (
            ["deposit_residue", "precipitation_residue"]
            if classification == "deposit_residue"
            else [classification]
        ),
        "matrix_residue": matrix_residue,
        "deposit_residue": deposit_residue,
        "bottom_region_flag": bottom_flag,
        "wall_region_flag": wall_flag,
        "coexist": matrix_residue and deposit_residue,
        "mixed": bottom_flag and wall_flag,
        "score": float(score),
        "scores": {
            "matrix": float(matrix_score),
            "deposit": float(deposit_score),
            "bottom_severity": float(bottom_severity),
            "wall_severity": float(wall_severity),
        },
        "metrics": {
            "matrix_remaining_fraction": matrix_fraction,
            "deposit_collector_fraction": deposit_fraction,
            "bottom_remaining_fraction": bottom_fraction,
            "bottom_remaining_count": bottom_count,
            "wall_remaining_fraction": wall_fraction,
            "wall_remaining_count": wall_count,
        },
        "thresholds": thresholds.to_dict(),
        "precedence": (
            "matrix first; for matrix residue bottom severity >= wall severity "
            "maps to bottom, otherwise wall; deposit only after matrix clear"
        ),
    }
    return to_plain_data(result)  # type: ignore[return-value]


def _extract_row_value(row: Mapping[str, Any], name: str) -> float:
    if name in row:
        value = row[name]
    else:
        parameters = row.get("parameters")
        metrics = row.get("metrics")
        if isinstance(parameters, Mapping) and name in parameters:
            value = parameters[name]
        elif isinstance(metrics, Mapping) and name in metrics:
            value = metrics[name]
        else:
            raise KeyError(f"row does not contain {name!r}")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"row value {name!r} must be finite")
    return number


def _rank_matrix(values: np.ndarray) -> np.ndarray:
    return np.column_stack(
        [rankdata(values[:, column], method="average") for column in range(values.shape[1])]
    ).astype(float)


def _partial_correlation_vector(
    predictors: np.ndarray, response: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    ranked_x = _rank_matrix(predictors)
    ranked_y = np.asarray(rankdata(response, method="average"), dtype=float)
    coefficients = np.zeros(ranked_x.shape[1], dtype=float)
    valid = np.zeros(ranked_x.shape[1], dtype=bool)
    for index in range(ranked_x.shape[1]):
        others = np.delete(ranked_x, index, axis=1)
        design = np.column_stack((np.ones(ranked_x.shape[0]), others))
        beta_x, *_ = np.linalg.lstsq(design, ranked_x[:, index], rcond=None)
        beta_y, *_ = np.linalg.lstsq(design, ranked_y, rcond=None)
        residual_x = ranked_x[:, index] - design @ beta_x
        residual_y = ranked_y - design @ beta_y
        norm_x = float(np.linalg.norm(residual_x))
        norm_y = float(np.linalg.norm(residual_y))
        if norm_x <= 1.0e-12 or norm_y <= 1.0e-12:
            coefficients[index] = 0.0
            continue
        value = float(np.dot(residual_x, residual_y) / (norm_x * norm_y))
        if math.isfinite(value):
            coefficients[index] = min(max(value, -1.0), 1.0)
            valid[index] = True
    return coefficients, valid


def compute_prcc(
    rows: Sequence[Mapping[str, Any]],
    parameter_names: Sequence[str],
    metric_names: Sequence[str],
    bootstrap_samples: int,
    seed: int,
    *,
    confidence_level: float = 0.95,
) -> dict[str, object]:
    """Compute PRCCs after rank transformation and linear residualization.

    Each predictor and response is ranked first.  For parameter ``i``, both its
    rank and the response rank are independently regressed on an intercept and
    every other predictor rank; their residual correlation is the PRCC.
    Percentile bootstrap intervals re-rank every resample.  Constant or
    rank-deficient residuals are reported as finite zero coefficients with
    ``valid=False`` so strict JSON never receives NaN or Infinity.
    """

    row_list = list(rows)
    names = tuple(str(name) for name in parameter_names)
    metrics = tuple(str(name) for name in metric_names)
    if not row_list:
        raise ValueError("rows cannot be empty")
    if not names or len(set(names)) != len(names):
        raise ValueError("parameter_names must be non-empty and unique")
    if not metrics or len(set(metrics)) != len(metrics):
        raise ValueError("metric_names must be non-empty and unique")
    if any(not isinstance(row, Mapping) for row in row_list):
        raise TypeError("every row must be a mapping")
    if len(row_list) <= len(names) + 1:
        raise ValueError(
            "PRCC requires more rows than parameter count plus one"
        )
    if (
        not isinstance(bootstrap_samples, int)
        or isinstance(bootstrap_samples, bool)
        or bootstrap_samples < 0
    ):
        raise ValueError("bootstrap_samples must be a non-negative integer")
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    confidence = float(confidence_level)
    if not math.isfinite(confidence) or not 0.0 < confidence < 1.0:
        raise ValueError("confidence_level must lie within (0, 1)")

    predictors = np.asarray(
        [[_extract_row_value(row, name) for name in names] for row in row_list],
        dtype=float,
    )
    rng = np.random.default_rng(seed)
    alpha = 0.5 * (1.0 - confidence)
    metric_payload: dict[str, object] = {}
    for metric_index, metric_name in enumerate(metrics):
        response = np.asarray(
            [_extract_row_value(row, metric_name) for row in row_list], dtype=float
        )
        coefficient, valid = _partial_correlation_vector(predictors, response)
        boot = np.empty((bootstrap_samples, len(names)), dtype=float)
        boot_valid = np.zeros((bootstrap_samples, len(names)), dtype=bool)
        # The single RNG advances in metric order, making the full analysis
        # reproducible while keeping intervals independent across responses.
        for iteration in range(bootstrap_samples):
            sample_indices = rng.integers(0, len(row_list), size=len(row_list))
            values, flags = _partial_correlation_vector(
                predictors[sample_indices], response[sample_indices]
            )
            boot[iteration] = values
            boot_valid[iteration] = flags

        parameter_results: list[dict[str, object]] = []
        by_parameter: dict[str, object] = {}
        for parameter_index, parameter_name in enumerate(names):
            if bootstrap_samples:
                accepted = (
                    boot_valid[:, parameter_index]
                    & np.isfinite(boot[:, parameter_index])
                )
                finite_values = boot[:, parameter_index][accepted]
                valid_bootstrap = int(np.count_nonzero(accepted))
                if finite_values.size:
                    ci_low, ci_high = np.quantile(
                        finite_values, (alpha, 1.0 - alpha)
                    )
                else:  # defensive; _partial_correlation_vector is finite
                    ci_low = ci_high = coefficient[parameter_index]
            else:
                ci_low = ci_high = coefficient[parameter_index]
                valid_bootstrap = 0
            item = {
                "parameter": parameter_name,
                "prcc": float(coefficient[parameter_index]),
                "valid": bool(valid[parameter_index]),
                "ci_low": float(ci_low),
                "ci_high": float(ci_high),
                "bootstrap_valid": valid_bootstrap,
            }
            parameter_results.append(item)
            by_parameter[parameter_name] = dict(item)
        metric_payload[metric_name] = {
            "metric": metric_name,
            "parameter_results": parameter_results,
            "by_parameter": by_parameter,
            "absolute_prcc_order": [
                names[index]
                for index in sorted(
                    range(len(names)),
                    key=lambda item: (-abs(float(coefficient[item])), item),
                )
            ],
            "metric_index": metric_index,
        }

    payload = {
        "method": "partial rank correlation coefficient",
        "residualization": (
            "rank each variable, then OLS-residualize predictor and response "
            "against all other ranked predictors plus an intercept"
        ),
        "sample_count": len(row_list),
        "parameter_names": list(names),
        "metric_names": list(metrics),
        "bootstrap_samples": bootstrap_samples,
        "confidence_level": confidence,
        "seed": seed,
        "metrics": metric_payload,
    }
    return to_plain_data(payload)  # type: ignore[return-value]


def compute_one_vs_rest_prcc(
    rows: Sequence[Mapping[str, Any]],
    parameter_names: Sequence[str],
    *,
    class_name: str = "classification",
    classes: Sequence[object] | None = None,
    bootstrap_samples: int = 0,
    seed: int = 0,
    confidence_level: float = 0.95,
) -> dict[str, object]:
    """Optional one-vs-rest PRCC diagnostic for categorical phase labels."""

    row_list = list(rows)
    if not row_list:
        raise ValueError("rows cannot be empty")
    observed: list[object] = []
    for row in row_list:
        value = row.get(class_name)
        if value not in observed:
            observed.append(value)
    selected = list(observed if classes is None else classes)
    if not selected:
        raise ValueError("at least one class is required")

    analyses: list[dict[str, object]] = []
    for class_index, class_value in enumerate(selected):
        response_name = "__one_vs_rest_response__"
        augmented = [
            {**dict(row), response_name: float(row.get(class_name) == class_value)}
            for row in row_list
        ]
        analysis = compute_prcc(
            augmented,
            parameter_names,
            (response_name,),
            bootstrap_samples,
            seed + 1_000_003 * class_index,
            confidence_level=confidence_level,
        )
        analyses.append(
            {
                "class": to_plain_data(class_value),
                "positive_count": sum(
                    row.get(class_name) == class_value for row in row_list
                ),
                "analysis": analysis,
            }
        )
    return to_plain_data(
        {
            "method": "one-vs-rest PRCC auxiliary diagnostic",
            "class_column": class_name,
            "classes": analyses,
        }
    )  # type: ignore[return-value]


def to_plain_data(value: Any) -> Any:
    """Recursively convert supported values to strict-JSON-compatible data.

    Non-finite floating-point values are rejected instead of silently emitted
    as non-standard ``NaN`` or ``Infinity`` tokens.
    """

    if is_dataclass(value) and not isinstance(value, type):
        return to_plain_data(asdict(value))
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (float, np.floating)):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("non-finite floating-point value is not strict JSON")
        return number
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.ndarray):
        return to_plain_data(value.tolist())
    if isinstance(value, Mapping):
        return {str(key): to_plain_data(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_plain_data(item) for item in value]
    raise TypeError(f"unsupported value for plain JSON conversion: {type(value)!r}")


def strict_json_dumps(value: Any, **kwargs: Any) -> str:
    """Serialize after plain conversion with ``allow_nan=False`` enforced."""

    options = dict(kwargs)
    options.pop("allow_nan", None)
    options.setdefault("ensure_ascii", False)
    return json.dumps(to_plain_data(value), allow_nan=False, **options)


__all__ = [
    "BOUNDS_SETS",
    "CLASSIFICATION_CODES",
    "CLASSIFICATION_JA",
    "CLASSIFICATION_ORDER",
    "ClassificationThresholds",
    "ParameterDefinition",
    "PRIMARY_CLASSIFICATION_CODES",
    "PRIMARY_CLASSIFICATION_ORDER",
    "SCREENING_NOTICE",
    "TRANSFORMS",
    "classify_residue",
    "compute_one_vs_rest_prcc",
    "compute_prcc",
    "default_parameter_definitions",
    "generate_sobol_design",
    "parameter_grid_values",
    "strict_json_dumps",
    "to_plain_data",
]

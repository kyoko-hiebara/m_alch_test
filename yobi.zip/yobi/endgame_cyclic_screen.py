"""End-game cyclic screen for the simplified system: Si trench + low-k fill.

The system this screen serves has exactly two materials: a silicon trench
(fixed device geometry) and the low-k film (SiN / SiOCN / SiCN family)
that filled it.  There is no same-material protected surface -- the
spacer-protection framing of the earlier maximin screens does not apply
here -- so the selectivity deadlock those screens found is absent, and a
cyclic oxidise-plus-dHF end-game is chemically viable.  What gates it
instead is the silicon itself: every oxidising reset consumes
``0.4407 x t_ox`` of every bare silicon surface it wets (the
reset-silicon screen's counter), and the trench walls above the residual
bottom pad are bare silicon for the entire end-game.

Per cycle and per candidate film the removal stays on the Kawarazaki
clock: ``dhf_only + epsilon x (ozone increment)`` with ``epsilon`` the
unmeasured wet-reset efficiency.  An end-game cycle is one oxidising
reset followed by one 30 s dHF pulse; the first pulse is also preceded
by a reset because the end-game starts on the decayed, carbon-enriched
surface that motivated cycling in the first place, so ``N`` cycles carry
``N`` oxidation events and end HF-last.  Silicon accounting follows
exposure: walls pay ``(N + margin) x delta``, while the silicon under
the pad is shielded until clear and pays only the ``margin x delta`` of
the cycles run past clear -- and that freshly cleared bottom is the
surface epitaxy nucleates on, so margin discipline is priced separately.

A no-reset control arm (plain 30 s dHF pulses on the same clock) is
reported beside every cyclic case.  It spends zero silicon; its cost is
pulses -- unbounded for the films whose dHF-only bars sit at the raster
floor, and 67x the cyclic count for SiCN C:22%.  Cycling is therefore
clearly necessary only where dHF alone is floor-bound on this clock, or
where the measured-blanket decay (a different film on a different clock,
cross-clock caveat declared) says plain HF stalls.

**Boundaries.**  Everything inherits the Kawarazaki provisional
assumptions (raster 0.05 nm bars, 0.15% dHF, linear 30 s reading,
linearity carried past the reported 3-cycle window) and the
reset-silicon assumptions (t_ox band 0.5--1.5 nm unmeasured, full
regrowth, zero direct silicon etch).  ``epsilon`` is swept, not
asserted.  The residual pad thickness is swept because the project's
rank-1/rank-2 degeneracy leaves it unmeasured.  The primary removal of
the fill bulk and overburden belongs to the primary-HF screens on their
own clocks and is not mixed in here.  Rinse discipline against AFS
re-deposition and SC1/SPM side effects are out of scope.  Nothing here
is a process recipe.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from reset_silicon_cost_screen import (
    ResetOxidationAssumptions,
    per_reset_recession_nm,
)
from spacer_pullback_screen import cycles_to_clear_residue


SCHEMA_VERSION = "endgame-cyclic-screen/v1"
MODEL_NOTICE = (
    "End-game screen for a silicon trench plus low-k fill only -- no "
    "same-material protected surface, so the spacer-maximin deadlock "
    "does not apply. Cycles to clear a residual bottom pad stay on the "
    "Kawarazaki clock (dhf_only + epsilon x ozone increment, 30 s "
    "pulses); silicon pays 0.4407 x t_ox per reset on every bare "
    "surface, walls for all N + margin cycles and the cleared bottom "
    "for margin cycles only. A zero-silicon no-reset dHF arm is the "
    "control. Not a process recipe."
)

MATERIAL_KEYS = (
    "kawarazaki_sicn_c22",
    "kawarazaki_sicn_c40",
    "kawarazaki_siocn_c5",
    "kawarazaki_sin_reference",
)
CARBON_MATERIAL_KEYS = (
    "kawarazaki_sicn_c22",
    "kawarazaki_sicn_c40",
    "kawarazaki_siocn_c5",
)

DEFAULT_PAD_THICKNESSES_NM = (0.5, 1.0, 2.0, 3.0, 5.0)
DEFAULT_WET_RESET_EFFICIENCIES = (0.3, 1.0)
DEFAULT_OXIDE_THICKNESSES_NM = (0.5, 1.0, 1.5)
DEFAULT_SILICON_BUDGETS_NM = (0.5, 1.0, 2.0)
DEFAULT_MARGIN_CYCLES = (0, 1, 2)


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def _margin(value: int) -> int:
    margin = int(value)
    if margin < 0:
        raise ValueError("margin_cycles must be non-negative")
    return margin


def clearing_case(
    *,
    material_key: str,
    pad_thickness_nm: float,
    wet_reset_efficiency: float,
) -> dict[str, Any]:
    """Cyclic and no-reset pulse counts for one film and one pad.

    Both arms live on the Kawarazaki clock.  The no-reset arm is plain
    30 s dHF pulses (epsilon = 0); its pulse count is unbounded when
    the film's dHF-only bar sits at the raster floor.  ``reset_leverage``
    is the pulse-count ratio the reset buys.
    """

    cyclic = cycles_to_clear_residue(
        material_key,
        thickness_nm=pad_thickness_nm,
        wet_reset_efficiency=wet_reset_efficiency,
    )
    no_reset = cycles_to_clear_residue(
        material_key,
        thickness_nm=pad_thickness_nm,
        wet_reset_efficiency=0.0,
    )
    cycles = cyclic["cycles_central"]
    hf_pulses = no_reset["cycles_central"]
    return {
        "material": material_key,
        "pad_thickness_nm": float(pad_thickness_nm),
        "wet_reset_efficiency": float(wet_reset_efficiency),
        "per_cycle_removal_nm": cyclic["per_cycle_removal_nm"],
        "cycles_central": cycles,
        "cycles_worst_raster": cyclic["cycles_worst_raster"],
        "cyclic_unbounded_within_resolution": (
            cyclic["worst_case_unbounded_within_resolution"]
        ),
        "no_reset_pulses_central": hf_pulses,
        "no_reset_unbounded_within_resolution": (
            no_reset["worst_case_unbounded_within_resolution"]
        ),
        "reset_leverage": (
            None
            if cycles is None or hf_pulses is None
            else hf_pulses / cycles
        ),
    }


def silicon_cost(
    *,
    cycles: int,
    margin_cycles: int,
    oxide_thickness_nm: float,
) -> dict[str, float]:
    """Wall and cleared-bottom recession for one cyclic end-game.

    Walls above the pad are bare silicon for the whole end-game and pay
    every oxidation; the silicon under the pad is shielded until clear
    and pays only the margin cycles -- and it is the surface epitaxy
    nucleates on.
    """

    count = int(cycles)
    if count < 1:
        raise ValueError("cycles must be a positive integer")
    margin = _margin(margin_cycles)
    delta = per_reset_recession_nm(
        ResetOxidationAssumptions(oxide_thickness_nm=oxide_thickness_nm)
    )
    return {
        "per_reset_recession_nm": delta,
        "wall_recession_nm": (count + margin) * delta,
        "cleared_bottom_recession_nm": margin * delta,
    }


def feasibility_row(
    *,
    pad_thickness_nm: float,
    wet_reset_efficiency: float,
    oxide_thickness_nm: float,
    silicon_budget_nm: float,
    margin_cycles: int,
    material_keys: Sequence[str] = MATERIAL_KEYS,
) -> dict[str, Any]:
    """Per-material feasibility of the cyclic end-game at one condition.

    The gate is wall recession within the silicon budget; the cleared
    bottom is reported beside it because margin cycles hit the epitaxy
    surface directly.  Films whose cycle count is unbounded are
    infeasible by construction.
    """

    budget = _finite_positive("silicon_budget_nm", silicon_budget_nm)
    materials: list[dict[str, Any]] = []
    for key in material_keys:
        case = clearing_case(
            material_key=key,
            pad_thickness_nm=pad_thickness_nm,
            wet_reset_efficiency=wet_reset_efficiency,
        )
        cycles = case["cycles_central"]
        if cycles is None:
            materials.append(
                {
                    "material": key,
                    "cycles_central": None,
                    "feasible": False,
                    "infeasible_reason": "cycle count unbounded",
                }
            )
            continue
        cost = silicon_cost(
            cycles=cycles,
            margin_cycles=margin_cycles,
            oxide_thickness_nm=oxide_thickness_nm,
        )
        materials.append(
            {
                "material": key,
                "cycles_central": cycles,
                "wall_recession_nm": cost["wall_recession_nm"],
                "cleared_bottom_recession_nm": (
                    cost["cleared_bottom_recession_nm"]
                ),
                "feasible": cost["wall_recession_nm"] <= budget + 1e-12,
            }
        )
    feasible_names = [
        row["material"] for row in materials if row["feasible"]
    ]
    carbon_rows = [
        row for row in materials if row["material"] in CARBON_MATERIAL_KEYS
    ]
    worst_carbon = max(
        (row for row in carbon_rows if row["cycles_central"] is not None),
        key=lambda row: row["wall_recession_nm"],
        default=None,
    )
    return {
        "pad_thickness_nm": float(pad_thickness_nm),
        "wet_reset_efficiency": float(wet_reset_efficiency),
        "oxide_thickness_nm": float(oxide_thickness_nm),
        "silicon_budget_nm": budget,
        "margin_cycles": int(margin_cycles),
        "materials": materials,
        "feasible_materials": feasible_names,
        "all_materials_feasible": all(
            row["feasible"] for row in materials
        ),
        "carbon_materials_feasible": all(
            row["feasible"] for row in carbon_rows
        ),
        "worst_carbon_material": (
            None
            if worst_carbon is None
            else {
                "material": worst_carbon["material"],
                "wall_recession_nm": worst_carbon["wall_recession_nm"],
            }
        ),
    }


def build_report(
    *,
    pad_thicknesses_nm: Sequence[float] = DEFAULT_PAD_THICKNESSES_NM,
    wet_reset_efficiencies: Sequence[float] = (
        DEFAULT_WET_RESET_EFFICIENCIES
    ),
    oxide_thicknesses_nm: Sequence[float] = DEFAULT_OXIDE_THICKNESSES_NM,
    silicon_budgets_nm: Sequence[float] = DEFAULT_SILICON_BUDGETS_NM,
    margin_cycles: Sequence[int] = DEFAULT_MARGIN_CYCLES,
) -> dict[str, Any]:
    """Clearing, silicon cost, and feasibility for the two-material system."""

    for thickness in pad_thicknesses_nm:
        _finite_positive("pad_thickness_nm", thickness)
    for thickness in oxide_thicknesses_nm:
        _finite_positive("oxide_thickness_nm", thickness)
    for value in margin_cycles:
        _margin(value)

    clearing_rows = [
        clearing_case(
            material_key=key,
            pad_thickness_nm=thickness,
            wet_reset_efficiency=efficiency,
        )
        for efficiency in wet_reset_efficiencies
        for thickness in pad_thicknesses_nm
        for key in MATERIAL_KEYS
    ]

    feasibility_rows = [
        feasibility_row(
            pad_thickness_nm=thickness,
            wet_reset_efficiency=efficiency,
            oxide_thickness_nm=oxide,
            silicon_budget_nm=budget,
            margin_cycles=margin,
        )
        for efficiency in wet_reset_efficiencies
        for thickness in pad_thicknesses_nm
        for oxide in oxide_thicknesses_nm
        for budget in silicon_budgets_nm
        for margin in margin_cycles
    ]

    carbon_feasible_conditions = [
        {
            key: row[key]
            for key in (
                "wet_reset_efficiency",
                "pad_thickness_nm",
                "oxide_thickness_nm",
                "silicon_budget_nm",
                "margin_cycles",
            )
        }
        for row in feasibility_rows
        if row["carbon_materials_feasible"]
    ]

    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "system_note": (
            "two materials only: a fixed silicon trench and the low-k "
            "fill; the spacer-protection framing of the maximin screens "
            "does not apply to this system, and its selectivity deadlock "
            "is absent. Fill bulk and overburden removal belong to the "
            "primary-HF screens on their own clocks."
        ),
        "cycle_structure_note": (
            "one end-game cycle = oxidising reset + 30 s dHF pulse; the "
            "first pulse is also preceded by a reset because the "
            "end-game starts on the decayed, carbon-enriched surface, "
            "so N cycles carry N oxidation events and end HF-last"
        ),
        "material_candidates": list(MATERIAL_KEYS),
        "carbon_material_candidates": list(CARBON_MATERIAL_KEYS),
        "assumptions": {
            "wet_reset_efficiencies": [
                float(value) for value in wet_reset_efficiencies
            ],
            "oxide_thickness_band_nm": [
                float(value) for value in oxide_thicknesses_nm
            ],
            "silicon_budgets_nm": [
                float(value) for value in silicon_budgets_nm
            ],
            "margin_cycles": [int(value) for value in margin_cycles],
            "pad_thickness_note": (
                "swept because the rank-1/rank-2 degeneracy leaves the "
                "pre-HF bottom thickness unmeasured"
            ),
            "clock_note": (
                "Kawarazaki clock throughout; the measured-blanket "
                "decay lives on a different film and clock and enters "
                "only as the qualitative reason plain dHF may stall"
            ),
        },
        "clearing": clearing_rows,
        "feasibility": feasibility_rows,
        "carbon_feasible_conditions": carbon_feasible_conditions,
        "reading_notes": {
            "no_reset_arm": (
                "plain dHF spends zero silicon; cycling is clearly "
                "necessary only where dHF alone is floor-bound on this "
                "clock (SiCN C:22%, SiN) or where the measured decay "
                "says real films stall"
            ),
            "margin_note": (
                "each margin cycle costs the freshly cleared bottom -- "
                "the epitaxy surface -- one full reset recession; "
                "margin discipline can outweigh material choice"
            ),
        },
    }


__all__ = [
    "CARBON_MATERIAL_KEYS",
    "DEFAULT_MARGIN_CYCLES",
    "DEFAULT_OXIDE_THICKNESSES_NM",
    "DEFAULT_PAD_THICKNESSES_NM",
    "DEFAULT_SILICON_BUDGETS_NM",
    "DEFAULT_WET_RESET_EFFICIENCIES",
    "MATERIAL_KEYS",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "build_report",
    "clearing_case",
    "feasibility_row",
    "silicon_cost",
]

#!/usr/bin/env python3
"""CLI for static depth/wall film-quality residue hypotheses."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

from literature_parameters import LITERATURE_ETCH_PRESETS
from literature_sweep import nominal_preset_names
from nonuniform_residue_sweep import (
    NonuniformSweepConfig,
    SPATIAL_HYPOTHESIS_SCENARIOS,
    run_nonuniform_sweep,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Compare static depth-, sidewall-, and floor-dependent GAP-FILL "
            "etchability at equal global removal. Spatial factors are "
            "hypotheses, not fitted wet-process parameters."
        )
    )
    parser.add_argument(
        "--geometry",
        choices=tuple(GEOMETRY_PRESETS),
        action="append",
        help="repeat to select geometries (default: both straight-wall standards)",
    )
    parser.add_argument(
        "--preset",
        choices=tuple(LITERATURE_ETCH_PRESETS),
        action="append",
        help="repeat to select blanket-WER presets (default: nominal SiN/SiOCN)",
    )
    parser.add_argument(
        "--scenario",
        choices=tuple(SPATIAL_HYPOTHESIS_SCENARIOS),
        action="append",
        help="repeat to select spatial hypotheses (default: all)",
    )
    parser.add_argument(
        "--target-remaining",
        type=float,
        action="append",
        help=(
            "global solid fraction at which morphology is saved; repeatable "
            "(default: 0.50, 0.10, 0.05)"
        ),
    )
    parser.add_argument("--grid-spacing-nm", type=float, default=0.5)
    parser.add_argument("--reservoir-height-nm", type=float, default=10.0)
    parser.add_argument("--sidewall-band-nm", type=float, default=1.0)
    parser.add_argument("--bottom-band-nm", type=float, default=2.0)
    parser.add_argument(
        "--maximum-fractional-front-change",
        type=float,
        default=0.50,
        help="loose per-step interface-cell removal limit (default: 0.50)",
    )
    parser.add_argument(
        "--maximum-uniform-clear-multiplier",
        type=float,
        default=12.0,
        help="stop time divided by blanket-rate depth/velocity time",
    )
    parser.add_argument(
        "--solution-temperature-k",
        type=float,
        default=298.15,
        help="independent HF solution bulk temperature [K]",
    )
    parser.add_argument(
        "--substrate-temperature-k",
        type=float,
        default=298.15,
        help="independent Si substrate backside temperature [K]",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent case processes; 0 selects up to 4 automatically",
    )
    parser.add_argument(
        "--list-scenarios",
        action="store_true",
        help="print spatial hypothesis definitions and exit",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="ordinary JSON output path; no hash-based storage is used",
    )
    return parser


def _scenario_listing() -> dict[str, object]:
    return {
        key: scenario.to_dict()
        for key, scenario in SPATIAL_HYPOTHESIS_SCENARIOS.items()
    }


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    if args.list_scenarios:
        payload: dict[str, object] = {"scenarios": _scenario_listing()}
    else:
        geometries = tuple(dict.fromkeys(args.geometry or DEFAULT_GEOMETRY_NAMES))
        presets = tuple(dict.fromkeys(args.preset or nominal_preset_names()))
        scenarios = tuple(
            dict.fromkeys(args.scenario or SPATIAL_HYPOTHESIS_SCENARIOS)
        )
        targets = tuple(
            dict.fromkeys(args.target_remaining or (0.50, 0.10, 0.05))
        )
        case_count = len(geometries) * len(presets) * len(scenarios)
        if args.workers < 0:
            raise ValueError("workers must be zero or a positive integer")
        workers = (
            min(4, os.cpu_count() or 1, case_count)
            if args.workers == 0
            else min(args.workers, case_count)
        )
        config = NonuniformSweepConfig(
            geometries=geometries,
            presets=presets,
            scenarios=scenarios,
            target_remaining_fractions=targets,
            grid_spacing_nm=args.grid_spacing_nm,
            reservoir_height_nm=args.reservoir_height_nm,
            sidewall_diagnostic_band_nm=args.sidewall_band_nm,
            bottom_diagnostic_band_nm=args.bottom_band_nm,
            maximum_fractional_front_change=(
                args.maximum_fractional_front_change
            ),
            maximum_uniform_clear_time_multiplier=(
                args.maximum_uniform_clear_multiplier
            ),
            solution_bulk_temperature_K=args.solution_temperature_k,
            substrate_backside_temperature_K=args.substrate_temperature_k,
            parallel_workers=workers,
        )
        payload = run_nonuniform_sweep(config)
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    return payload


if __name__ == "__main__":
    main()

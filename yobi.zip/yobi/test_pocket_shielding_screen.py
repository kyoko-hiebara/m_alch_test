from __future__ import annotations

import math
import unittest

from ozone_penetration_screen import concentration_fraction_at_depth
from pocket_shielding_screen import (
    build_report,
    capillary_entry,
    fully_exposed_verdicts,
    required_surface_transfer_nm_s,
    surface_transfer_basis,
    transport_shielding,
)


C22 = "kawarazaki_sicn_c22"
SIN = "kawarazaki_sin_reference"


class SurfaceTransferBasisTests(unittest.TestCase):
    def test_cyclic_allocation_scales_the_preset_velocity(self) -> None:
        """C22: the whole 2.47 nm cycle charged to the 30 s dHF pulse."""

        basis = surface_transfer_basis(C22)
        self.assertAlmostEqual(
            basis["cyclic_allocation_factor"], 2.47 / 0.03, places=9
        )
        self.assertAlmostEqual(
            basis["cyclic_nm_s"],
            basis["dhf_only_nm_s"] * basis["cyclic_allocation_factor"],
            places=9,
        )

    def test_sin_reference_gains_nothing_from_the_cycle(self) -> None:
        basis = surface_transfer_basis(SIN)
        self.assertAlmostEqual(
            basis["cyclic_allocation_factor"], 1.0, places=12
        )

    def test_unknown_film_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            surface_transfer_basis("phantom")


class TransportShieldingTests(unittest.TestCase):
    def test_sigma_reuses_the_penetration_screen_sech(self) -> None:
        """Same formula, same code path as the ozone screen."""

        row = transport_shielding(
            throat_width_nm=2.0,
            pocket_depth_nm=10.0,
            surface_transfer_nm_s=100.0,
        )
        self.assertAlmostEqual(
            row["sigma_wall_sink"],
            concentration_fraction_at_depth(row["thiele_modulus"], 1.0),
            places=12,
        )

    def test_no_wet_film_shields_any_swept_pocket(self) -> None:
        """The headline: 1 - sigma < 1e-3 across the entire sweep."""

        for key in (C22, SIN):
            basis = surface_transfer_basis(key)
            for width in (1.0, 2.0, 3.0, 5.0):
                for depth in (2.0, 5.0, 10.0, 20.0):
                    row = transport_shielding(
                        throat_width_nm=width,
                        pocket_depth_nm=depth,
                        surface_transfer_nm_s=basis["cyclic_nm_s"],
                    )
                    self.assertGreater(
                        row["sigma_wall_sink"], 0.999, (key, width, depth)
                    )
                    self.assertGreater(
                        row["sigma_end_face"], 0.999, (key, width, depth)
                    )

    def test_deeper_and_narrower_pockets_shield_more(self) -> None:
        shallow = transport_shielding(
            throat_width_nm=2.0,
            pocket_depth_nm=5.0,
            surface_transfer_nm_s=1.0e6,
        )
        deep = transport_shielding(
            throat_width_nm=1.0,
            pocket_depth_nm=20.0,
            surface_transfer_nm_s=1.0e6,
        )
        self.assertLess(deep["sigma_wall_sink"], shallow["sigma_wall_sink"])

    def test_thousandfold_margin_still_fails_to_shield(self) -> None:
        """Even 1000x the strongest chemistry leaves sigma ~ 0.94."""

        basis = surface_transfer_basis(C22)
        row = transport_shielding(
            throat_width_nm=1.0,
            pocket_depth_nm=20.0,
            surface_transfer_nm_s=basis["cyclic_nm_s"] * 1000.0,
        )
        self.assertGreater(row["sigma_wall_sink"], 0.9)

    def test_invalid_dimensions_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            transport_shielding(
                throat_width_nm=0.0,
                pocket_depth_nm=10.0,
                surface_transfer_nm_s=1.0,
            )


class RequiredChemistryTests(unittest.TestCase):
    def test_inversion_round_trips_through_the_forward_model(self) -> None:
        for sigma in (0.3, 0.1):
            required = required_surface_transfer_nm_s(
                throat_width_nm=2.0,
                pocket_depth_nm=10.0,
                sigma_target=sigma,
            )
            row = transport_shielding(
                throat_width_nm=2.0,
                pocket_depth_nm=10.0,
                surface_transfer_nm_s=required,
            )
            self.assertAlmostEqual(row["sigma_wall_sink"], sigma, places=9)

    def test_the_easiest_corner_still_needs_10000x_chemistry(self) -> None:
        """Shieldability and usability exclude each other."""

        basis = surface_transfer_basis(C22)
        required = required_surface_transfer_nm_s(
            throat_width_nm=1.0,
            pocket_depth_nm=20.0,
            sigma_target=0.3,
        )
        self.assertGreater(required / basis["cyclic_nm_s"], 1.0e4)

    def test_sigma_target_bounds_are_enforced(self) -> None:
        for bad in (0.0, 1.0, -0.2, 1.5):
            with self.assertRaises(ValueError):
                required_surface_transfer_nm_s(
                    throat_width_nm=1.0,
                    pocket_depth_nm=10.0,
                    sigma_target=bad,
                )


class CapillaryExclusionTests(unittest.TestCase):
    def test_hydrophilic_pockets_flood_at_nm_widths(self) -> None:
        """Below 90 deg, MPa-scale entry pressure leaves <5% dry."""

        for angle in (0.0, 40.0, 70.0, 80.0, 85.0):
            entry = capillary_entry(
                throat_width_nm=5.0, contact_angle_deg=angle
            )
            self.assertTrue(entry["liquid_enters"], angle)
            self.assertLess(entry["dry_residual_fraction"], 0.05, angle)

    def test_the_knife_edge_sits_exactly_at_ninety_degrees(self) -> None:
        at_edge = capillary_entry(
            throat_width_nm=2.0, contact_angle_deg=90.0
        )
        beyond = capillary_entry(
            throat_width_nm=2.0, contact_angle_deg=95.0
        )
        self.assertFalse(at_edge["liquid_enters"])
        self.assertEqual(at_edge["dry_residual_fraction"], 1.0)
        self.assertFalse(beyond["liquid_enters"])
        self.assertLess(beyond["entry_pressure_MPa"], 0.0)

    def test_entry_pressure_magnitude_is_tens_of_mpa(self) -> None:
        entry = capillary_entry(
            throat_width_nm=2.0, contact_angle_deg=80.0
        )
        self.assertGreater(entry["entry_pressure_MPa"], 10.0)
        self.assertLess(entry["dry_residual_fraction"], 0.01)

    def test_invalid_angle_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            capillary_entry(
                throat_width_nm=2.0, contact_angle_deg=181.0
            )


class FullyExposedVerdictTests(unittest.TestCase):
    def test_only_fast_carbon_residue_on_sin_survives_everywhere(
        self,
    ) -> None:
        """The matrix collapses to a single robust cell at sigma = 1."""

        verdicts = fully_exposed_verdicts()
        self.assertEqual(
            verdicts["pairs_surviving_every_condition"],
            [{"residue": C22, "spacer": SIN}],
        )

    def test_every_condition_keeps_at_least_one_survivor(self) -> None:
        """Wet cyclic is never hopeless -- if the materials cooperate."""

        verdicts = fully_exposed_verdicts()
        for condition in verdicts["conditions"]:
            self.assertTrue(
                condition["surviving_pairs"],
                (
                    condition["wet_reset_efficiency"],
                    condition["residue_thickness_nm"],
                    condition["spacer_budget_nm"],
                ),
            )

    def test_no_condition_is_blind_recommendable(self) -> None:
        verdicts = fully_exposed_verdicts()
        for condition in verdicts["conditions"]:
            self.assertFalse(
                condition["verdict"]["blind_recommendable"]
            )


class ReportTests(unittest.TestCase):
    def test_report_pins_sigma_at_one(self) -> None:
        report = build_report()
        floor = report["shielding_floor"]
        self.assertGreater(floor["minimum_sigma_wall_sink"], 0.999)
        self.assertGreater(
            floor["margin_case"]["sigma_wall_sink"], 0.9
        )

    def test_report_quantifies_the_incompatibility(self) -> None:
        report = build_report()
        easiest = report["required_chemistry_inversion"]["easiest_case"]
        self.assertGreater(easiest["ratio_over_strongest_cyclic"], 1.0e4)
        self.assertGreater(
            easiest["implied_blanket_rate_nm_min"], 1.0e5
        )

    def test_report_declares_the_reset_defeats_exclusion(self) -> None:
        report = build_report()
        capillary = report["capillary_exclusion"]
        self.assertIn(
            "re-hydroxylates", capillary["reset_defeats_exclusion_note"]
        )
        self.assertIn("90 deg", capillary["knife_edge_note"])

    def test_report_carries_the_fixed_geometry_note(self) -> None:
        report = build_report()
        self.assertIn("not propose", report["pocket_sweep_note"])

    def test_strongest_basis_is_the_c22_cyclic_allocation(self) -> None:
        report = build_report()
        self.assertEqual(report["strongest_basis"]["film"], C22)

    def test_math_of_the_easiest_corner(self) -> None:
        """phi = arccosh(1/0.3) at the narrowest, deepest pocket."""

        report = build_report()
        easiest = report["required_chemistry_inversion"]["easiest_case"]
        self.assertEqual(easiest["sigma_target"], 0.3)
        self.assertEqual(easiest["throat_width_nm"], 1.0)
        self.assertEqual(easiest["pocket_depth_nm"], 20.0)
        phi = math.acosh(1.0 / 0.3)
        expected = phi * phi * 1.0 * 1.68e9 / (2.0 * 20.0 * 20.0)
        self.assertAlmostEqual(
            easiest["required_surface_transfer_nm_s"],
            expected,
            delta=expected * 1e-9,
        )


if __name__ == "__main__":
    unittest.main()

"""Literature-anchored, multi-arm screening of sequential WET processes.

The primary HF clock is anchored to the reported blanket-film WER through
``clear_time = trench_depth / blanket_WER``.  The mean-field reference
frequency is ``blanket_WER / trench_depth`` so its *initial* equivalent depth
rate agrees with the blanket value.  The represented inventory is first order,
so this model is not a constant-velocity moving front and is not a replacement
for the 1-D or 2-D continuum solvers.

All second-WET, oxidation, product, passivation, and rinse coefficients are
explicit screening assumptions.  They are deliberately kept separate from the
literature-backed primary time axis and must not be interpreted as a process
recipe.  Solution-bulk and substrate-backside temperatures are independent;
the local interface temperature is obtained from the thermal-resistance model.
"""

from __future__ import annotations

import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Mapping, Sequence

from etch_process import ThermalBoundaryConditions
from literature_parameters import (
    LITERATURE_ETCH_PRESETS,
    SOURCES,
    LiteratureEtchPreset,
    get_literature_preset,
    silicon_thermal_conductivity_W_mK,
)
from literature_sweep import nominal_preset_names
from surface_chemistry import (
    LocalInterfaceConditions,
    MeanFieldKineticParameters,
    MeanFieldSurfaceChemistry,
    MeanFieldSurfaceState,
    ReactionMode,
)
from thermal_model import NM_TO_M, ThermalResistanceModel, ThermalResistanceParameters
from trench_geometry import (
    DEFAULT_GEOMETRY_NAMES,
    GEOMETRY_PRESETS,
    TaperedTrench2D,
    get_geometry_preset,
)
from wet_sequence import (
    SolverAdvance,
    StepStateSemantics,
    WetProcessState,
    WetSequenceRunner,
    WetStep,
    get_mechanism_preset,
)


WET_SEQUENCE_SWEEP_NOTICE = (
    "Screening model only; not a wet-process recipe. The primary HF timescale "
    "uses film-specific blanket WER. Second-WET, oxidation, product, "
    "passivation, and rinse coefficients are uncalibrated assumptions."
)


@dataclass(frozen=True)
class WetSequenceArm:
    key: str
    label: str
    step_keys: tuple[str, ...]
    purpose: str
    comparison_note: str

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["step_keys"] = list(self.step_keys)
        return result


WET_SEQUENCE_ARMS: Mapping[str, WetSequenceArm] = MappingProxyType(
    {
        arm.key: arm
        for arm in (
            WetSequenceArm(
                key="hf_only",
                label="HF only",
                step_keys=("primary_hf",),
                purpose="Primary-HF endpoint before any rinse.",
                comparison_note="Reference for interfacial product/passivation coverage.",
            ),
            WetSequenceArm(
                key="hf_rinse",
                label="HF -> rinse",
                step_keys=("primary_hf", "rinse"),
                purpose="Quantify rinse cleaning without additional solid removal.",
                comparison_note="Compared with hf_only at the same primary HF exposure.",
            ),
            WetSequenceArm(
                key="hf_rinse_second_wet",
                label="HF -> rinse -> second WET",
                step_keys=("primary_hf", "rinse", "second_wet"),
                purpose="Screen direct removal of the unconverted residual material.",
                comparison_note=(
                    "Second-WET exposure is duration-matched to secondary_hf in "
                    "hf_rinse_hf_control."
                ),
            ),
            WetSequenceArm(
                key="hf_rinse_hf_control",
                label="HF -> rinse -> HF control",
                step_keys=("primary_hf", "rinse", "secondary_hf"),
                purpose="Matched-duration repeated-HF control for the second WET.",
                comparison_note="Uses the same HF model as the primary step.",
            ),
            WetSequenceArm(
                key="hf_rinse_oxidation_rinse_fluoride",
                label="HF -> rinse -> oxidation -> rinse -> fluoride",
                step_keys=(
                    "primary_hf",
                    "rinse",
                    "oxidation",
                    "post_oxidation_rinse",
                    "fluoride",
                ),
                purpose="Test conversion of residual material followed by selective removal.",
                comparison_note=(
                    "Fluoride exposure is matched to the no-oxidation negative control; "
                    "total sequence time is not matched."
                ),
            ),
            WetSequenceArm(
                key="hf_rinse_fluoride_without_oxidation",
                label="HF -> rinse -> fluoride without oxidation",
                step_keys=("primary_hf", "rinse", "fluoride"),
                purpose="Negative control for the converted-inventory removal rule.",
                comparison_note=(
                    "Same fluoride duration as the oxidation arm, but no conversion step."
                ),
            ),
        )
    }
)


@dataclass(frozen=True)
class WetSequenceSweepConfig:
    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    presets: tuple[str, ...] = nominal_preset_names()
    arms: tuple[str, ...] = tuple(WET_SEQUENCE_ARMS)
    primary_hf_clear_time_fraction: float = 0.80
    rinse_duration_s: float = 30.0
    second_wet_clear_time_fraction: float = 0.25
    oxidation_clear_time_fraction: float = 0.25
    fluoride_clear_time_fraction: float = 0.25
    solution_bulk_temperature_K: float = 298.15
    substrate_backside_temperature_K: float = 298.15
    integration_chunks_per_reactive_step: int = 12
    integration_chunks_per_rinse: int = 4
    parallel_workers: int = 1

    # Uncalibrated kinetic assumptions.  Keeping them in the plain config makes
    # a sensitivity sweep possible without hiding any value in solver code.
    hf_activation_energy_J_mol: float = 20_000.0
    second_wet_rate_multiplier: float = 0.70
    second_wet_activation_energy_J_mol: float = 40_000.0
    oxidation_rate_multiplier: float = 1.00
    oxidation_activation_energy_J_mol: float = 25_000.0
    fluoride_rate_multiplier: float = 2.00
    fluoride_activation_energy_J_mol: float = 20_000.0
    hf_product_yield: float = 0.35
    hf_passivation_yield: float = 0.20
    rinse_product_release_s: float = 0.08
    rinse_passivation_removal_s: float = 0.03

    def __post_init__(self) -> None:
        if not self.geometries or not self.presets or not self.arms:
            raise ValueError("geometries, presets, and arms cannot be empty")
        unknown_geometries = set(self.geometries).difference(GEOMETRY_PRESETS)
        unknown_presets = set(self.presets).difference(LITERATURE_ETCH_PRESETS)
        unknown_arms = set(self.arms).difference(WET_SEQUENCE_ARMS)
        if unknown_geometries:
            raise ValueError(f"unknown geometries: {sorted(unknown_geometries)}")
        if unknown_presets:
            raise ValueError(f"unknown literature presets: {sorted(unknown_presets)}")
        if unknown_arms:
            raise ValueError(f"unknown WET arms: {sorted(unknown_arms)}")
        for name in (
            "primary_hf_clear_time_fraction",
            "rinse_duration_s",
            "second_wet_clear_time_fraction",
            "oxidation_clear_time_fraction",
            "fluoride_clear_time_fraction",
            "solution_bulk_temperature_K",
            "substrate_backside_temperature_K",
            "rinse_product_release_s",
            "rinse_passivation_removal_s",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        for name in (
            "hf_activation_energy_J_mol",
            "second_wet_rate_multiplier",
            "second_wet_activation_energy_J_mol",
            "oxidation_rate_multiplier",
            "oxidation_activation_energy_J_mol",
            "fluoride_rate_multiplier",
            "fluoride_activation_energy_J_mol",
            "hf_product_yield",
            "hf_passivation_yield",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and nonnegative")
        for name in (
            "integration_chunks_per_reactive_step",
            "integration_chunks_per_rinse",
            "parallel_workers",
        ):
            value = getattr(self, name)
            if not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for name in ("geometries", "presets", "arms"):
            result[name] = list(getattr(self, name))
        return result


def get_wet_sequence_arm(name: str) -> WetSequenceArm:
    try:
        return WET_SEQUENCE_ARMS[name]
    except KeyError as exc:
        choices = ", ".join(WET_SEQUENCE_ARMS)
        raise ValueError(f"unknown WET arm {name!r}; choose from {choices}") from exc


def _build_thermal_model(
    geometry: TaperedTrench2D,
    preset: LiteratureEtchPreset,
    config: WetSequenceSweepConfig,
) -> ThermalResistanceModel:
    return ThermalResistanceModel(
        geometry,
        ThermalResistanceParameters(
            liquid_thermal_conductivity_W_mK=0.6065,
            fill_thermal_conductivity_W_mK=preset.fill_thermal_conductivity_W_mK,
            substrate_thermal_conductivity_W_mK=(
                silicon_thermal_conductivity_W_mK(
                    config.substrate_backside_temperature_K
                )
            ),
            substrate_thickness_m=500.0e-6,
            solution_boundary_resistance_m2K_W=0.0,
            fill_substrate_contact_resistance_m2K_W=0.0,
            backside_contact_resistance_m2K_W=0.0,
        ),
    )


def _surface_models(
    characteristic_hf_frequency_s: float,
    config: WetSequenceSweepConfig,
) -> dict[str, MeanFieldSurfaceChemistry]:
    k_hf = characteristic_hf_frequency_s
    identity_factors = {"SiN": 1.0, "SiOCN": 1.0}
    second_factors = dict(
        get_mechanism_preset("phosphoric_like").relative_material_rates
    )
    oxidation_factors = dict(
        get_mechanism_preset("oxidative_conversion").relative_material_rates
    )

    def model(**values: object) -> MeanFieldSurfaceChemistry:
        return MeanFieldSurfaceChemistry(MeanFieldKineticParameters(**values))

    return {
        "hf": model(
            reaction_mode=ReactionMode.DIRECT_ETCH,
            rate_constant_ref_s=k_hf,
            reference_temperature_K=298.15,
            activation_energy_J_mol=config.hf_activation_energy_J_mol,
            product_yield=config.hf_product_yield,
            passivation_yield=config.hf_passivation_yield,
            product_release_s=0.25 * k_hf,
            passivation_removal_s=0.05 * k_hf,
            material_rate_factors=identity_factors,
        ),
        "rinse": model(
            reaction_mode=ReactionMode.RINSE,
            rate_constant_ref_s=0.0,
            reference_temperature_K=298.15,
            product_release_s=config.rinse_product_release_s,
            passivation_removal_s=config.rinse_passivation_removal_s,
            material_rate_factors=identity_factors,
        ),
        "phosphoric_like": model(
            reaction_mode=ReactionMode.DIRECT_ETCH,
            rate_constant_ref_s=config.second_wet_rate_multiplier * k_hf,
            reference_temperature_K=298.15,
            activation_energy_J_mol=config.second_wet_activation_energy_J_mol,
            product_yield=0.10,
            product_release_s=0.20 * k_hf,
            passivation_removal_s=0.50 * k_hf,
            material_rate_factors=second_factors,
        ),
        "oxidative_conversion": model(
            reaction_mode=ReactionMode.OXIDATIVE_CONVERSION,
            rate_constant_ref_s=config.oxidation_rate_multiplier * k_hf,
            reference_temperature_K=298.15,
            activation_energy_J_mol=config.oxidation_activation_energy_J_mol,
            product_yield=0.05,
            material_rate_factors=oxidation_factors,
        ),
        "fluoride_after_oxidation": model(
            reaction_mode=ReactionMode.ETCH_CONVERTED,
            rate_constant_ref_s=config.fluoride_rate_multiplier * k_hf,
            reference_temperature_K=298.15,
            activation_energy_J_mol=config.fluoride_activation_energy_J_mol,
            product_yield=0.15,
            product_release_s=0.25 * k_hf,
            passivation_removal_s=0.25 * k_hf,
            material_rate_factors=identity_factors,
        ),
    }


def _solution_inputs(reactive: bool) -> dict[str, float]:
    activity = 1.0 if reactive else 0.0
    return {
        "reactant_activity": activity,
        "reactant_concentration": activity,
        "product_activity": 0.0,
        "product_concentration": 0.0,
    }


def _build_steps(
    blanket_clear_time_s: float,
    config: WetSequenceSweepConfig,
) -> dict[str, WetStep]:
    primary_duration = (
        config.primary_hf_clear_time_fraction * blanket_clear_time_s
    )
    second_duration = (
        config.second_wet_clear_time_fraction * blanket_clear_time_s
    )
    oxidation_duration = (
        config.oxidation_clear_time_fraction * blanket_clear_time_s
    )
    fluoride_duration = (
        config.fluoride_clear_time_fraction * blanket_clear_time_s
    )
    boundary = {
        "solution_temperature_K": config.solution_bulk_temperature_K,
        "substrate_temperature_K": config.substrate_backside_temperature_K,
        "state_semantics": StepStateSemantics(
            solution="reset", surface="carry", substrate="carry"
        ),
    }

    def reactive_step(
        name: str,
        mechanism: str,
        duration_s: float,
        *,
        duration_basis: str,
    ) -> WetStep:
        return WetStep(
            name=name,
            mechanism=mechanism,
            duration_s=duration_s,
            solver_increment_s=duration_s
            / config.integration_chunks_per_reactive_step,
            solution_inputs=_solution_inputs(True),
            metadata={"duration_basis": duration_basis},
            **boundary,
        )

    rinse_increment = config.rinse_duration_s / config.integration_chunks_per_rinse
    return {
        "primary_hf": reactive_step(
            "primary_HF",
            "hf",
            primary_duration,
            duration_basis=(
                f"{config.primary_hf_clear_time_fraction:g} * depth / blanket_WER"
            ),
        ),
        "rinse": WetStep(
            name="rinse",
            mechanism="rinse",
            duration_s=config.rinse_duration_s,
            solver_increment_s=rinse_increment,
            solution_inputs=_solution_inputs(False),
            metadata={"duration_basis": "fixed screening duration"},
            **boundary,
        ),
        "second_wet": reactive_step(
            "second_WET",
            "phosphoric_like",
            second_duration,
            duration_basis=(
                f"{config.second_wet_clear_time_fraction:g} * depth / blanket_WER; "
                "duration only, second-WET rate is uncalibrated"
            ),
        ),
        "secondary_hf": reactive_step(
            "secondary_HF_control",
            "hf",
            second_duration,
            duration_basis="matched to second_WET duration",
        ),
        "oxidation": reactive_step(
            "oxidative_conversion",
            "oxidative_conversion",
            oxidation_duration,
            duration_basis=(
                f"{config.oxidation_clear_time_fraction:g} * depth / blanket_WER; "
                "kinetics uncalibrated"
            ),
        ),
        "post_oxidation_rinse": WetStep(
            name="post_oxidation_rinse",
            mechanism="rinse",
            duration_s=config.rinse_duration_s,
            solver_increment_s=rinse_increment,
            solution_inputs=_solution_inputs(False),
            metadata={"duration_basis": "fixed screening duration"},
            **boundary,
        ),
        "fluoride": reactive_step(
            "fluoride_after_oxidation",
            "fluoride_after_oxidation",
            fluoride_duration,
            duration_basis=(
                f"{config.fluoride_clear_time_fraction:g} * depth / blanket_WER; "
                "kinetics uncalibrated"
            ),
        ),
    }


class _SweepAdapter:
    """Mean-field adapter with thermal sampling and loose adaptive integration."""

    def __init__(
        self,
        models: Mapping[str, MeanFieldSurfaceChemistry],
        material: str,
        geometry: TaperedTrench2D,
        thermal: ThermalResistanceModel,
    ) -> None:
        self.models = models
        self.material = material
        self.geometry = geometry
        self.thermal = thermal
        self.temperature_samples_K: list[float] = []

    def interface_temperature_K(
        self,
        state: WetProcessState,
        step: WetStep,
    ) -> float:
        surface = state.surface_state
        if not isinstance(surface, MeanFieldSurfaceState):
            raise TypeError("surface_state must be MeanFieldSurfaceState")
        removed_fraction = min(max(1.0 - surface.material_coverage, 0.0), 1.0)
        front_depth_m = removed_fraction * self.geometry.depth_nm * NM_TO_M
        return self.thermal.interface_temperature_K(
            front_depth_m,
            ThermalBoundaryConditions(
                solution_bulk_temperature_K=step.solution_temperature_K,
                substrate_backside_temperature_K=step.substrate_temperature_K,
            ),
        )

    def __call__(
        self,
        state: WetProcessState,
        step: WetStep,
        requested_duration_s: float,
    ) -> SolverAdvance:
        surface = state.surface_state
        if not isinstance(surface, MeanFieldSurfaceState):
            raise TypeError("surface_state must be MeanFieldSurfaceState")
        temperature = self.interface_temperature_K(state, step)
        self.temperature_samples_K.append(temperature)
        solution = state.solution_state
        conditions = LocalInterfaceConditions(
            temperature_K=temperature,
            reactant_activity=float(solution.get("reactant_activity", 0.0)),
            product_activity=float(solution.get("product_activity", 0.0)),
            reactant_concentration=float(
                solution.get("reactant_concentration", 0.0)
            ),
            product_concentration=float(
                solution.get("product_concentration", 0.0)
            ),
        )
        model = self.models[step.mechanism.key]
        result = model.advance(
            self.material,
            surface,
            conditions,
            requested_duration_s,
            maximum_step_s=None,
        )
        advanced = state.copied()
        advanced.surface_state = result.state
        return SolverAdvance(
            state=advanced,
            elapsed_s=requested_duration_s,
            metrics={
                "reaction_extent": result.reaction_extent,
                "reaction_rate_coverage_s": (
                    result.final_rate.reaction_rate_coverage_s
                ),
                "material_coverage": result.state.material_coverage,
                "converted_coverage": result.state.converted_coverage,
                "product_coverage": result.state.product_coverage,
                "passivation_coverage": result.state.passivation_coverage,
                "interface_temperature_K": temperature,
            },
        )


def _surface_snapshot(
    surface: MeanFieldSurfaceState,
    geometry: TaperedTrench2D,
) -> dict[str, float]:
    removed = min(max(1.0 - surface.material_coverage, 0.0), 1.0)
    return {
        "material_coverage": surface.material_coverage,
        "unconverted_coverage": surface.unconverted_coverage,
        "converted_coverage": surface.converted_coverage,
        "product_coverage": surface.product_coverage,
        "passivation_coverage": surface.passivation_coverage,
        "blocked_interfacial_coverage": min(
            1.0, surface.product_coverage + surface.passivation_coverage
        ),
        "open_interfacial_fraction": surface.open_interfacial_fraction,
        "cumulative_removed_fraction": removed,
        "equivalent_removed_depth_nm": removed * geometry.depth_nm,
        "removed_cross_section_area_nm2_per_nm_span": removed * geometry.area_nm2,
        "remaining_cross_section_area_nm2_per_nm_span": (
            surface.material_coverage * geometry.area_nm2
        ),
    }


def _run_arm(
    arm: WetSequenceArm,
    steps: Mapping[str, WetStep],
    models: Mapping[str, MeanFieldSurfaceChemistry],
    material: str,
    geometry: TaperedTrench2D,
    thermal: ThermalResistanceModel,
) -> dict[str, object]:
    adapter = _SweepAdapter(models, material, geometry, thermal)
    runner = WetSequenceRunner(adapter)
    state = WetProcessState(surface_state=MeanFieldSurfaceState())
    records: list[dict[str, object]] = []
    all_temperatures: list[float] = []
    previous_surface_after: MeanFieldSurfaceState | None = None

    for step_key in arm.step_keys:
        step = steps[step_key]
        solution_state_before = dict(state.solution_state)
        before_surface = state.surface_state
        assert isinstance(before_surface, MeanFieldSurfaceState)
        before = _surface_snapshot(before_surface, geometry)
        surface_carry_verified = (
            None
            if previous_surface_after is None
            else before_surface == previous_surface_after
        )
        adapter.temperature_samples_K.clear()
        result = runner.run(state, (step,))
        state = result.final_state
        after_surface = state.surface_state
        assert isinstance(after_surface, MeanFieldSurfaceState)
        after = _surface_snapshot(after_surface, geometry)
        final_temperature = adapter.interface_temperature_K(state, step)
        temperature_samples = adapter.temperature_samples_K + [final_temperature]
        all_temperatures.extend(temperature_samples)
        incremental_fraction = max(
            0.0,
            before_surface.material_coverage - after_surface.material_coverage,
        )
        product_cleaning = max(
            0.0,
            before_surface.product_coverage - after_surface.product_coverage,
        )
        passivation_cleaning = max(
            0.0,
            before_surface.passivation_coverage
            - after_surface.passivation_coverage,
        )
        step_result = result.step_results[0]
        is_rinse = step.mechanism.reaction_mode is ReactionMode.RINSE
        expected_solution_state = dict(step.solution_inputs)
        solution_state_after = dict(state.solution_state)
        records.append(
            {
                "step_key": step_key,
                "name": step.name,
                "mechanism": step.mechanism.key,
                "reaction_mode": step.mechanism.reaction_mode.value,
                "duration_s": step.duration_s,
                "duration_basis": step.metadata["duration_basis"],
                "solution_bulk_temperature_K": step.solution_temperature_K,
                "substrate_backside_temperature_K": step.substrate_temperature_K,
                "state_boundary_audit": {
                    "surface_semantics": step.state_semantics.surface.value,
                    "surface_state_source": (
                        "initial_state"
                        if previous_surface_after is None
                        else "previous_step"
                    ),
                    "surface_carry_verified": surface_carry_verified,
                    "solution_semantics": step.state_semantics.solution.value,
                    "solution_inventory_before_reset": solution_state_before,
                    "solution_inputs_applied": expected_solution_state,
                    "solution_inventory_after_step": solution_state_after,
                    "solution_reset_verified": (
                        step.state_semantics.solution.value == "reset"
                        and solution_state_after == expected_solution_state
                    ),
                    "solution_inventory_interpretation": (
                        "imposed bulk activities/concentrations; this mean-field "
                        "adapter has no finite-volume aqueous mass inventory"
                    ),
                },
                "interface_temperature_range_K": {
                    "minimum": min(temperature_samples),
                    "maximum": max(temperature_samples),
                    "sample_count": len(temperature_samples),
                },
                "coverage_before": before,
                "coverage_after": after,
                "incremental_removal": {
                    "fraction_of_initial_inventory": incremental_fraction,
                    "equivalent_depth_nm": incremental_fraction
                    * geometry.depth_nm,
                    "cross_section_area_nm2_per_nm_span": incremental_fraction
                    * geometry.area_nm2,
                },
                "cumulative_removal_after": {
                    "fraction_of_initial_inventory": after[
                        "cumulative_removed_fraction"
                    ],
                    "equivalent_depth_nm": after["equivalent_removed_depth_nm"],
                    "cross_section_area_nm2_per_nm_span": after[
                        "removed_cross_section_area_nm2_per_nm_span"
                    ],
                },
                "rinse_cleaning": {
                    "is_rinse": is_rinse,
                    "product_coverage_removed": product_cleaning,
                    "passivation_coverage_removed": passivation_cleaning,
                    "blocked_coverage_removed": product_cleaning
                    + passivation_cleaning,
                    "material_removal_fraction": incremental_fraction,
                },
                "stop_reason": step_result.stop_reason,
                "stopped_early": step_result.stopped_early,
            }
        )
        previous_surface_after = after_surface

    final_surface = state.surface_state
    assert isinstance(final_surface, MeanFieldSurfaceState)
    return {
        "arm": arm.key,
        "label": arm.label,
        "purpose": arm.purpose,
        "comparison_note": arm.comparison_note,
        "steps": records,
        "total_elapsed_s": state.elapsed_s,
        "final_coverage": _surface_snapshot(final_surface, geometry),
        "interface_temperature_range_K": {
            "minimum": min(all_temperatures),
            "maximum": max(all_temperatures),
            "sample_count": len(all_temperatures),
        },
    }


def _difference(
    left: Mapping[str, object],
    right: Mapping[str, object],
    key: str,
) -> float:
    left_final = left["final_coverage"]
    right_final = right["final_coverage"]
    assert isinstance(left_final, Mapping) and isinstance(right_final, Mapping)
    return float(left_final[key]) - float(right_final[key])


def _control_differences(
    arms: Mapping[str, Mapping[str, object]],
) -> dict[str, object]:
    controls: dict[str, object] = {}
    if "hf_only" in arms and "hf_rinse" in arms:
        controls["rinse_vs_no_rinse"] = {
            "left": "hf_rinse",
            "right": "hf_only",
            "cumulative_removal_difference_fraction": _difference(
                arms["hf_rinse"], arms["hf_only"], "cumulative_removed_fraction"
            ),
            "product_coverage_difference": _difference(
                arms["hf_rinse"], arms["hf_only"], "product_coverage"
            ),
            "passivation_coverage_difference": _difference(
                arms["hf_rinse"], arms["hf_only"], "passivation_coverage"
            ),
            "matched_quantity": "primary HF exposure",
        }
    if (
        "hf_rinse_second_wet" in arms
        and "hf_rinse_hf_control" in arms
    ):
        controls["second_wet_vs_matched_hf"] = {
            "left": "hf_rinse_second_wet",
            "right": "hf_rinse_hf_control",
            "cumulative_removal_difference_fraction": _difference(
                arms["hf_rinse_second_wet"],
                arms["hf_rinse_hf_control"],
                "cumulative_removed_fraction",
            ),
            "remaining_material_difference_fraction": _difference(
                arms["hf_rinse_second_wet"],
                arms["hf_rinse_hf_control"],
                "material_coverage",
            ),
            "matched_quantity": "post-rinse exposure duration",
        }
    if (
        "hf_rinse_oxidation_rinse_fluoride" in arms
        and "hf_rinse_fluoride_without_oxidation" in arms
    ):
        controls["oxidation_required_for_fluoride_branch"] = {
            "left": "hf_rinse_oxidation_rinse_fluoride",
            "right": "hf_rinse_fluoride_without_oxidation",
            "cumulative_removal_difference_fraction": _difference(
                arms["hf_rinse_oxidation_rinse_fluoride"],
                arms["hf_rinse_fluoride_without_oxidation"],
                "cumulative_removed_fraction",
            ),
            "remaining_converted_coverage_difference": _difference(
                arms["hf_rinse_oxidation_rinse_fluoride"],
                arms["hf_rinse_fluoride_without_oxidation"],
                "converted_coverage",
            ),
            "matched_quantity": "fluoride exposure duration",
            "not_matched": "total sequence duration",
        }
    return controls


def _matched_duration_audit(steps: Mapping[str, WetStep]) -> dict[str, object]:
    second_wet = steps["second_wet"].duration_s
    secondary_hf = steps["secondary_hf"].duration_s
    fluoride = steps["fluoride"].duration_s
    return {
        "second_wet_vs_secondary_HF": {
            "second_wet_duration_s": second_wet,
            "secondary_HF_duration_s": secondary_hf,
            "difference_s": second_wet - secondary_hf,
            "exactly_matched": second_wet == secondary_hf,
        },
        "oxidation_arm_vs_no_oxidation_control": {
            "fluoride_duration_s_each": fluoride,
            "exactly_matched": True,
            "total_sequence_duration_matched": False,
        },
        "common_prefix": {
            "primary_HF_step_reused_by_all_selected_arms": True,
            "first_rinse_step_reused_by_all_selected_rinse_arms": True,
        },
    }


def _common_prefix_reproducibility(
    arms: Mapping[str, Mapping[str, object]],
) -> dict[str, object]:
    audits: dict[str, object] = {}
    for step_key in ("primary_hf", "rinse"):
        endpoints: list[tuple[str, Mapping[str, object]]] = []
        for arm_name, arm in arms.items():
            arm_steps = arm["steps"]
            assert isinstance(arm_steps, Sequence)
            for record in arm_steps:
                assert isinstance(record, Mapping)
                if record["step_key"] == step_key:
                    endpoint = record["coverage_after"]
                    assert isinstance(endpoint, Mapping)
                    endpoints.append((arm_name, endpoint))
                    break
        if not endpoints:
            continue
        reference_name, reference = endpoints[0]
        numeric_keys = tuple(
            key
            for key, value in reference.items()
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        )
        maximum_difference = max(
            (
                abs(float(endpoint[key]) - float(reference[key]))
                for _, endpoint in endpoints[1:]
                for key in numeric_keys
            ),
            default=0.0,
        )
        audits[step_key] = {
            "reference_arm": reference_name,
            "compared_arms": [name for name, _ in endpoints],
            "endpoint_count": len(endpoints),
            "exactly_equal": all(endpoint == reference for _, endpoint in endpoints),
            "maximum_absolute_coverage_or_geometry_difference": maximum_difference,
        }
    return audits


def _validate_plain_json_tree(value: object, path: str = "$") -> None:
    """Reject non-finite numbers and non-JSON-compatible payload objects."""

    if value is None or isinstance(value, (str, bool, int)):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"non-finite JSON number at {path}: {value!r}")
        return
    if isinstance(value, Mapping):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"non-string JSON key at {path}: {key!r}")
            _validate_plain_json_tree(item, f"{path}.{key}")
        return
    if isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _validate_plain_json_tree(item, f"{path}[{index}]")
        return
    raise TypeError(f"non-JSON-compatible object at {path}: {type(value).__name__}")


def run_wet_sequence_case(
    geometry_name: str,
    preset_name: str,
    config: WetSequenceSweepConfig,
) -> dict[str, object]:
    geometry = get_geometry_preset(geometry_name)
    preset = get_literature_preset(preset_name)
    blanket_velocity_nm_s = preset.planar_rate_nm_s
    blanket_clear_time_s = geometry.depth_nm / blanket_velocity_nm_s
    characteristic_frequency_s = blanket_velocity_nm_s / geometry.depth_nm
    thermal = _build_thermal_model(geometry, preset, config)
    models = _surface_models(characteristic_frequency_s, config)
    steps = _build_steps(blanket_clear_time_s, config)
    arm_results = {
        arm_name: _run_arm(
            get_wet_sequence_arm(arm_name),
            steps,
            models,
            preset.material,
            geometry,
            thermal,
        )
        for arm_name in config.arms
    }
    all_temperatures = [
        value
        for result in arm_results.values()
        for value in (
            float(result["interface_temperature_range_K"]["minimum"]),
            float(result["interface_temperature_range_K"]["maximum"]),
        )
    ]
    return {
        "case_id": f"{geometry_name}__{preset_name}",
        "geometry": geometry.to_dict(),
        "preset": preset.to_dict(),
        "material": preset.material,
        "boundary_temperatures_K": {
            "solution_bulk": config.solution_bulk_temperature_K,
            "substrate_backside": config.substrate_backside_temperature_K,
            "independent_inputs": True,
        },
        "interface_temperature_range_all_arms_K": {
            "minimum": min(all_temperatures),
            "maximum": max(all_temperatures),
        },
        "primary_HF_time_axis": {
            "blanket_WER_nm_min": preset.planar_rate_nm_min,
            "blanket_WER_nm_s": blanket_velocity_nm_s,
            "blanket_clear_time_s": blanket_clear_time_s,
            "primary_HF_duration_s": steps["primary_hf"].duration_s,
            "primary_HF_clear_time_fraction": (
                config.primary_hf_clear_time_fraction
            ),
            "mean_field_reference_frequency_s": characteristic_frequency_s,
            "frequency_formula": "blanket_WER_nm_s / trench_depth_nm",
            "initial_equivalent_rate_matches_blanket_WER": True,
            "limitation": (
                "mean-field reactive inventory is first order, so later-time "
                "coverage is not a constant-velocity blanket front"
            ),
        },
        "arms": list(arm_results.values()),
        "control_differences": _control_differences(arm_results),
        "matched_duration_audit": _matched_duration_audit(steps),
        "common_prefix_reproducibility": _common_prefix_reproducibility(
            arm_results
        ),
    }


_WORKER_THREAD_LIMITER = None


def _initialise_numeric_worker() -> None:
    global _WORKER_THREAD_LIMITER
    try:
        from threadpoolctl import threadpool_limits
    except ImportError:
        return
    _WORKER_THREAD_LIMITER = threadpool_limits(limits=1)


def _run_case_tuple(
    values: tuple[str, str, WetSequenceSweepConfig],
) -> dict[str, object]:
    return run_wet_sequence_case(*values)


def run_wet_sequence_sweep(
    config: WetSequenceSweepConfig = WetSequenceSweepConfig(),
) -> dict[str, object]:
    case_inputs = [
        (geometry, preset, config)
        for geometry in config.geometries
        for preset in config.presets
    ]
    effective_workers = min(config.parallel_workers, len(case_inputs))
    if effective_workers == 1:
        cases = [_run_case_tuple(values) for values in case_inputs]
    else:
        # Set common BLAS/OpenMP environment defaults before worker import.  The
        # threadpool limiter handles already-loaded numeric runtimes.
        for name in (
            "OMP_NUM_THREADS",
            "OPENBLAS_NUM_THREADS",
            "MKL_NUM_THREADS",
            "VECLIB_MAXIMUM_THREADS",
            "NUMEXPR_NUM_THREADS",
        ):
            os.environ.setdefault(name, "1")
        with ProcessPoolExecutor(
            max_workers=effective_workers,
            initializer=_initialise_numeric_worker,
        ) as executor:
            cases = list(executor.map(_run_case_tuple, case_inputs))

    used_sources: set[str] = set()
    for preset_name in config.presets:
        preset = get_literature_preset(preset_name)
        used_sources.add(preset.rate_source_key)
        used_sources.update(preset.property_source_keys)
    payload = {
        "schema_version": 1,
        "model": "literature-anchored mean-field WET sequence arm sweep",
        "notice": WET_SEQUENCE_SWEEP_NOTICE,
        "calibrated": False,
        "deterministic": True,
        "config": config.to_dict(),
        "parallel_execution": {
            "requested_workers": config.parallel_workers,
            "effective_workers": effective_workers,
            "case_count": len(case_inputs),
            "case_order_preserved": True,
            "numeric_threads_per_worker": 1 if effective_workers > 1 else None,
        },
        "arm_definitions": {
            name: WET_SEQUENCE_ARMS[name].to_dict() for name in config.arms
        },
        "parameter_provenance": {
            "literature_backed": [
                "film-specific primary HF blanket WER",
                "fill thermal conductivity and density metadata",
                "water and Si thermal properties",
            ],
            "uncalibrated_assumptions": [
                "all activation energies used for temperature sensitivity",
                "first-order coverage representation k_ref = blanket_WER/depth",
                "product and passivation yields and removal rates",
                "rinse cleaning coefficients and duration",
                "second-WET material factors and rate multiplier",
                "oxidative-conversion and converted-phase fluoride rates",
                "secondary-step durations expressed as fractions of primary blanket clear time",
                "rinse is first-order interfacial cleaning into an imposed fresh-solution sink; no finite aqueous inventory is integrated",
            ],
            "sources": {
                key: SOURCES[key].to_dict() for key in sorted(used_sources)
            },
        },
        "serialization_audit": {
            "plain_JSON_compatible": True,
            "nonfinite_numbers_allowed": False,
        },
        "cases": cases,
    }
    _validate_plain_json_tree(payload)
    return payload


__all__ = [
    "WET_SEQUENCE_ARMS",
    "WET_SEQUENCE_SWEEP_NOTICE",
    "WetSequenceArm",
    "WetSequenceSweepConfig",
    "get_wet_sequence_arm",
    "run_wet_sequence_case",
    "run_wet_sequence_sweep",
]

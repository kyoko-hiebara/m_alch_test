#!/usr/bin/env python3
"""Static diagnostics for dry-down versus surface-affinity screening.

Figure contract
---------------
Core conclusion: stage-resolved balances separate *how much* material is
captured during dry-down from *where* that inventory attaches.  The stage
figure supplies the conservation evidence, the two-response phase map tests
orthogonality, and the profile plate shows the resulting wall/floor
morphology.  The backend is Python/Matplotlib and the default export is a
300-dpi PNG.  Missing values are shown as missing and are never imputed.

Preferred payload schema is ``trench-attachment-discrimination/v1`` with
``cases[*].stages``, ``phase_maps`` and ``cases[*].surface_profiles``.  The
reader also accepts common aliases and older persistent-deposit diagnostic
names so that intermediate calculations remain inspectable.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
import numpy as np


plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = [
    "Hiragino Sans",
    "Noto Sans JP",
    "YuGothic",
    "Arial",
    "DejaVu Sans",
    "Liberation Sans",
]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42

SCREENING_NOTICE = (
    "未校正の機構スクリーニング — 捕捉量、乾燥速度、wall/bottom affinity、"
    "second-WET速度は感度パラメータです。\n"
    "絶対値をプロセスrecipeとして使用しないでください。"
)

EXPECTED_PAYLOAD_KEYS: dict[str, tuple[str, ...]] = {
    "top_level": (
        "schema_version",
        "config",
        "probe_definitions",
        "cases",
        "phase_maps",
        "quality_summary",
        "model_limitations",
    ),
    "case": (
        "case_id",
        "geometry_id",
        "preset_id",
        "material",
        "parameters",
        "stages",
        "metrics",
        "surface_profiles",
    ),
    "stages": (
        "hf_endpoint",
        "rinse_endpoint",
        "drydown_endpoint",
        "second_wet_endpoint",
    ),
    "phase_map": (
        "x_name",
        "y_name",
        "x_values",
        "y_values",
        "metric_grids",
    ),
}

_STYLE = {
    "font.size": 8.0,
    "axes.titlesize": 9.4,
    "axes.labelsize": 8.0,
    "axes.linewidth": 0.7,
    "xtick.labelsize": 7.0,
    "ytick.labelsize": 7.0,
    "legend.fontsize": 6.8,
    "legend.frameon": False,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
}

_REGION_COLORS = {
    "total": "#315A7D",
    "wall": "#A23B72",
    "bottom": "#D19A2A",
}
_REGION_LINE_STYLES = {
    "total": ("o", "-", 2),
    "wall": ("s", "--", 4),
    "bottom": ("o", "-", 3),
}
_CAPTURE_CMAP = LinearSegmentedColormap.from_list(
    "capture", ("#F2F5F7", "#9CC2CE", "#275D75")
)
_EXCESS_CMAP = LinearSegmentedColormap.from_list(
    "wall_excess", ("#557FA3", "#F7F7F7", "#B24C4C")
)

_STAGES = (
    ("hf_endpoint", "HF直後", ("hf_endpoint", "after_hf", "primary_hf", "hf")),
    (
        "rinse_endpoint",
        "rinse直後",
        ("rinse_endpoint", "after_rinse", "rinse", "post_rinse"),
    ),
    (
        "drydown_endpoint",
        "dry-down後",
        ("drydown_endpoint", "after_drydown", "dry_down", "drydown", "post_dry"),
    ),
    (
        "second_wet_endpoint",
        "second-WET後",
        ("second_wet_endpoint", "after_second_wet", "second_wet", "final"),
    ),
)


def expected_payload_keys() -> dict[str, tuple[str, ...]]:
    """Return a copy of the preferred, non-exclusive payload schema."""

    return {key: tuple(value) for key, value in EXPECTED_PAYLOAD_KEYS.items()}


def _load_payload(value: Mapping[str, Any] | str | Path) -> Mapping[str, Any]:
    if isinstance(value, (str, Path)):
        payload = json.loads(Path(value).read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("attachment-discrimination JSON must contain a mapping")
        return payload
    if not isinstance(value, Mapping):
        raise TypeError("expected a mapping or a JSON path")
    return value


def _number(value: Any) -> float | None:
    if value is None or isinstance(value, (bool, np.bool_)):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _first(mapping: Mapping[str, Any], names: Sequence[str]) -> Any:
    for name in names:
        value = mapping.get(name)
        if value is not None:
            return value
    return None


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _cases(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    raw = _first(payload, ("cases", "runs", "probe_cases", "results"))
    if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)):
        return [item for item in raw if isinstance(item, Mapping)]
    if isinstance(raw, Mapping):
        result = []
        for case_id, item in raw.items():
            if isinstance(item, Mapping):
                row = dict(item)
                row.setdefault("case_id", str(case_id))
                result.append(row)
        return result
    return []


def _destination(path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def _finish(
    figure: plt.Figure,
    output_path: str | Path,
    *,
    dpi: int,
    bottom: float = 0.15,
) -> Path:
    if not isinstance(dpi, int) or isinstance(dpi, bool) or dpi < 1:
        plt.close(figure)
        raise ValueError("dpi must be a positive integer")
    figure.text(
        0.5,
        0.004,
        SCREENING_NOTICE,
        ha="center",
        va="bottom",
        fontsize=6.4,
        color="0.30",
        wrap=True,
    )
    figure.subplots_adjust(bottom=bottom)
    destination = _destination(output_path)
    figure.savefig(destination, dpi=dpi, bbox_inches="tight")
    plt.close(figure)
    return destination


def _no_data(
    output_path: str | Path, *, title: str, message: str, dpi: int
) -> Path:
    with plt.rc_context(_STYLE):
        figure, axis = plt.subplots(figsize=(7.4, 3.2))
        axis.set_axis_off()
        axis.text(
            0.5,
            0.58,
            "No reported data",
            ha="center",
            va="center",
            fontsize=16,
        )
        axis.text(
            0.5,
            0.39,
            message,
            ha="center",
            va="center",
            transform=axis.transAxes,
            color="0.35",
            wrap=True,
        )
        figure.suptitle(title, y=0.94, fontsize=11)
        return _finish(figure, output_path, dpi=dpi)


def _case_title(case: Mapping[str, Any]) -> str:
    values = []
    for aliases in (
        ("material",),
        ("geometry_id", "geometry_name", "geometry"),
        ("preset_id", "preset_name", "preset"),
        ("probe_name", "scenario", "case_id", "id"),
    ):
        value = _first(case, aliases)
        if isinstance(value, Mapping):
            value = _first(value, ("id", "name", "label"))
        if value is not None and str(value) not in values:
            values.append(str(value))
    return " | ".join(values[:3]) or "reported case"


def _representative_stage_case(payload: Mapping[str, Any]) -> Mapping[str, Any] | None:
    cases = [
        case
        for case in _cases(payload)
        if str(case.get("status", "ok")).lower() not in {"failed", "error"}
        and isinstance(_first(case, ("stages", "stage_summaries", "stage_records")), Mapping)
    ]
    if not cases:
        return None
    requested = _first(
        payload,
        ("representative_stage_case_id", "reference_case_id", "baseline_case_id"),
    )
    if requested is not None:
        for case in cases:
            if str(_first(case, ("case_id", "id"))) == str(requested):
                return case
    for case in cases:
        if case.get("representative") is True:
            return case
        probe = str(_first(case, ("probe_name", "probe_id", "scenario")) or "").lower()
        level = str(case.get("probe_level", "")).lower()
        if probe in {"baseline", "reference", "centre", "center"} or level in {
            "baseline",
            "reference",
            "centre",
            "center",
        }:
            return case
    # The first OAT case is commonly the no-dry control.  Prefer the positive,
    # unit-affinity reference so the four-stage panel does not collapse to a
    # visually uninformative all-zero trace.
    for case in cases:
        parameters = _mapping(case.get("parameters"))
        probe = str(_first(case, ("probe_name", "probe_id", "scenario")) or "")
        dry_stage = _stage_mapping(case, ("drydown_endpoint", "dry_down", "drydown"))
        total = _region_inventory(_deposit(dry_stage), "total")
        if (
            probe == "wall_pretreatment"
            and bool(parameters.get("dry_enabled", True))
            and abs(float(parameters.get("wall_pretreatment_multiplier", 1.0)) - 1.0)
            <= 1.0e-12
            and total is not None
            and total > 0.0
        ):
            return case
    positive = []
    for case in cases:
        dry_stage = _stage_mapping(case, ("drydown_endpoint", "dry_down", "drydown"))
        total = _region_inventory(_deposit(dry_stage), "total")
        if total is not None and total > 0.0:
            positive.append((total, case))
    return max(positive, key=lambda item: item[0])[1] if positive else cases[0]


def _stage_mapping(case: Mapping[str, Any], aliases: Sequence[str]) -> Mapping[str, Any]:
    root = _first(case, ("stages", "stage_summaries", "stage_records"))
    if not isinstance(root, Mapping):
        return {}
    value = _first(root, aliases)
    return value if isinstance(value, Mapping) else {}


def _deposit(stage: Mapping[str, Any]) -> Mapping[str, Any]:
    value = _first(
        stage,
        (
            "deposit_diagnostics",
            "deposit",
            "deposit_metrics",
            "persistent_deposit",
            "final_deposit",
            "diagnostics",
        ),
    )
    if isinstance(value, Mapping):
        nested = value.get("diagnostics")
        return nested if isinstance(nested, Mapping) else value
    return stage


def _region_inventory(deposit: Mapping[str, Any], region: str) -> float | None:
    aliases = {
        "total": (
            "total_inventory_native",
            "deposit_inventory_native",
            "total_deposit_inventory_native",
            "inventory_native",
        ),
        "wall": (
            "wall_inventory_native",
            "wall_deposit_inventory_native",
            "sidewall_inventory_native",
        ),
        "bottom": (
            "bottom_inventory_native",
            "bottom_deposit_inventory_native",
            "floor_inventory_native",
        ),
    }
    return _number(_first(deposit, aliases[region]))


def _surface_mapping(deposit: Mapping[str, Any]) -> Mapping[str, Any]:
    value = _first(
        deposit,
        ("surface_normalized", "surface_metrics", "area_normalized", "densities"),
    )
    return value if isinstance(value, Mapping) else {}


def _region_density(deposit: Mapping[str, Any], region: str) -> float | None:
    surface = _surface_mapping(deposit)
    density_aliases = (
        f"{region}_inventory_density_native_per_nm2",
        f"{region}_deposit_density_native_per_nm2",
        f"{region}_inventory_per_nm2",
        f"{region}_density_native_per_nm2",
    )
    value = _number(_first(deposit, density_aliases))
    if value is None:
        value = _number(_first(surface, density_aliases))
    if value is not None:
        return value

    inventory = _region_inventory(deposit, region)
    if inventory is None:
        inventory = _number(
            _first(
                surface,
                (
                    f"{region}_inventory_native",
                    f"{region}_inventory_per_nm",
                ),
            )
        )
    area_aliases = (
        f"{region}_available_contact_area_nm2_for_1nm_span",
        f"{region}_contact_area_nm2",
        f"{region}_area_per_nm",
        f"{region}_contact_length_nm",
    )
    area = _number(_first(deposit, area_aliases))
    if area is None:
        area = _number(_first(surface, area_aliases))
    if inventory is not None and area is not None and area > 0.0:
        return inventory / area
    return None


def _region_areal_inventory_mol_m2(
    deposit: Mapping[str, Any], region: str
) -> float | None:
    surface = _surface_mapping(deposit)
    aliases = (
        f"{region}_areal_inventory_mol_m2",
        f"{region}_deposit_areal_inventory_mol_m2",
        f"{region}_inventory_mol_m2",
    )
    value = _number(_first(deposit, aliases))
    return value if value is not None else _number(_first(surface, aliases))


def plot_attachment_stage_inventory(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot deposit inventory and surface density at four process endpoints."""

    payload = _load_payload(payload_or_path)
    case = _representative_stage_case(payload)
    if case is None:
        return _no_data(
            output_path,
            title="Stage-resolved attachment balance",
            message="Expected cases[*].stages with HF, rinse, dry-down and second-WET endpoints.",
            dpi=dpi,
        )

    labels: list[str] = []
    inventories = {region: [] for region in _REGION_COLORS}
    densities = {region: [] for region in ("wall", "bottom")}
    molar_densities = {region: [] for region in ("wall", "bottom")}
    for _canonical, label, aliases in _STAGES:
        stage = _stage_mapping(case, aliases)
        deposit = _deposit(stage)
        labels.append(label)
        for region in inventories:
            inventories[region].append(_region_inventory(deposit, region))
        for region in densities:
            densities[region].append(_region_density(deposit, region))
            molar_densities[region].append(
                _region_areal_inventory_mol_m2(deposit, region)
            )

    has_inventory = any(value is not None for rows in inventories.values() for value in rows)
    has_density = any(value is not None for rows in densities.values() for value in rows)
    has_molar_density = any(
        value is not None for rows in molar_densities.values() for value in rows
    )
    if not has_inventory and not has_density and not has_molar_density:
        return _no_data(
            output_path,
            title="Stage-resolved attachment balance",
            message="Stage records were present, but no inventory or area-normalized density was reported.",
            dpi=dpi,
        )

    x = np.arange(len(labels))
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(1, 2, figsize=(10.2, 4.2))
        for region, values in inventories.items():
            array = np.asarray([np.nan if value is None else value for value in values])
            if np.any(np.isfinite(array)):
                marker, linestyle, zorder = _REGION_LINE_STYLES[region]
                axes[0].plot(
                    x,
                    array,
                    marker=marker,
                    linestyle=linestyle,
                    markersize=4.3,
                    linewidth=1.55,
                    color=_REGION_COLORS[region],
                    label=region,
                    zorder=zorder,
                )
        axes[0].set_title("a  捕捉在庫の段階収支", loc="left", fontweight="bold")
        axes[0].set_ylabel("deposit inventory (native model units)")
        axes[0].legend(ncol=3, loc="upper left")

        plotted_densities = molar_densities if has_molar_density else densities
        for region, values in plotted_densities.items():
            array = np.asarray([np.nan if value is None else value for value in values])
            if np.any(np.isfinite(array)):
                marker, linestyle, zorder = _REGION_LINE_STYLES[region]
                axes[1].plot(
                    x,
                    array,
                    marker=marker,
                    linestyle=linestyle,
                    markersize=4.3,
                    linewidth=1.55,
                    color=_REGION_COLORS[region],
                    label=region,
                    zorder=zorder,
                )
        axes[1].set_title("b  接触面積規格化密度", loc="left", fontweight="bold")
        axes[1].set_ylabel(
            r"areal deposit inventory (mol m$^{-2}$)"
            if has_molar_density
            else r"inventory density (native nm$^{-2}$)"
        )
        if has_density or has_molar_density:
            axes[1].legend(ncol=2, loc="upper left")
        else:
            axes[1].text(
                0.5,
                0.5,
                "Area-normalized density\nnot reported",
                ha="center",
                va="center",
                transform=axes[1].transAxes,
                color="0.4",
            )
        for axis in axes:
            axis.set_xticks(x, labels, rotation=20, ha="right")
            axis.grid(axis="y", color="0.90", linewidth=0.55)
            axis.spines[["top", "right"]].set_visible(False)
        figure.suptitle(
            f"Stage-resolved deposit balance — {_case_title(case)}",
            y=0.985,
            fontsize=11,
        )
        figure.tight_layout(rect=(0.01, 0.14, 0.99, 0.92))
        return _finish(figure, output_path, dpi=dpi)


def _sequence(value: Any) -> list[Any]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return list(value)
    return []


def _grid(value: Any, ny: int, nx: int) -> np.ndarray | None:
    try:
        result = np.asarray(value, dtype=float)
    except (TypeError, ValueError):
        return None
    if result.shape == (ny, nx):
        return result
    if result.shape == (nx, ny):
        return result.T
    return None


def _phase_map_records(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    raw = _first(payload, ("phase_maps", "phase_map", "response_surfaces"))
    if isinstance(raw, Mapping):
        rows = _first(raw, ("strata", "maps", "records"))
        if isinstance(rows, Sequence) and not isinstance(rows, (str, bytes)):
            base = {key: value for key, value in raw.items() if key not in {"strata", "maps", "records"}}
            return [dict(base, **row) for row in rows if isinstance(row, Mapping)]
        return [raw]
    if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)):
        records = []
        for item in raw:
            if not isinstance(item, Mapping):
                continue
            strata = item.get("strata")
            if isinstance(strata, Sequence) and not isinstance(strata, (str, bytes)):
                base = {key: value for key, value in item.items() if key != "strata"}
                records.extend(
                    dict(base, **row) for row in strata if isinstance(row, Mapping)
                )
            else:
                records.append(item)
        return records
    return []


def _metric_grid(
    record: Mapping[str, Any], aliases: Sequence[str], ny: int, nx: int
) -> np.ndarray | None:
    sources = [record]
    for key in ("metric_grids", "metrics", "grids", "responses"):
        value = record.get(key)
        if isinstance(value, Mapping):
            sources.insert(0, value)
    for source in sources:
        value = _first(source, aliases)
        result = _grid(value, ny, nx)
        if result is not None:
            return result
    return None


def _select_phase_map(payload: Mapping[str, Any]) -> tuple[Mapping[str, Any], list[Any], list[Any]] | None:
    candidates = _phase_map_records(payload)
    def score(record: Mapping[str, Any]) -> int:
        text = " ".join(
            str(_first(record, aliases) or "").lower()
            for aliases in (
                ("pair_id", "id", "name"),
                ("x_name", "x_parameter"),
                ("y_name", "y_parameter"),
            )
        )
        return int("dry" in text) + int("affinity" in text or "pretreatment" in text)

    for record in sorted(candidates, key=score, reverse=True):
        x_values = _sequence(_first(record, ("x_values", "dry_values", "dry_severity_values")))
        y_values = _sequence(_first(record, ("y_values", "affinity_values", "wall_affinity_values")))
        if x_values and y_values:
            return record, x_values, y_values
    return None


def _pretty_parameter(name: Any, fallback: str) -> str:
    text = str(name or fallback)
    replacements = {
        "dry_capture_fraction": "dry-down capture fraction",
        "drying_time_constant_s": "drying time constant (s)",
        "dry_severity": "dry-down severity",
        "wall_pretreatment_multiplier": "wall affinity multiplier",
        "wall_affinity": "wall affinity multiplier",
        "wall_material_selectivity": "wall material selectivity",
    }
    return replacements.get(text, text.replace("_", " "))


def _format_tick(value: Any) -> str:
    number = _number(value)
    if number is None:
        return str(value)
    return f"{number:.3g}"


def _annotate_grid(axis: plt.Axes, values: np.ndarray, *, diverging: bool) -> None:
    finite = values[np.isfinite(values)]
    if values.size > 64 or not finite.size:
        return
    scale = max(float(np.max(np.abs(finite))), np.finfo(float).eps)
    for row, column in zip(*np.nonzero(np.isfinite(values)), strict=True):
        value = float(values[row, column])
        color = "white" if abs(value) > 0.52 * scale else "0.18"
        if not diverging and value < float(np.min(finite)) + 0.38 * float(np.ptp(finite)):
            color = "0.18"
        axis.text(column, row, f"{value:.2g}", ha="center", va="center", fontsize=6.1, color=color)


def plot_attachment_separation_phase_map(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot total capture beside area-normalized wall excess."""

    payload = _load_payload(payload_or_path)
    selected = _select_phase_map(payload)
    if selected is None:
        return _no_data(
            output_path,
            title="Dry-down × wall-affinity separation map",
            message="Expected phase_maps with x_values, y_values and metric_grids.",
            dpi=dpi,
        )
    record, x_values, y_values = selected
    ny, nx = len(y_values), len(x_values)
    total = _metric_grid(
        record,
        (
            "total_capture_inventory_native",
            "drydown_total_deposit_inventory_native",
            "final_total_deposit_inventory_native",
            "total_capture_fraction",
            "captured_fraction",
            "total_capture",
        ),
        ny,
        nx,
    )
    excess = _metric_grid(
        record,
        (
            "wall_bottom_density_contrast",
            "normalized_wall_bottom_density_contrast",
            "wall_allocation_contrast",
        ),
        ny,
        nx,
    )
    dimensionless_excess = excess is not None
    if excess is None:
        excess = _metric_grid(
        record,
        (
            "wall_excess_density_native_per_nm2",
            "wall_minus_bottom_density_native_per_nm2",
            "wall_bottom_density_difference",
            "area_normalized_wall_excess",
            "wall_excess",
        ),
        ny,
        nx,
        )
    if excess is None:
        wall = _metric_grid(
            record,
            ("wall_inventory_density_native_per_nm2", "wall_density_native_per_nm2", "wall_density"),
            ny,
            nx,
        )
        bottom = _metric_grid(
            record,
            ("bottom_inventory_density_native_per_nm2", "bottom_density_native_per_nm2", "bottom_density"),
            ny,
            nx,
        )
        if wall is not None and bottom is not None:
            excess = wall - bottom
    if total is None and excess is None:
        return _no_data(
            output_path,
            title="Dry-down × wall-affinity separation map",
            message="Phase-map axes were present, but capture and wall-excess grids were not reported.",
            dpi=dpi,
        )

    x_label = _pretty_parameter(_first(record, ("x_name", "x_parameter")), "dry-down severity")
    y_label = _pretty_parameter(_first(record, ("y_name", "y_parameter")), "wall affinity")
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(1, 2, figsize=(10.3, 4.55))
        if total is not None and np.any(np.isfinite(total)):
            image = axes[0].imshow(total, aspect="auto", origin="lower", cmap=_CAPTURE_CMAP)
            colorbar = figure.colorbar(image, ax=axes[0], fraction=0.046, pad=0.04)
            colorbar.set_label("total captured inventory")
            _annotate_grid(axes[0], total, diverging=False)
        else:
            axes[0].text(0.5, 0.5, "Total capture not reported", ha="center", va="center", transform=axes[0].transAxes)
        axes[0].set_title("a  捕捉量：dry-down応答", loc="left", fontweight="bold")

        if excess is not None and np.any(np.isfinite(excess)):
            finite = excess[np.isfinite(excess)]
            limit = max(float(np.max(np.abs(finite))), np.finfo(float).eps)
            image = axes[1].imshow(
                excess,
                aspect="auto",
                origin="lower",
                cmap=_EXCESS_CMAP,
                norm=TwoSlopeNorm(vmin=-limit, vcenter=0.0, vmax=limit),
            )
            colorbar = figure.colorbar(image, ax=axes[1], fraction=0.046, pad=0.04)
            colorbar.set_label(
                r"$(\rho_{wall}-\rho_{bottom})/(\rho_{wall}+\rho_{bottom})$"
                if dimensionless_excess
                else r"wall − bottom density (native nm$^{-2}$)"
            )
            _annotate_grid(axes[1], excess, diverging=True)
        else:
            axes[1].text(0.5, 0.5, "Wall excess not reported", ha="center", va="center", transform=axes[1].transAxes)
        axes[1].set_title(
            "b  付着先：面積規格化wall contrast",
            loc="left",
            fontweight="bold",
        )

        for axis in axes:
            axis.set_xticks(np.arange(nx), [_format_tick(value) for value in x_values])
            axis.set_yticks(np.arange(ny), [_format_tick(value) for value in y_values])
            axis.set_xlabel(x_label)
            axis.set_ylabel(y_label)
        title_parts = [
            str(_first(record, ("material", "preset_id")) or ""),
            str(_first(record, ("geometry_id", "geometry")) or ""),
        ]
        context = " | ".join(value for value in title_parts if value)
        figure.suptitle(
            "Dry-down capture and wall-affinity redistribution"
            + (f" — {context}" if context else ""),
            y=0.99,
            fontsize=11,
        )
        figure.text(
            0.5,
            0.13,
            "左：総捕捉量の変化　　右：同じ総量がwallへ偏るかを検定",
            ha="center",
            va="center",
            fontsize=7.0,
            color="0.28",
        )
        figure.tight_layout(rect=(0.01, 0.23, 0.99, 0.92))
        return _finish(figure, output_path, dpi=dpi, bottom=0.22)


def _profile(case: Mapping[str, Any], stage_name: str) -> Mapping[str, Any]:
    root = _first(case, ("surface_profiles", "profiles", "morphology_profiles"))
    if not isinstance(root, Mapping):
        return {}
    aliases = next((aliases for canonical, _label, aliases in _STAGES if canonical == stage_name), (stage_name,))
    value = _first(root, aliases)
    return value if isinstance(value, Mapping) else {}


def _numeric_array(mapping: Mapping[str, Any], aliases: Sequence[str]) -> np.ndarray | None:
    value = _first(mapping, aliases)
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return None
    try:
        array = np.asarray(value, dtype=float).reshape(-1)
    except (TypeError, ValueError):
        return None
    return array if array.size and np.any(np.isfinite(array)) else None


def _has_profile(case: Mapping[str, Any], stage_name: str) -> bool:
    profile = _profile(case, stage_name)
    return any(
        _numeric_array(profile, aliases) is not None
        for aliases in (
            ("wall_mean_thickness_nm", "wall_thickness_nm"),
            ("wall_coverage_fraction", "wall_geometric_coverage_fraction"),
            ("bottom_thickness_nm", "bottom_mean_thickness_nm"),
            ("bottom_coverage_fraction", "bottom_geometric_coverage_fraction"),
        )
    )


def _case_parameter(case: Mapping[str, Any], aliases: Sequence[str]) -> float | None:
    sources = [case]
    for key in ("parameters", "derived_conditions", "metrics"):
        value = case.get(key)
        if isinstance(value, Mapping):
            sources.insert(0, value)
    for source in sources:
        value = _number(_first(source, aliases))
        if value is not None:
            return value
    return None


def _representative_profile_cases(
    payload: Mapping[str, Any], stage_name: str, max_examples: int
) -> list[Mapping[str, Any]]:
    raw = _first(payload, ("morphology_examples", "representative_cases"))
    candidates = (
        [item for item in raw if isinstance(item, Mapping)]
        if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes))
        else _cases(payload)
    )
    candidates = [
        case
        for case in candidates
        if str(case.get("status", "ok")).lower() not in {"failed", "error"}
        and _has_profile(case, stage_name)
    ]
    # Keep morphology comparisons within one physical stratum and select OAT
    # controls that have distinct scientific meanings: no dry, slow dry, low
    # wall affinity and high wall affinity.  Mixing materials/geometries or
    # duplicate reference cases can otherwise make an all-zero control look
    # like an unexplained replicate.
    if candidates:
        anchor = candidates[0]
        keys = ("geometry_id", "preset_id", "material", "seed")
        same_stratum = [
            case
            for case in candidates
            if all(case.get(key) == anchor.get(key) for key in keys)
        ]
        if same_stratum:
            candidates = same_stratum

    def probe_cases(name: str) -> list[Mapping[str, Any]]:
        return [case for case in candidates if str(case.get("probe_name", "")) == name]

    requested_cases: list[Mapping[str, Any]] = []
    dry_control = [
        case
        for case in probe_cases("dry_enabled")
        if not bool(_mapping(case.get("parameters")).get("dry_enabled", True))
    ]
    if dry_control:
        requested_cases.append(dry_control[0])
    drying = probe_cases("drying_rate")
    if drying:
        requested_cases.append(
            min(
                drying,
                key=lambda case: _case_parameter(case, ("drying_rate_s",))
                or math.inf,
            )
        )
    affinity = probe_cases("wall_pretreatment")
    if affinity:
        requested_cases.extend(
            (
                min(
                    affinity,
                    key=lambda case: _case_parameter(
                        case, ("wall_pretreatment_multiplier",)
                    )
                    or math.inf,
                ),
                max(
                    affinity,
                    key=lambda case: _case_parameter(
                        case, ("wall_pretreatment_multiplier",)
                    )
                    or -math.inf,
                ),
            )
        )
    selected: list[Mapping[str, Any]] = []
    seen: set[str] = set()
    for case in requested_cases:
        identity = str(_first(case, ("case_id", "id")) or id(case))
        if identity not in seen:
            selected.append(case)
            seen.add(identity)
        if len(selected) >= max_examples:
            return selected
    if selected:
        for case in candidates:
            identity = str(_first(case, ("case_id", "id")) or id(case))
            if identity not in seen:
                selected.append(case)
                seen.add(identity)
            if len(selected) >= max_examples:
                break
        return selected
    if len(candidates) <= max_examples:
        return candidates

    dry_aliases = (
        "dry_capture_fraction",
        "dry_severity",
        "drying_rate_s",
        "drying_time_constant_s",
    )
    affinity_aliases = (
        "wall_pretreatment_multiplier",
        "wall_affinity_multiplier",
        "wall_affinity",
        "wall_material_selectivity",
    )
    coordinates = [
        (_case_parameter(case, dry_aliases), _case_parameter(case, affinity_aliases))
        for case in candidates
    ]
    valid = [(index, x, y) for index, (x, y) in enumerate(coordinates) if x is not None and y is not None]
    if valid:
        xs = [row[1] for row in valid]
        ys = [row[2] for row in valid]
        corners = ((min(xs), min(ys)), (max(xs), min(ys)), (min(xs), max(ys)), (max(xs), max(ys)))
        selected_indices: list[int] = []
        for target_x, target_y in corners:
            index = min(
                valid,
                key=lambda row: (row[1] - target_x) ** 2 + (row[2] - target_y) ** 2,
            )[0]
            if index not in selected_indices:
                selected_indices.append(index)
        for index in range(len(candidates)):
            if len(selected_indices) >= max_examples:
                break
            if index not in selected_indices:
                selected_indices.append(index)
        return [candidates[index] for index in selected_indices[:max_examples]]
    return candidates[:max_examples]


def _profile_case_title(case: Mapping[str, Any]) -> str:
    parameters = _mapping(case.get("parameters"))
    if parameters.get("dry_enabled") is False:
        affinity = _case_parameter(
            case,
            ("wall_pretreatment_multiplier", "wall_affinity", "wall_material_selectivity"),
        )
        return "no-dry control" + (
            f" | wall affinity={affinity:.3g}" if affinity is not None else ""
        )
    dry = _case_parameter(
        case,
        (
            "dry_capture_fraction",
            "dry_severity",
            "drying_rate_s",
            "drying_time_constant_s",
        ),
    )
    affinity = _case_parameter(
        case,
        (
            "wall_pretreatment_multiplier",
            "wall_affinity_multiplier",
            "wall_affinity",
            "wall_material_selectivity",
        ),
    )
    values = []
    if dry is not None:
        values.append(f"dry={dry:.3g}")
    if affinity is not None:
        values.append(f"wall affinity={affinity:.3g}")
    if values:
        return " | ".join(values)
    return _case_title(case)


def _profile_arrays(
    profile: Mapping[str, Any], region: str
) -> tuple[np.ndarray | None, np.ndarray | None, np.ndarray | None]:
    if region == "wall":
        coordinate = _numeric_array(profile, ("wall_depth_fraction", "wall_coordinate", "wall_depth"))
        thickness = _numeric_array(profile, ("wall_mean_thickness_nm", "wall_thickness_nm"))
        coverage = _numeric_array(
            profile,
            ("wall_coverage_fraction", "wall_geometric_coverage_fraction", "wall_continuous_coverage_fraction"),
        )
    else:
        coordinate = _numeric_array(profile, ("bottom_x_fraction", "bottom_coordinate", "floor_x_fraction"))
        thickness = _numeric_array(profile, ("bottom_thickness_nm", "bottom_mean_thickness_nm"))
        coverage = _numeric_array(
            profile,
            ("bottom_coverage_fraction", "bottom_geometric_coverage_fraction", "bottom_continuous_coverage_fraction"),
        )
    size = min(
        (len(array) for array in (coordinate, thickness, coverage) if array is not None),
        default=0,
    )
    if size == 0:
        return coordinate, thickness, coverage
    return (
        coordinate[:size] if coordinate is not None else np.linspace(0.0, 1.0, size),
        thickness[:size] if thickness is not None else None,
        coverage[:size] if coverage is not None else None,
    )


def _plot_profile_axis(
    axis: plt.Axes,
    profile: Mapping[str, Any],
    region: str,
) -> tuple[bool, plt.Axes | None]:
    coordinate, thickness, coverage = _profile_arrays(profile, region)
    if coordinate is None:
        size = len(thickness) if thickness is not None else len(coverage) if coverage is not None else 0
        coordinate = np.linspace(0.0, 1.0, size) if size else None
    if coordinate is None or (thickness is None and coverage is None):
        axis.set_axis_off()
        axis.text(0.5, 0.5, "profile not reported", ha="center", va="center", transform=axis.transAxes, color="0.4")
        return False, None
    color = _REGION_COLORS[region]
    if thickness is not None:
        axis.plot(coordinate[: len(thickness)], thickness, color=color, linewidth=1.6)
        axis.fill_between(coordinate[: len(thickness)], 0.0, thickness, color=color, alpha=0.13)
    axis.set_xlim(0.0, 1.0)
    axis.set_ylim(bottom=0.0)
    axis.set_xlabel("normalized depth" if region == "wall" else "normalized floor position")
    axis.set_ylabel("mean thickness (nm)", color=color)
    axis.tick_params(axis="y", colors=color)
    axis.grid(axis="x", color="0.92", linewidth=0.45)
    axis.spines["top"].set_visible(False)
    twin = None
    if coverage is not None:
        twin = axis.twinx()
        twin.plot(
            coordinate[: len(coverage)],
            coverage,
            color="#4E8A75",
            linestyle="--",
            linewidth=1.35,
        )
        twin.set_ylim(0.0, 1.02)
        twin.set_ylabel("coverage", color="#4E8A75")
        twin.tick_params(axis="y", colors="#4E8A75")
        twin.spines["top"].set_visible(False)
    return True, twin


def plot_attachment_morphology_comparison(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
    stage: str = "drydown_endpoint",
    max_examples: int = 4,
) -> Path:
    """Compare wall-depth and floor-lateral thickness/coverage profiles."""

    if stage not in {item[0] for item in _STAGES}:
        raise ValueError("stage must be a canonical process endpoint")
    if not isinstance(max_examples, int) or isinstance(max_examples, bool) or max_examples < 1:
        raise ValueError("max_examples must be a positive integer")
    payload = _load_payload(payload_or_path)
    cases = _representative_profile_cases(payload, stage, max_examples)
    if not cases:
        return _no_data(
            output_path,
            title="Representative wall/bottom deposit morphology",
            message="Expected cases[*].surface_profiles with wall-depth and bottom-position profiles.",
            dpi=dpi,
        )

    columns = len(cases)
    stage_label = next(label for canonical, label, _aliases in _STAGES if canonical == stage)
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(2, columns, figsize=(3.05 * columns, 6.2), squeeze=False)
        for column, case in enumerate(cases):
            profile = _profile(case, stage)
            _plot_profile_axis(axes[0, column], profile, "wall")
            _plot_profile_axis(axes[1, column], profile, "bottom")
            axes[0, column].set_title(_profile_case_title(case), fontsize=8.2)
            if column == 0:
                axes[0, column].text(-0.30, 1.12, "a  wall", transform=axes[0, column].transAxes, fontweight="bold", fontsize=9.4)
                axes[1, column].text(-0.30, 1.12, "b  bottom", transform=axes[1, column].transAxes, fontweight="bold", fontsize=9.4)
        figure.legend(
            handles=(
                Line2D([], [], color=_REGION_COLORS["wall"], linewidth=1.6, label="wall thickness"),
                Line2D([], [], color=_REGION_COLORS["bottom"], linewidth=1.6, label="bottom thickness"),
                Line2D([], [], color="#4E8A75", linestyle="--", linewidth=1.35, label="coverage fraction"),
            ),
            loc="upper center",
            bbox_to_anchor=(0.5, 0.94),
            ncol=3,
        )
        figure.suptitle(
            f"Representative attachment morphology — {stage_label}",
            y=0.995,
            fontsize=11,
        )
        figure.tight_layout(rect=(0.01, 0.12, 0.99, 0.90), h_pad=2.0, w_pad=1.0)
        return _finish(figure, output_path, dpi=dpi)


def plot_attachment_discrimination_visualizations(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_directory: str | Path,
    *,
    dpi: int = 300,
) -> dict[str, Path]:
    """Write the three standard attachment-discrimination PNG figures."""

    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    return {
        "attachment_stage_resolved": plot_attachment_stage_inventory(
            payload_or_path, directory / "attachment_stage_resolved.png", dpi=dpi
        ),
        "attachment_separation_phase_map": plot_attachment_separation_phase_map(
            payload_or_path,
            directory / "attachment_separation_phase_map.png",
            dpi=dpi,
        ),
        "attachment_morphology_comparison": plot_attachment_morphology_comparison(
            payload_or_path,
            directory / "attachment_morphology_comparison.png",
            dpi=dpi,
        ),
    }


__all__ = [
    "EXPECTED_PAYLOAD_KEYS",
    "SCREENING_NOTICE",
    "expected_payload_keys",
    "plot_attachment_discrimination_visualizations",
    "plot_attachment_morphology_comparison",
    "plot_attachment_separation_phase_map",
    "plot_attachment_stage_inventory",
]

from __future__ import annotations

import unittest

from heated_endgame_screen import (
    TRANSPORT_CEILING_25K,
    backside_requirement_table,
    build_report,
    discrimination_table,
    heated_clearing_case,
    heated_feasibility_row,
    heated_per_cycle_removal_nm,
)
from thermal_path_screen import arrhenius_rate_ratio


C22 = "kawarazaki_sicn_c22"
C40 = "kawarazaki_sicn_c40"
C5 = "kawarazaki_siocn_c5"
SIN = "kawarazaki_sin_reference"

WATER_TRIMER_EV = 0.8431133533886168
TRANSPORT_EV = 0.17
T60 = 333.15


def _material(row, key: str):
    return next(entry for entry in row["materials"] if entry["material"] == key)


class ArrheniusScalingTests(unittest.TestCase):
    def test_sixty_degrees_factors_span_the_candidate_barriers(self) -> None:
        """2x under transport, ~31x under the corrected water trimer."""

        self.assertAlmostEqual(
            arrhenius_rate_ratio(TRANSPORT_EV, 298.15, T60), 2.0, delta=0.05
        )
        self.assertAlmostEqual(
            arrhenius_rate_ratio(WATER_TRIMER_EV, 298.15, T60),
            31.4,
            delta=0.3,
        )

    def test_transport_ceiling_matches_the_repository_value(self) -> None:
        """The 1.67x reject line of the field-observation screen."""

        self.assertAlmostEqual(TRANSPORT_CEILING_25K, 1.668, delta=0.002)

    def test_dhf_component_scales_and_increment_does_not(self) -> None:
        removal = heated_per_cycle_removal_nm(
            C5,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=WATER_TRIMER_EV,
        )
        factor = removal["arrhenius_factor"]
        self.assertAlmostEqual(
            removal["central"], 0.25 * factor + 0.25, places=9
        )

    def test_scale_increment_exposes_the_optimistic_bound(self) -> None:
        scaled = heated_per_cycle_removal_nm(
            C5,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=WATER_TRIMER_EV,
            scale_increment=True,
        )
        factor = scaled["arrhenius_factor"]
        self.assertAlmostEqual(scaled["central"], 0.5 * factor, places=9)

    def test_invalid_efficiency_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            heated_per_cycle_removal_nm(
                C5,
                wet_reset_efficiency=1.5,
                interface_temperature_K=T60,
                activation_energy_eV=WATER_TRIMER_EV,
            )


class HeatedClearingTests(unittest.TestCase):
    def test_reaction_control_rescues_the_sin_like_film(self) -> None:
        """50 cycles at 25 C become 2 at 60 C under the 0.843 eV saddle."""

        case = heated_clearing_case(
            material_key=SIN,
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=WATER_TRIMER_EV,
        )
        self.assertEqual(case["cycles_hot"], 2)
        self.assertEqual(case["cycles_cold"], 50)
        self.assertEqual(case["cycles_saved"], 48)

    def test_transport_control_leaves_the_sin_film_stranded(self) -> None:
        """The same heater is a ~2x nothing under the transport null."""

        case = heated_clearing_case(
            material_key=SIN,
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=TRANSPORT_EV,
        )
        self.assertEqual(case["cycles_hot"], 25)

    def test_raster_floor_films_stay_unbounded_when_hot(self) -> None:
        """Heat multiplies the measurement's ignorance with its value."""

        for energy in (TRANSPORT_EV, WATER_TRIMER_EV):
            case = heated_clearing_case(
                material_key=C22,
                pad_thickness_nm=2.0,
                wet_reset_efficiency=1.0,
                interface_temperature_K=T60,
                activation_energy_eV=energy,
            )
            self.assertTrue(
                case["no_reset_unbounded_within_resolution"], energy
            )

    def test_cyclic_worst_raster_stays_bounded_for_c22(self) -> None:
        """The reset increment keeps the cyclic bound even at the floor."""

        case = heated_clearing_case(
            material_key=C22,
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=WATER_TRIMER_EV,
        )
        self.assertEqual(case["cycles_hot_worst_raster"], 1)


class HeatedFeasibilityTests(unittest.TestCase):
    def test_reaction_control_at_sixty_c_passes_the_full_matrix(self) -> None:
        """Even the SiN-like fill fits a 2 nm silicon budget when hot."""

        row = heated_feasibility_row(
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=WATER_TRIMER_EV,
            silicon_budget_nm=2.0,
        )
        self.assertTrue(row["all_materials_feasible"])

    def test_transport_control_keeps_the_cold_verdict(self) -> None:
        row = heated_feasibility_row(
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=TRANSPORT_EV,
            silicon_budget_nm=2.0,
        )
        self.assertFalse(row["all_materials_feasible"])
        self.assertTrue(row["carbon_materials_feasible"])
        self.assertFalse(_material(row, SIN)["feasible"])

    def test_silicon_saved_by_heating_is_reported(self) -> None:
        """48 avoided cycles are ~21 nm of silicon the walls never pay."""

        row = heated_feasibility_row(
            pad_thickness_nm=2.0,
            wet_reset_efficiency=1.0,
            interface_temperature_K=T60,
            activation_energy_eV=WATER_TRIMER_EV,
            silicon_budget_nm=2.0,
        )
        saved = _material(row, SIN)["silicon_saved_by_heating_nm"]
        self.assertAlmostEqual(saved, 48 * 0.4407, delta=0.01)

    def test_nonpositive_budget_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            heated_feasibility_row(
                pad_thickness_nm=2.0,
                wet_reset_efficiency=1.0,
                interface_temperature_K=T60,
                activation_energy_eV=WATER_TRIMER_EV,
                silicon_budget_nm=0.0,
            )


class DiscriminationTests(unittest.TestCase):
    def test_inversion_round_trips_every_candidate(self) -> None:
        """Measured improvement + known temperature -> apparent barrier."""

        table = discrimination_table()
        for row in table["rows"]:
            self.assertAlmostEqual(
                row["apparent_barrier_from_inversion_eV"],
                row["activation_energy_eV"],
                places=9,
            )

    def test_ceiling_is_reported_beside_the_predictions(self) -> None:
        table = discrimination_table()
        self.assertAlmostEqual(
            table["transport_ceiling_at_25K_full_coupling"],
            1.668,
            delta=0.002,
        )


class BacksideDeliveryTests(unittest.TestCase):
    def test_poor_coupling_demands_absurd_backside_overheat(self) -> None:
        """35 K at eta = 0.058 needs a 600 K backside setting."""

        table = backside_requirement_table()
        row = next(
            r
            for r in table["rows"]
            if r["interface_uplift_K"] == 35.0 and r["eta"] == 0.058
        )
        self.assertAlmostEqual(
            row["required_backside_overheat_K"], 603.4, delta=0.5
        )

    def test_hot_bath_alternative_is_stated(self) -> None:
        table = backside_requirement_table()
        self.assertIn("hot bath", table["note"])
        self.assertIn("bottom-selective", table["note"])


class ReportTests(unittest.TestCase):
    def test_report_sizes_match_the_declared_sweeps(self) -> None:
        report = build_report()
        self.assertEqual(len(report["clearing"]), 2 * 4 * 3 * 3 * 4)
        self.assertEqual(len(report["feasibility"]), 2 * 4 * 3 * 3 * 3)

    def test_report_declares_the_barrier_provenance(self) -> None:
        report = build_report()
        self.assertIn("superseding", report["barrier_provenance_note"])
        self.assertIn(
            "unresolved", report["barrier_provenance_note"]
        )
        self.assertAlmostEqual(
            report["barrier_candidates_eV"][
                "siocn_water_trimer_hydrolysis_corrected"
            ],
            WATER_TRIMER_EV,
            places=12,
        )

    def test_report_rejects_subreference_temperatures(self) -> None:
        with self.assertRaises(ValueError):
            build_report(interface_temperatures_K=(298.15,))

    def test_reading_notes_carry_the_double_payoff(self) -> None:
        notes = build_report()["reading_notes"]
        self.assertIn("oxidation the", notes["double_payoff"])
        self.assertIn("game-changer", notes["barrier_decides"])


if __name__ == "__main__":
    unittest.main()

"""Sequential HF/rinse/second-WET orchestration with explicit state semantics.

The runner is solver-agnostic: a callable advances an arbitrary substrate state
for one requested interval.  This lets the same sequence control a scalar
mean-field model, a 1-D transport model, or a 2-D moving-interface solver.
Solution-bulk and substrate-backside temperatures remain independent fields on
every step.  A solver must resolve the local interface temperature; this module
never averages those boundary temperatures implicitly.

Built-in mechanism presets describe model topology and qualitative relative
reactivity only.  They are deliberately marked uncalibrated and are not
chemical recipes, operating windows, or safety instructions.
"""

from __future__ import annotations

import copy
import math
import operator
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Callable, Iterable, Mapping, Protocol, Sequence

from numerical_settings import LOOSE_NUMERICS
from surface_chemistry import (
    LocalInterfaceConditions,
    MeanFieldKineticParameters,
    MeanFieldSurfaceChemistry,
    MeanFieldSurfaceState,
    ReactionMode,
    SurfaceMaterial,
)


PLACEHOLDER_NOTICE = (
    "Parameterized model placeholder only; calibrate to measured film chemistry "
    "and fab-qualified conditions. Not a wet-process recipe."
)


@dataclass(frozen=True)
class MechanismPreset:
    key: str
    reaction_mode: ReactionMode | str
    relative_material_rates: Mapping[SurfaceMaterial | str, float]
    intent: str
    limitations: str
    calibrated: bool = False
    is_recipe: bool = False

    def __post_init__(self) -> None:
        if not self.key:
            raise ValueError("preset key must not be empty")
        object.__setattr__(self, "reaction_mode", ReactionMode(self.reaction_mode))
        rates: dict[SurfaceMaterial, float] = {}
        for material, value in self.relative_material_rates.items():
            number = float(value)
            if not math.isfinite(number) or number < 0.0:
                raise ValueError("relative material rates must be nonnegative")
            rates[SurfaceMaterial(material)] = number
        for material in SurfaceMaterial:
            rates.setdefault(material, 0.0)
        object.__setattr__(self, "relative_material_rates", MappingProxyType(rates))
        if self.calibrated or self.is_recipe:
            raise ValueError("built-in mechanism presets must remain uncalibrated")

    @property
    def notice(self) -> str:
        return PLACEHOLDER_NOTICE

    def calibrated_parameters(
        self,
        *,
        rate_constant_ref_s: float,
        reference_temperature_K: float,
        activation_energy_J_mol: float,
        **kinetic_overrides: float,
    ) -> MeanFieldKineticParameters:
        """Create a model only after the caller supplies calibration values."""

        return MeanFieldKineticParameters(
            reaction_mode=self.reaction_mode,
            rate_constant_ref_s=rate_constant_ref_s,
            reference_temperature_K=reference_temperature_K,
            activation_energy_J_mol=activation_energy_J_mol,
            material_rate_factors=self.relative_material_rates,
            **kinetic_overrides,
        )


_MECHANISM_PRESETS = {
    "hf": MechanismPreset(
        key="hf",
        reaction_mode=ReactionMode.DIRECT_ETCH,
        relative_material_rates={"SiN": 1.0, "SiCN": 0.1, "SiOCN": 0.1},
        intent="Initial fluoride-family direct removal with product inhibition.",
        limitations=(
            "SiCN/SiOCN factors are qualitative and strongly "
            "film-composition dependent; use film-specific blanket anchors."
        ),
    ),
    "rinse": MechanismPreset(
        key="rinse",
        reaction_mode=ReactionMode.RINSE,
        relative_material_rates={"SiN": 0.0, "SiCN": 0.0, "SiOCN": 0.0},
        intent="Fresh-solution exchange and removal of soluble/interfacial products.",
        limitations="Hydrodynamics, salt solubility, drying, and bubble release need a transport model.",
    ),
    "phosphoric_like": MechanismPreset(
        key="phosphoric_like",
        reaction_mode=ReactionMode.DIRECT_ETCH,
        relative_material_rates={"SiN": 1.0, "SiCN": 0.02, "SiOCN": 0.02},
        intent="Parameterized Si-N hydrolysis branch for low-carbon nitride.",
        limitations=(
            "Not validated for carbon-rich SiCN/SiOCN; no temperature or "
            "composition is prescribed."
        ),
    ),
    "oxidative_conversion": MechanismPreset(
        key="oxidative_conversion",
        reaction_mode=ReactionMode.OXIDATIVE_CONVERSION,
        relative_material_rates={"SiN": 0.2, "SiCN": 1.0, "SiOCN": 1.0},
        intent="Convert carbon-containing material toward an oxide-like removable phase.",
        limitations=(
            "Conversion is not removal. Kawarazaki Fig. 2 shows strong "
            "composition dependence; verify C loss and Si-O growth analytically."
        ),
    ),
    "fluoride_after_oxidation": MechanismPreset(
        key="fluoride_after_oxidation",
        reaction_mode=ReactionMode.ETCH_CONVERTED,
        relative_material_rates={"SiN": 1.0, "SiCN": 1.0, "SiOCN": 1.0},
        intent="Remove only the inventory previously marked as oxidatively converted.",
        limitations="Must be a separately modelled step; oxidant carryover and Si loss are not encoded.",
    ),
}
MECHANISM_PRESETS: Mapping[str, MechanismPreset] = MappingProxyType(
    _MECHANISM_PRESETS
)


def get_mechanism_preset(name: str) -> MechanismPreset:
    key = str(name).strip().lower().replace("-", "_")
    aliases = {
        "phosphoric": "phosphoric_like",
        "oxidation": "oxidative_conversion",
        "post_oxidation_fluoride": "fluoride_after_oxidation",
    }
    key = aliases.get(key, key)
    try:
        return MECHANISM_PRESETS[key]
    except KeyError as exc:
        choices = ", ".join(sorted(MECHANISM_PRESETS))
        raise KeyError(f"unknown mechanism preset {name!r}; choose {choices}") from exc


class StateMode(str, Enum):
    CARRY = "carry"
    RESET = "reset"
    CLEAR_INTERFACIAL = "clear_interfacial"


@dataclass(frozen=True)
class StepStateSemantics:
    """Boundary handling before a step begins."""

    solution: StateMode | str = StateMode.RESET
    surface: StateMode | str = StateMode.CARRY
    substrate: StateMode | str = StateMode.CARRY

    def __post_init__(self) -> None:
        solution = StateMode(self.solution)
        surface = StateMode(self.surface)
        substrate = StateMode(self.substrate)
        if solution is StateMode.CLEAR_INTERFACIAL:
            raise ValueError("CLEAR_INTERFACIAL is only valid for surface state")
        if substrate is StateMode.CLEAR_INTERFACIAL:
            raise ValueError("CLEAR_INTERFACIAL is only valid for surface state")
        object.__setattr__(self, "solution", solution)
        object.__setattr__(self, "surface", surface)
        object.__setattr__(self, "substrate", substrate)


class StopCriterion(Protocol):
    name: str
    terminate_sequence: bool

    def evaluate(
        self, state: "WetProcessState", metrics: Mapping[str, float]
    ) -> bool: ...


_COMPARISONS: Mapping[str, Callable[[float, float], bool]] = {
    ">=": operator.ge,
    ">": operator.gt,
    "<=": operator.le,
    "<": operator.lt,
    "==": operator.eq,
}


@dataclass(frozen=True)
class MetricStopCriterion:
    metric: str
    threshold: float
    comparison: str = ">="
    name: str | None = None
    terminate_sequence: bool = False

    def __post_init__(self) -> None:
        if self.comparison not in _COMPARISONS:
            raise ValueError(f"unsupported comparison {self.comparison!r}")
        threshold = float(self.threshold)
        if not math.isfinite(threshold):
            raise ValueError("stop threshold must be finite")
        object.__setattr__(self, "threshold", threshold)
        if self.name is None:
            object.__setattr__(
                self,
                "name",
                f"{self.metric}{self.comparison}{self.threshold:g}",
            )

    def evaluate(
        self, state: "WetProcessState", metrics: Mapping[str, float]
    ) -> bool:
        del state
        if self.metric not in metrics:
            return False
        return _COMPARISONS[self.comparison](
            float(metrics[self.metric]), self.threshold
        )


@dataclass(frozen=True)
class CallableStopCriterion:
    name: str
    predicate: Callable[["WetProcessState", Mapping[str, float]], bool]
    terminate_sequence: bool = False

    def evaluate(
        self, state: "WetProcessState", metrics: Mapping[str, float]
    ) -> bool:
        return bool(self.predicate(state, metrics))


@dataclass(frozen=True)
class WetStep:
    name: str
    mechanism: MechanismPreset | str
    duration_s: float
    solution_temperature_K: float
    substrate_temperature_K: float
    solver_increment_s: float | None = None
    state_semantics: StepStateSemantics = field(default_factory=StepStateSemantics)
    solution_inputs: Mapping[str, Any] = field(default_factory=dict)
    stop_criteria: Sequence[StopCriterion] = field(default_factory=tuple)
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("step name must not be empty")
        mechanism = (
            get_mechanism_preset(self.mechanism)
            if isinstance(self.mechanism, str)
            else self.mechanism
        )
        if not isinstance(mechanism, MechanismPreset):
            raise TypeError("mechanism must be a preset or preset name")
        object.__setattr__(self, "mechanism", mechanism)
        duration = float(self.duration_s)
        if not math.isfinite(duration) or duration < 0.0:
            raise ValueError("duration_s must be finite and nonnegative")
        object.__setattr__(self, "duration_s", duration)
        for name in ("solution_temperature_K", "substrate_temperature_K"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        increment = self.solver_increment_s
        if increment is not None:
            increment = float(increment)
            if not math.isfinite(increment) or increment <= 0.0:
                raise ValueError("solver_increment_s must be finite and positive")
            object.__setattr__(self, "solver_increment_s", increment)
        if not isinstance(self.state_semantics, StepStateSemantics):
            raise TypeError("state_semantics must be StepStateSemantics")
        object.__setattr__(self, "solution_inputs", dict(self.solution_inputs))
        object.__setattr__(self, "stop_criteria", tuple(self.stop_criteria))
        object.__setattr__(self, "metadata", dict(self.metadata))


@dataclass
class WetProcessState:
    """Generic carrier for continuum/KMC state between WET steps."""

    substrate_state: Any = None
    surface_state: Any = None
    solution_state: dict[str, Any] = field(default_factory=dict)
    elapsed_s: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        elapsed = float(self.elapsed_s)
        if not math.isfinite(elapsed) or elapsed < 0.0:
            raise ValueError("elapsed_s must be finite and nonnegative")
        self.elapsed_s = elapsed
        self.solution_state = dict(self.solution_state)
        self.metadata = dict(self.metadata)

    def copied(self) -> "WetProcessState":
        return copy.deepcopy(self)


@dataclass(frozen=True)
class SolverAdvance:
    state: WetProcessState
    elapsed_s: float
    metrics: Mapping[str, float] = field(default_factory=dict)
    terminal_reason: str | None = None
    terminate_sequence: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.state, WetProcessState):
            raise TypeError("solver advance state must be WetProcessState")
        elapsed = float(self.elapsed_s)
        if not math.isfinite(elapsed) or elapsed < 0.0:
            raise ValueError("solver elapsed_s must be finite and nonnegative")
        object.__setattr__(self, "elapsed_s", elapsed)
        numeric: dict[str, float] = {}
        for name, value in self.metrics.items():
            number = float(value)
            if not math.isfinite(number):
                raise ValueError(f"metric {name!r} must be finite")
            numeric[str(name)] = number
        object.__setattr__(self, "metrics", numeric)


class SolverAdapter(Protocol):
    def __call__(
        self, state: WetProcessState, step: WetStep, requested_duration_s: float
    ) -> SolverAdvance: ...


@dataclass(frozen=True)
class MetricSample:
    absolute_time_s: float
    step_elapsed_s: float
    values: Mapping[str, float]


@dataclass(frozen=True)
class WetStepResult:
    step: WetStep
    start_time_s: float
    end_time_s: float
    elapsed_s: float
    stop_reason: str
    stopped_early: bool
    final_metrics: Mapping[str, float]
    metric_history: tuple[MetricSample, ...]


@dataclass(frozen=True)
class WetSequenceResult:
    final_state: WetProcessState
    step_results: tuple[WetStepResult, ...]
    total_elapsed_s: float
    stop_reason: str
    metrics: Mapping[str, float]


def _clear_interfacial(surface_state: Any) -> Any:
    if surface_state is None:
        return None
    if isinstance(surface_state, MeanFieldSurfaceState):
        return surface_state.clear_interfacial()
    if isinstance(surface_state, Mapping):
        copied = copy.deepcopy(dict(surface_state))
        for key in ("product_coverage", "passivation_coverage"):
            if key in copied:
                copied[key] = 0.0
        return copied
    clear = getattr(surface_state, "clear_interfacial", None)
    if callable(clear):
        return clear()
    raise TypeError(
        "CLEAR_INTERFACIAL requires MeanFieldSurfaceState, a mapping, or "
        "an object with clear_interfacial()"
    )


class WetSequenceRunner:
    """Apply state-boundary policies, advance a solver, and evaluate stops."""

    def __init__(
        self,
        solver_adapter: SolverAdapter,
        *,
        copy_initial_state: bool = True,
    ) -> None:
        if not callable(solver_adapter):
            raise TypeError("solver_adapter must be callable")
        self.solver_adapter = solver_adapter
        self.copy_initial_state = bool(copy_initial_state)

    @staticmethod
    def _prepare_step_state(
        current: WetProcessState,
        baseline: WetProcessState,
        step: WetStep,
    ) -> WetProcessState:
        state = current.copied()
        semantics = step.state_semantics
        if semantics.substrate is StateMode.RESET:
            state.substrate_state = copy.deepcopy(baseline.substrate_state)
        if semantics.surface is StateMode.RESET:
            state.surface_state = copy.deepcopy(baseline.surface_state)
        elif semantics.surface is StateMode.CLEAR_INTERFACIAL:
            state.surface_state = _clear_interfacial(state.surface_state)
        if semantics.solution is StateMode.RESET:
            state.solution_state = {}
        state.solution_state.update(copy.deepcopy(dict(step.solution_inputs)))
        return state

    @staticmethod
    def _matched_criterion(
        criteria: Iterable[StopCriterion],
        state: WetProcessState,
        metrics: Mapping[str, float],
    ) -> StopCriterion | None:
        for criterion in criteria:
            if not hasattr(criterion, "evaluate"):
                raise TypeError("stop criteria must provide evaluate(state, metrics)")
            if criterion.evaluate(state, metrics):
                return criterion
        return None

    def run(
        self,
        initial_state: WetProcessState,
        steps: Sequence[WetStep],
        *,
        sequence_stop_criteria: Sequence[StopCriterion] = (),
    ) -> WetSequenceResult:
        if not isinstance(initial_state, WetProcessState):
            raise TypeError("initial_state must be WetProcessState")
        normalized_steps = tuple(steps)
        if any(not isinstance(step, WetStep) for step in normalized_steps):
            raise TypeError("steps must contain WetStep objects")
        sequence_criteria = tuple(sequence_stop_criteria)
        baseline = initial_state.copied()
        state = initial_state.copied() if self.copy_initial_state else initial_state
        sequence_start = state.elapsed_s
        results: list[WetStepResult] = []
        sequence_reason = "completed"
        terminate = False

        for step in normalized_steps:
            state = self._prepare_step_state(state, baseline, step)
            step_start = state.elapsed_s
            step_elapsed = 0.0
            final_metrics: dict[str, float] = {}
            samples: list[MetricSample] = []
            stop_reason = "duration"
            while step_elapsed < step.duration_s:
                remaining = step.duration_s - step_elapsed
                requested = min(
                    remaining,
                    step.solver_increment_s
                    if step.solver_increment_s is not None
                    else remaining,
                )
                prior_absolute_time = state.elapsed_s
                advance = self.solver_adapter(state, step, requested)
                if not isinstance(advance, SolverAdvance):
                    raise TypeError("solver_adapter must return SolverAdvance")
                actual = advance.elapsed_s
                if actual <= 0.0 and advance.terminal_reason is None:
                    raise RuntimeError(
                        "solver returned zero elapsed time without a terminal reason"
                    )
                if actual > requested * (1.0 + LOOSE_NUMERICS.linear_relative_tolerance):
                    raise RuntimeError("solver advanced beyond the requested interval")
                state = advance.state
                state.elapsed_s = prior_absolute_time + actual
                step_elapsed += actual
                final_metrics.update(advance.metrics)
                samples.append(
                    MetricSample(
                        absolute_time_s=state.elapsed_s,
                        step_elapsed_s=step_elapsed,
                        values=dict(final_metrics),
                    )
                )

                if advance.terminal_reason is not None:
                    stop_reason = f"adapter:{advance.terminal_reason}"
                    terminate = advance.terminate_sequence
                    break
                criterion = self._matched_criterion(
                    step.stop_criteria, state, final_metrics
                )
                if criterion is not None:
                    stop_reason = f"criterion:{criterion.name}"
                    terminate = bool(criterion.terminate_sequence)
                    break
                sequence_criterion = self._matched_criterion(
                    sequence_criteria, state, final_metrics
                )
                if sequence_criterion is not None:
                    stop_reason = f"criterion:{sequence_criterion.name}"
                    sequence_reason = stop_reason
                    terminate = True
                    break

            stopped_early = step_elapsed < step.duration_s * (
                1.0 - LOOSE_NUMERICS.linear_relative_tolerance
            )
            results.append(
                WetStepResult(
                    step=step,
                    start_time_s=step_start,
                    end_time_s=state.elapsed_s,
                    elapsed_s=step_elapsed,
                    stop_reason=stop_reason,
                    stopped_early=stopped_early,
                    final_metrics=dict(final_metrics),
                    metric_history=tuple(samples),
                )
            )
            if terminate:
                if sequence_reason == "completed":
                    sequence_reason = stop_reason
                break

        total_elapsed = state.elapsed_s - sequence_start
        summary: dict[str, float] = {
            "total_elapsed_s": total_elapsed,
            "steps_run": float(len(results)),
            "steps_stopped_early": float(
                sum(result.stopped_early for result in results)
            ),
        }
        for result in results:
            for name, value in result.final_metrics.items():
                summary[f"{result.step.name}.{name}"] = value
        return WetSequenceResult(
            final_state=state,
            step_results=tuple(results),
            total_elapsed_s=total_elapsed,
            stop_reason=sequence_reason,
            metrics=summary,
        )


ModelResolver = Callable[[WetStep], MeanFieldSurfaceChemistry]
ConditionResolver = Callable[
    [WetProcessState, WetStep], LocalInterfaceConditions
]
MaterialResolver = Callable[[WetProcessState, WetStep], SurfaceMaterial | str]


class MeanFieldSolverAdapter:
    """Optional bridge from :class:`WetSequenceRunner` to the local model.

    ``condition_resolver`` is mandatory so the caller explicitly supplies the
    local interface temperature and activities/concentrations.  In particular,
    the adapter never derives it by averaging the two step temperatures.
    """

    def __init__(
        self,
        model_resolver: ModelResolver,
        condition_resolver: ConditionResolver,
        material: SurfaceMaterial | str | MaterialResolver,
    ) -> None:
        if not callable(model_resolver) or not callable(condition_resolver):
            raise TypeError("model_resolver and condition_resolver must be callable")
        self.model_resolver = model_resolver
        self.condition_resolver = condition_resolver
        self.material = material

    def __call__(
        self,
        state: WetProcessState,
        step: WetStep,
        requested_duration_s: float,
    ) -> SolverAdvance:
        if not isinstance(state.surface_state, MeanFieldSurfaceState):
            raise TypeError("MeanFieldSolverAdapter requires MeanFieldSurfaceState")
        model = self.model_resolver(step)
        if not isinstance(model, MeanFieldSurfaceChemistry):
            raise TypeError("model_resolver must return MeanFieldSurfaceChemistry")
        conditions = self.condition_resolver(state, step)
        if not isinstance(conditions, LocalInterfaceConditions):
            raise TypeError("condition_resolver must return LocalInterfaceConditions")
        material = (
            self.material(state, step) if callable(self.material) else self.material
        )
        result = model.advance(
            material,
            state.surface_state,
            conditions,
            requested_duration_s,
        )
        advanced_state = state.copied()
        advanced_state.surface_state = result.state
        return SolverAdvance(
            state=advanced_state,
            elapsed_s=requested_duration_s,
            metrics={
                "reaction_extent": result.reaction_extent,
                "reaction_rate": result.final_rate.reaction_rate_coverage_s,
                "material_coverage": result.state.material_coverage,
                "converted_coverage": result.state.converted_coverage,
                "product_coverage": result.state.product_coverage,
                "passivation_coverage": result.state.passivation_coverage,
            },
        )


__all__ = [
    "CallableStopCriterion",
    "MECHANISM_PRESETS",
    "MeanFieldSolverAdapter",
    "MechanismPreset",
    "MetricSample",
    "MetricStopCriterion",
    "PLACEHOLDER_NOTICE",
    "SolverAdapter",
    "SolverAdvance",
    "StateMode",
    "StepStateSemantics",
    "WetProcessState",
    "WetSequenceResult",
    "WetSequenceRunner",
    "WetStep",
    "WetStepResult",
    "get_mechanism_preset",
]

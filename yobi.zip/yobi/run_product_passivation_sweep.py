#!/usr/bin/env python3
"""CLI for the dissolved-product/passivation mechanism sweep."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

from literature_parameters import LITERATURE_ETCH_PRESETS
from literature_sweep import nominal_preset_names
from product_passivation_sweep import (
    PRODUCT_PASSIVATION_SCENARIOS,
    ProductPassivationSweepConfig,
    run_product_passivation_sweep,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run literature-timescale 2-D product/passivation sensitivities. "
            "The mechanism coefficients are explicit uncalibrated hypotheses."
        )
    )
    parser.add_argument(
        "--geometry", choices=tuple(GEOMETRY_PRESETS), action="append"
    )
    parser.add_argument(
        "--preset", choices=tuple(LITERATURE_ETCH_PRESETS), action="append"
    )
    parser.add_argument(
        "--scenario",
        choices=tuple(PRODUCT_PASSIVATION_SCENARIOS),
        action="append",
    )
    parser.add_argument("--target-remaining", type=float, action="append")
    parser.add_argument("--sample-clear-time", type=float, action="append")
    parser.add_argument(
        "--sample-time-s",
        type=float,
        action="append",
        help=(
            "absolute physical checkpoint [s]; repeatable and reported in "
            "addition to normalized planar-clear checkpoints"
        ),
    )
    parser.add_argument("--grid-spacing-nm", type=float, default=1.0)
    parser.add_argument("--reservoir-height-nm", type=float, default=10.0)
    parser.add_argument(
        "--maximum-fractional-front-change", type=float, default=0.50
    )
    parser.add_argument("--solution-temperature-k", type=float, default=298.15)
    parser.add_argument("--substrate-temperature-k", type=float, default=298.15)
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent case processes; 0 selects up to 4 automatically",
    )
    parser.add_argument("--list-scenarios", action="store_true")
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    if args.list_scenarios:
        payload: dict[str, object] = {
            "scenarios": {
                key: value.to_dict()
                for key, value in PRODUCT_PASSIVATION_SCENARIOS.items()
            }
        }
    else:
        geometries = tuple(dict.fromkeys(args.geometry or DEFAULT_GEOMETRY_NAMES))
        presets = tuple(dict.fromkeys(args.preset or nominal_preset_names()))
        scenarios = tuple(
            dict.fromkeys(args.scenario or PRODUCT_PASSIVATION_SCENARIOS)
        )
        targets = tuple(dict.fromkeys(args.target_remaining or (0.50, 0.10)))
        times = tuple(dict.fromkeys(args.sample_clear_time or (0.50, 1.0, 2.0)))
        absolute_times = tuple(dict.fromkeys(args.sample_time_s or ()))
        case_count = len(geometries) * len(presets) * len(scenarios)
        if args.workers < 0:
            raise ValueError("workers must be zero or a positive integer")
        workers = (
            min(4, os.cpu_count() or 1, case_count)
            if args.workers == 0
            else min(args.workers, case_count)
        )
        payload = run_product_passivation_sweep(
            ProductPassivationSweepConfig(
                geometries=geometries,
                presets=presets,
                scenarios=scenarios,
                target_remaining_fractions=targets,
                sample_time_over_planar_clear=times,
                sample_times_s=absolute_times,
                grid_spacing_nm=args.grid_spacing_nm,
                reservoir_height_nm=args.reservoir_height_nm,
                maximum_fractional_front_change=(
                    args.maximum_fractional_front_change
                ),
                solution_bulk_temperature_K=args.solution_temperature_k,
                substrate_backside_temperature_K=args.substrate_temperature_k,
                parallel_workers=workers,
            )
        )
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    if args.output is None:
        print(text)
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    return payload


if __name__ == "__main__":
    main()

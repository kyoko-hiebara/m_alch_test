from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from graph_kmc_velocity_sweep import (
    GraphKMCVelocitySweepConfig,
    NOMINAL_PRESET_BY_MATERIAL,
    PatchEnvironment,
    build_surface_patch_kmc,
    run_graph_kmc_velocity_sweep,
)
from run_graph_kmc_velocity_sweep import main


def removal_count(model) -> int:
    return int(
        sum(site.attributes["removal_count"] for site in model.graph.sites.values())
    )


class GraphKMCVelocitySweepTests(unittest.TestCase):
    def test_nominal_blanket_anchors_are_material_specific(self) -> None:
        sin = NOMINAL_PRESET_BY_MATERIAL["SiN"]
        siocn = NOMINAL_PRESET_BY_MATERIAL["SiOCN"]
        self.assertEqual(sin.key, "sin_barcellona_b_0p55wt")
        self.assertEqual(siocn.key, "siocn_fujitsu_4b_100to1")
        self.assertAlmostEqual(sin.planar_rate_nm_min, 2.2)
        self.assertAlmostEqual(siocn.planar_rate_nm_min, 0.38)
        self.assertIsNotNone(sin.planar_rate_uncertainty_nm_min)
        self.assertIsNone(siocn.planar_rate_uncertainty_nm_min)
        self.assertEqual(sin.reported_solution_temperature_K, 298.15)
        self.assertIsNone(siocn.reported_solution_temperature_K)

    def test_surface_patch_is_periodic_and_regenerative(self) -> None:
        model = build_surface_patch_kmc(
            8,
            "SiN",
            PatchEnvironment(),
            seed=17,
        )
        for site_id in model.graph.site_ids:
            self.assertEqual(len(model.graph.neighbors(site_id)), 2)
            self.assertEqual(model.graph.sites[site_id].attributes["surface_column"], 1.0)
        result = model.run(
            max_events=500,
            stop_condition=lambda kmc: removal_count(kmc) >= 24,
        )
        self.assertEqual(result.stop_reason, "stop_condition")
        self.assertEqual(removal_count(model), 24)
        self.assertEqual(result.event_counts["remove"], 24)
        self.assertNotIn("removed", result.final_state_counts)

    def test_reference_is_exactly_one_and_materials_share_modifier(self) -> None:
        config = GraphKMCVelocitySweepConfig(
            site_counts=(4, 8),
            environment_site_count=8,
            replicas=3,
            temperatures_K=(298.15,),
            hf_activities=(1.0,),
            product_activities=(0.0, 0.5),
            warmup_layers=1,
            measurement_layers=3,
            workers=1,
            root_seed=91,
        )
        payload = run_graph_kmc_velocity_sweep(config)
        by_key = {
            (
                row["material"],
                row["environment"]["product_activity"],
            ): row
            for row in payload["environment_table"]
        }
        for material in ("SiN", "SiOCN"):
            reference = by_key[(material, 0.0)]
            self.assertEqual(reference["relative_modifier"]["value"], 1.0)
            self.assertEqual(
                reference["relative_modifier"]["paired_bootstrap_95ci_low"],
                1.0,
            )
            self.assertAlmostEqual(
                reference["absolute_velocity_nm_min"]["value"],
                NOMINAL_PRESET_BY_MATERIAL[material].planar_rate_nm_min,
            )
        self.assertEqual(
            by_key[("SiN", 0.5)]["relative_modifier"],
            by_key[("SiOCN", 0.5)]["relative_modifier"],
        )
        self.assertLess(by_key[("SiN", 0.5)]["relative_modifier"]["value"], 1.0)

    def test_environment_response_and_serial_reproducibility(self) -> None:
        config = GraphKMCVelocitySweepConfig(
            site_counts=(8,),
            environment_site_count=12,
            replicas=6,
            temperatures_K=(298.15, 323.15),
            hf_activities=(0.25, 1.0),
            product_activities=(0.0, 0.5),
            materials=("SiN",),
            warmup_layers=1,
            measurement_layers=5,
            workers=1,
            root_seed=1234,
        )
        first = run_graph_kmc_velocity_sweep(config)
        second = run_graph_kmc_velocity_sweep(config)
        self.assertEqual(first, second)
        rows = {
            (
                row["environment"]["temperature_K"],
                row["environment"]["hf_activity"],
                row["environment"]["product_activity"],
            ): row["relative_modifier"]["value"]
            for row in first["environment_table"]
        }
        self.assertLess(rows[(298.15, 0.25, 0.0)], 1.0)
        self.assertLess(rows[(298.15, 1.0, 0.5)], 1.0)
        self.assertGreater(rows[(323.15, 1.0, 0.0)], 1.0)
        provenance = first["parameter_provenance"]
        self.assertIn("literature_observation_and_derived_rate", provenance)
        self.assertIn("uncalibrated_assumptions", provenance)

    def test_cli_writes_strict_plain_json(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "kmc_velocity.json"
            payload = main(
                [
                    "--site-count",
                    "4",
                    "--environment-site-count",
                    "4",
                    "--replicas",
                    "2",
                    "--temperature-k",
                    "298.15",
                    "--hf-activity",
                    "1",
                    "--product-activity",
                    "0",
                    "--material",
                    "SiOCN",
                    "--warmup-layers",
                    "1",
                    "--measurement-layers",
                    "2",
                    "--workers",
                    "1",
                    "--output",
                    str(output),
                ]
            )
            saved = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(saved, payload)
            self.assertEqual(
                saved["case_counts"]["environment_condition_replicates"], 2
            )
            self.assertFalse(saved["calibration_status"]["process_recipe"])


if __name__ == "__main__":
    unittest.main()

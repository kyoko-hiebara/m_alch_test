#!/usr/bin/env python3
"""Pack neutral H2O and HF molecules into a periodic Si trench model.

The input is an extended XYZ produced by ``build_trench.py`` or a compatible
file supplied with explicit trench-coordinate overrides.  X and Y are
periodic; Z is nonperiodic.  ``--fill-depth`` is measured downward from the
nominal trench top.  An optional reservoir can be added above that plane.

This is a compositionally correct *neutral-molecule* starting model, not an
equilibrium speciation model for aqueous HF.  It contains no H3O+, F-, or
HF2-.  Relax and equilibrate it with a suitable HF/water/surface model before
production calculations.
"""

from __future__ import annotations

import argparse
import math
import os
import re
import shlex
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np


AVOGADRO = 6.02214076e23
MOLAR_MASS_H2O = 18.01528
MOLAR_MASS_HF = 20.006343
WATER_OH = 0.9572
WATER_ANGLE_DEGREES = 104.52
HF_BOND = 0.917
MOLECULE_RADIUS = max(WATER_OH, HF_BOND)
TOL = 1.0e-8


@dataclass(frozen=True)
class PropertySpec:
    name: str
    kind: str
    count: int


@dataclass
class ExtendedXYZ:
    properties: list[PropertySpec]
    rows: list[list[str]]
    species: np.ndarray
    positions: np.ndarray
    cell: np.ndarray
    metadata: dict[str, str]
    metadata_order: list[str]


@dataclass(frozen=True)
class TrenchGeometry:
    length_x: float
    length_y: float
    length_z: float
    y_left: float
    trench_width: float
    z_floor: float
    z_top: float
    sin_mode: str

    @property
    def trench_depth(self) -> float:
        return self.z_top - self.z_floor


@dataclass(frozen=True)
class RegionBox:
    y_origin: float
    y_length: float
    z_low: float
    z_high: float

    def volume(self, length_x: float) -> float:
        return length_x * self.y_length * (self.z_high - self.z_low)


@dataclass(frozen=True)
class LiquidRegion:
    geometry: TrenchGeometry
    fill_depth: float
    reservoir_height: float
    trench_liquid: str

    @property
    def z_lower(self) -> float:
        if self.trench_liquid == "exclude":
            return self.geometry.z_top
        return self.geometry.z_top - self.fill_depth

    @property
    def z_upper(self) -> float:
        return self.geometry.z_top + self.reservoir_height

    def boxes(self) -> tuple[RegionBox, ...]:
        boxes: list[RegionBox] = []
        if self.trench_liquid == "include" and self.fill_depth > TOL:
            boxes.append(
                RegionBox(
                    y_origin=self.geometry.y_left,
                    y_length=self.geometry.trench_width,
                    z_low=self.z_lower,
                    z_high=self.geometry.z_top,
                )
            )
        if self.reservoir_height > TOL:
            boxes.append(
                RegionBox(
                    y_origin=0.0,
                    y_length=self.geometry.length_y,
                    z_low=self.geometry.z_top,
                    z_high=self.z_upper,
                )
            )
        return tuple(boxes)

    def contains(self, position: np.ndarray) -> bool:
        y = float(position[1]) % self.geometry.length_y
        z = float(position[2])
        in_reservoir = (
            self.reservoir_height > TOL
            and z >= self.geometry.z_top - TOL
            and z <= self.z_upper + TOL
        )
        if in_reservoir:
            return True
        if self.trench_liquid != "include" or self.fill_depth <= TOL:
            return False
        relative_y = (y - self.geometry.y_left) % self.geometry.length_y
        return (
            relative_y >= -TOL
            and relative_y <= self.geometry.trench_width + TOL
            and z >= self.z_lower - TOL
            and z <= self.geometry.z_top + TOL
        )


@dataclass(frozen=True)
class Composition:
    n_h2o: int
    n_hf: int
    target_wt_percent: float
    actual_wt_percent: float
    target_density: float | None
    actual_density: float
    count_volume: float
    packing_volume: float

    @property
    def total_molecules(self) -> int:
        return self.n_h2o + self.n_hf


@dataclass
class PackingResult:
    molecule_kinds: list[str]
    molecule_species: list[np.ndarray]
    molecule_positions: list[np.ndarray]
    attempts: int
    restart: int

    @property
    def molecule_count(self) -> int:
        return len(self.molecule_kinds)


@dataclass(frozen=True)
class FillStats:
    accessible_volume: float
    geometric_volume: float
    count_volume: float
    volume_basis: str
    volume_samples: int
    requested_h2o: int
    requested_hf: int
    placed_h2o: int
    placed_hf: int
    target_wt_percent: float
    actual_wt_percent: float
    target_density: float | None
    actual_density: float
    geometric_loading_density: float
    attempts: int
    restart: int


def parse_comment(comment: str) -> tuple[dict[str, str], list[str]]:
    try:
        tokens = shlex.split(comment, posix=True)
    except ValueError as exc:
        raise ValueError(f"invalid extended-XYZ comment: {exc}") from exc
    metadata: dict[str, str] = {}
    order: list[str] = []
    for token in tokens:
        if "=" not in token:
            raise ValueError(f"extended-XYZ comment token lacks '=': {token!r}")
        key, value = token.split("=", 1)
        if not key or key in metadata:
            raise ValueError(f"duplicate or empty extended-XYZ metadata key: {key!r}")
        metadata[key] = value
        order.append(key)
    return metadata, order


def parse_properties(value: str) -> list[PropertySpec]:
    fields = value.split(":")
    if len(fields) % 3:
        raise ValueError("Properties field must contain name:type:count triples")
    result: list[PropertySpec] = []
    seen: set[str] = set()
    for start in range(0, len(fields), 3):
        name, kind, raw_count = fields[start : start + 3]
        if not name or name in seen:
            raise ValueError(f"duplicate or empty property name: {name!r}")
        if kind not in {"S", "R", "I", "L"}:
            raise ValueError(f"unsupported property type {kind!r} for {name!r}")
        try:
            count = int(raw_count)
        except ValueError as exc:
            raise ValueError(f"invalid column count for property {name!r}") from exc
        if count < 1:
            raise ValueError(f"property {name!r} must occupy at least one column")
        result.append(PropertySpec(name, kind, count))
        seen.add(name)
    return result


def property_offsets(properties: Sequence[PropertySpec]) -> dict[str, tuple[int, PropertySpec]]:
    result: dict[str, tuple[int, PropertySpec]] = {}
    offset = 0
    for spec in properties:
        result[spec.name] = (offset, spec)
        offset += spec.count
    return result


def read_extended_xyz(path: Path) -> ExtendedXYZ:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc
    if len(lines) < 2:
        raise ValueError(f"{path} is not a valid XYZ file")
    try:
        natoms = int(lines[0].strip())
    except ValueError as exc:
        raise ValueError(f"first line of {path} must be an atom count") from exc
    if natoms < 0 or len(lines) < natoms + 2:
        raise ValueError(f"{path} declares {natoms} atoms but is truncated")
    if any(line.strip() for line in lines[natoms + 2 :]):
        raise ValueError(
            f"{path} contains trailing data or multiple XYZ frames; provide one frame"
        )

    metadata, metadata_order = parse_comment(lines[1].strip())
    for required in ("Lattice", "Properties", "pbc"):
        if required not in metadata:
            raise ValueError(f"{path} needs a {required}=... field")
    try:
        lattice_values = [float(value) for value in metadata["Lattice"].split()]
    except ValueError as exc:
        raise ValueError(f"invalid Lattice field in {path}") from exc
    if len(lattice_values) != 9:
        raise ValueError(f"Lattice field in {path} must contain 9 numbers")
    cell = np.asarray(lattice_values, dtype=float).reshape(3, 3)
    diagonal = np.diag(np.diag(cell))
    if not np.allclose(cell, diagonal, atol=1.0e-7):
        raise ValueError("fill_dhf.py currently requires an orthorhombic cell")
    if np.any(np.diag(cell) <= 0.0):
        raise ValueError("cell lengths must be positive")
    pbc = metadata["pbc"].upper().split()
    if pbc != ["T", "T", "F"]:
        raise ValueError(
            'fill_dhf.py requires pbc="T T F" (X/Y periodic and Z nonperiodic)'
        )

    properties = parse_properties(metadata["Properties"])
    offsets = property_offsets(properties)
    if (
        "species" not in offsets
        or offsets["species"][1].kind != "S"
        or offsets["species"][1].count != 1
    ):
        raise ValueError("Properties must contain species:S:1")
    if (
        "pos" not in offsets
        or offsets["pos"][1].kind != "R"
        or offsets["pos"][1].count != 3
    ):
        raise ValueError("Properties must contain pos:R:3")
    expected_columns = sum(spec.count for spec in properties)
    rows: list[list[str]] = []
    species: list[str] = []
    positions: list[list[float]] = []
    species_offset = offsets["species"][0]
    position_offset = offsets["pos"][0]
    for line_number, line in enumerate(lines[2 : natoms + 2], start=3):
        values = line.split()
        if len(values) != expected_columns:
            raise ValueError(
                f"line {line_number} of {path} has {len(values)} columns; "
                f"Properties declares {expected_columns}"
            )
        rows.append(values)
        species.append(values[species_offset])
        try:
            positions.append(
                [float(value) for value in values[position_offset : position_offset + 3]]
            )
        except ValueError as exc:
            raise ValueError(f"invalid coordinate on line {line_number} of {path}") from exc
    position_array = np.asarray(positions, dtype=float).reshape((-1, 3))
    if not np.all(np.isfinite(position_array)):
        raise ValueError(f"{path} contains non-finite coordinates")
    return ExtendedXYZ(
        properties=properties,
        rows=rows,
        species=np.asarray(species, dtype="U8"),
        positions=position_array,
        cell=cell,
        metadata=metadata,
        metadata_order=metadata_order,
    )


def metadata_float(metadata: dict[str, str], key: str) -> float:
    if key not in metadata:
        raise ValueError(f"input metadata lacks {key}; provide the corresponding override")
    try:
        value = float(metadata[key])
    except ValueError as exc:
        raise ValueError(f"input metadata {key} is not numeric") from exc
    if not math.isfinite(value):
        raise ValueError(f"input metadata {key} is not finite")
    return value


def resolve_geometry(args: argparse.Namespace, structure: ExtendedXYZ) -> TrenchGeometry:
    lengths = np.diag(structure.cell)
    length_x, length_y, length_z = (float(value) for value in lengths)
    metadata = structure.metadata
    if "actual_length_x" in metadata and not math.isclose(
        metadata_float(metadata, "actual_length_x"), length_x, abs_tol=1.0e-5
    ):
        raise ValueError("actual_length_x metadata conflicts with the Lattice field")
    if "periodic_length_y" in metadata and not math.isclose(
        metadata_float(metadata, "periodic_length_y"), length_y, abs_tol=1.0e-5
    ):
        raise ValueError("periodic_length_y metadata conflicts with the Lattice field")

    shift_z = metadata_float(metadata, "geometry_shift_z") if args.trench_top_z is None or args.trench_floor_z is None else 0.0
    if args.trench_top_z is None:
        z_top = shift_z + metadata_float(metadata, "si_thickness")
    else:
        z_top = args.trench_top_z
    if args.trench_floor_z is None:
        z_floor = shift_z + metadata_float(metadata, "bottom_thickness")
    else:
        z_floor = args.trench_floor_z

    if args.trench_y_left is None:
        shift_y = metadata_float(metadata, "geometry_shift_y")
        y_left = shift_y + metadata_float(metadata, "sidewall_thickness")
    else:
        y_left = args.trench_y_left
    if args.trench_width is None:
        trench_width = metadata_float(metadata, "trench_width")
    else:
        trench_width = args.trench_width

    if not all(math.isfinite(value) for value in (z_top, z_floor, y_left, trench_width)):
        raise ValueError("trench geometry values must be finite")
    if not z_floor < z_top:
        raise ValueError("trench floor must be below the trench top")
    if not 0.0 < trench_width < length_y - TOL:
        raise ValueError("trench width must be positive and smaller than Ly")
    if z_floor < -TOL or z_top > length_z + TOL:
        raise ValueError("trench floor/top lies outside the input Z cell")
    if "trench_depth" in metadata and args.trench_top_z is None and args.trench_floor_z is None:
        stated_depth = metadata_float(metadata, "trench_depth")
        if not math.isclose(z_top - z_floor, stated_depth, abs_tol=1.0e-5):
            raise ValueError("trench_depth metadata conflicts with floor/top metadata")
    sin_mode = metadata.get("sin_mode", "unknown").lower()
    return TrenchGeometry(
        length_x=length_x,
        length_y=length_y,
        length_z=length_z,
        y_left=y_left % length_y,
        trench_width=trench_width,
        z_floor=z_floor,
        z_top=z_top,
        sin_mode=sin_mode,
    )


def pair_cutoff(first: str, second: str, scale: float = 1.0) -> float:
    first = first.capitalize()
    second = second.capitalize()
    pair = frozenset((first, second))
    if first == "H" and second == "H":
        value = 1.25
    elif "H" in pair:
        value = 1.40
    elif first == "O" and second == "O":
        value = 2.30
    elif pair == frozenset(("O", "F")):
        value = 2.20
    elif first == "F" and second == "F":
        value = 2.20
    elif (first in {"O", "F"} and second in {"Si", "N"}) or (
        second in {"O", "F"} and first in {"Si", "N"}
    ):
        value = 2.00
    else:
        value = 2.00
    return scale * value


class LinkedCell:
    """Sparse atom index with minimum-image X/Y distances and open Z."""

    def __init__(self, length_x: float, length_y: float, cutoff_scale: float) -> None:
        self.length_x = length_x
        self.length_y = length_y
        self.cutoff_scale = cutoff_scale
        self.maximum_cutoff = 2.30 * cutoff_scale
        self.nx = max(1, int(math.floor(length_x / self.maximum_cutoff)))
        self.ny = max(1, int(math.floor(length_y / self.maximum_cutoff)))
        self.bin_x = length_x / self.nx
        self.bin_y = length_y / self.ny
        self.bin_z = self.maximum_cutoff
        self.positions: list[tuple[float, float, float]] = []
        self.species: list[str] = []
        self.bins: dict[tuple[int, int, int], list[int]] = {}

    def key(self, position: np.ndarray | tuple[float, float, float]) -> tuple[int, int, int]:
        x = float(position[0]) % self.length_x
        y = float(position[1]) % self.length_y
        z = float(position[2])
        ix = min(self.nx - 1, int(math.floor(x / self.bin_x)))
        iy = min(self.ny - 1, int(math.floor(y / self.bin_y)))
        iz = int(math.floor(z / self.bin_z))
        return ix, iy, iz

    def add_atom(self, species: str, position: np.ndarray) -> None:
        wrapped = (
            float(position[0]) % self.length_x,
            float(position[1]) % self.length_y,
            float(position[2]),
        )
        index = len(self.positions)
        self.positions.append(wrapped)
        self.species.append(str(species))
        self.bins.setdefault(self.key(wrapped), []).append(index)

    def add_atoms(self, species: Iterable[str], positions: np.ndarray) -> None:
        for element, position in zip(species, positions, strict=True):
            self.add_atom(str(element), position)

    def collides_atom(self, species: str, position: np.ndarray) -> bool:
        position = np.asarray(position, dtype=float)
        ix, iy, iz = self.key(position)
        neighbor_keys = {
            ((ix + dx) % self.nx, (iy + dy) % self.ny, iz + dz)
            for dx in (-1, 0, 1)
            for dy in (-1, 0, 1)
            for dz in (-1, 0, 1)
        }
        for neighbor_key in neighbor_keys:
            for index in self.bins.get(neighbor_key, ()):
                other = self.positions[index]
                dx = float(position[0]) - other[0]
                dy = float(position[1]) - other[1]
                dz = float(position[2]) - other[2]
                dx -= round(dx / self.length_x) * self.length_x
                dy -= round(dy / self.length_y) * self.length_y
                cutoff = pair_cutoff(species, self.species[index], self.cutoff_scale)
                if dx * dx + dy * dy + dz * dz < cutoff * cutoff - 1.0e-12:
                    return True
        return False

    def collides_molecule(self, species: np.ndarray, positions: np.ndarray) -> bool:
        return any(
            self.collides_atom(str(element), position)
            for element, position in zip(species, positions, strict=True)
        )


def make_water_template() -> tuple[np.ndarray, np.ndarray]:
    half_angle = math.radians(WATER_ANGLE_DEGREES / 2.0)
    x = WATER_OH * math.sin(half_angle)
    z = WATER_OH * math.cos(half_angle)
    species = np.asarray(["O", "H", "H"], dtype="U2")
    positions = np.asarray([[0.0, 0.0, 0.0], [x, 0.0, z], [-x, 0.0, z]])
    return species, positions


def make_hf_template() -> tuple[np.ndarray, np.ndarray]:
    return np.asarray(["F", "H"], dtype="U2"), np.asarray(
        [[0.0, 0.0, 0.0], [0.0, 0.0, HF_BOND]], dtype=float
    )


MOLECULE_TEMPLATES = {"H2O": make_water_template(), "HF": make_hf_template()}


def random_rotation(rng: np.random.Generator) -> np.ndarray:
    """Sample a uniform SO(3) rotation using a random unit quaternion."""
    u1, u2, u3 = rng.random(3)
    x = math.sqrt(1.0 - u1) * math.sin(2.0 * math.pi * u2)
    y = math.sqrt(1.0 - u1) * math.cos(2.0 * math.pi * u2)
    z = math.sqrt(u1) * math.sin(2.0 * math.pi * u3)
    w = math.sqrt(u1) * math.cos(2.0 * math.pi * u3)
    return np.asarray(
        [
            [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)],
            [2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)],
            [2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)],
        ]
    )


def grid_dimensions(length: float, spacing: float) -> int:
    return max(1, int(math.ceil(length / spacing)))


def estimate_accessible_volume(
    region: LiquidRegion,
    fixed_index: LinkedCell,
    spacing: float,
) -> tuple[float, int]:
    accessible = 0.0
    samples_total = 0
    length_x = region.geometry.length_x
    length_y = region.geometry.length_y
    for box in region.boxes():
        nx = grid_dimensions(length_x, spacing)
        ny = grid_dimensions(box.y_length, spacing)
        nz = grid_dimensions(box.z_high - box.z_low, spacing)
        free = 0
        total = nx * ny * nz
        for ix in range(nx):
            x = (ix + 0.5) * length_x / nx
            for iy in range(ny):
                y = (box.y_origin + (iy + 0.5) * box.y_length / ny) % length_y
                for iz in range(nz):
                    z = box.z_low + (iz + 0.5) * (box.z_high - box.z_low) / nz
                    if not fixed_index.collides_atom("O", np.asarray([x, y, z])):
                        free += 1
        accessible += box.volume(length_x) * free / total
        samples_total += total
    return accessible, samples_total


def realized_wt_percent(n_h2o: int, n_hf: int) -> float:
    mass_hf = n_hf * MOLAR_MASS_HF
    total_mass = mass_hf + n_h2o * MOLAR_MASS_H2O
    return 0.0 if total_mass == 0.0 else 100.0 * mass_hf / total_mass


def choose_hf_count(total_molecules: int, wt_percent: float) -> int:
    if total_molecules <= 0 or wt_percent <= 0.0:
        return 0
    if wt_percent >= 100.0:
        return total_molecules
    fraction = wt_percent / 100.0
    mole_fraction = (fraction / MOLAR_MASS_HF) / (
        fraction / MOLAR_MASS_HF + (1.0 - fraction) / MOLAR_MASS_H2O
    )
    center = total_molecules * mole_fraction
    candidates = {
        max(0, min(total_molecules, int(math.floor(center)) + delta))
        for delta in range(-2, 4)
    }
    return min(
        candidates,
        key=lambda count: (
            abs(realized_wt_percent(total_molecules - count, count) - wt_percent),
            abs(count - center),
            count,
        ),
    )


def plan_composition(
    count_volume: float,
    wt_percent: float,
    density: float | None,
    molecule_count: int | None,
    packing_volume: float | None = None,
) -> Composition:
    if count_volume <= TOL:
        raise ValueError("the selected liquid region has no countable volume")
    if packing_volume is None:
        packing_volume = count_volume
    if packing_volume <= TOL:
        raise ValueError("the selected liquid region has no accessible packing volume")
    if molecule_count is None:
        if density is None:
            raise ValueError("internal error: density is required without --molecule-count")
        mass_grams = density * count_volume * 1.0e-24
        fraction = wt_percent / 100.0
        expected_total = AVOGADRO * mass_grams * (
            fraction / MOLAR_MASS_HF + (1.0 - fraction) / MOLAR_MASS_H2O
        )
        total_molecules = int(math.floor(expected_total + 0.5))
    else:
        total_molecules = molecule_count
    if total_molecules < 1:
        raise ValueError(
            "the selected volume/density corresponds to fewer than one molecule; "
            "increase the liquid region or use --molecule-count"
        )
    n_hf = choose_hf_count(total_molecules, wt_percent)
    n_h2o = total_molecules - n_hf
    mass_grams = (n_h2o * MOLAR_MASS_H2O + n_hf * MOLAR_MASS_HF) / AVOGADRO
    actual_density = mass_grams / (count_volume * 1.0e-24)
    return Composition(
        n_h2o=n_h2o,
        n_hf=n_hf,
        target_wt_percent=wt_percent,
        actual_wt_percent=realized_wt_percent(n_h2o, n_hf),
        target_density=density,
        actual_density=actual_density,
        count_volume=count_volume,
        packing_volume=packing_volume,
    )


def generate_candidate_sites(
    region: LiquidRegion,
    fixed_index: LinkedCell,
    target_count: int,
    accessible_volume: float,
    oversampling: float,
    rng: np.random.Generator,
) -> np.ndarray:
    site_density = oversampling * target_count / accessible_volume
    spacing = site_density ** (-1.0 / 3.0)
    sites: list[np.ndarray] = []
    length_x = region.geometry.length_x
    length_y = region.geometry.length_y
    for box in region.boxes():
        nx = grid_dimensions(length_x, spacing)
        ny = grid_dimensions(box.y_length, spacing)
        nz = grid_dimensions(box.z_high - box.z_low, spacing)
        cell_x = length_x / nx
        cell_y = box.y_length / ny
        cell_z = (box.z_high - box.z_low) / nz
        for ix in range(nx):
            for iy in range(ny):
                for iz in range(nz):
                    fractions = 0.18 + 0.64 * rng.random(3)
                    point = np.asarray(
                        [
                            (ix + fractions[0]) * cell_x,
                            (box.y_origin + (iy + fractions[1]) * cell_y) % length_y,
                            box.z_low + (iz + fractions[2]) * cell_z,
                        ]
                    )
                    if not fixed_index.collides_atom("O", point):
                        sites.append(point)
    if not sites:
        return np.empty((0, 3), dtype=float)
    result = np.vstack(sites)
    rng.shuffle(result)
    return result


def molecule_coordinates(
    kind: str,
    center: np.ndarray,
    rotation: np.ndarray,
    geometry: TrenchGeometry,
) -> tuple[np.ndarray, np.ndarray]:
    species, template = MOLECULE_TEMPLATES[kind]
    positions = template @ rotation.T + center
    positions[:, 0] %= geometry.length_x
    positions[:, 1] %= geometry.length_y
    return species, positions


def pack_once(
    structure: ExtendedXYZ,
    region: LiquidRegion,
    composition: Composition,
    fixed_index: LinkedCell,
    args: argparse.Namespace,
    restart: int,
) -> PackingResult:
    seed_sequence = np.random.SeedSequence([args.seed & 0xFFFFFFFF, restart, 32452843])
    site_rng, type_rng, orientation_rng = [
        np.random.default_rng(child) for child in seed_sequence.spawn(3)
    ]
    sites = generate_candidate_sites(
        region,
        fixed_index,
        composition.total_molecules,
        composition.packing_volume,
        args.site_oversampling,
        site_rng,
    )
    molecule_kinds = np.asarray(
        ["HF"] * composition.n_hf + ["H2O"] * composition.n_h2o,
        dtype="U3",
    )
    type_rng.shuffle(molecule_kinds)
    dynamic_index = LinkedCell(
        region.geometry.length_x,
        region.geometry.length_y,
        args.cutoff_scale,
    )
    placed_kinds: list[str] = []
    placed_species: list[np.ndarray] = []
    placed_positions: list[np.ndarray] = []
    attempts = 0
    site_index = 0
    for kind_value in molecule_kinds:
        kind = str(kind_value)
        accepted = False
        while site_index < len(sites) and not accepted:
            center = sites[site_index]
            site_index += 1
            for _ in range(args.orientations_per_site):
                attempts += 1
                rotation = random_rotation(orientation_rng)
                species, positions = molecule_coordinates(
                    kind, center, rotation, region.geometry
                )
                if np.any(positions[:, 2] < -TOL):
                    continue
                if args.containment == "all-atoms" and not all(
                    region.contains(position) for position in positions
                ):
                    continue
                if fixed_index.collides_molecule(species, positions):
                    continue
                if dynamic_index.collides_molecule(species, positions):
                    continue
                dynamic_index.add_atoms(species, positions)
                placed_kinds.append(kind)
                placed_species.append(species.copy())
                placed_positions.append(positions.copy())
                accepted = True
                break
        if not accepted:
            break
    return PackingResult(
        molecule_kinds=placed_kinds,
        molecule_species=placed_species,
        molecule_positions=placed_positions,
        attempts=attempts,
        restart=restart,
    )


def pack_molecules(
    structure: ExtendedXYZ,
    region: LiquidRegion,
    composition: Composition,
    fixed_index: LinkedCell,
    args: argparse.Namespace,
) -> PackingResult:
    best: PackingResult | None = None
    for restart in range(args.restarts + 1):
        result = pack_once(structure, region, composition, fixed_index, args, restart)
        if best is None or result.molecule_count > best.molecule_count:
            best = result
        if result.molecule_count == composition.total_molecules:
            return result
    assert best is not None
    if not args.allow_partial:
        raise ValueError(
            f"could place only {best.molecule_count}/{composition.total_molecules} molecules; "
            "increase --site-oversampling/--restarts, reduce --molecule-count or "
            "--density-g-cm3, or use --allow-partial"
        )
    return best


def default_property_value(kind: str) -> str:
    return "." if kind == "S" else "0"


def ensure_output_properties(structure: ExtendedXYZ) -> tuple[list[PropertySpec], list[list[str]], int, int]:
    properties = list(structure.properties)
    rows = [list(row) for row in structure.rows]
    offsets = property_offsets(properties)
    if "id" not in offsets:
        properties.append(PropertySpec("id", "I", 1))
        for atom_id, row in enumerate(rows, start=1):
            row.append(str(atom_id))
    offsets = property_offsets(properties)
    if "group" not in offsets:
        properties.append(PropertySpec("group", "S", 1))
        for row in rows:
            row.append("input_structure")
    offsets = property_offsets(properties)
    if "mol_id" not in offsets:
        properties.append(PropertySpec("mol_id", "I", 1))
        for row in rows:
            row.append("0")
    offsets = property_offsets(properties)
    id_offset, id_spec = offsets["id"]
    group_offset, group_spec = offsets["group"]
    mol_offset, mol_spec = offsets["mol_id"]
    if id_spec.count != 1 or id_spec.kind != "I":
        raise ValueError("id property must be id:I:1")
    if group_spec.count != 1 or group_spec.kind != "S":
        raise ValueError("group property must be group:S:1")
    if mol_spec.count != 1 or mol_spec.kind != "I":
        raise ValueError("mol_id property must be mol_id:I:1")
    try:
        next_atom_id = max((int(row[id_offset]) for row in rows), default=0) + 1
        next_molecule_id = max((int(row[mol_offset]) for row in rows), default=0) + 1
    except ValueError as exc:
        raise ValueError("existing id/mol_id values must be integers") from exc
    return properties, rows, next_atom_id, next_molecule_id


def make_new_atom_row(
    properties: Sequence[PropertySpec],
    species: str,
    position: np.ndarray,
    atom_id: int,
    group: str,
    molecule_id: int,
) -> list[str]:
    row: list[str] = []
    for spec in properties:
        if spec.name == "species":
            values = [species]
        elif spec.name == "pos":
            values = [f"{float(value):.10f}" for value in position]
        elif spec.name == "id":
            values = [str(atom_id)]
        elif spec.name == "group":
            values = [group]
        elif spec.name == "mol_id":
            values = [str(molecule_id)]
        else:
            values = [default_property_value(spec.kind)] * spec.count
        if len(values) != spec.count:
            raise ValueError(f"property {spec.name} has an incompatible column count")
        row.extend(values)
    return row


def properties_string(properties: Sequence[PropertySpec]) -> str:
    return ":".join(
        field
        for spec in properties
        for field in (spec.name, spec.kind, str(spec.count))
    )


def metadata_token(key: str, value: str) -> str:
    if re.fullmatch(r"[A-Za-z0-9_.+:/%,-]+", value):
        return f"{key}={value}"
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'{key}="{escaped}"'


def build_output_comment(
    structure: ExtendedXYZ,
    properties: Sequence[PropertySpec],
    output_cell: np.ndarray,
    args: argparse.Namespace,
    region: LiquidRegion,
    stats: FillStats,
) -> str:
    lattice = " ".join(f"{value:.10f}" for value in output_cell.reshape(-1))
    tokens = [
        f'Lattice="{lattice}"',
        f"Properties={properties_string(properties)}",
        'pbc="T T F"',
    ]
    replaced = {"Lattice", "Properties", "pbc", "packer"}
    replaced.update(key for key in structure.metadata if key.startswith("dhf_"))
    overrides_used = any(
        value is not None
        for value in (
            args.trench_top_z,
            args.trench_floor_z,
            args.trench_y_left,
            args.trench_width,
        )
    )
    if overrides_used:
        replaced.update(
            {
                "si_thickness",
                "bottom_thickness",
                "trench_depth",
                "trench_width",
                "sidewall_thickness",
                "geometry_shift_y",
                "geometry_shift_z",
            }
        )
    for key in structure.metadata_order:
        if key not in replaced:
            tokens.append(metadata_token(key, structure.metadata[key]))
    values = {
        "packer": "fill_dhf.py",
        "dhf_target_wt_percent": f"{stats.target_wt_percent:.8f}",
        "dhf_actual_wt_percent": f"{stats.actual_wt_percent:.8f}",
        "dhf_density_target_g_cm3": (
            "count_controlled" if stats.target_density is None else f"{stats.target_density:.8f}"
        ),
        "dhf_density_actual_g_cm3": f"{stats.actual_density:.8f}",
        "dhf_accessible_volume_a3": f"{stats.accessible_volume:.8f}",
        "dhf_geometric_volume_a3": f"{stats.geometric_volume:.8f}",
        "dhf_count_volume_a3": f"{stats.count_volume:.8f}",
        "dhf_volume_basis": stats.volume_basis,
        "dhf_density_geometric_g_cm3": f"{stats.geometric_loading_density:.8f}",
        "dhf_volume_probe_scale": f"{args.volume_probe_scale:.8f}",
        "dhf_fill_depth": f"{region.fill_depth:.8f}",
        "dhf_effective_fill_depth": (
            f"{0.0 if region.trench_liquid == 'exclude' else region.fill_depth:.8f}"
        ),
        "dhf_reservoir_height": f"{region.reservoir_height:.8f}",
        "dhf_trench_liquid": region.trench_liquid,
        "dhf_z_lower": f"{region.z_lower:.8f}",
        "dhf_z_upper": f"{region.z_upper:.8f}",
        "dhf_geometry_trench_top_z": f"{region.geometry.z_top:.8f}",
        "dhf_geometry_trench_floor_z": f"{region.geometry.z_floor:.8f}",
        "dhf_geometry_trench_y_left": f"{region.geometry.y_left:.8f}",
        "dhf_geometry_trench_width": f"{region.geometry.trench_width:.8f}",
        "dhf_geometry_source": "overrides" if overrides_used else "input_metadata",
        "dhf_n_h2o": str(stats.placed_h2o),
        "dhf_n_hf": str(stats.placed_hf),
        "dhf_seed": str(args.seed),
        "dhf_cutoff_scale": f"{args.cutoff_scale:.8f}",
        "dhf_containment": args.containment,
    }
    tokens.extend(metadata_token(key, value) for key, value in values.items())
    return " ".join(tokens)


def write_output(
    path: Path,
    structure: ExtendedXYZ,
    result: PackingResult,
    output_cell: np.ndarray,
    args: argparse.Namespace,
    region: LiquidRegion,
    stats: FillStats,
) -> None:
    properties, rows, next_atom_id, next_molecule_id = ensure_output_properties(structure)
    for kind, species, positions in zip(
        result.molecule_kinds,
        result.molecule_species,
        result.molecule_positions,
        strict=True,
    ):
        molecule_id = next_molecule_id
        next_molecule_id += 1
        for element, position in zip(species, positions, strict=True):
            rows.append(
                make_new_atom_row(
                    properties,
                    str(element),
                    position,
                    next_atom_id,
                    kind,
                    molecule_id,
                )
            )
            next_atom_id += 1
    comment = build_output_comment(structure, properties, output_cell, args, region, stats)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(f"{len(rows)}\n")
            handle.write(comment + "\n")
            for row in rows:
                handle.write(" ".join(row) + "\n")
        os.replace(temporary_name, path)
    except BaseException:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise


def nonnegative_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or parsed < 0.0:
        raise argparse.ArgumentTypeError("must be a finite non-negative number")
    return parsed


def positive_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or parsed <= 0.0:
        raise argparse.ArgumentTypeError("must be a finite positive number")
    return parsed


def wt_percent(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or not 0.0 <= parsed <= 100.0:
        raise argparse.ArgumentTypeError("must be in the interval [0, 100]")
    return parsed


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed < 1:
        raise argparse.ArgumentTypeError("must be at least 1")
    return parsed


def nonnegative_int(value: str) -> int:
    parsed = int(value)
    if parsed < 0:
        raise argparse.ArgumentTypeError("must be non-negative")
    return parsed


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Pack neutral H2O/HF molecules into an x/y-periodic Si trench "
            "using a linked-cell collision index."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("input", type=Path, help="input extended XYZ trench structure")
    parser.add_argument("-o", "--output", type=Path, default=Path("trench_dHF.xyz"))
    parser.add_argument(
        "--hf-wt-percent",
        "--hf-wt",
        dest="hf_wt_percent",
        type=wt_percent,
        required=True,
        help="HF mass percentage of the H2O+HF liquid (solid excluded)",
    )
    parser.add_argument(
        "--fill-depth",
        "--trench-fill-depth",
        dest="fill_depth",
        type=nonnegative_float,
        required=True,
        help="liquid penetration depth downward from the nominal trench top",
    )
    parser.add_argument(
        "--reservoir-height",
        type=nonnegative_float,
        default=0.0,
        help="optional liquid-layer height above the nominal trench top",
    )
    parser.add_argument(
        "--trench-liquid",
        "--residue-trench",
        choices=("include", "exclude"),
        default="include",
        help="include liquid inside the trench or restrict it to the upper reservoir",
    )
    amount = parser.add_mutually_exclusive_group()
    amount.add_argument(
        "--density-g-cm3",
        "--solution-density",
        dest="density_g_cm3",
        type=positive_float,
        default=None,
        help="solution density; required above 5 wt%% HF",
    )
    amount.add_argument(
        "--molecule-count",
        type=positive_int,
        default=None,
        help="exact total H2O+HF molecule count instead of density-derived count",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--volume-grid-spacing", type=positive_float, default=1.5)
    parser.add_argument(
        "--volume-basis",
        choices=("accessible", "geometric"),
        default="accessible",
        help="volume used for density-to-molecule-count conversion",
    )
    parser.add_argument(
        "--volume-probe-scale",
        type=positive_float,
        default=1.0,
        help="fixed O-probe exclusion scale for accessible-volume estimation",
    )
    parser.add_argument("--site-oversampling", type=positive_float, default=4.0)
    parser.add_argument("--orientations-per-site", type=positive_int, default=12)
    parser.add_argument("--restarts", type=nonnegative_int, default=2)
    parser.add_argument("--cutoff-scale", type=positive_float, default=1.0)
    parser.add_argument(
        "--containment",
        choices=("all-atoms", "center"),
        default="all-atoms",
        help="keep every molecular atom or only its O/F center inside the liquid region",
    )
    parser.add_argument(
        "--allow-partial",
        action="store_true",
        help="write the best partial packing instead of failing atomically",
    )
    parser.add_argument("--dry-run", action="store_true", help="report counts without packing or writing")
    parser.add_argument("--top-vacuum", type=nonnegative_float, default=5.0)
    overrides = parser.add_argument_group("geometry overrides for compatible external XYZ files")
    overrides.add_argument("--trench-top-z", type=float, default=None)
    overrides.add_argument("--trench-floor-z", type=float, default=None)
    overrides.add_argument("--trench-y-left", type=float, default=None)
    overrides.add_argument("--trench-width", type=positive_float, default=None)
    return parser


def validate_request(
    args: argparse.Namespace,
    structure: ExtendedXYZ,
    geometry: TrenchGeometry,
) -> tuple[LiquidRegion, float | None]:
    if args.trench_liquid == "include" and args.fill_depth > geometry.trench_depth + TOL:
        raise ValueError(
            f"--fill-depth={args.fill_depth:g} exceeds trench depth "
            f"{geometry.trench_depth:.8f} A"
        )
    if args.trench_liquid == "include" and args.fill_depth <= TOL and args.reservoir_height <= TOL:
        raise ValueError("the liquid region is empty; increase --fill-depth or --reservoir-height")
    if args.trench_liquid == "exclude" and args.reservoir_height <= TOL:
        raise ValueError(
            "--trench-liquid exclude needs a positive --reservoir-height; "
            "otherwise there is no liquid region"
        )
    if geometry.sin_mode == "fill" and args.trench_liquid == "include" and args.fill_depth > TOL:
        raise ValueError(
            "sin_mode=fill already occupies the trench; use --trench-liquid exclude "
            "with --reservoir-height to pack only above it"
        )
    if structure.metadata.get("packer") == "fill_dhf.py":
        raise ValueError("input appears to contain an existing dHF packing; use the original dry structure")
    density = args.density_g_cm3
    if args.molecule_count is None and density is None:
        if args.hf_wt_percent <= 5.0 + TOL:
            density = 0.997
        else:
            raise ValueError(
                "provide --density-g-cm3 above 5 wt% HF; the dilute 0.997 g/cm3 "
                "fallback is not valid at higher concentrations"
            )
    region = LiquidRegion(
        geometry=geometry,
        fill_depth=args.fill_depth,
        reservoir_height=args.reservoir_height,
        trench_liquid=args.trench_liquid,
    )
    return region, density


def execute(args: argparse.Namespace) -> FillStats:
    structure = read_extended_xyz(args.input)
    geometry = resolve_geometry(args, structure)
    region, density = validate_request(args, structure, geometry)
    fixed_index = LinkedCell(geometry.length_x, geometry.length_y, args.cutoff_scale)
    fixed_index.add_atoms(structure.species, structure.positions)
    volume_index = LinkedCell(
        geometry.length_x, geometry.length_y, args.volume_probe_scale
    )
    volume_index.add_atoms(structure.species, structure.positions)
    accessible_volume, volume_samples = estimate_accessible_volume(
        region, volume_index, args.volume_grid_spacing
    )
    geometric_volume = sum(
        box.volume(geometry.length_x) for box in region.boxes()
    )
    count_volume = (
        accessible_volume if args.volume_basis == "accessible" else geometric_volume
    )
    composition = plan_composition(
        count_volume,
        args.hf_wt_percent,
        density,
        args.molecule_count,
        packing_volume=accessible_volume,
    )
    if args.dry_run:
        result = PackingResult([], [], [], 0, 0)
        placed_h2o = composition.n_h2o
        placed_hf = composition.n_hf
    else:
        result = pack_molecules(structure, region, composition, fixed_index, args)
        placed_h2o = result.molecule_kinds.count("H2O")
        placed_hf = result.molecule_kinds.count("HF")
    actual_wt = realized_wt_percent(placed_h2o, placed_hf)
    actual_mass = (
        placed_h2o * MOLAR_MASS_H2O + placed_hf * MOLAR_MASS_HF
    ) / AVOGADRO
    actual_density = actual_mass / (count_volume * 1.0e-24)
    geometric_loading_density = actual_mass / (geometric_volume * 1.0e-24)
    stats = FillStats(
        accessible_volume=accessible_volume,
        geometric_volume=geometric_volume,
        count_volume=count_volume,
        volume_basis=args.volume_basis,
        volume_samples=volume_samples,
        requested_h2o=composition.n_h2o,
        requested_hf=composition.n_hf,
        placed_h2o=placed_h2o,
        placed_hf=placed_hf,
        target_wt_percent=args.hf_wt_percent,
        actual_wt_percent=actual_wt,
        target_density=density,
        actual_density=actual_density,
        geometric_loading_density=geometric_loading_density,
        attempts=result.attempts,
        restart=result.restart,
    )
    if not args.dry_run:
        output_cell = structure.cell.copy()
        fluid_maximum_z = max(
            (float(np.max(positions[:, 2])) for positions in result.molecule_positions),
            default=region.z_upper,
        )
        output_cell[2, 2] = max(
            output_cell[2, 2],
            region.z_upper + args.top_vacuum,
            fluid_maximum_z + args.top_vacuum,
        )
        write_output(args.output, structure, result, output_cell, args, region, stats)
    return stats


def print_summary(args: argparse.Namespace, stats: FillStats) -> None:
    if args.dry_run:
        print("Dry run: no output written")
    else:
        print(f"Wrote: {args.output}")
    print(
        f"Accessible liquid volume: {stats.accessible_volume:.3f} A^3 "
        f"({stats.volume_samples} grid samples)"
    )
    print(
        f"Geometric liquid volume: {stats.geometric_volume:.3f} A^3; "
        f"count basis: {stats.volume_basis} ({stats.count_volume:.3f} A^3)"
    )
    print(
        f"Molecules: H2O {stats.placed_h2o}/{stats.requested_h2o}, "
        f"HF {stats.placed_hf}/{stats.requested_hf}"
    )
    print(
        f"HF concentration: requested {stats.target_wt_percent:.6f} wt%, "
        f"integer-realized {stats.actual_wt_percent:.6f} wt%"
    )
    density_target = (
        "count-controlled"
        if stats.target_density is None
        else f"{stats.target_density:.6f} g/cm^3"
    )
    print(
        f"Density on {stats.volume_basis} count volume: requested {density_target}, "
        f"integer-realized {stats.actual_density:.6f} g/cm^3; "
        f"geometric loading {stats.geometric_loading_density:.6f} g/cm^3"
    )
    if stats.requested_hf == 0 and stats.target_wt_percent > 0.0:
        print(
            "WARNING: this finite liquid volume rounds to zero HF molecules; "
            "increase the region or use --molecule-count."
        )
    if not args.dry_run:
        print(f"Packing attempts: {stats.attempts} (restart {stats.restart})")
    print(
        "Note: neutral HF/H2O does not model aqueous dissociation; relax and "
        "equilibrate with a suitable interaction model."
    )


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        stats = execute(args)
    except ValueError as exc:
        parser.error(str(exc))
    print_summary(args, stats)
    return 0


if __name__ == "__main__":
    sys.exit(main())

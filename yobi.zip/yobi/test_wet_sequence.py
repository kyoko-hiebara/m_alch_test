from __future__ import annotations

import copy
import unittest

from surface_chemistry import (
    LocalInterfaceConditions,
    MeanFieldSurfaceChemistry,
    MeanFieldSurfaceState,
    ReactionMode,
)
from wet_sequence import (
    MECHANISM_PRESETS,
    MeanFieldSolverAdapter,
    MetricStopCriterion,
    SolverAdvance,
    StateMode,
    StepStateSemantics,
    WetProcessState,
    WetSequenceRunner,
    WetStep,
    get_mechanism_preset,
)


class RecordingAdapter:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def __call__(
        self, state: WetProcessState, step: WetStep, requested_duration_s: float
    ) -> SolverAdvance:
        self.calls.append(
            {
                "step": step.name,
                "solution_temperature_K": step.solution_temperature_K,
                "substrate_temperature_K": step.substrate_temperature_K,
                "solution": copy.deepcopy(state.solution_state),
                "product_before": state.surface_state.product_coverage,
                "substrate_ticks_before": state.substrate_state["ticks"],
            }
        )
        advanced = state.copied()
        advanced.substrate_state["ticks"] += 1
        surface = advanced.surface_state
        product = min(
            1.0 - surface.passivation_coverage,
            surface.product_coverage + 0.1,
        )
        advanced.surface_state = MeanFieldSurfaceState(
            material_coverage=surface.material_coverage,
            converted_coverage=surface.converted_coverage,
            product_coverage=product,
            passivation_coverage=surface.passivation_coverage,
        )
        advanced.solution_state["age"] = advanced.solution_state.get("age", 0.0) + requested_duration_s
        return SolverAdvance(
            state=advanced,
            elapsed_s=requested_duration_s,
            metrics={
                "ticks": float(advanced.substrate_state["ticks"]),
                "product": product,
            },
        )


class WetSequenceTests(unittest.TestCase):
    def test_presets_are_explicitly_uncalibrated_non_recipes(self) -> None:
        self.assertEqual(
            set(MECHANISM_PRESETS),
            {
                "hf",
                "rinse",
                "phosphoric_like",
                "oxidative_conversion",
                "fluoride_after_oxidation",
            },
        )
        for preset in MECHANISM_PRESETS.values():
            self.assertFalse(preset.calibrated)
            self.assertFalse(preset.is_recipe)
            self.assertIn("Not a wet-process recipe", preset.notice)
        self.assertIs(
            get_mechanism_preset("post-oxidation-fluoride").reaction_mode,
            ReactionMode.ETCH_CONVERTED,
        )

    def test_step_temperatures_and_carry_reset_semantics_remain_independent(self) -> None:
        adapter = RecordingAdapter()
        runner = WetSequenceRunner(adapter)
        initial = WetProcessState(
            substrate_state={"ticks": 0},
            surface_state=MeanFieldSurfaceState(product_coverage=0.2),
            solution_state={"old": 9.0},
        )
        steps = (
            WetStep(
                name="HF",
                mechanism="hf",
                duration_s=2.0,
                solver_increment_s=1.0,
                solution_temperature_K=291.0,
                substrate_temperature_K=331.0,
                solution_inputs={"HF_activity": 1.0},
            ),
            WetStep(
                name="rinse",
                mechanism="rinse",
                duration_s=1.0,
                solution_temperature_K=295.0,
                substrate_temperature_K=325.0,
                state_semantics=StepStateSemantics(
                    solution="reset", surface="clear_interfacial"
                ),
                solution_inputs={"fresh_water": 1.0},
            ),
            WetStep(
                name="second",
                mechanism="oxidative_conversion",
                duration_s=1.0,
                solution_temperature_K=303.0,
                substrate_temperature_K=343.0,
                state_semantics=StepStateSemantics(
                    solution="carry", surface="reset", substrate="reset"
                ),
                solution_inputs={"oxidant_activity": 0.4},
            ),
        )
        result = runner.run(initial, steps)

        self.assertEqual(len(adapter.calls), 4)
        self.assertEqual(adapter.calls[0]["solution_temperature_K"], 291.0)
        self.assertEqual(adapter.calls[0]["substrate_temperature_K"], 331.0)
        self.assertNotEqual(
            adapter.calls[0]["solution_temperature_K"],
            adapter.calls[0]["substrate_temperature_K"],
        )
        self.assertNotIn("old", adapter.calls[0]["solution"])
        self.assertAlmostEqual(adapter.calls[2]["product_before"], 0.0)
        self.assertEqual(adapter.calls[2]["solution"], {"fresh_water": 1.0})
        self.assertAlmostEqual(adapter.calls[3]["product_before"], 0.2)
        self.assertEqual(adapter.calls[3]["substrate_ticks_before"], 0)
        self.assertIn("fresh_water", adapter.calls[3]["solution"])
        self.assertIn("oxidant_activity", adapter.calls[3]["solution"])
        self.assertEqual(result.total_elapsed_s, 4.0)
        self.assertEqual(result.stop_reason, "completed")
        # Runner works on a copy unless explicitly asked otherwise.
        self.assertEqual(initial.substrate_state["ticks"], 0)
        self.assertAlmostEqual(initial.surface_state.product_coverage, 0.2)

    def test_metric_stop_is_checked_at_solver_increments(self) -> None:
        def advancing_adapter(
            state: WetProcessState, step: WetStep, requested_duration_s: float
        ) -> SolverAdvance:
            advanced = state.copied()
            advanced.substrate_state["removed"] += requested_duration_s
            return SolverAdvance(
                state=advanced,
                elapsed_s=requested_duration_s,
                metrics={"removed": advanced.substrate_state["removed"]},
            )

        step = WetStep(
            name="stop-test",
            mechanism="hf",
            duration_s=10.0,
            solver_increment_s=1.0,
            solution_temperature_K=300.0,
            substrate_temperature_K=320.0,
            stop_criteria=(MetricStopCriterion("removed", 2.5),),
        )
        result = WetSequenceRunner(advancing_adapter).run(
            WetProcessState(substrate_state={"removed": 0.0}), [step]
        )
        step_result = result.step_results[0]
        self.assertEqual(step_result.elapsed_s, 3.0)
        self.assertTrue(step_result.stopped_early)
        self.assertEqual(step_result.stop_reason, "criterion:removed>=2.5")
        self.assertEqual(step_result.final_metrics["removed"], 3.0)
        self.assertEqual(len(step_result.metric_history), 3)

    def test_mean_field_adapter_requires_explicit_local_interface_conditions(self) -> None:
        preset = get_mechanism_preset("oxidative_conversion")
        model = MeanFieldSurfaceChemistry(
            preset.calibrated_parameters(
                rate_constant_ref_s=0.5,
                reference_temperature_K=300.0,
                activation_energy_J_mol=0.0,
            )
        )
        observed_boundaries: list[tuple[float, float]] = []

        def conditions(
            state: WetProcessState, step: WetStep
        ) -> LocalInterfaceConditions:
            del state
            observed_boundaries.append(
                (step.solution_temperature_K, step.substrate_temperature_K)
            )
            # Explicit local value from a hypothetical thermal solver. It is not
            # inferred by MeanFieldSolverAdapter.
            return LocalInterfaceConditions(
                temperature_K=307.0,
                reactant_activity=0.8,
                reactant_concentration=1.0,
            )

        adapter = MeanFieldSolverAdapter(
            model_resolver=lambda step: model,
            condition_resolver=conditions,
            material="SiOCN",
        )
        step = WetStep(
            name="conversion",
            mechanism=preset,
            duration_s=2.0,
            solution_temperature_K=290.0,
            substrate_temperature_K=350.0,
        )
        result = WetSequenceRunner(adapter).run(
            WetProcessState(surface_state=MeanFieldSurfaceState()), [step]
        )
        self.assertEqual(observed_boundaries, [(290.0, 350.0)])
        self.assertGreater(
            result.final_state.surface_state.converted_coverage, 0.0
        )
        self.assertAlmostEqual(
            result.step_results[0].final_metrics["material_coverage"], 1.0
        )

    def test_invalid_semantics_and_solver_overrun_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            StepStateSemantics(solution=StateMode.CLEAR_INTERFACIAL)

        def overrun(
            state: WetProcessState, step: WetStep, requested_duration_s: float
        ) -> SolverAdvance:
            return SolverAdvance(state=state, elapsed_s=2.0 * requested_duration_s)

        step = WetStep(
            "bad",
            "rinse",
            1.0,
            solution_temperature_K=300.0,
            substrate_temperature_K=300.0,
        )
        with self.assertRaisesRegex(RuntimeError, "beyond"):
            WetSequenceRunner(overrun).run(WetProcessState(), [step])


if __name__ == "__main__":
    unittest.main()

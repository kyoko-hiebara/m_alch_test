#!/usr/bin/env python3
"""Run the dimensionless high-AR ozone-delivery screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from ozone_penetration_screen import (
    OzonePenetrationConfig,
    run_ozone_penetration_screen,
    save_ozone_penetration_json,
)
from trench_geometry import DEFAULT_GEOMETRY_NAMES, GEOMETRY_PRESETS


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Screen steady ozone delivery in a straight reactive slit versus "
            "Thiele modulus. This is not an etch prediction or recipe."
        )
    )
    parser.add_argument(
        "--geometry",
        choices=tuple(GEOMETRY_PRESETS),
        action="append",
        help="repeat to select straight geometries (default: two standards)",
    )
    parser.add_argument(
        "--phi",
        type=float,
        action="append",
        help="repeat to select Thiele moduli (default: 0,0.1,0.3,1,2,3,5)",
    )
    parser.add_argument(
        "--effective-diffusivity-m2-s",
        type=float,
        help=(
            "optional effective diffusivity used only to convert k_s/D_eff "
            "to an equivalent wall velocity"
        ),
    )
    parser.add_argument(
        "--exposure-duration-s",
        type=float,
        default=30.0,
        help="exposure used for the optional Fourier-number check (default: 30)",
    )
    parser.add_argument(
        "--steady-state-fourier-threshold",
        type=float,
        default=10.0,
        help="minimum Fo=D_eff*t/L^2 screening threshold (default: 10)",
    )
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config = OzonePenetrationConfig(
        geometry_names=tuple(
            dict.fromkeys(args.geometry or DEFAULT_GEOMETRY_NAMES)
        ),
        thiele_moduli=tuple(
            dict.fromkeys(
                args.phi or (0.0, 0.1, 0.3, 1.0, 2.0, 3.0, 5.0)
            )
        ),
        effective_diffusivity_m2_s=args.effective_diffusivity_m2_s,
        exposure_duration_s=args.exposure_duration_s,
        steady_state_fourier_threshold=args.steady_state_fourier_threshold,
    )
    payload = run_ozone_penetration_screen(config)
    if args.output is None:
        print(
            json.dumps(
                payload,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
                allow_nan=False,
            )
        )
    else:
        save_ozone_penetration_json(payload, args.output)
        print(f"JSON: {args.output}")
    return payload


if __name__ == "__main__":
    main()

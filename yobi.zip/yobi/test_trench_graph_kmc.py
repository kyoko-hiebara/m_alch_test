from __future__ import annotations

import unittest
from dataclasses import replace

import numpy as np

from graph_kmc import EventContext
from reaction_diffusion_2d import CartesianGrid2D
from spatial_etchability import SpatialEtchabilityParameters
from trench_geometry import GEOMETRY_PRESETS, TaperedTrench2D
from trench_graph_kmc import (
    ArrheniusRateSpec,
    IntermediateStateKMCParameters,
    MaterialIntermediateKinetics,
    SpeciesActivitySpec,
    REGION_BOTTOM,
    REGION_CORE,
    REGION_SIDEWALL,
    REGION_TOP,
    ContinuumCouplingParameters,
    ContinuumKMCFrame,
    SecondWetKMCParameters,
    TrenchGraphConfig,
    TrenchKMCParameters,
    apply_continuum_frame,
    build_trench_graph,
    build_trench_kmc,
    parameters_to_dict,
    run_coupled_trench_kmc,
    run_second_wet_stage,
)
from wetting_2d import WettingParameters


def _grid(
    geometry: TaperedTrench2D,
    *,
    spacing_nm: float = 1.0,
) -> CartesianGrid2D:
    return CartesianGrid2D.from_geometry(
        geometry,
        spacing_nm=spacing_nm,
        reservoir_height_nm=max(spacing_nm, 2.0),
        lateral_margin_nm=2.0,
    )


def _inactive_kinetics(**updates: float) -> TrenchKMCParameters:
    """Return a rate set with only explicitly requested mechanisms active."""

    baseline = TrenchKMCParameters(
        activation_rate_s=0.0,
        removal_rate_s=0.0,
        passivation_rate_s=0.0,
        depassivation_rate_s=0.0,
        precipitation_rate_s=0.0,
        deposit_dissolution_rate_s=0.0,
        reattachment_rate_s=0.0,
    )
    return replace(baseline, **updates)


def _event_context(kmc, event_name: str, site_id: int) -> EventContext:
    return EventContext(
        graph=kmc.graph,
        site_id=site_id,
        event_name=event_name,
        time_s=kmc.time_s,
        environment=kmc.environment,
    )


def _template(kmc, name: str):
    return next(template for template in kmc.event_templates if template.name == name)


class TrenchGraphConstructionTests(unittest.TestCase):
    def test_intermediate_rate_requires_an_explicit_absolute_rate_anchor(
        self,
    ) -> None:
        with self.assertRaisesRegex(ValueError, "exactly one"):
            ArrheniusRateSpec(activation_energy_eV=0.4)
        with self.assertRaisesRegex(ValueError, "exactly one"):
            ArrheniusRateSpec(
                activation_energy_eV=0.4,
                reference_rate_s=1.0,
                prefactor_per_s=1.0e12,
            )

        referenced = ArrheniusRateSpec(
            activation_energy_eV=0.4,
            reference_rate_s=2.5,
            reference_temperature_K=310.0,
        )
        prefactored = ArrheniusRateSpec(
            activation_energy_eV=0.4,
            prefactor_per_s=1.0e12,
        )
        self.assertEqual(referenced.rate_at_temperature(310.0), 2.5)
        self.assertGreater(
            referenced.rate_at_temperature(330.0),
            referenced.rate_at_temperature(290.0),
        )
        self.assertGreater(prefactored.rate_at_temperature(330.0), 0.0)

    def test_straight_geometries_fit_the_two_thousand_site_budget(self) -> None:
        expected = {
            "10_10_180": (1548, 351, 1899),
            "7_7_170": (1134, 329, 1463),
        }
        for name, counts in expected.items():
            with self.subTest(geometry=name):
                grid = CartesianGrid2D.from_geometry(
                    GEOMETRY_PRESETS[name],
                    spacing_nm=1.05,
                    reservoir_height_nm=4.0,
                    lateral_margin_nm=2.0,
                )
                graph, layout = build_trench_graph(grid)
                observed = (
                    layout.matrix_site_count,
                    layout.collector_site_count,
                    layout.site_count,
                )
                self.assertEqual(observed, counts)
                self.assertEqual(layout.matrix_site_count, np.count_nonzero(grid.cavity_mask))
                self.assertEqual(layout.site_count, len(graph.sites))
                self.assertLessEqual(layout.site_count, 2_000)

    def test_legacy_tapered_geometry_site_counts_are_preserved(self) -> None:
        expected = {
            "10_8_180": (1620, 367, 1987),
            "7_4p5_170": (986, 343, 1329),
        }
        for name, counts in expected.items():
            with self.subTest(geometry=name):
                grid = CartesianGrid2D.from_geometry(
                    GEOMETRY_PRESETS[name],
                    spacing_nm=1.0,
                    reservoir_height_nm=4.0,
                    lateral_margin_nm=2.0,
                )
                graph, layout = build_trench_graph(grid)
                observed = (
                    layout.matrix_site_count,
                    layout.collector_site_count,
                    layout.site_count,
                )
                self.assertEqual(observed, counts)
                self.assertEqual(layout.matrix_site_count, np.count_nonzero(grid.cavity_mask))
                self.assertEqual(layout.site_count, len(graph.sites))
                self.assertLessEqual(layout.site_count, 2_000)

    def test_region_flags_exist_and_only_the_opening_layer_is_exposed(self) -> None:
        grid = CartesianGrid2D.from_geometry(
            GEOMETRY_PRESETS["10_10_180"],
            spacing_nm=1.05,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
        )
        graph, layout = build_trench_graph(grid)

        region_codes = {
            int(round(graph.sites[site_id].attributes["region_code"]))
            for site_id in layout.matrix_site_ids
        }
        self.assertEqual(
            region_codes,
            {REGION_TOP, REGION_SIDEWALL, REGION_BOTTOM, REGION_CORE},
        )
        self.assertTrue(
            any(
                graph.sites[site_id].attributes["boundary_sidewall_flag"] > 0.5
                for site_id in layout.matrix_site_ids
            )
        )
        self.assertTrue(
            any(
                graph.sites[site_id].attributes["boundary_floor_flag"] > 0.5
                for site_id in layout.matrix_site_ids
            )
        )

        exposed = [
            site_id
            for site_id in layout.matrix_site_ids
            if graph.sites[site_id].state == "intact"
        ]
        self.assertGreater(len(exposed), 0)
        for site_id in layout.matrix_site_ids:
            row, col = layout.cell_by_site[site_id]
            touches_reservoir = row > 0 and bool(grid.reservoir_mask[row - 1, col])
            site = graph.sites[site_id]
            self.assertEqual(site.state == "intact", touches_reservoir)
            self.assertEqual(site.attributes["wet_exposed"] > 0.5, touches_reservoir)

    def test_static_material_factors_are_stored_with_exact_unit_defaults(self) -> None:
        geometry = TaperedTrench2D("spatial", 6.0, 4.0, 8.0)
        grid = _grid(geometry)
        default_graph, default_layout = build_trench_graph(grid)
        factor_names = (
            "depth_material_rate_factor",
            "sidewall_material_rate_factor",
            "floor_material_rate_factor",
            "material_rate_factor",
        )
        for site_id in default_layout.matrix_site_ids:
            for name in factor_names:
                self.assertEqual(default_graph.sites[site_id].attributes[name], 1.0)

        parameters = SpatialEtchabilityParameters(
            top_rate_factor=1.0,
            bottom_rate_factor=0.4,
            depth_exponent=1.5,
            sidewall_rate_factor=0.3,
            sidewall_influence_length_nm=1.2,
            floor_rate_factor=0.2,
            floor_influence_length_nm=1.5,
        )
        graph, layout = build_trench_graph(
            grid,
            spatial_etchability_parameters=parameters,
        )
        factors = []
        for site_id in layout.matrix_site_ids:
            attributes = graph.sites[site_id].attributes
            expected = (
                attributes["depth_material_rate_factor"]
                * attributes["sidewall_material_rate_factor"]
                * attributes["floor_material_rate_factor"]
            )
            self.assertAlmostEqual(attributes["material_rate_factor"], expected)
            factors.append(attributes["material_rate_factor"])
        self.assertLess(min(factors), 1.0)


class TrenchGraphEventTests(unittest.TestCase):
    def setUp(self) -> None:
        self.geometry = TaperedTrench2D("toy", 6.0, 4.0, 8.0)
        self.grid = _grid(self.geometry)

    def _top_centre_site(self, layout) -> int:
        exposed = [
            site_id
            for site_id in layout.matrix_site_ids
            if layout.cell_by_site[site_id][0]
            == min(row for row, _ in layout.cell_by_site.values())
        ]
        return min(
            exposed,
            key=lambda site_id: abs(
                self.grid.lateral_nm[layout.cell_by_site[site_id][1]]
            ),
        )

    def test_remove_exposes_the_actual_next_graph_layer(self) -> None:
        graph, layout = build_trench_graph(self.grid)
        site_id = self._top_centre_site(layout)
        below = layout.site_by_cell[
            (layout.cell_by_site[site_id][0] + 1, layout.cell_by_site[site_id][1])
        ]
        self.assertEqual(graph.sites[below].state, "buried")

        graph.sites[site_id].state = "activated"
        graph.sites[site_id].attributes.update(
            hf_activity=1.0,
            product_activity=0.0,
            temperature_K=310.0,
            wet_exposed=1.0,
            wet_face_count=1.0,
        )
        kmc = build_trench_kmc(
            graph,
            layout,
            _inactive_kinetics(removal_rate_s=2.0),
            seed=4,
        )
        record = kmc.step()

        self.assertIsNotNone(record)
        self.assertEqual(record.event_name, "remove")
        self.assertEqual(record.site_id, site_id)
        self.assertEqual(kmc.graph.sites[site_id].state, "removed")
        self.assertEqual(kmc.graph.sites[below].state, "intact")
        self.assertEqual(kmc.graph.sites[below].attributes["wet_exposed"], 1.0)
        self.assertEqual(kmc.graph.sites[below].attributes["hf_activity"], 1.0)
        self.assertEqual(kmc.graph.sites[below].attributes["temperature_K"], 310.0)
        self.assertIn(below, record.changed_sites)

    def test_default_event_topology_is_unchanged_without_opt_in(self) -> None:
        graph, layout = build_trench_graph(self.grid)
        kmc = build_trench_kmc(graph, layout, seed=19)
        self.assertEqual(
            [template.name for template in kmc.event_templates],
            [
                "activate",
                "passivate",
                "depassivate",
                "remove",
                "precipitate",
                "dissolve_deposit",
                "reattach",
            ],
        )

    def test_material_intermediates_separate_water_hf_and_removal(self) -> None:
        graph, layout = build_trench_graph(
            self.grid,
            TrenchGraphConfig(material="SiOCN"),
        )
        site_id = self._top_centre_site(layout)
        below = layout.site_by_cell[
            (
                layout.cell_by_site[site_id][0] + 1,
                layout.cell_by_site[site_id][1],
            )
        ]
        graph.sites[site_id].attributes.update(
            wet_exposed=1.0,
            wet_face_count=1.0,
            water_activity=0.4,
            hf_activity=0.0,
            product_activity=0.0,
            temperature_K=298.15,
        )
        chemistry = IntermediateStateKMCParameters(
            enabled=True,
            materials=(
                MaterialIntermediateKinetics(
                    material="SiOCN",
                    hydrolysis=ArrheniusRateSpec(
                        activation_energy_eV=0.0,
                        reference_rate_s=2.0,
                        provenance="unit_test",
                    ),
                    direct_fluorination=ArrheniusRateSpec(
                        activation_energy_eV=0.0,
                        reference_rate_s=3.0,
                        provenance="unit_test",
                    ),
                    direct_fluorination_activity=SpeciesActivitySpec(
                        total_hf_order=1.0
                    ),
                    silanol_fluorination=ArrheniusRateSpec(
                        activation_energy_eV=0.0,
                        reference_rate_s=4.0,
                        provenance="unit_test",
                    ),
                    silanol_fluorination_activity=SpeciesActivitySpec(
                        total_hf_order=1.0
                    ),
                    fluorinated_removal=ArrheniusRateSpec(
                        activation_energy_eV=0.0,
                        reference_rate_s=5.0,
                        provenance="unit_test",
                    ),
                    fluorinated_removal_activity=SpeciesActivitySpec(
                        total_hf_order=1.0
                    ),
                ),
            ),
            water_activity=1.0,
        )
        kinetics = _inactive_kinetics(
            top_rate_factor=1.0,
            sidewall_rate_factor=1.0,
            bottom_rate_factor=1.0,
            core_rate_factor=1.0,
        )
        kmc = build_trench_kmc(
            graph,
            layout,
            kinetics,
            intermediate_parameters=chemistry,
            seed=29,
        )

        hydrolysis = _template(kmc, "hydrolyze")
        direct_fluorination = _template(kmc, "fluorinate_intact")
        hydrolysis_context = _event_context(kmc, "hydrolyze", site_id)
        direct_context = _event_context(
            kmc, "fluorinate_intact", site_id
        )
        self.assertTrue(hydrolysis.is_enabled(hydrolysis_context))
        self.assertAlmostEqual(
            hydrolysis.base_rate(hydrolysis_context),
            0.8,
        )
        self.assertEqual(
            direct_fluorination.base_rate(direct_context),
            0.0,
        )

        direct_context.site.attributes["hf_activity"] = 1.0
        self.assertGreater(
            direct_fluorination.base_rate(direct_context),
            0.0,
        )
        hydrolysis.execute(hydrolysis_context, np.random.default_rng(3))
        self.assertEqual(
            kmc.graph.sites[site_id].state,
            "hydrolyzed_silanol",
        )

        silanol_fluorination = _template(kmc, "fluorinate_silanol")
        silanol_context = _event_context(
            kmc, "fluorinate_silanol", site_id
        )
        self.assertTrue(silanol_fluorination.is_enabled(silanol_context))
        silanol_fluorination.execute(
            silanol_context, np.random.default_rng(4)
        )
        self.assertEqual(kmc.graph.sites[site_id].state, "fluorinated")

        removal = _template(kmc, "remove_fluorinated")
        removal_context = _event_context(
            kmc, "remove_fluorinated", site_id
        )
        self.assertTrue(removal.is_enabled(removal_context))
        self.assertGreater(removal.base_rate(removal_context), 0.0)
        changed = removal.execute(
            removal_context, np.random.default_rng(5)
        )
        self.assertEqual(kmc.graph.sites[site_id].state, "removed")
        self.assertEqual(kmc.graph.sites[below].state, "intact")
        self.assertIn(below, changed)

    def test_intermediate_material_match_and_serialized_policy_are_explicit(
        self,
    ) -> None:
        chemistry = IntermediateStateKMCParameters(
            enabled=True,
            materials=(
                MaterialIntermediateKinetics(
                    material="SiOCN",
                    hydrolysis=ArrheniusRateSpec(
                        activation_energy_eV=0.25,
                        reference_rate_s=0.5,
                        provenance="manual_screening_choice",
                    ),
                ),
            ),
        )
        graph, layout = build_trench_graph(
            self.grid,
            TrenchGraphConfig(material="SiN"),
        )
        kmc = build_trench_kmc(
            graph,
            layout,
            _inactive_kinetics(
                top_rate_factor=1.0,
                sidewall_rate_factor=1.0,
                bottom_rate_factor=1.0,
                core_rate_factor=1.0,
            ),
            intermediate_parameters=chemistry,
        )
        site_id = self._top_centre_site(layout)
        context = _event_context(kmc, "hydrolyze", site_id)
        self.assertFalse(_template(kmc, "hydrolyze").is_enabled(context))

        payload = parameters_to_dict(
            TrenchGraphConfig(material="SiN"),
            ContinuumCouplingParameters(),
            TrenchKMCParameters(),
            intermediate_parameters=chemistry,
        )
        intermediate = payload["intermediate_kinetics"]
        self.assertFalse(intermediate["automatic_screening_result_mapping"])
        self.assertEqual(
            intermediate["mapping_policy"],
            "explicit_manual_only",
        )

    def test_ionic_species_activities_are_independent_opt_in_factors(
        self,
    ) -> None:
        rate = ArrheniusRateSpec(
            activation_energy_eV=0.0,
            reference_rate_s=8.0,
            provenance="unit_test",
        )
        with self.assertRaisesRegex(
            ValueError, "direct_fluorination_activity"
        ):
            MaterialIntermediateKinetics(
                material="SiOCN",
                direct_fluorination=rate,
            )
        chemistry = IntermediateStateKMCParameters(
            enabled=True,
            materials=(
                MaterialIntermediateKinetics(
                    material="SiOCN",
                    direct_fluorination=rate,
                    direct_fluorination_activity=SpeciesActivitySpec(
                        hf2_order=1.0,
                        fluoride_order=1.0,
                        protonated_site_order=1.0,
                    ),
                ),
            ),
        )
        graph, layout = build_trench_graph(
            self.grid,
            TrenchGraphConfig(material="SiOCN"),
        )
        site_id = self._top_centre_site(layout)
        graph.sites[site_id].attributes.update(
            wet_exposed=1.0,
            wet_face_count=1.0,
            hf_activity=10.0,
            product_activity=0.0,
            temperature_K=298.15,
        )
        kmc = build_trench_kmc(
            graph,
            layout,
            _inactive_kinetics(
                top_rate_factor=1.0,
                sidewall_rate_factor=1.0,
                bottom_rate_factor=1.0,
                core_rate_factor=1.0,
            ),
            intermediate_parameters=chemistry,
        )
        fluorination = _template(kmc, "fluorinate_intact")
        context = _event_context(kmc, "fluorinate_intact", site_id)

        self.assertEqual(fluorination.base_rate(context), 0.0)
        context.site.attributes.update(
            hf2_activity=1.0,
            fluoride_activity=1.0,
            protonated_site_fraction=0.5,
        )
        self.assertAlmostEqual(fluorination.base_rate(context), 1.0)
        context.site.attributes["fluoride_activity"] = 0.0
        self.assertEqual(fluorination.base_rate(context), 0.0)

    def test_hydronium_assisted_hydrolysis_can_require_protonated_sites(
        self,
    ) -> None:
        chemistry = IntermediateStateKMCParameters(
            enabled=True,
            materials=(
                MaterialIntermediateKinetics(
                    material="SiN",
                    hydrolysis=ArrheniusRateSpec(
                        activation_energy_eV=0.0,
                        reference_rate_s=4.0,
                        provenance="unit_test",
                    ),
                    hydrolysis_activity=SpeciesActivitySpec(
                        protonated_site_order=1.0,
                    ),
                ),
            ),
            water_activity=0.5,
        )
        graph, layout = build_trench_graph(
            self.grid,
            TrenchGraphConfig(material="SiN"),
        )
        site_id = self._top_centre_site(layout)
        graph.sites[site_id].attributes.update(
            wet_exposed=1.0,
            wet_face_count=1.0,
            product_activity=0.0,
            temperature_K=298.15,
        )
        kmc = build_trench_kmc(
            graph,
            layout,
            _inactive_kinetics(
                top_rate_factor=1.0,
                sidewall_rate_factor=1.0,
                bottom_rate_factor=1.0,
                core_rate_factor=1.0,
            ),
            intermediate_parameters=chemistry,
        )
        hydrolysis = _template(kmc, "hydrolyze")
        context = _event_context(kmc, "hydrolyze", site_id)
        self.assertEqual(hydrolysis.base_rate(context), 0.0)
        context.site.attributes["protonated_site_fraction"] = 0.25
        self.assertAlmostEqual(hydrolysis.base_rate(context), 0.5)

    def test_local_fields_map_to_matrix_sidewall_and_bottom_and_dry_sites_are_off(self) -> None:
        graph, layout = build_trench_graph(self.grid)
        coupling = ContinuumCouplingParameters(
            hf_reference_concentration=2.0,
            product_reference_concentration=0.5,
        )
        kmc = build_trench_kmc(graph, layout, seed=3)

        top_sites = [
            site_id
            for site_id in layout.matrix_site_ids
            if kmc.graph.sites[site_id].state == "intact"
        ]
        top_sites.sort(
            key=lambda site_id: abs(kmc.graph.sites[site_id].attributes["x_nm"])
        )
        wet_matrix, dry_matrix = top_sites[:2]
        side_collector = next(
            site_id
            for site_id in layout.collector_site_ids
            if kmc.graph.sites[site_id].attributes["sidewall_flag"] > 0.5
            and kmc.graph.sites[site_id].attributes["bottom_flag"] < 0.5
        )
        bottom_collector = next(
            site_id
            for site_id in layout.collector_site_ids
            if kmc.graph.sites[site_id].attributes["bottom_flag"] > 0.5
            and kmc.graph.sites[site_id].attributes["sidewall_flag"] < 0.5
        )
        collector_values = {
            side_collector: (1.4, 0.30, 312.0),
            bottom_collector: (0.8, 0.45, 325.0),
        }

        shape = self.grid.shape
        solid = self.grid.cavity_mask.copy()
        liquid = self.grid.reservoir_mask.copy()
        interface = np.zeros(shape, dtype=bool)
        hf_field = np.zeros(shape)
        product_field = np.zeros(shape)
        hf_at_solid = np.zeros(shape)
        product_at_solid = np.zeros(shape)
        temperature = np.full(shape, 298.15)
        face_length = np.zeros(shape)
        face_count = np.zeros(shape, dtype=np.int16)

        wet_row, wet_col = layout.cell_by_site[wet_matrix]
        interface[wet_row, wet_col] = True
        hf_at_solid[wet_row, wet_col] = 1.2
        product_at_solid[wet_row, wet_col] = 0.20
        temperature[wet_row, wet_col] = 305.0
        face_length[wet_row, wet_col] = self.grid.dx_nm
        face_count[wet_row, wet_col] = 1

        for collector_id, (hf, product, site_temperature) in collector_values.items():
            support = layout.support_by_collector[collector_id]
            row, col = layout.cell_by_site[support]
            kmc.graph.sites[support].state = "removed"
            solid[row, col] = False
            liquid[row, col] = True
            hf_field[row, col] = hf
            product_field[row, col] = product
            temperature[row, col] = site_temperature

        frame = ContinuumKMCFrame(
            time_s=0.0,
            solid_mask=solid,
            liquid_mask=liquid,
            gas_mask=np.zeros(shape, dtype=bool),
            interface_mask=interface,
            hf_field=hf_field,
            product_field=product_field,
            hf_at_solid=hf_at_solid,
            product_at_solid=product_at_solid,
            interface_temperature_K=temperature,
            wet_face_length_nm=face_length,
            wet_face_count=face_count,
            hf_converged=True,
            product_converged=True,
            hf_relative_residual=0.0,
            product_relative_residual=0.0,
        )
        apply_continuum_frame(kmc, layout, frame, coupling)

        wet = kmc.graph.sites[wet_matrix]
        dry = kmc.graph.sites[dry_matrix]
        self.assertAlmostEqual(wet.attributes["hf_activity"], 0.6)
        self.assertAlmostEqual(wet.attributes["product_activity"], 0.4)
        self.assertEqual(wet.attributes["temperature_K"], 305.0)
        self.assertEqual(wet.attributes["wet_exposed"], 1.0)
        self.assertEqual(dry.attributes["wet_exposed"], 0.0)

        for collector_id, (hf, product, site_temperature) in collector_values.items():
            collector = kmc.graph.sites[collector_id]
            self.assertEqual(collector.attributes["wet_exposed"], 1.0)
            self.assertAlmostEqual(collector.attributes["hf_activity"], hf / 2.0)
            self.assertAlmostEqual(
                collector.attributes["product_activity"], product / 0.5
            )
            self.assertEqual(collector.attributes["temperature_K"], site_temperature)

        activation = _template(kmc, "activate")
        wet_context = _event_context(kmc, "activate", wet_matrix)
        dry_context = _event_context(kmc, "activate", dry_matrix)
        self.assertTrue(activation.is_enabled(wet_context))
        self.assertGreater(activation.base_rate(wet_context), 0.0)
        self.assertFalse(activation.is_enabled(dry_context))
        self.assertEqual(kmc._evaluate_slot(0, dry_matrix), 0.0)

    def test_rates_respond_to_hf_temperature_product_and_neighbour_state(self) -> None:
        graph, layout = build_trench_graph(self.grid)
        focal = self._top_centre_site(layout)
        graph.sites[focal].state = "activated"
        graph.sites[focal].attributes.update(
            wet_exposed=1.0,
            wet_face_count=1.0,
            hf_activity=0.05,
            product_activity=0.0,
            temperature_K=285.0,
        )
        kmc = build_trench_kmc(graph, layout, seed=2)
        removal = _template(kmc, "remove")
        passivation = _template(kmc, "passivate")
        context = _event_context(kmc, "remove", focal)
        site = context.site

        low_hf = removal.base_rate(context)
        site.attributes["hf_activity"] = 1.0
        high_hf = removal.base_rate(context)
        self.assertGreater(high_hf, low_hf)

        site.attributes["temperature_K"] = 335.0
        hot = removal.base_rate(context)
        self.assertGreater(hot, high_hf)

        site.attributes["product_activity"] = 2.0
        inhibited = removal.base_rate(context)
        self.assertLess(inhibited, hot)

        neighbour = layout.exposure_neighbours[focal][0]
        site.attributes["product_activity"] = 0.0
        kmc.graph.sites[neighbour].state = "intact"
        no_removed_neighbour = removal.base_rate(context)
        kmc.graph.sites[neighbour].state = "removed"
        removed_neighbour = removal.base_rate(context)
        self.assertGreater(removed_neighbour, no_removed_neighbour)

        site.attributes["product_activity"] = 1.0
        kmc.graph.sites[neighbour].state = "intact"
        passivation_context = _event_context(kmc, "passivate", focal)
        isolated = passivation.base_rate(passivation_context)
        kmc.graph.sites[neighbour].state = "passivated"
        clustered = passivation.base_rate(passivation_context)
        self.assertGreater(clustered, isolated)

    def test_static_material_factor_scales_removal_once_but_not_activation(self) -> None:
        spatial = SpatialEtchabilityParameters(
            top_rate_factor=1.0,
            bottom_rate_factor=0.25,
            depth_exponent=1.0,
            sidewall_rate_factor=0.5,
            sidewall_influence_length_nm=1.0,
            floor_rate_factor=0.4,
            floor_influence_length_nm=1.0,
        )
        default_graph, default_layout = build_trench_graph(self.grid)
        spatial_graph, spatial_layout = build_trench_graph(
            self.grid,
            spatial_etchability_parameters=spatial,
        )
        focal = self._top_centre_site(default_layout)
        self.assertEqual(focal, self._top_centre_site(spatial_layout))
        for graph in (default_graph, spatial_graph):
            graph.sites[focal].state = "activated"
            graph.sites[focal].attributes.update(
                wet_exposed=1.0,
                wet_face_count=1.0,
                hf_activity=1.0,
                product_activity=0.0,
                temperature_K=298.15,
            )
        kinetics = _inactive_kinetics(
            activation_rate_s=2.0,
            removal_rate_s=3.0,
        )
        default_kmc = build_trench_kmc(
            default_graph,
            default_layout,
            kinetics,
            seed=11,
        )
        spatial_kmc = build_trench_kmc(
            spatial_graph,
            spatial_layout,
            kinetics,
            seed=11,
        )
        default_context = _event_context(default_kmc, "remove", focal)
        spatial_context = _event_context(spatial_kmc, "remove", focal)

        default_activation = _template(default_kmc, "activate").base_rate(
            default_context
        )
        spatial_activation = _template(spatial_kmc, "activate").base_rate(
            spatial_context
        )
        self.assertEqual(default_activation, spatial_activation)

        default_removal = _template(default_kmc, "remove").base_rate(
            default_context
        )
        spatial_removal = _template(spatial_kmc, "remove").base_rate(
            spatial_context
        )
        material_factor = spatial_kmc.graph.sites[focal].attributes[
            "material_rate_factor"
        ]
        self.assertLess(material_factor, 1.0)
        self.assertAlmostEqual(
            spatial_removal / default_removal,
            material_factor,
        )

    def test_precipitation_then_reattachment_conserves_deposit_count(self) -> None:
        graph, layout = build_trench_graph(self.grid)
        source = next(
            collector_id
            for collector_id, neighbours in layout.collector_neighbours.items()
            if neighbours
        )
        target = layout.collector_neighbours[source][0]
        graph.sites[source].attributes.update(
            wet_exposed=1.0,
            wet_face_count=1.0,
            product_activity=1.0,
            hf_activity=0.0,
        )
        kinetics = _inactive_kinetics(
            precipitation_rate_s=2.0,
            reattachment_rate_s=2.0,
        )
        kmc = build_trench_kmc(graph, layout, kinetics, seed=7)

        precipitate = kmc.step()
        self.assertIsNotNone(precipitate)
        self.assertEqual(precipitate.event_name, "precipitate")
        self.assertEqual(precipitate.site_id, source)
        self.assertEqual(kmc.graph.sites[source].state, "deposit")

        kmc.graph.sites[target].attributes.update(
            wet_exposed=1.0,
            wet_face_count=1.0,
            product_activity=0.0,
            hf_activity=0.0,
        )
        kmc.refresh_sites((source, target), expand=True)
        deposits_before = sum(
            kmc.graph.sites[site_id].state == "deposit"
            for site_id in layout.collector_site_ids
        )
        reattach = kmc.step()
        deposits_after = sum(
            kmc.graph.sites[site_id].state == "deposit"
            for site_id in layout.collector_site_ids
        )

        self.assertIsNotNone(reattach)
        self.assertEqual(reattach.event_name, "reattach")
        self.assertEqual(deposits_before, 1)
        self.assertEqual(deposits_after, deposits_before)
        self.assertEqual(kmc.graph.sites[source].state, "collector")
        self.assertEqual(kmc.graph.sites[target].state, "deposit")

    def test_seed_reproduces_a_short_multilayer_sequence(self) -> None:
        graph, layout = build_trench_graph(self.grid)
        for site_id in layout.matrix_site_ids:
            site = graph.sites[site_id]
            if site.state == "intact":
                site.attributes.update(
                    wet_exposed=1.0,
                    wet_face_count=1.0,
                    hf_activity=1.0,
                    product_activity=0.0,
                    temperature_K=298.15,
                )
        kinetics = _inactive_kinetics(
            activation_rate_s=5.0,
            removal_rate_s=4.0,
        )
        first = build_trench_kmc(graph, layout, kinetics, seed=123).run(max_events=10)
        second = build_trench_kmc(graph, layout, kinetics, seed=123).run(max_events=10)
        first_signature = [
            (record.event_name, record.site_id, record.time_s)
            for record in first.event_log
        ]
        second_signature = [
            (record.event_name, record.site_id, record.time_s)
            for record in second.event_log
        ]
        self.assertEqual(first_signature, second_signature)
        self.assertEqual(first.event_count, 10)

    def test_second_wet_continues_graph_or_outcome_with_common_rate_scale(self) -> None:
        primary = run_coupled_trench_kmc(
            self.grid,
            graph_config=TrenchGraphConfig(maximum_sites=200),
            coupling_parameters=ContinuumCouplingParameters(
                product_interface_source_flux=0.0,
                product_bulk_decay_per_s=0.0,
                macro_time_step_s=0.1,
                total_time_s=0.1,
                maximum_events=20,
                relative_tolerance=1.0e-4,
                maximum_iterations=50,
            ),
            kmc_parameters=_inactive_kinetics(),
            seed=17,
        )
        support = next(
            site_id
            for site_id, collector_id in primary.layout.collector_by_support.items()
            if primary.graph.sites[site_id].state == "intact"
        )
        collector = primary.layout.collector_by_support[support]
        primary.graph.sites[support].state = "removed"
        primary.graph.sites[collector].state = "deposit"
        passivated = next(
            site_id
            for site_id in primary.layout.matrix_site_ids
            if primary.graph.sites[site_id].state == "intact"
        )
        primary.graph.sites[passivated].state = "passivated"

        slow_parameters = SecondWetKMCParameters(
            duration_s=10.0,
            common_rate_multiplier=1.0,
            matrix_removal_rate_s=50.0,
            deposit_dissolution_rate_s=50.0,
        )
        fast_parameters = replace(
            slow_parameters,
            common_rate_multiplier=4.0,
        )
        slow = run_second_wet_stage(
            primary,
            parameters=slow_parameters,
            seed=919,
        )
        from_graph = run_second_wet_stage(
            primary.graph,
            primary.layout,
            parameters=slow_parameters,
            seed=919,
        )
        fast = run_second_wet_stage(
            primary,
            parameters=fast_parameters,
            seed=919,
        )

        def signature(outcome):
            return [
                (record.event_name, record.site_id)
                for record in outcome.event_log
            ]

        self.assertEqual(signature(slow), signature(from_graph))
        self.assertEqual(signature(slow), signature(fast))
        self.assertIn(
            "second_wet_remove",
            {record.event_name for record in slow.event_log},
        )
        self.assertIn(
            "second_wet_dissolve_deposit",
            {record.event_name for record in slow.event_log},
        )
        for slow_record, fast_record in zip(
            slow.event_log,
            fast.event_log,
            strict=True,
        ):
            self.assertAlmostEqual(
                fast_record.waiting_time_s,
                slow_record.waiting_time_s / 4.0,
            )
            self.assertAlmostEqual(
                fast_record.time_s,
                slow_record.time_s / 4.0,
            )

        self.assertEqual(slow.time_s, slow_parameters.duration_s)
        self.assertEqual(slow.duration_s, slow_parameters.duration_s)
        self.assertAlmostEqual(
            slow.total_time_s,
            primary.total_time_s + slow_parameters.duration_s,
        )
        self.assertGreater(slow.event_count, 0)
        self.assertEqual(slow.after_metrics["remaining_fraction"], 0.0)
        self.assertEqual(slow.after_metrics["deposit_count"], 0)
        self.assertEqual(primary.graph.sites[collector].state, "deposit")
        self.assertEqual(primary.graph.sites[passivated].state, "passivated")
        summary = slow.summary()
        self.assertGreater(summary["matrix_removed_count"], 0)
        self.assertEqual(summary["deposit_dissolved_count"], 1)


class CoupledClockTests(unittest.TestCase):
    def test_target_remaining_fraction_validation(self) -> None:
        for value in (-0.1, 1.0, float("inf"), float("nan")):
            with self.subTest(value=value):
                with self.assertRaisesRegex(
                    ValueError, "target_remaining_fraction"
                ):
                    ContinuumCouplingParameters(
                        target_remaining_fraction=value
                    )

    def test_target_stops_on_first_crossing_event_before_macro_horizon(self) -> None:
        geometry = TaperedTrench2D("endpoint", 3.0, 3.0, 3.0)
        grid = CartesianGrid2D.from_geometry(
            geometry,
            spacing_nm=1.0,
            reservoir_height_nm=1.0,
            lateral_margin_nm=1.0,
        )
        matrix_site_count = int(np.count_nonzero(grid.cavity_mask))
        target = (matrix_site_count - 1) / matrix_site_count
        coupling = ContinuumCouplingParameters(
            product_interface_source_flux=0.0,
            product_bulk_decay_per_s=0.0,
            macro_time_step_s=1.0,
            total_time_s=1.0,
            target_remaining_fraction=target,
            maximum_events=100,
            relative_tolerance=1.0e-4,
            maximum_iterations=50,
        )
        outcome = run_coupled_trench_kmc(
            grid,
            graph_config=TrenchGraphConfig(maximum_sites=100),
            coupling_parameters=coupling,
            kmc_parameters=_inactive_kinetics(
                activation_rate_s=1.0e4,
                removal_rate_s=1.0e4,
            ),
            seed=29,
        )

        self.assertEqual(outcome.stop_reason, "remaining_fraction_target")
        self.assertLess(outcome.total_time_s, coupling.macro_time_step_s)
        self.assertEqual(outcome.event_log[-1].event_name, "remove")
        self.assertAlmostEqual(
            outcome.target_crossing_before_fraction,
            1.0,
        )
        self.assertAlmostEqual(
            outcome.target_crossing_after_fraction,
            target,
        )
        summary = outcome.summary()
        self.assertTrue(summary["target_reached"])
        self.assertAlmostEqual(summary["remaining_fraction"], target)
        self.assertAlmostEqual(summary["target_remaining_fraction"], target)
        self.assertAlmostEqual(
            summary["target_crossing_before_fraction"],
            1.0,
        )
        self.assertAlmostEqual(
            summary["target_crossing_after_fraction"],
            target,
        )

    def test_five_percent_target_uses_exact_integer_site_threshold(self) -> None:
        geometry = TaperedTrench2D("integer-endpoint", 5.0, 5.0, 100.0)
        grid = CartesianGrid2D.from_geometry(
            geometry,
            spacing_nm=1.0,
            reservoir_height_nm=1.0,
            lateral_margin_nm=0.0,
        )
        matrix_site_count = int(np.count_nonzero(grid.cavity_mask))
        self.assertEqual(matrix_site_count, 500)
        coupling = ContinuumCouplingParameters(
            product_interface_source_flux=0.0,
            product_bulk_decay_per_s=0.0,
            macro_time_step_s=2.0,
            total_time_s=2.0,
            target_remaining_fraction=0.05,
            maximum_events=2_000,
            relative_tolerance=1.0e-4,
            maximum_iterations=50,
        )
        outcome = run_coupled_trench_kmc(
            grid,
            graph_config=TrenchGraphConfig(maximum_sites=1_000),
            coupling_parameters=coupling,
            kmc_parameters=_inactive_kinetics(
                activation_rate_s=1.0e5,
                removal_rate_s=1.0e5,
            ),
            seed=37,
        )

        summary = outcome.summary()
        self.assertEqual(outcome.stop_reason, "remaining_fraction_target")
        self.assertEqual(summary["state_counts"]["removed"], 475)
        self.assertEqual(summary["remaining_fraction"], 0.05)
        self.assertEqual(
            outcome.target_crossing_before_fraction,
            26 / 500,
        )
        self.assertEqual(
            outcome.target_crossing_after_fraction,
            25 / 500,
        )

    def test_unspecified_target_preserves_seeded_fixed_time_result(self) -> None:
        geometry = TaperedTrench2D("compatibility", 3.0, 3.0, 3.0)
        grid = CartesianGrid2D.from_geometry(
            geometry,
            spacing_nm=1.0,
            reservoir_height_nm=1.0,
            lateral_margin_nm=1.0,
        )
        default_parameters = ContinuumCouplingParameters(
            product_interface_source_flux=0.0,
            product_bulk_decay_per_s=0.0,
            macro_time_step_s=0.05,
            total_time_s=0.10,
            maximum_events=100,
            relative_tolerance=1.0e-4,
            maximum_iterations=50,
        )
        explicit_none = replace(
            default_parameters,
            target_remaining_fraction=None,
        )
        kinetics = _inactive_kinetics(
            activation_rate_s=20.0,
            removal_rate_s=20.0,
        )
        outcomes = [
            run_coupled_trench_kmc(
                grid,
                graph_config=TrenchGraphConfig(maximum_sites=100),
                coupling_parameters=parameters,
                kmc_parameters=kinetics,
                seed=31,
            )
            for parameters in (default_parameters, explicit_none)
        ]

        signatures = [
            [
                (record.event_name, record.site_id, record.time_s)
                for record in outcome.event_log
            ]
            for outcome in outcomes
        ]
        self.assertEqual(signatures[0], signatures[1])
        self.assertEqual(outcomes[0].summary(), outcomes[1].summary())
        self.assertNotIn(
            "target_remaining_fraction",
            outcomes[0].summary(),
        )

    def test_seeded_gas_forces_sync_at_activation_depth(self) -> None:
        geometry = TaperedTrench2D("gas-sync", 4.0, 4.0, 8.0)
        grid = CartesianGrid2D.from_geometry(
            geometry,
            spacing_nm=1.0,
            reservoir_height_nm=1.0,
            lateral_margin_nm=1.0,
        )
        outcome = run_coupled_trench_kmc(
            grid,
            graph_config=TrenchGraphConfig(maximum_sites=100),
            coupling_parameters=ContinuumCouplingParameters(
                product_interface_source_flux=0.0,
                product_bulk_decay_per_s=0.0,
                macro_time_step_s=5.0,
                total_time_s=5.0,
                maximum_events=500,
                relative_tolerance=1.0e-4,
                maximum_iterations=50,
            ),
            kmc_parameters=_inactive_kinetics(
                activation_rate_s=50.0,
                removal_rate_s=50.0,
            ),
            wetting_parameters=WettingParameters(
                enabled=True,
                new_void_filling_mode="liquid_inherited",
                bottom_gas_pocket_seed_height_nm=2.0,
                bottom_gas_activation_depth_fraction=0.5,
                gas_compression_mode="none",
            ),
            seed=5,
        )

        self.assertGreater(len(outcome.sync_history), 2)
        self.assertGreater(
            max(int(item["gas_cavity_cell_count"]) for item in outcome.sync_history),
            0,
        )
        self.assertGreater(outcome.summary()["remaining_fraction"], 0.0)

    def test_no_event_operator_split_still_advances_the_external_clock(self) -> None:
        geometry = TaperedTrench2D("clock", 3.0, 3.0, 3.0)
        grid = CartesianGrid2D.from_geometry(
            geometry,
            spacing_nm=1.0,
            reservoir_height_nm=1.0,
            lateral_margin_nm=1.0,
        )
        coupling = ContinuumCouplingParameters(
            product_interface_source_flux=0.0,
            product_bulk_decay_per_s=0.0,
            macro_time_step_s=0.1,
            total_time_s=0.25,
            maximum_events=20,
            relative_tolerance=1.0e-4,
            maximum_iterations=50,
        )
        outcome = run_coupled_trench_kmc(
            grid,
            graph_config=TrenchGraphConfig(maximum_sites=100),
            coupling_parameters=coupling,
            kmc_parameters=_inactive_kinetics(),
            seed=5,
        )

        self.assertEqual(len(outcome.event_log), 0)
        self.assertEqual(outcome.stop_reason, "total_time")
        self.assertAlmostEqual(outcome.total_time_s, coupling.total_time_s)
        self.assertAlmostEqual(
            float(outcome.sync_history[-1]["time_s"]), coupling.total_time_s
        )


if __name__ == "__main__":
    unittest.main()

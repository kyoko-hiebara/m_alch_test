from __future__ import annotations

import unittest

from graph_kmc import (
    AmorphousGraph,
    ChemistryRateProvider,
    EventTemplate,
    GraphKMC,
    GraphSite,
    SiteState,
)


def line_graph(size: int) -> AmorphousGraph:
    return AmorphousGraph(
        [
            GraphSite(
                site_id=index,
                state="intact",
                material="SiOCN" if index % 2 else "SiN",
                attributes={"exposure": 1.0 if index == 0 else 0.2},
            )
            for index in range(size)
        ],
        [(index, index + 1) for index in range(size - 1)],
    )


class GraphKMCTests(unittest.TestCase):
    def test_graph_stores_connectivity_state_and_attributes(self) -> None:
        graph = line_graph(4)
        self.assertEqual(graph.neighbors(1), (0, 2))
        self.assertEqual(graph.coordination(1), 2)
        self.assertEqual(graph.sites[0].attributes["exposure"], 1.0)
        graph.sites[2].state = "oxidized"
        self.assertEqual(graph.coordination(1, states=["oxidized"]), 1)
        copied = graph.copy()
        copied.sites[2].state = "removed"
        self.assertEqual(graph.sites[2].state, "oxidized")

    def test_seed_reproduces_rejection_free_event_sequence(self) -> None:
        templates = (
            EventTemplate(
                name="activate",
                from_states=SiteState.INTACT,
                to_state=SiteState.ACTIVATED,
                rate=lambda context: 1.0 + context.site.attributes["exposure"],
            ),
            EventTemplate(
                name="remove",
                from_states="activated",
                to_state="removed",
                rate=0.7,
            ),
        )
        first = GraphKMC(line_graph(6), templates, seed=123).run(max_events=8)
        second = GraphKMC(line_graph(6), templates, seed=123).run(max_events=8)
        signature_1 = [
            (record.event_name, record.site_id, record.time_s)
            for record in first.event_log
        ]
        signature_2 = [
            (record.event_name, record.site_id, record.time_s)
            for record in second.event_log
        ]
        self.assertEqual(signature_1, signature_2)
        self.assertEqual(first.event_count, 8)
        self.assertEqual(first.stop_reason, "max_events")
        self.assertEqual(sum(first.event_counts.values()), first.event_count)
        self.assertAlmostEqual(
            sum(first.event_flux_s.values()), first.event_count / first.elapsed_s
        )

    def test_rate_table_override_and_surrogate_are_supported(self) -> None:
        template = EventTemplate(
            name="react",
            from_states="intact",
            to_state="removed",
            rate=0.0,
        )
        provider = ChemistryRateProvider(
            table={("react", "SiN"): 2.0, "react": 0.25},
            surrogate=lambda context: 4.0
            if context.site.attributes["exposure"] > 0.9
            else None,
        )
        kmc = GraphKMC(line_graph(3), [template], seed=7, rate_provider=provider)
        self.assertAlmostEqual(kmc.total_rate_s, 4.0 + 0.25 + 2.0)
        result = kmc.run(max_events=1)
        self.assertEqual(result.event_count, 1)
        self.assertEqual(result.event_log[0].event_name, "react")

    def test_only_local_dependency_neighbourhood_is_recomputed(self) -> None:
        graph = line_graph(30)
        template = EventTemplate(
            name="convert",
            from_states="intact",
            to_state="oxidized",
            rate=lambda context: 1.0 + context.neighbour_count("oxidized"),
            dependency_radius=1,
        )
        kmc = GraphKMC(graph, [template], seed=2)
        initial_evaluations = kmc.rate_evaluations
        record = kmc.step()
        self.assertIsNotNone(record)
        updates = kmc.rate_evaluations - initial_evaluations
        # Focal site and at most its two nearest neighbours are refreshed.
        self.assertLessEqual(updates, 3)
        self.assertLess(updates, len(graph.sites))

    def test_changed_neighbour_rates_enable_growth_event(self) -> None:
        graph = line_graph(3)
        graph.sites[0].attributes["nucleation"] = 1.0
        nucleate = EventTemplate(
            name="nucleate",
            from_states="intact",
            to_state="oxidized",
            enabled=lambda context: context.site.attributes.get("nucleation", 0.0) > 0.5,
            rate=1.0,
            attribute_updates={"nucleation": 0.0},
            dependency_radius=1,
        )
        grow = EventTemplate(
            name="grow",
            from_states="intact",
            to_state="oxidized",
            enabled=lambda context: context.neighbour_count("oxidized") > 0,
            rate=3.0,
            dependency_radius=1,
        )
        kmc = GraphKMC(graph, [nucleate, grow], seed=11, copy_graph=False)
        first = kmc.step()
        self.assertEqual(first.event_name, "nucleate")
        self.assertGreater(kmc.total_rate_s, 0.0)
        second = kmc.step()
        self.assertEqual(second.event_name, "grow")
        self.assertEqual(abs(second.site_id - first.site_id), 1)

    def test_time_horizon_and_no_event_outputs_are_well_defined(self) -> None:
        graph = line_graph(2)
        result = GraphKMC(
            graph,
            [EventTemplate("never", "intact", "removed", 0.0)],
            seed=1,
        ).run(max_time_s=5.0)
        self.assertEqual(result.stop_reason, "no_events")
        self.assertEqual(result.event_count, 0)
        self.assertEqual(result.elapsed_s, 0.0)
        self.assertEqual(result.event_flux_s, {})

    def test_extremely_small_positive_rate_is_not_treated_as_exhausted(self) -> None:
        result = GraphKMC(
            AmorphousGraph([GraphSite(0)]),
            [EventTemplate("slow", "intact", "removed", 1.0e-20)],
            seed=5,
        ).run(max_events=1)
        self.assertEqual(result.event_count, 1)
        self.assertEqual(result.stop_reason, "max_events")
        self.assertGreater(result.elapsed_s, 0.0)
        self.assertEqual(result.final_state_counts, {"removed": 1})

    def test_propensity_tree_exhaustion_ignores_roundoff_residue(self) -> None:
        # Repeated local positive-to-zero updates previously left a tiny
        # positive Fenwick sum and could select a zero-rate slot.
        graph = line_graph(64)
        result = GraphKMC(
            graph,
            [EventTemplate("remove", "intact", "removed", 0.37)],
            seed=32,
        ).run(max_events=256)
        self.assertEqual(result.event_count, 64)
        self.assertEqual(result.stop_reason, "no_events")
        self.assertEqual(result.final_state_counts, {"removed": 64})
        self.assertEqual(result.final_total_rate_s, 0.0)


if __name__ == "__main__":
    unittest.main()

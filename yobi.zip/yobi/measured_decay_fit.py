"""Does the measured blanket etch keep going, or does it stall?

The user-supplied SiN blanket series is the only measured data this project
has.  Its interval rates fall monotonically -- ``0.6418``, ``0.4794``,
``0.3065 nm/min`` -- so the removal is not a constant-rate process, and the
usual response to a residue ("etch longer") cannot be assumed to work.

This module fits four removal laws to that series and reports what each one
implies for a thicker film.  The point is not to select a law: with four
points and no stated uncertainty, a saturating law and a logarithmic law fit
almost equally well and disagree completely at long times.  The point is that
**both of them, and the data itself, exclude the constant-rate assumption**,
and that they agree with each other up to roughly ``2 nm`` before diverging.

It also computes the one prediction that separates the two families of cause.
If the slowdown comes from something accumulating in the liquid, replacing the
liquid resets it and a split etch removes more than one continuous etch of the
same total time.  If the slowdown is a surface change, splitting does nothing.

**This is a fit to four points, not a kinetic model.** No mechanism is
asserted, no activation energy is derived, and the extrapolations past the
measured window are shown precisely so their disagreement is visible.
"""

from __future__ import annotations

import csv
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import numpy as np
from scipy.optimize import curve_fit


SCHEMA_VERSION = "measured-blanket-decay-fit/v1"
MODEL_NOTICE = (
    "Four-point fit to the user-supplied SiN blanket series. No mechanism is "
    "asserted and no activation energy is derived. The saturating and "
    "logarithmic laws fit comparably and disagree at long times; both, and the "
    "data, exclude a constant rate. Extrapolation beyond the 180 s measured "
    "window is shown only so the disagreement between laws is visible."
)

DEFAULT_INPUT_CSV = Path("inputs/sin_blanket_user_20260728.csv")

# The measured window. Anything past this is extrapolation, and is labelled so.
MEASURED_WINDOW_S = 180.0


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def load_series(
    path: Path = DEFAULT_INPUT_CSV,
) -> tuple[np.ndarray, np.ndarray]:
    """Read the cumulative etch series from the same CSV the clock uses."""

    times: list[float] = []
    amounts: list[float] = []
    with Path(path).open(encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream):
            times.append(float(row["time_s"]))
            amounts.append(float(row["etch_amount_nm"]))
    order = np.argsort(times)
    time_s = np.asarray(times, dtype=float)[order]
    etch_nm = np.asarray(amounts, dtype=float)[order]
    if time_s.size < 3:
        raise ValueError("a decay fit needs at least three points")
    if not np.all(np.diff(etch_nm) > 0.0):
        raise ValueError("cumulative etch must increase")
    return time_s, etch_nm


def interval_rates_nm_min(
    time_s: Sequence[float], etch_nm: Sequence[float]
) -> list[float]:
    """Rate over each measured interval, in nm/min."""

    time = np.asarray(time_s, dtype=float)
    etch = np.asarray(etch_nm, dtype=float)
    return [
        float(d / dt * 60.0) for d, dt in zip(np.diff(etch), np.diff(time))
    ]


def _linear(t, k):
    return k * t


def _parabolic(t, k):
    return k * np.sqrt(t)


def _logarithmic(t, amplitude, tau):
    return amplitude * np.log1p(t / tau)


def _saturating(t, ceiling, tau):
    return ceiling * (1.0 - np.exp(-t / tau))


@dataclass(frozen=True)
class RemovalLaw:
    """One fitted removal law and what it implies at long times."""

    name: str
    parameters: dict[str, float]
    rms_residual_nm: float
    has_finite_ceiling: bool
    ceiling_nm: float | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


_LAW_SPECS: tuple[tuple[str, Callable, tuple[str, ...], list[float], bool], ...] = (
    ("linear", _linear, ("rate_nm_s",), [0.008], False),
    ("parabolic", _parabolic, ("coefficient_nm_s_half",), [0.08], False),
    ("logarithmic", _logarithmic, ("amplitude_nm", "tau_s"), [1.0, 50.0], False),
    ("saturating", _saturating, ("ceiling_nm", "tau_s"), [2.0, 120.0], True),
)


def fit_laws(
    time_s: Sequence[float], etch_nm: Sequence[float]
) -> list[RemovalLaw]:
    """Fit every candidate law, best residual first."""

    time = np.asarray(time_s, dtype=float)
    etch = np.asarray(etch_nm, dtype=float)
    laws: list[RemovalLaw] = []
    for name, function, parameter_names, guess, finite_ceiling in _LAW_SPECS:
        values, _ = curve_fit(function, time, etch, p0=guess, maxfev=40000)
        residual = float(
            np.sqrt(np.mean((function(time, *values) - etch) ** 2))
        )
        parameters = {
            key: float(value) for key, value in zip(parameter_names, values)
        }
        laws.append(
            RemovalLaw(
                name=name,
                parameters=parameters,
                rms_residual_nm=residual,
                has_finite_ceiling=finite_ceiling,
                ceiling_nm=(
                    float(values[0]) if finite_ceiling else None
                ),
            )
        )
    return sorted(laws, key=lambda law: law.rms_residual_nm)


def time_to_remove_s(law: RemovalLaw, thickness_nm: float) -> float | None:
    """Time to remove a thickness, or ``None`` when the law never reaches it."""

    target = _finite_positive("thickness_nm", thickness_nm)
    parameters = law.parameters
    if law.name == "linear":
        return target / parameters["rate_nm_s"]
    if law.name == "parabolic":
        return (target / parameters["coefficient_nm_s_half"]) ** 2
    if law.name == "logarithmic":
        return parameters["tau_s"] * (
            math.exp(target / parameters["amplitude_nm"]) - 1.0
        )
    if law.name == "saturating":
        ceiling = parameters["ceiling_nm"]
        if target >= ceiling:
            return None
        return -parameters["tau_s"] * math.log(1.0 - target / ceiling)
    raise ValueError(f"unknown law: {law.name}")


def split_etch_prediction(
    time_s: Sequence[float],
    etch_nm: Sequence[float],
    *,
    segment_duration_s: float,
    segment_count: int,
) -> dict[str, Any]:
    """Split etch versus one continuous etch of the same total time.

    The split total assumes each segment starts from a fully reset surface and
    liquid, which is the *upper* bound of what replacing the liquid can buy.
    The continuous total is read from the measured series where possible.
    Comparing the two separates a liquid-side cause from a surface-side one:
    a liquid-side slowdown resets, a surface-side slowdown does not.
    """

    duration = _finite_positive("segment_duration_s", segment_duration_s)
    count = int(segment_count)
    if count < 2:
        raise ValueError("a split etch needs at least two segments")
    time = np.asarray(time_s, dtype=float)
    etch = np.asarray(etch_nm, dtype=float)
    total_s = duration * count

    per_segment = float(np.interp(duration, time, etch))
    split_total = per_segment * count
    if total_s <= float(time.max()):
        continuous_total = float(np.interp(total_s, time, etch))
        continuous_source = "measured"
    else:
        continuous_total = None
        continuous_source = "beyond the measured window"

    result: dict[str, Any] = {
        "segment_duration_s": duration,
        "segment_count": count,
        "total_duration_s": total_s,
        "per_segment_removal_nm": per_segment,
        "split_total_nm": split_total,
        "continuous_total_nm": continuous_total,
        "continuous_source": continuous_source,
        "interpretation": (
            "a split etch that removes more than the continuous etch points at "
            "a liquid-side cause; no difference points at a surface-side one"
        ),
    }
    if continuous_total is not None and continuous_total > 0.0:
        result["split_over_continuous"] = split_total / continuous_total
        result["excess_nm"] = split_total - continuous_total
    return result


def build_report(
    *,
    input_csv: Path = DEFAULT_INPUT_CSV,
    thicknesses_nm: Sequence[float] = (0.5, 1.0, 1.5, 2.0, 3.0, 5.0, 10.0),
    segment_duration_s: float = 60.0,
    segment_count: int = 3,
) -> dict[str, Any]:
    """Full decay report for the measured series."""

    time_s, etch_nm = load_series(input_csv)
    laws = fit_laws(time_s, etch_nm)
    best = laws[0]
    constant_rate = next(law for law in laws if law.name == "linear")

    removal_times = []
    for thickness in thicknesses_nm:
        row: dict[str, Any] = {
            "thickness_nm": float(thickness),
            "beyond_measured_window": {},
        }
        for law in laws:
            seconds = time_to_remove_s(law, thickness)
            row[law.name] = seconds
            row["beyond_measured_window"][law.name] = (
                seconds is None or seconds > MEASURED_WINDOW_S
            )
        removal_times.append(row)

    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "claim_boundary": {
            "point_count": int(time_s.size),
            "measured_window_s": MEASURED_WINDOW_S,
            "mechanism_asserted": False,
            "activation_energy_derived": False,
            "law_selected": False,
            "law_selection_note": (
                "the saturating and logarithmic laws fit comparably and "
                "disagree at long times; neither is selected here"
            ),
        },
        "series": {
            "time_s": [float(t) for t in time_s],
            "cumulative_etch_nm": [float(d) for d in etch_nm],
            "interval_rates_nm_min": interval_rates_nm_min(time_s, etch_nm),
            "final_over_initial_interval_rate": (
                interval_rates_nm_min(time_s, etch_nm)[-1]
                / interval_rates_nm_min(time_s, etch_nm)[0]
            ),
        },
        "laws": [law.to_dict() for law in laws],
        "best_fit": best.name,
        "constant_rate_residual_ratio": (
            constant_rate.rms_residual_nm / best.rms_residual_nm
        ),
        "removal_times_s": removal_times,
        "split_etch": split_etch_prediction(
            time_s,
            etch_nm,
            segment_duration_s=segment_duration_s,
            segment_count=segment_count,
        ),
    }


__all__ = [
    "DEFAULT_INPUT_CSV",
    "MEASURED_WINDOW_S",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "RemovalLaw",
    "build_report",
    "fit_laws",
    "interval_rates_nm_min",
    "load_series",
    "split_etch_prediction",
    "time_to_remove_s",
]

"""Targeted, multicore mechanism-discrimination study for GAP-FILL residue.

The global process-window sweep asks which uncertain parameters matter.  This
module asks a different question: *which deliberately imposed mechanism gives
the same residue burden but a different response to experimental probes?*

Eight one-cause-at-a-time profiles are first calibrated at a common reference
geometry to an apparent pre-second-WET burden.  Wall affinity is the explicit
exception: because it redistributes a fixed carrier without changing total
burden, it is evaluated at a fixed wall-selective ratio.  The profiles are then
run with common random numbers at low/centre/high settings of temperature, HF,
rinse delay, width, depth and second-WET strength.  The returned fingerprints
use stage-resolved continuous responses; the exclusive four-class display is
intentionally not used for inference.

All profile strengths, wetting/gas settings, deposit capture and second-WET
rates remain uncalibrated screening hypotheses.  Results are not recipes.
"""

from __future__ import annotations

import json
import math
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np

from literature_parameters import LITERATURE_ETCH_PRESETS, get_literature_preset
from literature_sweep import nominal_preset_names
from process_window_sampling import (
    default_parameter_definitions,
    strict_json_dumps,
    to_plain_data,
)
from process_window_sweep import (
    ProcessCaseSpec,
    ProcessWindowConfig,
    _case_objects,
    _deposit_metrics,
    _deposit_phase,
    _worker_initializer,
)
from spatial_etchability import SpatialEtchabilityParameters
from trench_geometry import GEOMETRY_PRESETS
from trench_graph_kmc import (
    SecondWetKMCParameters,
    TrenchKMCParameters,
    run_coupled_trench_kmc,
    run_second_wet_stage,
    trench_residue_metrics,
)
from wetting_2d import WettingParameters


SCHEMA_VERSION = "trench-mechanism-discrimination/v1"
MODEL_NOTICE = (
    "Uncalibrated mechanism-discrimination calculation only, not a process "
    "recipe. Eight cause amplitudes are burden-matched model hypotheses; wall "
    "affinity is a fixed-carrier redistribution morphology at ratio 8 because "
    "total burden cannot calibrate it. Primary HF speciation and diffusivity "
    "retain the current 298 K closures."
)

CAUSE_ORDER = (
    "intrinsic_reaction",
    "passivation",
    "hf_supply",
    "product_inhibition",
    "dry_down",
    "wetting_gas",
    "depth_floor_quality",
    "wall_quality",
    "wall_affinity",
)

DIAGNOSTIC_GEOMETRY_IDS = (
    "7_7_175",
    "8_8_140",
    "8_8_175",
    "8_8_210",
    "10_10_175",
)


@dataclass(frozen=True)
class CauseProfile:
    cause_id: str
    label_ja: str
    family: str
    severity_semantics: str
    calibration_candidates: tuple[float, ...]
    expected_signature: str

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["calibration_candidates"] = list(self.calibration_candidates)
        return result


CAUSE_PROFILES: Mapping[str, CauseProfile] = {
    "intrinsic_reaction": CauseProfile(
        "intrinsic_reaction", "固有反応律速", "reaction",
        "primary activation/removal rate multiplier; smaller is slower",
        (0.01, 0.02, 0.04, 0.08, 0.15, 0.20, 0.23, 0.26, 0.30, 0.60, 1.0, 2.0, 4.0, 8.0),
        "large temperature response, modest saturating HF response",
    ),
    "passivation": CauseProfile(
        "passivation", "passivation", "reaction_passivation",
        "passivation generation rate in s^-1; release decreases with strength",
        (0.02, 0.05, 0.12, 0.26, 0.35, 0.45, 0.50, 0.53, 0.56,
         0.58, 0.59, 0.60, 0.80, 1.2, 1.8, 2.5, 4.0, 7.0, 10.0),
        "temperature/second-WET recovery with a primary passivation cluster",
    ),
    "hf_supply": CauseProfile(
        "hf_supply", "HF供給律速", "transport",
        "effective HF transport-resistance multiplier; larger is stronger",
        (1.0, 3.0, 10.0, 30.0, 50.0, 70.0, 100.0, 300.0, 600.0, 1.0e3, 1.5e3, 2.0e3, 2.5e3, 3.0e3),
        "strong HF and aspect-ratio response with a bottom/top HF deficit",
    ),
    "product_inhibition": CauseProfile(
        "product_inhibition", "生成物阻害", "reaction_product",
        "dimensionless local product-inhibition coefficient",
        (0.0, 0.5, 1.0, 2.0, 3.0, 5.0, 8.0, 12.0, 20.0, 30.0, 60.0, 100.0, 200.0, 300.0),
        "primary residue follows product gradients without a passivation cluster",
    ),
    "dry_down": CauseProfile(
        "dry_down", "析出・dry-down", "post_hf_deposit",
        "asymptotic captured-product fraction",
        (1.0e-4, 5.0e-4, 0.002, 0.01, 0.05, 0.08, 0.12, 0.20, 0.50),
        "primary matrix invariant; deposit rises with rinse delay",
    ),
    "wetting_gas": CauseProfile(
        "wetting_gas", "濡れ遅延・gas pocket", "wetting_transport",
        "0--1 failure-mode amplitude controlling capillary delay and gas seed",
        (0.0, 0.05, 0.12, 0.25, 0.40, 0.60, 0.80, 1.0),
        "nonlinear width/depth response with delayed invasion; gas appears only after its activation depth",
    ),
    "depth_floor_quality": CauseProfile(
        "depth_floor_quality", "depth/floor膜質差", "film_quality",
        "common bottom-depth and floor etchability multiplier; smaller is harder",
        (1.0e-4, 5.0e-4, 0.002, 0.003, 0.004, 0.005, 0.006, 0.008, 0.01, 0.02, 0.05, 0.10, 0.20, 0.40, 0.70, 1.0),
        "bottom-local matrix residue already present after primary HF",
    ),
    "wall_quality": CauseProfile(
        "wall_quality", "wall膜質差", "film_quality",
        "sidewall etchability multiplier; smaller is harder",
        (1.0e-4, 5.0e-4, 0.002, 0.01, 0.02, 0.05, 0.10, 0.20, 0.40, 0.70, 1.0),
        "continuous native wall residue already present after primary HF",
    ),
    "wall_affinity": CauseProfile(
        "wall_affinity", "wall affinity", "post_hf_attachment",
        "wall/floor affinity ratio at fixed captured-product carrier",
        # Total burden cannot calibrate a redistribution-only parameter.  Use
        # one explicitly wall-selective morphology here; the independent
        # affinity sweep is performed by attachment_discrimination.py.
        (8.0,),
        "wall share/continuity changes more strongly than total deposit",
    ),
}


@dataclass(frozen=True)
class ProbeDefinition:
    """One low/centre/high experimental perturbation."""

    name: str
    label_ja: str
    kind: str
    parameter_name: str | None
    level_values: tuple[float, float, float]
    geometry_ids: tuple[str, str, str] | None = None

    def __post_init__(self) -> None:
        if not self.name or self.kind not in {"parameter", "geometry"}:
            raise ValueError("probe needs a name and kind parameter/geometry")
        values = tuple(float(value) for value in self.level_values)
        if len(values) != 3 or any(not math.isfinite(value) for value in values):
            raise ValueError("level_values must contain three finite values")
        object.__setattr__(self, "level_values", values)
        if self.kind == "parameter":
            if not self.parameter_name or self.geometry_ids is not None:
                raise ValueError("parameter probe needs parameter_name only")
        else:
            if self.parameter_name is not None or self.geometry_ids is None:
                raise ValueError("geometry probe needs geometry_ids only")
            if len(self.geometry_ids) != 3:
                raise ValueError("geometry_ids must contain low/centre/high IDs")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["level_values"] = list(self.level_values)
        if self.geometry_ids is not None:
            result["geometry_ids"] = list(self.geometry_ids)
        return result


def default_probe_definitions() -> tuple[ProbeDefinition, ...]:
    return (
        ProbeDefinition(
            "liquid_temperature", "液温", "parameter", "liquid_temperature_K",
            (278.15, 298.15, 318.15),
        ),
        ProbeDefinition(
            "substrate_temperature", "基板温度", "parameter",
            "substrate_temperature_K", (293.15, 323.15, 353.15),
        ),
        ProbeDefinition(
            "hf_concentration", "HF濃度", "parameter", "hf_bulk_scale",
            (0.50, 1.0, 1.50),
        ),
        ProbeDefinition(
            "rinse_delay", "rinse待ち時間", "parameter", "rinse_delay_s",
            (0.0, 30.0, 300.0),
        ),
        ProbeDefinition(
            "width", "trench幅", "geometry", None, (7.0, 8.0, 10.0),
            ("7_7_175", "8_8_175", "10_10_175"),
        ),
        ProbeDefinition(
            "depth", "trench深さ", "geometry", None, (140.0, 175.0, 210.0),
            ("8_8_140", "8_8_175", "8_8_210"),
        ),
        ProbeDefinition(
            "second_wet", "second-WET速度", "parameter",
            "second_wet_rate_multiplier", (0.0, 0.70, 2.0),
        ),
    )


@dataclass(frozen=True)
class MechanismDiscriminationConfig:
    """Execution and inference controls for the targeted study."""

    cause_ids: tuple[str, ...] = CAUSE_ORDER
    presets: tuple[str, ...] = field(default_factory=nominal_preset_names)
    probes: tuple[ProbeDefinition, ...] = field(default_factory=default_probe_definitions)
    diagnostic_geometry_ids: tuple[str, ...] = DIAGNOSTIC_GEOMETRY_IDS
    reference_geometry_id: str = "8_8_175"
    target_apparent_burden: float = 0.25
    calibration_seed: int = 271828
    replicate_seeds: tuple[int, ...] = (271828, 314159, 161803)
    calibration_candidates_override: Mapping[str, tuple[float, ...]] = field(
        default_factory=dict
    )
    bootstrap_samples: int = 400
    bootstrap_seed: int = 20260714
    ambiguity_distance: float = 1.0
    parallel_workers: int = 1
    grid_spacing_nm: float = 1.4
    reservoir_height_nm: float = 4.0
    lateral_margin_nm: float = 3.0
    primary_hf_duration_s: float = 300.0
    primary_sync_steps: int = 30
    maximum_events: int = 40_000
    second_wet_duration_s: float = 30.0
    deposit_reference_dissolution_rate_s: float = 0.025
    rinse_delay_capture_tau_s: float = 30.0
    sidewall_influence_length_nm: float = 2.0
    floor_influence_length_nm: float = 5.0
    minimum_material_rate_factor: float = 0.01
    wall_depth_bins: int = 24

    def __post_init__(self) -> None:
        if not self.cause_ids or len(set(self.cause_ids)) != len(self.cause_ids):
            raise ValueError("cause_ids must be non-empty and unique")
        unknown_causes = set(self.cause_ids).difference(CAUSE_PROFILES)
        if unknown_causes:
            raise ValueError(f"unknown causes: {sorted(unknown_causes)}")
        if not self.presets or set(self.presets).difference(LITERATURE_ETCH_PRESETS):
            raise ValueError("presets must be a non-empty known selection")
        if not self.probes or len({probe.name for probe in self.probes}) != len(self.probes):
            raise ValueError("probes must be non-empty with unique names")
        if self.reference_geometry_id not in self.diagnostic_geometry_ids:
            raise ValueError("reference geometry must be in diagnostic_geometry_ids")
        if len(set(self.diagnostic_geometry_ids)) != len(self.diagnostic_geometry_ids):
            raise ValueError("diagnostic geometry IDs must be unique")
        if not 0.0 < self.target_apparent_burden < 1.0:
            raise ValueError("target_apparent_burden must lie within (0, 1)")
        if self.calibration_seed < 0 or self.bootstrap_seed < 0:
            raise ValueError("seeds must be non-negative")
        if not self.replicate_seeds or any(seed < 0 for seed in self.replicate_seeds):
            raise ValueError("replicate_seeds must be non-empty and non-negative")
        if len(set(self.replicate_seeds)) != len(self.replicate_seeds):
            raise ValueError("replicate_seeds cannot contain duplicates")
        if self.bootstrap_samples < 0 or self.parallel_workers < 1:
            raise ValueError("bootstrap_samples >= 0 and parallel_workers >= 1 required")
        if not math.isfinite(self.ambiguity_distance) or self.ambiguity_distance <= 0.0:
            raise ValueError("ambiguity_distance must be finite and positive")
        for name in (
            "grid_spacing_nm", "reservoir_height_nm", "primary_hf_duration_s",
            "second_wet_duration_s", "deposit_reference_dissolution_rate_s",
            "rinse_delay_capture_tau_s", "sidewall_influence_length_nm",
            "floor_influence_length_nm", "minimum_material_rate_factor",
        ):
            if not math.isfinite(float(getattr(self, name))) or float(getattr(self, name)) <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.lateral_margin_nm < 0.0:
            raise ValueError("lateral_margin_nm must be non-negative")
        if self.primary_sync_steps < 1 or self.maximum_events < 1:
            raise ValueError("primary_sync_steps and maximum_events must be positive")
        if self.wall_depth_bins < 4:
            raise ValueError("wall_depth_bins must be at least four")
        for cause_id, values in self.calibration_candidates_override.items():
            if cause_id not in self.cause_ids or not values:
                raise ValueError("candidate overrides need a selected cause and values")
            if any(not math.isfinite(float(value)) for value in values):
                raise ValueError("calibration candidate overrides must be finite")

    def calibration_candidates(self, cause_id: str) -> tuple[float, ...]:
        values = self.calibration_candidates_override.get(
            cause_id, CAUSE_PROFILES[cause_id].calibration_candidates
        )
        return tuple(float(value) for value in values)

    def process_window_config(self) -> ProcessWindowConfig:
        missing = set(self.diagnostic_geometry_ids).difference(GEOMETRY_PRESETS)
        if missing:
            raise ValueError(
                "diagnostic geometries are not registered in GEOMETRY_PRESETS: "
                f"{sorted(missing)}"
            )
        return ProcessWindowConfig(
            geometries=tuple(self.diagnostic_geometry_ids),
            presets=tuple(self.presets),
            design_points=2,
            design_seed=self.bootstrap_seed,
            parameter_bounds_set="full",
            replicate_seeds=tuple(self.replicate_seeds),
            grid_spacing_nm=self.grid_spacing_nm,
            reservoir_height_nm=self.reservoir_height_nm,
            lateral_margin_nm=self.lateral_margin_nm,
            primary_hf_duration_s=self.primary_hf_duration_s,
            primary_sync_steps=self.primary_sync_steps,
            maximum_events=self.maximum_events,
            second_wet_duration_s=self.second_wet_duration_s,
            deposit_reference_dissolution_rate_s=self.deposit_reference_dissolution_rate_s,
            rinse_delay_capture_tau_s=self.rinse_delay_capture_tau_s,
            sidewall_influence_length_nm=self.sidewall_influence_length_nm,
            floor_influence_length_nm=self.floor_influence_length_nm,
            minimum_material_rate_factor=self.minimum_material_rate_factor,
            phase_levels=3,
            maximum_phase_pairs=0,
            bootstrap_samples=0,
            parallel_workers=self.parallel_workers,
            include_phase_maps=False,
            include_representatives=False,
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["cause_ids"] = list(self.cause_ids)
        result["presets"] = list(self.presets)
        result["diagnostic_geometry_ids"] = list(self.diagnostic_geometry_ids)
        result["replicate_seeds"] = list(self.replicate_seeds)
        result["probes"] = [probe.to_dict() for probe in self.probes]
        result["calibration_candidates_override"] = {
            key: list(values)
            for key, values in self.calibration_candidates_override.items()
        }
        return result


@dataclass(frozen=True)
class _MechanismJob:
    order: int
    case_group: str
    cause_id: str
    severity: float
    geometry_id: str
    preset_id: str
    seed: int
    parameters: Mapping[str, float]
    process_config: ProcessWindowConfig
    wall_depth_bins: int
    probe_name: str = "calibration"
    probe_level: str = "centre"
    probe_value: float = 0.0


LEVEL_NAMES = ("low", "centre", "high")

# A wall-affinity experiment needs a non-zero deposited-product carrier, but
# changing affinity must not change how much product is captured during
# dry-down.  Keep that carrier fixed while the affinity ratio only redistributes
# the conserved inventory between wall and bottom collectors.
WALL_AFFINITY_CARRIER_CAPTURE_FRACTION = 0.08


def _reference_parameters() -> dict[str, float]:
    values = {
        definition.name: float(definition.reference_value)
        for definition in default_parameter_definitions()
    }
    # Neutralize all optional residue causes before one profile is imposed.
    values.update(
        liquid_temperature_K=298.15,
        substrate_temperature_K=323.15,
        hf_bulk_scale=1.0,
        depth_quality_factor=1.0,
        wall_quality_factor=1.0,
        floor_quality_factor=1.0,
        product_inhibition_strength=0.0,
        passivation_generation_rate_s=0.0,
        passivation_release_rate_s=0.08,
        rinse_delay_s=30.0,
        wall_affinity=1.0,
        drydown_capture_fraction=0.0,
        second_wet_rate_multiplier=0.70,
    )
    return values


def _profile_parameters(
    cause_id: str, severity: float, base: Mapping[str, float]
) -> dict[str, float]:
    values = {key: float(value) for key, value in base.items()}
    if cause_id == "passivation":
        values["passivation_generation_rate_s"] = max(severity, 0.0)
        values["passivation_release_rate_s"] = max(0.001, 0.12 / (1.0 + 4.0 * severity))
    elif cause_id == "product_inhibition":
        values["product_inhibition_strength"] = max(severity, 0.0)
    elif cause_id == "dry_down":
        values["drydown_capture_fraction"] = min(max(severity, 0.0), 0.50)
    elif cause_id == "depth_floor_quality":
        values["depth_quality_factor"] = max(severity, 0.001)
        values["floor_quality_factor"] = max(severity, 0.001)
    elif cause_id == "wall_quality":
        values["wall_quality_factor"] = max(severity, 0.001)
    elif cause_id == "wall_affinity":
        values["wall_affinity"] = max(severity, 0.01)
        # Attachment needs a non-zero carrier, but affinity controls only where
        # the already-captured product lands.  Its total is deliberately
        # invariant to wall affinity.
        values["drydown_capture_fraction"] = (
            WALL_AFFINITY_CARRIER_CAPTURE_FRACTION
        )
    return values


def _profile_objects(
    cause_id: str,
    severity: float,
    kinetics: TrenchKMCParameters,
    coupling: Any,
    spatial: SpatialEtchabilityParameters,
    depth_nm: float,
    width_nm: float,
) -> tuple[TrenchKMCParameters, Any, SpatialEtchabilityParameters, WettingParameters | None]:
    wetting: WettingParameters | None = None
    # A faster neutral matrix clock gives every material room for the imposed
    # cause, rather than making the slow nominal SiOCN clock itself the label.
    rate_factor = 4.0
    if cause_id in {"dry_down", "wall_affinity"}:
        rate_factor = 10.0
    elif cause_id in {"passivation", "product_inhibition"}:
        rate_factor = 1.0
    elif cause_id in {"depth_floor_quality", "wall_quality"}:
        rate_factor = 0.60
    if cause_id == "intrinsic_reaction":
        rate_factor = max(severity, 0.001)
    kinetics = replace(
        kinetics,
        # Normalize the nominal graph clock across material presets before
        # imposing a cause. Chemistry, product yield and transport still remain
        # material-specific, while baseline blanket WER cannot become the label.
        activation_rate_s=2.2 * rate_factor,
        removal_rate_s=1.0 * rate_factor,
    )
    if cause_id == "hf_supply":
        resistance = max(severity, 1.0)
        coupling = replace(
            coupling,
            hf_diffusivity_nm2_s=coupling.hf_diffusivity_nm2_s / resistance,
            hf_interface_sink_velocity_nm_s=(
                coupling.hf_interface_sink_velocity_nm_s * math.sqrt(resistance)
            ),
        )
        kinetics = replace(
            kinetics,
            hf_half_activity=kinetics.hf_half_activity * math.sqrt(resistance),
        )
        aspect_ratio = depth_nm / width_nm
        attenuation = 1.0 / (
            1.0 + 0.02 * resistance * (aspect_ratio / (175.0 / 8.0)) ** 2
        )
        spatial = replace(
            spatial,
            bottom_rate_factor=spatial.bottom_rate_factor * attenuation,
            depth_exponent=1.5,
        )
    elif cause_id == "wetting_gas":
        # Meniscus entry and trapped-gas risks rise with aspect ratio.  Scale
        # the calibrated 8 nm x 175 nm amplitude by AR^2 so the crossed width
        # and depth probes exercise transport physics instead of changing only
        # the number of graph sites.
        reference_aspect_ratio = 175.0 / 8.0
        aspect_ratio = depth_nm / width_nm
        amplitude = min(
            max(severity, 0.0)
            * (aspect_ratio / reference_aspect_ratio) ** 2,
            1.0,
        )
        wetting = WettingParameters(
            enabled=True,
            # Dissolution of the initially solid GAP FILL inherits liquid.
            # The adverse hypothesis is an explicitly seeded pocket that
            # arrests the front after an AR-dependent fraction of the depth;
            # this avoids mistaking continuum/KMC synchronization frequency
            # for a physical capillary delay.
            new_void_filling_mode="liquid_inherited",
            advancing_contact_angle_deg=60.0,
            bottom_gas_pocket_seed_height_nm=0.12 * depth_nm * amplitude,
            bottom_gas_activation_depth_fraction=max(0.15, 1.0 - amplitude),
            gas_dissolution_time_s=1.0e12,
            gas_residual_fraction=min(1.0, 0.25 + 0.75 * amplitude),
            gas_compression_mode="none",
        )
    elif cause_id == "depth_floor_quality":
        spatial = replace(
            spatial,
            # A sub-linear depth profile extends the poor-film region above
            # the last few floor cells, making an equal-burden diagnostic
            # comparison possible without changing the bottom-local topology.
            depth_exponent=0.35,
            floor_influence_length_nm=max(spatial.floor_influence_length_nm, 10.0),
            minimum_combined_rate_factor=0.0,
        )
    elif cause_id == "wall_quality":
        spatial = replace(
            spatial,
            sidewall_influence_length_nm=max(
                spatial.sidewall_influence_length_nm, width_nm
            ),
            minimum_combined_rate_factor=0.0,
        )
    return kinetics, coupling, spatial, wetting


def _longest_true_run(mask: Sequence[bool]) -> int:
    longest = current = 0
    for value in mask:
        current = current + 1 if bool(value) else 0
        longest = max(longest, current)
    return longest


def _native_wall_topology(graph: Any, layout: Any, bins: int) -> dict[str, object]:
    valid = np.zeros(bins, dtype=bool)
    occupied = np.zeros(bins, dtype=bool)
    depth = float(layout.grid.geometry.depth_nm)
    for site_id in layout.matrix_site_ids:
        site = graph.sites[site_id]
        if site.attributes.get("sidewall_flag", 0.0) <= 0.5:
            continue
        index = min(
            bins - 1,
            max(0, int(float(site.attributes["depth_nm"]) / depth * bins)),
        )
        valid[index] = True
        if site.state != "removed":
            occupied[index] = True
    denominator = int(np.count_nonzero(valid))
    run = _longest_true_run(occupied & valid)
    return {
        "coverage_fraction": (
            float(np.count_nonzero(occupied & valid)) / denominator
            if denominator else 0.0
        ),
        "longest_run_fraction": float(run) / denominator if denominator else 0.0,
        "valid_by_depth": valid.tolist(),
        "occupied_by_depth": (occupied & valid).tolist(),
    }


def _deposit_wall_topology(phase: Any, bins: int) -> dict[str, object]:
    grid = phase.grid
    contact = np.asarray(phase.wall_contact_length_nm, dtype=float) > 0.0
    occupied_cells = contact & (np.asarray(phase.wall_thickness_nm, dtype=float) > 0.0)
    valid = np.zeros(bins, dtype=bool)
    occupied = np.zeros(bins, dtype=bool)
    rows, _ = np.nonzero(contact)
    for row in rows:
        index = min(
            bins - 1,
            max(0, int(float(grid.depth_nm[row]) / grid.geometry.depth_nm * bins)),
        )
        valid[index] = True
        if bool(np.any(occupied_cells[row, :])):
            occupied[index] = True
    denominator = int(np.count_nonzero(valid))
    run = _longest_true_run(occupied & valid)
    return {
        "coverage_fraction": (
            float(np.count_nonzero(occupied & valid)) / denominator
            if denominator else 0.0
        ),
        "longest_run_fraction": float(run) / denominator if denominator else 0.0,
        "valid_by_depth": valid.tolist(),
        "occupied_by_depth": (occupied & valid).tolist(),
    }


def _depth_field_ratio(frame: Any, grid: Any, field_name: str) -> tuple[float, bool]:
    field = np.asarray(getattr(frame, field_name), dtype=float)
    interface = np.asarray(frame.interface_mask, dtype=bool)
    depth_fraction = grid.depth_mesh_nm / float(grid.geometry.depth_nm)
    cavity_depth = depth_fraction >= 0.0
    top = interface & cavity_depth & (depth_fraction <= 0.25)
    bottom = interface & cavity_depth & (depth_fraction >= 0.75)
    if not np.any(top) or not np.any(bottom):
        # A cleared top region is common.  Fall back to the shallowest/deepest
        # quartiles of the *remaining* interface while recording validity.
        rows, cols = np.nonzero(interface & cavity_depth)
        if len(rows) < 4:
            return 0.0, False
        order = np.argsort(depth_fraction[rows, cols])
        count = max(1, len(order) // 4)
        top_values = field[rows[order[:count]], cols[order[:count]]]
        bottom_values = field[rows[order[-count:]], cols[order[-count:]]]
    else:
        top_values = field[top]
        bottom_values = field[bottom]
    top_mean = float(np.mean(top_values))
    bottom_mean = float(np.mean(bottom_values))
    if top_mean <= 1.0e-30:
        return 0.0, False
    ratio = bottom_mean / top_mean
    return (float(ratio), bool(math.isfinite(ratio))) if math.isfinite(ratio) else (0.0, False)


def _wetting_diagnostics(outcome: Any) -> dict[str, float | bool]:
    frame, grid = outcome.final_frame, outcome.layout.grid
    cavity = np.asarray(grid.cavity_mask, dtype=bool)
    liquid = np.asarray(frame.liquid_mask, dtype=bool) & cavity
    gas = np.asarray(frame.gas_mask, dtype=bool) & cavity
    opened = liquid | gas
    denominator = int(np.count_nonzero(opened))
    gas_fraction = float(np.count_nonzero(gas)) / denominator if denominator else 0.0
    if np.any(liquid):
        deepest = float(np.max(grid.depth_mesh_nm[liquid])) / float(grid.geometry.depth_nm)
        deepest = min(max(deepest, 0.0), 1.0)
    else:
        deepest = 0.0
    maximum_gas = gas_fraction
    for item in outcome.sync_history:
        gas_count = int(item.get("gas_cavity_cell_count", 0))
        liquid_count = int(item.get("liquid_cavity_cell_count", 0))
        total = gas_count + liquid_count
        if total:
            maximum_gas = max(maximum_gas, gas_count / total)
    hf_ratio, hf_valid = _depth_field_ratio(frame, grid, "hf_at_solid")
    product_ratio, product_valid = _depth_field_ratio(frame, grid, "product_at_solid")
    return {
        "hf_bottom_to_top_ratio": hf_ratio,
        "hf_bottom_to_top_ratio_valid": hf_valid,
        "product_bottom_to_top_ratio": product_ratio,
        "product_bottom_to_top_ratio_valid": product_valid,
        "final_gas_fraction": gas_fraction,
        "maximum_gas_fraction": float(maximum_gas),
        "deepest_wetted_fraction": deepest,
    }


def _region_fraction(summary: Mapping[str, Any], name: str) -> float:
    region = summary["region_metrics"][name]
    return float(region["remaining_fraction"])


def _run_mechanism_case(job: _MechanismJob) -> dict[str, object]:
    parameters = _profile_parameters(job.cause_id, job.severity, job.parameters)
    spec = ProcessCaseSpec(
        order=job.order,
        case_group=job.case_group,
        design_index=job.order,
        geometry_id=job.geometry_id,
        preset_id=job.preset_id,
        replicate_index=0,
        seed=job.seed,
        parameters=parameters,
        design_role="mechanism_probe",
    )
    grid, graph_config, coupling, kinetics, spatial, derived = _case_objects(
        spec, job.process_config
    )
    kinetics, coupling, spatial, wetting = _profile_objects(
        job.cause_id,
        job.severity,
        kinetics,
        coupling,
        spatial,
        float(grid.geometry.depth_nm),
        float(grid.geometry.top_width_nm),
    )
    outcome = run_coupled_trench_kmc(
        grid,
        graph_config=graph_config,
        coupling_parameters=coupling,
        kmc_parameters=kinetics,
        spatial_etchability_parameters=spatial,
        wetting_parameters=wetting,
        seed=job.seed,
    )
    primary = outcome.summary()
    removed_count = int(primary["state_counts"].get("removed", 0))
    phase, formation, capture = _deposit_phase(
        outcome, spec, job.process_config, removed_count=removed_count
    )
    deposit_pre = _deposit_metrics(phase)
    native_primary = _native_wall_topology(
        outcome.graph, outcome.layout, job.wall_depth_bins
    )
    deposit_primary = _deposit_wall_topology(phase, job.wall_depth_bins)
    primary_remaining = float(primary["remaining_fraction"])
    pre_deposit_fraction = float(deposit_pre["deposit_collector_fraction"])
    pre_burden = min(1.0, primary_remaining + pre_deposit_fraction)

    second_multiplier = float(parameters["second_wet_rate_multiplier"])
    second = run_second_wet_stage(
        outcome,
        parameters=SecondWetKMCParameters(
            duration_s=job.process_config.second_wet_duration_s,
            common_rate_multiplier=second_multiplier,
            matrix_removal_rate_s=kinetics.removal_rate_s,
            deposit_dissolution_rate_s=0.0,
        ),
        seed=job.seed + 1_000_003,
    )
    phase.dissolve(
        job.process_config.second_wet_duration_s,
        wall_rate_s=(
            job.process_config.deposit_reference_dissolution_rate_s * second_multiplier
        ),
        bottom_rate_s=(
            job.process_config.deposit_reference_dissolution_rate_s * second_multiplier
        ),
    )
    final = trench_residue_metrics(second.graph, outcome.layout)
    deposit_final = _deposit_metrics(phase)
    native_final = _native_wall_topology(second.graph, outcome.layout, job.wall_depth_bins)
    deposit_final_topology = _deposit_wall_topology(phase, job.wall_depth_bins)
    final_remaining = float(final["remaining_fraction"])
    final_deposit_fraction = float(deposit_final["deposit_collector_fraction"])

    matrix_recovery = (
        (primary_remaining - final_remaining) / primary_remaining
        if primary_remaining > 0.0 else 0.0
    )
    deposit_recovery = (
        (pre_deposit_fraction - final_deposit_fraction) / pre_deposit_fraction
        if pre_deposit_fraction > 0.0 else 0.0
    )
    primary_passivated = int(primary["state_counts"].get("passivated", 0))
    site_count = int(primary["matrix_site_count"])
    wet = _wetting_diagnostics(outcome)
    metrics: dict[str, float] = {
        "primary_matrix_remaining_fraction": primary_remaining,
        "primary_bottom_remaining_fraction": _region_fraction(primary, "bottom"),
        "primary_wall_remaining_fraction": _region_fraction(primary, "sidewall"),
        "primary_passivated_fraction": primary_passivated / site_count if site_count else 0.0,
        "primary_passivation_cluster_fraction": (
            int(primary["largest_passivation_cluster"]) / site_count if site_count else 0.0
        ),
        "pre_second_deposit_fraction": pre_deposit_fraction,
        "pre_second_wall_deposit_fraction": (
            pre_deposit_fraction * float(deposit_pre["deposit_wall_fraction"])
        ),
        "pre_second_apparent_burden": pre_burden,
        "final_matrix_remaining_fraction": final_remaining,
        "final_bottom_remaining_fraction": _region_fraction(final, "bottom"),
        "final_wall_remaining_fraction": _region_fraction(final, "sidewall"),
        "final_deposit_fraction": final_deposit_fraction,
        "final_apparent_burden": min(1.0, final_remaining + final_deposit_fraction),
        "second_wet_matrix_recovery_fraction": min(max(matrix_recovery, 0.0), 1.0),
        "second_wet_deposit_recovery_fraction": min(max(deposit_recovery, 0.0), 1.0),
        "hf_bottom_to_top_ratio": float(wet["hf_bottom_to_top_ratio"]),
        "product_bottom_to_top_ratio": float(wet["product_bottom_to_top_ratio"]),
        "maximum_gas_fraction": float(wet["maximum_gas_fraction"]),
        "deepest_wetted_fraction": float(wet["deepest_wetted_fraction"]),
        "native_wall_coverage_primary": float(native_primary["coverage_fraction"]),
        "native_wall_longest_run_primary": float(native_primary["longest_run_fraction"]),
        "native_wall_coverage_final": float(native_final["coverage_fraction"]),
        "native_wall_longest_run_final": float(native_final["longest_run_fraction"]),
        "deposit_wall_coverage_pre_second": float(deposit_primary["coverage_fraction"]),
        "deposit_wall_longest_run_pre_second": float(deposit_primary["longest_run_fraction"]),
        "deposit_wall_coverage_final": float(deposit_final_topology["coverage_fraction"]),
        "deposit_wall_longest_run_final": float(deposit_final_topology["longest_run_fraction"]),
    }
    case_id = (
        f"{job.case_group}__{job.cause_id}__{job.preset_id}__{job.probe_name}__"
        f"{job.probe_level}__s{job.seed}__n{job.order:05d}"
    )
    return to_plain_data({
        "order": job.order,
        "case_id": case_id,
        "case_group": job.case_group,
        "cause_id": job.cause_id,
        "severity": float(job.severity),
        "geometry_id": job.geometry_id,
        "preset_id": job.preset_id,
        "material": derived["material"],
        "seed": job.seed,
        "probe_name": job.probe_name,
        "probe_level": job.probe_level,
        "probe_value": float(job.probe_value),
        "status": "ok",
        "parameters": parameters,
        "metrics": metrics,
        "diagnostic_validity": {
            "hf_bottom_to_top_ratio": bool(wet["hf_bottom_to_top_ratio_valid"]),
            "product_bottom_to_top_ratio": bool(wet["product_bottom_to_top_ratio_valid"]),
        },
        "spatial_profile": {
            "normalized_depth_bin_centres": [
                (index + 0.5) / job.wall_depth_bins
                for index in range(job.wall_depth_bins)
            ],
            "primary_native_wall_valid": native_primary["valid_by_depth"],
            "primary_native_wall_occupied": native_primary["occupied_by_depth"],
            "final_native_wall_occupied": native_final["occupied_by_depth"],
            "pre_second_deposit_wall_valid": deposit_primary["valid_by_depth"],
            "pre_second_deposit_wall_occupied": deposit_primary["occupied_by_depth"],
            "final_deposit_wall_occupied": deposit_final_topology["occupied_by_depth"],
            "primary_bottom_remaining_fraction": _region_fraction(primary, "bottom"),
            "final_bottom_remaining_fraction": _region_fraction(final, "bottom"),
        },
        "stage_summaries": {
            "primary_hf": primary,
            "rinse_delay_and_drydown": {
                "capture_closure": capture,
                "formation": formation,
                "deposit_metrics": deposit_pre,
            },
            "second_wet_matrix": second.summary(),
            "final": final,
            "final_deposit_metrics": deposit_final,
        },
        "model_parameters": {
            "kinetics": asdict(kinetics),
            "coupling": asdict(coupling),
            "spatial_etchability": spatial.to_dict(),
            "wetting": None if wetting is None else wetting.to_dict(),
        },
    })


def _mechanism_worker(job: _MechanismJob) -> dict[str, object]:
    try:
        return _run_mechanism_case(job)
    except Exception as exc:  # Keep a broad diagnostic design running.
        return {
            "order": job.order,
            "case_group": job.case_group,
            "cause_id": job.cause_id,
            "severity": float(job.severity),
            "geometry_id": job.geometry_id,
            "preset_id": job.preset_id,
            "seed": job.seed,
            "probe_name": job.probe_name,
            "probe_level": job.probe_level,
            "probe_value": float(job.probe_value),
            "status": "failed",
            "error_type": type(exc).__name__,
            "error_message": str(exc),
        }


def _execute_jobs(jobs: Sequence[_MechanismJob], workers: int) -> list[dict[str, object]]:
    if workers == 1:
        return [_mechanism_worker(job) for job in jobs]
    with ProcessPoolExecutor(
        max_workers=min(workers, len(jobs)), initializer=_worker_initializer
    ) as executor:
        chunksize = max(1, len(jobs) // max(1, workers * 16))
        return list(executor.map(_mechanism_worker, jobs, chunksize=chunksize))


FINGERPRINT_METRICS = (
    "primary_matrix_remaining_fraction",
    "primary_bottom_remaining_fraction",
    "primary_wall_remaining_fraction",
    "primary_passivated_fraction",
    "primary_passivation_cluster_fraction",
    "pre_second_deposit_fraction",
    "pre_second_wall_deposit_fraction",
    "pre_second_apparent_burden",
    "final_matrix_remaining_fraction",
    "final_apparent_burden",
    "second_wet_matrix_recovery_fraction",
    "second_wet_deposit_recovery_fraction",
    "hf_bottom_to_top_ratio",
    "product_bottom_to_top_ratio",
    "maximum_gas_fraction",
    "deepest_wetted_fraction",
    "native_wall_coverage_primary",
    "native_wall_longest_run_primary",
    "deposit_wall_coverage_pre_second",
    "deposit_wall_longest_run_pre_second",
)

_RATIO_METRICS = {"hf_bottom_to_top_ratio", "product_bottom_to_top_ratio"}


def _metric_case_valid(case: Mapping[str, object], metric: str) -> bool:
    validity = case.get("diagnostic_validity", {})
    return not isinstance(validity, Mapping) or bool(validity.get(metric, True))


def _response_transform(metric: str, value: float) -> float:
    number = float(value)
    if metric in _RATIO_METRICS:
        return math.log1p(max(number, 0.0))
    clipped = min(max(number, 0.0), 1.0)
    return 2.0 * math.asin(math.sqrt(clipped))


def _response_scales(cases: Sequence[Mapping[str, object]]) -> dict[str, float]:
    result: dict[str, float] = {}
    for metric in FINGERPRINT_METRICS:
        values = [
            _response_transform(metric, float(case["metrics"][metric]))
            for case in cases
            if case.get("status") == "ok"
            and isinstance(case.get("metrics"), Mapping)
            and metric in case["metrics"]
            and _metric_case_valid(case, metric)
        ]
        if not values:
            result[metric] = 0.05
            continue
        median = float(np.median(values))
        mad = float(np.median(np.abs(np.asarray(values) - median)))
        result[metric] = max(1.4826 * mad, 0.05)
    return result


def _bootstrap_median_ci(
    values: Sequence[float], samples: int, rng: np.random.Generator
) -> tuple[float, float, float]:
    array = np.asarray(values, dtype=float)
    if array.size == 0:
        return 0.0, 0.0, 0.0
    estimate = float(np.median(array))
    if samples <= 0 or array.size == 1:
        return estimate, estimate, estimate
    indices = rng.integers(0, array.size, size=(samples, array.size))
    boot = np.median(array[indices], axis=1)
    return estimate, float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))


def _aggregate_fingerprints(
    cases: Sequence[Mapping[str, object]],
    config: MechanismDiscriminationConfig,
) -> tuple[list[dict[str, object]], dict[str, float]]:
    scales = _response_scales(cases)
    fingerprints: list[dict[str, object]] = []
    for preset_id in config.presets:
        for cause_id in config.cause_ids:
            entries: list[dict[str, object]] = []
            for probe_index, probe in enumerate(config.probes):
                subset = [
                    case for case in cases
                    if case.get("status") == "ok"
                    and case.get("preset_id") == preset_id
                    and case.get("cause_id") == cause_id
                    and case.get("probe_name") == probe.name
                ]
                by_seed_level = {
                    (int(case["seed"]), str(case["probe_level"])): case
                    for case in subset
                }
                for metric_index, metric in enumerate(FINGERPRINT_METRICS):
                    linear_values: list[float] = []
                    curvature_values: list[float] = []
                    for seed in config.replicate_seeds:
                        triplet = [
                            by_seed_level.get((seed, level)) for level in LEVEL_NAMES
                        ]
                        if any(item is None for item in triplet):
                            continue
                        if any(
                            not _metric_case_valid(item, metric)
                            for item in triplet  # type: ignore[arg-type]
                        ):
                            continue
                        transformed = [
                            _response_transform(metric, float(item["metrics"][metric]))
                            for item in triplet  # type: ignore[union-attr]
                        ]
                        scale = scales[metric]
                        linear_values.append((transformed[2] - transformed[0]) / (2.0 * scale))
                        curvature_values.append(
                            (transformed[2] - 2.0 * transformed[1] + transformed[0]) / scale
                        )
                    rng = np.random.default_rng(
                        config.bootstrap_seed + 1009 * probe_index + 9176 * metric_index
                    )
                    linear, linear_low, linear_high = _bootstrap_median_ci(
                        linear_values, config.bootstrap_samples, rng
                    )
                    curvature, curve_low, curve_high = _bootstrap_median_ci(
                        curvature_values, config.bootstrap_samples, rng
                    )
                    entries.append({
                        "component_id": f"{probe.name}:{metric}",
                        "probe": probe.name,
                        "metric": metric,
                        "valid": bool(linear_values),
                        "paired_seed_count": len(linear_values),
                        "linear_effect": linear,
                        "linear_ci95": [linear_low, linear_high],
                        "curvature_effect": curvature,
                        "curvature_ci95": [curve_low, curve_high],
                        "response_scale": scales[metric],
                    })
            material = get_literature_preset(preset_id).material
            fingerprints.append({
                "cause_id": cause_id,
                "preset_id": preset_id,
                "material": material,
                "entries": entries,
            })
    return fingerprints, scales


def _fingerprint_vector(
    fingerprint: Mapping[str, object], probes: set[str] | None = None
) -> dict[str, tuple[float, float]]:
    result: dict[str, tuple[float, float]] = {}
    for entry in fingerprint["entries"]:  # type: ignore[index]
        if not entry.get("valid", False):
            continue
        if probes is not None and str(entry["probe"]) not in probes:
            continue
        result[str(entry["component_id"])] = (
            float(entry["linear_effect"]), float(entry["curvature_effect"])
        )
    return result


def _robust_vector_distance(
    left: Mapping[str, tuple[float, float]],
    right: Mapping[str, tuple[float, float]],
) -> tuple[float, int]:
    common = sorted(set(left).intersection(right))
    differences: list[float] = []
    for key in common:
        for index in (0, 1):
            differences.append(min(abs(left[key][index] - right[key][index]), 6.0))
    if not differences:
        return 0.0, 0
    return float(math.sqrt(np.mean(np.square(differences)))), len(differences)


def _cumulative_vector_distance(
    left: Mapping[str, tuple[float, float]],
    right: Mapping[str, tuple[float, float]],
) -> tuple[float, int]:
    """Add independent fingerprint evidence without RMS renormalization."""

    common = sorted(set(left).intersection(right))
    differences = [
        min(abs(left[key][index] - right[key][index]), 6.0)
        for key in common
        for index in (0, 1)
    ]
    if not differences:
        return 0.0, 0
    return float(math.sqrt(np.sum(np.square(differences)))), len(differences)


def _pairwise_distances(
    fingerprints: Sequence[Mapping[str, object]],
    config: MechanismDiscriminationConfig,
    probes: set[str] | None = None,
) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for preset_id in config.presets:
        subset = [item for item in fingerprints if item["preset_id"] == preset_id]
        for left_index, left in enumerate(subset):
            for right in subset[left_index + 1:]:
                distance, components = _robust_vector_distance(
                    _fingerprint_vector(left, probes), _fingerprint_vector(right, probes)
                )
                result.append({
                    "preset_id": preset_id,
                    "material": left["material"],
                    "left_cause": left["cause_id"],
                    "right_cause": right["cause_id"],
                    "robust_distance": distance,
                    "component_count": components,
                    "ambiguous": components == 0 or distance < config.ambiguity_distance,
                })
    return result


def _greedy_probe_order(
    fingerprints: Sequence[Mapping[str, object]], config: MechanismDiscriminationConfig
) -> list[dict[str, object]]:
    result: list[dict[str, object]] = []
    for preset_id in config.presets:
        selected: set[str] = set()
        remaining = {probe.name for probe in config.probes}
        steps: list[dict[str, object]] = []
        subset = [
            item for item in fingerprints if item["preset_id"] == preset_id
        ]
        while remaining:
            candidates: list[tuple[float, float, str]] = []
            for probe_name in sorted(remaining):
                active = selected | {probe_name}
                values: list[float] = []
                for left_index, left in enumerate(subset):
                    for right in subset[left_index + 1:]:
                        distance, _ = _cumulative_vector_distance(
                            _fingerprint_vector(left, active),
                            _fingerprint_vector(right, active),
                        )
                        values.append(distance)
                minimum = min(values) if values else 0.0
                median = float(np.median(values)) if values else 0.0
                candidates.append((minimum, median, probe_name))
            minimum, median, chosen = max(candidates)
            selected.add(chosen)
            remaining.remove(chosen)
            steps.append({
                "step": len(steps) + 1,
                "probe": chosen,
                "minimum_pair_distance": minimum,
                "median_pair_distance": median,
                "distance_metric": "cumulative_root_sum_square",
            })
        result.append({
            "preset_id": preset_id,
            "material": get_literature_preset(preset_id).material,
            "steps": steps,
        })
    return result


def _diagnosis_table(
    fingerprints: Sequence[Mapping[str, object]],
    pairwise: Sequence[Mapping[str, object]],
    probe_cases: Sequence[Mapping[str, object]],
    config: MechanismDiscriminationConfig,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for fingerprint in fingerprints:
        cause_id = str(fingerprint["cause_id"])
        preset_id = str(fingerprint["preset_id"])
        strengths: dict[str, float] = {}
        burden_direction: dict[str, str] = {}
        for probe in config.probes:
            entries = [
                item for item in fingerprint["entries"]
                if item["probe"] == probe.name and item["valid"]
            ]
            effects = [float(item["linear_effect"]) for item in entries]
            strengths[probe.name] = (
                float(math.sqrt(np.mean(np.square(effects)))) if effects else 0.0
            )
            burden = next(
                (float(item["linear_effect"]) for item in entries
                 if item["metric"] == "pre_second_apparent_burden"),
                0.0,
            )
            burden_direction[probe.name] = (
                "increases_residue" if burden > 0.25
                else "decreases_residue" if burden < -0.25
                else "weak_or_flat"
            )
        relevant_pairs = [
            item for item in pairwise
            if item["preset_id"] == preset_id
            and cause_id in {item["left_cause"], item["right_cause"]}
        ]
        relevant_pairs.sort(key=lambda item: float(item["robust_distance"]))
        ambiguous_with = [
            (item["right_cause"] if item["left_cause"] == cause_id else item["left_cause"])
            for item in relevant_pairs if item["ambiguous"]
        ]
        centres = [
            case for case in probe_cases
            if case.get("status") == "ok"
            and case.get("cause_id") == cause_id
            and case.get("preset_id") == preset_id
            and case.get("probe_level") == "centre"
        ]
        def centre_median(metric: str) -> float:
            values = [float(case["metrics"][metric]) for case in centres]
            return float(np.median(values)) if values else 0.0

        def probe_median(probe: str, level: str, metric: str) -> float:
            values = [
                float(case["metrics"][metric])
                for case in probe_cases
                if case.get("status") == "ok"
                and case.get("cause_id") == cause_id
                and case.get("preset_id") == preset_id
                and case.get("probe_name") == probe
                and case.get("probe_level") == level
            ]
            return float(np.median(values)) if values else 0.0

        raw_effects_pp = {
            "liquid_temperature_residue_reduction_pp": 100.0 * (
                probe_median("liquid_temperature", "low", "primary_matrix_remaining_fraction")
                - probe_median("liquid_temperature", "high", "primary_matrix_remaining_fraction")
            ),
            "substrate_temperature_residue_reduction_pp": 100.0 * (
                probe_median("substrate_temperature", "low", "primary_matrix_remaining_fraction")
                - probe_median("substrate_temperature", "high", "primary_matrix_remaining_fraction")
            ),
            "hf_concentration_residue_reduction_pp": 100.0 * (
                probe_median("hf_concentration", "low", "primary_matrix_remaining_fraction")
                - probe_median("hf_concentration", "high", "primary_matrix_remaining_fraction")
            ),
            "rinse_delay_deposit_increase_pp": 100.0 * (
                probe_median("rinse_delay", "high", "pre_second_deposit_fraction")
                - probe_median("rinse_delay", "low", "pre_second_deposit_fraction")
            ),
            "narrow_width_residue_penalty_pp": 100.0 * (
                probe_median("width", "low", "primary_matrix_remaining_fraction")
                - probe_median("width", "high", "primary_matrix_remaining_fraction")
            ),
            "depth_residue_penalty_pp": 100.0 * (
                probe_median("depth", "high", "primary_matrix_remaining_fraction")
                - probe_median("depth", "low", "primary_matrix_remaining_fraction")
            ),
            "second_wet_residue_reduction_pp": 100.0 * (
                probe_median("second_wet", "low", "final_apparent_burden")
                - probe_median("second_wet", "high", "final_apparent_burden")
            ),
        }
        strongest = max(strengths, key=strengths.get) if strengths else "none"
        rows.append({
            "cause_id": cause_id,
            "cause_label_ja": CAUSE_PROFILES[cause_id].label_ja,
            "preset_id": preset_id,
            "material": fingerprint["material"],
            "strongest_probe": strongest,
            "probe_strengths": strengths,
            "burden_directions": burden_direction,
            "raw_probe_effects_percentage_points": raw_effects_pp,
            "primary_passivated_fraction_at_centre": centre_median(
                "primary_passivated_fraction"
            ),
            "primary_passivation_cluster_fraction_at_centre": centre_median(
                "primary_passivation_cluster_fraction"
            ),
            "primary_bottom_remaining_fraction_at_centre": centre_median(
                "primary_bottom_remaining_fraction"
            ),
            "primary_wall_remaining_fraction_at_centre": centre_median(
                "primary_wall_remaining_fraction"
            ),
            "native_wall_longest_run_at_centre": centre_median(
                "native_wall_longest_run_primary"
            ),
            "deposit_wall_longest_run_at_centre": centre_median(
                "deposit_wall_longest_run_pre_second"
            ),
            "maximum_gas_fraction_at_centre": centre_median("maximum_gas_fraction"),
            "deepest_wetted_fraction_at_centre": centre_median(
                "deepest_wetted_fraction"
            ),
            "nearest_other_cause": (
                None if not relevant_pairs else (
                    relevant_pairs[0]["right_cause"]
                    if relevant_pairs[0]["left_cause"] == cause_id
                    else relevant_pairs[0]["left_cause"]
                )
            ),
            "nearest_distance": 0.0 if not relevant_pairs else float(
                relevant_pairs[0]["robust_distance"]
            ),
            "identifiability": "ambiguous" if ambiguous_with else "distinct_in_model",
            "ambiguous_with": ambiguous_with,
            "expected_signature": CAUSE_PROFILES[cause_id].expected_signature,
        })
    return rows


def diagnose_fingerprint(
    observed_components: Mapping[str, float],
    fingerprints: Sequence[Mapping[str, object]],
    *,
    preset_id: str,
    ambiguity_margin: float = 0.25,
) -> dict[str, object]:
    """Compare normalized observed linear effects with model templates.

    Keys must be ``"probe:metric"`` component IDs from the study payload.
    A small best/second-best distance gap is reported as ambiguous instead of
    forcing a cause label.
    """

    if not observed_components:
        raise ValueError("observed_components cannot be empty")
    if not math.isfinite(ambiguity_margin) or ambiguity_margin < 0.0:
        raise ValueError("ambiguity_margin must be finite and non-negative")
    observed = {str(key): float(value) for key, value in observed_components.items()}
    if any(not math.isfinite(value) for value in observed.values()):
        raise ValueError("observed components must be finite")
    candidates: list[dict[str, object]] = []
    for fingerprint in fingerprints:
        if fingerprint.get("preset_id") != preset_id:
            continue
        vector = _fingerprint_vector(fingerprint)
        common = sorted(set(observed).intersection(vector))
        if not common:
            continue
        differences = [
            min(abs(observed[key] - vector[key][0]), 6.0) for key in common
        ]
        candidates.append({
            "cause_id": fingerprint["cause_id"],
            "distance": float(math.sqrt(np.mean(np.square(differences)))),
            "component_count": len(common),
        })
    if not candidates:
        return {
            "preset_id": preset_id,
            "diagnosis": "insufficient_overlap",
            "ambiguous": True,
            "candidates": [],
        }
    candidates.sort(key=lambda item: (float(item["distance"]), str(item["cause_id"])))
    gap = (
        float(candidates[1]["distance"]) - float(candidates[0]["distance"])
        if len(candidates) > 1 else float("inf")
    )
    ambiguous = len(candidates) > 1 and gap < ambiguity_margin
    # Avoid non-finite JSON for the single-template case.
    finite_gap = gap if math.isfinite(gap) else 0.0
    return to_plain_data({
        "preset_id": preset_id,
        "diagnosis": "ambiguous" if ambiguous else candidates[0]["cause_id"],
        "ambiguous": ambiguous,
        "best_second_distance_gap": finite_gap,
        "candidates": candidates,
    })


def _calibration_jobs(
    config: MechanismDiscriminationConfig, process: ProcessWindowConfig
) -> list[_MechanismJob]:
    jobs: list[_MechanismJob] = []
    base = _reference_parameters()
    for cause_id in config.cause_ids:
        for preset_id in config.presets:
            for severity in config.calibration_candidates(cause_id):
                # Use the same common-random-number ensemble as the diagnostic
                # probes.  A single-seed calibration can otherwise select a
                # severity whose median probe burden is substantially shifted.
                for seed in config.replicate_seeds:
                    jobs.append(_MechanismJob(
                        order=len(jobs),
                        case_group="calibration",
                        cause_id=cause_id,
                        severity=severity,
                        geometry_id=config.reference_geometry_id,
                        preset_id=preset_id,
                        seed=seed,
                        parameters=base,
                        process_config=process,
                        wall_depth_bins=config.wall_depth_bins,
                        probe_value=severity,
                    ))
    return jobs


def _select_calibrations(
    cases: Sequence[Mapping[str, object]], config: MechanismDiscriminationConfig
) -> list[dict[str, object]]:
    selected: list[dict[str, object]] = []
    for cause_id in config.cause_ids:
        for preset_id in config.presets:
            subset = [
                case for case in cases
                if case.get("cause_id") == cause_id
                and case.get("preset_id") == preset_id
            ]
            successful = [case for case in subset if case.get("status") == "ok"]
            if not successful:
                selected.append({
                    "cause_id": cause_id,
                    "preset_id": preset_id,
                    "material": get_literature_preset(preset_id).material,
                    "status": "failed",
                    "selected_severity": 0.0,
                    "apparent_burden": 0.0,
                    "absolute_target_error": 1.0,
                    "target_reached": False,
                    "candidate_cases": [str(case.get("status")) for case in subset],
                })
                continue
            grouped: dict[float, list[Mapping[str, object]]] = {}
            for case in successful:
                grouped.setdefault(float(case["severity"]), []).append(case)
            candidate_summaries: list[dict[str, object]] = []
            for severity, candidate_group in sorted(grouped.items()):
                burdens = [
                    float(case["metrics"]["pre_second_apparent_burden"])
                    for case in candidate_group
                ]
                candidate_summaries.append({
                    "severity": severity,
                    "status": "ok",
                    "apparent_burden": float(np.median(burdens)),
                    "burden_range": [float(min(burdens)), float(max(burdens))],
                    "replicate_count": len(burdens),
                    "case_ids": [str(case.get("case_id", "")) for case in candidate_group],
                })
            chosen_summary = min(
                candidate_summaries,
                key=lambda item: (
                    abs(float(item["apparent_burden"])
                        - config.target_apparent_burden),
                    float(item["severity"]),
                ),
            )
            chosen_severity = float(chosen_summary["severity"])
            chosen_cases = grouped[chosen_severity]
            burden = float(chosen_summary["apparent_burden"])
            error = abs(burden - config.target_apparent_burden)
            selected.append({
                "cause_id": cause_id,
                "preset_id": preset_id,
                "material": chosen_cases[0]["material"],
                "status": "ok",
                "selected_severity": chosen_severity,
                "apparent_burden": burden,
                "burden_range": list(chosen_summary["burden_range"]),
                "replicate_count": int(chosen_summary["replicate_count"]),
                "absolute_target_error": error,
                "target_reached": error <= 0.10,
                "selected_case_id": chosen_cases[0]["case_id"],
                "selected_case_ids": list(chosen_summary["case_ids"]),
                "candidate_cases": candidate_summaries,
            })
    return selected


def _probe_jobs(
    calibrations: Sequence[Mapping[str, object]],
    config: MechanismDiscriminationConfig,
    process: ProcessWindowConfig,
) -> list[_MechanismJob]:
    jobs: list[_MechanismJob] = []
    baseline = _reference_parameters()
    calibration_by_key = {
        (str(item["cause_id"]), str(item["preset_id"])): item
        for item in calibrations if item.get("status") == "ok"
    }
    for cause_id in config.cause_ids:
        for preset_id in config.presets:
            calibration = calibration_by_key.get((cause_id, preset_id))
            if calibration is None:
                continue
            severity = float(calibration["selected_severity"])
            for probe in config.probes:
                for level_index, (level, probe_value) in enumerate(
                    zip(LEVEL_NAMES, probe.level_values)
                ):
                    parameters = dict(baseline)
                    geometry_id = config.reference_geometry_id
                    if probe.kind == "parameter":
                        assert probe.parameter_name is not None
                        parameters[probe.parameter_name] = float(probe_value)
                    else:
                        assert probe.geometry_ids is not None
                        geometry_id = probe.geometry_ids[level_index]
                    for seed in config.replicate_seeds:
                        jobs.append(_MechanismJob(
                            order=len(jobs),
                            case_group="probe",
                            cause_id=cause_id,
                            severity=severity,
                            geometry_id=geometry_id,
                            preset_id=preset_id,
                            seed=seed,
                            parameters=parameters,
                            process_config=process,
                            wall_depth_bins=config.wall_depth_bins,
                            probe_name=probe.name,
                            probe_level=level,
                            probe_value=probe_value,
                        ))
    return jobs


def run_mechanism_discrimination(
    config: MechanismDiscriminationConfig = MechanismDiscriminationConfig(),
) -> dict[str, object]:
    """Calibrate nine cause profiles, run paired probes and infer fingerprints."""

    if not isinstance(config, MechanismDiscriminationConfig):
        raise TypeError("config must be MechanismDiscriminationConfig")
    process = config.process_window_config()
    calibration_cases = _execute_jobs(
        _calibration_jobs(config, process), config.parallel_workers
    )
    calibrations = _select_calibrations(calibration_cases, config)
    probe_cases = _execute_jobs(
        _probe_jobs(calibrations, config, process), config.parallel_workers
    )
    fingerprints, scales = _aggregate_fingerprints(probe_cases, config)
    pairwise = _pairwise_distances(fingerprints, config)
    greedy = _greedy_probe_order(fingerprints, config)
    diagnosis = _diagnosis_table(
        fingerprints, pairwise, probe_cases, config
    )
    all_cases = calibration_cases + probe_cases
    failed = [case for case in all_cases if case.get("status") != "ok"]
    payload = {
        "schema_version": SCHEMA_VERSION,
        "model_name": (
            "burden-matched 2D continuum / graph-KMC fingerprints with fixed-"
            "carrier wall-affinity morphology"
        ),
        "notice": MODEL_NOTICE,
        "config": config.to_dict(),
        "cause_order": list(config.cause_ids),
        "cause_profiles": [CAUSE_PROFILES[cause].to_dict() for cause in config.cause_ids],
        "probe_definitions": [probe.to_dict() for probe in config.probes],
        "response_metrics": list(FINGERPRINT_METRICS),
        "response_scales": scales,
        "calibrations": calibrations,
        "calibration_cases": calibration_cases,
        "probe_cases": probe_cases,
        "fingerprints": fingerprints,
        "pairwise_robust_distances": pairwise,
        "greedy_probe_order": greedy,
        "diagnosis_table": diagnosis,
        "quality_summary": {
            "requested_calibration_cases": len(calibration_cases),
            "requested_probe_cases": len(probe_cases),
            "successful_case_count": len(all_cases) - len(failed),
            "failed_case_count": len(failed),
            "calibrations_within_0p10_burden": sum(
                bool(item.get("target_reached")) for item in calibrations
            ),
            "calibration_count": len(calibrations),
            "paired_common_random_seeds": list(config.replicate_seeds),
            "strict_finite_json": True,
        },
    }
    return to_plain_data(payload)  # type: ignore[return-value]


def save_mechanism_discrimination_json(
    payload: Mapping[str, object], path: str | Path
) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(strict_json_dumps(payload, indent=2), encoding="utf-8")
    return destination


__all__ = [
    "CAUSE_ORDER",
    "CAUSE_PROFILES",
    "DIAGNOSTIC_GEOMETRY_IDS",
    "FINGERPRINT_METRICS",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "CauseProfile",
    "MechanismDiscriminationConfig",
    "ProbeDefinition",
    "default_probe_definitions",
    "diagnose_fingerprint",
    "run_mechanism_discrimination",
    "save_mechanism_discrimination_json",
]

#!/usr/bin/env python3
"""Run the stage-separated HF-only trench-bottom residue screen."""

from __future__ import annotations

import argparse
import csv
import json
import os
from dataclasses import replace
from pathlib import Path
from typing import Mapping, Sequence

from hf_only_residue_screen import (
    HFOnlyResidueScreenConfig,
    KAWARAZAKI_DHF_PRESET_IDS,
    build_screen_payload,
    save_bottom_pad_csv,
    save_json,
    sha256_file,
    summarize_wetting_mesh_convergence,
)
from product_passivation_sweep import (
    PRODUCT_PASSIVATION_SCENARIOS,
    ProductPassivationSweepConfig,
    run_product_passivation_sweep,
)
from wetting_sweep import (
    SCENARIO_ORDER,
    WettingSweepConfig,
    run_wetting_sweep,
)


RESULT_NAME = "hf_only_residue_screen_results.json"
BOTTOM_PAD_CSV_NAME = "bottom_pad_burn_down.csv"
DECISION_CSV_NAME = "mechanism_decision_table.csv"
FIGURE_NAME = "hf_only_residue_summary.png"
README_NAME = "README_JA.md"
MANIFEST_NAME = "manifest_sha256.json"
WETTING_COMPONENT_NAME = "wetting_straight_2d.json"
PASSIVATION_COMPONENT_NAME = "product_passivation_2d.json"
WETTING_MESH_SUMMARY_NAME = "wetting_mesh_convergence.json"
WETTING_MESH_COMPONENT_NAMES = {
    1.0: "wetting_straight_1nm.json",
    0.5: "wetting_straight_0p5nm.json",
}
WETTING_MESH_SCENARIOS = (
    "baseline_inherited_liquid",
    "entrance_delayed",
    "bottom_gas_ideal_compression",
    "bottom_gas_fixed_volume_bound",
    "combined_adverse",
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run dHF-only blanket anchoring, sub-grid bottom-pad burn-down, "
            "straight-trench wetting/gas, product/passivation and rinse/dry "
            "capture screens. No ozone-enabled removal is used."
        )
    )
    parser.add_argument(
        "--mode",
        choices=("smoke", "quick"),
        default="quick",
        help=(
            "smoke=one geometry/film with coarse grids; quick=two standard "
            "geometries and all four Fig. 2 films"
        ),
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="independent case processes; 0 selects up to four",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/hf_only_residue_screen_20260728"),
    )
    parser.add_argument(
        "--no-figure",
        action="store_true",
        help="skip the six-panel PNG summary",
    )
    parser.add_argument(
        "--wetting-mesh-convergence",
        action="store_true",
        help=(
            "also run selected wetting/gas fingerprints at 1.0 and 0.5 nm; "
            "this is substantially slower than the default quick screen"
        ),
    )
    return parser


def _resolved_workers(requested: int, cases: int) -> int:
    if requested < 0:
        raise ValueError("workers must be zero or positive")
    if requested == 0:
        return max(1, min(4, os.cpu_count() or 1, cases))
    return max(1, min(requested, cases))


def _mode_inputs(
    mode: str,
) -> tuple[HFOnlyResidueScreenConfig, float, float, tuple[str, ...]]:
    if mode == "smoke":
        config = HFOnlyResidueScreenConfig(
            geometry_ids=("10_10_180",),
            preset_ids=(
                "kawarazaki_sicn_c22_dhf0p15_linear30s",
            ),
            bottom_pad_thicknesses_nm=(1.0, 2.0),
            bottom_local_rate_factors=(1.0, 0.1),
            hf_exposure_times_s=(30.0, 60.0, 120.0),
        )
        return config, 5.0, 5.0, ("null", "product_plus_passivation")
    if mode == "quick":
        return (
            HFOnlyResidueScreenConfig(),
            2.0,
            2.0,
            tuple(PRODUCT_PASSIVATION_SCENARIOS),
        )
    raise ValueError("mode must be smoke or quick")


def _component_metadata(path: Path, *, generated_this_run: bool) -> dict[str, object]:
    return {
        "path": path.name,
        "sha256": sha256_file(path),
        "size_bytes": path.stat().st_size,
        "generated_this_run": generated_this_run,
    }


def _write_decision_csv(
    payload: Mapping[str, object],
    path: Path,
) -> Path:
    rows = [
        {
            "mechanism": "bottom_pad_thickness_or_local_rate",
            "calibration_status": "blanket_clock_only",
            "hf_wet_endpoint_signature": "native bottom film remains",
            "decisive_probe": (
                "initial bottom thickness plus 30/60/120 s time series"
            ),
            "main_limit": (
                "single endpoint observes thickness/local-rate only as a ratio"
            ),
        },
        {
            "mechanism": "pinning_or_persistent_gas",
            "calibration_status": "uncalibrated_failure_mode",
            "hf_wet_endpoint_signature": (
                "native residue co-located with dry/gas region"
            ),
            "decisive_probe": "forced pre-wet, degas and pressure assist",
            "main_limit": "2 nm gas mask is a coarse screening grid",
        },
        {
            "mechanism": "product_inhibition_or_passivation",
            "calibration_status": "uncalibrated_dimensionless_hypothesis",
            "hf_wet_endpoint_signature": (
                "native residue with product/passivation field, no dry required"
            ),
            "decisive_probe": "fixed HF time plus second-WET/temperature response",
            "main_limit": "aqueous product identity and kinetic constants unknown",
        },
        {
            "mechanism": "rinse_dry_redeposition",
            "calibration_status": "uncalibrated_post_HF_closure",
            "hf_wet_endpoint_signature": "absent while wet; deposit appears after dry",
            "decisive_probe": "no-dry and immediate-quench controls",
            "main_limit": "well-mixed rinse and first-order drying approximation",
        },
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=tuple(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return path


def _material_label(preset_id: str) -> str:
    labels = {
        "kawarazaki_sicn_c22_dhf0p15_linear30s": "SiCN C22",
        "kawarazaki_sicn_c40_dhf0p15_linear30s": "SiCN C40",
        "kawarazaki_siocn_c5_dhf0p15_linear30s": "SiOCN C5",
        "kawarazaki_sin_reference_dhf0p15_linear30s": "SiN",
    }
    return labels.get(preset_id, preset_id)


def _bottom_clear_rows(payload: Mapping[str, object]) -> list[str]:
    cases = payload["bottom_pad_burn_down"]["cases"]
    lines = []
    for preset_id in payload["config"]["preset_ids"]:
        values = []
        for factor in (1.0, 0.3, 0.1):
            match = next(
                (
                    case
                    for case in cases
                    if case["geometry_id"]
                    == payload["config"]["geometry_ids"][0]
                    and case["preset_id"] == preset_id
                    and float(case["initial_bottom_pad_thickness_nm"]) == 1.0
                    and float(case["bottom_local_rate_factor"]) == factor
                ),
                None,
            )
            values.append(
                "n/a"
                if match is None
                else f"{float(match['central_clear_time_min']):.2f}"
            )
        lines.append(
            f"| {_material_label(preset_id)} | {values[0]} | "
            f"{values[1]} | {values[2]} |"
        )
    return lines


def _bottom_remaining_rows(
    payload: Mapping[str, object],
    *,
    exposure_time_s: float,
) -> list[str]:
    cases = payload["bottom_pad_burn_down"]["cases"]
    lines = []
    for preset_id in payload["config"]["preset_ids"]:
        case = next(
            (
                item
                for item in cases
                if item["geometry_id"]
                == payload["config"]["geometry_ids"][0]
                and item["preset_id"] == preset_id
                and float(item["initial_bottom_pad_thickness_nm"]) == 1.0
                and float(item["bottom_local_rate_factor"]) == 1.0
            ),
            None,
        )
        point = (
            None
            if case is None
            else next(
                (
                    item
                    for item in case["time_points"]
                    if abs(
                        float(item["exposure_time_s"]) - exposure_time_s
                    )
                    < 1.0e-12
                ),
                None,
            )
        )
        if point is None:
            continue
        lines.append(
            f"| {_material_label(preset_id)} | "
            f"{float(point['etched_thickness_nm']):.3f} | "
            f"{float(point['remaining_thickness_nm']):.3f} |"
        )
    return lines


def _wetting_rows(payload: Mapping[str, object]) -> list[str]:
    rows = payload["wetting_and_gas"]["summary"]
    lines = []
    for scenario in dict.fromkeys(row["scenario"] for row in rows):
        subset = [row for row in rows if row["scenario"] == scenario]
        values = {
            row["geometry_id"]: 100.0
            * float(row["bottom_15pct_remaining_fraction"])
            for row in subset
        }
        lines.append(
            f"| {scenario} | {values.get('10_10_180', float('nan')):.1f} | "
            f"{values.get('7_7_170', float('nan')):.1f} |"
        )
    return lines


def _wetting_mesh_rows(payload: Mapping[str, object]) -> list[str]:
    convergence = payload["wetting_and_gas"].get("mesh_convergence", {})
    cases = convergence.get("cases", [])
    finest = convergence.get("finest_grid_spacing_nm")
    if finest is None:
        return []
    rows = []
    for scenario in WETTING_MESH_SCENARIOS:
        values: list[float] = []
        for geometry_id in ("10_10_180", "7_7_170"):
            case = next(
                (
                    item
                    for item in cases
                    if item["scenario"] == scenario
                    and item["geometry_id"] == geometry_id
                ),
                None,
            )
            point = (
                None
                if case is None
                else next(
                    (
                        entry
                        for entry in case["ladder"]
                        if abs(
                            float(entry["grid_spacing_nm"])
                            - float(finest)
                        )
                        < 1.0e-12
                    ),
                    None,
                )
            )
            if point is None:
                values.extend((float("nan"), float("nan")))
            else:
                values.extend(
                    (
                        100.0 * float(point["remaining_mass_fraction"]),
                        100.0
                        * float(
                            point["bottom_15pct_remaining_fraction"]
                        ),
                    )
                )
        rows.append(
            f"| {scenario} | {values[0]:.3f} | {values[1]:.3f} | "
            f"{values[2]:.3f} | {values[3]:.3f} |"
        )
    return rows


def _passivation_rows(payload: Mapping[str, object]) -> list[str]:
    by_time = payload["product_and_passivation"][
        "summary_at_absolute_time_s"
    ]
    rows = by_time.get("120", [])
    lines = []
    for preset_id in payload["config"]["preset_ids"]:
        null_removed = [
            1.0 - float(row["remaining_mass_fraction"])
            for row in rows
            if row["preset_id"] == preset_id and row["scenario"] == "null"
        ]
        denominator = (
            sum(null_removed) / len(null_removed) if null_removed else 0.0
        )
        ratios = []
        for scenario in (
            "product_inhibition",
            "reversible_passivation",
            "product_plus_passivation",
        ):
            removed = [
                1.0 - float(row["remaining_mass_fraction"])
                for row in rows
                if row["preset_id"] == preset_id
                and row["scenario"] == scenario
            ]
            ratio = (
                100.0 * (sum(removed) / len(removed)) / denominator
                if removed and denominator > 0.0
                else None
            )
            ratios.append("n/a" if ratio is None else f"{ratio:.1f}")
        lines.append(
            f"| {_material_label(preset_id)} | {ratios[0]} | "
            f"{ratios[1]} | {ratios[2]} |"
        )
    return lines


def _selected_drydown_metrics(
    payload: Mapping[str, object],
) -> dict[str, float]:
    conditions = payload["rinse_and_dry_redeposition"]["post_hf_conditions"]

    def find(
        *,
        dry: bool,
        quench: bool,
        rinse: float,
    ) -> float:
        for item in conditions:
            if (
                bool(item["dry_enabled"]) is dry
                and bool(item["immediate_quench"]) is quench
                and abs(float(item["rinse_exchange_rate_s"]) - rinse) < 1e-12
                and abs(float(item["drying_rate_s"]) - 1.0 / 30.0) < 1e-12
            ):
                return float(
                    item["effective_capture_fraction_of_generated"]
                )
        raise RuntimeError("requested dry-down reference condition is missing")

    reference = find(dry=True, quench=False, rinse=0.05)
    immediate = find(dry=True, quench=True, rinse=0.05)
    high_flow = find(dry=True, quench=False, rinse=0.20)
    no_dry = find(dry=False, quench=False, rinse=0.05)
    return {
        "reference": reference,
        "immediate": immediate,
        "high_flow": high_flow,
        "no_dry": no_dry,
        "immediate_reduction": (
            1.0 - immediate / reference if reference else 0.0
        ),
        "high_flow_reduction": (
            1.0 - high_flow / reference if reference else 0.0
        ),
    }


def write_readme(
    payload: Mapping[str, object],
    path: Path,
    *,
    mode: str,
) -> Path:
    anchors = payload["blanket_anchors"]
    wetting_rows = payload["wetting_and_gas"]["summary"]
    wetting_mesh = payload["wetting_and_gas"].get(
        "mesh_convergence", {}
    )
    passivation_rows = payload["product_and_passivation"][
        "summary_at_absolute_time_s"
    ].get("120", [])
    dry = _selected_drydown_metrics(payload)
    maximum_partition = max(
        (
            abs(float(row["phase_partition_relative_error"]))
            for row in wetting_rows
        ),
        default=0.0,
    )
    maximum_product_balance = max(
        (
            abs(
                float(
                    row[
                        "maximum_product_inventory_balance_relative_error"
                    ]
                )
            )
            for row in passivation_rows
            if row[
                "maximum_product_inventory_balance_relative_error"
            ]
            is not None
        ),
        default=0.0,
    )
    converged_count = sum(
        bool(row["all_numerics_converged"]) for row in passivation_rows
    )
    lines = [
        "# HF-only Trench bottom残渣 機構screen",
        "",
        f"実行モード: `{mode}`",
        "",
        "O₃由来の除去量を完全に外し、Fig. 2右側のdHF-only値だけを"
        "化学clockとして用いたscreeningです。",
        "",
        "## 結論",
        "",
        "- 液がbottomまで連通するnullでは、blanket速度で薄膜量が線形に減ります。",
        "- bottom膜厚と局所速度倍率は、単一endpointでは"
        "`thickness / rate_factor`として完全に縮退します。",
        "- straight形状の2D screenでbottom残渣を作ったのは、"
        "入口pinningまたは維持されるgasを明示的に課した枝だけです。",
        "- 生成物阻害/passivationはfixed 30/60/120 sで元膜除去を遅くできますが、"
        "係数は未校正です。",
        "- no-dryで析出量は厳密に0です。dry後だけ増える残渣は、"
        "一次HF元膜と分けて扱えます。",
        "",
        "## dHF-only blanket anchor",
        "",
        "| film | 30 s除去量 [nm] | 中央WER [nm/min] | 1-raster感度 [nm/min] |",
        "|---|---:|---:|---:|",
        *[
            (
                f"| {_material_label(str(row['preset_id']))} | "
                f"{float(row['source_etch_amount_nm']):.3f} | "
                f"{float(row['central_rate_nm_min']):.3f} | "
                f"{float(row['one_raster_rate_sensitivity_nm_min']['lower']):.3f}"
                "–"
                f"{float(row['one_raster_rate_sensitivity_nm_min']['upper']):.3f} |"
            )
            for row in anchors
        ],
        "",
        "感度幅は統計誤差ではありません。0.05 nmのraster読取りを上下へ"
        "1段動かしただけです。",
        "",
        "## 1 nm bottom padの中央clear時間",
        "",
        "| film | local rate ×1 [min] | ×0.3 [min] | ×0.1 [min] |",
        "|---|---:|---:|---:|",
        *_bottom_clear_rows(payload),
        "",
        "0.5/1/2/5 nmの全caseと30–3600 sの残膜厚は"
        f"`{BOTTOM_PAD_CSV_NAME}`へ保存しました。",
        "",
        "実processが30 sなら、完全濡れ・local rate ×1でも1 nm padは"
        "次の量だけ残ります。",
        "",
        "| film | 30 s除去 [nm] | 1 nmからの残膜 [nm] |",
        "|---|---:|---:|",
        *_bottom_remaining_rows(payload, exposure_time_s=30.0),
        "",
        "したがって初期bottom膜がnm級なら、追加の輸送阻害を入れなくても"
        "30 s残渣を説明できます。",
        "",
        "## pinning / persistent gas",
        "",
        "次はHF速度で校正した値ではなく、明示的failure-modeの2 nm格子screenです。",
        "",
        "| scenario | 10×180 bottom 15%残存 [%] | 7×170 [%] |",
        "|---|---:|---:|",
        *_wetting_rows(payload),
        "",
        "通常のhydrophilic capillaryとideal-gas圧縮だけではclearします。"
        "persistent gas枝は固定体積/残留gasを課した上限仮説です。",
        "",
        *(
            [
                "### 2.0 → 1.0 → 0.5 nm格子確認",
                "",
                (
                    "下表は最細0.5 nm格子の値です。判定は3格子すべてで"
                    f"`{str(wetting_mesh.get('qualitative_fingerprint_preserved')).lower()}`"
                    "でした。"
                ),
                "",
                (
                    "| scenario | 10×180 total [%] | 10×180 bottom [%] | "
                    "7×170 total [%] | 7×170 bottom [%] |"
                ),
                "|---|---:|---:|---:|---:|",
                *_wetting_mesh_rows(payload),
                "",
                "ideal-gas枝の0.5 nm格子残渣はtotal 0.11%未満で、"
                "pinning/persistent-gas枝のbottom 100%とは分離しています。",
                "",
            ]
            if wetting_mesh
            else []
        ),
        "## 生成物阻害 / passivation",
        "",
        "120 s時点の除去量をnull=100%として比較します。",
        "",
        "| film | product inhibition [%] | reversible passivation [%] | combined [%] |",
        "|---|---:|---:|---:|",
        *_passivation_rows(payload),
        "",
        "product濃度はdissolved-Si equivalentであり、実際の析出種を同定した値では"
        "ありません。absolute 30/60/120 s checkpointとplanar-clear規格化値を"
        f"`{PASSIVATION_COMPONENT_NAME}`に分けて保存しています。",
        "120 sでは全full-fill caseで反応frontがbottomへ未到達のため、"
        "ここで見える最大約10%の差は全体/初期除去の遅延であり、"
        "bottom局在passivationの証拠ではありません。",
        "",
        "## rinse / dry再析出",
        "",
        f"- 基準条件のcapture: 生成poolの {100.0 * dry['reference']:.3f}%",
        f"- immediate quenchによる低下: {100.0 * dry['immediate_reduction']:.2f}%",
        f"- rinse交換0.20 s^-1による低下: {100.0 * dry['high_flow_reduction']:.2f}%",
        f"- no-dry capture: {100.0 * dry['no_dry']:.3f}%",
        "",
        "総captureを先に決め、その後にwall/bottom affinityで配分しています。"
        "したがってaffinityは総析出量を変えません。",
        "",
        "## 数値確認",
        "",
        f"- product/passivation absolute 120 s: {converged_count}/"
        f"{len(passivation_rows)} caseでreactant/product/nonlinear収束",
        f"- 最大product inventory balance相対誤差: {maximum_product_balance:.3e}",
        f"- 最大wetting phase-partition相対誤差: {maximum_partition:.3e}",
        "- bottom-pad burn-downは解析的な厚さ収支で、clear後の負値だけを"
        "0へ制限しています。",
        "",
        "## 原因を絞る実験順",
        "",
        "1. HF直後をwet保持して元膜組成・bottom厚さを測る。",
        "2. 同一構造で30/60/120 sの時間系列を取る。",
        "3. forced pre-wet / degas / pressure assistを対照化する。",
        "4. no-dry、immediate quench、通常rinse/dryを比較する。",
        "5. 元膜とF-rich/salt-like depositを別々に定量する。",
        "",
        "## 解釈境界",
        "",
        "- blanket値は同一lot実測ではなく文献priorです。",
        "- C22とSiNの30 s値はraster分解能より小さく、最遅clear時間は有限に"
        "拘束できません。",
        "- wetting/gasの0.5–2 nm確認は定性的fingerprint用です。gas面積や"
        "実process量の定量判断には0.25 nm確認と物性校正が必要です。",
        "- passivation、gas寿命、pinning、dry captureの係数をprocess recipe値として"
        "使えません。",
        "- 5機構のstate変数は合算せず、stage-resolved fingerprintとして比較しています。",
        "",
        "## 成果物",
        "",
        f"- `{RESULT_NAME}`: 統合summaryと薄膜全case",
        f"- `{BOTTOM_PAD_CSV_NAME}`: 固定HF時間ごとのbottom pad残膜",
        f"- `{WETTING_COMPONENT_NAME}`: straight 2D wetting/gas全field",
        *(
            [
                f"- `{WETTING_MESH_SUMMARY_NAME}`: 0.5–2 nm格子比較",
                f"- `{WETTING_MESH_COMPONENT_NAMES[1.0]}`: 1 nm raw field",
                f"- `{WETTING_MESH_COMPONENT_NAMES[0.5]}`: 0.5 nm raw field",
            ]
            if wetting_mesh
            else []
        ),
        f"- `{PASSIVATION_COMPONENT_NAME}`: 2D product/passivation全checkpoint",
        f"- `{DECISION_CSV_NAME}`: 実験判定表",
        f"- `{FIGURE_NAME}`: 六面summary",
        f"- `{MANIFEST_NAME}`: SHA-256 manifest",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _write_manifest(output_dir: Path, names: Sequence[str]) -> Path:
    payload = {
        "algorithm": "sha256",
        "files": {
            name: {
                "sha256": sha256_file(output_dir / name),
                "size_bytes": (output_dir / name).stat().st_size,
            }
            for name in names
            if (output_dir / name).is_file()
        },
    }
    return save_json(payload, output_dir / MANIFEST_NAME)


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config, wetting_grid_nm, passivation_grid_nm, passivation_scenarios = (
        _mode_inputs(args.mode)
    )
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    wetting_case_count = len(config.geometry_ids) * len(SCENARIO_ORDER)
    wetting_workers = _resolved_workers(args.workers, wetting_case_count)
    wetting_payload = run_wetting_sweep(
        WettingSweepConfig(
            geometries=config.geometry_ids,
            scenarios=SCENARIO_ORDER,
            material="SiCN",
            grid_spacing_nm=wetting_grid_nm,
            probe_grid_spacing_nm=0.5 if args.mode == "quick" else 1.0,
            reservoir_height_nm=4.0,
            maximum_etch_velocity_nm_s=4.0,
            maximum_time_over_planar_clear=1.40,
            parallel_workers=wetting_workers,
        )
    )
    wetting_path = save_json(
        wetting_payload, output_dir / WETTING_COMPONENT_NAME
    )
    wetting_mesh_summary: dict[str, object] = {}
    wetting_mesh_paths: list[Path] = []
    if args.wetting_mesh_convergence:
        mesh_payloads: dict[str, Mapping[str, object]] = {
            f"{wetting_grid_nm:g}nm": wetting_payload,
        }
        mesh_case_count = (
            len(config.geometry_ids) * len(WETTING_MESH_SCENARIOS)
        )
        mesh_workers = _resolved_workers(args.workers, mesh_case_count)
        for grid_spacing_nm, component_name in (
            WETTING_MESH_COMPONENT_NAMES.items()
        ):
            mesh_payload = run_wetting_sweep(
                WettingSweepConfig(
                    geometries=config.geometry_ids,
                    scenarios=WETTING_MESH_SCENARIOS,
                    material="SiCN",
                    grid_spacing_nm=grid_spacing_nm,
                    probe_grid_spacing_nm=0.5,
                    reservoir_height_nm=4.0,
                    maximum_etch_velocity_nm_s=4.0,
                    maximum_time_over_planar_clear=1.40,
                    parallel_workers=mesh_workers,
                )
            )
            mesh_path = save_json(
                mesh_payload, output_dir / component_name
            )
            wetting_mesh_paths.append(mesh_path)
            mesh_payloads[f"{grid_spacing_nm:g}nm"] = mesh_payload
        wetting_mesh_summary = summarize_wetting_mesh_convergence(
            mesh_payloads
        )
        wetting_mesh_paths.append(
            save_json(
                wetting_mesh_summary,
                output_dir / WETTING_MESH_SUMMARY_NAME,
            )
        )

    passivation_case_count = (
        len(config.geometry_ids)
        * len(config.preset_ids)
        * len(passivation_scenarios)
    )
    passivation_workers = _resolved_workers(
        args.workers, passivation_case_count
    )
    passivation_payload = run_product_passivation_sweep(
        ProductPassivationSweepConfig(
            geometries=config.geometry_ids,
            presets=config.preset_ids,
            scenarios=passivation_scenarios,
            target_remaining_fractions=(0.50,),
            sample_time_over_planar_clear=(0.01,),
            sample_times_s=(30.0, 60.0, 120.0),
            grid_spacing_nm=passivation_grid_nm,
            reservoir_height_nm=4.0,
            parallel_workers=passivation_workers,
        )
    )
    passivation_path = save_json(
        passivation_payload, output_dir / PASSIVATION_COMPONENT_NAME
    )

    component_artifacts = {
        "wetting_straight_2d": _component_metadata(
            wetting_path, generated_this_run=True
        ),
        "product_passivation_2d": _component_metadata(
            passivation_path, generated_this_run=True
        ),
    }
    for mesh_path in wetting_mesh_paths:
        component_artifacts[mesh_path.stem] = _component_metadata(
            mesh_path, generated_this_run=True
        )
    existing_primary = Path(
        "results/kawarazaki_fig2_screen_20260728/"
        "primary_hf_kmc_quick/primary_hf_endpoint_results.json"
    )
    if existing_primary.is_file():
        component_artifacts["existing_full_gapfill_primary_hf_kmc"] = {
            "path": str(existing_primary),
            "sha256": sha256_file(existing_primary),
            "size_bytes": existing_primary.stat().st_size,
            "generated_this_run": False,
            "use": (
                "full-GAP-FILL transport/passivation cross-check only; not "
                "used as a 0.5--5 nm bottom-pad prediction"
            ),
        }
    payload = build_screen_payload(
        config,
        wetting_payload=wetting_payload,
        wetting_mesh_convergence_payload=wetting_mesh_summary,
        product_passivation_payload=passivation_payload,
        component_artifacts=component_artifacts,
    )
    result_path = save_json(payload, output_dir / RESULT_NAME)
    save_bottom_pad_csv(
        payload["bottom_pad_burn_down"],
        output_dir / BOTTOM_PAD_CSV_NAME,
    )
    _write_decision_csv(payload, output_dir / DECISION_CSV_NAME)
    write_readme(payload, output_dir / README_NAME, mode=args.mode)

    generated_names = [
        RESULT_NAME,
        BOTTOM_PAD_CSV_NAME,
        DECISION_CSV_NAME,
        WETTING_COMPONENT_NAME,
        PASSIVATION_COMPONENT_NAME,
        README_NAME,
    ]
    generated_names.extend(path.name for path in wetting_mesh_paths)
    if not args.no_figure:
        from hf_only_residue_screen_visualization import (
            plot_hf_only_residue_screen,
        )

        plot_hf_only_residue_screen(payload, output_dir / FIGURE_NAME)
        generated_names.append(FIGURE_NAME)
    manifest_path = _write_manifest(output_dir, generated_names)

    payload["artifacts"] = {
        name: {
            "path": str(output_dir / name),
            "sha256": sha256_file(output_dir / name),
        }
        for name in generated_names
        if (output_dir / name).is_file()
    }
    payload["artifacts"][MANIFEST_NAME] = {
        "path": str(manifest_path),
        "sha256": sha256_file(manifest_path),
    }
    # Do not rewrite RESULT_NAME after computing the manifest: the returned
    # object contains convenience paths, while the persisted result remains
    # the hash-stable scientific payload recorded by the manifest.
    return payload


if __name__ == "__main__":
    main()

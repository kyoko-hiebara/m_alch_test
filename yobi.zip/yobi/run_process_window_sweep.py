#!/usr/bin/env python3
"""Run the multicore 13-parameter process-window screening study."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Sequence

# Set numerical-library limits before importing NumPy/SciPy through the model.
for _thread_variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ[_thread_variable] = "1"

from process_window_sweep import CLASS_LABELS_JA, ProcessWindowConfig, run_process_window_sweep


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run a scrambled-Sobol global sensitivity study followed by "
            "targeted real-computation phase maps for the two straight trenches."
        )
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/process_window"),
    )
    parser.add_argument(
        "--mode",
        choices=("smoke", "quick", "full"),
        default="quick",
        help="smoke=16 Sobol points; quick=128; full=512 x three KMC seeds",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="processes; 0 selects up to eight physical jobs automatically",
    )
    parser.add_argument(
        "--global-only",
        action="store_true",
        help="skip targeted pair maps but retain global sensitivity and representatives",
    )
    parser.add_argument(
        "--no-representatives",
        action="store_true",
        help="skip the representative graph reruns",
    )
    parser.add_argument(
        "--grid-spacing-nm",
        type=float,
        default=None,
        help="override the mode mesh; see results/mesh_seed_convergence",
    )
    parser.add_argument(
        "--replicate-seeds",
        type=int,
        nargs="+",
        default=None,
        help=(
            "KMC seeds; more seeds turn a 0/1 phase classification into a "
            "probability"
        ),
    )
    parser.add_argument(
        "--maximum-sites",
        type=int,
        default=None,
        help="graph site budget; must grow with a finer mesh",
    )
    parser.add_argument(
        "--design-points",
        type=int,
        default=None,
        help="override the Sobol design size (power of two)",
    )
    parser.add_argument(
        "--phase-pairs",
        type=int,
        default=None,
        help="override the number of targeted phase-map pairs",
    )
    return parser


def _config(args: argparse.Namespace) -> ProcessWindowConfig:
    if args.workers < 0:
        raise ValueError("workers must be zero or positive")
    mode_values: dict[str, dict[str, object]] = {
        "smoke": {
            "design_points": 16,
            "parameter_bounds_set": "quick",
            "grid_spacing_nm": 2.0,
            "phase_levels": 3,
            "maximum_phase_pairs": 2,
            "bootstrap_samples": 20,
            "primary_sync_steps": 12,
        },
        "quick": {
            "design_points": 128,
            "parameter_bounds_set": "full",
            "grid_spacing_nm": 1.4,
            "phase_levels": 7,
            "maximum_phase_pairs": 5,
            "bootstrap_samples": 200,
            "primary_sync_steps": 30,
        },
        "full": {
            "design_points": 512,
            "parameter_bounds_set": "full",
            "grid_spacing_nm": 1.4,
            "phase_levels": 9,
            "maximum_phase_pairs": 4,
            "bootstrap_samples": 1000,
            "primary_sync_steps": 30,
            "replicate_seeds": (271828, 314159, 161803),
        },
    }
    values = dict(mode_values[args.mode])
    if args.grid_spacing_nm is not None:
        values["grid_spacing_nm"] = float(args.grid_spacing_nm)
    if args.replicate_seeds is not None:
        values["replicate_seeds"] = tuple(args.replicate_seeds)
    if args.maximum_sites is not None:
        values["maximum_sites"] = int(args.maximum_sites)
    if args.phase_pairs is not None:
        values["maximum_phase_pairs"] = int(args.phase_pairs)
    if args.design_points is not None:
        values["design_points"] = int(args.design_points)
    global_cases = (
        int(values["design_points"])
        * 2
        * 2
        * len(values.get("replicate_seeds", (271828,)))
    )
    workers = (
        min(8, os.cpu_count() or 1, global_cases)
        if args.workers == 0
        else min(args.workers, global_cases)
    )
    return ProcessWindowConfig(
        **values,
        parallel_workers=workers,
        include_phase_maps=not args.global_only,
        include_representatives=not args.no_representatives,
    )


def _readme(payload: dict[str, object], mode: str) -> str:
    counts = payload["classification_counts"]
    assert isinstance(counts, dict)
    lines = [
        "# GAP-FILL WET process-window screening",
        "",
        f"実行モード: `{mode}`",
        "",
        "この結果は実験recipeではなく、未校正パラメータを含む機構screeningです。",
        "13変数をscrambled Sobolで広く振り、PRCC上位の変数対だけを追加の実計算phase mapにしています。",
        "zero-capture controlは分類には含めますが、PRCCからは除外しています。",
        "Graph KMCの絶対clockは未校正で、SiN/SiOCN間の相対prefactorだけを文献blanket WER比で補正しています。",
        "析出軸のphase mapは、元膜残渣に隠れないよう他の一次HF条件をmatrix-clearing側へ固定しています。",
        "",
        "## 四分類",
        "",
    ]
    for key, label in CLASS_LABELS_JA.items():
        lines.append(f"- `{key}`: {label}")
    lines.extend(("", "## Global Sobol集計", ""))
    for item in counts.values():
        assert isinstance(item, dict)
        count_text = ", ".join(
            f"{CLASS_LABELS_JA[key]}={value}"
            for key, value in item["counts"].items()
        )
        lines.append(
            f"- {item['geometry_id']} / {item['material']} ({item['preset_id']}): {count_text}"
        )
    lines.extend(
        (
            "",
            "## 出力",
            "",
            "- `process_window_results.json`: 全条件、分類、PRCC、phase map、代表graph",
            "- `sensitivity_prcc.png`: 連続残渣量に対するPRCC",
            "- `dominant_phase_maps.png`: 四分類の支配相",
            "- `class_probability_maps.png`: 各classの確率",
            "- `representative_residue_graphs.png`: 実寸trench上の代表残渣",
            "",
            "温度は液温と基板温度を独立境界条件として扱います。HF speciationと拡散係数は298 K値のままです。",
            "rinse待ち時間は `capture_inf*(1-exp(-wait/30 s))` の固定終端近似です。",
            "quick modeはKMC seedが1本なので、phase-map確率は0/1です。境界の確率幅を見る場合はfull mode（3 seeds）を使います。",
            "",
        )
    )
    return "\n".join(lines)


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    args = build_parser().parse_args(argv)
    config = _config(args)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    print(
        f"process-window {args.mode}: {config.design_points} Sobol points, "
        f"{config.parallel_workers} workers",
        flush=True,
    )
    payload = run_process_window_sweep(config)
    result_path = output_dir / "process_window_results.json"
    # Persist the expensive numerical result before rendering so a plotting
    # failure cannot discard a completed multicore sweep.
    result_path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )

    from process_window_visualization import plot_process_window_outputs

    artifacts = plot_process_window_outputs(payload, output_dir)
    payload["artifacts"] = {
        "results_json": result_path.name,
        "readme": "README_JA.md",
        **{key: Path(value).name for key, value in artifacts.items()},
    }
    result_path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (output_dir / "README_JA.md").write_text(
        _readme(payload, args.mode), encoding="utf-8"
    )
    quality = payload["quality_summary"]
    print(
        f"done: global={quality['successful_global_case_count']}, "
        f"phase={quality['successful_phase_case_count']}, "
        f"failed={quality['failed_case_count']}",
        flush=True,
    )
    return payload


if __name__ == "__main__":
    main()

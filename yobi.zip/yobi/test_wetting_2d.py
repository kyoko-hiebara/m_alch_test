from __future__ import annotations

import math
import unittest

import numpy as np

from reaction_diffusion_2d import CartesianGrid2D
from trench_geometry import TaperedTrench2D
from wetting_2d import (
    WettingParameters,
    WettingState2D,
    slit_capillary_pressure_Pa,
    slit_lucas_washburn_time_s,
)


class Wetting2DTests(unittest.TestCase):
    def setUp(self) -> None:
        self.geometry = TaperedTrench2D("toy", 8.0, 6.0, 20.0)
        self.grid = CartesianGrid2D.from_geometry(
            self.geometry,
            spacing_nm=1.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
        )
        self.fully_open = self.grid.reservoir_mask | self.grid.cavity_mask

    def assert_partition(self, state: WettingState2D) -> None:
        open_cavity = self.fully_open & self.grid.cavity_mask
        np.testing.assert_array_equal(
            state.liquid_mask & self.grid.cavity_mask | state.gas_mask,
            open_cavity,
        )
        self.assertFalse(np.any(state.liquid_mask & state.gas_mask))
        self.assertFalse(np.any(state.liquid_mask & ~self.fully_open))
        self.assertFalse(np.any(state.gas_mask & ~self.fully_open))
        self.assertLess(
            state.diagnostics.phase_partition_relative_error, 1.0e-12
        )

    def test_slit_pressure_and_washburn_limit_have_expected_signs(self) -> None:
        wetting_pressure = slit_capillary_pressure_Pa(8.0, 60.0, 0.07197)
        nonwetting_pressure = slit_capillary_pressure_Pa(
            8.0, 120.0, 0.07197
        )
        self.assertGreater(wetting_pressure, 0.0)
        self.assertLess(nonwetting_pressure, 0.0)
        self.assertGreater(
            slit_lucas_washburn_time_s(
                180.0, 8.0, 60.0, 0.07197, 0.89e-3
            ),
            0.0,
        )
        self.assertTrue(
            math.isinf(
                slit_lucas_washburn_time_s(
                    180.0, 8.0, 120.0, 0.07197, 0.89e-3
                )
            )
        )

    def test_entrance_delay_holds_then_releases_the_meniscus(self) -> None:
        state = WettingState2D(
            self.grid,
            WettingParameters(
                enabled=True,
                new_void_filling_mode="capillary",
                entrance_delay_s=1.0,
                maximum_contact_line_speed_nm_s=2.0,
            ),
        )
        self.assertFalse(state.diagnostics.wetting_delay_active)
        state.update(self.fully_open, 0.5)
        self.assertEqual(state.contact_line_depth_nm, 0.0)
        self.assertTrue(state.diagnostics.wetting_delay_active)
        state.update(self.fully_open, 0.6)
        self.assertAlmostEqual(state.contact_line_depth_nm, 0.2)
        self.assertFalse(state.diagnostics.wetting_delay_active)
        self.assert_partition(state)

    def test_stable_step_limits_delay_event_and_contact_line_motion(self) -> None:
        state = WettingState2D(
            self.grid,
            WettingParameters(
                enabled=True,
                new_void_filling_mode="capillary",
                entrance_delay_s=0.5,
            ),
        )
        state.update(self.fully_open, 0.0)
        self.assertAlmostEqual(
            state.stable_time_step_s(
                self.fully_open,
                maximum_contact_line_displacement_nm=0.2,
                maximum_fractional_gas_change=0.5,
            ),
            0.5,
        )
        state.update(self.fully_open, 0.5)
        speed, _, _ = state.hydraulic_contact_line_state(
            state.contact_line_depth_nm
        )
        self.assertAlmostEqual(
            state.stable_time_step_s(
                self.fully_open,
                maximum_contact_line_displacement_nm=0.2,
                maximum_fractional_gas_change=0.5,
            ),
            0.2 / speed,
        )

    def test_isolated_open_void_is_rejected_instead_of_dropped(self) -> None:
        isolated = self.grid.reservoir_mask.copy()
        row, column = np.argwhere(self.grid.cavity_mask)[-1]
        isolated[row, column] = True
        state = WettingState2D(
            self.grid, WettingParameters(enabled=True)
        )
        with self.assertRaisesRegex(ValueError, "top-connected"):
            state.update(isolated, 0.0)

    def test_nonwetting_angle_does_not_invade_without_overpressure(self) -> None:
        state = WettingState2D(
            self.grid,
            WettingParameters(
                enabled=True,
                new_void_filling_mode="capillary",
                advancing_contact_angle_deg=120.0,
            ),
        )
        state.update(self.fully_open, 10.0)
        self.assertEqual(state.contact_line_depth_nm, 0.0)
        self.assertFalse(np.any(state.liquid_mask & self.grid.cavity_mask))
        self.assert_partition(state)

    def test_explicit_bottom_pocket_blocks_a_partitioned_open_region(self) -> None:
        state = WettingState2D(
            self.grid,
            WettingParameters(
                enabled=True,
                bottom_gas_pocket_seed_height_nm=4.0,
                bottom_gas_activation_depth_fraction=0.0,
                gas_compression_mode="none",
            ),
        )
        state.update(self.fully_open, 0.0)
        self.assertTrue(state.diagnostics.bottom_gas_pocket_active)
        self.assertGreater(state.diagnostics.gas_area_nm2, 0.0)
        self.assertGreater(np.count_nonzero(state.bottom_gas_mask), 0)
        self.assertFalse(np.any(state.bottom_gas_mask & state.liquid_mask))
        self.assert_partition(state)

    def test_finite_gas_dissolution_time_reduces_target_inventory(self) -> None:
        state = WettingState2D(
            self.grid,
            WettingParameters(
                enabled=True,
                bottom_gas_pocket_seed_height_nm=6.0,
                bottom_gas_activation_depth_fraction=0.0,
                gas_compression_mode="none",
                gas_dissolution_time_s=2.0,
            ),
        )
        state.update(self.fully_open, 0.0)
        initial = state.diagnostics.target_bottom_gas_area_nm2
        state.update(self.fully_open, 2.0)
        self.assertAlmostEqual(
            state.diagnostics.target_bottom_gas_area_nm2,
            initial / math.e,
        )
        self.assert_partition(state)
        state.update(self.fully_open, 20.0)
        self.assertLess(
            state.diagnostics.target_bottom_gas_area_nm2,
            0.5 * self.grid.cell_area_nm2,
        )
        self.assertFalse(np.any(state.bottom_gas_mask))
        self.assertFalse(np.any(state.gas_mask))

    def test_liquid_inheritance_is_the_default_for_fully_filled_gapfill(self) -> None:
        state = WettingState2D(
            self.grid, WettingParameters(enabled=True)
        )
        state.update(self.fully_open, 0.0)
        np.testing.assert_array_equal(
            state.liquid_mask,
            self.fully_open,
        )
        self.assertFalse(np.any(state.gas_mask))
        self.assert_partition(state)

    def test_capillary_only_controls_cannot_be_silently_ignored(self) -> None:
        for keyword in (
            {"entrance_delay_s": 1.0},
            {"entrance_pinning_pressure_Pa": 1.0},
            {"maximum_contact_line_speed_nm_s": 1.0},
            {"hydraulic_mobility_scale": 0.5},
        ):
            with self.subTest(keyword=keyword):
                with self.assertRaisesRegex(ValueError, "require.*capillary"):
                    WettingParameters(enabled=True, **keyword)


if __name__ == "__main__":
    unittest.main()

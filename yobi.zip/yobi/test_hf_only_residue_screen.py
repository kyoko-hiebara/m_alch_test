from __future__ import annotations

import unittest

from hf_only_residue_screen import (
    HFOnlyResidueScreenConfig,
    blanket_anchor_rows,
    build_screen_payload,
    run_bottom_pad_burn_down,
    run_redeposition_closure_screen,
    summarize_product_passivation_payload,
    summarize_wetting_mesh_convergence,
)


class HFOnlyResidueScreenTests(unittest.TestCase):
    def config(self, **updates) -> HFOnlyResidueScreenConfig:
        values = {
            "geometry_ids": ("10_10_180",),
            "preset_ids": (
                "kawarazaki_sicn_c22_dhf0p15_linear30s",
            ),
            "bottom_pad_thicknesses_nm": (1.0,),
            "bottom_local_rate_factors": (1.0, 0.1),
            "hf_exposure_times_s": (30.0, 1_000.0),
            "rinse_exchange_rates_s": (0.0, 0.05),
            "drying_rates_s": (1.0 / 30.0,),
        }
        values.update(updates)
        return HFOnlyResidueScreenConfig(**values)

    def test_blanket_anchor_is_dhf_only(self) -> None:
        row = blanket_anchor_rows(self.config())[0]
        self.assertEqual(row["central_rate_nm_min"], 0.06)
        self.assertFalse(row["ozone_used_in_rate_anchor"])
        self.assertEqual(
            row["one_raster_rate_sensitivity_nm_min"]["lower"], 0.0
        )

    def test_bottom_pad_uses_fixed_physical_time_and_local_rate_factor(
        self,
    ) -> None:
        payload = run_bottom_pad_burn_down(self.config())
        by_factor = {
            case["bottom_local_rate_factor"]: case
            for case in payload["cases"]
        }
        baseline = by_factor[1.0]
        slow = by_factor[0.1]
        self.assertAlmostEqual(baseline["central_clear_time_s"], 1_000.0)
        self.assertAlmostEqual(slow["central_clear_time_s"], 10_000.0)
        self.assertAlmostEqual(
            baseline["time_points"][0]["remaining_thickness_nm"], 0.97
        )
        self.assertAlmostEqual(
            baseline["time_points"][1]["remaining_thickness_nm"], 0.0
        )
        self.assertAlmostEqual(
            slow["time_points"][1]["remaining_thickness_nm"], 0.9
        )
        self.assertEqual(
            baseline["thickness_rate_degeneracy_coordinate_nm"], 1.0
        )
        self.assertEqual(
            slow["thickness_rate_degeneracy_coordinate_nm"], 10.0
        )

    def test_redeposition_capture_closes_and_no_dry_is_zero(self) -> None:
        payload = run_redeposition_closure_screen(self.config())
        self.assertLess(
            max(
                case["capture_plus_rinse_and_uncaptured_closure"]
                for case in payload["cases"]
            ),
            1.0e-12,
        )
        no_dry = [
            case
            for case in payload["cases"]
            if not case["post_hf_condition"]["dry_enabled"]
        ]
        self.assertTrue(no_dry)
        self.assertTrue(
            all(
                case["captured_fraction_of_generated_inventory"] == 0.0
                for case in no_dry
            )
        )

    def test_absolute_passivation_summary_reads_bottom_region(self) -> None:
        payload = {
            "cases": [
                {
                    "case_id": "10_10_180__preset__null",
                    "preset_key": "preset",
                    "material": "SiCN",
                    "scenario": {"key": "null"},
                    "absolute_time_checkpoints": [
                        {
                            "requested_value": 30.0,
                            "time_s": 30.0,
                            "time_over_planar_clear": 0.1,
                            "remaining_mass_fraction": 0.8,
                            "fields": {
                                "maximum_product_mol_m3": 0.0,
                                "mean_interface_product_mol_m3": 0.0,
                                "maximum_passivation": 0.0,
                                "mean_interface_passivation": 0.0,
                            },
                            "residue": {
                                "bottom_region": {
                                    "remaining_fraction_of_region": 0.9
                                }
                            },
                        }
                    ],
                    "convergence": {
                        "reactant": True,
                        "product": True,
                        "nonlinear": True,
                        "maximum_product_inventory_balance_relative_error": 0.0,
                    },
                }
            ]
        }
        rows = summarize_product_passivation_payload(
            payload,
            normalized_time=None,
            absolute_time_s=30.0,
        )
        self.assertEqual(rows[0]["time_basis"], "physical_time_s")
        self.assertEqual(rows[0]["bottom_region_remaining_fraction"], 0.9)

    def test_screen_payload_keeps_state_owners_separate(self) -> None:
        payload = build_screen_payload(self.config())
        self.assertFalse(
            payload["mechanism_state_ownership"][
                "combined_residue_used_for_causal_inference"
            ]
        )
        self.assertFalse(payload["bottom_pad_burn_down"]["ozone_terms_used"])

    def test_wetting_mesh_summary_checks_common_fingerprint(self) -> None:
        def payload(
            grid_spacing_nm: float,
            *,
            baseline_total: float,
            ideal_total: float,
        ) -> dict[str, object]:
            def case(
                scenario: str,
                remaining: float,
                bottom: float,
            ) -> dict[str, object]:
                return {
                    "geometry_name": "10_10_180",
                    "geometry": {"depth_nm": 180.0},
                    "scenario": scenario,
                    "scenario_interpretation": "test",
                    "outcome": {
                        "remaining_mass_fraction": remaining,
                        "bottom_15pct_remaining_fraction": bottom,
                        "near_wall_remaining_fraction": remaining,
                        "gas_area_nm2": 0.0,
                        "gas_area_quantization_error_nm2": 0.0,
                        "contact_line_depth_nm": 180.0,
                        "gas_pressure_Pa": 0.0,
                        "high_pressure_model_warning": False,
                        "gas_subgrid_representation_warning": False,
                        "phase_partition_relative_error": 0.0,
                    },
                }

            return {
                "config": {"grid_spacing_nm": grid_spacing_nm},
                "coupled_cases": [
                    case(
                        "baseline_inherited_liquid",
                        baseline_total,
                        0.0,
                    ),
                    case(
                        "bottom_gas_ideal_compression",
                        ideal_total,
                        0.005,
                    ),
                    case("entrance_delayed", 0.60, 1.0),
                    case("bottom_gas_fixed_volume_bound", 0.20, 1.0),
                    case("combined_adverse", 0.73, 1.0),
                ],
            }

        summary = summarize_wetting_mesh_convergence(
            {
                "coarse": payload(
                    2.0, baseline_total=0.0, ideal_total=0.0
                ),
                "fine": payload(
                    0.5, baseline_total=0.0, ideal_total=0.001
                ),
            }
        )
        self.assertEqual(summary["common_case_count"], 5)
        self.assertTrue(summary["qualitative_fingerprint_preserved"])
        self.assertEqual(summary["finest_grid_spacing_nm"], 0.5)


if __name__ == "__main__":
    unittest.main()

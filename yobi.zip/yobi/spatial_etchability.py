"""Spatial film-quality fields and residue topology for 2-D GAP FILL etching.

This module separates two questions that are otherwise easy to conflate:

* Is the as-deposited film intrinsically less etchable near the trench bottom
  or the Si sidewall?
* After etching, is the remaining solid geometrically attached to a sidewall,
  attached to the floor, attached to both, or isolated in the liquid?

The static rate factors below are hypothesis parameters, not literature-fitted
SiN/SiCN/SiOCN values. Dynamic product passivation, precipitation, and wetting can
later multiply the same local rate without changing residue classification.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Callable

import numpy as np
from scipy import ndimage

from level_set_2d import MonotonicLevelSet2D
from reaction_diffusion_2d import CartesianGrid2D, FOUR_CONNECTED


RateLaw = Callable[
    [np.ndarray, np.ndarray, np.ndarray, np.ndarray], np.ndarray | float
]


def _finite_nonnegative(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    return number


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


@dataclass(frozen=True)
class SpatialEtchabilityParameters:
    """Static multiplicative rate profile for an as-deposited GAP FILL.

    ``top_rate_factor`` and ``bottom_rate_factor`` define a monotone depth
    profile.  The sidewall and floor terms approach their respective
    ``*_rate_factor`` at zero distance and recover to one exponentially over
    ``*_influence_length_nm``.  All active terms are multiplied.
    """

    top_rate_factor: float = 1.0
    bottom_rate_factor: float = 1.0
    depth_exponent: float = 1.0
    sidewall_rate_factor: float = 1.0
    sidewall_influence_length_nm: float = 0.0
    floor_rate_factor: float = 1.0
    floor_influence_length_nm: float = 0.0
    minimum_combined_rate_factor: float = 0.0

    def __post_init__(self) -> None:
        for name in (
            "top_rate_factor",
            "bottom_rate_factor",
            "sidewall_rate_factor",
            "sidewall_influence_length_nm",
            "floor_rate_factor",
            "floor_influence_length_nm",
            "minimum_combined_rate_factor",
        ):
            _finite_nonnegative(name, getattr(self, name))
        _finite_positive("depth_exponent", self.depth_exponent)

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class GeometryDistanceFields:
    normalised_depth: np.ndarray
    sidewall_distance_nm: np.ndarray
    floor_distance_nm: np.ndarray


@dataclass(frozen=True)
class BoundaryContactFields:
    sidewall_contact_length_nm: np.ndarray
    bottom_contact_length_nm: np.ndarray


def geometry_distance_fields(grid: CartesianGrid2D) -> GeometryDistanceFields:
    """Return analytic distances inside the tapered cavity.

    Values outside the cavity are ``NaN`` so they cannot accidentally enter a
    film-property statistic.
    """

    geometry = grid.geometry
    depth = np.clip(grid.depth_mesh_nm, 0.0, geometry.depth_nm)
    normalised_depth = depth / geometry.depth_nm
    width = geometry.top_width_nm - (
        geometry.top_width_nm - geometry.bottom_width_nm
    ) * normalised_depth
    horizontal_clearance = 0.5 * width - np.abs(grid.lateral_mesh_nm)
    half_width_slope = 0.5 * (
        geometry.top_width_nm - geometry.bottom_width_nm
    ) / geometry.depth_nm
    sidewall_distance = horizontal_clearance / math.sqrt(
        1.0 + half_width_slope**2
    )
    floor_distance = geometry.depth_nm - depth
    cavity = grid.cavity_mask
    return GeometryDistanceFields(
        normalised_depth=np.where(cavity, normalised_depth, np.nan),
        sidewall_distance_nm=np.where(
            cavity, np.maximum(sidewall_distance, 0.0), np.nan
        ),
        floor_distance_nm=np.where(
            cavity, np.maximum(floor_distance, 0.0), np.nan
        ),
    )


def boundary_contact_fields(grid: CartesianGrid2D) -> BoundaryContactFields:
    """Return discrete Si-sidewall and trench-floor contact length per cell.

    The top opening is excluded.  Contact faces follow the same Cartesian mask
    used by front propagation, so attachment topology and moving-front
    connectivity use a consistent discretisation.
    """

    cavity = grid.cavity_mask
    sidewall = np.zeros(grid.shape, dtype=float)
    bottom = np.zeros(grid.shape, dtype=float)
    n_rows, n_columns = grid.shape
    rows, columns = np.nonzero(cavity)
    for row, column in zip(rows, columns, strict=True):
        # Horizontal left/right faces have length dz and can only be sidewall.
        for neighbour_column in (column - 1, column + 1):
            if not (0 <= neighbour_column < n_columns) or not cavity[
                row, neighbour_column
            ]:
                sidewall[row, column] += grid.dz_nm

        # The upper face at the opening is deliberately not a Si contact.
        if row > 0 and not cavity[row - 1, column]:
            if grid.depth_nm[row - 1] >= 0.0:
                sidewall[row, column] += grid.dx_nm

        # The final grid row terminates on the trench floor.  A missing cavity
        # cell above the floor is a staircase representation of the sidewall.
        if row == n_rows - 1:
            bottom[row, column] += grid.dx_nm
        elif not cavity[row + 1, column]:
            sidewall[row, column] += grid.dx_nm

    sidewall.setflags(write=False)
    bottom.setflags(write=False)
    return BoundaryContactFields(
        sidewall_contact_length_nm=sidewall,
        bottom_contact_length_nm=bottom,
    )


@dataclass(frozen=True)
class SpatialEtchabilityField:
    grid: CartesianGrid2D
    parameters: SpatialEtchabilityParameters
    depth_factor: np.ndarray
    sidewall_factor: np.ndarray
    floor_factor: np.ndarray
    combined_factor: np.ndarray
    distances: GeometryDistanceFields

    @classmethod
    def build(
        cls,
        grid: CartesianGrid2D,
        parameters: SpatialEtchabilityParameters | None = None,
    ) -> "SpatialEtchabilityField":
        p = parameters or SpatialEtchabilityParameters()
        distances = geometry_distance_fields(grid)
        cavity = grid.cavity_mask
        zeta = np.nan_to_num(distances.normalised_depth, nan=0.0)
        depth_factor = p.top_rate_factor + (
            p.bottom_rate_factor - p.top_rate_factor
        ) * zeta**p.depth_exponent

        sidewall_factor = np.ones(grid.shape, dtype=float)
        if p.sidewall_influence_length_nm > 0.0:
            distance = np.nan_to_num(
                distances.sidewall_distance_nm,
                nan=math.inf,
            )
            sidewall_factor = 1.0 - (1.0 - p.sidewall_rate_factor) * np.exp(
                -distance / p.sidewall_influence_length_nm
            )

        floor_factor = np.ones(grid.shape, dtype=float)
        if p.floor_influence_length_nm > 0.0:
            distance = np.nan_to_num(
                distances.floor_distance_nm,
                nan=math.inf,
            )
            floor_factor = 1.0 - (1.0 - p.floor_rate_factor) * np.exp(
                -distance / p.floor_influence_length_nm
            )

        combined = depth_factor * sidewall_factor * floor_factor
        combined = np.maximum(combined, p.minimum_combined_rate_factor)
        for field in (depth_factor, sidewall_factor, floor_factor, combined):
            field[~cavity] = 1.0
            field.setflags(write=False)
        return cls(
            grid=grid,
            parameters=p,
            depth_factor=depth_factor,
            sidewall_factor=sidewall_factor,
            floor_factor=floor_factor,
            combined_factor=combined,
            distances=distances,
        )

    def summary(self) -> dict[str, object]:
        values = self.combined_factor[self.grid.cavity_mask]
        return {
            "parameters": self.parameters.to_dict(),
            "minimum": float(np.min(values)),
            "maximum": float(np.max(values)),
            "mean": float(np.mean(values)),
            "percentiles": {
                str(percentile): float(np.percentile(values, percentile))
                for percentile in (1, 5, 25, 50, 75, 95, 99)
            },
        }


@dataclass(frozen=True)
class SpatiallyModifiedRateLaw:
    """Multiply any existing local rate law by a static film-quality field."""

    base_rate_law: RateLaw
    etchability: SpatialEtchabilityField

    def __call__(
        self,
        reactant: np.ndarray,
        product: np.ndarray,
        passivation: np.ndarray,
        interface_mask: np.ndarray,
    ) -> np.ndarray:
        interface = np.asarray(interface_mask, dtype=bool)
        if interface.shape != self.etchability.grid.shape:
            raise ValueError("interface_mask must match the etchability grid")
        raw = self.base_rate_law(reactant, product, passivation, interface)
        velocity = np.broadcast_to(np.asarray(raw, dtype=float), interface.shape)
        if np.any(~np.isfinite(velocity)) or np.any(velocity < 0.0):
            raise ValueError("base_rate_law must return finite non-negative values")
        modified = velocity * self.etchability.combined_factor
        return np.where(interface, modified, 0.0)


@dataclass(frozen=True)
class ResidueRegionSummary:
    initial_area_nm2: float
    remaining_area_nm2: float
    remaining_fraction_of_region: float
    fraction_of_total_remaining: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class ResidueAttachmentSummary:
    component_count: int
    remaining_area_nm2: float
    fraction_of_total_remaining: float

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


@dataclass(frozen=True)
class ResidueDiagnostics2D:
    time_s: float
    remaining_area_nm2: float
    remaining_mass_fraction: float
    sidewall_band_nm: float
    bottom_band_nm: float
    sidewall_region: ResidueRegionSummary
    bottom_region: ResidueRegionSummary
    core_region: ResidueRegionSummary
    sidewall_only: ResidueAttachmentSummary
    bottom_only: ResidueAttachmentSummary
    sidewall_and_bottom: ResidueAttachmentSummary
    isolated: ResidueAttachmentSummary
    total_component_count: int
    largest_component_area_nm2: float
    sidewall_contact_length_nm: float
    bottom_contact_length_nm: float
    wall_to_core_retention_ratio: float | None
    bottom_to_upper_retention_ratio: float | None
    residue_depth_centroid_nm: float | None
    mean_sidewall_distance_nm: float | None
    left_right_asymmetry: float
    classified_area_balance_relative_error: float

    def to_dict(self) -> dict[str, object]:
        return {
            "time_s": self.time_s,
            "remaining_area_nm2": self.remaining_area_nm2,
            "remaining_mass_fraction": self.remaining_mass_fraction,
            "sidewall_band_nm": self.sidewall_band_nm,
            "bottom_band_nm": self.bottom_band_nm,
            "sidewall_region": self.sidewall_region.to_dict(),
            "bottom_region": self.bottom_region.to_dict(),
            "core_region": self.core_region.to_dict(),
            "sidewall_only": self.sidewall_only.to_dict(),
            "bottom_only": self.bottom_only.to_dict(),
            "sidewall_and_bottom": self.sidewall_and_bottom.to_dict(),
            "isolated": self.isolated.to_dict(),
            "total_component_count": self.total_component_count,
            "largest_component_area_nm2": self.largest_component_area_nm2,
            "sidewall_contact_length_nm": self.sidewall_contact_length_nm,
            "bottom_contact_length_nm": self.bottom_contact_length_nm,
            "wall_to_core_retention_ratio": (
                self.wall_to_core_retention_ratio
            ),
            "bottom_to_upper_retention_ratio": (
                self.bottom_to_upper_retention_ratio
            ),
            "residue_depth_centroid_nm": self.residue_depth_centroid_nm,
            "mean_sidewall_distance_nm": self.mean_sidewall_distance_nm,
            "left_right_asymmetry": self.left_right_asymmetry,
            "classified_area_balance_relative_error": (
                self.classified_area_balance_relative_error
            ),
        }


def _region_summary(
    region: np.ndarray,
    solid_fraction: np.ndarray,
    cell_area_nm2: float,
    total_remaining_area_nm2: float,
) -> ResidueRegionSummary:
    initial_area = float(np.count_nonzero(region) * cell_area_nm2)
    remaining_area = float(np.sum(solid_fraction[region]) * cell_area_nm2)
    return ResidueRegionSummary(
        initial_area_nm2=initial_area,
        remaining_area_nm2=remaining_area,
        remaining_fraction_of_region=(
            remaining_area / initial_area if initial_area > 0.0 else 0.0
        ),
        fraction_of_total_remaining=(
            remaining_area / total_remaining_area_nm2
            if total_remaining_area_nm2 > 0.0
            else 0.0
        ),
    )


def analyse_residue_topology(
    front: MonotonicLevelSet2D,
    *,
    sidewall_band_nm: float = 1.0,
    bottom_band_nm: float = 2.0,
) -> ResidueDiagnostics2D:
    """Classify remaining GAP FILL by location and geometric attachment."""

    side_band = _finite_positive("sidewall_band_nm", sidewall_band_nm)
    bottom_band = _finite_positive("bottom_band_nm", bottom_band_nm)
    grid = front.grid
    distances = geometry_distance_fields(grid)
    cavity = grid.cavity_mask
    sidewall_region_mask = (
        cavity
        & (distances.sidewall_distance_nm <= side_band)
        & ~(distances.floor_distance_nm <= bottom_band)
    )
    bottom_region_mask = cavity & (
        distances.floor_distance_nm <= bottom_band
    )
    core_region_mask = cavity & ~sidewall_region_mask & ~bottom_region_mask

    solid_fraction = front.solid_fraction
    total_remaining_area = float(
        np.sum(solid_fraction[cavity]) * grid.cell_area_nm2
    )
    sidewall_region = _region_summary(
        sidewall_region_mask,
        solid_fraction,
        grid.cell_area_nm2,
        total_remaining_area,
    )
    bottom_region = _region_summary(
        bottom_region_mask,
        solid_fraction,
        grid.cell_area_nm2,
        total_remaining_area,
    )
    core_region = _region_summary(
        core_region_mask,
        solid_fraction,
        grid.cell_area_nm2,
        total_remaining_area,
    )

    labels, component_count = ndimage.label(
        front.solid_mask,
        structure=FOUR_CONNECTED,
    )
    boundary_contacts = boundary_contact_fields(grid)
    side_contact = boundary_contacts.sidewall_contact_length_nm > 0.0
    bottom_contact = boundary_contacts.bottom_contact_length_nm > 0.0
    categories: dict[str, list[float | int]] = {
        "sidewall_only": [0, 0.0],
        "bottom_only": [0, 0.0],
        "sidewall_and_bottom": [0, 0.0],
        "isolated": [0, 0.0],
    }
    largest_component_area = 0.0
    for label in range(1, component_count + 1):
        component = labels == label
        touches_side = bool(np.any(component & side_contact))
        touches_bottom = bool(np.any(component & bottom_contact))
        if touches_side and touches_bottom:
            category = "sidewall_and_bottom"
        elif touches_side:
            category = "sidewall_only"
        elif touches_bottom:
            category = "bottom_only"
        else:
            category = "isolated"
        area = float(np.sum(solid_fraction[component]) * grid.cell_area_nm2)
        largest_component_area = max(largest_component_area, area)
        categories[category][0] = int(categories[category][0]) + 1
        categories[category][1] = float(categories[category][1]) + area

    def attachment(name: str) -> ResidueAttachmentSummary:
        count = int(categories[name][0])
        area = float(categories[name][1])
        return ResidueAttachmentSummary(
            component_count=count,
            remaining_area_nm2=area,
            fraction_of_total_remaining=(
                area / total_remaining_area if total_remaining_area > 0.0 else 0.0
            ),
        )

    classified_area = sum(float(values[1]) for values in categories.values())
    scale = max(total_remaining_area, classified_area, 1.0e-30)

    def safe_ratio(numerator: float, denominator: float) -> float | None:
        if denominator <= 0.0:
            return None
        return numerator / denominator

    wall_to_core = safe_ratio(
        sidewall_region.remaining_fraction_of_region,
        core_region.remaining_fraction_of_region,
    )
    upper_initial_area = (
        sidewall_region.initial_area_nm2 + core_region.initial_area_nm2
    )
    upper_remaining_area = (
        sidewall_region.remaining_area_nm2 + core_region.remaining_area_nm2
    )
    upper_retention = (
        upper_remaining_area / upper_initial_area
        if upper_initial_area > 0.0
        else 0.0
    )
    bottom_to_upper = safe_ratio(
        bottom_region.remaining_fraction_of_region,
        upper_retention,
    )

    weights = solid_fraction * grid.cell_area_nm2
    if total_remaining_area > 0.0:
        depth_centroid = float(
            np.sum(weights * grid.depth_mesh_nm) / total_remaining_area
        )
        mean_wall_distance = float(
            np.nansum(weights * distances.sidewall_distance_nm)
            / total_remaining_area
        )
    else:
        depth_centroid = None
        mean_wall_distance = None
    left_area = float(
        np.sum(weights[grid.lateral_mesh_nm < 0.0])
    )
    right_area = float(
        np.sum(weights[grid.lateral_mesh_nm > 0.0])
    )
    centre_area = float(
        np.sum(weights[grid.lateral_mesh_nm == 0.0])
    )
    left_area += 0.5 * centre_area
    right_area += 0.5 * centre_area
    asymmetry = (
        abs(left_area - right_area) / total_remaining_area
        if total_remaining_area > 0.0
        else 0.0
    )
    sidewall_contact_length = float(
        np.sum(
            boundary_contacts.sidewall_contact_length_nm * solid_fraction
        )
    )
    bottom_contact_length = float(
        np.sum(
            boundary_contacts.bottom_contact_length_nm * solid_fraction
        )
    )
    return ResidueDiagnostics2D(
        time_s=front.time_s,
        remaining_area_nm2=total_remaining_area,
        remaining_mass_fraction=(
            total_remaining_area / front.initial_solid_area_nm2
        ),
        sidewall_band_nm=side_band,
        bottom_band_nm=bottom_band,
        sidewall_region=sidewall_region,
        bottom_region=bottom_region,
        core_region=core_region,
        sidewall_only=attachment("sidewall_only"),
        bottom_only=attachment("bottom_only"),
        sidewall_and_bottom=attachment("sidewall_and_bottom"),
        isolated=attachment("isolated"),
        total_component_count=int(component_count),
        largest_component_area_nm2=largest_component_area,
        sidewall_contact_length_nm=sidewall_contact_length,
        bottom_contact_length_nm=bottom_contact_length,
        wall_to_core_retention_ratio=wall_to_core,
        bottom_to_upper_retention_ratio=bottom_to_upper,
        residue_depth_centroid_nm=depth_centroid,
        mean_sidewall_distance_nm=mean_wall_distance,
        left_right_asymmetry=asymmetry,
        classified_area_balance_relative_error=(
            abs(classified_area - total_remaining_area) / scale
        ),
    )


__all__ = [
    "GeometryDistanceFields",
    "BoundaryContactFields",
    "ResidueAttachmentSummary",
    "ResidueDiagnostics2D",
    "ResidueRegionSummary",
    "SpatialEtchabilityField",
    "SpatialEtchabilityParameters",
    "SpatiallyModifiedRateLaw",
    "analyse_residue_topology",
    "boundary_contact_fields",
    "geometry_distance_fields",
]

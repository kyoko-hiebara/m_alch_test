from __future__ import annotations

import copy
import tempfile
import unittest
from pathlib import Path

from trench_graph_kmc_visualization import (
    plot_trench_kmc_event_history,
    plot_trench_kmc_phase_maps,
    plot_trench_kmc_sensitivity_summary,
)
from trench_kmc_sweep import TrenchKMCSweepConfig, run_trench_kmc_sweep


class TrenchGraphKMCVisualizationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = run_trench_kmc_sweep(
            TrenchKMCSweepConfig(
                geometries=("10_8_180",),
                scenarios=("combined",),
                grid_spacing_nm=10.0,
                reservoir_height_nm=10.0,
                lateral_margin_nm=0.0,
                total_time_s=0.01,
                macro_time_step_s=0.01,
                maximum_events=5,
                hf_scales=(0.8, 1.2),
                retention_strength_scales=(0.0, 1.0),
                base_seed=161803,
                parallel_workers=1,
            )
        )

    def test_all_three_plot_functions_write_png_files(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            phase_path = root / "phase.png"
            sensitivity_path = root / "sensitivity.png"
            history_path = root / "history.png"

            returned = (
                plot_trench_kmc_phase_maps(
                    self.payload,
                    phase_path,
                    max_panels=1,
                    dpi=55,
                ),
                plot_trench_kmc_sensitivity_summary(
                    self.payload,
                    sensitivity_path,
                    dpi=55,
                ),
                plot_trench_kmc_event_history(
                    self.payload["cases"][0],
                    history_path,
                    dpi=55,
                ),
            )

            self.assertEqual(
                returned,
                (phase_path, sensitivity_path, history_path),
            )
            for path in returned:
                with self.subTest(path=path.name):
                    self.assertTrue(path.is_file())
                    self.assertGreater(path.stat().st_size, 1_024)
                    self.assertEqual(path.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")

    def test_intermediate_states_and_events_are_visualized(self) -> None:
        payload = copy.deepcopy(self.payload)
        case = payload["cases"][0]
        sites = case["snapshot"]["sites"]
        matrix_indices = [
            index
            for index, site_type in enumerate(sites["site_type"])
            if site_type == "matrix"
        ]
        self.assertGreaterEqual(len(matrix_indices), 2)
        sites["state"][matrix_indices[0]] = "hydrolyzed_silanol"
        sites["state"][matrix_indices[1]] = "fluorinated"
        for record in case["sync_history"]:
            record["state_counts"]["hydrolyzed_silanol"] = 1
            record["state_counts"]["fluorinated"] = 1
        x_nm = sites["x_nm"][matrix_indices[0]]
        depth_nm = sites["depth_nm"][matrix_indices[0]]
        case["event_locations"].extend(
            [
                {
                    "event_name": "hydrolyze",
                    "time_s": 0.002,
                    "x_nm": x_nm,
                    "depth_nm": depth_nm,
                },
                {
                    "event_name": "fluorinate_silanol",
                    "time_s": 0.004,
                    "x_nm": x_nm,
                    "depth_nm": depth_nm,
                },
                {
                    "event_name": "remove_fluorinated",
                    "time_s": 0.006,
                    "x_nm": x_nm,
                    "depth_nm": depth_nm,
                },
            ]
        )

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            phase_path = plot_trench_kmc_phase_maps(
                payload,
                root / "intermediate_phase.png",
                max_panels=1,
                dpi=55,
            )
            history_path = plot_trench_kmc_event_history(
                case,
                root / "intermediate_history.png",
                dpi=55,
            )
            for path in (phase_path, history_path):
                self.assertTrue(path.is_file())
                self.assertGreater(path.stat().st_size, 1_024)
                self.assertEqual(
                    path.read_bytes()[:8],
                    b"\x89PNG\r\n\x1a\n",
                )


if __name__ == "__main__":
    unittest.main()

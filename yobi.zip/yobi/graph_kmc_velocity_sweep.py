"""Ensemble graph-KMC relative velocity law for a reactive surface patch.

The graph in this module represents parallel surface columns, not the full
170--180 nm trench depth.  Removing a site exposes the next reactive layer in
the same column, so the regenerative removal flux per surface column is a
well-defined local rate.  KMC supplies only a dimensionless environmental
modifier.  Absolute velocities are anchored to film-specific blanket WER
presets from :mod:`literature_parameters`::

    v_absolute = v_blanket,literature * q_KMC(environment) / q_KMC(reference)

The event prefactors, barriers, inhibition, and passivation constants remain
uncalibrated assumptions and are reported separately from literature-fixed
inputs in every sweep result.
"""

from __future__ import annotations

import math
import os
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from typing import Iterable, Mapping, Sequence

import numpy as np

from graph_kmc import AmorphousGraph, EventTemplate, GraphKMC, GraphSite
from literature_parameters import (
    LITERATURE_ETCH_PRESETS,
    SOURCES,
    LiteratureEtchPreset,
)


GAS_CONSTANT_J_MOL_K = 8.31446261815324
REFERENCE_TEMPERATURE_K = 298.15
DEFAULT_SITE_COUNTS = (24, 48, 96, 192)
DEFAULT_TEMPERATURES_K = (288.15, 298.15, 323.15)
DEFAULT_HF_ACTIVITIES = (0.25, 1.0)
DEFAULT_PRODUCT_ACTIVITIES = (0.0, 0.15, 0.5)
DEFAULT_MATERIALS = ("SiN", "SiOCN")

GRAPH_KMC_VELOCITY_NOTICE = (
    "Blanket WER values are literature anchors. Graph KMC contributes only a "
    "dimensionless, uncalibrated environmental modifier; it is not an "
    "independent absolute etch-rate prediction or a process recipe."
)


def _nominal_presets_by_material() -> dict[str, LiteratureEtchPreset]:
    result: dict[str, LiteratureEtchPreset] = {}
    for preset in LITERATURE_ETCH_PRESETS.values():
        if preset.rate_band != "nominal":
            continue
        if preset.material in result:
            raise RuntimeError(
                f"more than one nominal preset exists for {preset.material}"
            )
        result[preset.material] = preset
    missing = set(DEFAULT_MATERIALS).difference(result)
    if missing:
        raise RuntimeError(f"missing nominal literature presets: {sorted(missing)}")
    return result


NOMINAL_PRESET_BY_MATERIAL = _nominal_presets_by_material()


@dataclass(frozen=True)
class SurfacePatchRateAssumptions:
    """Uncalibrated event-rate assumptions used only for relative modifiers."""

    activation_prefactor_s_inv: float = 0.5
    activation_barrier_J_mol: float = 18_000.0
    removal_prefactor_s_inv: float = 0.8
    removal_barrier_J_mol: float = 24_000.0
    product_inhibition_coefficient: float = 2.0
    passivation_prefactor_s_inv: float = 0.2
    depassivation_rate_s_inv: float = 0.05
    reference_temperature_K: float = REFERENCE_TEMPERATURE_K

    def __post_init__(self) -> None:
        positive = (
            "activation_prefactor_s_inv",
            "removal_prefactor_s_inv",
            "depassivation_rate_s_inv",
            "reference_temperature_K",
        )
        nonnegative = (
            "activation_barrier_J_mol",
            "removal_barrier_J_mol",
            "product_inhibition_coefficient",
            "passivation_prefactor_s_inv",
        )
        for name in positive:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        for name in nonnegative:
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")


@dataclass(frozen=True)
class PatchEnvironment:
    temperature_K: float = REFERENCE_TEMPERATURE_K
    hf_activity: float = 1.0
    product_activity: float = 0.0

    def __post_init__(self) -> None:
        if not math.isfinite(self.temperature_K) or self.temperature_K <= 0.0:
            raise ValueError("temperature_K must be finite and positive")
        for name in ("hf_activity", "product_activity"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


REFERENCE_ENVIRONMENT = PatchEnvironment()


@dataclass(frozen=True)
class GraphKMCVelocitySweepConfig:
    site_counts: tuple[int, ...] = DEFAULT_SITE_COUNTS
    environment_site_count: int = 96
    replicas: int = 32
    temperatures_K: tuple[float, ...] = DEFAULT_TEMPERATURES_K
    hf_activities: tuple[float, ...] = DEFAULT_HF_ACTIVITIES
    product_activities: tuple[float, ...] = DEFAULT_PRODUCT_ACTIVITIES
    materials: tuple[str, ...] = DEFAULT_MATERIALS
    warmup_layers: int = 1
    measurement_layers: int = 4
    maximum_events_per_requested_removal: int = 100
    root_seed: int = 20260714
    workers: int = 0
    assumptions: SurfacePatchRateAssumptions = SurfacePatchRateAssumptions()

    def __post_init__(self) -> None:
        if not self.site_counts:
            raise ValueError("site_counts must not be empty")
        if any(not isinstance(value, int) or value < 3 for value in self.site_counts):
            raise ValueError("every site count must be an integer >= 3")
        if len(set(self.site_counts)) != len(self.site_counts):
            raise ValueError("site_counts must be unique")
        if not isinstance(self.environment_site_count, int) or self.environment_site_count < 3:
            raise ValueError("environment_site_count must be an integer >= 3")
        for name in (
            "replicas",
            "warmup_layers",
            "measurement_layers",
            "maximum_events_per_requested_removal",
        ):
            value = getattr(self, name)
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if not isinstance(self.root_seed, int) or self.root_seed < 0:
            raise ValueError("root_seed must be a non-negative integer")
        if not isinstance(self.workers, int) or self.workers < 0:
            raise ValueError("workers must be a non-negative integer")
        if not self.temperatures_K or not self.hf_activities or not self.product_activities:
            raise ValueError("environment axes must not be empty")
        for temperature in self.temperatures_K:
            PatchEnvironment(temperature, 1.0, 0.0)
        for activity in self.hf_activities:
            PatchEnvironment(REFERENCE_TEMPERATURE_K, activity, 0.0)
            if activity <= 0.0:
                raise ValueError("hf_activities must be positive for a removal sweep")
        for activity in self.product_activities:
            PatchEnvironment(REFERENCE_TEMPERATURE_K, 1.0, activity)
        for name in (
            "temperatures_K",
            "hf_activities",
            "product_activities",
            "materials",
        ):
            values = getattr(self, name)
            if len(set(values)) != len(values):
                raise ValueError(f"{name} must contain unique values")
        if not self.materials:
            raise ValueError("materials must not be empty")
        unknown = set(self.materials).difference(NOMINAL_PRESET_BY_MATERIAL)
        if unknown:
            raise ValueError(f"unknown materials: {sorted(unknown)}")

    @property
    def resolved_workers(self) -> int:
        if self.workers > 0:
            return self.workers
        return max(1, min(4, os.cpu_count() or 1))

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["site_counts"] = list(self.site_counts)
        result["temperatures_K"] = list(self.temperatures_K)
        result["hf_activities"] = list(self.hf_activities)
        result["product_activities"] = list(self.product_activities)
        result["materials"] = list(self.materials)
        return result


def _arrhenius_ratio(
    temperature_K: float,
    barrier_J_mol: float,
    reference_temperature_K: float,
) -> float:
    exponent = -barrier_J_mol / GAS_CONSTANT_J_MOL_K * (
        1.0 / temperature_K - 1.0 / reference_temperature_K
    )
    return math.exp(float(np.clip(exponent, -700.0, 700.0)))


def build_surface_patch_kmc(
    site_count: int,
    material: str,
    environment: PatchEnvironment,
    *,
    seed: int,
    assumptions: SurfacePatchRateAssumptions = SurfacePatchRateAssumptions(),
) -> GraphKMC:
    """Build a periodic patch of equivalent, always-liquid-accessible columns."""

    if not isinstance(site_count, int) or site_count < 3:
        raise ValueError("site_count must be an integer >= 3")
    if material not in {*DEFAULT_MATERIALS, "generic_surface_patch"}:
        raise ValueError("material must be SiN, SiOCN, or generic_surface_patch")
    sites = [
        GraphSite(
            site_id=index,
            material=material,
            attributes={
                "surface_column": 1.0,
                "removal_count": 0.0,
            },
        )
        for index in range(site_count)
    ]
    edges = [(index, (index + 1) % site_count) for index in range(site_count)]
    graph = AmorphousGraph(sites, edges)

    activation_temperature_factor = _arrhenius_ratio(
        environment.temperature_K,
        assumptions.activation_barrier_J_mol,
        assumptions.reference_temperature_K,
    )
    removal_temperature_factor = _arrhenius_ratio(
        environment.temperature_K,
        assumptions.removal_barrier_J_mol,
        assumptions.reference_temperature_K,
    )

    activation_rate = (
        assumptions.activation_prefactor_s_inv
        * environment.hf_activity
        * activation_temperature_factor
    )
    removal_rate = (
        assumptions.removal_prefactor_s_inv
        * removal_temperature_factor
        / (
            1.0
            + assumptions.product_inhibition_coefficient
            * environment.product_activity
        )
    )
    passivation_rate = (
        assumptions.passivation_prefactor_s_inv * environment.product_activity
    )

    def expose_next_layer(context, _rng) -> tuple[int, ...]:
        context.site.attributes["removal_count"] += 1.0
        context.site.state = "intact"
        return (context.site_id,)

    events = (
        EventTemplate(
            "activate",
            "intact",
            "activated",
            activation_rate,
            dependency_radius=0,
        ),
        EventTemplate(
            "passivate",
            "activated",
            "passivated",
            passivation_rate,
            dependency_radius=0,
        ),
        EventTemplate(
            "depassivate",
            "passivated",
            "activated",
            assumptions.depassivation_rate_s_inv,
            dependency_radius=0,
        ),
        EventTemplate(
            "remove",
            "activated",
            None,
            removal_rate,
            action=expose_next_layer,
            dependency_radius=0,
        ),
    )
    return GraphKMC(
        graph,
        events,
        seed=seed,
        environment={
            **environment.to_dict(),
            "surface_patch_semantics": "parallel_regenerative_columns",
        },
    )


def _total_removals(kmc: GraphKMC) -> int:
    return int(
        round(
            sum(
                site.attributes.get("removal_count", 0.0)
                for site in kmc.graph.sites.values()
            )
        )
    )


def _time_averaged_state_fractions(
    initial_counts: Mapping[str, int],
    records: Sequence,
    site_count: int,
    elapsed_s: float,
) -> dict[str, float]:
    states = ("intact", "activated", "passivated", "removed", "oxidized")
    counts = Counter({name: int(initial_counts.get(name, 0)) for name in states})
    integrals = Counter({name: 0.0 for name in states})
    for record in records:
        for name in states:
            integrals[name] += counts[name] * record.waiting_time_s
        if record.old_state != record.new_state:
            counts[record.old_state] -= 1
            counts[record.new_state] += 1
    if elapsed_s <= 0.0:
        return {name: 0.0 for name in states}
    return {
        name: float(integrals[name] / (site_count * elapsed_s))
        for name in states
    }


@dataclass(frozen=True)
class _PatchTask:
    task_key: tuple[object, ...]
    site_count: int
    material: str
    environment: PatchEnvironment
    seed: int
    warmup_layers: int
    measurement_layers: int
    maximum_events_per_requested_removal: int
    assumptions: SurfacePatchRateAssumptions


def _run_patch_task(task: _PatchTask) -> tuple[tuple[object, ...], dict[str, object]]:
    kmc = build_surface_patch_kmc(
        task.site_count,
        task.material,
        task.environment,
        seed=task.seed,
        assumptions=task.assumptions,
    )
    warmup_target = task.warmup_layers * task.site_count
    measurement_removals = task.measurement_layers * task.site_count
    event_cap = (
        task.maximum_events_per_requested_removal
        * (warmup_target + measurement_removals)
    )
    warmup = kmc.run(
        max_events=event_cap,
        stop_condition=lambda model: _total_removals(model) >= warmup_target,
    )
    if _total_removals(kmc) != warmup_target:
        raise RuntimeError(
            f"surface-patch warmup did not reach {warmup_target} removals; "
            f"stop_reason={warmup.stop_reason}"
        )

    initial_counts = kmc.graph.state_counts()
    final_target = warmup_target + measurement_removals
    measurement = kmc.run(
        max_events=event_cap,
        stop_condition=lambda model: _total_removals(model) >= final_target,
    )
    achieved = _total_removals(kmc) - warmup_target
    if achieved != measurement_removals or measurement.elapsed_s <= 0.0:
        raise RuntimeError(
            f"surface-patch measurement reached {achieved}/{measurement_removals} "
            f"removals; stop_reason={measurement.stop_reason}"
        )
    removal_flux_s = achieved / measurement.elapsed_s
    per_column_rate_s = removal_flux_s / task.site_count
    state_fractions = _time_averaged_state_fractions(
        initial_counts,
        measurement.event_log,
        task.site_count,
        measurement.elapsed_s,
    )
    result: dict[str, object] = {
        "seed": task.seed,
        "site_count": task.site_count,
        "material_label": task.material,
        "environment": task.environment.to_dict(),
        "warmup_removals": warmup_target,
        "measurement_removals": achieved,
        "measurement_elapsed_s": measurement.elapsed_s,
        "removal_flux_events_s": removal_flux_s,
        "per_column_removal_rate_s": per_column_rate_s,
        "event_count": measurement.event_count,
        "event_counts": dict(measurement.event_counts),
        "time_averaged_state_fractions": state_fractions,
        "final_state_counts": dict(measurement.final_state_counts),
        "stop_reason": measurement.stop_reason,
        "rate_evaluations": measurement.rate_evaluations,
    }
    return task.task_key, result


_WORKER_THREAD_LIMITER = None


def _initialise_worker() -> None:
    global _WORKER_THREAD_LIMITER
    try:
        from threadpoolctl import threadpool_limits
    except ImportError:
        return
    _WORKER_THREAD_LIMITER = threadpool_limits(limits=1)


def _execute_tasks(
    tasks: Sequence[_PatchTask], workers: int
) -> dict[tuple[object, ...], dict[str, object]]:
    if workers == 1:
        pairs = [_run_patch_task(task) for task in tasks]
    else:
        with ProcessPoolExecutor(
            max_workers=workers,
            initializer=_initialise_worker,
        ) as executor:
            pairs = list(executor.map(_run_patch_task, tasks))
    return dict(pairs)


def _stable_seed(root_seed: int, *indices: int) -> int:
    sequence = np.random.SeedSequence([root_seed, *indices])
    return int(sequence.generate_state(1, dtype=np.uint64)[0])


def _summary(values: Iterable[float]) -> dict[str, float]:
    data = np.asarray(tuple(values), dtype=float)
    if data.size == 0 or not np.all(np.isfinite(data)):
        raise ValueError("summary values must be nonempty and finite")
    mean = float(np.mean(data))
    sample_sd = float(np.std(data, ddof=1)) if data.size > 1 else 0.0
    standard_error = sample_sd / math.sqrt(data.size)
    return {
        "count": int(data.size),
        "mean": mean,
        "sample_sd": sample_sd,
        "standard_error": standard_error,
        "normal_approx_95ci_low": mean - 1.96 * standard_error,
        "normal_approx_95ci_high": mean + 1.96 * standard_error,
        "median": float(np.median(data)),
        "q05": float(np.quantile(data, 0.05)),
        "q95": float(np.quantile(data, 0.95)),
        "minimum": float(np.min(data)),
        "maximum": float(np.max(data)),
    }


def _ratio_of_means_modifier(
    conditioned_rates: Sequence[float],
    reference_rates: Sequence[float],
    *,
    bootstrap_seed: int,
    bootstrap_replicates: int = 2000,
) -> dict[str, object]:
    """Return a paired-bootstrap ratio of arithmetic ensemble throughputs."""

    conditioned = np.asarray(conditioned_rates, dtype=float)
    reference = np.asarray(reference_rates, dtype=float)
    if conditioned.shape != reference.shape or conditioned.ndim != 1:
        raise ValueError("conditioned and reference rates must be paired vectors")
    if conditioned.size == 0 or np.any(conditioned <= 0.0) or np.any(reference <= 0.0):
        raise ValueError("paired rates must be nonempty, finite, and positive")
    value = float(np.mean(conditioned) / np.mean(reference))
    rng = np.random.default_rng(bootstrap_seed)
    indices = rng.integers(
        0,
        conditioned.size,
        size=(bootstrap_replicates, conditioned.size),
    )
    sampled_conditioned = np.mean(conditioned[indices], axis=1)
    sampled_reference = np.mean(reference[indices], axis=1)
    bootstrap = sampled_conditioned / sampled_reference
    paired_ratios = conditioned / reference
    return {
        "estimator": "ratio_of_arithmetic_mean_per_column_throughputs",
        "value": value,
        "paired_bootstrap_replicates": bootstrap_replicates,
        "paired_bootstrap_95ci_low": float(np.quantile(bootstrap, 0.025)),
        "paired_bootstrap_95ci_high": float(np.quantile(bootstrap, 0.975)),
        "conditioned_rate_s": _summary(conditioned),
        "reference_rate_s": _summary(reference),
        "paired_replicate_ratio_diagnostic": _summary(paired_ratios),
    }


def _is_reference(environment: PatchEnvironment) -> bool:
    return environment == REFERENCE_ENVIRONMENT


def run_graph_kmc_velocity_sweep(
    config: GraphKMCVelocitySweepConfig = GraphKMCVelocitySweepConfig(),
) -> dict[str, object]:
    """Run the size audit and paired environmental modifier ensemble."""

    size_tasks: list[_PatchTask] = []
    for site_index, site_count in enumerate(config.site_counts):
        for replica in range(config.replicas):
            size_tasks.append(
                _PatchTask(
                    task_key=("size", site_count, replica),
                    site_count=site_count,
                    material="generic_surface_patch",
                    environment=REFERENCE_ENVIRONMENT,
                    seed=_stable_seed(config.root_seed, 1, site_index, replica),
                    warmup_layers=config.warmup_layers,
                    measurement_layers=config.measurement_layers,
                    maximum_events_per_requested_removal=(
                        config.maximum_events_per_requested_removal
                    ),
                    assumptions=config.assumptions,
                )
            )

    environments = tuple(
        PatchEnvironment(temperature, hf_activity, product_activity)
        for temperature in config.temperatures_K
        for hf_activity in config.hf_activities
        for product_activity in config.product_activities
    )
    environment_tasks: list[_PatchTask] = []
    for material in config.materials:
        for replica in range(config.replicas):
            # The relative mechanism is intentionally shared across materials;
            # common random numbers make any material difference come only from
            # the independently documented blanket anchor.
            seed = _stable_seed(config.root_seed, 2, replica)
            environment_tasks.append(
                _PatchTask(
                    task_key=("reference", material, replica),
                    site_count=config.environment_site_count,
                    material=material,
                    environment=REFERENCE_ENVIRONMENT,
                    seed=seed,
                    warmup_layers=config.warmup_layers,
                    measurement_layers=config.measurement_layers,
                    maximum_events_per_requested_removal=(
                        config.maximum_events_per_requested_removal
                    ),
                    assumptions=config.assumptions,
                )
            )
            for environment_index, environment in enumerate(environments):
                if _is_reference(environment):
                    continue
                environment_tasks.append(
                    _PatchTask(
                        task_key=(
                            "environment",
                            material,
                            environment_index,
                            replica,
                        ),
                        site_count=config.environment_site_count,
                        material=material,
                        environment=environment,
                        seed=seed,
                        warmup_layers=config.warmup_layers,
                        measurement_layers=config.measurement_layers,
                        maximum_events_per_requested_removal=(
                            config.maximum_events_per_requested_removal
                        ),
                        assumptions=config.assumptions,
                    )
                )

    all_results = _execute_tasks(
        tuple(size_tasks + environment_tasks), config.resolved_workers
    )

    size_audit = []
    for site_count in config.site_counts:
        runs = [
            all_results[("size", site_count, replica)]
            for replica in range(config.replicas)
        ]
        size_audit.append(
            {
                "site_count": site_count,
                "replica_count": config.replicas,
                "per_column_removal_rate_s": _summary(
                    float(run["per_column_removal_rate_s"]) for run in runs
                ),
                "measurement_elapsed_s": _summary(
                    float(run["measurement_elapsed_s"]) for run in runs
                ),
                "runs": runs,
            }
        )
    largest_size_item = max(size_audit, key=lambda item: int(item["site_count"]))
    largest_size_mean = float(
        largest_size_item["per_column_removal_rate_s"]["mean"]
    )
    for item in size_audit:
        mean_rate = float(item["per_column_removal_rate_s"]["mean"])
        item["mean_rate_relative_to_largest_size"] = mean_rate / largest_size_mean
        item["relative_difference_from_largest_size"] = (
            mean_rate / largest_size_mean - 1.0
        )

    environment_table = []
    for material in config.materials:
        preset = NOMINAL_PRESET_BY_MATERIAL[material]
        references = {
            replica: all_results[("reference", material, replica)]
            for replica in range(config.replicas)
        }
        for environment_index, environment in enumerate(environments):
            replicate_rows = []
            for replica in range(config.replicas):
                reference = references[replica]
                conditioned = (
                    reference
                    if _is_reference(environment)
                    else all_results[
                        ("environment", material, environment_index, replica)
                    ]
                )
                reference_rate = float(reference["per_column_removal_rate_s"])
                conditioned_rate = float(conditioned["per_column_removal_rate_s"])
                modifier = conditioned_rate / reference_rate
                replicate_rows.append(
                    {
                        "replica": replica,
                        "seed": int(conditioned["seed"]),
                        "reference_per_column_rate_s": reference_rate,
                        "conditioned_per_column_rate_s": conditioned_rate,
                        "relative_modifier": modifier,
                        "absolute_velocity_nm_s": (
                            preset.planar_rate_nm_s * modifier
                        ),
                        "conditioned_measurement_elapsed_s": conditioned[
                            "measurement_elapsed_s"
                        ],
                        "conditioned_event_counts": conditioned["event_counts"],
                        "conditioned_time_averaged_state_fractions": conditioned[
                            "time_averaged_state_fractions"
                        ],
                        "conditioned_stop_reason": conditioned["stop_reason"],
                    }
                )
            conditioned_rates = [
                float(row["conditioned_per_column_rate_s"])
                for row in replicate_rows
            ]
            reference_rates = [
                float(row["reference_per_column_rate_s"])
                for row in replicate_rows
            ]
            modifier_summary = _ratio_of_means_modifier(
                conditioned_rates,
                reference_rates,
                bootstrap_seed=_stable_seed(
                    config.root_seed,
                    3,
                    environment_index,
                ),
            )
            modifier_value = float(modifier_summary["value"])
            modifier_ci_low = float(
                modifier_summary["paired_bootstrap_95ci_low"]
            )
            modifier_ci_high = float(
                modifier_summary["paired_bootstrap_95ci_high"]
            )
            anchor_uncertainty_nm_s = (
                None
                if preset.planar_rate_uncertainty_nm_min is None
                else preset.planar_rate_uncertainty_nm_min / 60.0
            )
            environment_table.append(
                {
                    "material": material,
                    "preset_key": preset.key,
                    "environment": environment.to_dict(),
                    "reference_environment": REFERENCE_ENVIRONMENT.to_dict(),
                    "blanket_reference_velocity_nm_s": preset.planar_rate_nm_s,
                    "blanket_reference_velocity_nm_min": preset.planar_rate_nm_min,
                    "relative_modifier": modifier_summary,
                    "absolute_velocity_nm_s": {
                        "value": preset.planar_rate_nm_s * modifier_value,
                        "kmc_paired_bootstrap_95ci_low": (
                            preset.planar_rate_nm_s * modifier_ci_low
                        ),
                        "kmc_paired_bootstrap_95ci_high": (
                            preset.planar_rate_nm_s * modifier_ci_high
                        ),
                        "blanket_anchor_uncertainty_nm_s": (
                            anchor_uncertainty_nm_s
                        ),
                        "uncertainties_combined": False,
                    },
                    "absolute_velocity_nm_min": {
                        "value": preset.planar_rate_nm_min * modifier_value,
                        "kmc_paired_bootstrap_95ci_low": (
                            preset.planar_rate_nm_min * modifier_ci_low
                        ),
                        "kmc_paired_bootstrap_95ci_high": (
                            preset.planar_rate_nm_min * modifier_ci_high
                        ),
                        "blanket_anchor_uncertainty_nm_min": (
                            preset.planar_rate_uncertainty_nm_min
                        ),
                        "uncertainties_combined": False,
                    },
                    "replicates": replicate_rows,
                }
            )

    literature_fixed = {}
    for material in config.materials:
        preset = NOMINAL_PRESET_BY_MATERIAL[material]
        literature_fixed[material] = {
            "preset_key": preset.key,
            "material": preset.material,
            "rate_band": preset.rate_band,
            "film_description": preset.film_description,
            "reported_or_derived_planar_rate_nm_min": preset.planar_rate_nm_min,
            "derived_planar_rate_nm_s": preset.planar_rate_nm_s,
            "planar_rate_uncertainty_nm_min": (
                preset.planar_rate_uncertainty_nm_min
            ),
            "reported_solution": preset.reported_solution,
            "reported_solution_temperature_K": (
                preset.reported_solution_temperature_K
            ),
            "rate_evidence": preset.rate_evidence,
            "rate_source": SOURCES[preset.rate_source_key].to_dict(),
            "extrapolation_caveat": preset.extrapolation_caveat,
        }
    return {
        "schema_version": 1,
        "model": "regenerative surface-patch graph KMC relative velocity law",
        "notice": GRAPH_KMC_VELOCITY_NOTICE,
        "calibration_status": {
            "absolute_blanket_anchor": "film-specific literature WER",
            "relative_kmc_response": "uncalibrated screening assumption",
            "deep_trench_prediction_validated": False,
            "process_recipe": False,
        },
        "config": config.to_dict(),
        "case_counts": {
            "size_audit_runs": len(size_tasks),
            "environment_condition_replicates": (
                len(config.materials) * len(environments) * config.replicas
            ),
            "unique_reference_runs_reused_for_pairing": (
                len(config.materials) * config.replicas
            ),
            "executed_kmc_runs": len(size_tasks) + len(environment_tasks),
        },
        "parameter_provenance": {
            "literature_observation_and_derived_rate": {
                "blanket_WER_presets": literature_fixed,
                "role": (
                    "The nominal film-specific blanket rate supplies the only "
                    "absolute velocity scale."
                ),
            },
            "model_conventions": {
                "reference_environment": REFERENCE_ENVIRONMENT.to_dict(),
                "hf_activity_definition": (
                    "ratio to each material preset's reference bath"
                ),
                "product_reference": (
                    "zero product activity; consistent with the refreshed SiN "
                    "bath but only a convention for the SiOCN source"
                ),
                "SiOCN_reference_temperature_K": REFERENCE_TEMPERATURE_K,
                "SiOCN_reference_temperature_origin": (
                    "modelling convention because the source temperature is "
                    "not reported"
                ),
            },
            "uncalibrated_assumptions": {
                "surface_patch_event_rates": asdict(config.assumptions),
                "patch_topology": (
                    "periodic ring of equivalent, liquid-accessible surface "
                    "columns; removal exposes a fresh intact site in that column"
                ),
                "fresh_layer_state": (
                    "surface passivation is reset on removal; persistent wall "
                    "deposit is outside this KMC model"
                ),
                "material_modifier": (
                    "the same dimensionless KMC event model is used for SiN and "
                    "SiOCN; their absolute blanket anchors differ"
                ),
                "SiOCN_temperature_anchor": (
                    "the source does not report liquid temperature; 298.15 K is "
                    "a normalization convention, not a literature-fixed value"
                ),
            },
            "derived_mapping": {
                "formula": (
                    "v_absolute(material, env) = v_blanket(material) * "
                    "mean[q_KMC(env)] / "
                    "mean[q_KMC(T=298.15 K, a_HF=1, a_product=0)]"
                ),
                "q_definition": (
                    "regenerative removal events per second per parallel "
                    "surface column after warmup"
                ),
                "paired_seed_normalization": True,
                "uncertainty_estimator": (
                    "paired bootstrap of the ratio of arithmetic ensemble means"
                ),
                "atomic_length_or_site_volume_required": False,
            },
        },
        "size_audit": size_audit,
        "environment_table": environment_table,
    }


__all__ = [
    "DEFAULT_HF_ACTIVITIES",
    "DEFAULT_MATERIALS",
    "DEFAULT_PRODUCT_ACTIVITIES",
    "DEFAULT_SITE_COUNTS",
    "DEFAULT_TEMPERATURES_K",
    "GRAPH_KMC_VELOCITY_NOTICE",
    "GraphKMCVelocitySweepConfig",
    "NOMINAL_PRESET_BY_MATERIAL",
    "PatchEnvironment",
    "REFERENCE_ENVIRONMENT",
    "SurfacePatchRateAssumptions",
    "build_surface_patch_kmc",
    "run_graph_kmc_velocity_sweep",
]

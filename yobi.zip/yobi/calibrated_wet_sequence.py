"""Blanket-clock-calibrated primary HF through post-HF wet processing.

This module keeps one live graph/continuum state from the exact primary-HF
endpoint and passes it directly into rinse, dry-down and second-WET models.
Saved endpoint masks are never used as restart states.

Three collector branches separate two otherwise-confounded questions:

``all_physical_fixed_inventory``
    Meniscus-migration spatial upper branch. The fixed captured precursor can
    allocate over every physical wall/floor collector.

``endpoint_accessible_fixed_inventory``
    Same captured amount, but allocation is restricted to collectors that are
    liquid-accessible at the primary endpoint. This brackets *location* only;
    it is not a lower bound on total deposit.

``endpoint_accessible_area_scaled``
    An explicit quantity-lower hypothesis in which captured precursor scales
    linearly with the accessible weighted contact fraction. The excluded
    amount is retained as a separate mass-balance term.

All coefficients remain screening assumptions until same-lot blanket,
cross-section and post-HF measurements are fitted.
"""

from __future__ import annotations

import csv
import json
import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np

from attachment_discrimination import (
    _balance,
    _deposit_parameters,
    _deposit_stage,
    _matrix_stage,
    _residue_components,
    _surface_profile,
    post_hf_closure,
)
from literature_parameters import get_literature_preset
from literature_sweep import nominal_preset_names
from persistent_deposit import (
    NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN,
    PersistentDepositPhase2D,
)
from primary_hf_endpoint import (
    BlanketRateInput,
    PrimaryHFEndpointConfig,
    _primary_parameters,
    _process_config,
    literature_blanket_input,
    run_blanket_coupon,
    run_calibrated_primary_hf_to_endpoint,
)
from process_window_sweep import ProcessCaseSpec, _case_objects
from trench_geometry import GEOMETRY_PRESETS
from trench_graph_kmc import (
    SecondWetKMCParameters,
    run_second_wet_stage,
    trench_residue_metrics,
)


SCHEMA_VERSION = "trench-calibrated-wet-sequence/v1"

BRANCH_ALL_PHYSICAL = "all_physical_fixed_inventory"
BRANCH_ALL_PHYSICAL_SCALED = "all_physical_area_scaled_reference"
BRANCH_ACCESSIBLE_FIXED = "endpoint_accessible_fixed_inventory"
BRANCH_ACCESSIBLE_SCALED = "endpoint_accessible_area_scaled"
COLLECTOR_BRANCHES = (
    BRANCH_ALL_PHYSICAL,
    BRANCH_ACCESSIBLE_FIXED,
    BRANCH_ALL_PHYSICAL_SCALED,
    BRANCH_ACCESSIBLE_SCALED,
)

MODEL_NOTICE = (
    "Screening calculation, not a process recipe. Primary-HF time is anchored "
    "to a literature or user blanket WER and stopped at an exact graph-KMC "
    "event. Post-HF product capture, collector accessibility and second-WET "
    "rate laws remain uncalibrated hypotheses."
)


def _positive(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


def _nonnegative(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")


def _unit_fraction(name: str, value: float, *, allow_one: bool = True) -> None:
    upper_ok = float(value) <= 1.0 if allow_one else float(value) < 1.0
    if (
        not math.isfinite(float(value))
        or float(value) < 0.0
        or not upper_ok
    ):
        upper = "]" if allow_one else ")"
        raise ValueError(f"{name} must lie within [0, 1{upper}")


@dataclass(frozen=True)
class CalibratedWetSequenceConfig:
    geometries: tuple[str, ...] = ("10_10_180", "7_7_170")
    presets: tuple[str, ...] = nominal_preset_names()
    scenarios: tuple[str, ...] = (
        "transport_only",
        "passivation_hypothesis",
    )
    replicate_seeds: tuple[int, ...] = (271828, 314159)
    collector_branches: tuple[str, ...] = COLLECTOR_BRANCHES
    primary_target_remaining_fraction: float = 0.01
    grid_spacing_nm: float = 1.7
    reservoir_height_nm: float = 4.0
    lateral_margin_nm: float = 3.0
    solution_temperature_K: float = 298.15
    substrate_temperature_K: float = 298.15
    # Matches PrimaryHFEndpointConfig: a 3x budget right-censored every
    # passivation stratum, which removed the passivation arm from the whole
    # downstream rinse / dry-down / second-WET design.
    maximum_planar_clear_time_multiplier: float = 200.0
    primary_sync_steps: int = 60
    maximum_events: int = 80_000
    parallel_workers: int = 1
    coupon_width_nm: float = 24.0
    coupon_depth_nm: float = 48.0
    coupon_measurement_start_removed_fraction: float = 0.10
    coupon_measurement_end_removed_fraction: float = 0.90
    coupon_maximum_events: int = 20_000
    post_hf_to_dry_window_s: float = 60.0
    rinse_start_delay_s: float = 30.0
    rinse_exchange_rate_s: float = 0.05
    immediate_quench: bool = False
    drying_duration_s: float = 60.0
    drying_rate_s: float = 1.0 / 30.0
    drydown_capture_fraction: float = 0.05
    dry_enabled: bool = True
    wall_pretreatment_multiplier: float = 1.0
    wall_material_selectivity: float = 1.0
    bottom_material_selectivity: float = 1.0
    second_wet_duration_s: float = 30.0
    second_wet_rate_multiplier: float = 0.70
    deposit_reference_dissolution_rate_s: float = 0.025
    surface_profile_bins: int = 24
    blanket_rate_inputs: Mapping[str, BlanketRateInput] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        if not self.geometries or set(self.geometries).difference(
            GEOMETRY_PRESETS
        ):
            raise ValueError("geometries must be a non-empty known selection")
        if len(set(self.geometries)) != len(self.geometries):
            raise ValueError("geometries cannot contain duplicates")
        if not self.presets:
            raise ValueError("presets cannot be empty")
        for preset_id in self.presets:
            get_literature_preset(preset_id)
        if len(set(self.presets)) != len(self.presets):
            raise ValueError("presets cannot contain duplicates")
        known_scenarios = {"transport_only", "passivation_hypothesis"}
        if not self.scenarios or set(self.scenarios).difference(known_scenarios):
            raise ValueError("scenarios must be a non-empty known selection")
        if len(set(self.scenarios)) != len(self.scenarios):
            raise ValueError("scenarios cannot contain duplicates")
        if not self.replicate_seeds or any(
            not isinstance(seed, int) or seed < 0
            for seed in self.replicate_seeds
        ):
            raise ValueError(
                "replicate_seeds must contain non-negative integers"
            )
        if len(set(self.replicate_seeds)) != len(self.replicate_seeds):
            raise ValueError("replicate_seeds cannot contain duplicates")
        if not self.collector_branches or set(
            self.collector_branches
        ).difference(COLLECTOR_BRANCHES):
            raise ValueError(
                "collector_branches must be a non-empty known selection"
            )
        if len(set(self.collector_branches)) != len(
            self.collector_branches
        ):
            raise ValueError("collector_branches cannot contain duplicates")
        _unit_fraction(
            "primary_target_remaining_fraction",
            self.primary_target_remaining_fraction,
            allow_one=False,
        )
        _unit_fraction(
            "coupon_measurement_start_removed_fraction",
            self.coupon_measurement_start_removed_fraction,
            allow_one=False,
        )
        _unit_fraction(
            "coupon_measurement_end_removed_fraction",
            self.coupon_measurement_end_removed_fraction,
            allow_one=False,
        )
        if (
            self.coupon_measurement_start_removed_fraction
            >= self.coupon_measurement_end_removed_fraction
        ):
            raise ValueError("coupon measurement start must be below end")
        for name in (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "solution_temperature_K",
            "substrate_temperature_K",
            "maximum_planar_clear_time_multiplier",
            "coupon_width_nm",
            "coupon_depth_nm",
            "post_hf_to_dry_window_s",
            "drying_duration_s",
            "drying_rate_s",
            "second_wet_duration_s",
            "deposit_reference_dissolution_rate_s",
        ):
            _positive(name, getattr(self, name))
        for name in (
            "lateral_margin_nm",
            "rinse_start_delay_s",
            "rinse_exchange_rate_s",
        ):
            _nonnegative(name, getattr(self, name))
        for name in (
            "drydown_capture_fraction",
        ):
            _unit_fraction(name, getattr(self, name))
        for name in (
            "wall_pretreatment_multiplier",
            "wall_material_selectivity",
            "bottom_material_selectivity",
            "second_wet_rate_multiplier",
        ):
            _positive(name, getattr(self, name))
        for name in (
            "primary_sync_steps",
            "maximum_events",
            "parallel_workers",
            "coupon_maximum_events",
            "surface_profile_bins",
        ):
            if not isinstance(getattr(self, name), int) or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.surface_profile_bins < 4:
            raise ValueError("surface_profile_bins must be at least four")
        unknown_rates = set(self.blanket_rate_inputs).difference(self.presets)
        if unknown_rates:
            raise ValueError(
                "blanket_rate_inputs contain unselected presets: "
                f"{sorted(unknown_rates)}"
            )
        for key, value in self.blanket_rate_inputs.items():
            if key != value.preset_id:
                raise ValueError(
                    "blanket_rate_inputs keys must match preset_id"
                )
        object.__setattr__(self, "geometries", tuple(self.geometries))
        object.__setattr__(self, "presets", tuple(self.presets))
        object.__setattr__(self, "scenarios", tuple(self.scenarios))
        object.__setattr__(
            self, "replicate_seeds", tuple(self.replicate_seeds)
        )
        object.__setattr__(
            self, "collector_branches", tuple(self.collector_branches)
        )

    def blanket_input(self, preset_id: str) -> BlanketRateInput:
        return self.blanket_rate_inputs.get(
            preset_id, literature_blanket_input(preset_id)
        )

    def primary_config(self) -> PrimaryHFEndpointConfig:
        return PrimaryHFEndpointConfig(
            geometries=self.geometries,
            presets=self.presets,
            scenarios=self.scenarios,
            replicate_seeds=self.replicate_seeds,
            target_remaining_fractions=(
                self.primary_target_remaining_fraction,
            ),
            fixed_probe_times_s=(),
            grid_spacing_nm=self.grid_spacing_nm,
            reservoir_height_nm=self.reservoir_height_nm,
            lateral_margin_nm=self.lateral_margin_nm,
            solution_temperature_K=self.solution_temperature_K,
            substrate_temperature_K=self.substrate_temperature_K,
            maximum_planar_clear_time_multiplier=(
                self.maximum_planar_clear_time_multiplier
            ),
            primary_sync_steps=self.primary_sync_steps,
            maximum_events=self.maximum_events,
            parallel_workers=1,
            coupon_width_nm=self.coupon_width_nm,
            coupon_depth_nm=self.coupon_depth_nm,
            coupon_measurement_start_removed_fraction=(
                self.coupon_measurement_start_removed_fraction
            ),
            coupon_measurement_end_removed_fraction=(
                self.coupon_measurement_end_removed_fraction
            ),
            coupon_maximum_events=self.coupon_maximum_events,
            trace_points=20,
            blanket_rate_inputs=self.blanket_rate_inputs,
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for key in (
            "geometries",
            "presets",
            "scenarios",
            "replicate_seeds",
            "collector_branches",
        ):
            result[key] = list(result[key])
        result["blanket_rate_inputs"] = {
            key: value.to_dict()
            for key, value in self.blanket_rate_inputs.items()
        }
        return result


@dataclass(frozen=True)
class _SequenceJob:
    order: int
    geometry_id: str
    preset_id: str
    scenario: str
    replicate_index: int
    seed: int
    coupon: Mapping[str, object]
    config: CalibratedWetSequenceConfig


def _matrix_mask(graph: object, layout: object) -> list[list[int]]:
    grid = layout.grid
    remaining = np.zeros(grid.shape, dtype=np.uint8)
    for site_id in layout.matrix_site_ids:
        if graph.sites[site_id].state == "removed":
            continue
        row, column = layout.cell_by_site[site_id]
        remaining[row, column] = 1
    return remaining.tolist()


def _collector_accessibility(
    phase: PersistentDepositPhase2D,
    access_mask: np.ndarray | None,
) -> dict[str, object]:
    enabled = phase.collector_mask(access_mask)
    all_enabled = phase.collector_mask()
    wall_mask = phase.collector_mask(
        access_mask, include_bottom=False
    )
    bottom_mask = phase.collector_mask(
        access_mask, include_wall=False
    )
    all_wall = phase.collector_mask(include_bottom=False)
    all_bottom = phase.collector_mask(include_wall=False)
    wall_length = float(np.sum(phase.wall_contact_length_nm[wall_mask]))
    bottom_length = float(
        np.sum(phase.bottom_contact_length_nm[bottom_mask])
    )
    all_wall_length = float(
        np.sum(phase.wall_contact_length_nm[all_wall])
    )
    all_bottom_length = float(
        np.sum(phase.bottom_contact_length_nm[all_bottom])
    )
    weighted = (
        phase.parameters.wall_affinity * phase.wall_contact_length_nm
        + phase.parameters.bottom_affinity * phase.bottom_contact_length_nm
    )
    enabled_weight = float(np.sum(weighted[enabled]))
    all_weight = float(np.sum(weighted[all_enabled]))
    weighted_fraction = enabled_weight / all_weight if all_weight else 0.0
    return {
        "enabled_collector_mask": enabled.astype(np.uint8).tolist(),
        "enabled_collector_cell_count": int(np.count_nonzero(enabled)),
        "all_collector_cell_count": int(np.count_nonzero(all_enabled)),
        "accessible_wall_length_nm": wall_length,
        "accessible_bottom_length_nm": bottom_length,
        "accessible_total_length_nm": wall_length + bottom_length,
        "all_wall_length_nm": all_wall_length,
        "all_bottom_length_nm": all_bottom_length,
        "all_total_length_nm": all_wall_length + all_bottom_length,
        "accessible_wall_length_fraction": (
            wall_length / all_wall_length if all_wall_length else 0.0
        ),
        "accessible_bottom_length_fraction": (
            bottom_length / all_bottom_length if all_bottom_length else 0.0
        ),
        "accessible_total_length_fraction": (
            (wall_length + bottom_length)
            / (all_wall_length + all_bottom_length)
            if all_wall_length + all_bottom_length
            else 0.0
        ),
        "accessible_weighted_contact_fraction": weighted_fraction,
    }


def _enabled_area_normalization(
    phase: PersistentDepositPhase2D,
    accessibility: Mapping[str, object],
) -> dict[str, object]:
    wall_area = float(accessibility["accessible_wall_length_nm"])
    bottom_area = float(accessibility["accessible_bottom_length_nm"])
    total_area = wall_area + bottom_area
    wall_inventory = float(np.sum(phase.wall_inventory_native))
    bottom_inventory = float(np.sum(phase.bottom_inventory_native))
    total_inventory = wall_inventory + bottom_inventory
    return {
        "basis": "enabled_contact_area_for_1nm_out_of_plane_span",
        "wall_enabled_area_nm2": wall_area,
        "bottom_enabled_area_nm2": bottom_area,
        "total_enabled_area_nm2": total_area,
        "wall_inventory_density_native_per_enabled_nm2": (
            wall_inventory / wall_area if wall_area else 0.0
        ),
        "bottom_inventory_density_native_per_enabled_nm2": (
            bottom_inventory / bottom_area if bottom_area else 0.0
        ),
        "total_inventory_density_native_per_enabled_nm2": (
            total_inventory / total_area if total_area else 0.0
        ),
        "wall_areal_inventory_mol_m2_enabled": (
            wall_inventory / wall_area * 1.0e-9 if wall_area else 0.0
        ),
        "bottom_areal_inventory_mol_m2_enabled": (
            bottom_inventory / bottom_area * 1.0e-9
            if bottom_area
            else 0.0
        ),
        "total_areal_inventory_mol_m2_enabled": (
            total_inventory / total_area * 1.0e-9
            if total_area
            else 0.0
        ),
    }


def _branch_definition(
    branch_id: str,
    endpoint_liquid_mask: np.ndarray,
) -> tuple[str, str, np.ndarray | None]:
    if branch_id == BRANCH_ALL_PHYSICAL:
        return (
            "all_physical_upper",
            "fixed_inventory",
            None,
        )
    if branch_id == BRANCH_ALL_PHYSICAL_SCALED:
        return (
            "all_physical_upper",
            "accessible_area_scaled",
            None,
        )
    if branch_id == BRANCH_ACCESSIBLE_FIXED:
        return (
            "endpoint_liquid_accessible",
            "fixed_inventory",
            endpoint_liquid_mask,
        )
    if branch_id == BRANCH_ACCESSIBLE_SCALED:
        return (
            "endpoint_liquid_accessible",
            "accessible_area_scaled",
            endpoint_liquid_mask,
        )
    raise ValueError(f"unknown collector branch {branch_id!r}")


def _cumulative_time_uncertainty(
    endpoint: Mapping[str, object],
    offset_s: float,
) -> dict[str, object] | None:
    interval = endpoint.get("blanket_rate_uncertainty_interval")
    if not isinstance(interval, Mapping):
        return None
    lower = interval.get("lower_physical_time_s")
    upper = interval.get("upper_physical_time_s")
    if lower is None or upper is None:
        return None
    return {
        "basis": (
            "primary_blanket_rate_clock_interval_shifted_by_fixed_"
            "post_HF_duration"
        ),
        "lower_cumulative_physical_time_s": float(lower) + offset_s,
        "upper_cumulative_physical_time_s": float(upper) + offset_s,
        "post_hf_duration_uncertainty_included": False,
    }


def _run_branch(
    *,
    job: _SequenceJob,
    handoff: object,
    primary_summary: Mapping[str, object],
    final_matrix_summary: Mapping[str, object],
    second_wet_clock: Mapping[str, object],
    second_wet_matrix: Mapping[str, object],
    closure: Mapping[str, object],
    branch_id: str,
) -> dict[str, object]:
    config = job.config
    outcome = handoff.outcome
    grid = outcome.layout.grid
    wall_weight = (
        config.wall_pretreatment_multiplier
        * config.wall_material_selectivity
    )
    bottom_weight = config.bottom_material_selectivity
    deposit_parameters, yield_value, yield_basis = _deposit_parameters(
        job.preset_id,
        wall_weight,
        bottom_weight,
    )
    phase = PersistentDepositPhase2D(grid, deposit_parameters)
    collector_basis, capture_policy, access_mask = _branch_definition(
        branch_id,
        np.asarray(outcome.final_frame.liquid_mask, dtype=bool),
    )
    accessibility = _collector_accessibility(phase, access_mask)
    base_captured = float(
        closure["captured_precursor_inventory_native"]
    )
    if capture_policy == "accessible_area_scaled":
        capture_scale = float(
            accessibility["accessible_weighted_contact_fraction"]
        )
    else:
        capture_scale = 1.0
    effective_captured = base_captured * capture_scale
    accessibility_excluded = max(0.0, base_captured - effective_captured)

    zero_deposit = _deposit_stage(phase)
    formation = phase.precipitate_during_drydown(
        np.zeros(grid.shape, dtype=float),
        grid.cavity_mask,
        solute_retention_fraction=0.0,
        liquid_retention_fraction=0.0,
        additional_trapped_inventory_native=effective_captured,
        collector_access_mask=access_mask,
    )
    dry_stage_deposit = _deposit_stage(phase)
    dry_profile = _surface_profile(phase, config.surface_profile_bins)
    dry_enabled_normalization = _enabled_area_normalization(
        phase, accessibility
    )
    dry_diagnostics = dry_stage_deposit["deposit_diagnostics"]
    assert isinstance(dry_diagnostics, Mapping)
    attached = float(dry_diagnostics["total_inventory_native"])
    captured_but_not_deposited = max(0.0, effective_captured - attached)
    dry_wall_thickness = phase.wall_thickness_nm.copy()
    dry_bottom_thickness = phase.bottom_thickness_nm.copy()

    dissolution_rate = (
        config.deposit_reference_dissolution_rate_s
        * config.second_wet_rate_multiplier
    )
    dissolution = phase.dissolve(
        config.second_wet_duration_s,
        wall_rate_s=dissolution_rate,
        bottom_rate_s=dissolution_rate,
    )
    second_stage_deposit = _deposit_stage(phase)
    second_profile = _surface_profile(phase, config.surface_profile_bins)
    second_enabled_normalization = _enabled_area_normalization(
        phase, accessibility
    )
    second_diagnostics = second_stage_deposit["deposit_diagnostics"]
    assert isinstance(second_diagnostics, Mapping)
    after_second = float(second_diagnostics["total_inventory_native"])

    generated_inventory = float(
        handoff.product_inventory[
            "cumulative_generated_si_equivalent_inventory_native"
        ]
    )
    hf_balance = _balance(
        generated_inventory,
        {"model_post_hf_pool": generated_inventory},
    )
    rinse_balance = _balance(
        generated_inventory,
        {
            "removed_by_rinse": float(
                closure["rinse_removed_inventory_native"]
            ),
            "soluble_residual": float(
                closure["soluble_residual_inventory_native"]
            ),
        },
    )
    dry_balance = _balance(
        float(closure["soluble_residual_inventory_native"]),
        {
            "attached_deposit": attached,
            "captured_but_not_deposited_by_yield": (
                captured_but_not_deposited
            ),
            "accessibility_excluded_capture": accessibility_excluded,
            "uncaptured_soluble": float(
                closure["uncaptured_soluble_inventory_native"]
            ),
        },
    )
    second_balance = _balance(
        attached,
        {
            "deposit_removed_by_second_wet": float(
                dissolution.removed_inventory_native
            ),
            "deposit_after_second_wet": after_second,
        },
    )

    initial_matrix_site_count = int(primary_summary["matrix_site_count"])
    cell_area_nm2 = float(grid.cell_area_nm2)
    material = get_literature_preset(job.preset_id).material
    component_common = {
        "material": material,
        "deposit_species_name": deposit_parameters.species_name,
        "initial_matrix_site_count": initial_matrix_site_count,
        "cell_area_nm2": cell_area_nm2,
    }
    zero_diagnostics = zero_deposit["deposit_diagnostics"]
    assert isinstance(zero_diagnostics, Mapping)
    zero_components = _residue_components(
        primary_summary,
        zero_diagnostics,
        **component_common,
    )
    dry_components = _residue_components(
        primary_summary,
        dry_diagnostics,
        **component_common,
    )
    second_components = _residue_components(
        final_matrix_summary,
        second_diagnostics,
        **component_common,
    )

    endpoint_time = float(handoff.endpoint["endpoint_physical_time_s"])
    rinse_time = endpoint_time + config.post_hf_to_dry_window_s
    dry_time = rinse_time + config.drying_duration_s
    second_time = dry_time + config.second_wet_duration_s
    rinse_offset = config.post_hf_to_dry_window_s
    dry_offset = rinse_offset + config.drying_duration_s
    second_offset = dry_offset + config.second_wet_duration_s
    common_geometry = {
        "x_nm": grid.lateral_nm.tolist(),
        "depth_nm": grid.depth_nm.tolist(),
        "cavity_mask": grid.cavity_mask.astype(np.uint8).tolist(),
    }
    primary_mask = _matrix_mask(outcome.graph, outcome.layout)
    second_mask = second_wet_matrix[
        "remaining_original_gap_fill_mask"
    ]
    zero_thickness = np.zeros(grid.shape, dtype=float).tolist()
    primary_spatial = {
        **common_geometry,
        "remaining_original_gap_fill_mask": primary_mask,
        "wall_deposit_thickness_nm": zero_thickness,
        "bottom_deposit_thickness_nm": zero_thickness,
    }
    dry_spatial = {
        **common_geometry,
        "remaining_original_gap_fill_mask": primary_mask,
        "wall_deposit_thickness_nm": dry_wall_thickness.tolist(),
        "bottom_deposit_thickness_nm": dry_bottom_thickness.tolist(),
    }
    second_spatial = {
        **common_geometry,
        "remaining_original_gap_fill_mask": second_mask,
        "wall_deposit_thickness_nm": phase.wall_thickness_nm.tolist(),
        "bottom_deposit_thickness_nm": (
            phase.bottom_thickness_nm.tolist()
        ),
    }
    stages = {
        "hf_endpoint": {
            "cumulative_physical_time_s": endpoint_time,
            "cumulative_process_time_s": endpoint_time,
            "cumulative_time_uncertainty": _cumulative_time_uncertainty(
                handoff.endpoint, 0.0
            ),
            "matrix": _matrix_stage(primary_summary),
            **zero_deposit,
            "residue_components": zero_components,
            "mass_balance": hf_balance,
            "spatial": primary_spatial,
            "remaining_original_gap_fill_mask": primary_mask,
        },
        "rinse_endpoint": {
            "cumulative_physical_time_s": rinse_time,
            "cumulative_process_time_s": rinse_time,
            "cumulative_time_uncertainty": _cumulative_time_uncertainty(
                handoff.endpoint, rinse_offset
            ),
            "matrix": _matrix_stage(primary_summary),
            **zero_deposit,
            "residue_components": zero_components,
            "mass_balance": rinse_balance,
            "spatial": primary_spatial,
            "remaining_original_gap_fill_mask": primary_mask,
        },
        "drydown_endpoint": {
            "cumulative_physical_time_s": dry_time,
            "cumulative_process_time_s": dry_time,
            "cumulative_time_uncertainty": _cumulative_time_uncertainty(
                handoff.endpoint, dry_offset
            ),
            "matrix": _matrix_stage(primary_summary),
            **dry_stage_deposit,
            "enabled_area_normalization": dry_enabled_normalization,
            "residue_components": dry_components,
            "mass_balance": dry_balance,
            "spatial": dry_spatial,
            "remaining_original_gap_fill_mask": primary_mask,
            "wall_deposit_thickness_nm": dry_wall_thickness.tolist(),
            "bottom_deposit_thickness_nm": dry_bottom_thickness.tolist(),
        },
        "second_wet_endpoint": {
            "cumulative_physical_time_s": second_time,
            "cumulative_process_time_s": second_time,
            "cumulative_time_uncertainty": _cumulative_time_uncertainty(
                handoff.endpoint, second_offset
            ),
            "matrix": _matrix_stage(final_matrix_summary),
            **second_stage_deposit,
            "enabled_area_normalization": second_enabled_normalization,
            "residue_components": second_components,
            "mass_balance": second_balance,
            "spatial": second_spatial,
            "remaining_original_gap_fill_mask": second_mask,
            "wall_deposit_thickness_nm": (
                phase.wall_thickness_nm.tolist()
            ),
            "bottom_deposit_thickness_nm": (
                phase.bottom_thickness_nm.tolist()
            ),
        },
    }
    primary_case_id = (
        f"{job.geometry_id}__{job.preset_id}__{job.scenario}__"
        f"r{job.replicate_index}"
    )
    paired_branch_id = f"{primary_case_id}__{capture_policy}"
    unassigned_fraction = (
        accessibility_excluded / base_captured if base_captured else 0.0
    )
    primary_endpoint_payload = {
        **dict(handoff.endpoint),
        "validity": dict(handoff.validity),
        "clock_calibration": dict(handoff.clock_calibration),
        "product_inventory": dict(handoff.product_inventory),
        "planar_reference": dict(handoff.planar_reference),
        "snapshot": primary_spatial,
    }
    return {
        "case_id": (
            f"{job.geometry_id}__{job.preset_id}__{job.scenario}__"
            f"r{job.replicate_index}__{branch_id}"
        ),
        "status": "ok",
        "stratum_order": job.order,
        "geometry_id": job.geometry_id,
        "preset_id": job.preset_id,
        "material": material,
        "scenario": job.scenario,
        "replicate_index": job.replicate_index,
        "seed": job.seed,
        "stratum": {
            "geometry_id": job.geometry_id,
            "preset_id": job.preset_id,
            "material": material,
            "scenario": job.scenario,
            "replicate_index": job.replicate_index,
            "seed": job.seed,
        },
        "collector_branch_id": branch_id,
        "collector_branch": {
            "paired_branch_id": paired_branch_id,
            "basis": collector_basis,
            "collector_basis": collector_basis,
            "capture_policy": capture_policy,
            "eligible_collector_mask": accessibility[
                "enabled_collector_mask"
            ],
            "eligible_wall_contact_fraction": accessibility[
                "accessible_wall_length_fraction"
            ],
            "eligible_bottom_contact_fraction": accessibility[
                "accessible_bottom_length_fraction"
            ],
            "unassigned_precursor_fraction": unassigned_fraction,
            "same_primary_state_as_paired_branches": True,
            "base_captured_precursor_inventory_native": base_captured,
            "capture_scale": capture_scale,
            "effective_captured_precursor_inventory_native": (
                effective_captured
            ),
            "accessibility_excluded_capture_inventory_native": (
                accessibility_excluded
            ),
            **accessibility,
        },
        "lineage": {
            "primary_case_id": primary_case_id,
            "target_remaining_fraction": (
                config.primary_target_remaining_fraction
            ),
            "removed_count_at_endpoint": handoff.endpoint[
                "removed_count_at_endpoint"
            ],
            "seed": job.seed,
            "primary_target_remaining_fraction": (
                config.primary_target_remaining_fraction
            ),
            "primary_removed_count_at_endpoint": handoff.endpoint[
                "removed_count_at_endpoint"
            ],
            "primary_seed": job.seed,
            "restart_state_basis": "live_in_memory_TrenchKMCOutcome",
        },
        "primary_endpoint": primary_endpoint_payload,
        "primary_handoff": handoff.serializable_summary(),
        "post_hf_closure": dict(closure),
        "formation": formation.to_dict(),
        "second_wet_clock": dict(second_wet_clock),
        "second_wet_matrix": dict(second_wet_matrix),
        "stages": stages,
        "surface_profiles": {
            "drydown_endpoint": dry_profile,
            "second_wet_endpoint": second_profile,
        },
        "geometry_fields": common_geometry,
        "quality": {
            "all_stage_mass_balances_closed": all(
                bool(stage["mass_balance"]["closed"])
                for stage in stages.values()
            ),
            "primary_downstream_eligible": True,
            "primary_endpoint_observed": True,
            "second_wet_clock_independently_calibrated": False,
        },
        "final_metrics": {
            "unassigned_precursor_fraction": unassigned_fraction,
            "drydown_total_deposit_inventory_native": attached,
            "second_wet_total_deposit_inventory_native": after_second,
            "drydown_total_deposit_mol_per_nm_span": (
                attached * NATIVE_INVENTORY_TO_MOL_PER_NM_SPAN
            ),
            "second_wet_matrix_remaining_fraction": float(
                final_matrix_summary["remaining_fraction"]
            ),
            "drydown_combined_residue_fraction": float(
                dry_components["combined"][
                    "fraction_of_discrete_initial_gap_fill_area"
                ]
            ),
            "second_wet_combined_residue_fraction": float(
                second_components["combined"][
                    "fraction_of_discrete_initial_gap_fill_area"
                ]
            ),
        },
    }


def _run_stratum(job: _SequenceJob) -> dict[str, object]:
    try:
        primary_config = job.config.primary_config()
        handoff = run_calibrated_primary_hf_to_endpoint(
            geometry_id=job.geometry_id,
            preset_id=job.preset_id,
            scenario=job.scenario,
            replicate_index=job.replicate_index,
            seed=job.seed,
            config=primary_config,
            coupon=job.coupon,
            target_remaining_fraction=(
                job.config.primary_target_remaining_fraction
            ),
        )
        primary_summary = trench_residue_metrics(
            handoff.outcome.graph,
            handoff.outcome.layout,
        )
        base = {
            "stratum_order": job.order,
            "stratum_id": (
                f"{job.geometry_id}__{job.preset_id}__{job.scenario}__"
                f"r{job.replicate_index}"
            ),
            "geometry_id": job.geometry_id,
            "preset_id": job.preset_id,
            "material": get_literature_preset(job.preset_id).material,
            "scenario": job.scenario,
            "replicate_index": job.replicate_index,
            "seed": job.seed,
            "primary_endpoint": handoff.serializable_summary(),
        }
        if not bool(handoff.validity["downstream_eligible"]):
            return {
                **base,
                "status": "skipped",
                "downstream_status": "skipped",
                "skip_reason": (
                    f"primary_{handoff.validity['level']}_"
                    f"{handoff.endpoint['observation_status']}"
                ),
                "cases": [],
            }

        clock_scale = float(
            handoff.clock_calibration[
                "physical_seconds_per_model_second"
            ]
        )
        native_site_rate = float(
            handoff.model_parameters[
                "derived_conditions_before_clock_calibration"
            ]["nominal_site_rate_s"]
        )
        physical_matrix_rate = native_site_rate / clock_scale
        second = run_second_wet_stage(
            handoff.outcome.graph,
            handoff.outcome.layout,
            parameters=SecondWetKMCParameters(
                duration_s=job.config.second_wet_duration_s,
                common_rate_multiplier=(
                    job.config.second_wet_rate_multiplier
                ),
                matrix_removal_rate_s=physical_matrix_rate,
                deposit_dissolution_rate_s=0.0,
            ),
            seed=job.seed + 1_000_003,
        )
        final_matrix_summary = trench_residue_metrics(
            second.graph,
            handoff.outcome.layout,
        )
        second_wet_clock = {
            "clock_basis": "primary_blanket_clock_reused_provisionally",
            "physical_duration_s": job.config.second_wet_duration_s,
            "native_primary_site_rate_per_model_s": native_site_rate,
            "physical_matrix_rate_per_s": physical_matrix_rate,
            "common_rate_multiplier": (
                job.config.second_wet_rate_multiplier
            ),
            "second_wet_independently_calibrated": False,
            "source_graph_time_excluded_from_stage_clock": True,
        }
        second_wet_matrix = {
            "stop_reason": second.stop_reason,
            "physical_duration_s": second.duration_s,
            "event_count": second.event_count,
            "before_metrics": dict(second.before_metrics),
            "after_metrics": dict(second.after_metrics),
            "remaining_original_gap_fill_mask": _matrix_mask(
                second.graph, handoff.outcome.layout
            ),
        }
        generated = float(
            handoff.product_inventory[
                "cumulative_generated_si_equivalent_inventory_native"
            ]
        )
        closure = post_hf_closure(
            generated,
            post_hf_to_dry_window_s=(
                job.config.post_hf_to_dry_window_s
            ),
            rinse_start_delay_s=job.config.rinse_start_delay_s,
            rinse_exchange_rate_s=job.config.rinse_exchange_rate_s,
            immediate_quench=job.config.immediate_quench,
            dry_enabled=job.config.dry_enabled,
            drying_rate_s=job.config.drying_rate_s,
            drying_duration_s=job.config.drying_duration_s,
            drydown_capture_fraction=(
                job.config.drydown_capture_fraction
            ),
        )
        cases = [
            _run_branch(
                job=job,
                handoff=handoff,
                primary_summary=primary_summary,
                final_matrix_summary=final_matrix_summary,
                second_wet_clock=second_wet_clock,
                second_wet_matrix=second_wet_matrix,
                closure=closure,
                branch_id=branch_id,
            )
            for branch_id in job.config.collector_branches
        ]
        return {
            **base,
            "status": "ok",
            "downstream_status": "executed",
            "skip_reason": None,
            "cases": cases,
        }
    except Exception as exc:
        return {
            "stratum_order": job.order,
            "stratum_id": (
                f"{job.geometry_id}__{job.preset_id}__{job.scenario}__"
                f"r{job.replicate_index}"
            ),
            "geometry_id": job.geometry_id,
            "preset_id": job.preset_id,
            "material": get_literature_preset(job.preset_id).material,
            "scenario": job.scenario,
            "replicate_index": job.replicate_index,
            "seed": job.seed,
            "status": "failed",
            "downstream_status": "failed",
            "skip_reason": None,
            "error_type": type(exc).__name__,
            "error_message": str(exc),
            "cases": [],
        }


def _worker_initializer() -> None:
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = "1"
    try:
        from threadpoolctl import threadpool_limits

        threadpool_limits(1)
    except ImportError:
        pass


def _execute(
    jobs: Sequence[_SequenceJob], workers: int
) -> list[dict[str, object]]:
    if workers == 1:
        return [_run_stratum(job) for job in jobs]
    with ProcessPoolExecutor(
        max_workers=min(workers, len(jobs)),
        initializer=_worker_initializer,
    ) as executor:
        chunksize = max(1, len(jobs) // max(1, workers * 8))
        return list(executor.map(_run_stratum, jobs, chunksize=chunksize))


def _summary(values: Iterable[float]) -> dict[str, float | int | None]:
    array = np.asarray(list(values), dtype=float)
    if array.size == 0:
        return {
            "count": 0,
            "median": None,
            "minimum": None,
            "maximum": None,
        }
    return {
        "count": int(array.size),
        "median": float(np.median(array)),
        "minimum": float(np.min(array)),
        "maximum": float(np.max(array)),
    }


def _paired_contrasts(
    cases: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    result = []
    stratum_ids = list(
        dict.fromkeys(
            str(case["lineage"]["primary_case_id"])
            for case in cases
            if case.get("status") == "ok"
        )
    )
    for stratum_id in stratum_ids:
        subset = {
            str(case["collector_branch_id"]): case
            for case in cases
            if case.get("status") == "ok"
            and str(case["lineage"]["primary_case_id"]) == stratum_id
        }
        upper = subset.get(BRANCH_ALL_PHYSICAL)
        fixed = subset.get(BRANCH_ACCESSIBLE_FIXED)
        scaled = subset.get(BRANCH_ACCESSIBLE_SCALED)
        if upper is None:
            continue
        upper_dry = float(
            upper["final_metrics"][
                "drydown_total_deposit_inventory_native"
            ]
        )
        row: dict[str, object] = {
            "primary_case_id": stratum_id,
            "geometry_id": upper["geometry_id"],
            "preset_id": upper["preset_id"],
            "material": upper["material"],
            "scenario": upper["scenario"],
            "replicate_index": upper["replicate_index"],
            "seed": upper["seed"],
            "upper_drydown_inventory_native": upper_dry,
        }
        if fixed is not None:
            fixed_dry = float(
                fixed["final_metrics"][
                    "drydown_total_deposit_inventory_native"
                ]
            )
            row.update(
                {
                    "fixed_inventory_accessible_drydown_inventory_native": (
                        fixed_dry
                    ),
                    "fixed_inventory_mass_match_absolute_error": abs(
                        fixed_dry - upper_dry
                    ),
                    "fixed_inventory_is_spatial_only_comparison": True,
                }
            )
        if scaled is not None:
            scaled_dry = float(
                scaled["final_metrics"][
                    "drydown_total_deposit_inventory_native"
                ]
            )
            row.update(
                {
                    "area_scaled_lower_drydown_inventory_native": scaled_dry,
                    "area_scaled_lower_to_upper_inventory_ratio": (
                        scaled_dry / upper_dry if upper_dry else 0.0
                    ),
                    "accessible_weighted_contact_fraction": scaled[
                        "collector_branch"
                    ]["accessible_weighted_contact_fraction"],
                }
            )
        result.append(row)
    return result


def _aggregates(
    cases: Sequence[Mapping[str, object]],
    config: CalibratedWetSequenceConfig,
) -> list[dict[str, object]]:
    rows = []
    for geometry_id in config.geometries:
        for preset_id in config.presets:
            for scenario in config.scenarios:
                for branch_id in config.collector_branches:
                    subset = [
                        case
                        for case in cases
                        if case.get("status") == "ok"
                        and case.get("geometry_id") == geometry_id
                        and case.get("preset_id") == preset_id
                        and case.get("scenario") == scenario
                        and case.get("collector_branch_id") == branch_id
                    ]
                    rows.append(
                        {
                            "geometry_id": geometry_id,
                            "preset_id": preset_id,
                            "material": get_literature_preset(
                                preset_id
                            ).material,
                            "scenario": scenario,
                            "collector_branch_id": branch_id,
                            "successful_replicates": len(subset),
                            "drydown_total_deposit_inventory_native": _summary(
                                float(
                                    case["final_metrics"][
                                        "drydown_total_deposit_inventory_native"
                                    ]
                                )
                                for case in subset
                            ),
                            "second_wet_total_deposit_inventory_native": _summary(
                                float(
                                    case["final_metrics"][
                                        "second_wet_total_deposit_inventory_native"
                                    ]
                                )
                                for case in subset
                            ),
                            "drydown_combined_residue_fraction": _summary(
                                float(
                                    case["final_metrics"][
                                        "drydown_combined_residue_fraction"
                                    ]
                                )
                                for case in subset
                            ),
                            "second_wet_combined_residue_fraction": _summary(
                                float(
                                    case["final_metrics"][
                                        "second_wet_combined_residue_fraction"
                                    ]
                                )
                                for case in subset
                            ),
                            "accessible_weighted_contact_fraction": _summary(
                                float(
                                    case["collector_branch"][
                                        "accessible_weighted_contact_fraction"
                                    ]
                                )
                                for case in subset
                            ),
                        }
                    )
    return rows


def run_calibrated_wet_sequence(
    config: CalibratedWetSequenceConfig = CalibratedWetSequenceConfig(),
) -> dict[str, object]:
    """Run coupons, exact primary endpoints and all post-HF branches."""

    primary_config = config.primary_config()
    coupons: dict[tuple[str, int], dict[str, object]] = {}
    coupon_failures: list[dict[str, object]] = []
    placeholder_config = _process_config(primary_config, 1.0)
    for preset_index, preset_id in enumerate(config.presets):
        preset = get_literature_preset(preset_id)
        blanket_input = config.blanket_input(preset_id)
        for replicate_index, base_seed in enumerate(config.replicate_seeds):
            seed = int(base_seed) + 100_003 * preset_index
            spec = ProcessCaseSpec(
                order=0,
                case_group="calibrated_sequence_coupon",
                design_index=0,
                geometry_id=config.geometries[0],
                preset_id=preset_id,
                replicate_index=replicate_index,
                seed=seed,
                parameters=_primary_parameters(primary_config),
            )
            try:
                _, _, _, kinetics, _, _ = _case_objects(
                    spec, placeholder_config
                )
                coupons[(preset_id, replicate_index)] = run_blanket_coupon(
                    preset,
                    kinetics,
                    seed=seed,
                    spacing_nm=config.grid_spacing_nm,
                    width_nm=config.coupon_width_nm,
                    depth_nm=config.coupon_depth_nm,
                    start_removed_fraction=(
                        config.coupon_measurement_start_removed_fraction
                    ),
                    end_removed_fraction=(
                        config.coupon_measurement_end_removed_fraction
                    ),
                    maximum_events=config.coupon_maximum_events,
                    environment_temperature_K=(
                        blanket_input.normalization_temperature_K
                    ),
                )
            except Exception as exc:
                coupon_failures.append(
                    {
                        "preset_id": preset_id,
                        "replicate_index": replicate_index,
                        "seed": seed,
                        "error_type": type(exc).__name__,
                        "error_message": str(exc),
                    }
                )

    jobs = []
    for geometry_id in config.geometries:
        for preset_index, preset_id in enumerate(config.presets):
            for scenario in config.scenarios:
                for replicate_index, base_seed in enumerate(
                    config.replicate_seeds
                ):
                    coupon = coupons.get((preset_id, replicate_index))
                    if coupon is None:
                        continue
                    jobs.append(
                        _SequenceJob(
                            order=len(jobs),
                            geometry_id=geometry_id,
                            preset_id=preset_id,
                            scenario=scenario,
                            replicate_index=replicate_index,
                            seed=int(base_seed) + 100_003 * preset_index,
                            coupon=coupon,
                            config=config,
                        )
                    )
    strata = _execute(jobs, config.parallel_workers) if jobs else []
    strata.sort(key=lambda item: int(item["stratum_order"]))
    cases = [
        case
        for stratum in strata
        for case in stratum.get("cases", [])
        if isinstance(case, Mapping)
    ]
    failed_strata = [
        item for item in strata if item.get("status") == "failed"
    ]
    skipped_strata = [
        item for item in strata if item.get("status") == "skipped"
    ]
    executed_strata = [
        item for item in strata if item.get("status") == "ok"
    ]
    successful_cases = [
        case for case in cases if case.get("status") == "ok"
    ]
    expected_strata = (
        len(config.geometries)
        * len(config.presets)
        * len(config.scenarios)
        * len(config.replicate_seeds)
    )
    payload = {
        "schema_version": SCHEMA_VERSION,
        "model_name": (
            "blanket-calibrated primary HF to stage-resolved wet sequence"
        ),
        "notice": MODEL_NOTICE,
        "config": config.to_dict(),
        "blanket_inputs": {
            preset_id: config.blanket_input(preset_id).to_dict()
            for preset_id in config.presets
        },
        "coupon_calibrations": [
            coupons[key] for key in sorted(coupons)
        ],
        "coupon_failures": coupon_failures,
        "strata": strata,
        "cases": cases,
        "representative_pair_id": next(
            (
                str(case["collector_branch"]["paired_branch_id"])
                for case in cases
                if case.get("collector_branch_id")
                == BRANCH_ALL_PHYSICAL
            ),
            None,
        ),
        "paired_branch_contrasts": _paired_contrasts(cases),
        "aggregates": _aggregates(cases, config),
        "quality_summary": {
            "expected_coupon_runs": (
                len(config.presets) * len(config.replicate_seeds)
            ),
            "successful_coupon_runs": len(coupons),
            "failed_coupon_runs": len(coupon_failures),
            "expected_primary_strata": expected_strata,
            "requested_primary_strata_after_coupon_failures": len(jobs),
            "executed_downstream_strata": len(executed_strata),
            "skipped_censored_strata": len(skipped_strata),
            "failed_primary_strata": len(failed_strata),
            "expected_branch_cases_if_all_endpoints_observed": (
                expected_strata * len(config.collector_branches)
            ),
            "successful_branch_cases": len(successful_cases),
            "mass_balance_failure_cases": sum(
                not bool(
                    case["quality"]["all_stage_mass_balances_closed"]
                )
                for case in successful_cases
            ),
            "fixed_inventory_pair_mismatch_count": sum(
                float(
                    item.get(
                        "fixed_inventory_mass_match_absolute_error", 0.0
                    )
                )
                > 1.0e-10
                * max(
                    1.0,
                    abs(
                        float(
                            item.get(
                                "upper_drydown_inventory_native", 0.0
                            )
                        )
                    ),
                )
                for item in _paired_contrasts(cases)
            ),
            "skipped_stratum_ids": [
                str(item["stratum_id"]) for item in skipped_strata
            ],
            "failed_stratum_ids": [
                str(item["stratum_id"]) for item in failed_strata
            ],
        },
        "parallel_execution": {
            "backend": "ProcessPoolExecutor",
            "workers": config.parallel_workers,
            "case_order_preserved": True,
            "worker_numeric_thread_limit_requested": 1,
        },
        "model_limitations": {
            "primary_clock": (
                "Absolute primary time follows the supplied blanket WER. "
                "The graph supplies only relative transport/passivation."
            ),
            "restart_state": (
                "Post-HF stages use the live in-memory endpoint outcome. "
                "Serialized masks are visualization-only and not restartable."
            ),
            "product_pool": (
                "Dry-down uses cumulative generated Si-equivalent product as "
                "an upper-bound rinseable pool. The instantaneous endpoint "
                "quasi-steady field is diagnostic only and is not added."
            ),
            "collector_fixed_inventory": (
                "Restricting collectors while keeping captured inventory "
                "fixed changes allocation and local density, not total mass."
            ),
            "collector_area_scaled": (
                "The quantity-lower branch assumes capture scales linearly "
                "with accessible affinity-weighted contact. This is an "
                "explicit uncalibrated hypothesis, not a theorem."
            ),
            "second_wet_clock": (
                "The primary blanket clock is provisionally reused for graph "
                "matrix removal. A second-WET-specific blanket rate has not "
                "been fitted."
            ),
            "deposit_identity": (
                "SiN uses an AFS-like proxy. The persistent SiOCN species and "
                "its solubility/dissolution law remain unverified."
            ),
            "recipe_boundary": (
                "No Si/liner loss, CD loss, roughness, detection threshold or "
                "same-lot trench cross-section fit is included."
            ),
        },
        "artifacts": {},
    }
    json.dumps(payload, ensure_ascii=False, allow_nan=False)
    return payload


def save_calibrated_wet_sequence_json(
    payload: Mapping[str, object],
    path: str | Path,
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return target


def save_calibrated_wet_sequence_csv(
    payload: Mapping[str, object],
    path: str | Path,
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = (
        "case_id",
        "geometry_id",
        "preset_id",
        "material",
        "scenario",
        "replicate_index",
        "seed",
        "collector_branch_id",
        "collector_basis",
        "capture_policy",
        "primary_endpoint_time_s",
        "primary_endpoint_observation",
        "accessible_weighted_contact_fraction",
        "base_captured_precursor_inventory_native",
        "capture_scale",
        "effective_captured_precursor_inventory_native",
        "accessibility_excluded_capture_inventory_native",
        "drydown_total_deposit_inventory_native",
        "second_wet_total_deposit_inventory_native",
        "drydown_combined_residue_fraction",
        "second_wet_combined_residue_fraction",
        "all_stage_mass_balances_closed",
    )
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for case in payload.get("cases", []):
            if not isinstance(case, Mapping):
                continue
            branch = case["collector_branch"]
            endpoint = case["primary_endpoint"]
            final = case["final_metrics"]
            writer.writerow(
                {
                    "case_id": case["case_id"],
                    "geometry_id": case["geometry_id"],
                    "preset_id": case["preset_id"],
                    "material": case["material"],
                    "scenario": case["scenario"],
                    "replicate_index": case["replicate_index"],
                    "seed": case["seed"],
                    "collector_branch_id": case["collector_branch_id"],
                    "collector_basis": branch["collector_basis"],
                    "capture_policy": branch["capture_policy"],
                    "primary_endpoint_time_s": endpoint[
                        "endpoint_physical_time_s"
                    ],
                    "primary_endpoint_observation": endpoint[
                        "observation_status"
                    ],
                    "accessible_weighted_contact_fraction": branch[
                        "accessible_weighted_contact_fraction"
                    ],
                    "base_captured_precursor_inventory_native": branch[
                        "base_captured_precursor_inventory_native"
                    ],
                    "capture_scale": branch["capture_scale"],
                    "effective_captured_precursor_inventory_native": branch[
                        "effective_captured_precursor_inventory_native"
                    ],
                    "accessibility_excluded_capture_inventory_native": branch[
                        "accessibility_excluded_capture_inventory_native"
                    ],
                    "drydown_total_deposit_inventory_native": final[
                        "drydown_total_deposit_inventory_native"
                    ],
                    "second_wet_total_deposit_inventory_native": final[
                        "second_wet_total_deposit_inventory_native"
                    ],
                    "drydown_combined_residue_fraction": final[
                        "drydown_combined_residue_fraction"
                    ],
                    "second_wet_combined_residue_fraction": final[
                        "second_wet_combined_residue_fraction"
                    ],
                    "all_stage_mass_balances_closed": case["quality"][
                        "all_stage_mass_balances_closed"
                    ],
                }
            )
    return target


__all__ = [
    "BRANCH_ACCESSIBLE_FIXED",
    "BRANCH_ACCESSIBLE_SCALED",
    "BRANCH_ALL_PHYSICAL",
    "BRANCH_ALL_PHYSICAL_SCALED",
    "COLLECTOR_BRANCHES",
    "CalibratedWetSequenceConfig",
    "run_calibrated_wet_sequence",
    "save_calibrated_wet_sequence_csv",
    "save_calibrated_wet_sequence_json",
]

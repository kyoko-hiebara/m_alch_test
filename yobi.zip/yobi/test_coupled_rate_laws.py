from __future__ import annotations

import unittest

import numpy as np

from coupled_rate_laws import (
    ThermalArrheniusRateLaw2D,
    ThermalArrheniusRateParameters,
)
from etch_process import ThermalBoundaryConditions
from reaction_diffusion_2d import CartesianGrid2D
from thermal_model import ThermalResistanceModel, ThermalResistanceParameters
from trench_geometry import TaperedTrench2D


class ThermalArrheniusRateLaw2DTests(unittest.TestCase):
    def setUp(self) -> None:
        self.geometry = TaperedTrench2D("toy", 8.0, 6.0, 20.0)
        self.grid = CartesianGrid2D.from_geometry(
            self.geometry,
            spacing_nm=2.0,
            reservoir_height_nm=4.0,
            lateral_margin_nm=2.0,
        )
        self.thermal = ThermalResistanceModel(
            self.geometry,
            ThermalResistanceParameters(
                substrate_thickness_m=20.0e-9,
                effective_substrate_width_m=8.0e-9,
                solution_boundary_resistance_m2K_W=1.0e-8,
                backside_contact_resistance_m2K_W=1.0e-8,
            ),
        )
        self.interface = np.zeros(self.grid.shape, dtype=bool)
        first_cavity_row = int(np.flatnonzero(self.grid.depth_nm > 0.0)[0])
        self.interface[first_cavity_row] = self.grid.cavity_mask[first_cavity_row]

    def make_rate(self, solution_K: float, substrate_K: float):
        return ThermalArrheniusRateLaw2D(
            self.grid,
            self.thermal,
            ThermalBoundaryConditions(solution_K, substrate_K),
            ThermalArrheniusRateParameters(
                reference_maximum_velocity_nm_s=1.0,
                half_saturation_concentration=0.1,
                product_inhibition=1.0,
                reference_temperature_K=300.0,
                activation_energy_J_mol=40_000.0,
            ),
        )

    def evaluate(self, rate: ThermalArrheniusRateLaw2D) -> np.ndarray:
        return rate(
            np.ones(self.grid.shape),
            np.zeros(self.grid.shape),
            np.zeros(self.grid.shape),
            self.interface,
        )

    def test_equal_external_temperatures_are_preserved_exactly(self) -> None:
        rate = self.make_rate(310.0, 310.0)
        velocity = self.evaluate(rate)
        np.testing.assert_allclose(
            rate.last_interface_temperature_K[self.interface], 310.0
        )
        self.assertTrue(np.all(velocity[~self.interface] == 0.0))

    def test_independent_substrate_temperature_changes_rate(self) -> None:
        cold = self.make_rate(290.0, 290.0)
        split = self.make_rate(290.0, 350.0)
        cold_velocity = self.evaluate(cold)
        split_velocity = self.evaluate(split)
        self.assertGreater(
            float(np.mean(split.last_interface_temperature_K[self.interface])),
            290.0,
        )
        self.assertGreater(
            float(np.mean(split_velocity[self.interface])),
            float(np.mean(cold_velocity[self.interface])),
        )
        # The adapter uses the thermal network, not an arithmetic mean.
        self.assertFalse(
            np.allclose(
                split.last_interface_temperature_K[self.interface],
                0.5 * (290.0 + 350.0),
            )
        )

    def test_product_and_passivation_reduce_velocity(self) -> None:
        rate = self.make_rate(300.0, 300.0)
        clean = self.evaluate(rate)
        blocked = rate(
            np.ones(self.grid.shape),
            np.ones(self.grid.shape),
            np.full(self.grid.shape, 0.5),
            self.interface,
        )
        self.assertTrue(np.all(blocked[self.interface] < clean[self.interface]))


if __name__ == "__main__":
    unittest.main()

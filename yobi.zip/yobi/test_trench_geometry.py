from __future__ import annotations

import math
import unittest

import numpy as np

from trench_geometry import (
    DEFAULT_GEOMETRY_NAMES,
    GEOMETRY_PRESETS,
    LEGACY_TAPERED_GEOMETRY_NAMES,
    STRAIGHT_GEOMETRY_NAMES,
    TaperedTrench2D,
    get_geometry_preset,
)


class TaperedTrench2DTests(unittest.TestCase):
    def test_default_presets_are_the_two_straight_wall_geometries(self) -> None:
        self.assertEqual(
            DEFAULT_GEOMETRY_NAMES,
            ("10_10_180", "7_7_170"),
        )
        self.assertEqual(DEFAULT_GEOMETRY_NAMES, STRAIGHT_GEOMETRY_NAMES)
        self.assertEqual(
            LEGACY_TAPERED_GEOMETRY_NAMES,
            ("10_8_180", "7_4p5_170"),
        )
        self.assertTrue(set(DEFAULT_GEOMETRY_NAMES).issubset(GEOMETRY_PRESETS))
        self.assertTrue(
            set(LEGACY_TAPERED_GEOMETRY_NAMES).issubset(GEOMETRY_PRESETS)
        )

    def test_straight_wall_presets_and_exact_geometry(self) -> None:
        first = get_geometry_preset("10_10_180")
        self.assertEqual(
            first.polygon_nm(),
            ((-5.0, 0.0), (-5.0, 180.0), (5.0, 180.0), (5.0, 0.0)),
        )
        np.testing.assert_allclose(
            first.width_at_depth_nm(np.asarray([0.0, 90.0, 180.0])),
            [10.0, 10.0, 10.0],
        )
        self.assertEqual(first.area_nm2, 1800.0)
        self.assertEqual(first.opening_aspect_ratio, 18.0)
        self.assertEqual(first.bottom_aspect_ratio, 18.0)
        self.assertEqual(first.sidewall_angle_from_vertical_deg, 0.0)

        second = get_geometry_preset("7_7_170")
        self.assertEqual(
            second.polygon_nm(),
            ((-3.5, 0.0), (-3.5, 170.0), (3.5, 170.0), (3.5, 0.0)),
        )
        np.testing.assert_allclose(
            second.width_at_depth_nm(np.asarray([0.0, 85.0, 170.0])),
            [7.0, 7.0, 7.0],
        )
        self.assertEqual(second.area_nm2, 1190.0)
        self.assertAlmostEqual(second.opening_aspect_ratio, 170.0 / 7.0)
        self.assertAlmostEqual(second.bottom_aspect_ratio, 170.0 / 7.0)
        self.assertEqual(second.sidewall_angle_from_vertical_deg, 0.0)

    def test_non_default_diagnostic_straight_geometry_presets(self) -> None:
        expected = {
            "7_7_175": (7.0, 175.0),
            "8_8_140": (8.0, 140.0),
            "8_8_175": (8.0, 175.0),
            "8_8_210": (8.0, 210.0),
            "10_10_175": (10.0, 175.0),
        }
        for name, (width_nm, depth_nm) in expected.items():
            with self.subTest(name=name):
                geometry = get_geometry_preset(name)
                self.assertEqual(geometry.name, name)
                self.assertEqual(geometry.top_width_nm, width_nm)
                self.assertEqual(geometry.bottom_width_nm, width_nm)
                self.assertEqual(geometry.depth_nm, depth_nm)
                np.testing.assert_allclose(
                    geometry.width_at_depth_nm(
                        np.asarray([0.0, 0.5 * depth_nm, depth_nm])
                    ),
                    [width_nm, width_nm, width_nm],
                )
                self.assertEqual(geometry.sidewall_angle_from_vertical_deg, 0.0)
                self.assertAlmostEqual(geometry.opening_aspect_ratio, depth_nm / width_nm)
                self.assertAlmostEqual(geometry.bottom_aspect_ratio, depth_nm / width_nm)

        self.assertEqual(DEFAULT_GEOMETRY_NAMES, ("10_10_180", "7_7_170"))
        self.assertEqual(STRAIGHT_GEOMETRY_NAMES, DEFAULT_GEOMETRY_NAMES)
        self.assertTrue(set(expected).isdisjoint(DEFAULT_GEOMETRY_NAMES))

    def test_legacy_tapered_presets_and_exact_geometry(self) -> None:
        first = get_geometry_preset("10_8_180")
        self.assertEqual(
            first.polygon_nm(),
            ((-5.0, 0.0), (-4.0, 180.0), (4.0, 180.0), (5.0, 0.0)),
        )
        self.assertEqual(first.width_at_depth_nm(0.0), 10.0)
        self.assertEqual(first.width_at_depth_nm(90.0), 9.0)
        self.assertEqual(first.width_at_depth_nm(180.0), 8.0)
        self.assertEqual(first.area_nm2, 1620.0)
        self.assertAlmostEqual(first.opening_aspect_ratio, 18.0)
        self.assertAlmostEqual(first.bottom_aspect_ratio, 22.5)
        self.assertAlmostEqual(
            first.sidewall_angle_from_vertical_deg,
            math.degrees(math.atan(1.0 / 180.0)),
        )

        second = get_geometry_preset("7_4p5_170")
        self.assertEqual(
            second.polygon_nm(),
            ((-3.5, 0.0), (-2.25, 170.0), (2.25, 170.0), (3.5, 0.0)),
        )
        np.testing.assert_allclose(
            second.width_at_depth_nm(np.asarray([0.0, 85.0, 170.0])),
            [7.0, 5.75, 4.5],
        )
        self.assertEqual(second.area_nm2, 977.5)

    def test_contains_sloped_boundaries(self) -> None:
        geometry = get_geometry_preset("10_8_180")
        self.assertTrue(geometry.contains_nm(5.0, 0.0))
        self.assertFalse(geometry.contains_nm(5.0001, 0.0))
        self.assertTrue(geometry.contains_nm(4.5, 90.0))
        self.assertFalse(geometry.contains_nm(4.5001, 90.0))
        self.assertTrue(geometry.contains_nm(4.0, 180.0))
        self.assertFalse(geometry.contains_nm(0.0, -0.001))
        self.assertFalse(geometry.contains_nm(0.0, 180.001))

    def test_validation_and_round_trip(self) -> None:
        with self.assertRaises(ValueError):
            TaperedTrench2D("bad", 4.0, 5.0, 10.0)
        with self.assertRaises(ValueError):
            TaperedTrench2D("bad", math.nan, 5.0, 10.0)
        with self.assertRaises(ValueError):
            get_geometry_preset("missing")
        original = get_geometry_preset("7_4p5_170")
        self.assertEqual(TaperedTrench2D.from_dict(original.to_dict()), original)
        with self.assertRaises(ValueError):
            original.width_at_depth_nm(-1.0)


if __name__ == "__main__":
    unittest.main()

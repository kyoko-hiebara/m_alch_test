"""Can proton delivery to the trench bottom limit the acid-assisted etch?

The protonation probe settled that ``theta_H`` is an occupancy: a site
protonates without a barrier whenever a proton reaches it.  That moved the
question from equilibrium to supply -- if protons cannot reach the bottom fast
enough, the bottom etches slower than the top and the residue is explained.
This module asks whether that supply limitation can actually occur.

Three demand channels compete against diffusive resupply down the liquid
column:

1. **steady etch demand** -- each removed Si consumes ``nu_H = 4/3`` protons,
   because every nitrogen of Si3N4 leaves as ammonium (the AFS salt observed
   after SiN/HF etching is direct evidence of that channel);
2. **wall titration** -- on first contact the sidewall sites protonate once,
   an inventory that can exceed the protons held in the trench liquid;
3. **profile build-up** -- the diffusion transient over the trench depth.

Each is expressed against the same capacity, the quasi-steady diffusive flux
``D C / L`` to a consuming front at depth ``L``.  The depletion fraction
``delta = demand / capacity`` is the primary output; the front concentration is
``C (1 - delta)`` in the linear regime the numbers turn out to justify.

The answer is decided by scale, so the module sweeps every disputable factor
well past its plausible range -- etch rate up to the 19x passivation
multiplier and beyond, diffusivity reduced up to 100x for nano-confinement,
both standard geometries, both dHF strengths -- and reports the worst case.

**Boundaries.**  Quasi-steady linear diffusion in a straight slit; no
electromigration or ambipolar coupling (the mobile-ion background makes the
neutral-diffusion estimate the right order of magnitude, not the exact
number); no nano-confinement physics beyond the swept diffusivity reduction;
infinite-dilution diffusivities at 25 degC.  The sulfuric-acid lever reuses the
Step-0 speciation model and inherits its ionic-strength validity limits.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any, Mapping, Sequence

from acid_speciation import (
    protonated_site_fraction,
    solve_acidified_speciation,
    weight_percent_to_fluorine_molality,
)
from literature_parameters import (
    HF_DIFFUSIVITY_298_M2_S,
    WATER_DENSITY_298_KG_M3,
    get_literature_preset,
    hf_speciation_298K_from_weight_percent,
)
from trench_geometry import get_geometry_preset


SCHEMA_VERSION = "trench-proton-delivery-screen/v1"
MODEL_NOTICE = (
    "Quasi-steady linear-diffusion screen for proton delivery down a straight "
    "trench, against etch demand, one-shot wall titration, and the diffusion "
    "transient. No electromigration, no ambipolar coupling, no "
    "nano-confinement physics beyond a swept diffusivity reduction; "
    "infinite-dilution 25 degC diffusivities. The sulfuric lever inherits the "
    "Step-0 speciation validity limits. This decides whether delivery can "
    "limit the bottom, not what the absolute etch rate is."
)

# Infinite-dilution tracer diffusivities at 25 degC from limiting ionic
# conductivities (Grotthuss-dominated for the proton).  These are external
# constants; everything else is already in the repository.
PROTON_DIFFUSIVITY_298_M2_S = 9.31e-9
PROTON_DIFFUSIVITY_SOURCE = (
    "H+ tracer diffusivity at infinite dilution, 25 degC, from the limiting "
    "ionic conductivity; Grotthuss-dominated"
)
FLUORIDE_DIFFUSIVITY_298_M2_S = 1.46e-9
FLUORIDE_DIFFUSIVITY_SOURCE = (
    "F- tracer diffusivity at infinite dilution, 25 degC, from the limiting "
    "ionic conductivity"
)

# Stoichiometry for Si3N4 in acidic HF: every nitrogen leaves as ammonium, so
# 4/3 protons per silicon; six fluorines per silicon for the SiF6(2-)-like
# product is the declared assumption for the HF channel.
PROTONS_PER_SILICON = 4.0 / 3.0
HF_PER_SILICON = 6.0

# Verdict bands on the worst-case depletion fraction.
NEGLIGIBLE_BELOW = 0.01
LIMITING_ABOVE = 0.10

# The sweep deliberately runs past plausibility so the conclusion cannot be
# accused of stopping early.  The verdict, however, is taken over the
# plausible envelope: the 19x passivation multiplier is the largest slowdown
# the mesh-converged calculations support, and one decade of confinement
# slowdown is already generous for a 10 nm aqueous slit.
PLAUSIBLE_RATE_MULTIPLIER_MAX = 19.0
PLAUSIBLE_DIFFUSIVITY_REDUCTION_MAX = 10.0

VERDICT_NEGLIGIBLE = "delivery_cannot_limit_the_bottom"
VERDICT_MARGINAL = "delivery_marginal_in_worst_case"
VERDICT_LIMITING = "delivery_can_limit_the_bottom"

DEFAULT_RATE_MULTIPLIERS = (1.0, 19.0, 100.0)
DEFAULT_DIFFUSIVITY_REDUCTIONS = (1.0, 10.0, 100.0)
DEFAULT_GEOMETRIES = ("10_10_180", "7_7_170")
DEFAULT_HF_WEIGHT_PERCENTS = (0.55, 0.15)
DEFAULT_SULFURIC_MOL_KG = (0.0, 0.003, 0.01, 0.03, 0.1)
DEFAULT_HALF_SATURATIONS_MOL_KG = (0.01, 0.1, 1.0)


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def etch_flux_mol_m2_s(
    rate_nm_min: float, site_density_mol_m3: float
) -> float:
    """Silicon removal flux of a front etching at ``rate_nm_min``."""

    rate = _finite_positive("rate_nm_min", rate_nm_min)
    density = _finite_positive("site_density_mol_m3", site_density_mol_m3)
    return rate * 1.0e-9 / 60.0 * density


def depletion_fraction(
    *,
    demand_flux_mol_m2_s: float,
    diffusivity_m2_s: float,
    bulk_concentration_mol_m3: float,
    depth_m: float,
) -> float:
    """``demand / (D C / L)``: fractional draw-down at a consuming front.

    Below about 0.1 the linear reading ``C_front = C (1 - delta)`` is valid;
    the verdict bands are set so the linearity question never matters for the
    conclusion.
    """

    demand = float(demand_flux_mol_m2_s)
    if not math.isfinite(demand) or demand < 0.0:
        raise ValueError("demand_flux_mol_m2_s must be finite and non-negative")
    capacity = (
        _finite_positive("diffusivity_m2_s", diffusivity_m2_s)
        * _finite_positive(
            "bulk_concentration_mol_m3", bulk_concentration_mol_m3
        )
        / _finite_positive("depth_m", depth_m)
    )
    return demand / capacity


def wall_titration(
    *,
    site_density_mol_m3: float,
    depth_m: float,
    width_m: float,
    proton_concentration_mol_m3: float,
    proton_diffusivity_m2_s: float,
) -> dict[str, float]:
    """One-shot protonation of the sidewalls versus the liquid inventory.

    The areal site density is taken as the two-thirds power of the volumetric
    one.  The interesting outputs are the ratio of wall demand to the protons
    the trench liquid holds, and how long the reservoir needs to refill it.
    """

    volumetric = _finite_positive(
        "site_density_mol_m3", site_density_mol_m3
    )
    depth = _finite_positive("depth_m", depth_m)
    width = _finite_positive("width_m", width_m)
    concentration = _finite_positive(
        "proton_concentration_mol_m3", proton_concentration_mol_m3
    )
    diffusivity = _finite_positive(
        "proton_diffusivity_m2_s", proton_diffusivity_m2_s
    )
    avogadro = 6.02214076e23
    areal_mol_m2 = (volumetric * avogadro) ** (2.0 / 3.0) / avogadro
    wall_area_per_opening = 2.0 * depth / width
    wall_demand_mol_m2 = wall_area_per_opening * areal_mol_m2
    liquid_inventory_mol_m2 = concentration * depth
    resupply_flux = diffusivity * concentration / depth
    return {
        "areal_site_density_mol_m2": areal_mol_m2,
        "wall_area_per_opening_area": wall_area_per_opening,
        "wall_demand_mol_m2_opening": wall_demand_mol_m2,
        "liquid_inventory_mol_m2_opening": liquid_inventory_mol_m2,
        "demand_over_inventory": wall_demand_mol_m2 / liquid_inventory_mol_m2,
        "refill_time_s": wall_demand_mol_m2 / resupply_flux,
    }


@dataclass(frozen=True)
class DeliveryCase:
    """One point of the depletion sweep."""

    geometry: str
    hf_weight_percent: float
    rate_multiplier: float
    diffusivity_reduction: float
    base_rate_nm_min: float
    proton_depletion: float
    hf_depletion: float
    front_over_bulk_proton: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def sweep_depletion(
    *,
    geometries: Sequence[str] = DEFAULT_GEOMETRIES,
    hf_weight_percents: Sequence[float] = DEFAULT_HF_WEIGHT_PERCENTS,
    rate_multipliers: Sequence[float] = DEFAULT_RATE_MULTIPLIERS,
    diffusivity_reductions: Sequence[float] = DEFAULT_DIFFUSIVITY_REDUCTIONS,
    base_rate_nm_min: float = 2.2,
    site_density_mol_m3: float = 5.31e4,
) -> list[DeliveryCase]:
    """Depletion fractions across every disputable factor.

    The default base rate is the literature SiN WER; the multipliers carry it
    through the 19x passivation regime and a factor-5 beyond.  Diffusivity
    reductions stand in for nano-confinement, which is otherwise unmodelled.
    """

    cases: list[DeliveryCase] = []
    for geometry_name in geometries:
        geometry = get_geometry_preset(geometry_name)
        depth_m = geometry.depth_nm * 1.0e-9
        for weight_percent in hf_weight_percents:
            speciation = hf_speciation_298K_from_weight_percent(weight_percent)
            for multiplier in rate_multipliers:
                silicon_flux = etch_flux_mol_m2_s(
                    base_rate_nm_min * multiplier, site_density_mol_m3
                )
                for reduction in diffusivity_reductions:
                    proton = depletion_fraction(
                        demand_flux_mol_m2_s=PROTONS_PER_SILICON * silicon_flux,
                        diffusivity_m2_s=PROTON_DIFFUSIVITY_298_M2_S
                        / reduction,
                        bulk_concentration_mol_m3=speciation.hydronium_mol_m3,
                        depth_m=depth_m,
                    )
                    hf = depletion_fraction(
                        demand_flux_mol_m2_s=HF_PER_SILICON * silicon_flux,
                        diffusivity_m2_s=HF_DIFFUSIVITY_298_M2_S / reduction,
                        bulk_concentration_mol_m3=speciation.neutral_hf_mol_m3,
                        depth_m=depth_m,
                    )
                    cases.append(
                        DeliveryCase(
                            geometry=geometry_name,
                            hf_weight_percent=weight_percent,
                            rate_multiplier=multiplier,
                            diffusivity_reduction=reduction,
                            base_rate_nm_min=base_rate_nm_min,
                            proton_depletion=proton,
                            hf_depletion=hf,
                            front_over_bulk_proton=max(0.0, 1.0 - proton),
                        )
                    )
    return cases


def classify(worst_depletion: float) -> str:
    value = float(worst_depletion)
    if not math.isfinite(value) or value < 0.0:
        raise ValueError("worst_depletion must be finite and non-negative")
    if value < NEGLIGIBLE_BELOW:
        return VERDICT_NEGLIGIBLE
    if value <= LIMITING_ABOVE:
        return VERDICT_MARGINAL
    return VERDICT_LIMITING


def sulfuric_theta_lever(
    *,
    hf_weight_percent: float = 0.55,
    sulfuric_mol_kg: Sequence[float] = DEFAULT_SULFURIC_MOL_KG,
    half_saturations_mol_kg: Sequence[float] = DEFAULT_HALF_SATURATIONS_MOL_KG,
) -> list[dict[str, Any]]:
    """Bulk ``theta_H`` versus sulfuric dose, per half-saturation constant.

    Once delivery is shown non-limiting, the bottom sees bulk chemistry and
    this bulk lever is the whole of the proton effect.  ``K_half`` is unknown,
    so the lever is reported across three decades of it; the saturating shape
    is the point -- past ``C_H >> K_half`` more acid buys nothing.
    """

    fluorine = weight_percent_to_fluorine_molality(hf_weight_percent)
    rows: list[dict[str, Any]] = []
    reference = None
    for dose in sulfuric_mol_kg:
        solved = solve_acidified_speciation(
            analytical_fluorine_mol_kg=fluorine,
            added_sulfuric_acid_mol_kg=float(dose),
        )
        if reference is None:
            reference = solved
        row: dict[str, Any] = {
            "added_sulfuric_mol_kg": float(dose),
            "proton_mol_kg": solved.proton_mol_kg,
            "ph": solved.ph,
            "support_status": solved.support_status,
            "theta": {},
            "theta_gain_over_dhf": {},
        }
        for half in half_saturations_mol_kg:
            constant = 1.0 / _finite_positive(
                "half_saturation_mol_kg", half
            )
            theta = protonated_site_fraction(solved.proton_mol_kg, constant)
            theta_ref = protonated_site_fraction(
                reference.proton_mol_kg, constant
            )
            key = f"K_half={half:g}"
            row["theta"][key] = theta
            row["theta_gain_over_dhf"][key] = theta / theta_ref
        rows.append(row)
    return rows


def build_report(
    *,
    base_rate_nm_min: float = 2.2,
    measured_rate_nm_min: float = 0.6418,
    site_density_mol_m3: float = 5.31e4,
) -> dict[str, Any]:
    """Verdict, sweeps, titration, transient, and the sulfuric lever."""

    cases = sweep_depletion(
        base_rate_nm_min=base_rate_nm_min,
        site_density_mol_m3=site_density_mol_m3,
    )
    plausible = [
        case
        for case in cases
        if case.rate_multiplier <= PLAUSIBLE_RATE_MULTIPLIER_MAX
        and case.diffusivity_reduction <= PLAUSIBLE_DIFFUSIVITY_REDUCTION_MAX
    ]
    worst = max(plausible, key=lambda case: case.proton_depletion)
    extreme = max(cases, key=lambda case: case.proton_depletion)
    verdict = classify(worst.proton_depletion)

    # Parameter-light invariant: HF depletes harder than the proton in every
    # case, because (nu_HF/nu_H) x (D_H C_H)/(D_HF C_HF) stays well above one
    # for both dHF strengths.  Proton delivery therefore can never be the
    # *first* transport limit -- HF delivery fails first, and the repository's
    # null model already showed HF delivery does not fail.
    hf_first_ratio = min(
        case.hf_depletion / case.proton_depletion
        for case in cases
        if case.proton_depletion > 0.0
    )

    speciation = hf_speciation_298K_from_weight_percent(0.55)
    geometry = get_geometry_preset("10_10_180")
    titration = wall_titration(
        site_density_mol_m3=site_density_mol_m3,
        depth_m=geometry.depth_nm * 1.0e-9,
        width_m=geometry.top_width_nm * 1.0e-9,
        proton_concentration_mol_m3=speciation.hydronium_mol_m3,
        proton_diffusivity_m2_s=PROTON_DIFFUSIVITY_298_M2_S,
    )
    depth_m = geometry.depth_nm * 1.0e-9
    transient_s = depth_m**2 / PROTON_DIFFUSIVITY_298_M2_S

    return {
        "schema_version": SCHEMA_VERSION,
        "model_notice": MODEL_NOTICE,
        "external_constants": {
            "proton_diffusivity_m2_s": PROTON_DIFFUSIVITY_298_M2_S,
            "proton_diffusivity_source": PROTON_DIFFUSIVITY_SOURCE,
            "fluoride_diffusivity_m2_s": FLUORIDE_DIFFUSIVITY_298_M2_S,
            "fluoride_diffusivity_source": FLUORIDE_DIFFUSIVITY_SOURCE,
        },
        "stoichiometry": {
            "protons_per_silicon": PROTONS_PER_SILICON,
            "protons_note": (
                "every nitrogen of Si3N4 leaves as ammonium; the AFS salt "
                "observed after SiN/HF etching evidences the channel"
            ),
            "hf_per_silicon": HF_PER_SILICON,
            "hf_note": "declared assumption for a SiF6(2-)-like product",
        },
        "rates_nm_min": {
            "literature_base": base_rate_nm_min,
            "measured_initial": measured_rate_nm_min,
            "note": (
                "the sweep uses the larger literature base so the worst case "
                "bounds the measured clock as well"
            ),
        },
        "verdict": verdict,
        "plausible_envelope": {
            "rate_multiplier_max": PLAUSIBLE_RATE_MULTIPLIER_MAX,
            "diffusivity_reduction_max": PLAUSIBLE_DIFFUSIVITY_REDUCTION_MAX,
        },
        "worst_case": worst.to_dict(),
        "extreme_corner": {
            **extreme.to_dict(),
            "note": (
                "outside the plausible envelope by construction; at 100x rate "
                "with 100x slower diffusion the proton reaches the marginal "
                "band -- but HF reaches the limiting band first, so even here "
                "proton delivery is not the binding constraint"
            ),
        },
        "hf_depletes_first_invariant": {
            "minimum_hf_over_proton_depletion": hf_first_ratio,
            "reading": (
                "in every swept case HF draws down at least this many times "
                "harder than the proton; proton delivery can never be the "
                "first transport limit, and the null model already showed HF "
                "delivery does not fail"
            ),
        },
        "headline": (
            "across the plausible envelope (rate up to 19x, diffusivity down "
            f"10x) the proton draw-down stays below {worst.proton_depletion:.2%}; "
            "the bottom sees bulk chemistry, and in every case HF would "
            "deplete before the proton does"
            if verdict == VERDICT_NEGLIGIBLE
            else "proton delivery approaches or enters the limiting regime "
            "inside the plausible envelope; the bottom does not see bulk "
            "chemistry"
        ),
        "consequences": {
            "rank_3_reading": (
                "proton-supply limitation as a transport effect is excluded "
                "at these scales; theta_H at the bottom equals bulk theta_H"
                if verdict == VERDICT_NEGLIGIBLE
                else "proton-supply limitation stays live as a transport "
                "effect"
            ),
            "h2so4_reading": (
                "the sulfuric lever acts through bulk theta_H everywhere in "
                "the trench, not preferentially at the bottom"
                if verdict == VERDICT_NEGLIGIBLE
                else "the sulfuric lever also relieves a real bottom deficit"
            ),
            "bottom_specificity_reading": (
                "bottom specificity must come from the film side (initial "
                "thickness, local quality), not from proton delivery"
                if verdict == VERDICT_NEGLIGIBLE
                else "bottom specificity can be carried by delivery itself"
            ),
        },
        "cases": [case.to_dict() for case in cases],
        "wall_titration": {
            **titration,
            "reading": (
                "the walls demand more protons than the trench liquid holds "
                f"({titration['demand_over_inventory']:.0f}x), but the "
                "reservoir refills that inventory in "
                f"{titration['refill_time_s']:.1e} s; a one-shot transient, "
                "not a steady limitation"
            ),
        },
        "diffusion_transient_s": transient_s,
        "sulfuric_theta_lever": sulfuric_theta_lever(),
    }


__all__ = [
    "DEFAULT_GEOMETRIES",
    "DEFAULT_HALF_SATURATIONS_MOL_KG",
    "DEFAULT_HF_WEIGHT_PERCENTS",
    "DEFAULT_RATE_MULTIPLIERS",
    "DEFAULT_SULFURIC_MOL_KG",
    "FLUORIDE_DIFFUSIVITY_298_M2_S",
    "HF_PER_SILICON",
    "LIMITING_ABOVE",
    "MODEL_NOTICE",
    "NEGLIGIBLE_BELOW",
    "PROTONS_PER_SILICON",
    "PROTON_DIFFUSIVITY_298_M2_S",
    "SCHEMA_VERSION",
    "PLAUSIBLE_DIFFUSIVITY_REDUCTION_MAX",
    "PLAUSIBLE_RATE_MULTIPLIER_MAX",
    "VERDICT_LIMITING",
    "VERDICT_MARGINAL",
    "VERDICT_NEGLIGIBLE",
    "DeliveryCase",
    "build_report",
    "classify",
    "depletion_fraction",
    "etch_flux_mol_m2_s",
    "sulfuric_theta_lever",
    "sweep_depletion",
    "wall_titration",
]

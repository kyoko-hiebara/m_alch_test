from __future__ import annotations

import csv
import json
import math
import tempfile
import unittest
from pathlib import Path

from attachment_discrimination import (
    AttachmentDiscriminationConfig,
    build_attachment_design,
    post_hf_closure,
    run_attachment_discrimination,
    save_attachment_contrast_csv,
    save_attachment_discrimination_csv,
    save_attachment_discrimination_json,
)
from run_attachment_discrimination import config_for_mode


SIN_PRESET = "sin_barcellona_b_0p55wt"


def coarse_config(**updates: object) -> AttachmentDiscriminationConfig:
    values: dict[str, object] = {
        "geometries": ("10_10_180",),
        "presets": (SIN_PRESET,),
        "replicate_seeds": (17,),
        "include_phase_maps": False,
        "phase_levels": 3,
        "parallel_workers": 1,
        "grid_spacing_nm": 20.0,
        "reservoir_height_nm": 20.0,
        "lateral_margin_nm": 0.0,
        # Leave native GAP FILL and form dry-down deposit in the same coarse
        # case so component-wise residue accounting is exercised in coexistence.
        "primary_hf_duration_s": 3.0,
        "primary_sync_steps": 1,
        "maximum_events": 100,
        "second_wet_duration_s": 5.0,
        "surface_profile_bins": 8,
    }
    values.update(updates)
    return AttachmentDiscriminationConfig(**values)


def assert_finite_tree(testcase: unittest.TestCase, value: object) -> None:
    if isinstance(value, float):
        testcase.assertTrue(math.isfinite(value))
    elif isinstance(value, dict):
        for item in value.values():
            assert_finite_tree(testcase, item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            assert_finite_tree(testcase, item)


class AttachmentDefinitionTests(unittest.TestCase):
    def test_design_has_all_independent_probes_and_interaction_maps(self) -> None:
        config = coarse_config(include_phase_maps=True, phase_levels=3)
        designs, metadata = build_attachment_design(config)
        probe_names = {
            design.probe_name
            for design in designs
            if design.case_group == "probe"
        }
        self.assertEqual(
            probe_names,
            {
                "dry_enabled",
                "drying_rate",
                "rinse_flow",
                "immediate_quench",
                "wall_pretreatment",
                "wall_material_selectivity",
                "bottom_material_selectivity",
            },
        )
        self.assertEqual(len(metadata), 3)
        self.assertEqual(
            sum(design.case_group == "phase_map" for design in designs),
            27,
        )

    def test_closure_obeys_fixed_window_and_keeps_dry_control_exact(self) -> None:
        common = {
            "generated_inventory_native": 100.0,
            "post_hf_to_dry_window_s": 60.0,
            "rinse_start_delay_s": 30.0,
            "rinse_exchange_rate_s": 0.05,
            "dry_enabled": True,
            "drying_rate_s": 1.0 / 30.0,
            "drying_duration_s": 60.0,
            "drydown_capture_fraction": 0.10,
        }
        delayed = post_hf_closure(**common, immediate_quench=False)
        immediate = post_hf_closure(**common, immediate_quench=True)
        no_dry = post_hf_closure(
            **{**common, "dry_enabled": False}, immediate_quench=False
        )
        self.assertEqual(delayed["effective_rinse_flow_duration_s"], 30.0)
        self.assertEqual(immediate["effective_rinse_flow_duration_s"], 60.0)
        self.assertLess(
            immediate["soluble_residual_inventory_native"],
            delayed["soluble_residual_inventory_native"],
        )
        self.assertEqual(no_dry["dry_extent"], 0.0)
        self.assertEqual(no_dry["captured_precursor_inventory_native"], 0.0)

    def test_modes_cover_target_straight_trenches(self) -> None:
        self.assertEqual(
            AttachmentDiscriminationConfig().geometries,
            ("10_10_180", "7_7_170"),
        )
        smoke = config_for_mode("smoke", 1)
        quick = config_for_mode("quick", 1)
        full = config_for_mode("full", 1)
        self.assertEqual(smoke.parallel_workers, 1)
        self.assertEqual(quick.geometries[:2], ("10_10_180", "7_7_170"))
        self.assertTrue({"10_10_180", "7_7_170"}.issubset(full.geometries))
        self.assertEqual(len(full.replicate_seeds), 5)

    def test_invalid_config_rejects_bad_capture_or_duplicate_seed(self) -> None:
        with self.assertRaisesRegex(ValueError, "drydown_capture_fraction"):
            coarse_config(drydown_capture_fraction=1.1)
        with self.assertRaisesRegex(ValueError, "duplicates"):
            coarse_config(replicate_seeds=(1, 1))


class AttachmentRealRunTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = run_attachment_discrimination(coarse_config())

    def test_primary_is_reused_and_four_endpoints_close(self) -> None:
        quality = self.payload["quality_summary"]
        self.assertEqual(quality["requested_primary_strata"], 1)
        self.assertEqual(quality["successful_primary_strata"], 1)
        self.assertEqual(quality["failed_case_count"], 0)
        self.assertEqual(quality["mass_balance_failure_count"], 0)
        self.assertEqual(self.payload["primary_reuse"]["primary_run_count"], 1)
        self.assertEqual(
            self.payload["primary_reuse"]["second_wet_matrix_run_count"], 1
        )
        self.assertGreater(self.payload["primary_reuse"]["post_hf_case_count"], 7)
        case = self.payload["cases"][0]
        self.assertEqual(
            tuple(case["stages"]),
            (
                "hf_endpoint",
                "rinse_endpoint",
                "drydown_endpoint",
                "second_wet_endpoint",
            ),
        )
        self.assertIn(
            "modeled_rinseable_product_pool_inventory_native",
            case["stages"]["hf_endpoint"],
        )
        self.assertIn(
            "continuum_snapshot_product_inventory_native",
            case["stages"]["hf_endpoint"],
        )

    def test_capture_and_allocation_probes_are_orthogonal(self) -> None:
        cases = self.payload["cases"]
        no_dry = next(
            case
            for case in cases
            if case["probe_name"] == "dry_enabled"
            and case["parameters"]["dry_enabled"] is False
        )
        self.assertEqual(
            no_dry["metrics"]["drydown_total_deposit_inventory_native"], 0.0
        )
        dry = next(
            case
            for case in cases
            if case["probe_name"] == "dry_enabled"
            and case["parameters"]["dry_enabled"] is True
        )
        self.assertEqual(
            set(no_dry["stages"]["drydown_endpoint"]["formation"]),
            set(dry["stages"]["drydown_endpoint"]["formation"]),
        )
        wall_cases = sorted(
            (case for case in cases if case["probe_name"] == "wall_pretreatment"),
            key=lambda case: case["parameters"]["wall_pretreatment_multiplier"],
        )
        totals = [
            case["metrics"]["drydown_total_deposit_inventory_native"]
            for case in wall_cases
        ]
        self.assertGreater(totals[0], 0.0)
        self.assertAlmostEqual(max(totals), min(totals), places=8)
        wall_shares = [case["metrics"]["wall_deposit_fraction"] for case in wall_cases]
        self.assertEqual(wall_shares, sorted(wall_shares))
        self.assertGreater(wall_shares[-1], wall_shares[0])

    def test_stage_diagnostics_include_mass_density_thickness_and_profiles(self) -> None:
        case = next(
            case
            for case in self.payload["cases"]
            if case["probe_name"] == "wall_pretreatment"
            and case["parameters"]["wall_pretreatment_multiplier"] == 1.0
        )
        diagnostics = case["stages"]["drydown_endpoint"]["deposit_diagnostics"]
        for key in (
            "total_inventory_native",
            "total_mass_kg_per_nm_span",
            "mean_wall_thickness_nm",
            "mean_bottom_thickness_nm",
            "wall_inventory_density_native_per_nm2",
            "bottom_inventory_density_native_per_nm2",
            "wall_continuous_coverage_fraction",
            "bottom_continuous_coverage_fraction",
        ):
            self.assertIn(key, diagnostics)
        self.assertIsNotNone(diagnostics["total_mass_kg_per_nm_span"])
        profile = case["surface_profiles"]["drydown_endpoint"]
        self.assertEqual(len(profile["wall_depth_fraction"]), 8)
        self.assertAlmostEqual(sum(profile["wall_inventory_fraction"]), 1.0)
        self.assertIn("wall_excess_density_native_per_nm2", case["metrics"])
        self.assertIn("wall_bottom_density_contrast", case["metrics"])
        self.assertGreaterEqual(case["metrics"]["wall_bottom_density_contrast"], -1.0)
        self.assertLessEqual(case["metrics"]["wall_bottom_density_contrast"], 1.0)

    def test_stage_residue_components_share_one_discrete_area_basis(self) -> None:
        case = next(
            case
            for case in self.payload["cases"]
            if case["probe_name"] == "wall_pretreatment"
            and case["parameters"]["wall_pretreatment_multiplier"] == 1.0
        )
        components = [
            case["stages"][stage]["residue_components"]
            for stage in (
                "hf_endpoint",
                "rinse_endpoint",
                "drydown_endpoint",
                "second_wet_endpoint",
            )
        ]
        initial_areas = {
            item["normalization"]["discrete_initial_gap_fill_area_nm2"]
            for item in components
        }
        self.assertEqual(len(initial_areas), 1)
        for item in components:
            normalization = item["normalization"]
            original = item["original_gap_fill"]
            deposit = item["post_hf_deposit"]
            combined = item["combined"]
            initial_area = normalization["discrete_initial_gap_fill_area_nm2"]
            self.assertEqual(
                initial_area,
                normalization["initial_matrix_site_count"]
                * normalization["cell_area_nm2"],
            )
            self.assertEqual(
                original["equivalent_cross_section_area_nm2"],
                original["remaining_site_count"] * normalization["cell_area_nm2"],
            )
            self.assertEqual(
                combined["equivalent_cross_section_area_nm2"],
                original["equivalent_cross_section_area_nm2"]
                + deposit["equivalent_cross_section_area_nm2"],
            )
            self.assertEqual(
                original["fraction_of_discrete_initial_gap_fill_area"],
                original["equivalent_cross_section_area_nm2"] / initial_area,
            )
            self.assertEqual(
                deposit["fraction_of_discrete_initial_gap_fill_area"],
                deposit["equivalent_cross_section_area_nm2"] / initial_area,
            )
            self.assertEqual(
                combined["fraction_of_discrete_initial_gap_fill_area"],
                original["fraction_of_discrete_initial_gap_fill_area"]
                + deposit["fraction_of_discrete_initial_gap_fill_area"],
            )
            self.assertAlmostEqual(
                combined["fraction_of_discrete_initial_gap_fill_area"],
                combined["equivalent_cross_section_area_nm2"] / initial_area,
                places=15,
            )

        hf, rinse, drydown, second_wet = components
        self.assertEqual(hf["original_gap_fill"], rinse["original_gap_fill"])
        self.assertEqual(rinse["original_gap_fill"], drydown["original_gap_fill"])
        self.assertEqual(hf["post_hf_deposit"]["inventory_native"], 0.0)
        self.assertEqual(rinse["post_hf_deposit"]["inventory_native"], 0.0)
        self.assertGreater(drydown["post_hf_deposit"]["inventory_native"], 0.0)
        self.assertLessEqual(
            second_wet["original_gap_fill"]["remaining_site_count"],
            drydown["original_gap_fill"]["remaining_site_count"],
        )
        self.assertLessEqual(
            second_wet["post_hf_deposit"]["inventory_native"],
            drydown["post_hf_deposit"]["inventory_native"],
        )
        self.assertEqual(
            {item["original_gap_fill"]["material"] for item in components},
            {"SiN"},
        )
        self.assertEqual(
            {item["post_hf_deposit"]["species_name"] for item in components},
            {"AFS_like_(NH4)2SiF6"},
        )

    def test_strict_json_and_flat_csv_round_trip(self) -> None:
        assert_finite_tree(self, self.payload)
        json.dumps(self.payload, allow_nan=False)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            json_path = save_attachment_discrimination_json(
                self.payload, root / "result.json"
            )
            csv_path = save_attachment_discrimination_csv(
                self.payload, root / "cases.csv"
            )
            contrast_path = save_attachment_contrast_csv(
                self.payload, root / "contrasts.csv"
            )
            loaded = json.loads(json_path.read_text(encoding="utf-8"))
            with csv_path.open(encoding="utf-8", newline="") as stream:
                rows = list(csv.DictReader(stream))
            with contrast_path.open(encoding="utf-8", newline="") as stream:
                contrast_rows = list(csv.DictReader(stream))
        self.assertEqual(loaded["schema_version"], self.payload["schema_version"])
        self.assertEqual(len(rows), len(self.payload["cases"]))
        self.assertIn("drydown_total_deposit_inventory_native", rows[0])
        self.assertEqual(len(contrast_rows), len(self.payload["contrasts"]))
        self.assertIn("interpretation", contrast_rows[0])


if __name__ == "__main__":
    unittest.main()

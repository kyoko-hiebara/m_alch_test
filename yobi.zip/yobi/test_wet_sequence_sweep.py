from __future__ import annotations

import json
import math
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from run_wet_sequence_sweep import main
from wet_sequence_sweep import (
    WET_SEQUENCE_ARMS,
    WetSequenceSweepConfig,
    run_wet_sequence_case,
    run_wet_sequence_sweep,
)


SIN_PRESET = "sin_barcellona_b_0p55wt"


def small_config(**overrides: object) -> WetSequenceSweepConfig:
    values: dict[str, object] = {
        "geometries": ("10_8_180",),
        "presets": (SIN_PRESET,),
        "primary_hf_clear_time_fraction": 0.05,
        "rinse_duration_s": 5.0,
        "second_wet_clear_time_fraction": 0.03,
        "oxidation_clear_time_fraction": 0.03,
        "fluoride_clear_time_fraction": 0.03,
        "integration_chunks_per_reactive_step": 3,
        "integration_chunks_per_rinse": 2,
    }
    values.update(overrides)
    return WetSequenceSweepConfig(**values)


class WetSequenceSweepTests(unittest.TestCase):
    def test_six_required_arms_are_explicit(self) -> None:
        self.assertEqual(
            tuple(WET_SEQUENCE_ARMS),
            (
                "hf_only",
                "hf_rinse",
                "hf_rinse_second_wet",
                "hf_rinse_hf_control",
                "hf_rinse_oxidation_rinse_fluoride",
                "hf_rinse_fluoride_without_oxidation",
            ),
        )
        with self.assertRaisesRegex(ValueError, "unknown WET arms"):
            small_config(arms=("missing",))
        with self.assertRaisesRegex(ValueError, "positive"):
            small_config(rinse_duration_s=0.0)

    def test_case_records_step_coverages_rinse_cleaning_and_controls(self) -> None:
        config = small_config(
            solution_bulk_temperature_K=295.0,
            substrate_backside_temperature_K=320.0,
        )
        case = run_wet_sequence_case("10_8_180", SIN_PRESET, config)
        arms = {item["arm"]: item for item in case["arms"]}

        primary = case["primary_HF_time_axis"]
        self.assertAlmostEqual(
            primary["primary_HF_duration_s"],
            0.05 * primary["blanket_clear_time_s"],
        )
        self.assertTrue(primary["initial_equivalent_rate_matches_blanket_WER"])
        self.assertEqual(
            case["boundary_temperatures_K"],
            {
                "solution_bulk": 295.0,
                "substrate_backside": 320.0,
                "independent_inputs": True,
            },
        )

        hf_final = arms["hf_only"]["final_coverage"]
        rinse_final = arms["hf_rinse"]["final_coverage"]
        self.assertAlmostEqual(
            hf_final["cumulative_removed_fraction"],
            rinse_final["cumulative_removed_fraction"],
        )
        self.assertLess(
            rinse_final["product_coverage"], hf_final["product_coverage"]
        )
        self.assertLess(
            rinse_final["passivation_coverage"],
            hf_final["passivation_coverage"],
        )
        rinse_step = arms["hf_rinse"]["steps"][-1]
        self.assertTrue(rinse_step["rinse_cleaning"]["is_rinse"])
        self.assertGreater(
            rinse_step["rinse_cleaning"]["blocked_coverage_removed"], 0.0
        )
        self.assertAlmostEqual(
            rinse_step["incremental_removal"]["fraction_of_initial_inventory"],
            0.0,
        )
        self.assertIn("coverage_before", rinse_step)
        self.assertIn("coverage_after", rinse_step)
        self.assertIn("cumulative_removal_after", rinse_step)

        temperature_range = case["interface_temperature_range_all_arms_K"]
        self.assertGreaterEqual(temperature_range["minimum"], 295.0 - 1.0e-10)
        self.assertGreater(temperature_range["maximum"], 295.0)
        self.assertLessEqual(temperature_range["maximum"], 320.0 + 1.0e-10)
        self.assertEqual(
            set(case["control_differences"]),
            {
                "rinse_vs_no_rinse",
                "second_wet_vs_matched_hf",
                "oxidation_required_for_fluoride_branch",
            },
        )
        duration_audit = case["matched_duration_audit"]
        self.assertTrue(
            duration_audit["second_wet_vs_secondary_HF"]["exactly_matched"]
        )
        self.assertEqual(
            duration_audit["second_wet_vs_secondary_HF"]["difference_s"], 0.0
        )
        self.assertTrue(
            duration_audit["oxidation_arm_vs_no_oxidation_control"][
                "exactly_matched"
            ]
        )
        for audit in case["common_prefix_reproducibility"].values():
            self.assertTrue(audit["exactly_equal"])
            self.assertEqual(
                audit["maximum_absolute_coverage_or_geometry_difference"], 0.0
            )

        for arm in arms.values():
            previous_after = None
            for step in arm["steps"]:
                boundary = step["state_boundary_audit"]
                self.assertTrue(boundary["solution_reset_verified"])
                self.assertEqual(
                    boundary["solution_inventory_after_step"],
                    boundary["solution_inputs_applied"],
                )
                if previous_after is not None:
                    self.assertTrue(boundary["surface_carry_verified"])
                    self.assertEqual(step["coverage_before"], previous_after)
                previous_after = step["coverage_after"]
                if step["reaction_mode"] == "rinse":
                    self.assertEqual(
                        boundary["solution_inputs_applied"]["reactant_activity"],
                        0.0,
                    )

    def test_fluoride_negative_control_needs_converted_inventory(self) -> None:
        case = run_wet_sequence_case("10_8_180", SIN_PRESET, small_config())
        arms = {item["arm"]: item for item in case["arms"]}
        negative = arms["hf_rinse_fluoride_without_oxidation"]
        fluoride_step = negative["steps"][-1]
        self.assertEqual(fluoride_step["mechanism"], "fluoride_after_oxidation")
        self.assertAlmostEqual(
            fluoride_step["incremental_removal"][
                "fraction_of_initial_inventory"
            ],
            0.0,
            places=12,
        )
        oxidation = arms["hf_rinse_oxidation_rinse_fluoride"]
        self.assertGreater(
            oxidation["final_coverage"]["cumulative_removed_fraction"],
            negative["final_coverage"]["cumulative_removed_fraction"],
        )

        second = arms["hf_rinse_second_wet"]["steps"][-1]
        hf_control = arms["hf_rinse_hf_control"]["steps"][-1]
        self.assertAlmostEqual(second["duration_s"], hf_control["duration_s"])

    def test_process_parallel_preserves_case_order(self) -> None:
        common = dict(
            geometries=("10_8_180", "7_4p5_170"),
            presets=(SIN_PRESET,),
            arms=("hf_only", "hf_rinse"),
            primary_hf_clear_time_fraction=0.02,
            rinse_duration_s=2.0,
            integration_chunks_per_reactive_step=2,
            integration_chunks_per_rinse=2,
        )
        serial = run_wet_sequence_sweep(
            WetSequenceSweepConfig(**common, parallel_workers=1)
        )
        parallel = run_wet_sequence_sweep(
            WetSequenceSweepConfig(**common, parallel_workers=2)
        )
        serial_ids = [case["case_id"] for case in serial["cases"]]
        parallel_ids = [case["case_id"] for case in parallel["cases"]]
        self.assertEqual(serial_ids, parallel_ids)
        self.assertEqual(parallel["parallel_execution"]["effective_workers"], 2)
        self.assertEqual(serial["cases"], parallel["cases"])

    def test_cli_writes_plain_json(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "wet_sequence.json"
            payload = main(
                [
                    "--geometry",
                    "7_4p5_170",
                    "--preset",
                    SIN_PRESET,
                    "--arm",
                    "hf_only",
                    "--primary-clear-fraction",
                    "0.01",
                    "--reactive-chunks",
                    "2",
                    "--solution-temperature-k",
                    "294",
                    "--substrate-temperature-k",
                    "322",
                    "--workers",
                    "1",
                    "--output",
                    str(output),
                ]
            )
            saved = json.loads(output.read_text(encoding="utf-8"))
            raw_text = output.read_text(encoding="utf-8")
            self.assertEqual(saved, payload)
            self.assertFalse(saved["calibrated"])
            self.assertTrue(saved["deterministic"])
            self.assertEqual(
                saved["serialization_audit"],
                {
                    "plain_JSON_compatible": True,
                    "nonfinite_numbers_allowed": False,
                },
            )
            self.assertEqual(saved["cases"][0]["arms"][0]["arm"], "hf_only")
            self.assertEqual(
                saved["cases"][0]["boundary_temperatures_K"][
                    "solution_bulk"
                ],
                294.0,
            )
            self.assertNotIn("hash", saved)
            self.assertNotIn("NaN", raw_text)
            self.assertNotIn("Infinity", raw_text)

            def assert_finite_tree(value: object) -> None:
                if isinstance(value, float):
                    self.assertTrue(math.isfinite(value))
                elif isinstance(value, dict):
                    for item in value.values():
                        assert_finite_tree(item)
                elif isinstance(value, list):
                    for item in value:
                        assert_finite_tree(item)

            assert_finite_tree(saved)

    def test_cli_rejects_nonfinite_solver_payload(self) -> None:
        with patch(
            "run_wet_sequence_sweep.run_wet_sequence_sweep",
            return_value={"bad": math.nan},
        ):
            with self.assertRaisesRegex(ValueError, "Out of range float values"):
                main(
                    [
                        "--geometry",
                        "10_8_180",
                        "--preset",
                        SIN_PRESET,
                        "--arm",
                        "hf_only",
                        "--workers",
                        "1",
                    ]
                )


if __name__ == "__main__":
    unittest.main()

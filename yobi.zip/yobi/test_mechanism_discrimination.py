from __future__ import annotations

import json
import math
import tempfile
import unittest
from pathlib import Path

from mechanism_discrimination import (
    CAUSE_ORDER,
    CAUSE_PROFILES,
    DIAGNOSTIC_GEOMETRY_IDS,
    MechanismDiscriminationConfig,
    ProbeDefinition,
    WALL_AFFINITY_CARRIER_CAPTURE_FRACTION,
    _calibration_jobs,
    _cumulative_vector_distance,
    _longest_true_run,
    _metric_case_valid,
    _profile_parameters,
    _robust_vector_distance,
    default_probe_definitions,
    diagnose_fingerprint,
    run_mechanism_discrimination,
    save_mechanism_discrimination_json,
)


PRESET = "sin_barcellona_b_0p55wt"


def assert_finite_tree(testcase: unittest.TestCase, value: object) -> None:
    if isinstance(value, float):
        testcase.assertTrue(math.isfinite(value))
    elif isinstance(value, dict):
        for item in value.values():
            assert_finite_tree(testcase, item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            assert_finite_tree(testcase, item)


def coarse_config(**updates: object) -> MechanismDiscriminationConfig:
    values: dict[str, object] = {
        "cause_ids": ("intrinsic_reaction",),
        "presets": (PRESET,),
        "probes": (
            ProbeDefinition(
                "hf_concentration",
                "HF濃度",
                "parameter",
                "hf_bulk_scale",
                (0.5, 1.0, 1.5),
            ),
        ),
        "diagnostic_geometry_ids": ("10_10_180",),
        "reference_geometry_id": "10_10_180",
        "replicate_seeds": (17,),
        "calibration_seed": 17,
        "calibration_candidates_override": {"intrinsic_reaction": (0.2,)},
        "bootstrap_samples": 0,
        "parallel_workers": 1,
        "grid_spacing_nm": 20.0,
        "reservoir_height_nm": 20.0,
        "lateral_margin_nm": 0.0,
        "primary_hf_duration_s": 20.0,
        "primary_sync_steps": 1,
        "maximum_events": 100,
        "second_wet_duration_s": 5.0,
        "wall_depth_bins": 8,
    }
    values.update(updates)
    return MechanismDiscriminationConfig(**values)


class MechanismDefinitionTests(unittest.TestCase):
    def test_nine_profiles_and_crossed_default_geometry_probes(self) -> None:
        self.assertEqual(len(CAUSE_ORDER), 9)
        self.assertEqual(set(CAUSE_ORDER), set(CAUSE_PROFILES))
        self.assertEqual(
            CAUSE_PROFILES["wall_affinity"].calibration_candidates,
            (8.0,),
        )
        probes = {probe.name: probe for probe in default_probe_definitions()}
        self.assertEqual(len(probes), 7)
        self.assertEqual(
            probes["width"].geometry_ids,
            ("7_7_175", "8_8_175", "10_10_175"),
        )
        self.assertEqual(
            probes["depth"].geometry_ids,
            ("8_8_140", "8_8_175", "8_8_210"),
        )
        self.assertEqual(set(DIAGNOSTIC_GEOMETRY_IDS), {
            "7_7_175", "8_8_140", "8_8_175", "8_8_210", "10_10_175"
        })

    def test_config_rejects_invalid_scope_and_controls(self) -> None:
        with self.assertRaisesRegex(ValueError, "unknown causes"):
            coarse_config(cause_ids=("missing",))
        with self.assertRaisesRegex(ValueError, "target_apparent_burden"):
            coarse_config(target_apparent_burden=1.0)
        with self.assertRaisesRegex(ValueError, "wall_depth_bins"):
            coarse_config(wall_depth_bins=3)
        with self.assertRaisesRegex(ValueError, "duplicates"):
            coarse_config(replicate_seeds=(1, 1))

    def test_wall_affinity_does_not_change_drydown_capture_amount(self) -> None:
        base = {"wall_affinity": 1.0, "drydown_capture_fraction": 0.0}
        low = _profile_parameters("wall_affinity", 0.25, base)
        high = _profile_parameters("wall_affinity", 30.0, base)
        self.assertEqual(
            low["drydown_capture_fraction"],
            WALL_AFFINITY_CARRIER_CAPTURE_FRACTION,
        )
        self.assertEqual(
            high["drydown_capture_fraction"],
            WALL_AFFINITY_CARRIER_CAPTURE_FRACTION,
        )
        self.assertNotEqual(low["wall_affinity"], high["wall_affinity"])

    def test_drydown_capture_does_not_change_wall_affinity(self) -> None:
        base = {"wall_affinity": 1.0, "drydown_capture_fraction": 0.0}
        low = _profile_parameters("dry_down", 0.01, base)
        high = _profile_parameters("dry_down", 0.50, base)
        self.assertEqual(low["wall_affinity"], high["wall_affinity"])
        self.assertNotEqual(
            low["drydown_capture_fraction"],
            high["drydown_capture_fraction"],
        )


class DiagnosticMathTests(unittest.TestCase):
    def test_longest_wall_run_and_robust_distance_are_deterministic(self) -> None:
        self.assertEqual(_longest_true_run([False, True, True, False, True]), 2)
        distance, count = _robust_vector_distance(
            {"a": (0.0, 1.0), "b": (10.0, 0.0)},
            {"a": (3.0, 1.0), "b": (0.0, 0.0)},
        )
        self.assertEqual(count, 4)
        self.assertAlmostEqual(distance, math.sqrt((9.0 + 36.0) / 4.0))
        cumulative, cumulative_count = _cumulative_vector_distance(
            {"a": (0.0, 1.0)}, {"a": (3.0, 1.0)}
        )
        expanded, expanded_count = _cumulative_vector_distance(
            {"a": (0.0, 1.0), "b": (10.0, 0.0)},
            {"a": (3.0, 1.0), "b": (0.0, 0.0)},
        )
        self.assertEqual((cumulative_count, expanded_count), (2, 4))
        self.assertGreaterEqual(expanded, cumulative)

    def test_invalid_depth_ratio_is_excluded_from_fingerprint_inputs(self) -> None:
        case = {
            "diagnostic_validity": {
                "hf_bottom_to_top_ratio": False,
                "product_bottom_to_top_ratio": True,
            }
        }
        self.assertFalse(_metric_case_valid(case, "hf_bottom_to_top_ratio"))
        self.assertTrue(_metric_case_valid(case, "product_bottom_to_top_ratio"))
        self.assertTrue(_metric_case_valid(case, "primary_matrix_remaining_fraction"))

    def test_calibration_uses_same_seed_ensemble_as_probes(self) -> None:
        config = coarse_config(replicate_seeds=(17, 19))
        jobs = _calibration_jobs(config, config.process_window_config())
        self.assertEqual(len(jobs), 2)
        self.assertEqual({job.seed for job in jobs}, {17, 19})

    def test_diagnosis_can_return_distinct_or_ambiguous(self) -> None:
        fingerprints = [
            {
                "cause_id": "a", "preset_id": PRESET,
                "entries": [{
                    "component_id": "hf:x", "probe": "hf", "valid": True,
                    "linear_effect": 0.0, "curvature_effect": 0.0,
                }],
            },
            {
                "cause_id": "b", "preset_id": PRESET,
                "entries": [{
                    "component_id": "hf:x", "probe": "hf", "valid": True,
                    "linear_effect": 0.1, "curvature_effect": 0.0,
                }],
            },
        ]
        ambiguous = diagnose_fingerprint(
            {"hf:x": 0.05}, fingerprints, preset_id=PRESET, ambiguity_margin=0.01
        )
        self.assertTrue(ambiguous["ambiguous"])
        distinct = diagnose_fingerprint(
            {"hf:x": 0.0}, fingerprints, preset_id=PRESET, ambiguity_margin=0.01
        )
        self.assertEqual(distinct["diagnosis"], "a")


class MechanismRunnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.payload = run_mechanism_discrimination(coarse_config())

    def test_coarse_real_run_has_calibration_probe_and_spatial_profiles(self) -> None:
        quality = self.payload["quality_summary"]
        self.assertEqual(quality["requested_calibration_cases"], 1)
        self.assertEqual(quality["requested_probe_cases"], 3)
        self.assertEqual(quality["failed_case_count"], 0)
        self.assertEqual(len(self.payload["fingerprints"]), 1)
        case = self.payload["probe_cases"][0]
        self.assertEqual(len(case["spatial_profile"]["primary_native_wall_occupied"]), 8)
        self.assertIn("primary_passivated_fraction", case["metrics"])
        self.assertIn("hf_bottom_to_top_ratio", case["metrics"])
        self.assertIn("pre_second_apparent_burden", case["metrics"])
        assert_finite_tree(self, self.payload)
        json.dumps(self.payload, allow_nan=False)

    def test_save_writes_strict_json(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = save_mechanism_discrimination_json(
                self.payload, Path(directory) / "mechanism.json"
            )
            loaded = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(loaded["schema_version"], self.payload["schema_version"])


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import math
import unittest

from thermal_path_screen import (
    ACCEPTED_BARRIER_EV,
    TRANSPORT_APPARENT_BARRIER_EV,
    arrhenius_rate_ratio,
    coupling_efficiency_for_rate_ratio,
    coupling_efficiency_to_rate_ratio,
    evaluate_thermal_path,
    required_activation_energy_eV,
)


class ArrheniusTests(unittest.TestCase):
    def test_equal_temperatures_give_unit_ratio(self) -> None:
        self.assertAlmostEqual(
            arrhenius_rate_ratio(1.2148, 298.15, 298.15), 1.0, places=12
        )

    def test_zero_barrier_is_temperature_independent(self) -> None:
        self.assertAlmostEqual(
            arrhenius_rate_ratio(0.0, 298.15, 348.15), 1.0, places=12
        )

    def test_ratio_and_inverse_round_trip(self) -> None:
        ratio = arrhenius_rate_ratio(1.2148, 298.15, 310.0)
        self.assertAlmostEqual(
            required_activation_energy_eV(ratio, 298.15, 310.0),
            1.2148,
            places=10,
        )

    def test_inverse_rejects_identical_temperatures(self) -> None:
        with self.assertRaises(ValueError):
            required_activation_energy_eV(2.0, 298.15, 298.15)


class ThermalPathTests(unittest.TestCase):
    def test_default_narrow_substrate_nearly_decouples_the_heater(self) -> None:
        """The thermal_model default makes a backside heater look inert."""

        case = evaluate_thermal_path(effective_substrate_width_m=10.0e-9)
        self.assertLess(case.coupling_efficiency, 0.10)
        self.assertLess(case.rate_ratios["si_n_hydrolysis"], 1.5)

    def test_wide_substrate_couples_the_heater_almost_fully(self) -> None:
        case = evaluate_thermal_path(effective_substrate_width_m=1.0e-3)
        self.assertGreater(case.coupling_efficiency, 0.99)
        self.assertGreater(case.rate_ratios["si_n_hydrolysis"], 30.0)

    def test_coupling_efficiency_increases_with_substrate_width(self) -> None:
        previous = -math.inf
        for width in (1.0e-8, 1.0e-7, 1.0e-6, 1.0e-5, 1.0e-3):
            case = evaluate_thermal_path(effective_substrate_width_m=width)
            self.assertGreater(case.coupling_efficiency, previous)
            previous = case.coupling_efficiency

    def test_solution_boundary_resistance_raises_coupling(self) -> None:
        """A convective boundary layer stops the bath pinning the front."""

        without = evaluate_thermal_path(
            effective_substrate_width_m=1.0e-7,
            solution_boundary_resistance_m2K_W=0.0,
        )
        with_layer = evaluate_thermal_path(
            effective_substrate_width_m=1.0e-7,
            solution_boundary_resistance_m2K_W=1.0e-4,
        )
        self.assertGreater(
            with_layer.coupling_efficiency, without.coupling_efficiency
        )

    def test_coupling_efficiency_is_bounded(self) -> None:
        for width in (1.0e-9, 1.0e-6, 1.0):
            case = evaluate_thermal_path(effective_substrate_width_m=width)
            self.assertGreaterEqual(case.coupling_efficiency, 0.0)
            self.assertLessEqual(case.coupling_efficiency, 1.0 + 1.0e-12)

    def test_deeper_front_couples_better_than_the_opening(self) -> None:
        """Backside heating is bottom-selective, which is where residue is."""

        top = evaluate_thermal_path(
            effective_substrate_width_m=1.0e-7, front_depth_nm=1.0
        )
        bottom = evaluate_thermal_path(
            effective_substrate_width_m=1.0e-7, front_depth_nm=180.0
        )
        self.assertGreater(bottom.coupling_efficiency, top.coupling_efficiency)

    def test_rejects_backside_colder_than_bath(self) -> None:
        with self.assertRaises(ValueError):
            evaluate_thermal_path(
                effective_substrate_width_m=1.0e-6,
                substrate_backside_temperature_K=290.0,
            )

    def test_rejects_front_depth_outside_the_trench(self) -> None:
        with self.assertRaises(ValueError):
            evaluate_thermal_path(
                effective_substrate_width_m=1.0e-6, front_depth_nm=500.0
            )

    def test_every_accepted_barrier_is_reported(self) -> None:
        case = evaluate_thermal_path(effective_substrate_width_m=1.0e-6)
        for key in ACCEPTED_BARRIER_EV:
            self.assertIn(key, case.rate_ratios)
        self.assertIn("transport_limited_null", case.rate_ratios)


class InverseReadingTests(unittest.TestCase):
    def test_transport_null_cannot_reach_a_doubling(self) -> None:
        """A parameter-free falsification: 2x rules transport control out.

        Even perfect thermal coupling of a 25 K backside overheat moves an
        aqueous-diffusion-limited rate by less than 1.7x.
        """

        self.assertIsNone(
            coupling_efficiency_for_rate_ratio(
                2.0, TRANSPORT_APPARENT_BARRIER_EV
            )
        )
        saturated = coupling_efficiency_to_rate_ratio(
            1.0, TRANSPORT_APPARENT_BARRIER_EV
        )
        self.assertLess(saturated, 1.7)

    def test_reaction_control_reaches_a_doubling_with_poor_coupling(self) -> None:
        efficiency = coupling_efficiency_for_rate_ratio(2.0, 1.2148)
        self.assertIsNotNone(efficiency)
        self.assertLess(efficiency, 0.25)

    def test_forward_and_inverse_round_trip(self) -> None:
        ratio = coupling_efficiency_to_rate_ratio(0.35, 1.2148)
        self.assertAlmostEqual(
            coupling_efficiency_for_rate_ratio(ratio, 1.2148), 0.35, places=10
        )

    def test_no_improvement_needs_no_coupling(self) -> None:
        self.assertEqual(coupling_efficiency_for_rate_ratio(1.0, 1.2148), 0.0)

    def test_zero_efficiency_gives_unit_ratio(self) -> None:
        self.assertAlmostEqual(
            coupling_efficiency_to_rate_ratio(0.0, 1.2148), 1.0, places=12
        )

    def test_rejects_efficiency_outside_unit_interval(self) -> None:
        with self.assertRaises(ValueError):
            coupling_efficiency_to_rate_ratio(1.5, 1.2148)


if __name__ == "__main__":
    unittest.main()

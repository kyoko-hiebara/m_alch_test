"""Literature-anchored primary-HF endpoint calibration.

The full-trench graph KMC has a useful topology and local environment law, but
its native seconds are not physical process seconds.  This module measures the
native front velocity with a planar coupon built from the *same* trench event
templates, then anchors that velocity to a film-specific blanket WER::

    physical_seconds_per_model_second = v_coupon,model / v_blanket

The calibrated clock is used only to interpret full-trench trajectories.
Absolute velocity therefore comes from a literature or user-supplied blanket
observation, while KMC contributes a relative transport/passivation modifier.

Every endpoint is an exact discrete removal-event crossing.  No interpolation
is used to claim sub-site endpoint precision.
"""

from __future__ import annotations

import csv
import json
import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np

from literature_parameters import (
    LITERATURE_ETCH_PRESETS,
    LiteratureEtchPreset,
    get_literature_preset,
)
from literature_sweep import nominal_preset_names
from process_window_sweep import ProcessCaseSpec, ProcessWindowConfig, _case_objects
from reaction_diffusion_2d import CartesianGrid2D
from trench_geometry import (
    DEFAULT_GEOMETRY_NAMES,
    GEOMETRY_PRESETS,
    TaperedTrench2D,
)
from trench_graph_kmc import (
    REGION_NAMES,
    TrenchGraphConfig,
    TrenchKMCOutcome,
    TrenchKMCParameters,
    build_trench_graph,
    build_trench_kmc,
    run_coupled_trench_kmc,
    trench_residue_metrics,
)


SCHEMA_VERSION = "trench-primary-hf-endpoint/v1"
MODEL_NOTICE = (
    "Literature-prior endpoint calibration, not a process recipe. Absolute "
    "time is anchored to blanket WER; full-trench graph KMC supplies only a "
    "relative transport/passivation response. Reported blanket-rate "
    "uncertainty is propagated as a clock-only interval; some SiCN/SiOCN "
    "sources provide only a linearly normalized single endpoint with no "
    "temperature or rate uncertainty. No trench "
    "cross-section data have yet been fitted."
)

SCENARIO_LABELS_JA = {
    "transport_only": "輸送のみ",
    "passivation_hypothesis": "生成物阻害＋passivation仮説",
}


def _positive(name: str, value: float) -> None:
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


def _fraction(name: str, value: float, *, include_zero: bool = True) -> None:
    lower_ok = float(value) >= 0.0 if include_zero else float(value) > 0.0
    if not math.isfinite(float(value)) or not lower_ok or float(value) >= 1.0:
        interval = "[0, 1)" if include_zero else "(0, 1)"
        raise ValueError(f"{name} must lie within {interval}")


@dataclass(frozen=True)
class BlanketRateInput:
    """One absolute blanket velocity anchor."""

    preset_id: str
    rate_nm_min: float
    uncertainty_nm_min: float | None
    source_kind: str
    source_note: str
    measurement_temperature_K: float | None = None

    def __post_init__(self) -> None:
        get_literature_preset(self.preset_id)
        _positive("rate_nm_min", self.rate_nm_min)
        if self.uncertainty_nm_min is not None:
            value = float(self.uncertainty_nm_min)
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(
                    "uncertainty_nm_min must be finite and non-negative"
                )
            if value >= self.rate_nm_min:
                raise ValueError("uncertainty_nm_min must be below rate_nm_min")
        if not self.source_kind or not self.source_note:
            raise ValueError("blanket source_kind and source_note cannot be empty")
        if self.measurement_temperature_K is not None:
            _positive(
                "measurement_temperature_K", self.measurement_temperature_K
            )
        if (
            self.source_kind == "experimental_blanket"
            and self.measurement_temperature_K is None
        ):
            raise ValueError(
                "measurement_temperature_K is required for experimental_blanket"
            )

    @property
    def rate_nm_s(self) -> float:
        return self.rate_nm_min / 60.0

    @property
    def normalization_temperature_K(self) -> float:
        return (
            298.15
            if self.measurement_temperature_K is None
            else float(self.measurement_temperature_K)
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["rate_nm_s"] = self.rate_nm_s
        result["normalization_temperature_K"] = (
            self.normalization_temperature_K
        )
        result["normalization_temperature_basis"] = (
            "298.15_K_modelling_convention"
            if self.measurement_temperature_K is None
            else "reported_or_user_measurement_temperature"
        )
        return result


def literature_blanket_input(preset_id: str) -> BlanketRateInput:
    preset = get_literature_preset(preset_id)
    return BlanketRateInput(
        preset_id=preset_id,
        rate_nm_min=preset.planar_rate_nm_min,
        uncertainty_nm_min=preset.planar_rate_uncertainty_nm_min,
        source_kind="literature_prior",
        source_note=(
            f"{preset.rate_evidence}; source={preset.rate_source_key}; "
            f"{preset.extrapolation_caveat}"
        ),
        measurement_temperature_K=preset.reported_solution_temperature_K,
    )


def load_blanket_rate_csv(path: str | Path) -> dict[str, BlanketRateInput]:
    """Load user blanket rates.

    Required columns are ``preset_id``, ``rate_nm_min`` and
    ``measurement_temperature_K``. Optional columns are
    ``uncertainty_nm_min`` and ``source_note``. Rows replace literature
    anchors only for the listed preset IDs.
    """

    source = Path(path)
    result: dict[str, BlanketRateInput] = {}
    with source.open(encoding="utf-8", newline="") as stream:
        for row_number, row in enumerate(csv.DictReader(stream), start=2):
            preset_id = str(row.get("preset_id", "")).strip()
            rate_text = str(row.get("rate_nm_min", "")).strip()
            if not preset_id or not rate_text:
                raise ValueError(
                    f"{source}:{row_number}: preset_id and rate_nm_min are required"
                )
            uncertainty_text = str(
                row.get("uncertainty_nm_min", "")
            ).strip()
            temperature_text = str(
                row.get("measurement_temperature_K", "")
            ).strip()
            if not temperature_text:
                raise ValueError(
                    f"{source}:{row_number}: measurement_temperature_K is "
                    "required for an experimental blanket rate"
                )
            note = str(row.get("source_note", "")).strip() or (
                f"user blanket CSV {source.name}, row {row_number}"
            )
            item = BlanketRateInput(
                preset_id=preset_id,
                rate_nm_min=float(rate_text),
                uncertainty_nm_min=(
                    None if not uncertainty_text else float(uncertainty_text)
                ),
                source_kind="experimental_blanket",
                source_note=note,
                measurement_temperature_K=float(temperature_text),
            )
            if preset_id in result:
                raise ValueError(f"duplicate blanket row for {preset_id}")
            result[preset_id] = item
    if not result:
        raise ValueError("blanket CSV contains no data rows")
    return result


@dataclass(frozen=True)
class PrimaryHFEndpointConfig:
    geometries: tuple[str, ...] = DEFAULT_GEOMETRY_NAMES
    presets: tuple[str, ...] = nominal_preset_names()
    scenarios: tuple[str, ...] = (
        "transport_only",
        "passivation_hypothesis",
    )
    replicate_seeds: tuple[int, ...] = (271828, 314159)
    target_remaining_fractions: tuple[float, ...] = (0.10, 0.05, 0.01, 0.0)
    fixed_probe_times_s: tuple[float, ...] = (300.0,)
    grid_spacing_nm: float = 1.7
    reservoir_height_nm: float = 4.0
    lateral_margin_nm: float = 3.0
    solution_temperature_K: float = 298.15
    substrate_temperature_K: float = 298.15
    # A passivated trench decelerates without stopping, so a short budget
    # right-censors the whole passivation branch instead of measuring it.  The
    # budget is generous because the run is time-driven: the event count is
    # bounded by the site count, not by the physical time simulated.
    maximum_planar_clear_time_multiplier: float = 200.0
    primary_sync_steps: int = 60
    # Coupling resolution is expressed per planar clear time so that widening
    # the budget does not silently coarsen the transport/KMC synchronisation.
    # 20 steps per planar clear reproduces the previous 60 steps at a 3x budget.
    macro_steps_per_planar_clear_time: int = 20
    # Multiplies the passivation generation rate only.  One run gives one
    # point; sweeping this gives the residue-versus-passivation-strength curve
    # that mechanism discrimination actually needs.
    passivation_strength_scale: float = 1.0
    maximum_events: int = 80_000
    maximum_sites: int = 2_500
    parallel_workers: int = 1
    coupon_width_nm: float = 24.0
    coupon_depth_nm: float = 48.0
    coupon_measurement_start_removed_fraction: float = 0.10
    coupon_measurement_end_removed_fraction: float = 0.90
    coupon_maximum_events: int = 20_000
    trace_points: int = 160
    blanket_rate_inputs: Mapping[str, BlanketRateInput] = field(
        default_factory=dict
    )

    def __post_init__(self) -> None:
        if not self.geometries or set(self.geometries).difference(GEOMETRY_PRESETS):
            raise ValueError("geometries must be a non-empty known selection")
        if len(set(self.geometries)) != len(self.geometries):
            raise ValueError("geometries cannot contain duplicates")
        if not self.presets or set(self.presets).difference(LITERATURE_ETCH_PRESETS):
            raise ValueError("presets must be a non-empty known selection")
        if len(set(self.presets)) != len(self.presets):
            raise ValueError("presets cannot contain duplicates")
        if not self.scenarios or set(self.scenarios).difference(SCENARIO_LABELS_JA):
            raise ValueError("scenarios must be a non-empty known selection")
        if len(set(self.scenarios)) != len(self.scenarios):
            raise ValueError("scenarios cannot contain duplicates")
        if not self.replicate_seeds or any(seed < 0 for seed in self.replicate_seeds):
            raise ValueError("replicate_seeds must be non-empty and non-negative")
        if len(set(self.replicate_seeds)) != len(self.replicate_seeds):
            raise ValueError("replicate_seeds cannot contain duplicates")
        if not self.target_remaining_fractions:
            raise ValueError("target_remaining_fractions cannot be empty")
        for value in self.target_remaining_fractions:
            _fraction("target_remaining_fraction", value)
        if len(set(self.target_remaining_fractions)) != len(
            self.target_remaining_fractions
        ):
            raise ValueError("target_remaining_fractions cannot contain duplicates")
        if any(
            not math.isfinite(float(value)) or float(value) < 0.0
            for value in self.fixed_probe_times_s
        ):
            raise ValueError("fixed_probe_times_s must be finite and non-negative")
        for name in (
            "grid_spacing_nm",
            "reservoir_height_nm",
            "solution_temperature_K",
            "substrate_temperature_K",
            "maximum_planar_clear_time_multiplier",
            "passivation_strength_scale",
            "coupon_width_nm",
            "coupon_depth_nm",
        ):
            _positive(name, getattr(self, name))
        if not math.isfinite(self.lateral_margin_nm) or self.lateral_margin_nm < 0:
            raise ValueError("lateral_margin_nm must be finite and non-negative")
        _fraction(
            "coupon_measurement_start_removed_fraction",
            self.coupon_measurement_start_removed_fraction,
        )
        _fraction(
            "coupon_measurement_end_removed_fraction",
            self.coupon_measurement_end_removed_fraction,
            include_zero=False,
        )
        if (
            self.coupon_measurement_start_removed_fraction
            >= self.coupon_measurement_end_removed_fraction
        ):
            raise ValueError("coupon measurement start must be below end")
        for name in (
            "primary_sync_steps",
            "macro_steps_per_planar_clear_time",
            "maximum_events",
            "maximum_sites",
            "parallel_workers",
            "coupon_maximum_events",
            "trace_points",
        ):
            if int(getattr(self, name)) < 1:
                raise ValueError(f"{name} must be positive")
        unknown_rates = set(self.blanket_rate_inputs).difference(self.presets)
        if unknown_rates:
            raise ValueError(
                "blanket_rate_inputs contain unselected presets: "
                f"{sorted(unknown_rates)}"
            )
        for key, value in self.blanket_rate_inputs.items():
            if key != value.preset_id:
                raise ValueError("blanket_rate_inputs keys must match preset_id")
        object.__setattr__(self, "geometries", tuple(self.geometries))
        object.__setattr__(self, "presets", tuple(self.presets))
        object.__setattr__(self, "scenarios", tuple(self.scenarios))
        object.__setattr__(self, "replicate_seeds", tuple(self.replicate_seeds))
        object.__setattr__(
            self,
            "target_remaining_fractions",
            tuple(sorted(self.target_remaining_fractions, reverse=True)),
        )
        object.__setattr__(
            self, "fixed_probe_times_s", tuple(sorted(set(self.fixed_probe_times_s)))
        )

    def synchronization_steps(self) -> int:
        """Coupling steps for one case, held at a fixed physical resolution."""

        scaled = math.ceil(
            self.macro_steps_per_planar_clear_time
            * self.maximum_planar_clear_time_multiplier
        )
        return max(int(self.primary_sync_steps), int(scaled))

    def blanket_input(self, preset_id: str) -> BlanketRateInput:
        return self.blanket_rate_inputs.get(
            preset_id, literature_blanket_input(preset_id)
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        for key in (
            "geometries",
            "presets",
            "scenarios",
            "replicate_seeds",
            "target_remaining_fractions",
            "fixed_probe_times_s",
        ):
            result[key] = list(result[key])
        result["blanket_rate_inputs"] = {
            key: value.to_dict()
            for key, value in self.blanket_rate_inputs.items()
        }
        return result


def _primary_parameters(config: PrimaryHFEndpointConfig) -> dict[str, float]:
    return {
        "hf_bulk_scale": 1.0,
        "liquid_temperature_K": config.solution_temperature_K,
        "substrate_temperature_K": config.substrate_temperature_K,
        "depth_quality_factor": 1.0,
        "wall_quality_factor": 1.0,
        "floor_quality_factor": 1.0,
        "product_inhibition_strength": 2.0,
        "passivation_generation_rate_s": 0.26,
        "passivation_release_rate_s": 0.08,
    }


def _process_config(
    config: PrimaryHFEndpointConfig, duration_s: float
) -> ProcessWindowConfig:
    return ProcessWindowConfig(
        geometries=config.geometries,
        presets=config.presets,
        design_points=2,
        parameter_bounds_set="quick",
        replicate_seeds=(config.replicate_seeds[0],),
        grid_spacing_nm=config.grid_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=config.lateral_margin_nm,
        primary_hf_duration_s=duration_s,
        primary_sync_steps=config.synchronization_steps(),
        maximum_events=config.maximum_events,
        maximum_sites=config.maximum_sites,
        phase_levels=3,
        maximum_phase_pairs=0,
        bootstrap_samples=0,
        parallel_workers=1,
        include_phase_maps=False,
        include_representatives=False,
    )


def _scenario_kinetics(
    kinetics: TrenchKMCParameters,
    scenario: str,
    *,
    passivation_strength_scale: float = 1.0,
) -> TrenchKMCParameters:
    if scenario == "transport_only":
        return replace(
            kinetics,
            product_inhibition_strength=0.0,
            passivation_rate_s=0.0,
            depassivation_rate_s=0.0,
            precipitation_rate_s=0.0,
            deposit_dissolution_rate_s=0.0,
            reattachment_rate_s=0.0,
        )
    if scenario == "passivation_hypothesis":
        # Preserve the legacy dimensionless 0.26/0.08 competition while
        # allowing the blanket-clock normalization to cancel each material's
        # arbitrary native KMC prefactor.  The scale multiplies only the
        # generation side, so it moves the steady-state passivated coverage
        # rather than the overall event clock.
        _positive("passivation_strength_scale", passivation_strength_scale)
        return replace(
            kinetics,
            passivation_rate_s=(
                0.26 * passivation_strength_scale * kinetics.removal_rate_s
            ),
            depassivation_rate_s=0.08 * kinetics.removal_rate_s,
            product_inhibition_strength=2.0,
            precipitation_rate_s=0.0,
            deposit_dissolution_rate_s=0.0,
            reattachment_rate_s=0.0,
        )
    raise ValueError(f"unknown scenario {scenario!r}")


def run_blanket_coupon(
    preset: LiteratureEtchPreset,
    kinetics: TrenchKMCParameters,
    *,
    seed: int,
    spacing_nm: float,
    width_nm: float,
    depth_nm: float,
    start_removed_fraction: float,
    end_removed_fraction: float,
    maximum_events: int,
    environment_temperature_K: float = 298.15,
) -> dict[str, object]:
    """Measure native front velocity using the full-trench event templates."""

    _positive("environment_temperature_K", environment_temperature_K)
    geometry = TaperedTrench2D(
        name=f"blanket_coupon_{preset.key}",
        top_width_nm=width_nm,
        bottom_width_nm=width_nm,
        depth_nm=depth_nm,
    )
    grid = CartesianGrid2D.from_geometry(
        geometry,
        spacing_nm=spacing_nm,
        reservoir_height_nm=max(spacing_nm, 2.0),
        lateral_margin_nm=0.0,
    )
    graph, layout = build_trench_graph(
        grid,
        TrenchGraphConfig(maximum_sites=10_000, material=preset.material),
    )
    reference_kinetics = replace(
        kinetics,
        product_inhibition_strength=0.0,
        passivation_rate_s=0.0,
        depassivation_rate_s=0.0,
        precipitation_rate_s=0.0,
        deposit_dissolution_rate_s=0.0,
        reattachment_rate_s=0.0,
        top_rate_factor=1.0,
        sidewall_rate_factor=1.0,
        bottom_rate_factor=1.0,
        core_rate_factor=1.0,
    )
    kmc = build_trench_kmc(
        graph,
        layout,
        reference_kinetics,
        seed=seed,
        newly_exposed_are_wet=True,
    )
    for site_id in layout.matrix_site_ids:
        site = kmc.graph.sites[site_id]
        if site.state == "intact":
            site.attributes["hf_activity"] = 1.0
            site.attributes["product_activity"] = 0.0
            site.attributes["temperature_K"] = environment_temperature_K
            site.attributes["wet_exposed"] = 1.0
            site.attributes["wet_face_count"] = 1.0
    # Rebuild propensities after setting the reference environment.
    kmc = build_trench_kmc(
        kmc.graph,
        layout,
        reference_kinetics,
        seed=seed,
        newly_exposed_are_wet=True,
    )

    matrix_count = layout.matrix_site_count
    removed = 0
    previous_time = 0.0
    start_time: float | None = (
        0.0 if start_removed_fraction == 0.0 else None
    )
    end_time: float | None = None
    achieved_start_fraction: float | None = (
        0.0 if start_removed_fraction == 0.0 else None
    )
    achieved_end_fraction: float | None = None
    while len(kmc.event_log) < maximum_events:
        record = kmc.step()
        if record is None:
            break
        previous_time = record.time_s
        if record.event_name != "remove":
            continue
        removed += 1
        fraction = removed / matrix_count
        if start_time is None and fraction >= start_removed_fraction:
            start_time = record.time_s
            achieved_start_fraction = fraction
        if fraction >= end_removed_fraction:
            end_time = record.time_s
            achieved_end_fraction = fraction
            break
    if (
        start_time is None
        or end_time is None
        or achieved_start_fraction is None
        or achieved_end_fraction is None
        or end_time <= start_time
    ):
        raise RuntimeError(
            "blanket coupon did not cross its measurement interval "
            f"(removed={removed}/{matrix_count}, model_time={previous_time:g})"
        )
    removed_depth_nm = (
        achieved_end_fraction - achieved_start_fraction
    ) * geometry.depth_nm
    model_velocity = removed_depth_nm / (end_time - start_time)
    return {
        "preset_id": preset.key,
        "material": preset.material,
        "seed": seed,
        "environment_temperature_K": environment_temperature_K,
        "grid_spacing_requested_nm": spacing_nm,
        "coupon_width_nm": width_nm,
        "coupon_depth_nm": depth_nm,
        "grid_dx_nm": grid.dx_nm,
        "grid_dz_nm": grid.dz_nm,
        "matrix_site_count": matrix_count,
        "measurement_start_removed_fraction": start_removed_fraction,
        "measurement_end_removed_fraction": end_removed_fraction,
        "measurement_achieved_start_removed_fraction": achieved_start_fraction,
        "measurement_achieved_end_removed_fraction": achieved_end_fraction,
        "discrete_fraction_resolution": 1.0 / matrix_count,
        "measurement_start_model_time_s": start_time,
        "measurement_end_model_time_s": end_time,
        "measurement_elapsed_model_s": end_time - start_time,
        "equivalent_depth_removed_nm": removed_depth_nm,
        "native_front_velocity_nm_per_model_s": model_velocity,
        "event_count": len(kmc.event_log),
        "stop_reason": "measurement_end_reached",
    }


def endpoint_from_removal_events(
    removal_events: Sequence[Mapping[str, object]],
    *,
    matrix_site_count: int,
    target_remaining_fraction: float,
    physical_seconds_per_model_second: float,
) -> dict[str, object]:
    """Select the first exact event crossing of a matrix-remaining target."""

    if matrix_site_count < 1:
        raise ValueError("matrix_site_count must be positive")
    _fraction("target_remaining_fraction", target_remaining_fraction)
    _positive(
        "physical_seconds_per_model_second",
        physical_seconds_per_model_second,
    )
    maximum_remaining_count = math.floor(
        target_remaining_fraction * matrix_site_count + 1.0e-12
    )
    required_removed_count = matrix_site_count - maximum_remaining_count
    for removed, event in enumerate(removal_events, start=1):
        if removed >= required_removed_count:
            remaining_count = matrix_site_count - removed
            remaining = remaining_count / matrix_site_count
            previous_remaining = (
                (remaining_count + 1) / matrix_site_count
            )
            model_time = float(event["time_s"])
            return {
                "target_remaining_fraction": target_remaining_fraction,
                "reached": True,
                "endpoint_model_time_s": model_time,
                "endpoint_physical_time_s": (
                    model_time * physical_seconds_per_model_second
                ),
                "previous_remaining_fraction": previous_remaining,
                "achieved_remaining_fraction": remaining,
                "discrete_fraction_resolution": 1.0 / matrix_site_count,
                "removed_count_at_endpoint": removed,
                "required_removed_count": required_removed_count,
            }
    removed = len(removal_events)
    remaining = (matrix_site_count - removed) / matrix_site_count
    return {
        "target_remaining_fraction": target_remaining_fraction,
        "reached": False,
        "endpoint_model_time_s": None,
        "endpoint_physical_time_s": None,
        "previous_remaining_fraction": remaining,
        "achieved_remaining_fraction": remaining,
        "discrete_fraction_resolution": 1.0 / matrix_site_count,
        "removed_count_at_endpoint": removed,
        "required_removed_count": required_removed_count,
    }


def _clock_uncertainty_interval(
    physical_time_s: float | None,
    blanket_input: BlanketRateInput,
) -> dict[str, object] | None:
    """Propagate only the reported blanket-rate uncertainty to the clock.

    The already simulated relative KMC trajectory is held fixed. This is not
    a rerun of transport/passivation at the rate bounds.
    """

    if physical_time_s is None or blanket_input.uncertainty_nm_min is None:
        return None
    rate = float(blanket_input.rate_nm_min)
    uncertainty = float(blanket_input.uncertainty_nm_min)
    return {
        "basis": (
            "blanket_rate_plus_or_minus_reported_uncertainty; "
            "relative_KMC_trajectory_held_fixed"
        ),
        "lower_physical_time_s": (
            float(physical_time_s) * rate / (rate + uncertainty)
        ),
        "upper_physical_time_s": (
            float(physical_time_s) * rate / (rate - uncertainty)
        ),
        "relative_trajectory_rerun": False,
    }


def _removal_events(outcome: object) -> list[dict[str, object]]:
    return [
        dict(item)
        for item in outcome.event_locations
        if str(item.get("event_name")) == "remove"
    ]


def _state_at_physical_time(
    removal_events: Sequence[Mapping[str, object]],
    *,
    physical_time_s: float,
    physical_seconds_per_model_second: float,
    matrix_site_count: int,
    initial_region_counts: Mapping[str, int],
) -> dict[str, object]:
    tolerance_s = max(1.0e-12, abs(physical_time_s) * 1.0e-12)
    region_removed = {name: 0 for name in initial_region_counts}
    removed_ids: list[int] = []
    last_model_time = 0.0
    for event in removal_events:
        event_time = float(event["time_s"])
        if (
            event_time * physical_seconds_per_model_second
            > physical_time_s + tolerance_s
        ):
            break
        removed_ids.append(int(event["site_id"]))
        last_model_time = event_time
        region_name = REGION_NAMES[int(event["region_code"])]
        region_removed[region_name] += 1
    removed_count = len(removed_ids)
    regions: dict[str, dict[str, float | int]] = {}
    for name, initial in initial_region_counts.items():
        remaining = initial - region_removed[name]
        regions[name] = {
            "site_count": initial,
            "removed_count": region_removed[name],
            "remaining_count": remaining,
            "remaining_fraction": remaining / initial if initial else 0.0,
        }
    return {
        "requested_physical_time_s": physical_time_s,
        "last_removal_model_time_s": last_model_time,
        "last_removal_physical_time_s": (
            last_model_time * physical_seconds_per_model_second
        ),
        "removed_count": removed_count,
        "remaining_count": matrix_site_count - removed_count,
        "remaining_fraction": 1.0 - removed_count / matrix_site_count,
        "region_metrics": regions,
        "removed_site_ids": removed_ids,
    }


def _state_after_removal_count(
    removal_events: Sequence[Mapping[str, object]],
    *,
    removed_count: int,
    matrix_site_count: int,
    initial_region_counts: Mapping[str, int],
) -> dict[str, object]:
    """Reconstruct an exact event prefix without a time-unit round trip."""

    if not 0 <= removed_count <= min(len(removal_events), matrix_site_count):
        raise ValueError("removed_count is outside the available event prefix")
    region_removed = {name: 0 for name in initial_region_counts}
    removed_ids: list[int] = []
    for event in removal_events[:removed_count]:
        removed_ids.append(int(event["site_id"]))
        region_name = REGION_NAMES[int(event["region_code"])]
        region_removed[region_name] += 1
    regions: dict[str, dict[str, float | int]] = {}
    for name, initial in initial_region_counts.items():
        remaining = initial - region_removed[name]
        regions[name] = {
            "site_count": initial,
            "removed_count": region_removed[name],
            "remaining_count": remaining,
            "remaining_fraction": remaining / initial if initial else 0.0,
        }
    return {
        "removed_count": removed_count,
        "remaining_count": matrix_site_count - removed_count,
        "remaining_fraction": (
            matrix_site_count - removed_count
        ) / matrix_site_count,
        "region_metrics": regions,
        "removed_site_ids": removed_ids,
    }


def _initial_region_counts(outcome: object) -> dict[str, int]:
    counts = {name: 0 for name in REGION_NAMES.values()}
    for site_id in outcome.layout.matrix_site_ids:
        site = outcome.graph.sites[site_id]
        counts[REGION_NAMES[int(round(site.attributes["region_code"]))]] += 1
    return counts


def _regional_clear_endpoint(
    removal_events: Sequence[Mapping[str, object]],
    *,
    region_name: str,
    initial_region_count: int,
    physical_seconds_per_model_second: float,
) -> dict[str, object]:
    if region_name not in REGION_NAMES.values():
        raise ValueError(f"unknown region {region_name!r}")
    if initial_region_count < 0:
        raise ValueError("initial_region_count must be non-negative")
    if initial_region_count == 0:
        return {
            "region": region_name,
            "initial_site_count": 0,
            "reached": True,
            "endpoint_model_time_s": 0.0,
            "endpoint_physical_time_s": 0.0,
        }
    removed = 0
    code = next(key for key, value in REGION_NAMES.items() if value == region_name)
    for event in removal_events:
        if int(event["region_code"]) != code:
            continue
        removed += 1
        if removed == initial_region_count:
            model_time = float(event["time_s"])
            return {
                "region": region_name,
                "initial_site_count": initial_region_count,
                "reached": True,
                "endpoint_model_time_s": model_time,
                "endpoint_physical_time_s": (
                    model_time * physical_seconds_per_model_second
                ),
            }
    return {
        "region": region_name,
        "initial_site_count": initial_region_count,
        "reached": False,
        "endpoint_model_time_s": None,
        "endpoint_physical_time_s": None,
    }


def _trace(
    removal_events: Sequence[Mapping[str, object]],
    *,
    physical_seconds_per_model_second: float,
    matrix_site_count: int,
    trace_points: int,
) -> dict[str, list[float]]:
    if not removal_events:
        return {
            "physical_time_s": [0.0],
            "remaining_fraction": [1.0],
        }
    indices = np.unique(
        np.linspace(0, len(removal_events) - 1, min(trace_points, len(removal_events)))
        .round()
        .astype(int)
    )
    times = [0.0]
    fractions = [1.0]
    for index in indices:
        times.append(
            float(removal_events[int(index)]["time_s"])
            * physical_seconds_per_model_second
        )
        fractions.append(
            max(0.0, 1.0 - (int(index) + 1) / matrix_site_count)
        )
    return {"physical_time_s": times, "remaining_fraction": fractions}


def _snapshot(
    outcome: object,
    removed_site_ids: Iterable[int],
    *,
    physical_time_s: float,
    label: str,
) -> dict[str, object]:
    grid = outcome.layout.grid
    removed = set(int(site_id) for site_id in removed_site_ids)
    remaining = np.zeros(grid.shape, dtype=np.uint8)
    for site_id in outcome.layout.matrix_site_ids:
        if site_id in removed:
            continue
        row, column = outcome.layout.cell_by_site[site_id]
        remaining[row, column] = 1
    return {
        "label": label,
        "physical_time_s": physical_time_s,
        "x_nm": grid.lateral_nm.tolist(),
        "depth_nm": grid.depth_nm.tolist(),
        "cavity_mask": grid.cavity_mask.astype(np.uint8).tolist(),
        "remaining_original_gap_fill_mask": remaining.tolist(),
    }


@dataclass(frozen=True)
class _EndpointJob:
    order: int
    geometry_id: str
    preset_id: str
    scenario: str
    replicate_index: int
    seed: int
    blanket_input: BlanketRateInput
    coupon: Mapping[str, object]
    config: PrimaryHFEndpointConfig


@dataclass(frozen=True)
class CalibratedPrimaryHFHandoff:
    """Live primary-HF endpoint state for a downstream wet sequence.

    ``outcome`` intentionally remains an in-memory object. A saved endpoint
    mask cannot reconstruct passivation, collector state or the endpoint
    continuum fields and must not be used as a resumable state.
    """

    outcome: TrenchKMCOutcome
    clock_calibration: Mapping[str, object]
    endpoint: Mapping[str, object]
    validity: Mapping[str, object]
    product_inventory: Mapping[str, object]
    planar_reference: Mapping[str, object]
    model_parameters: Mapping[str, object]

    def serializable_summary(self) -> dict[str, object]:
        return {
            "clock_calibration": dict(self.clock_calibration),
            "endpoint": dict(self.endpoint),
            "validity": dict(self.validity),
            "product_inventory": dict(self.product_inventory),
            "planar_reference": dict(self.planar_reference),
            "model_parameters": dict(self.model_parameters),
        }

    def require_downstream_eligible(self) -> "CalibratedPrimaryHFHandoff":
        if not bool(self.validity.get("downstream_eligible", False)):
            raise RuntimeError(
                "primary-HF handoff is not downstream-eligible: "
                f"validity={self.validity.get('level')}, "
                f"observation={self.endpoint.get('observation_status')}"
            )
        return self


def run_calibrated_primary_hf_to_endpoint(
    *,
    geometry_id: str,
    preset_id: str,
    scenario: str,
    replicate_index: int,
    seed: int,
    config: PrimaryHFEndpointConfig,
    coupon: Mapping[str, object],
    target_remaining_fraction: float,
) -> CalibratedPrimaryHFHandoff:
    """Run once to an exact endpoint and return the live graph/field state."""

    if geometry_id not in config.geometries:
        raise ValueError("geometry_id must be selected in config")
    if preset_id not in config.presets:
        raise ValueError("preset_id must be selected in config")
    if scenario not in config.scenarios:
        raise ValueError("scenario must be selected in config")
    if not isinstance(replicate_index, int) or replicate_index < 0:
        raise ValueError("replicate_index must be a non-negative integer")
    if replicate_index >= len(config.replicate_seeds):
        raise ValueError("replicate_index is outside config.replicate_seeds")
    if not isinstance(seed, int) or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    _fraction(
        "target_remaining_fraction",
        target_remaining_fraction,
    )
    blanket_input = config.blanket_input(preset_id)
    geometry = GEOMETRY_PRESETS[geometry_id]
    preset = get_literature_preset(preset_id)
    preset_index = config.presets.index(preset_id)
    expected_seed = (
        int(config.replicate_seeds[replicate_index])
        + 100_003 * preset_index
    )
    if seed != expected_seed:
        raise ValueError(
            f"seed does not match the selected preset/replicate ({expected_seed})"
        )
    required_coupon_values = {
        "preset_id": preset_id,
        "material": preset.material,
        "seed": seed,
        "stop_reason": "measurement_end_reached",
    }
    for key, expected in required_coupon_values.items():
        if coupon.get(key) != expected:
            raise ValueError(
                f"coupon {key} does not match handoff selection"
            )
    for key, expected in (
        (
            "environment_temperature_K",
            blanket_input.normalization_temperature_K,
        ),
        ("grid_spacing_requested_nm", config.grid_spacing_nm),
        ("coupon_width_nm", config.coupon_width_nm),
        ("coupon_depth_nm", config.coupon_depth_nm),
        (
            "measurement_start_removed_fraction",
            config.coupon_measurement_start_removed_fraction,
        ),
        (
            "measurement_end_removed_fraction",
            config.coupon_measurement_end_removed_fraction,
        ),
    ):
        try:
            actual = float(coupon[key])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"coupon {key} is missing or invalid") from exc
        if not math.isclose(
            actual, float(expected), rel_tol=0.0, abs_tol=1.0e-12
        ):
            raise ValueError(f"coupon {key} does not match handoff config")
    try:
        coupon_start = float(
            coupon["measurement_achieved_start_removed_fraction"]
        )
        coupon_end = float(
            coupon["measurement_achieved_end_removed_fraction"]
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(
            "coupon measurement achieved fractions are missing or invalid"
        ) from exc
    if not coupon_end > coupon_start:
        raise ValueError("coupon measurement interval must have positive depth")
    blanket_velocity = blanket_input.rate_nm_s
    model_velocity = float(coupon["native_front_velocity_nm_per_model_s"])
    _positive("native_front_velocity_nm_per_model_s", model_velocity)
    clock_scale = model_velocity / blanket_velocity
    planar_clear_time_s = geometry.depth_nm / blanket_velocity
    maximum_physical_time_s = (
        config.maximum_planar_clear_time_multiplier * planar_clear_time_s
    )
    maximum_model_time_s = maximum_physical_time_s / clock_scale
    spec = ProcessCaseSpec(
        order=0,
        case_group="calibrated_primary_hf_handoff",
        design_index=0,
        geometry_id=geometry_id,
        preset_id=preset_id,
        replicate_index=replicate_index,
        seed=seed,
        parameters=_primary_parameters(config),
    )
    grid, graph_config, coupling, kinetics, spatial, derived = _case_objects(
        spec,
        _process_config(config, max(maximum_model_time_s, 1.0e-9)),
    )
    continuum_rate_scale = (
        blanket_input.rate_nm_min / preset.planar_rate_nm_min
    )
    kinetics = _scenario_kinetics(
        kinetics,
        scenario,
        passivation_strength_scale=config.passivation_strength_scale,
    )
    coupling = replace(
        coupling,
        hf_interface_sink_velocity_nm_s=(
            coupling.hf_interface_sink_velocity_nm_s * continuum_rate_scale
        ),
        product_interface_source_flux=(
            coupling.product_interface_source_flux * continuum_rate_scale
        ),
        product_reference_concentration=(
            coupling.product_reference_concentration * continuum_rate_scale
        ),
        total_time_s=maximum_model_time_s,
        macro_time_step_s=(
            maximum_model_time_s / config.synchronization_steps()
        ),
        maximum_events=config.maximum_events,
        target_remaining_fraction=target_remaining_fraction,
    )
    outcome = run_coupled_trench_kmc(
        grid,
        graph_config=graph_config,
        coupling_parameters=coupling,
        kmc_parameters=kinetics,
        spatial_etchability_parameters=spatial,
        seed=seed,
    )
    events = _removal_events(outcome)
    matrix_count = outcome.layout.matrix_site_count
    endpoint = endpoint_from_removal_events(
        events,
        matrix_site_count=matrix_count,
        target_remaining_fraction=target_remaining_fraction,
        physical_seconds_per_model_second=clock_scale,
    )
    endpoint = {
        **endpoint,
        "blanket_rate_uncertainty_interval": _clock_uncertainty_interval(
            (
                None
                if endpoint["endpoint_physical_time_s"] is None
                else float(endpoint["endpoint_physical_time_s"])
            ),
            blanket_input,
        ),
        "region_metrics_at_endpoint": (
            trench_residue_metrics(outcome.graph, outcome.layout)[
                "region_metrics"
            ]
            if endpoint["reached"]
            else None
        ),
    }
    all_hf_converged = all(
        bool(item["hf_converged"]) for item in outcome.sync_history
    )
    all_product_converged = all(
        bool(item["product_converged"]) for item in outcome.sync_history
    )
    if not all_hf_converged or not all_product_converged:
        validity_level = "invalid"
        observation_status = "invalid"
    elif outcome.stop_reason == "maximum_events":
        validity_level = "partial"
        observation_status = "budget_censored"
    elif (
        outcome.stop_reason == "remaining_fraction_target"
        and bool(endpoint["reached"])
    ):
        validity_level = "valid"
        observation_status = "observed"
    else:
        validity_level = "valid"
        observation_status = "right_censored"
    endpoint["observation_status"] = observation_status
    endpoint["censor_physical_time_s"] = (
        None
        if observation_status == "observed"
        else outcome.total_time_s * clock_scale
    )
    if observation_status == "observed":
        endpoint_model_time = float(endpoint["endpoint_model_time_s"])
        final_frame_time = float(outcome.final_frame.time_s)
        remaining_fraction = float(outcome.summary()["remaining_fraction"])
        if not math.isclose(
            endpoint_model_time,
            outcome.total_time_s,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise RuntimeError("endpoint event and outcome clocks diverged")
        if not math.isclose(
            final_frame_time,
            outcome.total_time_s,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise RuntimeError("endpoint continuum frame clock diverged")
        if not math.isclose(
            float(endpoint["achieved_remaining_fraction"]),
            remaining_fraction,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise RuntimeError("endpoint selector and live graph state diverged")
    summary = trench_residue_metrics(outcome.graph, outcome.layout)
    removed_count = int(summary["state_counts"].get("removed", 0))
    cumulative_generated = (
        removed_count
        * grid.cell_area_nm2
        * preset.solid_si_site_density_mol_m3
    )
    instantaneous_liquid = float(
        np.sum(
            outcome.final_frame.product_field[
                outcome.final_frame.liquid_mask & grid.cavity_mask
            ]
        )
        * grid.cell_area_nm2
    )
    return CalibratedPrimaryHFHandoff(
        outcome=outcome,
        clock_calibration={
            **dict(coupon),
            "blanket_anchor": blanket_input.to_dict(),
            "blanket_velocity_nm_s": blanket_velocity,
            "physical_seconds_per_model_second": clock_scale,
            "calibration_equation": (
                "physical_seconds_per_model_second = "
                "native_coupon_velocity_nm_per_model_s / blanket_velocity_nm_s"
            ),
        },
        endpoint=endpoint,
        validity={
            "level": validity_level,
            "all_hf_synchronizations": all_hf_converged,
            "all_product_synchronizations": all_product_converged,
            "native_stop_reason": outcome.stop_reason,
            "downstream_eligible": (
                validity_level == "valid"
                and observation_status == "observed"
            ),
        },
        product_inventory={
            "cumulative_generated_si_equivalent_inventory_native": (
                cumulative_generated
            ),
            "instantaneous_endpoint_liquid_inventory_native": (
                instantaneous_liquid
            ),
            "instantaneous_endpoint_field_is_cumulative_mass_balance": False,
            "post_hf_pool_basis": "cumulative_generated_upper_bound",
            "double_counting_prohibited": True,
        },
        planar_reference={
            "planar_clear_time_s": planar_clear_time_s,
            "maximum_simulated_physical_time_s": maximum_physical_time_s,
            "maximum_time_over_planar_clear": (
                config.maximum_planar_clear_time_multiplier
            ),
        },
        model_parameters={
            "graph": asdict(graph_config),
            "coupling_native_clock": asdict(coupling),
            "kinetics_native_clock": asdict(kinetics),
            "spatial_etchability": spatial.to_dict(),
            "derived_conditions_before_clock_calibration": {
                **derived,
                "continuum_rate_scale_from_blanket_input": (
                    continuum_rate_scale
                ),
            },
        },
    )


def _run_endpoint_job(job: _EndpointJob) -> dict[str, object]:
    config = job.config
    geometry = GEOMETRY_PRESETS[job.geometry_id]
    blanket_velocity = job.blanket_input.rate_nm_s
    model_velocity = float(job.coupon["native_front_velocity_nm_per_model_s"])
    clock_scale = model_velocity / blanket_velocity
    planar_clear_time_s = geometry.depth_nm / blanket_velocity
    maximum_physical_time_s = (
        config.maximum_planar_clear_time_multiplier * planar_clear_time_s
    )
    maximum_model_time_s = maximum_physical_time_s / clock_scale
    spec = ProcessCaseSpec(
        order=job.order,
        case_group="primary_hf_endpoint",
        design_index=0,
        geometry_id=job.geometry_id,
        preset_id=job.preset_id,
        replicate_index=job.replicate_index,
        seed=job.seed,
        parameters=_primary_parameters(config),
    )
    grid, graph_config, coupling, kinetics, spatial, derived = _case_objects(
        spec, _process_config(config, max(maximum_model_time_s, 1.0e-9))
    )
    preset = get_literature_preset(job.preset_id)
    continuum_rate_scale = (
        job.blanket_input.rate_nm_min / preset.planar_rate_nm_min
    )
    kinetics = _scenario_kinetics(
        kinetics,
        job.scenario,
        passivation_strength_scale=config.passivation_strength_scale,
    )
    coupling = replace(
        coupling,
        hf_interface_sink_velocity_nm_s=(
            coupling.hf_interface_sink_velocity_nm_s * continuum_rate_scale
        ),
        product_interface_source_flux=(
            coupling.product_interface_source_flux * continuum_rate_scale
        ),
        product_reference_concentration=(
            coupling.product_reference_concentration * continuum_rate_scale
        ),
        total_time_s=maximum_model_time_s,
        macro_time_step_s=(
            maximum_model_time_s / config.synchronization_steps()
        ),
        maximum_events=config.maximum_events,
    )
    derived = {
        **derived,
        "blanket_rate_input_nm_min": job.blanket_input.rate_nm_min,
        "literature_preset_rate_nm_min": preset.planar_rate_nm_min,
        "continuum_rate_scale_from_blanket_input": continuum_rate_scale,
        "planar_clear_time_s": planar_clear_time_s,
    }
    outcome = run_coupled_trench_kmc(
        grid,
        graph_config=graph_config,
        coupling_parameters=coupling,
        kmc_parameters=kinetics,
        spatial_etchability_parameters=spatial,
        seed=job.seed,
    )
    events = _removal_events(outcome)
    matrix_count = outcome.layout.matrix_site_count
    region_counts = _initial_region_counts(outcome)
    endpoints = [
        endpoint_from_removal_events(
            events,
            matrix_site_count=matrix_count,
            target_remaining_fraction=target,
            physical_seconds_per_model_second=clock_scale,
        )
        for target in config.target_remaining_fractions
    ]
    for endpoint in endpoints:
        endpoint["blanket_rate_uncertainty_interval"] = (
            _clock_uncertainty_interval(
                (
                    None
                    if endpoint["endpoint_physical_time_s"] is None
                    else float(endpoint["endpoint_physical_time_s"])
                ),
                job.blanket_input,
            )
        )
        if not endpoint["reached"]:
            endpoint["region_metrics_at_endpoint"] = None
            continue
        endpoint_state = _state_after_removal_count(
            events,
            removed_count=int(endpoint["removed_count_at_endpoint"]),
            matrix_site_count=matrix_count,
            initial_region_counts=region_counts,
        )
        endpoint["region_metrics_at_endpoint"] = endpoint_state["region_metrics"]
    final_physical_time = outcome.total_time_s * clock_scale
    fixed_probes = []
    for time_s in config.fixed_probe_times_s:
        within_horizon = time_s <= final_physical_time + 1.0e-9
        evaluated_time_s = min(time_s, final_physical_time)
        state = _state_at_physical_time(
            events,
            physical_time_s=evaluated_time_s,
            physical_seconds_per_model_second=clock_scale,
            matrix_site_count=matrix_count,
            initial_region_counts=region_counts,
        )
        state.update(
            {
                "requested_physical_time_s": time_s,
                "evaluated_physical_time_s": evaluated_time_s,
                "within_simulated_horizon": within_horizon,
                "censored_at_simulation_horizon": not within_horizon,
            }
        )
        fixed_probes.append(state)
    final_state = _state_after_removal_count(
        events,
        removed_count=len(events),
        matrix_site_count=matrix_count,
        initial_region_counts=region_counts,
    )
    final_state.update(
        {
            "model_time_s": outcome.total_time_s,
            "physical_time_s": final_physical_time,
        }
    )
    snapshot_specs: list[tuple[dict[str, object], str, float]] = [
        (
            state,
            f"fixed_{float(state['requested_physical_time_s']):g}s",
            float(state["requested_physical_time_s"]),
        )
        for state in fixed_probes
        if bool(state["within_simulated_horizon"])
    ]
    one_percent = next(
        (
            item
            for item in endpoints
            if math.isclose(
                float(item["target_remaining_fraction"]),
                0.01,
                rel_tol=0.0,
                abs_tol=1.0e-12,
            )
            and bool(item["reached"])
        ),
        None,
    )
    if one_percent is not None:
        one_percent_state = _state_after_removal_count(
            events,
            removed_count=int(one_percent["removed_count_at_endpoint"]),
            matrix_site_count=matrix_count,
            initial_region_counts=region_counts,
        )
        one_percent_time = float(one_percent["endpoint_physical_time_s"])
        one_percent_state["requested_physical_time_s"] = one_percent_time
        snapshot_specs.append(
            (one_percent_state, "target_1pct", one_percent_time)
        )
    snapshots = []
    for state, label, snapshot_time in snapshot_specs:
        snapshots.append(
            _snapshot(
                outcome,
                state["removed_site_ids"],
                physical_time_s=snapshot_time,
                label=label,
            )
        )
    for state in fixed_probes:
        state.pop("removed_site_ids", None)
    final_state.pop("removed_site_ids", None)
    all_hf_converged = all(
        bool(item["hf_converged"]) for item in outcome.sync_history
    )
    all_product_converged = all(
        bool(item["product_converged"]) for item in outcome.sync_history
    )
    maximum_event_budget_reached = outcome.stop_reason == "maximum_events"
    validity_reasons = []
    if not all_hf_converged:
        validity_reasons.append("hf_continuum_nonconvergence")
    if not all_product_converged:
        validity_reasons.append("product_continuum_nonconvergence")
    if not all_hf_converged or not all_product_converged:
        validity_level = "invalid"
    elif maximum_event_budget_reached:
        validity_level = "partial"
        validity_reasons.append("maximum_event_budget")
    else:
        validity_level = "valid"
    for endpoint in endpoints:
        if validity_level == "invalid":
            observation_status = "invalid"
        elif bool(endpoint["reached"]):
            observation_status = "observed"
        elif validity_level == "partial":
            observation_status = "budget_censored"
        else:
            observation_status = "right_censored"
        endpoint["observation_status"] = observation_status
        endpoint["censor_physical_time_s"] = (
            None if observation_status == "observed" else final_physical_time
        )
    for probe in fixed_probes:
        if validity_level == "invalid":
            observation_status = "invalid"
        elif bool(probe["within_simulated_horizon"]):
            observation_status = "observed"
        elif validity_level == "partial":
            observation_status = "budget_censored"
        else:
            observation_status = "right_censored"
        probe["observation_status"] = observation_status
    regional_clear_endpoints = {
        region_name: _regional_clear_endpoint(
            events,
            region_name=region_name,
            initial_region_count=region_counts[region_name],
            physical_seconds_per_model_second=clock_scale,
        )
        for region_name in ("sidewall", "bottom")
    }
    for endpoint in regional_clear_endpoints.values():
        endpoint["blanket_rate_uncertainty_interval"] = (
            _clock_uncertainty_interval(
                (
                    None
                    if endpoint["endpoint_physical_time_s"] is None
                    else float(endpoint["endpoint_physical_time_s"])
                ),
                job.blanket_input,
            )
        )
        if validity_level == "invalid":
            observation_status = "invalid"
        elif bool(endpoint["reached"]):
            observation_status = "observed"
        elif validity_level == "partial":
            observation_status = "budget_censored"
        else:
            observation_status = "right_censored"
        endpoint["observation_status"] = observation_status
        endpoint["censor_physical_time_s"] = (
            None if observation_status == "observed" else final_physical_time
        )

    return {
        "order": job.order,
        "case_id": (
            f"{job.geometry_id}__{job.preset_id}__{job.scenario}__"
            f"r{job.replicate_index}"
        ),
        "status": "ok",
        "result_validity": {
            "level": validity_level,
            "reasons": validity_reasons,
            "aggregate_eligible": validity_level == "valid",
            "observed_endpoint_eligible": validity_level != "invalid",
        },
        "geometry_id": job.geometry_id,
        "preset_id": job.preset_id,
        "material": get_literature_preset(job.preset_id).material,
        "scenario": job.scenario,
        "scenario_label_ja": SCENARIO_LABELS_JA[job.scenario],
        "replicate_index": job.replicate_index,
        "seed": job.seed,
        "blanket_anchor": job.blanket_input.to_dict(),
        "clock_calibration": {
            **dict(job.coupon),
            "blanket_velocity_nm_s": blanket_velocity,
            "physical_seconds_per_model_second": clock_scale,
            "calibration_equation": (
                "physical_seconds_per_model_second = "
                "native_coupon_velocity_nm_per_model_s / blanket_velocity_nm_s"
            ),
        },
        "planar_reference": {
            "planar_clear_time_s": planar_clear_time_s,
            "maximum_simulated_physical_time_s": maximum_physical_time_s,
            "maximum_time_over_planar_clear": (
                config.maximum_planar_clear_time_multiplier
            ),
        },
        "endpoints": endpoints,
        "regional_clear_endpoints": regional_clear_endpoints,
        "fixed_time_probes": fixed_probes,
        "final_state": final_state,
        "trace": _trace(
            events,
            physical_seconds_per_model_second=clock_scale,
            matrix_site_count=matrix_count,
            trace_points=config.trace_points,
        ),
        "snapshots": snapshots,
        "convergence": {
            "all_hf_synchronizations": all_hf_converged,
            "all_product_synchronizations": all_product_converged,
            "native_stop_reason": outcome.stop_reason,
            "maximum_event_budget_reached": maximum_event_budget_reached,
            "matrix_site_count": matrix_count,
            "removed_event_count": len(events),
        },
        "model_parameters": {
            "graph": asdict(graph_config),
            "coupling_native_clock": asdict(coupling),
            "kinetics_native_clock": asdict(kinetics),
            "spatial_etchability": spatial.to_dict(),
            "derived_conditions_before_clock_calibration": derived,
        },
    }


def _failed_job(job: _EndpointJob, exc: Exception) -> dict[str, object]:
    return {
        "order": job.order,
        "case_id": (
            f"{job.geometry_id}__{job.preset_id}__{job.scenario}__"
            f"r{job.replicate_index}"
        ),
        "status": "failed",
        "geometry_id": job.geometry_id,
        "preset_id": job.preset_id,
        "material": get_literature_preset(job.preset_id).material,
        "scenario": job.scenario,
        "replicate_index": job.replicate_index,
        "seed": job.seed,
        "error_type": type(exc).__name__,
        "error_message": str(exc),
    }


def _worker(job: _EndpointJob) -> dict[str, object]:
    try:
        return _run_endpoint_job(job)
    except Exception as exc:
        return _failed_job(job, exc)


def _worker_initializer() -> None:
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = "1"
    try:
        from threadpoolctl import threadpool_limits

        threadpool_limits(1)
    except ImportError:
        pass


def _execute(jobs: Sequence[_EndpointJob], workers: int) -> list[dict[str, object]]:
    if workers == 1:
        return [_worker(job) for job in jobs]
    with ProcessPoolExecutor(
        max_workers=min(workers, len(jobs)),
        initializer=_worker_initializer,
    ) as executor:
        chunksize = max(1, len(jobs) // max(1, workers * 8))
        return list(executor.map(_worker, jobs, chunksize=chunksize))


def _summary(values: Iterable[float]) -> dict[str, float | int | None]:
    array = np.asarray(list(values), dtype=float)
    if array.size == 0:
        return {
            "count": 0,
            "median": None,
            "minimum": None,
            "maximum": None,
        }
    return {
        "count": int(array.size),
        "median": float(np.median(array)),
        "minimum": float(np.min(array)),
        "maximum": float(np.max(array)),
    }


def _validity_level(case: Mapping[str, object]) -> str:
    validity = case.get("result_validity")
    if isinstance(validity, Mapping):
        return str(validity.get("level", "invalid"))
    return "valid" if case.get("status") == "ok" else "invalid"


def _uncertainty_summary(
    endpoints: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    intervals = [
        item["blanket_rate_uncertainty_interval"]
        for item in endpoints
        if isinstance(item.get("blanket_rate_uncertainty_interval"), Mapping)
    ]
    if not intervals:
        return {
            "count": 0,
            "median_lower_physical_time_s": None,
            "median_upper_physical_time_s": None,
            "envelope_lower_physical_time_s": None,
            "envelope_upper_physical_time_s": None,
            "propagation_method": None,
        }
    lower = [
        float(item["lower_physical_time_s"])
        for item in intervals
    ]
    upper = [
        float(item["upper_physical_time_s"])
        for item in intervals
    ]
    return {
        "count": len(intervals),
        "median_lower_physical_time_s": float(np.median(lower)),
        "median_upper_physical_time_s": float(np.median(upper)),
        "envelope_lower_physical_time_s": min(lower),
        "envelope_upper_physical_time_s": max(upper),
        "propagation_method": (
            "inverse_clock_fixed_native_trajectory; "
            "not_a_confidence_interval"
        ),
    }


def _aggregate(
    cases: Sequence[Mapping[str, object]],
    config: PrimaryHFEndpointConfig,
) -> list[dict[str, object]]:
    result = []
    for geometry_id in config.geometries:
        for preset_id in config.presets:
            for scenario in config.scenarios:
                executed_subset = [
                    case
                    for case in cases
                    if case.get("status") == "ok"
                    and case.get("geometry_id") == geometry_id
                    and case.get("preset_id") == preset_id
                    and case.get("scenario") == scenario
                ]
                valid_subset = [
                    case
                    for case in executed_subset
                    if _validity_level(case) == "valid"
                ]
                partial_subset = [
                    case
                    for case in executed_subset
                    if _validity_level(case) == "partial"
                ]
                invalid_subset = [
                    case
                    for case in executed_subset
                    if _validity_level(case) == "invalid"
                ]
                endpoint_subset = valid_subset + partial_subset
                endpoint_rows = []
                for target in config.target_remaining_fractions:
                    matches = [
                        endpoint
                        for case in endpoint_subset
                        for endpoint in case["endpoints"]
                        if math.isclose(
                            float(endpoint["target_remaining_fraction"]),
                            target,
                            rel_tol=0.0,
                            abs_tol=1.0e-12,
                        )
                    ]
                    reached = [
                        item
                        for item in matches
                        if item.get("observation_status") == "observed"
                        or (
                            "observation_status" not in item
                            and bool(item["reached"])
                        )
                    ]
                    all_target_rows = [
                        endpoint
                        for case in executed_subset
                        for endpoint in case["endpoints"]
                        if math.isclose(
                            float(endpoint["target_remaining_fraction"]),
                            target,
                            rel_tol=0.0,
                            abs_tol=1.0e-12,
                        )
                    ]
                    endpoint_rows.append(
                        {
                            "target_remaining_fraction": target,
                            "requested_replicates": len(config.replicate_seeds),
                            "successful_case_replicates": len(executed_subset),
                            "valid_replicates": len(valid_subset),
                            "partial_replicates": len(partial_subset),
                            "invalid_replicates": len(invalid_subset),
                            "reached_replicates": len(reached),
                            "observed_replicates": len(reached),
                            "right_censored_replicates": sum(
                                item.get("observation_status")
                                == "right_censored"
                                for item in all_target_rows
                            ),
                            "budget_censored_replicates": sum(
                                item.get("observation_status")
                                == "budget_censored"
                                for item in all_target_rows
                            ),
                            "physical_time_s": _summary(
                                float(item["endpoint_physical_time_s"])
                                for item in reached
                            ),
                            "blanket_rate_uncertainty_time_s": (
                                _uncertainty_summary(reached)
                            ),
                        }
                    )
                fixed_rows = []
                for probe_time in config.fixed_probe_times_s:
                    probes = [
                        probe
                        for case in valid_subset
                        for probe in case["fixed_time_probes"]
                        if math.isclose(
                            float(probe["requested_physical_time_s"]),
                            probe_time,
                            rel_tol=0.0,
                            abs_tol=1.0e-12,
                        )
                        and bool(probe.get("within_simulated_horizon", True))
                    ]
                    fixed_rows.append(
                        {
                            "physical_time_s": probe_time,
                            "remaining_fraction": _summary(
                                float(item["remaining_fraction"]) for item in probes
                            ),
                            "bottom_remaining_fraction": _summary(
                                float(item["region_metrics"]["bottom"]["remaining_fraction"])
                                for item in probes
                            ),
                            "sidewall_remaining_fraction": _summary(
                                float(
                                    item["region_metrics"]["sidewall"][
                                        "remaining_fraction"
                                    ]
                                )
                                for item in probes
                            ),
                        }
                    )
                regional_clear = {}
                for region_name in ("sidewall", "bottom"):
                    rows = [
                        case["regional_clear_endpoints"][region_name]
                        for case in endpoint_subset
                    ]
                    reached = [
                        item
                        for item in rows
                        if item.get("observation_status") == "observed"
                        or (
                            "observation_status" not in item
                            and bool(item["reached"])
                        )
                    ]
                    regional_clear[region_name] = {
                        "requested_replicates": len(config.replicate_seeds),
                        "successful_case_replicates": len(rows),
                        "reached_replicates": len(reached),
                        "physical_time_s": _summary(
                            float(item["endpoint_physical_time_s"])
                            for item in reached
                        ),
                        "blanket_rate_uncertainty_time_s": (
                            _uncertainty_summary(reached)
                        ),
                    }
                result.append(
                    {
                        "geometry_id": geometry_id,
                        "preset_id": preset_id,
                        "material": get_literature_preset(preset_id).material,
                        "scenario": scenario,
                        "scenario_label_ja": SCENARIO_LABELS_JA[scenario],
                        "successful_replicates": len(executed_subset),
                        "valid_replicates": len(valid_subset),
                        "partial_replicates": len(partial_subset),
                        "invalid_replicates": len(invalid_subset),
                        "endpoint_summaries": endpoint_rows,
                        "regional_clear_summaries": regional_clear,
                        "fixed_time_summaries": fixed_rows,
                        "final_remaining_fraction": _summary(
                            float(case["final_state"]["remaining_fraction"])
                            for case in valid_subset
                        ),
                    }
                )
    return result


def _planar_anchor_summary(
    config: PrimaryHFEndpointConfig,
) -> list[dict[str, object]]:
    rows = []
    for geometry_id in config.geometries:
        geometry = GEOMETRY_PRESETS[geometry_id]
        for preset_id in config.presets:
            anchor = config.blanket_input(preset_id)
            time_s = geometry.depth_nm / anchor.rate_nm_s
            uncertainty = anchor.uncertainty_nm_min
            if uncertainty is None:
                time_interval = None
            else:
                low_rate = (anchor.rate_nm_min - uncertainty) / 60.0
                high_rate = (anchor.rate_nm_min + uncertainty) / 60.0
                time_interval = {
                    "basis": "blanket_rate_plus_or_minus_reported_uncertainty",
                    "clear_time_low_s": geometry.depth_nm / high_rate,
                    "clear_time_high_s": geometry.depth_nm / low_rate,
                }
            rows.append(
                {
                    "geometry_id": geometry_id,
                    "preset_id": preset_id,
                    "material": get_literature_preset(preset_id).material,
                    "depth_nm": geometry.depth_nm,
                    "blanket_anchor": anchor.to_dict(),
                    "planar_clear_time_s": time_s,
                    "reported_rate_uncertainty_time_interval": time_interval,
                }
            )
    return rows


def run_primary_hf_endpoint_calibration(
    config: PrimaryHFEndpointConfig = PrimaryHFEndpointConfig(),
) -> dict[str, object]:
    """Run paired blanket coupons and full-trench endpoint trajectories."""

    coupons: dict[tuple[str, int], dict[str, object]] = {}
    coupon_failures: list[dict[str, object]] = []
    placeholder_config = _process_config(config, 1.0)
    for preset_index, preset_id in enumerate(config.presets):
        preset = get_literature_preset(preset_id)
        blanket_input = config.blanket_input(preset_id)
        for replicate_index, base_seed in enumerate(config.replicate_seeds):
            seed = int(base_seed) + 100_003 * preset_index
            spec = ProcessCaseSpec(
                order=0,
                case_group="blanket_coupon",
                design_index=0,
                geometry_id=config.geometries[0],
                preset_id=preset_id,
                replicate_index=replicate_index,
                seed=seed,
                parameters=_primary_parameters(config),
            )
            try:
                _, _, _, kinetics, _, _ = _case_objects(spec, placeholder_config)
                coupon = run_blanket_coupon(
                    preset,
                    kinetics,
                    seed=seed,
                    spacing_nm=config.grid_spacing_nm,
                    width_nm=config.coupon_width_nm,
                    depth_nm=config.coupon_depth_nm,
                    start_removed_fraction=(
                        config.coupon_measurement_start_removed_fraction
                    ),
                    end_removed_fraction=(
                        config.coupon_measurement_end_removed_fraction
                    ),
                    maximum_events=config.coupon_maximum_events,
                    environment_temperature_K=(
                        blanket_input.normalization_temperature_K
                    ),
                )
                coupons[(preset_id, replicate_index)] = coupon
            except Exception as exc:
                coupon_failures.append(
                    {
                        "preset_id": preset_id,
                        "replicate_index": replicate_index,
                        "seed": seed,
                        "error_type": type(exc).__name__,
                        "error_message": str(exc),
                    }
                )

    jobs: list[_EndpointJob] = []
    for geometry_id in config.geometries:
        for preset_index, preset_id in enumerate(config.presets):
            for scenario in config.scenarios:
                for replicate_index, base_seed in enumerate(config.replicate_seeds):
                    coupon = coupons.get((preset_id, replicate_index))
                    if coupon is None:
                        continue
                    jobs.append(
                        _EndpointJob(
                            order=len(jobs),
                            geometry_id=geometry_id,
                            preset_id=preset_id,
                            scenario=scenario,
                            replicate_index=replicate_index,
                            seed=int(base_seed) + 100_003 * preset_index,
                            blanket_input=config.blanket_input(preset_id),
                            coupon=coupon,
                            config=config,
                        )
                    )
    cases = _execute(jobs, config.parallel_workers) if jobs else []
    cases.sort(key=lambda item: int(item["order"]))
    failed = [case for case in cases if case.get("status") != "ok"]
    executed = [case for case in cases if case.get("status") == "ok"]
    valid = [case for case in executed if _validity_level(case) == "valid"]
    partial = [
        case for case in executed if _validity_level(case) == "partial"
    ]
    invalid = [
        case for case in executed if _validity_level(case) == "invalid"
    ]
    expected_jobs = (
        len(config.geometries)
        * len(config.presets)
        * len(config.scenarios)
        * len(config.replicate_seeds)
    )
    custom_count = sum(
        config.blanket_input(preset_id).source_kind == "experimental_blanket"
        for preset_id in config.presets
    )
    if custom_count == 0:
        calibration_status = "literature_prior"
    elif custom_count == len(config.presets):
        calibration_status = "blanket_calibrated"
    else:
        calibration_status = "mixed_literature_and_blanket_inputs"
    payload = {
        "schema_version": SCHEMA_VERSION,
        "model_name": "blanket-WER-anchored primary-HF endpoint calibration",
        "notice": MODEL_NOTICE,
        "calibration_status": {
            "level": calibration_status,
            "trench_cross_section_fitted": False,
            "holdout_validated": False,
        },
        "config": config.to_dict(),
        "blanket_inputs": {
            preset_id: config.blanket_input(preset_id).to_dict()
            for preset_id in config.presets
        },
        "planar_anchor_summary": _planar_anchor_summary(config),
        "coupon_calibrations": [
            coupons[key] for key in sorted(coupons)
        ],
        "coupon_failures": coupon_failures,
        "cases": cases,
        "aggregates": _aggregate(cases, config),
        "parallel_execution": {
            "backend": "ProcessPoolExecutor",
            "workers": config.parallel_workers,
            "case_order_preserved": True,
            "worker_numeric_thread_limit_requested": 1,
        },
        "quality_summary": {
            "expected_coupon_runs": len(config.presets)
            * len(config.replicate_seeds),
            "successful_coupon_runs": len(coupons),
            "failed_coupon_runs": len(coupon_failures),
            "expected_trench_runs": expected_jobs,
            "requested_trench_runs_after_coupon_failures": len(jobs),
            "successful_trench_runs": len(executed),
            "valid_trench_runs": len(valid),
            "partial_trench_runs": len(partial),
            "invalid_trench_runs": len(invalid),
            "failed_trench_runs": len(failed),
            "failed_case_ids": [str(case["case_id"]) for case in failed],
            "partial_case_ids": [
                str(case["case_id"]) for case in partial
            ],
            "invalid_case_ids": [
                str(case["case_id"]) for case in invalid
            ],
            "hf_nonconverged_runs": sum(
                not bool(case["convergence"]["all_hf_synchronizations"])
                for case in executed
            ),
            "product_nonconverged_runs": sum(
                not bool(case["convergence"]["all_product_synchronizations"])
                for case in executed
            ),
            "maximum_event_budget_runs": sum(
                bool(case["convergence"]["maximum_event_budget_reached"])
                for case in executed
            ),
        },
        "model_limitations": {
            "blanket_anchor": (
                "Literature blanket rates are different deposited films, not "
                "a confidence band for one production film. User blanket CSV "
                "values should replace them before recipe selection. A user "
                "rate rescales the continuum HF sink, product source and "
                "product reference together with the clock anchor."
            ),
            "coupon": (
                "The planar coupon shares the trench event templates and grid "
                "scale, but is a finite mesoscopic strip rather than an "
                "atomistically resolved blanket film."
            ),
            "passivation": (
                "The passivation hypothesis preserves dimensionless legacy "
                "rate ratios; no stage-resolved experiment has fitted them."
            ),
            "continuum_product": (
                "Product source strength is literature-WER anchored and "
                "quasi-steady; it is not a measured transient liquid inventory."
            ),
            "temperature": (
                "The blanket anchor is not empirically temperature-corrected. "
                "Separate liquid/substrate temperatures affect the local "
                "thermal/KMC modifier relative to the reported/user blanket "
                "measurement temperature. Experimental blanket inputs require "
                "that temperature; literature inputs without one retain an "
                "explicit 298.15 K modelling convention. HF speciation and "
                "continuum diffusivities remain at their preset reference "
                "values during a temperature sweep, while the interface "
                "sink/source remains anchored to the blanket-rate input; such "
                "a sweep is therefore a sensitivity study, not a predictive "
                "temperature law."
            ),
            "blanket_rate_uncertainty": (
                "Reported blanket-rate uncertainty is mapped inversely to "
                "endpoint time while holding the central relative KMC "
                "trajectory fixed. Bounds are input-rate mappings, not a "
                "confidence interval, and the continuum is not rerun at the "
                "rate bounds."
            ),
            "SiOCN": (
                "SiOCN rate derives from a 60 s sub-nm patent loss; bath stock "
                "concentration, temperature and uncertainty are unavailable."
            ),
            "endpoint_precision": (
                "Endpoint times are exact KMC event crossings. Remaining "
                "fractions cannot resolve below one matrix site."
            ),
            "recipe_boundary": (
                "No Si/liner loss, CD loss, roughness, or experimentally "
                "validated residue detection limit is included."
            ),
        },
        "artifacts": {},
    }
    json.dumps(payload, ensure_ascii=False, allow_nan=False)
    return payload


def save_primary_hf_endpoint_json(
    payload: Mapping[str, object], path: str | Path
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    return target


def save_primary_hf_endpoint_csv(
    payload: Mapping[str, object], path: str | Path
) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = (
        "case_id",
        "status",
        "result_validity",
        "geometry_id",
        "preset_id",
        "material",
        "scenario",
        "replicate_index",
        "seed",
        "target_remaining_fraction",
        "target_reached",
        "observation_status",
        "censor_physical_time_s",
        "endpoint_physical_time_s",
        "blanket_rate_time_lower_s",
        "blanket_rate_time_upper_s",
        "achieved_remaining_fraction",
        "previous_remaining_fraction",
        "discrete_fraction_resolution",
        "bottom_remaining_fraction_at_endpoint",
        "sidewall_remaining_fraction_at_endpoint",
        "planar_clear_time_s",
        "physical_seconds_per_model_second",
        "native_stop_reason",
        "error_type",
        "error_message",
    )
    cases = payload.get("cases", [])
    with target.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for case in cases if isinstance(cases, Sequence) else []:
            if not isinstance(case, Mapping):
                continue
            endpoints = case.get("endpoints", [])
            if case.get("status") != "ok":
                writer.writerow(
                    {
                        key: case.get(key, "")
                        for key in fields
                    }
                )
                continue
            for endpoint in endpoints if isinstance(endpoints, Sequence) else []:
                if not isinstance(endpoint, Mapping):
                    continue
                region_metrics = endpoint.get("region_metrics_at_endpoint")
                region_metrics = (
                    region_metrics if isinstance(region_metrics, Mapping) else {}
                )
                uncertainty = endpoint.get(
                    "blanket_rate_uncertainty_interval"
                )
                uncertainty = (
                    uncertainty if isinstance(uncertainty, Mapping) else {}
                )
                bottom = region_metrics.get("bottom", {})
                sidewall = region_metrics.get("sidewall", {})
                writer.writerow(
                    {
                        "case_id": case.get("case_id", ""),
                        "status": case.get("status", ""),
                        "result_validity": _validity_level(case),
                        "geometry_id": case.get("geometry_id", ""),
                        "preset_id": case.get("preset_id", ""),
                        "material": case.get("material", ""),
                        "scenario": case.get("scenario", ""),
                        "replicate_index": case.get("replicate_index", ""),
                        "seed": case.get("seed", ""),
                        "target_remaining_fraction": endpoint.get(
                            "target_remaining_fraction", ""
                        ),
                        "target_reached": endpoint.get("reached", ""),
                        "observation_status": endpoint.get(
                            "observation_status", ""
                        ),
                        "censor_physical_time_s": endpoint.get(
                            "censor_physical_time_s", ""
                        ),
                        "endpoint_physical_time_s": endpoint.get(
                            "endpoint_physical_time_s", ""
                        ),
                        "blanket_rate_time_lower_s": uncertainty.get(
                            "lower_physical_time_s", ""
                        ),
                        "blanket_rate_time_upper_s": uncertainty.get(
                            "upper_physical_time_s", ""
                        ),
                        "achieved_remaining_fraction": endpoint.get(
                            "achieved_remaining_fraction", ""
                        ),
                        "previous_remaining_fraction": endpoint.get(
                            "previous_remaining_fraction", ""
                        ),
                        "discrete_fraction_resolution": endpoint.get(
                            "discrete_fraction_resolution", ""
                        ),
                        "bottom_remaining_fraction_at_endpoint": (
                            bottom.get("remaining_fraction", "")
                            if isinstance(bottom, Mapping)
                            else ""
                        ),
                        "sidewall_remaining_fraction_at_endpoint": (
                            sidewall.get("remaining_fraction", "")
                            if isinstance(sidewall, Mapping)
                            else ""
                        ),
                        "planar_clear_time_s": case["planar_reference"].get(
                            "planar_clear_time_s", ""
                        ),
                        "physical_seconds_per_model_second": case[
                            "clock_calibration"
                        ].get("physical_seconds_per_model_second", ""),
                        "native_stop_reason": case["convergence"].get(
                            "native_stop_reason", ""
                        ),
                        "error_type": "",
                        "error_message": "",
                    }
                )
    return target


__all__ = [
    "BlanketRateInput",
    "CalibratedPrimaryHFHandoff",
    "MODEL_NOTICE",
    "PrimaryHFEndpointConfig",
    "SCENARIO_LABELS_JA",
    "SCHEMA_VERSION",
    "endpoint_from_removal_events",
    "literature_blanket_input",
    "load_blanket_rate_csv",
    "run_blanket_coupon",
    "run_calibrated_primary_hf_to_endpoint",
    "run_primary_hf_endpoint_calibration",
    "save_primary_hf_endpoint_csv",
    "save_primary_hf_endpoint_json",
]

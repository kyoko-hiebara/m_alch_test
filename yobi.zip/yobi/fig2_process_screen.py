"""Blanket-equivalent process screen derived from Kawarazaki et al. Fig. 2.

The screen answers a deliberately narrow question: under the user-approved
linear scaling assumption, how long would dHF-only removal take, and how many
fixed ozone-bake/dHF cycles would be needed to clear a specified residual film
thickness?  The paired SiN endpoint is propagated as a blanket selectivity
cost.

This is not a patterned-feature model.  Ozone delivery into a trench, cycle
saturation, incubation, purge/rinse time, and within-wafer variability are not
encoded here.
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

from literature_parameters import (
    KAWARAZAKI_2024_FIG2_ENDPOINTS,
    get_cyclic_etch_endpoint,
)


SCHEMA_VERSION = "kawarazaki-fig2-process-screen/v1"
SIN_REFERENCE_ENDPOINT_ID = "kawarazaki_sin_reference"
DEFAULT_TARGET_ENDPOINT_IDS = tuple(
    endpoint_id
    for endpoint_id, endpoint in KAWARAZAKI_2024_FIG2_ENDPOINTS.items()
    if endpoint.material != "SiN"
)
MODEL_NOTICE = (
    "Blanket-equivalent screening calculation, not a process recipe. "
    "The single 30 s dHF endpoint is assumed linear in time and the fixed "
    "30 s ozone-bake + 30 s dHF endpoint is assumed linear in integer cycle "
    "count by user request. Ozone penetration, saturation, incubation, "
    "pattern loading, uncertainty, damage, purge/rinse, and transfer time are "
    "not modelled."
)


def _rounded(value: float) -> float:
    return round(float(value), 12)


@dataclass(frozen=True)
class Fig2ProcessScreenConfig:
    target_endpoint_ids: tuple[str, ...] = DEFAULT_TARGET_ENDPOINT_IDS
    residual_thicknesses_nm: tuple[float, ...] = (0.5, 1.0, 2.0, 5.0, 10.0)
    sin_reference_endpoint_id: str = SIN_REFERENCE_ENDPOINT_ID
    reported_cycle_range_max: int = 3

    def __post_init__(self) -> None:
        if not self.target_endpoint_ids:
            raise ValueError("target_endpoint_ids cannot be empty")
        unknown = set(self.target_endpoint_ids).difference(
            KAWARAZAKI_2024_FIG2_ENDPOINTS
        )
        if unknown:
            raise ValueError(f"unknown target_endpoint_ids: {sorted(unknown)}")
        if len(set(self.target_endpoint_ids)) != len(self.target_endpoint_ids):
            raise ValueError("target_endpoint_ids cannot contain duplicates")
        if self.sin_reference_endpoint_id not in (
            KAWARAZAKI_2024_FIG2_ENDPOINTS
        ):
            raise ValueError("unknown sin_reference_endpoint_id")
        reference = get_cyclic_etch_endpoint(
            self.sin_reference_endpoint_id
        )
        if reference.material != "SiN":
            raise ValueError("sin_reference_endpoint_id must identify SiN")
        if self.sin_reference_endpoint_id in self.target_endpoint_ids:
            raise ValueError("SiN reference cannot also be a target endpoint")
        for endpoint_id in self.target_endpoint_ids:
            if get_cyclic_etch_endpoint(endpoint_id).material == "SiN":
                raise ValueError("target endpoints must not identify SiN")
        if not self.residual_thicknesses_nm:
            raise ValueError("residual_thicknesses_nm cannot be empty")
        thicknesses = tuple(float(value) for value in self.residual_thicknesses_nm)
        if any(
            not math.isfinite(value) or value <= 0.0
            for value in thicknesses
        ):
            raise ValueError(
                "residual_thicknesses_nm must be finite and positive"
            )
        if len(set(thicknesses)) != len(thicknesses):
            raise ValueError(
                "residual_thicknesses_nm cannot contain duplicates"
            )
        if (
            not isinstance(self.reported_cycle_range_max, int)
            or self.reported_cycle_range_max < 1
        ):
            raise ValueError(
                "reported_cycle_range_max must be a positive integer"
            )
        object.__setattr__(
            self, "target_endpoint_ids", tuple(self.target_endpoint_ids)
        )
        object.__setattr__(
            self, "residual_thicknesses_nm", thicknesses
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["target_endpoint_ids"] = list(self.target_endpoint_ids)
        result["residual_thicknesses_nm"] = list(
            self.residual_thicknesses_nm
        )
        return result


def _minimum_cycles(thickness_nm: float, etch_per_cycle_nm: float) -> int:
    if etch_per_cycle_nm <= 0.0:
        raise ValueError("etch_per_cycle_nm must be positive")
    # The tolerance avoids turning an exact floating-point multiple into one
    # extra cycle.
    scaled = thickness_nm / etch_per_cycle_nm
    return max(1, int(math.ceil(scaled - 1.0e-12)))


def _resolution_interval(
    amount_nm: float,
    resolution_nm: float,
) -> tuple[float, float]:
    """Return a non-statistical +/- one-raster-resolution sensitivity span."""

    return (
        max(0.0, amount_nm - resolution_nm),
        amount_nm + resolution_nm,
    )


def _target_case(
    endpoint_id: str,
    config: Fig2ProcessScreenConfig,
) -> dict[str, object]:
    endpoint = get_cyclic_etch_endpoint(endpoint_id)
    sin_reference = get_cyclic_etch_endpoint(
        config.sin_reference_endpoint_id
    )
    target_per_cycle = endpoint.ozone_then_dhf_etch_amount_nm
    sin_per_cycle = sin_reference.ozone_then_dhf_etch_amount_nm
    target_reported_cycle_max = min(
        endpoint.reported_cycle_linearity_max,
        config.reported_cycle_range_max,
    )
    sin_reported_cycle_max = sin_reference.reported_cycle_linearity_max
    if target_per_cycle <= 0.0 or sin_per_cycle <= 0.0:
        raise ValueError("target and SiN cycle endpoints must be positive")

    rows: list[dict[str, object]] = []
    for residual_thickness_nm in config.residual_thicknesses_nm:
        cycles = _minimum_cycles(residual_thickness_nm, target_per_cycle)
        target_cycle_low, target_cycle_high = _resolution_interval(
            target_per_cycle,
            endpoint.digitization_resolution_nm,
        )
        minimum_cycles_at_resolution = _minimum_cycles(
            residual_thickness_nm, target_cycle_high
        )
        maximum_cycles_at_resolution = (
            None
            if target_cycle_low == 0.0
            else _minimum_cycles(residual_thickness_nm, target_cycle_low)
        )
        target_dhf_low, target_dhf_high = _resolution_interval(
            endpoint.dhf_only_etch_amount_nm,
            endpoint.digitization_resolution_nm,
        )
        target_dhf_rate_low = (
            target_dhf_low * 60.0 / endpoint.dhf_duration_s
        )
        target_dhf_rate_high = (
            target_dhf_high * 60.0 / endpoint.dhf_duration_s
        )
        earliest_hf_clear_time_min = (
            residual_thickness_nm / target_dhf_rate_high
        )
        latest_hf_clear_time_min = (
            None
            if target_dhf_rate_low == 0.0
            else residual_thickness_nm / target_dhf_rate_low
        )
        sin_cycle_low, sin_cycle_high = _resolution_interval(
            sin_per_cycle,
            sin_reference.digitization_resolution_nm,
        )
        sin_dhf_low, sin_dhf_high = _resolution_interval(
            sin_reference.dhf_only_etch_amount_nm,
            sin_reference.digitization_resolution_nm,
        )
        sin_dhf_rate_low = (
            sin_dhf_low * 60.0 / sin_reference.dhf_duration_s
        )
        sin_dhf_rate_high = (
            sin_dhf_high * 60.0 / sin_reference.dhf_duration_s
        )
        target_total = _rounded(cycles * target_per_cycle)
        paired_dhf = _rounded(
            cycles * endpoint.dhf_only_etch_amount_nm
        )
        ozone_enabled = _rounded(
            cycles * endpoint.ozone_enabled_increment_nm_per_cycle
        )
        sin_loss = _rounded(cycles * sin_per_cycle)
        active_step_time_s = _rounded(
            cycles
            * (
                endpoint.ozone_bake_duration_s
                + endpoint.dhf_duration_s
            )
        )
        hf_only_time_min = _rounded(
            residual_thickness_nm
            / endpoint.dhf_only_apparent_rate_nm_min
        )
        hf_only_sin_loss = _rounded(
            hf_only_time_min
            * sin_reference.dhf_only_apparent_rate_nm_min
        )
        maximum_hf_sin_loss_at_resolution = (
            None
            if latest_hf_clear_time_min is None
            else _rounded(latest_hf_clear_time_min * sin_dhf_rate_high)
        )
        maximum_cycle_sin_loss_at_resolution = (
            None
            if maximum_cycles_at_resolution is None
            else _rounded(maximum_cycles_at_resolution * sin_cycle_high)
        )
        rows.append(
            {
                "residual_thickness_nm": residual_thickness_nm,
                "dhf_only_clear_time_min": hf_only_time_min,
                "dhf_only_clear_time_s": _rounded(
                    60.0 * hf_only_time_min
                ),
                "dhf_only_sin_reference_loss_nm": hf_only_sin_loss,
                "dhf_only_target_to_sin_selectivity": _rounded(
                    endpoint.dhf_only_apparent_rate_nm_min
                    / sin_reference.dhf_only_apparent_rate_nm_min
                ),
                "dhf_only_raster_resolution_sensitivity": {
                    "earliest_clear_time_min": _rounded(
                        earliest_hf_clear_time_min
                    ),
                    "latest_clear_time_min": (
                        None
                        if latest_hf_clear_time_min is None
                        else _rounded(latest_hf_clear_time_min)
                    ),
                    "finite_latest_clear_time": (
                        latest_hf_clear_time_min is not None
                    ),
                    "minimum_sin_reference_loss_nm": _rounded(
                        earliest_hf_clear_time_min * sin_dhf_rate_low
                    ),
                    "maximum_sin_reference_loss_nm": (
                        maximum_hf_sin_loss_at_resolution
                    ),
                },
                "minimum_fixed_cycles": cycles,
                "fixed_cycle_active_step_time_s": active_step_time_s,
                "fixed_cycle_active_step_time_min": _rounded(
                    active_step_time_s / 60.0
                ),
                "target_predicted_total_etch_nm": target_total,
                "target_clearance_margin_nm": _rounded(
                    target_total - residual_thickness_nm
                ),
                "target_paired_dhf_baseline_nm": paired_dhf,
                "target_ozone_enabled_increment_nm": ozone_enabled,
                "target_decomposition_residual_nm": _rounded(
                    target_total - paired_dhf - ozone_enabled
                ),
                "sin_reference_predicted_loss_nm": sin_loss,
                "fixed_cycle_raster_resolution_sensitivity": {
                    "minimum_cycles": minimum_cycles_at_resolution,
                    "maximum_cycles": maximum_cycles_at_resolution,
                    "finite_maximum_cycles": (
                        maximum_cycles_at_resolution is not None
                    ),
                    "minimum_sin_reference_loss_nm": _rounded(
                        minimum_cycles_at_resolution * sin_cycle_low
                    ),
                    "maximum_sin_reference_loss_nm": (
                        maximum_cycle_sin_loss_at_resolution
                    ),
                },
                "cleared_target_thickness_to_sin_loss_ratio": _rounded(
                    residual_thickness_nm / sin_loss
                ),
                "endpoint_target_to_sin_selectivity": _rounded(
                    target_per_cycle / sin_per_cycle
                ),
                "dhf_only_to_fixed_active_time_ratio": _rounded(
                    60.0 * hf_only_time_min / active_step_time_s
                ),
                "target_cycle_count_within_fig4_observed_range": (
                    cycles <= target_reported_cycle_max
                ),
                "target_cycle_count_extrapolated": (
                    cycles > target_reported_cycle_max
                ),
                "target_fixed_30s_sequence_directly_supported": (
                    cycles <= 1
                ),
                "target_fixed_30s_cycle_scaling_is_assumption": (
                    cycles > 1
                ),
                "sin_reference_cycle_count_supported_by_source": (
                    cycles <= sin_reported_cycle_max
                ),
                "sin_reference_cycle_count_extrapolated": (
                    cycles > sin_reported_cycle_max
                ),
                "joint_target_and_sin_cycle_count_supported_by_source": (
                    cycles
                    <= min(target_reported_cycle_max, sin_reported_cycle_max)
                ),
            }
        )

    return {
        "endpoint_id": endpoint_id,
        "material": endpoint.material,
        "film_description": endpoint.film_description,
        "nominal_carbon_percent": endpoint.nominal_carbon_percent,
        "digitization_resolution_nm": endpoint.digitization_resolution_nm,
        "dhf_only_apparent_rate_nm_min": (
            endpoint.dhf_only_apparent_rate_nm_min
        ),
        "ozone_then_dhf_etch_nm_per_fixed_cycle": target_per_cycle,
        "ozone_enabled_increment_nm_per_cycle": (
            endpoint.ozone_enabled_increment_nm_per_cycle
        ),
        "reported_target_cycle_linearity_max": (
            endpoint.reported_cycle_linearity_max
        ),
        "endpoint_target_to_sin_selectivity": _rounded(
            target_per_cycle / sin_per_cycle
        ),
        "comparisons": rows,
    }


def run_fig2_process_screen(
    config: Fig2ProcessScreenConfig = Fig2ProcessScreenConfig(),
) -> dict[str, object]:
    sin_reference = get_cyclic_etch_endpoint(
        config.sin_reference_endpoint_id
    )
    cases = [
        _target_case(endpoint_id, config)
        for endpoint_id in config.target_endpoint_ids
    ]
    rows = [
        row
        for case in cases
        for row in case["comparisons"]
    ]
    maximum_decomposition_residual_nm = max(
        abs(float(row["target_decomposition_residual_nm"]))
        for row in rows
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "model": "Kawarazaki Fig. 2 blanket-equivalent process screen",
        "notice": MODEL_NOTICE,
        "config": config.to_dict(),
        "assumptions": {
            "dhf_only_time_linearity": True,
            "fixed_cycle_count_linearity": True,
            "ozone_delivery_is_uniform": True,
            "ozone_delivery_is_modelled_here": False,
            "cycle_saturation_or_incubation_modelled": False,
            "patterned_feature_validation": False,
            "fixed_active_time_excludes_purge_rinse_transfer": True,
            "sin_reference_is_paired_blanket_endpoint": True,
            "sin_reference_repeated_cycle_loss_reported": False,
            "fig4_ozone_bake_duration_reported": False,
            "fig4_cycle_count_range_validates_exact_fig2_30s_sequence": False,
            "raster_resolution_envelope_is_confidence_interval": False,
        },
        "sensitivity_envelope": {
            "definition": (
                "Each raster-digitized target and SiN bar is independently "
                "shifted by plus/minus one stored digitization resolution and "
                "clamped at zero. This is a numerical sensitivity envelope, "
                "not an experimental uncertainty or confidence interval."
            ),
            "zero_lower_endpoint_means_finite_clear_time_not_established": True,
        },
        "sin_reference": {
            "endpoint_id": config.sin_reference_endpoint_id,
            "film_description": sin_reference.film_description,
            "dhf_only_etch_amount_nm_per_30s": (
                sin_reference.dhf_only_etch_amount_nm
            ),
            "ozone_then_dhf_etch_nm_per_fixed_cycle": (
                sin_reference.ozone_then_dhf_etch_amount_nm
            ),
        },
        "quality": {
            "target_case_count": len(cases),
            "comparison_count": len(rows),
            "maximum_target_decomposition_residual_nm": (
                maximum_decomposition_residual_nm
            ),
            "strictly_algebraic_closure": (
                maximum_decomposition_residual_nm <= 1.0e-12
            ),
            "all_cycle_counts_positive": all(
                int(row["minimum_fixed_cycles"]) >= 1 for row in rows
            ),
            "dhf_cases_with_unbounded_resolution_floor": sum(
                not bool(
                    row["dhf_only_raster_resolution_sensitivity"][
                        "finite_latest_clear_time"
                    ]
                )
                for row in rows
            ),
        },
        "cases": cases,
    }


def save_fig2_process_screen_json(
    payload: dict[str, object],
    path: str | Path,
) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(
        payload,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    destination.write_text(text + "\n", encoding="utf-8")
    return destination


__all__ = [
    "DEFAULT_TARGET_ENDPOINT_IDS",
    "Fig2ProcessScreenConfig",
    "MODEL_NOTICE",
    "SCHEMA_VERSION",
    "SIN_REFERENCE_ENDPOINT_ID",
    "run_fig2_process_screen",
    "save_fig2_process_screen_json",
]

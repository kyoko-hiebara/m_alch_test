#!/usr/bin/env python3
"""Build the compact interactive process-window HTML fragment for Codex."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence


DEFAULT_OUTPUT = Path("results/process_window/process_window_inline_vis.html")


def _compact_payload(payload: dict[str, object]) -> dict[str, object]:
    sensitivity = payload["sensitivity"]
    assert isinstance(sensitivity, dict)

    def compact_sensitivity(source: dict[str, object]) -> dict[str, object]:
        metrics = source.get("metrics", {})
        assert isinstance(metrics, dict)
        result: dict[str, object] = {}
        for metric_name, metric_payload in metrics.items():
            assert isinstance(metric_payload, dict)
            rows = metric_payload.get("parameter_results", [])
            assert isinstance(rows, list)
            result[str(metric_name)] = [
                {
                    "parameter": row["parameter"],
                    "prcc": row["prcc"],
                    "ci_low": row["ci_low"],
                    "ci_high": row["ci_high"],
                }
                for row in rows
            ]
        return result

    strata = sensitivity.get("strata", {})
    assert isinstance(strata, dict)
    compact_phases: list[dict[str, object]] = []
    for phase in payload["phase_maps"]:
        assert isinstance(phase, dict)
        phase_strata: list[dict[str, object]] = []
        for stratum in phase["strata"]:
            assert isinstance(stratum, dict)
            phase_strata.append(
                {
                    "geometry_id": stratum["geometry_id"],
                    "preset_id": stratum["preset_id"],
                    "material": stratum["material"],
                    "dominant_class": stratum["dominant_class"],
                    "dominant_probability": stratum["dominant_probability"],
                    "failure_probability": stratum["failure_probability"],
                    "metric_medians": stratum["metric_medians"],
                }
            )
        compact_phases.append(
            {
                "pair_id": phase["pair_id"],
                "x_parameter": phase["x_parameter"],
                "y_parameter": phase["y_parameter"],
                "x_values": phase["x_values"],
                "y_values": phase["y_values"],
                "held_parameter_context": phase["held_parameter_context"],
                "strata": phase_strata,
            }
        )
    return {
        "notice": payload["notice"],
        "quality": payload["quality_summary"],
        "class_order": payload["class_order"],
        "class_labels_ja": payload["class_labels_ja"],
        "classification_counts": payload["classification_counts"],
        "sensitivity": {
            "pooled": compact_sensitivity(sensitivity),
            "strata": {
                key: compact_sensitivity(value)
                for key, value in strata.items()
                if isinstance(value, dict)
            },
        },
        "phase_maps": compact_phases,
        "replicate_seeds": payload["design"]["replicate_seeds"],
        "bounds_set": payload["design"]["bounds_set"],
    }


FRAGMENT = r'''
<meta charset="utf-8">
<section class="pw-app" aria-labelledby="pw-title">
  <style>
    .pw-app {
      --pw-bg: var(--color-background-primary, #f7f8fa);
      --pw-card: var(--color-background-secondary, #ffffff);
      --pw-text: var(--color-text-primary, #182028);
      --pw-muted: var(--color-text-secondary, #64707b);
      --pw-line: color-mix(in srgb, var(--pw-text) 18%, transparent);
      --pw-complete: #079b77;
      --pw-bottom: #e9a400;
      --pw-wall: #7352a6;
      --pw-deposit: #9a2458;
      color: var(--pw-text);
      background: var(--pw-bg);
      border: 1px solid var(--pw-line);
      border-radius: 16px;
      padding: clamp(12px, 2.4vw, 24px);
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.4;
      max-width: 1180px;
      margin: 0 auto;
      box-sizing: border-box;
    }
    @media (prefers-color-scheme: dark) {
      .pw-app {
        --pw-bg: var(--color-background-primary, #11161b);
        --pw-card: var(--color-background-secondary, #1a2128);
        --pw-text: var(--color-text-primary, #edf2f6);
        --pw-muted: var(--color-text-secondary, #aab5bf);
      }
    }
    .pw-app * { box-sizing: border-box; }
    .pw-head { display: grid; gap: 8px; margin-bottom: 16px; }
    .pw-head h2 { font-size: clamp(20px, 3vw, 30px); line-height: 1.15; margin: 0; }
    .pw-head p { margin: 0; color: var(--pw-muted); max-width: 85ch; font-size: 13px; }
    .pw-badges { display: flex; flex-wrap: wrap; gap: 7px; margin-top: 4px; }
    .pw-badge { background: var(--pw-card); border: 1px solid var(--pw-line); border-radius: 999px; padding: 5px 9px; font-size: 12px; }
    .pw-layout { display: grid; grid-template-columns: minmax(0, 1.15fr) minmax(280px, .85fr); gap: 14px; align-items: start; }
    .pw-card { background: var(--pw-card); border: 1px solid var(--pw-line); border-radius: 12px; padding: 14px; min-width: 0; }
    .pw-card h3 { margin: 0 0 10px; font-size: 15px; }
    .pw-controls { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 9px; margin-bottom: 12px; }
    .pw-controls label { display: grid; gap: 4px; color: var(--pw-muted); font-size: 11px; }
    .pw-controls select { width: 100%; min-width: 0; border: 1px solid var(--pw-line); border-radius: 8px; padding: 7px; background: var(--pw-bg); color: var(--pw-text); font: inherit; font-size: 12px; }
    .pw-scope-title, .pw-context { color: var(--pw-muted); font-size: 11px; margin: 4px 0 10px; }
    .pw-stack-row { display: grid; grid-template-columns: minmax(125px, 1fr) 2fr; gap: 8px; align-items: center; margin: 7px 0; font-size: 11px; }
    .pw-stack { height: 17px; display: flex; overflow: hidden; border-radius: 5px; background: color-mix(in srgb, var(--pw-text) 7%, transparent); }
    .pw-stack span { min-width: 0; }
    .pw-legend { display: flex; flex-wrap: wrap; gap: 9px 12px; margin: 9px 0 4px; font-size: 11px; color: var(--pw-muted); }
    .pw-legend span { display: inline-flex; align-items: center; gap: 5px; }
    .pw-dot { width: 10px; height: 10px; border-radius: 3px; display: inline-block; }
    .pw-grid-wrap { overflow-x: auto; padding-bottom: 3px; }
    .pw-phase-grid { display: grid; gap: 2px; min-width: 252px; }
    .pw-cell { aspect-ratio: 1; min-height: 31px; border-radius: 4px; display: grid; place-items: center; padding: 2px; font-size: 9px; font-weight: 700; color: white; text-shadow: 0 1px 2px rgba(0,0,0,.55); cursor: default; border: 1px solid rgba(255,255,255,.22); }
    .pw-axis { display: flex; justify-content: space-between; gap: 8px; color: var(--pw-muted); font-size: 10px; margin-top: 6px; }
    .pw-axis strong { color: var(--pw-text); font-weight: 600; }
    .pw-driver { display: grid; grid-template-columns: minmax(125px, 1fr) 2fr 42px; gap: 7px; align-items: center; margin: 6px 0; font-size: 10.5px; }
    .pw-driver-track { height: 14px; position: relative; border-radius: 4px; background: color-mix(in srgb, var(--pw-text) 7%, transparent); overflow: hidden; }
    .pw-driver-track::after { content:""; position:absolute; left:50%; top:0; bottom:0; width:1px; background: var(--pw-line); }
    .pw-driver-bar { position: absolute; top: 2px; bottom: 2px; border-radius: 3px; }
    .pw-driver-value { text-align: right; font-variant-numeric: tabular-nums; }
    .pw-note { margin-top: 12px; padding-top: 10px; border-top: 1px solid var(--pw-line); color: var(--pw-muted); font-size: 11px; }
    @media (max-width: 760px) { .pw-layout { grid-template-columns: 1fr; } }
    @media (max-width: 430px) { .pw-app { padding: 10px; border-radius: 10px; } .pw-controls { grid-template-columns: 1fr; } .pw-stack-row, .pw-driver { grid-template-columns: 1fr; gap: 3px; } .pw-driver-value { text-align: left; } }
  </style>

  <header class="pw-head">
    <h2 id="pw-title">GAP-FILL WET process-window explorer</h2>
    <p>実寸straight trenchのcontinuum / graph-KMC screening。色は「完全除去・底残り・壁残り・析出残り」、数値表示へ切り替えると連続残渣率を確認できます。</p>
    <div class="pw-badges" id="pw-badges"></div>
  </header>

  <div class="pw-layout">
    <div class="pw-card">
      <h3>Phase map</h3>
      <div class="pw-controls">
        <label>形状 / 材料<select id="pw-scope"></select></label>
        <label>変数対<select id="pw-pair"></select></label>
        <label>表示<select id="pw-view"></select></label>
        <label>感度metric<select id="pw-metric"></select></label>
      </div>
      <div class="pw-context" id="pw-context"></div>
      <div class="pw-grid-wrap"><div class="pw-phase-grid" id="pw-grid"></div></div>
      <div class="pw-axis" id="pw-axis"></div>
      <div class="pw-legend" id="pw-legend"></div>
    </div>

    <div class="pw-card">
      <h3>Global class balance</h3>
      <div id="pw-counts"></div>
      <div class="pw-legend" id="pw-count-legend"></div>
      <h3 style="margin-top:16px">PRCC drivers</h3>
      <div class="pw-scope-title" id="pw-driver-title"></div>
      <div id="pw-drivers"></div>
    </div>
  </div>
  <div class="pw-note">Screening only—not a process recipe. Quick mode uses one KMC seed, so phase probabilities are 0/1. SiN/SiOCN graph prefactors use the relative literature blanket-WER ratio; the absolute graph clock, dry-down capture and second-WET rates remain uncalibrated.</div>

  <script>
  (() => {
    const DATA = __DATA__;
    const COLORS = {complete_removal:'#079b77',bottom_residue:'#e9a400',wall_residue:'#7352a6',precipitation_residue:'#9a2458',failed:'#777'};
    const SHORT = {complete_removal:'C',bottom_residue:'B',wall_residue:'W',precipitation_residue:'P',failed:'×'};
    const METRIC_LABELS = {
      total_remaining_fraction:'元膜・全残渣率', bottom_remaining_fraction:'底部残渣率', wall_remaining_fraction:'壁部残渣率',
      deposit_fraction:'析出collector率', wall_deposit_fraction:'wall析出率'
    };
    const $ = id => document.getElementById(id);
    const fmt = value => {
      const v = Number(value); if (!Number.isFinite(v)) return '—';
      if (Math.abs(v) >= 100) return v.toFixed(0); if (Math.abs(v) >= 10) return v.toFixed(1);
      if (Math.abs(v) >= .01) return v.toFixed(3).replace(/0+$/,'').replace(/\.$/,'');
      return v.toExponential(1);
    };
    const scopes = Object.values(DATA.classification_counts);
    const scopeKey = s => `${s.geometry_id}__${s.preset_id}`;
    const classLabel = key => DATA.class_labels_ja[key] || key;

    function option(select, value, label) { const o=document.createElement('option'); o.value=value; o.textContent=label; select.appendChild(o); }
    scopes.forEach(s => option($('pw-scope'), scopeKey(s), `${s.geometry_id} / ${s.material}`));
    DATA.phase_maps.forEach(p => option($('pw-pair'), p.pair_id, `${p.x_parameter} × ${p.y_parameter}`));
    option($('pw-view'),'dominant_class','四分類');
    Object.entries(METRIC_LABELS).forEach(([k,v]) => option($('pw-view'),k,v));
    const sensitivityMetrics = Object.keys(DATA.sensitivity.pooled);
    sensitivityMetrics.forEach(m => option($('pw-metric'),m,METRIC_LABELS[m] || m));
    $('pw-metric').value = 'total_remaining_fraction';

    $('pw-badges').innerHTML = [
      `${DATA.quality.successful_global_case_count} global cases`, `${DATA.quality.successful_phase_case_count} phase cases`,
      `${DATA.quality.failed_case_count} failed`, `${DATA.bounds_set} bounds`, `${DATA.replicate_seeds.length} KMC seed`
    ].map(x=>`<span class="pw-badge">${x}</span>`).join('');

    function legend(target) {
      target.innerHTML = DATA.class_order.map(k => `<span><i class="pw-dot" style="background:${COLORS[k]}"></i>${classLabel(k)}</span>`).join('');
    }
    legend($('pw-legend')); legend($('pw-count-legend'));

    function renderCounts() {
      $('pw-counts').innerHTML = scopes.map(s => {
        const total = s.successful_case_count || 1;
        const bars = DATA.class_order.map(k => `<span title="${classLabel(k)} ${s.counts[k]}" style="width:${100*s.counts[k]/total}%;background:${COLORS[k]}"></span>`).join('');
        return `<div class="pw-stack-row"><span>${s.geometry_id} / ${s.material}</span><div class="pw-stack">${bars}</div></div>`;
      }).join('');
    }

    function metricColor(v) {
      const x=Math.max(0,Math.min(1,Number(v)||0));
      const hue=198-150*x, light=88-43*x; return `hsl(${hue} 67% ${light}%)`;
    }
    function renderPhase() {
      const scope=$('pw-scope').value, pair=DATA.phase_maps.find(p=>p.pair_id===$('pw-pair').value), view=$('pw-view').value;
      const stratum=pair.strata.find(s=>`${s.geometry_id}__${s.preset_id}`===scope);
      const nx=pair.x_values.length, ny=pair.y_values.length, grid=$('pw-grid');
      grid.style.gridTemplateColumns=`repeat(${nx}, minmax(31px, 1fr))`; grid.innerHTML='';
      for (let iy=ny-1; iy>=0; iy--) for (let ix=0; ix<nx; ix++) {
        const c=document.createElement('div'); c.className='pw-cell';
        const cls=stratum.dominant_class[iy][ix];
        if (view==='dominant_class') {
          const prob=stratum.dominant_probability[iy][ix]; c.style.background=COLORS[cls]||COLORS.failed; c.textContent=`${SHORT[cls]||'?'} ${Math.round(100*prob)}%`;
          c.title=`${pair.x_parameter}=${fmt(pair.x_values[ix])}\n${pair.y_parameter}=${fmt(pair.y_values[iy])}\n${classLabel(cls)} ${Math.round(100*prob)}%`;
        } else {
          const v=stratum.metric_medians[view][iy][ix]; c.style.background=metricColor(v); c.style.color=(Number(v)||0)>.5?'white':'#14212b'; c.style.textShadow='none'; c.textContent=v==null?'—':`${Math.round(100*v)}%`;
          c.title=`${pair.x_parameter}=${fmt(pair.x_values[ix])}\n${pair.y_parameter}=${fmt(pair.y_values[iy])}\n${METRIC_LABELS[view]}=${fmt(v)}`;
        }
        grid.appendChild(c);
      }
      $('pw-context').textContent = pair.held_parameter_context==='matrix_clearing_deposit_focus'
        ? '析出境界を表示するため、他の一次HF条件はmatrix-clearing側に固定'
        : '他の11変数はtransform-aware midpointに固定';
      $('pw-axis').innerHTML=`<span><strong>x:</strong> ${pair.x_parameter} ${fmt(pair.x_values[0])} → ${fmt(pair.x_values[nx-1])}</span><span><strong>y:</strong> ${pair.y_parameter} ${fmt(pair.y_values[0])} → ${fmt(pair.y_values[ny-1])}</span>`;
    }

    function renderDrivers() {
      const scope=$('pw-scope').value, metric=$('pw-metric').value;
      const source=(DATA.sensitivity.strata[scope]||DATA.sensitivity.pooled)[metric]||[];
      const rows=[...source].sort((a,b)=>Math.abs(b.prcc)-Math.abs(a.prcc)).slice(0,8);
      $('pw-driver-title').textContent=`${scope.replace('__',' / ')} | ${METRIC_LABELS[metric]||metric}`;
      $('pw-drivers').innerHTML=rows.map(r=>{
        const mag=Math.min(50,50*Math.abs(r.prcc)), left=r.prcc>=0?50:50-mag, color=r.prcc>=0?'#1677a8':'#d55e00';
        return `<div class="pw-driver"><span>${r.parameter}</span><div class="pw-driver-track" title="95% CI ${fmt(r.ci_low)} … ${fmt(r.ci_high)}"><i class="pw-driver-bar" style="left:${left}%;width:${mag}%;background:${color}"></i></div><span class="pw-driver-value">${r.prcc>=0?'+':''}${r.prcc.toFixed(2)}</span></div>`;
      }).join('');
    }

    ['pw-scope','pw-pair','pw-view'].forEach(id => $(id).addEventListener('change',()=>{renderPhase();renderDrivers();}));
    $('pw-metric').addEventListener('change',renderDrivers);
    renderCounts(); renderPhase(); renderDrivers();
  })();
  </script>
</section>
'''


def build_fragment(input_path: Path, output_path: Path) -> Path:
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    data = json.dumps(_compact_payload(payload), ensure_ascii=False, separators=(",", ":"))
    fragment = FRAGMENT.replace("__DATA__", data)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(fragment, encoding="utf-8")
    return output_path


def main(argv: Sequence[str] | None = None) -> Path:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("results/process_window/process_window_results.json"),
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args(argv)
    return build_fragment(args.input.resolve(), args.output.resolve())


if __name__ == "__main__":
    main()

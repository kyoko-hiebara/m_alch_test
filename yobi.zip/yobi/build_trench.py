#!/usr/bin/env python3
"""Build an atomistic Si trench, optionally containing Si3N4 and H/OH caps.

Axis convention
---------------
    x: trench longitudinal direction (periodic)
    y: trench width direction (periodic; crystalline Si continues across the seam)
    z: surface normal / etch depth direction

The Si thickness is the thickness before etching.  Therefore the remaining Si
under the trench is ``substrate_thickness - trench_depth``.  The requested x
length is snapped to an integer number of Si unit cells.  When Si3N4 is added,
the code finds a nearly commensurate Si/Si3N4 repeat and strains only the x
coordinate of Si3N4 by no more than ``--max-sin-strain``.
The y cell length is rounded upward to an integer Si repeat so the substrate
connects crystallographically across the y seam; vacuum is added only in z.

This script creates an initial, unrelaxed atomistic model.  Interfaces and
freshly cut surfaces should be relaxed with an appropriate force field or DFT
before they are used for production calculations.
"""

from __future__ import annotations

import argparse
import math
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np


TOL = 1.0e-8


@dataclass(frozen=True)
class XYZStructure:
    species: np.ndarray
    positions: np.ndarray
    cell: np.ndarray
    comment: str


@dataclass(frozen=True)
class Geometry:
    length_x: float
    outer_width: float
    y_repeats: int
    si_height: float
    trench_width: float
    trench_depth: float
    sidewall_thickness: float
    y_left: float
    y_right: float
    z_floor: float


@dataclass(frozen=True)
class Neighbor:
    basis_index: int
    cell_shift: tuple[int, int, int]
    vector: np.ndarray


@dataclass(frozen=True)
class SiScaffold:
    positions: np.ndarray
    cell_indices: np.ndarray
    basis_indices: np.ndarray
    retained_keys: frozenset[tuple[int, int, int, int]]
    neighbor_map: tuple[tuple[Neighbor, ...], ...]
    removed_atoms: int
    y_repeats: int


@dataclass(frozen=True)
class SiNPeriod:
    si_repeats: int
    sin_axis: int
    sin_repeats: int
    length_x: float
    strain: float


@dataclass(frozen=True)
class ResidueIsland:
    center: np.ndarray
    radii: np.ndarray
    phase1: float
    phase2: float


@dataclass
class BuildStats:
    requested_length_x: float
    actual_length_x: float
    length_y: float = 0.0
    sidewall_thickness: float = 0.0
    si_atoms: int = 0
    sin_atoms: int = 0
    termination_h: int = 0
    termination_o: int = 0
    dangling_considered: int = 0
    dangling_covered_by_sin: int = 0
    termination_collision_skips: int = 0
    sin_axis: int | None = None
    sin_repeats: int | None = None
    sin_strain: float | None = None


def read_extended_xyz(path: Path) -> XYZStructure:
    """Read species, Cartesian coordinates, and a 3x3 Lattice field."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ValueError(f"cannot read {path}: {exc}") from exc
    if len(lines) < 2:
        raise ValueError(f"{path} is not a valid XYZ file")
    try:
        natoms = int(lines[0].strip())
    except ValueError as exc:
        raise ValueError(f"first line of {path} must be an atom count") from exc
    if len(lines) < natoms + 2:
        raise ValueError(f"{path} declares {natoms} atoms but is truncated")

    comment = lines[1].strip()
    match = re.search(r'Lattice\s*=\s*"([^"]+)"', comment)
    if match is None:
        raise ValueError(f"{path} needs an extended-XYZ Lattice=\"...\" field")
    try:
        lattice_values = [float(value) for value in match.group(1).split()]
    except ValueError as exc:
        raise ValueError(f"invalid Lattice field in {path}") from exc
    if len(lattice_values) != 9:
        raise ValueError(f"Lattice field in {path} must contain 9 numbers")
    cell = np.asarray(lattice_values, dtype=float).reshape(3, 3)
    if abs(float(np.linalg.det(cell))) < 1.0e-10:
        raise ValueError(f"singular lattice in {path}")

    species: list[str] = []
    positions: list[list[float]] = []
    for line_number, line in enumerate(lines[2 : natoms + 2], start=3):
        fields = line.split()
        if len(fields) < 4:
            raise ValueError(f"line {line_number} of {path} has fewer than 4 fields")
        species.append(fields[0])
        try:
            positions.append([float(fields[1]), float(fields[2]), float(fields[3])])
        except ValueError as exc:
            raise ValueError(f"invalid coordinate on line {line_number} of {path}") from exc
    return XYZStructure(
        species=np.asarray(species, dtype="U4"),
        positions=np.asarray(positions, dtype=float),
        cell=cell,
        comment=comment,
    )


def wrapped_fractional(structure: XYZStructure) -> np.ndarray:
    frac = structure.positions @ np.linalg.inv(structure.cell)
    frac -= np.floor(frac + 1.0e-12)
    frac[np.isclose(frac, 1.0, atol=1.0e-10)] = 0.0
    return frac


def validate_si_cell(si: XYZStructure) -> tuple[float, float, float]:
    if not np.all(si.species == "Si"):
        raise ValueError("the Si template must contain only Si atoms")
    diagonal = np.diag(np.diag(si.cell))
    if not np.allclose(si.cell, diagonal, atol=1.0e-6):
        raise ValueError("the Si template must be aligned to an orthorhombic x/y/z cell")
    lengths = tuple(float(value) for value in np.diag(si.cell))
    if any(value <= 0.0 for value in lengths):
        raise ValueError("the Si cell vectors must point along +x, +y, and +z")
    return lengths


def snap_si_length(requested: float, period: float, mode: str) -> tuple[int, float]:
    ratio = requested / period
    if mode == "ceil":
        repeats = max(1, int(math.ceil(ratio - 1.0e-12)))
    elif mode == "nearest":
        repeats = max(1, int(math.floor(ratio + 0.5)))
    elif mode == "strict":
        repeats = max(1, int(round(ratio)))
        if not math.isclose(repeats * period, requested, abs_tol=1.0e-6):
            raise ValueError(
                f"--structure-depth={requested:g} is not an integer multiple of "
                f"the Si x period ({period:.8f} A) in strict mode"
            )
    else:  # pragma: no cover - guarded by argparse
        raise ValueError(f"unknown snap mode: {mode}")
    return repeats, repeats * period


def find_commensurate_period(
    requested: float,
    si_period: float,
    sin_cell: np.ndarray,
    mode: str,
    max_strain: float,
) -> SiNPeriod:
    """Find Lx=n*Si_period close to m*|SiN vector|."""
    sin_lengths = np.linalg.norm(sin_cell, axis=1)
    target_n = max(1, int(math.ceil(requested / si_period)))
    n_max = max(target_n + 120, 160)
    candidates: list[tuple[tuple[float, float, int], SiNPeriod]] = []
    for n_si in range(1, n_max + 1):
        length_x = n_si * si_period
        if mode == "ceil" and length_x < requested - 1.0e-7:
            continue
        if mode == "strict" and not math.isclose(length_x, requested, abs_tol=1.0e-6):
            continue
        for axis, sin_length in enumerate(sin_lengths):
            approximate_m = max(1, int(round(length_x / float(sin_length))))
            for n_sin in range(max(1, approximate_m - 2), approximate_m + 3):
                strain = length_x / (n_sin * float(sin_length)) - 1.0
                if abs(strain) > max_strain + 1.0e-12:
                    continue
                dimension_error = abs(length_x - requested) / requested
                # Length fidelity dominates; strain and smaller repeat counts break ties.
                key = (dimension_error, abs(strain), n_si + n_sin)
                candidates.append(
                    (
                        key,
                        SiNPeriod(
                            si_repeats=n_si,
                            sin_axis=axis,
                            sin_repeats=n_sin,
                            length_x=length_x,
                            strain=strain,
                        ),
                    )
                )
    if not candidates:
        qualifier = "at or above the requested length" if mode == "ceil" else "near the requested length"
        raise ValueError(
            f"no Si/SiN x repeat {qualifier} satisfies --max-sin-strain={max_strain:g}; "
            "increase --max-sin-strain or change --structure-depth"
        )
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def derive_neighbor_map(si: XYZStructure) -> tuple[tuple[Neighbor, ...], ...]:
    """Derive the four ideal diamond bonds for every basis atom."""
    frac = wrapped_fractional(si)
    all_neighbors: list[tuple[Neighbor, ...]] = []
    for i in range(len(frac)):
        candidates: list[tuple[float, int, tuple[int, int, int], np.ndarray]] = []
        for j in range(len(frac)):
            for sx in (-1, 0, 1):
                for sy in (-1, 0, 1):
                    for sz in (-1, 0, 1):
                        shift = (sx, sy, sz)
                        delta_frac = frac[j] + np.asarray(shift, dtype=float) - frac[i]
                        vector = delta_frac @ si.cell
                        distance = float(np.linalg.norm(vector))
                        if distance > 1.0e-7:
                            candidates.append((distance, j, shift, vector))
        candidates.sort(key=lambda item: item[0])
        nearest = candidates[0][0]
        selected = [item for item in candidates if item[0] <= nearest * 1.05]
        if len(selected) != 4:
            raise ValueError(
                "the Si template does not look like four-coordinate diamond Si "
                f"(basis atom {i + 1} has {len(selected)} nearest neighbors)"
            )
        all_neighbors.append(
            tuple(
                Neighbor(basis_index=j, cell_shift=shift, vector=vector.copy())
                for _, j, shift, vector in selected
            )
        )
    return tuple(all_neighbors)


def build_si_scaffold(
    si: XYZStructure,
    nx: int,
    geometry: Geometry,
) -> SiScaffold:
    ax, ay, az = validate_si_cell(si)
    expected_lx = nx * ax
    if not math.isclose(expected_lx, geometry.length_x, abs_tol=1.0e-6):
        raise ValueError("internal x repeat mismatch")
    frac = wrapped_fractional(si)
    base_positions = frac @ si.cell
    ny = geometry.y_repeats
    nz = int(math.ceil(geometry.si_height / az)) + 1

    positions: list[np.ndarray] = []
    cell_indices: list[tuple[int, int, int]] = []
    basis_indices: list[int] = []
    keys: set[tuple[int, int, int, int]] = set()
    removed_atoms = 0
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                translation = ix * si.cell[0] + iy * si.cell[1] + iz * si.cell[2]
                for basis, base in enumerate(base_positions):
                    pos = base + translation
                    if not (-TOL <= pos[0] < geometry.length_x - TOL):
                        continue
                    if not (-TOL <= pos[1] < geometry.outer_width - TOL):
                        continue
                    if not (-TOL <= pos[2] < geometry.si_height - TOL):
                        continue
                    in_cavity = (
                        pos[1] > geometry.y_left + TOL
                        and pos[1] < geometry.y_right - TOL
                        and pos[2] > geometry.z_floor + TOL
                    )
                    if in_cavity:
                        removed_atoms += 1
                        continue
                    key = (ix, iy, iz, basis)
                    positions.append(pos)
                    cell_indices.append((ix, iy, iz))
                    basis_indices.append(basis)
                    keys.add(key)

    if not positions:
        raise ValueError("the requested dimensions leave no Si atoms")
    if removed_atoms == 0:
        raise ValueError(
            "the requested trench removes no Si atoms at this lattice resolution; "
            "increase --trench-width and/or --trench-depth"
        )
    pos_array = np.asarray(positions, dtype=float)
    if not np.any(pos_array[:, 1] < geometry.y_left):
        raise ValueError("left sidewall contains no Si atoms; increase --sidewall-thickness")
    if not np.any(pos_array[:, 1] > geometry.y_right):
        raise ValueError("right sidewall contains no Si atoms; increase --sidewall-thickness")
    if not np.any(pos_array[:, 2] <= geometry.z_floor + TOL):
        raise ValueError("no Si remains below the trench; reduce --trench-depth")

    return SiScaffold(
        positions=pos_array,
        cell_indices=np.asarray(cell_indices, dtype=int),
        basis_indices=np.asarray(basis_indices, dtype=int),
        retained_keys=frozenset(keys),
        neighbor_map=derive_neighbor_map(si),
        removed_atoms=removed_atoms,
        y_repeats=ny,
    )


def minimum_image_deltas(
    deltas: np.ndarray,
    length_x: float,
    length_y: float | None = None,
) -> np.ndarray:
    result = np.asarray(deltas, dtype=float).copy()
    result[..., 0] -= np.rint(result[..., 0] / length_x) * length_x
    if length_y is not None:
        result[..., 1] -= np.rint(result[..., 1] / length_y) * length_y
    return result


def minimum_distances(
    query: np.ndarray,
    reference: np.ndarray,
    length_x: float,
    chunk_size: int = 256,
    length_y: float | None = None,
) -> np.ndarray:
    if len(query) == 0:
        return np.empty(0, dtype=float)
    if len(reference) == 0:
        return np.full(len(query), np.inf, dtype=float)
    result = np.empty(len(query), dtype=float)
    for start in range(0, len(query), chunk_size):
        stop = min(start + chunk_size, len(query))
        delta = query[start:stop, None, :] - reference[None, :, :]
        delta[..., 0] -= np.rint(delta[..., 0] / length_x) * length_x
        if length_y is not None:
            delta[..., 1] -= np.rint(delta[..., 1] / length_y) * length_y
        result[start:stop] = np.sqrt(np.min(np.einsum("ijk,ijk->ij", delta, delta), axis=1))
    return result


def local_frame_along_vector(cell: np.ndarray, axis: int) -> np.ndarray:
    """Return columns that convert Cartesian vectors to a frame with cell[axis] on x."""
    qx = cell[axis] / np.linalg.norm(cell[axis])
    other_axes = [candidate for candidate in range(3) if candidate != axis]
    projections = []
    for candidate in other_axes:
        projected = cell[candidate] - np.dot(cell[candidate], qx) * qx
        projections.append((float(np.linalg.norm(projected)), projected))
    _, best_projection = max(projections, key=lambda item: item[0])
    qy = best_projection / np.linalg.norm(best_projection)
    qz = np.cross(qx, qy)
    qz /= np.linalg.norm(qz)
    return np.column_stack((qx, qy, qz))


def prepare_sin_template(
    sin: XYZStructure,
    period: SiNPeriod,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    frac = wrapped_fractional(sin)
    transform = local_frame_along_vector(sin.cell, period.sin_axis)
    rotated_cell = sin.cell @ transform
    stretch = 1.0 + period.strain
    rotated_cell[:, 0] *= stretch
    base_positions = frac @ rotated_cell
    selected = rotated_cell[period.sin_axis]
    expected_period = period.length_x / period.sin_repeats
    if not (
        math.isclose(selected[0], expected_period, abs_tol=1.0e-6)
        and abs(selected[1]) < 1.0e-6
        and abs(selected[2]) < 1.0e-6
    ):
        raise ValueError("internal SiN orientation error")
    return sin.species.copy(), base_positions, rotated_cell


def deduplicate_atoms(
    species: np.ndarray,
    positions: np.ndarray,
    decimals: int = 7,
) -> tuple[np.ndarray, np.ndarray]:
    seen: set[tuple[str, float, float, float]] = set()
    keep: list[int] = []
    rounded = np.round(positions, decimals=decimals)
    for index, (element, pos) in enumerate(zip(species, rounded, strict=True)):
        key = (str(element), float(pos[0]), float(pos[1]), float(pos[2]))
        if key not in seen:
            seen.add(key)
            keep.append(index)
    return species[keep], positions[keep]


def tile_sin_in_cavity(
    base_species: np.ndarray,
    base_positions: np.ndarray,
    cell: np.ndarray,
    period: SiNPeriod,
    geometry: Geometry,
    phase: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    axis = period.sin_axis
    transverse = [candidate for candidate in range(3) if candidate != axis]
    yz_matrix = cell[transverse, 1:3]
    singular_values = np.linalg.svd(yz_matrix, compute_uv=False)
    smallest = float(np.min(singular_values))
    if smallest < 1.0e-6:
        raise ValueError("SiN transverse lattice vectors do not span the y-z plane")
    extent = max(geometry.outer_width, geometry.si_height) + 3.0 * float(
        np.max(np.linalg.norm(cell, axis=1))
    )
    transverse_repeats = int(math.ceil(extent / smallest)) + 2

    all_positions: list[np.ndarray] = []
    all_species: list[np.ndarray] = []
    vector_x = cell[axis]
    vector_u = cell[transverse[0]]
    vector_v = cell[transverse[1]]
    for ix in range(period.sin_repeats):
        for iu in range(-transverse_repeats, transverse_repeats + 1):
            for iv in range(-transverse_repeats, transverse_repeats + 1):
                translation = ix * vector_x + iu * vector_u + iv * vector_v + phase
                trial = base_positions + translation
                trial[:, 0] %= geometry.length_x
                mask = (
                    (trial[:, 1] > geometry.y_left + TOL)
                    & (trial[:, 1] < geometry.y_right - TOL)
                    & (trial[:, 2] > geometry.z_floor + TOL)
                    & (trial[:, 2] < geometry.si_height - TOL)
                )
                if np.any(mask):
                    all_positions.append(trial[mask])
                    all_species.append(base_species[mask])
    if not all_positions:
        return np.empty(0, dtype="U4"), np.empty((0, 3), dtype=float)
    species = np.concatenate(all_species)
    positions = np.vstack(all_positions)
    return deduplicate_atoms(species, positions)


def make_residue_islands(
    geometry: Geometry,
    count: int,
    coverage: float,
    max_height: float,
    rng: np.random.Generator,
) -> tuple[ResidueIsland, ...]:
    target_area = max(1.0, coverage * geometry.length_x * geometry.trench_width)
    base_radius = math.sqrt(target_area / (math.pi * count))
    islands: list[ResidueIsland] = []
    for index in range(count):
        anchor_draw = rng.random()
        x = rng.uniform(0.0, geometry.length_x)
        if anchor_draw < 0.72:
            y = rng.uniform(geometry.y_left, geometry.y_right)
            z = geometry.z_floor
            ry_scale = rng.uniform(0.65, 1.35)
        else:
            y = geometry.y_left if (index % 2 == 0) else geometry.y_right
            z = geometry.z_floor + rng.uniform(0.0, 0.28 * max_height)
            ry_scale = rng.uniform(0.45, 0.9)
        rx = max(1.8, base_radius * rng.uniform(0.70, 1.45))
        ry = max(1.8, base_radius * ry_scale)
        rz = max(0.25, max_height * rng.uniform(0.50, 1.0))
        islands.append(
            ResidueIsland(
                center=np.asarray([x, y, z], dtype=float),
                radii=np.asarray([rx, ry, rz], dtype=float),
                phase1=rng.uniform(0.0, 2.0 * math.pi),
                phase2=rng.uniform(0.0, 2.0 * math.pi),
            )
        )
    return tuple(islands)


def residue_mask(
    positions: np.ndarray,
    islands: Sequence[ResidueIsland],
    length_x: float,
) -> np.ndarray:
    keep = np.zeros(len(positions), dtype=bool)
    for island in islands:
        delta = positions - island.center
        delta[:, 0] -= np.rint(delta[:, 0] / length_x) * length_x
        scaled = delta / island.radii
        metric = np.einsum("ij,ij->i", scaled, scaled)
        ripple = (
            0.16 * np.sin(2.7 * scaled[:, 0] + 1.9 * scaled[:, 1] + island.phase1)
            + 0.10 * np.sin(3.1 * scaled[:, 1] - 1.7 * scaled[:, 2] + island.phase2)
        )
        keep |= metric <= 1.0 + ripple
    return keep


class UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))
        self.component_size = [1] * size

    def find(self, value: int) -> int:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, first: int, second: int) -> None:
        root_first = self.find(first)
        root_second = self.find(second)
        if root_first == root_second:
            return
        if self.component_size[root_first] < self.component_size[root_second]:
            root_first, root_second = root_second, root_first
        self.parent[root_second] = root_first
        self.component_size[root_first] += self.component_size[root_second]


def filter_residue_components(
    species: np.ndarray,
    positions: np.ndarray,
    contact: np.ndarray,
    length_x: float,
    min_atoms: int,
    bond_cutoff: float = 2.25,
    length_y: float | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Keep bonded Si-N chunks that touch the Si substrate."""
    if len(positions) == 0:
        return species, positions, contact
    members = sin_bonded_components(
        species, positions, length_x, bond_cutoff, length_y=length_y
    )
    keep = np.zeros(len(positions), dtype=bool)
    for indices in members:
        if len(indices) >= min_atoms and bool(np.any(contact[indices])):
            keep[indices] = True
    return species[keep], positions[keep], contact[keep]


def sin_bonded_components(
    species: np.ndarray,
    positions: np.ndarray,
    length_x: float,
    bond_cutoff: float = 2.25,
    length_y: float | None = None,
) -> list[list[int]]:
    """Return Si--N connected components using periodic minimum-image distances."""
    if len(positions) == 0:
        return []
    union_find = UnionFind(len(positions))
    cutoff2 = bond_cutoff * bond_cutoff
    for first in range(len(positions) - 1):
        candidates = np.arange(first + 1, len(positions))
        unlike = species[candidates] != species[first]
        if not np.any(unlike):
            continue
        candidates = candidates[unlike]
        delta = positions[candidates] - positions[first]
        delta[:, 0] -= np.rint(delta[:, 0] / length_x) * length_x
        if length_y is not None:
            delta[:, 1] -= np.rint(delta[:, 1] / length_y) * length_y
        distances2 = np.einsum("ij,ij->i", delta, delta)
        for second in candidates[distances2 <= cutoff2]:
            union_find.union(first, int(second))

    members: dict[int, list[int]] = {}
    for index in range(len(positions)):
        members.setdefault(union_find.find(index), []).append(index)
    return list(members.values())


def filter_small_sin_components(
    species: np.ndarray,
    positions: np.ndarray,
    length_x: float,
    min_atoms: int,
    length_y: float | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Remove orphan atoms and tiny fragments made by interface cropping."""
    keep = np.zeros(len(positions), dtype=bool)
    for indices in sin_bonded_components(
        species, positions, length_x, length_y=length_y
    ):
        if len(indices) >= min_atoms:
            keep[indices] = True
    return species[keep], positions[keep]


def sin_internal_coordination(
    species: np.ndarray,
    positions: np.ndarray,
    length_x: float,
    bond_cutoff: float = 2.25,
    length_y: float | None = None,
) -> np.ndarray:
    """Count unlike-species Si--N neighbors with periodic minimum-image distances."""
    coordination = np.zeros(len(positions), dtype=int)
    cutoff2 = bond_cutoff * bond_cutoff
    for first in range(len(positions) - 1):
        candidates = np.arange(first + 1, len(positions))
        candidates = candidates[species[candidates] != species[first]]
        if len(candidates) == 0:
            continue
        delta = positions[candidates] - positions[first]
        delta[:, 0] -= np.rint(delta[:, 0] / length_x) * length_x
        if length_y is not None:
            delta[:, 1] -= np.rint(delta[:, 1] / length_y) * length_y
        bonded = candidates[np.einsum("ij,ij->i", delta, delta) <= cutoff2]
        coordination[first] += len(bonded)
        coordination[bonded] += 1
    return coordination


def interface_filter_and_score(
    species: np.ndarray,
    positions: np.ndarray,
    substrate: np.ndarray,
    interface_dangling: Sequence[tuple[int, np.ndarray]],
    length_x: float,
    minimum_distance: float,
    length_y: float | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    distances = minimum_distances(
        positions, substrate, length_x, length_y=length_y
    )
    allowed = np.full(len(positions), minimum_distance, dtype=float)
    # An inserted Si atom must not approach substrate Si as closely as N can.
    allowed[species == "Si"] = max(minimum_distance, 2.10)
    keep = distances >= allowed
    species_kept = species[keep]
    positions_kept = positions[keep]
    internal_coordination = sin_internal_coordination(
        species_kept, positions_kept, length_x, length_y=length_y
    )
    nominal_valence = np.where(species_kept == "N", 3, 4)
    available_valence = np.maximum(0, nominal_valence - internal_coordination)

    slots_by_substrate: dict[int, list[tuple[int, np.ndarray]]] = {}
    for slot_index, (substrate_index, direction) in enumerate(interface_dangling):
        slots_by_substrate.setdefault(substrate_index, []).append((slot_index, direction))

    interior = np.zeros(len(positions_kept), dtype=bool)
    edges: list[tuple[float, int, int]] = []
    contact_upper = np.where(species_kept == "N", 2.25, 2.75)
    ideal_distance = np.where(species_kept == "N", 1.75, 2.35)
    for sin_index, sin_position in enumerate(positions_kept):
        delta = minimum_image_deltas(
            substrate - sin_position, length_x, length_y
        )
        substrate_distance = np.linalg.norm(delta, axis=1)
        close_substrate = np.flatnonzero(substrate_distance <= contact_upper[sin_index])
        if len(close_substrate) == 0:
            interior[sin_index] = True
            continue
        # Use a conservative one-interface-bond model.  A candidate close to
        # multiple substrate Si atoms could overcoordinate one of them; it is
        # removed rather than guessed into a bridge configuration.
        if len(close_substrate) != 1 or available_valence[sin_index] < 1:
            continue
        substrate_index = int(close_substrate[0])
        slots = slots_by_substrate.get(substrate_index, [])
        if not slots:
            continue
        outward = -delta[substrate_index] / substrate_distance[substrate_index]
        for slot_index, direction in slots:
            alignment = float(np.dot(outward, direction))
            if alignment < 0.75:
                continue
            distance_penalty = 0.08 * abs(
                substrate_distance[substrate_index] - ideal_distance[sin_index]
            )
            edges.append((alignment - distance_penalty, sin_index, slot_index))

    edges.sort(reverse=True)
    assigned_sin: set[int] = set()
    assigned_slots: set[int] = set()
    for _, sin_index, slot_index in edges:
        if sin_index in assigned_sin or slot_index in assigned_slots:
            continue
        assigned_sin.add(sin_index)
        assigned_slots.add(slot_index)

    interface_contact = np.zeros(len(positions_kept), dtype=bool)
    if assigned_sin:
        interface_contact[list(assigned_sin)] = True
    valence_keep = interior | interface_contact
    removed = int(len(species) - np.count_nonzero(valence_keep))
    species_final = species_kept[valence_keep]
    positions_final = positions_kept[valence_keep]
    contact_final = interface_contact[valence_keep]
    score = float(
        len(species_final) + 8 * np.count_nonzero(contact_final) - 0.25 * removed
    )
    return species_final, positions_final, contact_final, score


def add_sin_material(
    sin: XYZStructure,
    period: SiNPeriod,
    geometry: Geometry,
    substrate: np.ndarray,
    interface_dangling: Sequence[tuple[int, np.ndarray]],
    mode: str,
    phase_trials: int,
    minimum_distance: float,
    residue_islands: int,
    residue_coverage: float,
    residue_max_height: float,
    residue_min_atoms: int,
    fill_min_component_atoms: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    base_species, base_positions, transformed_cell = prepare_sin_template(sin, period)
    island_rng = np.random.default_rng(seed + 104729)
    islands = make_residue_islands(
        geometry,
        residue_islands,
        residue_coverage,
        residue_max_height,
        island_rng,
    )
    phase_rng = np.random.default_rng(seed)
    phase_span = float(np.max(np.linalg.norm(transformed_cell, axis=1)))

    best_score = -np.inf
    best_species = np.empty(0, dtype="U4")
    best_positions = np.empty((0, 3), dtype=float)
    for trial_index in range(phase_trials):
        if trial_index == 0:
            phase = np.zeros(3, dtype=float)
        else:
            phase = np.asarray(
                [
                    phase_rng.uniform(0.0, geometry.length_x / period.sin_repeats),
                    phase_rng.uniform(0.0, phase_span),
                    phase_rng.uniform(0.0, phase_span),
                ],
                dtype=float,
            )
        species, positions = tile_sin_in_cavity(
            base_species,
            base_positions,
            transformed_cell,
            period,
            geometry,
            phase,
        )
        if mode == "residue":
            mask = residue_mask(positions, islands, geometry.length_x)
            # The ellipsoid ripple and sidewall-centered blobs may otherwise
            # extend beyond the user-facing maximum-height contract.
            mask &= positions[:, 2] <= geometry.z_floor + residue_max_height + TOL
            species = species[mask]
            positions = positions[mask]
        species, positions, contact, score = interface_filter_and_score(
            species,
            positions,
            substrate,
            interface_dangling,
            geometry.length_x,
            minimum_distance,
            length_y=geometry.outer_width,
        )
        if mode == "residue":
            species, positions, contact = filter_residue_components(
                species,
                positions,
                contact,
                geometry.length_x,
                residue_min_atoms,
                length_y=geometry.outer_width,
            )
            score = float(len(species) + 6 * np.count_nonzero(contact))
        if score > best_score:
            best_score = score
            best_species = species.copy()
            best_positions = positions.copy()

    if len(best_positions) == 0:
        suggestion = (
            "increase --residue-coverage/--residue-max-height or reduce --residue-min-atoms"
            if mode == "residue"
            else "reduce --interface-min-distance"
        )
        raise ValueError(f"SiN {mode} produced no atoms; {suggestion}")
    if mode == "fill":
        best_species, best_positions = filter_small_sin_components(
            best_species,
            best_positions,
            geometry.length_x,
            fill_min_component_atoms,
            length_y=geometry.outer_width,
        )
        if len(best_positions) == 0:
            raise ValueError(
                "SiN fill consists only of tiny disconnected fragments; "
                "reduce --fill-min-component-atoms"
            )
    return best_species, best_positions


def dangling_bonds(
    scaffold: SiScaffold,
    nx: int,
    geometry: Geometry,
    scope: str,
) -> list[tuple[int, np.ndarray]]:
    result: list[tuple[int, np.ndarray]] = []
    for atom_index, (cell_index, basis_index) in enumerate(
        zip(scaffold.cell_indices, scaffold.basis_indices, strict=True)
    ):
        ix, iy, iz = (int(value) for value in cell_index)
        for neighbor in scaffold.neighbor_map[int(basis_index)]:
            sx, sy, sz = neighbor.cell_shift
            key = (
                (ix + sx) % nx,
                (iy + sy) % scaffold.y_repeats,
                iz + sz,
                neighbor.basis_index,
            )
            if key in scaffold.retained_keys:
                continue
            target = scaffold.positions[atom_index] + neighbor.vector
            target_y = target[1] % geometry.outer_width
            points_into_trench = (
                target_y > geometry.y_left + TOL
                and target_y < geometry.y_right - TOL
                and target[2] > geometry.z_floor + TOL
            )
            if scope == "trench" and not points_into_trench:
                continue
            result.append((atom_index, neighbor.vector / np.linalg.norm(neighbor.vector)))
    return result


def assign_sin_covered_dangling_bonds(
    dangling: Sequence[tuple[int, np.ndarray]],
    substrate_positions: np.ndarray,
    sin_species: np.ndarray,
    sin_positions: np.ndarray,
    length_x: float,
    length_y: float | None = None,
) -> dict[int, int]:
    """Match each nearby SiN atom to at most one missing ray on a given Si.

    The same N atom may legitimately bridge two *different* substrate Si
    atoms, but it must not be counted twice for two dangling rays on one Si.
    A 0.75 cosine cutoff keeps matches within 41.4 degrees of the ideal ray.
    """
    if len(sin_positions) == 0:
        return {}
    by_substrate: dict[int, list[tuple[int, np.ndarray]]] = {}
    for dangling_index, (substrate_index, direction) in enumerate(dangling):
        by_substrate.setdefault(substrate_index, []).append((dangling_index, direction))

    assignments: dict[int, int] = {}
    cutoff = np.where(sin_species == "N", 2.30, 2.75)
    for substrate_index, missing in by_substrate.items():
        delta = minimum_image_deltas(
            sin_positions - substrate_positions[substrate_index],
            length_x,
            length_y,
        )
        distance = np.linalg.norm(delta, axis=1)
        nearby = np.flatnonzero((distance > TOL) & (distance <= cutoff))
        candidates: list[tuple[float, int, int]] = []
        for dangling_index, direction in missing:
            cosine = np.einsum("ij,j->i", delta[nearby], direction) / distance[nearby]
            for sin_index, alignment in zip(nearby, cosine, strict=True):
                if alignment >= 0.75:
                    candidates.append((float(alignment), dangling_index, int(sin_index)))
        candidates.sort(reverse=True)
        used_dangling: set[int] = set()
        used_sin: set[int] = set()
        for _, dangling_index, sin_index in candidates:
            if dangling_index in used_dangling or sin_index in used_sin:
                continue
            assignments[dangling_index] = sin_index
            used_dangling.add(dangling_index)
            used_sin.add(sin_index)
    return assignments


def point_minimum_distance(
    point: np.ndarray,
    atoms: np.ndarray,
    length_x: float,
    length_y: float | None = None,
) -> float:
    if len(atoms) == 0:
        return math.inf
    delta = atoms - point
    delta[:, 0] -= np.rint(delta[:, 0] / length_x) * length_x
    if length_y is not None:
        delta[:, 1] -= np.rint(delta[:, 1] / length_y) * length_y
    return float(np.sqrt(np.min(np.einsum("ij,ij->i", delta, delta))))


def perpendicular_frame(direction: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    reference = np.asarray([1.0, 0.0, 0.0])
    if abs(float(np.dot(direction, reference))) > 0.80:
        reference = np.asarray([0.0, 1.0, 0.0])
    first = np.cross(direction, reference)
    first /= np.linalg.norm(first)
    second = np.cross(direction, first)
    second /= np.linalg.norm(second)
    return first, second


def termination_rng(
    seed: int,
    atom_index: int,
    direction: np.ndarray,
) -> np.random.Generator:
    """Return a stable RNG for one missing Si bond.

    The direction bit mask distinguishes the four tetrahedral bond rays.  A
    per-ray generator keeps candidate orientations unchanged when exterior
    top/bottom rays are added by ``--termination-scope all``.
    """
    direction_bits = sum(
        (1 if component > 0.0 else 0) << axis
        for axis, component in enumerate(direction)
    )
    sequence = np.random.SeedSequence(
        [seed & 0xFFFFFFFF, atom_index, direction_bits, 15485863]
    )
    return np.random.default_rng(sequence)


def build_terminations(
    termination: str,
    scaffold: SiScaffold,
    nx: int,
    geometry: Geometry,
    scope: str,
    sin_species: np.ndarray,
    sin_positions: np.ndarray,
    seed: int,
    stats: BuildStats,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if termination == "none":
        return (
            np.empty(0, dtype="U4"),
            np.empty((0, 3), dtype=float),
            np.empty(0, dtype="U20"),
        )
    dangling = dangling_bonds(scaffold, nx, geometry, scope)
    stats.dangling_considered = len(dangling)
    covered_assignments = assign_sin_covered_dangling_bonds(
        dangling,
        scaffold.positions,
        sin_species,
        sin_positions,
        geometry.length_x,
        geometry.outer_width,
    )
    placed_positions: list[np.ndarray] = []
    placed_species: list[str] = []
    placed_groups: list[str] = []

    for dangling_index, (atom_index, direction) in enumerate(dangling):
        si_position = scaffold.positions[atom_index]
        if dangling_index in covered_assignments:
            stats.dangling_covered_by_sin += 1
            continue
        # Exclude the intended parent Si from collision scoring.  Otherwise
        # its fixed Si--H/Si--O bond length caps every clearance score and can
        # hide a closer contact to another atom.
        existing_parts = [
            scaffold.positions[:atom_index],
            scaffold.positions[atom_index + 1 :],
        ]
        if len(sin_positions):
            existing_parts.append(sin_positions)
        if placed_positions:
            existing_parts.append(np.asarray(placed_positions, dtype=float))
        existing = np.vstack(existing_parts)
        ray_rng = termination_rng(seed, atom_index, direction)
        if termination == "h":
            # Ideal missing-bond rays on an unreconstructed Si(100) cut can
            # place H atoms on neighboring Si atoms only ~1.45 A apart.  Keep
            # the Si--H length fixed but search a small outward cone so the
            # passivation is a less crowded relaxation starting point.
            perpendicular1, perpendicular2 = perpendicular_frame(direction)
            phase_offset = ray_rng.uniform(0.0, 2.0 * math.pi)
            h_position: np.ndarray | None = None
            h_clearance = -np.inf
            for tilt_degrees in (0.0, 10.0, 20.0, 30.0, 40.0, 50.0):
                azimuth_count = 1 if tilt_degrees == 0.0 else 16
                tilt = math.radians(tilt_degrees)
                best_at_tilt: np.ndarray | None = None
                clearance_at_tilt = -np.inf
                for candidate_index in range(azimuth_count):
                    phi = phase_offset + 2.0 * math.pi * candidate_index / azimuth_count
                    tangent = (
                        math.cos(phi) * perpendicular1 + math.sin(phi) * perpendicular2
                    )
                    candidate_direction = (
                        math.cos(tilt) * direction + math.sin(tilt) * tangent
                    )
                    candidate = si_position + 1.48 * candidate_direction
                    candidate[0] %= geometry.length_x
                    candidate[1] %= geometry.outer_width
                    clearance = point_minimum_distance(
                        candidate,
                        existing,
                        geometry.length_x,
                        geometry.outer_width,
                    )
                    if clearance > clearance_at_tilt:
                        clearance_at_tilt = clearance
                        best_at_tilt = candidate
                if clearance_at_tilt >= 1.60:
                    h_clearance = clearance_at_tilt
                    h_position = best_at_tilt
                    break
            if h_position is None or h_clearance < 1.60:
                stats.termination_collision_skips += 1
                continue
            placed_positions.append(h_position)
            placed_species.append("H")
            placed_groups.append("H_termination")
            stats.termination_h += 1
            continue

        # On an ideal unreconstructed Si(100) cut, neighboring missing-bond
        # rays can put two O atoms only about 1.2 A apart.  Search a modest
        # cone around the ideal tetrahedral ray so a dense OH termination is
        # usable as a relaxation starting point without an O--O overlap.
        ideal_perpendicular1, ideal_perpendicular2 = perpendicular_frame(direction)
        oxygen_phase = ray_rng.uniform(0.0, 2.0 * math.pi)
        hydrogen_phase = ray_rng.uniform(0.0, 2.0 * math.pi)
        oxygen: np.ndarray | None = None
        best_hydrogen: np.ndarray | None = None
        theta = math.radians(180.0 - 108.5)
        for tilt_degrees in (0.0, 10.0, 20.0, 30.0, 40.0, 50.0):
            azimuth_count = 1 if tilt_degrees == 0.0 else 16
            tilt = math.radians(tilt_degrees)
            best_pair_score = -np.inf
            for candidate_index in range(azimuth_count):
                phi = oxygen_phase + 2.0 * math.pi * candidate_index / azimuth_count
                tangent = (
                    math.cos(phi) * ideal_perpendicular1
                    + math.sin(phi) * ideal_perpendicular2
                )
                candidate_direction = math.cos(tilt) * direction + math.sin(tilt) * tangent
                candidate_oxygen = si_position + 1.63 * candidate_direction
                candidate_oxygen[0] %= geometry.length_x
                candidate_oxygen[1] %= geometry.outer_width
                clearance = point_minimum_distance(
                    candidate_oxygen,
                    existing,
                    geometry.length_x,
                    geometry.outer_width,
                )
                if clearance < 1.80:
                    continue
                perpendicular1, perpendicular2 = perpendicular_frame(candidate_direction)
                for hydrogen_index in range(16):
                    hydrogen_phi = (
                        hydrogen_phase
                        + 2.0 * math.pi * hydrogen_index / 16.0
                    )
                    hydrogen_tangent = (
                        math.cos(hydrogen_phi) * perpendicular1
                        + math.sin(hydrogen_phi) * perpendicular2
                    )
                    oh_direction = (
                        math.cos(theta) * candidate_direction
                        + math.sin(theta) * hydrogen_tangent
                    )
                    candidate_hydrogen = candidate_oxygen + 0.98 * oh_direction
                    candidate_hydrogen[0] %= geometry.length_x
                    candidate_hydrogen[1] %= geometry.outer_width
                    hydrogen_clearance = point_minimum_distance(
                        candidate_hydrogen,
                        existing,
                        geometry.length_x,
                        geometry.outer_width,
                    )
                    if hydrogen_clearance < 1.60:
                        continue
                    pair_score = min(clearance - 1.80, hydrogen_clearance - 1.60)
                    if pair_score > best_pair_score:
                        best_pair_score = pair_score
                        oxygen = candidate_oxygen
                        best_hydrogen = candidate_hydrogen
            if oxygen is not None:
                break
        if oxygen is None or best_hydrogen is None:
            stats.termination_collision_skips += 1
            continue
        placed_positions.extend((oxygen, best_hydrogen))
        placed_species.extend(("O", "H"))
        placed_groups.extend(("OH_oxygen", "OH_hydrogen"))
        stats.termination_o += 1
        stats.termination_h += 1

    if not placed_positions:
        return (
            np.empty(0, dtype="U4"),
            np.empty((0, 3), dtype=float),
            np.empty(0, dtype="U20"),
        )
    return (
        np.asarray(placed_species, dtype="U4"),
        np.asarray(placed_positions, dtype=float),
        np.asarray(placed_groups, dtype="U20"),
    )


def add_nonperiodic_vacuum(
    positions: np.ndarray,
    geometry: Geometry,
    vacuum: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    wrapped = positions.copy()
    wrapped[:, 0] %= geometry.length_x
    wrapped[:, 1] %= geometry.outer_width
    minimum_z = min(0.0, float(np.min(wrapped[:, 2])))
    maximum_z = max(geometry.si_height, float(np.max(wrapped[:, 2])))
    shift = np.asarray([0.0, 0.0, vacuum - minimum_z])
    shifted = wrapped + shift
    cell_lengths = np.asarray(
        [
            geometry.length_x,
            geometry.outer_width,
            maximum_z - minimum_z + 2.0 * vacuum,
        ]
    )
    cell = np.diag(cell_lengths)
    return shifted, cell, shift


def minimum_pair_distance_below(
    positions: np.ndarray,
    length_x: float,
    threshold: float,
    length_y: float | None = None,
) -> tuple[float, tuple[int, int] | None]:
    """Find the smallest pair distance, stopping only after all close candidates are checked."""
    best = math.inf
    pair: tuple[int, int] | None = None
    threshold2 = threshold * threshold
    # A vectorized row loop is adequate for validation and avoids a SciPy dependency.
    for first in range(len(positions) - 1):
        delta = positions[first + 1 :] - positions[first]
        delta[:, 0] -= np.rint(delta[:, 0] / length_x) * length_x
        if length_y is not None:
            delta[:, 1] -= np.rint(delta[:, 1] / length_y) * length_y
        distance2 = np.einsum("ij,ij->i", delta, delta)
        close = np.flatnonzero(distance2 < threshold2)
        if len(close):
            local = close[int(np.argmin(distance2[close]))]
            value = math.sqrt(float(distance2[local]))
            if value < best:
                best = value
                pair = (first, first + 1 + int(local))
    return best, pair


def write_extended_xyz(
    path: Path,
    species: np.ndarray,
    positions: np.ndarray,
    groups: np.ndarray,
    cell: np.ndarray,
    geometry: Geometry,
    stats: BuildStats,
    mode: str,
    termination: str,
    termination_scope: str,
    shift: np.ndarray,
) -> None:
    lattice = " ".join(f"{value:.10f}" for value in cell.reshape(-1))
    metadata = [
        'Properties=species:S:1:pos:R:3:id:I:1:group:S:1',
        'pbc="T T F"',
        "generator=build_trench.py",
        f"sin_mode={mode}",
        f"termination={termination}",
        f"termination_scope={termination_scope}",
        f"requested_length_x={stats.requested_length_x:.8f}",
        f"actual_length_x={stats.actual_length_x:.8f}",
        f"periodic_length_y={geometry.outer_width:.8f}",
        f"si_thickness={geometry.si_height:.8f}",
        f"bottom_thickness={geometry.z_floor:.8f}",
        f"trench_depth={geometry.trench_depth:.8f}",
        f"trench_width={geometry.trench_width:.8f}",
        f"sidewall_thickness={geometry.sidewall_thickness:.8f}",
        f"geometry_shift_y={shift[1]:.8f}",
        f"geometry_shift_z={shift[2]:.8f}",
    ]
    if stats.sin_strain is not None:
        metadata.extend(
            (
                f"sin_periodic_axis={'abc'[int(stats.sin_axis)]}",
                f"sin_x_repeats={stats.sin_repeats}",
                f"sin_x_strain={stats.sin_strain:.10f}",
            )
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        handle.write(f"{len(species)}\n")
        handle.write(f'Lattice="{lattice}" ' + " ".join(metadata) + "\n")
        for atom_id, (element, pos, group) in enumerate(
            zip(species, positions, groups, strict=True), start=1
        ):
            handle.write(
                f"{element:<2s} {pos[0]:.10f} {pos[1]:.10f} {pos[2]:.10f} "
                f"{atom_id:d} {group}\n"
            )


def positive_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or parsed <= 0.0:
        raise argparse.ArgumentTypeError("must be a finite positive number")
    return parsed


def nonnegative_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or parsed < 0.0:
        raise argparse.ArgumentTypeError("must be a finite non-negative number")
    return parsed


def fraction(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or not 0.0 < parsed <= 1.0:
        raise argparse.ArgumentTypeError("must be in the interval (0, 1]")
    return parsed


def unit_interval(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed) or not 0.0 <= parsed <= 1.0:
        raise argparse.ArgumentTypeError("must be in the interval [0, 1]")
    return parsed


def build_parser() -> argparse.ArgumentParser:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description=(
            "Create an x/y-periodic Si trench (x: length, y: width, z: depth), "
            "optionally filled with SiN or decorated with irregular SiN residue."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--si", type=Path, default=script_dir / "si_8atom.xyz", help="Si unit-cell XYZ")
    parser.add_argument("--sin", type=Path, default=script_dir / "SiN_56atom.xyz", help="SiN unit-cell XYZ")
    parser.add_argument("-o", "--output", type=Path, default=Path("trench.xyz"), help="output extended XYZ")

    geometry = parser.add_argument_group("trench geometry (angstrom)")
    geometry.add_argument(
        "--substrate-thickness",
        "--si-thickness",
        dest="substrate_thickness",
        type=positive_float,
        default=None,
        help="Si thickness before etching; 235.155304 A for the bundled Si cell",
    )
    geometry.add_argument(
        "--bottom-thickness",
        type=positive_float,
        default=None,
        help="alternative: remaining Si thickness below the trench",
    )
    geometry.add_argument(
        "--trench-depth",
        type=positive_float,
        default=218.74912,
        help="etch depth from the top",
    )
    geometry.add_argument(
        "--trench-width",
        type=positive_float,
        default=10.937456,
        help="inner trench width along y",
    )
    geometry.add_argument(
        "--structure-depth",
        "--length-x",
        "--overall-depth",
        dest="structure_depth",
        type=positive_float,
        default=32.0,
        help="requested structure/trench length along periodic x",
    )
    geometry.add_argument(
        "--sidewall-thickness",
        type=positive_float,
        default=None,
        help="Si thickness on each side along y; default is two Si cells",
    )
    geometry.add_argument(
        "--length-snap",
        choices=("ceil", "nearest", "strict"),
        default="ceil",
        help="how to snap x length to periodic repeats",
    )
    geometry.add_argument(
        "--vacuum",
        type=nonnegative_float,
        default=5.0,
        help="vacuum on each nonperiodic z face (no x/y vacuum)",
    )

    material = parser.add_argument_group("SiN material")
    material.add_argument("--sin-mode", choices=("none", "fill", "residue"), default="none")
    material.add_argument(
        "--max-sin-strain",
        type=unit_interval,
        default=0.02,
        help="maximum absolute uniaxial SiN strain used for x commensurability",
    )
    material.add_argument("--phase-trials", type=int, default=8, help="SiN interface translations to test")
    material.add_argument(
        "--interface-min-distance",
        type=positive_float,
        default=1.60,
        help="minimum substrate-Si to inserted-N distance (inserted Si uses at least 2.10 A)",
    )
    material.add_argument(
        "--fill-min-component-atoms",
        type=int,
        default=6,
        help="remove disconnected SiN fill fragments smaller than this",
    )
    material.add_argument("--seed", type=int, default=42, help="random seed for phase/residue/OH orientation")

    residue = parser.add_argument_group("residue mode")
    residue.add_argument("--residue-coverage", type=fraction, default=0.25, help="approximate covered floor fraction")
    residue.add_argument("--residue-islands", type=int, default=8, help="number of irregular anchored blobs")
    residue.add_argument(
        "--residue-max-height",
        type=positive_float,
        default=None,
        help="maximum blob height; default is min(8 A, 45%% of trench depth)",
    )
    residue.add_argument(
        "--residue-min-atoms",
        type=int,
        default=6,
        help="discard disconnected residue chunks smaller than this",
    )

    termination = parser.add_argument_group("surface termination")
    termination.add_argument(
        "--termination",
        type=str.lower,
        choices=("none", "h", "oh"),
        default="none",
        help="cap dangling bonds on substrate Si",
    )
    termination.add_argument(
        "--termination-scope",
        choices=("trench", "all"),
        default="all",
        help=(
            "cap only trench-facing bonds or all exposed Si bonds, including the "
            "substrate top and bottom (x/y seams are periodic)"
        ),
    )
    return parser


def validate_arguments(args: argparse.Namespace) -> float:
    if args.substrate_thickness is not None and args.bottom_thickness is not None:
        raise ValueError("use either --substrate-thickness or --bottom-thickness, not both")
    if args.bottom_thickness is not None:
        substrate_thickness = args.bottom_thickness + args.trench_depth
    elif args.substrate_thickness is not None:
        substrate_thickness = args.substrate_thickness
    else:
        substrate_thickness = 235.155304
    if args.trench_depth >= substrate_thickness:
        raise ValueError("--trench-depth must be smaller than --substrate-thickness")
    if args.phase_trials < 1:
        raise ValueError("--phase-trials must be at least 1")
    if args.residue_islands < 1:
        raise ValueError("--residue-islands must be at least 1")
    if args.residue_min_atoms < 1:
        raise ValueError("--residue-min-atoms must be at least 1")
    if args.fill_min_component_atoms < 1:
        raise ValueError("--fill-min-component-atoms must be at least 1")
    return substrate_thickness


def build(args: argparse.Namespace) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, BuildStats]:
    substrate_thickness = validate_arguments(args)
    si = read_extended_xyz(args.si)
    ax, ay, _ = validate_si_cell(si)
    sidewall_thickness = args.sidewall_thickness
    if sidewall_thickness is None:
        sidewall_thickness = 2.0 * ay
    requested_outer_width = args.trench_width + 2.0 * sidewall_thickness
    y_repeats, outer_width = snap_si_length(requested_outer_width, ay, "ceil")
    # Y is crystalline and periodic, so Ly must be an integer Si repeat.  Any
    # rounding surplus is split equally between the two sidewalls.
    sidewall_thickness = 0.5 * (outer_width - args.trench_width)

    sin: XYZStructure | None = None
    sin_period: SiNPeriod | None = None
    if args.sin_mode == "none":
        nx, length_x = snap_si_length(args.structure_depth, ax, args.length_snap)
    else:
        sin = read_extended_xyz(args.sin)
        elements = set(str(value) for value in sin.species)
        if not elements.issubset({"Si", "N"}) or not {"Si", "N"}.issubset(elements):
            raise ValueError("the SiN template must contain both Si and N and no other elements")
        sin_period = find_commensurate_period(
            args.structure_depth,
            ax,
            sin.cell,
            args.length_snap,
            args.max_sin_strain,
        )
        nx = sin_period.si_repeats
        length_x = sin_period.length_x

    geometry = Geometry(
        length_x=length_x,
        outer_width=outer_width,
        y_repeats=y_repeats,
        si_height=substrate_thickness,
        trench_width=args.trench_width,
        trench_depth=args.trench_depth,
        sidewall_thickness=sidewall_thickness,
        y_left=sidewall_thickness,
        y_right=sidewall_thickness + args.trench_width,
        z_floor=substrate_thickness - args.trench_depth,
    )
    scaffold = build_si_scaffold(si, nx, geometry)
    stats = BuildStats(
        requested_length_x=args.structure_depth,
        actual_length_x=length_x,
        length_y=outer_width,
        sidewall_thickness=sidewall_thickness,
        si_atoms=len(scaffold.positions),
    )

    sin_species = np.empty(0, dtype="U4")
    sin_positions = np.empty((0, 3), dtype=float)
    if sin is not None and sin_period is not None:
        interface_dangling = dangling_bonds(scaffold, nx, geometry, "trench")
        residue_max_height = args.residue_max_height
        if residue_max_height is None:
            residue_max_height = min(8.0, 0.45 * args.trench_depth)
        residue_max_height = min(residue_max_height, 0.95 * args.trench_depth)
        sin_species, sin_positions = add_sin_material(
            sin=sin,
            period=sin_period,
            geometry=geometry,
            substrate=scaffold.positions,
            interface_dangling=interface_dangling,
            mode=args.sin_mode,
            phase_trials=args.phase_trials,
            minimum_distance=args.interface_min_distance,
            residue_islands=args.residue_islands,
            residue_coverage=args.residue_coverage,
            residue_max_height=residue_max_height,
            residue_min_atoms=args.residue_min_atoms,
            fill_min_component_atoms=args.fill_min_component_atoms,
            seed=args.seed,
        )
        stats.sin_atoms = len(sin_positions)
        stats.sin_axis = sin_period.sin_axis
        stats.sin_repeats = sin_period.sin_repeats
        stats.sin_strain = sin_period.strain

    term_species, term_positions, term_groups = build_terminations(
        termination=args.termination,
        scaffold=scaffold,
        nx=nx,
        geometry=geometry,
        scope=args.termination_scope,
        sin_species=sin_species,
        sin_positions=sin_positions,
        seed=args.seed,
        stats=stats,
    )

    species_parts = [np.full(len(scaffold.positions), "Si", dtype="U4")]
    position_parts = [scaffold.positions]
    group_parts = [np.full(len(scaffold.positions), "Si_substrate", dtype="U20")]
    if len(sin_positions):
        species_parts.append(sin_species)
        position_parts.append(sin_positions)
        sin_group_name = "SiN_fill" if args.sin_mode == "fill" else "SiN_residue"
        group_parts.append(np.full(len(sin_positions), sin_group_name, dtype="U20"))
    if len(term_positions):
        species_parts.append(term_species)
        position_parts.append(term_positions)
        group_parts.append(term_groups)

    species = np.concatenate(species_parts)
    positions = np.vstack(position_parts)
    groups = np.concatenate(group_parts)
    positions[:, 0] %= geometry.length_x
    positions[:, 1] %= geometry.outer_width
    positions, cell, shift = add_nonperiodic_vacuum(positions, geometry, args.vacuum)

    # Catch only severe overlaps. Normal covalent bonds in the input are >=1.45 A.
    minimum_distance, pair = minimum_pair_distance_below(
        positions,
        geometry.length_x,
        0.65,
        length_y=geometry.outer_width,
    )
    if pair is not None:
        first, second = pair
        raise ValueError(
            f"generated atoms {first + 1} ({species[first]}) and {second + 1} "
            f"({species[second]}) overlap at {minimum_distance:.4f} A"
        )

    write_extended_xyz(
        path=args.output,
        species=species,
        positions=positions,
        groups=groups,
        cell=cell,
        geometry=geometry,
        stats=stats,
        mode=args.sin_mode,
        termination=args.termination,
        termination_scope=args.termination_scope,
        shift=shift,
    )
    return species, positions, groups, cell, stats


def print_summary(args: argparse.Namespace, stats: BuildStats, total_atoms: int) -> None:
    print(f"Wrote: {args.output}")
    print(
        f"Periodic x length: requested {stats.requested_length_x:.6f} A, "
        f"actual {stats.actual_length_x:.6f} A"
    )
    print(
        f"Periodic y length: {stats.length_y:.6f} A "
        f"(effective sidewall {stats.sidewall_thickness:.6f} A per side)"
    )
    print(
        f"Trench aspect ratio depth/width: "
        f"{args.trench_depth / args.trench_width:.3f}:1"
    )
    relative_length_change = abs(stats.actual_length_x - stats.requested_length_x) / stats.requested_length_x
    if relative_length_change > 0.05:
        print(
            f"WARNING: x length changed by {100.0 * relative_length_change:.1f}% to preserve "
            "periodicity; consider --length-snap nearest or a commensurate length."
        )
    if stats.sin_strain is not None:
        print(
            f"SiN x match: input lattice vector {'abc'[int(stats.sin_axis)]}, "
            f"{stats.sin_repeats} repeats, "
            f"strain {100.0 * stats.sin_strain:+.4f}%"
        )
    print(
        f"Atoms: total {total_atoms}, substrate Si {stats.si_atoms}, "
        f"SiN {stats.sin_atoms}, terminal O {stats.termination_o}, "
        f"terminal H {stats.termination_h}"
    )
    if args.termination != "none":
        print(
            f"Dangling directions: {stats.dangling_considered} considered, "
            f"{stats.dangling_covered_by_sin} covered by SiN, "
            f"{stats.termination_collision_skips} skipped for collision"
        )
    print("Note: this is an unrelaxed initial structure; relax it before production use.")


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        species, _, _, _, stats = build(args)
    except ValueError as exc:
        parser.error(str(exc))
    print_summary(args, stats, len(species))
    return 0


if __name__ == "__main__":
    sys.exit(main())

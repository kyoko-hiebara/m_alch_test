from __future__ import annotations

import json
import unittest
from dataclasses import replace

import numpy as np

from trench_geometry import DEFAULT_GEOMETRY_NAMES
from trench_kmc_sweep import TrenchKMCSweepConfig, run_trench_kmc_sweep


def _tiny_config(*, workers: int = 1) -> TrenchKMCSweepConfig:
    """Exercise the real coupling on a deliberately tiny physical grid."""

    return TrenchKMCSweepConfig(
        geometries=("10_8_180",),
        # A non-default order makes the executor ordering assertion meaningful.
        scenarios=("combined", "baseline"),
        grid_spacing_nm=10.0,
        reservoir_height_nm=10.0,
        lateral_margin_nm=0.0,
        total_time_s=0.01,
        macro_time_step_s=0.01,
        maximum_events=5,
        hf_scales=(1.2, 0.8),
        retention_strength_scales=(1.5, 0.0),
        base_seed=271828,
        parallel_workers=workers,
        maximum_sites=2_000,
    )


class TrenchKMCSweepTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = _tiny_config()
        cls.payload = run_trench_kmc_sweep(cls.config)

    def test_default_config_uses_straight_geometries_and_budget_safe_grid(self) -> None:
        config = TrenchKMCSweepConfig()
        self.assertEqual(config.geometries, ("10_10_180", "7_7_170"))
        self.assertEqual(config.geometries, DEFAULT_GEOMETRY_NAMES)
        self.assertEqual(config.grid_spacing_nm, 1.05)
        self.assertEqual(config.maximum_sites, 2_000)

    def test_top_level_schema_ordering_and_strict_json(self) -> None:
        payload = self.payload
        self.assertEqual(payload["schema_version"], "trench-kmc-sweep/v1")
        self.assertEqual(payload["geometry_order"], ["10_8_180"])
        self.assertEqual(payload["scenario_order"], ["combined", "baseline"])
        self.assertEqual(
            payload["case_order"],
            [
                "10_8_180__combined",
                "10_8_180__baseline",
            ],
        )
        self.assertEqual(
            payload["sensitivity_case_order"],
            [
                "10_8_180__hf1p2__retention1p5",
                "10_8_180__hf0p8__retention1p5",
                "10_8_180__hf1p2__retention0p0",
                "10_8_180__hf0p8__retention0p0",
            ],
        )
        encoded = json.dumps(payload, allow_nan=False)
        self.assertNotIn("NaN", encoded)
        self.assertNotIn("Infinity", encoded)

    def test_snapshot_uses_equal_length_columnar_sites_and_grid_shaped_fields(self) -> None:
        case = self.payload["cases"][0]
        snapshot = case["snapshot"]
        sites = snapshot["sites"]
        required_columns = {
            "site_id",
            "site_type",
            "state",
            "region",
            "x_nm",
            "depth_nm",
            "row",
            "column",
            "hf_activity",
            "product_activity",
            "temperature_K",
            "wet_exposed",
            "support_site_id",
        }
        self.assertTrue(required_columns.issubset(sites))
        lengths = {key: len(values) for key, values in sites.items()}
        self.assertEqual(len(set(lengths.values())), 1)
        site_count = next(iter(lengths.values()))
        self.assertEqual(site_count, case["summary"]["total_site_count"])
        self.assertEqual(sites["site_id"], list(range(site_count)))
        self.assertEqual(
            sites["site_type"].count("matrix"),
            case["summary"]["matrix_site_count"],
        )
        self.assertEqual(
            sites["site_type"].count("collector"),
            case["summary"]["collector_site_count"],
        )

        shape = tuple(snapshot["grid"]["shape"])
        for field_name in (
            "hf",
            "product",
            "interface_temperature_K",
            "solid_mask",
            "liquid_mask",
            "gas_mask",
            "interface_mask",
        ):
            with self.subTest(field=field_name):
                self.assertEqual(np.asarray(snapshot["fields"][field_name]).shape, shape)

    def test_explicit_phase_map_respects_declared_axis_order_and_shape(self) -> None:
        phase = self.payload["phase_map"]
        self.assertEqual(phase["axes"]["hf_scale"], [1.2, 0.8])
        self.assertEqual(
            phase["axes"]["retention_strength_scale"], [1.5, 0.0]
        )
        geometry = phase["by_geometry"]["10_8_180"]
        self.assertEqual(
            geometry["dimension_order"],
            ["retention_strength_scale", "hf_scale"],
        )
        expected_shape = (2, 2)
        for name, values in geometry["metrics"].items():
            with self.subTest(metric=name):
                self.assertEqual(np.asarray(values, dtype=float).shape, expected_shape)
        self.assertEqual(np.asarray(geometry["case_ids"]).shape, expected_shape)

    def test_process_pool_preserves_order_and_fixed_seed_results(self) -> None:
        parallel = run_trench_kmc_sweep(replace(self.config, parallel_workers=2))
        for key in (
            "case_order",
            "sensitivity_case_order",
            "cases",
            "sensitivity_cases",
            "mechanism_sensitivity",
            "phase_map",
        ):
            with self.subTest(section=key):
                self.assertEqual(parallel[key], self.payload[key])


if __name__ == "__main__":
    unittest.main()

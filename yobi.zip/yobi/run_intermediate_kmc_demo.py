#!/usr/bin/env python3
"""Run a visibly state-resolved, explicitly uncalibrated trench-KMC demo."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from reaction_diffusion_2d import CartesianGrid2D
from trench_geometry import GEOMETRY_PRESETS
from trench_graph_kmc import (
    ArrheniusRateSpec,
    ContinuumCouplingParameters,
    IntermediateStateKMCParameters,
    MaterialIntermediateKinetics,
    SpeciesActivitySpec,
    TrenchGraphConfig,
    TrenchKMCParameters,
    parameters_to_dict,
    run_coupled_trench_kmc,
)
from trench_graph_kmc_visualization import (
    plot_trench_kmc_event_history,
    plot_trench_kmc_phase_maps,
)
from trench_kmc_sweep import _snapshot, _surface_residue


SCHEMA_VERSION = "trench-intermediate-kmc-demo/v1"


def _rate(value: float, name: str) -> ArrheniusRateSpec:
    return ArrheniusRateSpec(
        activation_energy_eV=0.0,
        reference_rate_s=value,
        provenance=f"manual_topology_demo:{name}",
    )


def _intermediate_parameters(material: str) -> IntermediateStateKMCParameters:
    total_hf = SpeciesActivitySpec(total_hf_order=1.0)
    hf2 = SpeciesActivitySpec(hf2_order=1.0)
    hydrolysis_activity = (
        SpeciesActivitySpec(protonated_site_order=1.0)
        if material == "SiN"
        else None
    )
    return IntermediateStateKMCParameters(
        enabled=True,
        materials=(
            MaterialIntermediateKinetics(
                material=material,
                hydrolysis=_rate(0.45, "hydrolysis"),
                hydrolysis_activity=hydrolysis_activity,
                direct_fluorination=_rate(0.28, "direct_fluorination"),
                direct_fluorination_activity=hf2,
                silanol_fluorination=_rate(0.38, "silanol_fluorination"),
                silanol_fluorination_activity=hf2,
                hydrolyzed_removal=_rate(0.16, "hydrolyzed_removal"),
                hydrolyzed_removal_activity=total_hf,
                fluorinated_removal=_rate(0.24, "fluorinated_removal"),
                fluorinated_removal_activity=total_hf,
            ),
        ),
        water_activity=1.0,
        hf2_activity=0.70,
        fluoride_activity=0.15,
        protonated_site_fraction=0.35,
    )


def run_demo(
    *,
    geometry_name: str,
    material: str,
    spacing_nm: float,
    total_time_s: float,
    seed: int,
    output_dir: Path,
) -> dict[str, object]:
    geometry = GEOMETRY_PRESETS[geometry_name]
    grid = CartesianGrid2D.from_geometry(
        geometry,
        spacing_nm=spacing_nm,
        reservoir_height_nm=max(4.0, 2.0 * spacing_nm),
        lateral_margin_nm=max(2.0, spacing_nm),
    )
    graph_config = TrenchGraphConfig(
        maximum_sites=2_000,
        material=material,
    )
    coupling = ContinuumCouplingParameters(
        total_time_s=total_time_s,
        macro_time_step_s=min(5.0, total_time_s),
        maximum_events=20_000,
    )
    legacy = TrenchKMCParameters(
        activation_rate_s=0.0,
        removal_rate_s=0.0,
        passivation_rate_s=0.0,
        depassivation_rate_s=0.0,
        precipitation_rate_s=0.0,
        deposit_dissolution_rate_s=0.0,
        reattachment_rate_s=0.0,
        top_rate_factor=1.0,
        sidewall_rate_factor=1.0,
        bottom_rate_factor=1.0,
        core_rate_factor=1.0,
    )
    intermediate = _intermediate_parameters(material)
    outcome = run_coupled_trench_kmc(
        grid,
        graph_config=graph_config,
        coupling_parameters=coupling,
        kmc_parameters=legacy,
        intermediate_parameters=intermediate,
        seed=seed,
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    case_id = f"{geometry_name}__{material.lower()}"
    json_path = output_dir / f"{case_id}__intermediate_demo.json"
    figure_path = output_dir / f"{case_id}__intermediate_history.png"
    phase_path = output_dir / f"{case_id}__intermediate_snapshot.png"
    payload: dict[str, object] = {
        "schema_version": SCHEMA_VERSION,
        "case_id": case_id,
        "screening_only": True,
        "claim_boundary": (
            "All rates and species activities in this file are manual values "
            "chosen to exercise state topology and visualization. They are "
            "not a calibrated etch recipe or an atomistic-barrier mapping."
        ),
        "geometry_id": geometry_name,
        "material": material,
        "seed": seed,
        "parameters": parameters_to_dict(
            graph_config,
            coupling,
            legacy,
            intermediate_parameters=intermediate,
        ),
        "summary": {
            **dict(outcome.summary()),
            "surface_residue": _surface_residue(outcome),
            "total_site_count": outcome.layout.site_count,
        },
        "sync_history": [dict(item) for item in outcome.sync_history],
        "event_locations": [dict(item) for item in outcome.event_locations],
        "snapshot": _snapshot(outcome),
        "artifacts": {
            "results_json": json_path.name,
            "event_history_png": figure_path.name,
            "final_snapshot_png": phase_path.name,
        },
    }
    json_path.write_text(
        json.dumps(
            payload,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )
    plot_trench_kmc_event_history(outcome, figure_path)
    plot_trench_kmc_phase_maps(
        outcome,
        phase_path,
        x_visual_expansion=15.0,
    )
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--geometry",
        choices=tuple(GEOMETRY_PRESETS),
        default="7_7_170",
    )
    parser.add_argument(
        "--material",
        choices=("SiN", "SiCN", "SiOCN"),
        default="SiOCN",
    )
    parser.add_argument("--spacing-nm", type=float, default=2.0)
    parser.add_argument("--total-time-s", type=float, default=80.0)
    parser.add_argument("--seed", type=int, default=20260724)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/intermediate_kmc_demo"),
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.spacing_nm <= 0.0 or args.total_time_s <= 0.0:
        raise SystemExit("spacing and total time must be positive")
    if args.seed < 0:
        raise SystemExit("seed must be non-negative")
    payload = run_demo(
        geometry_name=args.geometry,
        material=args.material,
        spacing_nm=args.spacing_nm,
        total_time_s=args.total_time_s,
        seed=args.seed,
        output_dir=args.output_dir.resolve(),
    )
    print(
        json.dumps(
            {
                "case_id": payload["case_id"],
                "summary": payload["summary"],
                "screening_only": True,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Claim-bounded SiN full-fill screen for a dHF/DIW/SC1/DIW sequence.

Only the dHF stage is quantitatively calibrated.  The SiN blanket time series
is converted to a constant velocity over the requested dHF interval and
applied to a conservative partial-cell front.  DIW stages preserve the SiN
matrix.  SC1 is kept as an explicitly uncalibrated rate-ratio sensitivity
because this repository has no SiN-in-SC1 calibration at 40 degC.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Iterable, Mapping

import numpy as np

from level_set_2d import MonotonicLevelSet2D
from measured_blanket_clock import (
    BlanketEtchTimeSeries,
    piecewise_cumulative_etch_nm,
)
from reaction_diffusion_2d import CartesianGrid2D
from trench_geometry import GEOMETRY_PRESETS, TaperedTrench2D


SCHEMA_VERSION = "sin-fullfill-recipe-screen/v1"


def _positive(name: str, value: float) -> float:
    result = float(value)
    if not math.isfinite(result) or result <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return result


def _nonnegative_tuple(
    name: str, values: Iterable[float]
) -> tuple[float, ...]:
    result = tuple(float(value) for value in values)
    if not result or any(
        not math.isfinite(value) or value < 0.0 for value in result
    ):
        raise ValueError(f"{name} must contain finite non-negative values")
    if len(set(result)) != len(result):
        raise ValueError(f"{name} cannot contain duplicates")
    return result


@dataclass(frozen=True)
class SiNFullFillRecipeConfig:
    """Recipe and numerical settings for one fully filled straight trench."""

    geometry_id: str = "10_10_180"
    dhf_ratio_label: str = "1:100"
    dhf_duration_s: float = 20.0
    diw1_duration_s: float = 60.0
    sc1_duration_s: float = 180.0
    sc1_temperature_C: float = 40.0
    diw2_duration_s: float = 60.0
    nominal_grid_spacings_nm: tuple[float, ...] = (0.5, 0.25, 0.125)
    reservoir_height_nm: float = 2.0
    lateral_margin_nm: float = 2.0
    maximum_fractional_change: float = 0.2
    sc1_rate_ratios_to_initial_dhf: tuple[float, ...] = (
        0.0,
        0.01,
        0.1,
        1.0,
    )

    def __post_init__(self) -> None:
        if self.geometry_id not in GEOMETRY_PRESETS:
            raise ValueError("geometry_id must select a known geometry")
        geometry = GEOMETRY_PRESETS[self.geometry_id]
        if not math.isclose(
            geometry.top_width_nm,
            geometry.bottom_width_nm,
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise ValueError(
                "the aligned full-fill screen currently requires a straight trench"
            )
        if not self.dhf_ratio_label.strip():
            raise ValueError("dhf_ratio_label cannot be empty")
        for name in (
            "dhf_duration_s",
            "diw1_duration_s",
            "sc1_duration_s",
            "diw2_duration_s",
            "reservoir_height_nm",
            "lateral_margin_nm",
        ):
            _positive(name, getattr(self, name))
        if (
            not math.isfinite(self.sc1_temperature_C)
            or self.sc1_temperature_C <= -273.15
        ):
            raise ValueError("sc1_temperature_C must be above absolute zero")
        spacings = tuple(
            _positive("nominal_grid_spacing_nm", value)
            for value in self.nominal_grid_spacings_nm
        )
        if len(set(spacings)) != len(spacings):
            raise ValueError("nominal_grid_spacings_nm cannot contain duplicates")
        object.__setattr__(
            self,
            "nominal_grid_spacings_nm",
            tuple(sorted(spacings, reverse=True)),
        )
        if (
            not math.isfinite(self.maximum_fractional_change)
            or not 0.0 < self.maximum_fractional_change <= 1.0
        ):
            raise ValueError(
                "maximum_fractional_change must lie in (0, 1]"
            )
        object.__setattr__(
            self,
            "sc1_rate_ratios_to_initial_dhf",
            _nonnegative_tuple(
                "sc1_rate_ratios_to_initial_dhf",
                self.sc1_rate_ratios_to_initial_dhf,
            ),
        )

    @property
    def total_recipe_duration_s(self) -> float:
        return (
            self.dhf_duration_s
            + self.diw1_duration_s
            + self.sc1_duration_s
            + self.diw2_duration_s
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["nominal_grid_spacings_nm"] = list(
            self.nominal_grid_spacings_nm
        )
        result["sc1_rate_ratios_to_initial_dhf"] = list(
            self.sc1_rate_ratios_to_initial_dhf
        )
        result["total_recipe_duration_s"] = self.total_recipe_duration_s
        return result


@dataclass(frozen=True)
class FullFillFrontResult:
    """One fixed-time conservative-front calculation."""

    grid: CartesianGrid2D
    solid_fraction: np.ndarray
    metrics: Mapping[str, object]


def build_aligned_straight_grid(
    geometry: TaperedTrench2D,
    *,
    nominal_spacing_nm: float,
    reservoir_height_nm: float,
    lateral_margin_nm: float,
) -> CartesianGrid2D:
    """Build a centred straight-trench grid with exact cavity area.

    ``CartesianGrid2D.from_geometry`` deliberately places a cell centre on the
    symmetry line.  For an even width/spacing ratio this includes both physical
    edge centres and slightly overestimates a straight cavity.  Here the actual
    ``dx`` is adjusted so an odd number of cells tiles the physical width
    exactly, which makes the shallow-retreat area closure independent of mesh.
    """

    spacing = _positive("nominal_spacing_nm", nominal_spacing_nm)
    reservoir = _positive("reservoir_height_nm", reservoir_height_nm)
    margin = _positive("lateral_margin_nm", lateral_margin_nm)
    if not math.isclose(
        geometry.top_width_nm,
        geometry.bottom_width_nm,
        rel_tol=0.0,
        abs_tol=1.0e-12,
    ):
        raise ValueError("build_aligned_straight_grid requires a straight trench")

    width_cells = max(3, int(math.ceil(geometry.top_width_nm / spacing)))
    if width_cells % 2 == 0:
        width_cells += 1
    dx_nm = geometry.top_width_nm / width_cells
    margin_cells = max(1, int(math.ceil(margin / dx_nm)))
    nx = width_cells + 2 * margin_cells
    lateral_nm = (
        np.arange(nx, dtype=float) - 0.5 * (nx - 1)
    ) * dx_nm

    trench_rows = max(1, int(math.ceil(geometry.depth_nm / spacing)))
    dz_nm = geometry.depth_nm / trench_rows
    reservoir_rows = max(1, int(math.ceil(reservoir / dz_nm)))
    reservoir_depth_nm = -(
        np.arange(reservoir_rows, 0, -1, dtype=float) - 0.5
    ) * dz_nm
    trench_depth_nm = (
        np.arange(trench_rows, dtype=float) + 0.5
    ) * dz_nm
    depth_nm = np.concatenate((reservoir_depth_nm, trench_depth_nm))

    lateral_mesh, depth_mesh = np.meshgrid(
        lateral_nm, depth_nm, indexing="xy"
    )
    reservoir_mask = depth_mesh < 0.0
    cavity_mask = np.asarray(
        geometry.contains_nm(lateral_mesh, depth_mesh), dtype=bool
    )
    grid = CartesianGrid2D(
        geometry=geometry,
        lateral_nm=lateral_nm,
        depth_nm=depth_nm,
        dx_nm=dx_nm,
        dz_nm=dz_nm,
        reservoir_mask=reservoir_mask,
        cavity_mask=cavity_mask,
    )
    discrete_area_nm2 = (
        float(np.count_nonzero(grid.cavity_mask)) * grid.cell_area_nm2
    )
    if not math.isclose(
        discrete_area_nm2,
        geometry.area_nm2,
        rel_tol=0.0,
        abs_tol=1.0e-9,
    ):
        raise RuntimeError("aligned straight grid did not close cavity area")
    return grid


def _initial_interval_rate_nm_min(
    series: BlanketEtchTimeSeries,
) -> float:
    left, right = series.points[:2]
    duration_min = (right.time_s - left.time_s) / 60.0
    return (right.etch_amount_nm - left.etch_amount_nm) / duration_min


def simulate_dhf_fullfill_front(
    series: BlanketEtchTimeSeries,
    config: SiNFullFillRecipeConfig,
    *,
    nominal_spacing_nm: float,
) -> FullFillFrontResult:
    """Advance one full-fill front for the measured-clock dHF duration."""

    if series.material.strip().lower() != "sin":
        raise ValueError("the full-fill recipe screen requires a SiN series")
    target_retreat_nm, clock_status = piecewise_cumulative_etch_nm(
        series, config.dhf_duration_s
    )
    if target_retreat_nm is None:
        raise ValueError("dHF duration lies outside the measured blanket window")
    geometry = GEOMETRY_PRESETS[config.geometry_id]
    if target_retreat_nm >= geometry.depth_nm:
        raise ValueError(
            "this shallow planar-front screen cannot pass the trench floor"
        )
    grid = build_aligned_straight_grid(
        geometry,
        nominal_spacing_nm=nominal_spacing_nm,
        reservoir_height_nm=config.reservoir_height_nm,
        lateral_margin_nm=config.lateral_margin_nm,
    )
    front = MonotonicLevelSet2D(grid)
    normal_velocity_nm_s = target_retreat_nm / config.dhf_duration_s
    remaining_time_s = config.dhf_duration_s
    steps = 0
    maximum_mass_balance_relative_error = 0.0
    while remaining_time_s > 1.0e-12:
        stable_dt_s = front.stable_time_step_s(
            normal_velocity_nm_s,
            maximum_fractional_change=config.maximum_fractional_change,
        )
        dt_s = min(remaining_time_s, stable_dt_s)
        step = front.advance(normal_velocity_nm_s, dt_s)
        maximum_mass_balance_relative_error = max(
            maximum_mass_balance_relative_error,
            step.mass_balance_relative_error,
        )
        remaining_time_s -= dt_s
        steps += 1

    diagnostics = front.diagnostics()
    equivalent_planar_retreat_nm = (
        diagnostics.dissolved_area_nm2 / geometry.top_width_nm
    )
    bottom_row = grid.cavity_mask & (
        grid.depth_mesh_nm > geometry.depth_nm - grid.dz_nm
    )
    bottom_minimum_solid_fraction = float(
        np.min(front.solid_fraction[bottom_row])
    )
    metrics: dict[str, object] = {
        "nominal_grid_spacing_nm": float(nominal_spacing_nm),
        "actual_dx_nm": grid.dx_nm,
        "actual_dz_nm": grid.dz_nm,
        "grid_shape": list(grid.shape),
        "time_steps": steps,
        "blanket_clock_status": clock_status,
        "target_planar_retreat_nm": target_retreat_nm,
        "equivalent_planar_retreat_nm": equivalent_planar_retreat_nm,
        "absolute_retreat_closure_error_nm": abs(
            equivalent_planar_retreat_nm - target_retreat_nm
        ),
        "initial_solid_area_nm2": diagnostics.initial_solid_area_nm2,
        "geometric_cavity_area_nm2": diagnostics.geometric_cavity_area_nm2,
        "initial_area_discretization_relative_error": (
            diagnostics.initial_area_discretization_relative_error
        ),
        "dissolved_area_nm2": diagnostics.dissolved_area_nm2,
        "remaining_solid_area_nm2": diagnostics.remaining_solid_area_nm2,
        "dissolved_solid_fraction": diagnostics.dissolved_mass_fraction,
        "remaining_solid_fraction": diagnostics.remaining_mass_fraction,
        "maximum_step_mass_balance_relative_error": (
            maximum_mass_balance_relative_error
        ),
        "bottom_minimum_solid_fraction": bottom_minimum_solid_fraction,
        "bottom_exposed": bool(bottom_minimum_solid_fraction < 1.0 - 1.0e-12),
    }
    return FullFillFrontResult(
        grid=grid,
        solid_fraction=front.solid_fraction.copy(),
        metrics=metrics,
    )


def _recipe_stage_rows(
    config: SiNFullFillRecipeConfig,
    *,
    retreat_nm: float,
    remaining_fraction: float,
) -> list[dict[str, object]]:
    cumulative_s = 0.0
    rows: list[dict[str, object]] = [
        {
            "stage_index": 0,
            "stage": "initial_full_fill",
            "duration_s": 0.0,
            "end_time_s": 0.0,
            "temperature_C": None,
            "quantitative_status": "defined_initial_state",
            "quantified_top_retreat_nm": 0.0,
            "quantified_remaining_solid_fraction": 1.0,
            "null_branch_top_retreat_nm": 0.0,
            "matrix_state": "fully_filled_SiN",
        }
    ]
    cumulative_s += config.dhf_duration_s
    rows.append(
        {
            "stage_index": 1,
            "stage": "dHF",
            "duration_s": config.dhf_duration_s,
            "end_time_s": cumulative_s,
            "temperature_C": None,
            "quantitative_status": "measured_clock_interpolation",
            "quantified_top_retreat_nm": retreat_nm,
            "quantified_remaining_solid_fraction": remaining_fraction,
            "null_branch_top_retreat_nm": retreat_nm,
            "matrix_state": "quantified_partial_cell_front",
        }
    )
    cumulative_s += config.diw1_duration_s
    rows.append(
        {
            "stage_index": 2,
            "stage": "DIW_1",
            "duration_s": config.diw1_duration_s,
            "end_time_s": cumulative_s,
            "temperature_C": None,
            "quantitative_status": "state_preserving_matrix_assumption",
            "quantified_top_retreat_nm": retreat_nm,
            "quantified_remaining_solid_fraction": remaining_fraction,
            "null_branch_top_retreat_nm": retreat_nm,
            "matrix_state": "SiN_unchanged_immediate_HF_quench",
        }
    )
    cumulative_s += config.sc1_duration_s
    rows.append(
        {
            "stage_index": 3,
            "stage": "SC1",
            "duration_s": config.sc1_duration_s,
            "end_time_s": cumulative_s,
            "temperature_C": config.sc1_temperature_C,
            "quantitative_status": "unresolved_no_calibrated_SiN_rate",
            "quantified_top_retreat_nm": None,
            "quantified_remaining_solid_fraction": None,
            "null_branch_top_retreat_nm": retreat_nm,
            "matrix_state": "null_branch_only_not_process_prediction",
        }
    )
    cumulative_s += config.diw2_duration_s
    rows.append(
        {
            "stage_index": 4,
            "stage": "DIW_2",
            "duration_s": config.diw2_duration_s,
            "end_time_s": cumulative_s,
            "temperature_C": None,
            "quantitative_status": "unresolved_after_SC1",
            "quantified_top_retreat_nm": None,
            "quantified_remaining_solid_fraction": None,
            "null_branch_top_retreat_nm": retreat_nm,
            "matrix_state": "null_branch_only_not_process_prediction",
        }
    )
    return rows


def run_sin_fullfill_recipe_screen(
    series: BlanketEtchTimeSeries,
    config: SiNFullFillRecipeConfig | None = None,
) -> dict[str, object]:
    """Run the mesh ladder and build a JSON-safe recipe payload."""

    resolved = SiNFullFillRecipeConfig() if config is None else config
    if series.material.strip().lower() != "sin":
        raise ValueError("the full-fill recipe screen requires a SiN series")
    geometry = GEOMETRY_PRESETS[resolved.geometry_id]
    retreat_nm, clock_status = piecewise_cumulative_etch_nm(
        series, resolved.dhf_duration_s
    )
    if retreat_nm is None:
        raise ValueError("dHF duration lies outside the measured blanket window")
    initial_rate_nm_min = _initial_interval_rate_nm_min(series)
    ladder = [
        dict(
            simulate_dhf_fullfill_front(
                series,
                resolved,
                nominal_spacing_nm=spacing_nm,
            ).metrics
        )
        for spacing_nm in resolved.nominal_grid_spacings_nm
    ]
    finest = ladder[-1]
    remaining_fraction = float(finest["remaining_solid_fraction"])
    stages = _recipe_stage_rows(
        resolved,
        retreat_nm=retreat_nm,
        remaining_fraction=remaining_fraction,
    )

    sc1_sensitivity: list[dict[str, object]] = []
    for alpha in resolved.sc1_rate_ratios_to_initial_dhf:
        sc1_rate_nm_min = alpha * initial_rate_nm_min
        sc1_added_retreat_nm = (
            sc1_rate_nm_min * resolved.sc1_duration_s / 60.0
        )
        total_retreat_nm = min(
            geometry.depth_nm, retreat_nm + sc1_added_retreat_nm
        )
        sc1_sensitivity.append(
            {
                "alpha_SC1_to_initial_dHF_rate": alpha,
                "SC1_rate_nm_min": sc1_rate_nm_min,
                "SC1_added_retreat_nm": sc1_added_retreat_nm,
                "total_top_retreat_after_SC1_nm": total_retreat_nm,
                "remaining_vertical_fill_nm": max(
                    0.0, geometry.depth_nm - total_retreat_nm
                ),
                "removed_solid_fraction": total_retreat_nm
                / geometry.depth_nm,
                "remaining_solid_fraction": 1.0
                - total_retreat_nm / geometry.depth_nm,
                "bottom_exposed": bool(total_retreat_nm >= geometry.depth_nm),
                "status": "uncalibrated_sensitivity_not_prediction",
            }
        )

    payload: dict[str, object] = {
        "schema_version": SCHEMA_VERSION,
        "case_id": (
            f"SiN_fullfill_{resolved.geometry_id}_dHF"
            f"{resolved.dhf_duration_s:g}s_DIW{resolved.diw1_duration_s:g}s_"
            f"SC1{resolved.sc1_duration_s:g}s_"
            f"{resolved.sc1_temperature_C:g}C_DIW"
            f"{resolved.diw2_duration_s:g}s"
        ),
        "material": "SiN",
        "geometry": geometry.to_dict(),
        "config": resolved.to_dict(),
        "source_series": series.to_dict(),
        "recipe": {
            "steps": [
                {
                    "name": "dHF",
                    "ratio_label": resolved.dhf_ratio_label,
                    "duration_s": resolved.dhf_duration_s,
                    "temperature_C": None,
                },
                {
                    "name": "DIW_1",
                    "duration_s": resolved.diw1_duration_s,
                    "temperature_C": None,
                },
                {
                    "name": "SC1",
                    "duration_s": resolved.sc1_duration_s,
                    "temperature_C": resolved.sc1_temperature_C,
                    "composition": None,
                },
                {
                    "name": "DIW_2",
                    "duration_s": resolved.diw2_duration_s,
                    "temperature_C": None,
                },
            ],
            "total_duration_s": resolved.total_recipe_duration_s,
            "dry_step_present": False,
        },
        "dhf_calibrated_endpoint": {
            "duration_s": resolved.dhf_duration_s,
            "clock_status": clock_status,
            "top_retreat_nm": retreat_nm,
            "effective_velocity_nm_s": retreat_nm
            / resolved.dhf_duration_s,
            "initial_interval_rate_nm_min": initial_rate_nm_min,
            "remaining_vertical_fill_nm": geometry.depth_nm - retreat_nm,
            "dissolved_cross_section_nm2": (
                geometry.top_width_nm * retreat_nm
            ),
            "removed_solid_fraction": retreat_nm / geometry.depth_nm,
            "remaining_solid_fraction": 1.0
            - retreat_nm / geometry.depth_nm,
            "bottom_exposed": False,
        },
        "mesh_ladder": ladder,
        "stage_states": stages,
        "sc1_sensitivity": sc1_sensitivity,
        "claim_boundary": {
            "quantitative_endpoint": "after_dHF_20s",
            "diw_matrix_rule": (
                "zero direct SiN removal and immediate HF quench"
            ),
            "sc1_quantitative_prediction_available": False,
            "sc1_reason": (
                "no SiN SC1-only blanket WER, composition, or calibrated "
                "40 degC rate law is available"
            ),
            "sc1_null_branch_is_prediction": False,
            "sc1_sensitivity_is_prediction": False,
            "drydown_redeposition_enabled": False,
            "pinning_or_persistent_gas_active": False,
            "pinning_reason": (
                "a fully solid fill has no connected internal liquid path; "
                "20 s retreat does not expose the trench interior"
            ),
            "passivation_added_to_clock": False,
            "passivation_reason": (
                "the measured cumulative clock already supplies the net dHF "
                "retreat and no independent passivation calibration exists"
            ),
            "applicability_assumptions": [
                (
                    "the supplied blanket series is the same dHF 1:100 "
                    "chemistry and comparable SiN film as this recipe"
                ),
                (
                    "the trench is a void-free, seam-free, fully solid SiN "
                    "fill with a planar open top"
                ),
                (
                    "the assumed (0 s, 0 nm) origin and linear 0-60 s "
                    "interpolation are accepted for the 20 s point"
                ),
            ],
        },
    }
    return payload


__all__ = [
    "FullFillFrontResult",
    "SCHEMA_VERSION",
    "SiNFullFillRecipeConfig",
    "build_aligned_straight_grid",
    "run_sin_fullfill_recipe_screen",
    "simulate_dhf_fullfill_front",
]

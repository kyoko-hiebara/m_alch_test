"""Traceable literature inputs for dilute-HF GAP-FILL screening.

The presets in this module are deliberately film-specific.  Labels such as
``low`` and ``high`` describe the reported removal rate of different films;
they are not statistical confidence limits for one material.  Values copied
from a paper/patent, unit conversions, interpolations, and modelling
assumptions are kept as separate metadata fields.

The blanket-film rates are suitable as empirical boundary conditions at the
reported chemistry.  Extrapolating those rates through a 170--180 nm GAP FILL
is a screening calculation, not a validated process prediction.

Kawarazaki et al. Fig. 2 supplies 30 s etch *amounts*, not steady-state rates.
The corresponding presets retain those raw endpoints and expose a provisional
linear 30 s normalization separately.  The ozone-bake/dHF sequence remains a
cycle endpoint and is never folded into the primary-HF blanket clock.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Mapping

import numpy as np


HF_MOLAR_MASS_KG_MOL = 0.0200063
WATER_DENSITY_298_KG_M3 = 997.047
HF_DIFFUSIVITY_298_M2_S = 1.68e-9
HF_DIFFUSIVITY_298_NM2_S = HF_DIFFUSIVITY_298_M2_S * 1.0e18


@dataclass(frozen=True)
class LiteratureSource:
    key: str
    citation: str
    url: str
    source_kind: str
    directly_supports: str
    caveat: str = ""

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


SOURCES: Mapping[str, LiteratureSource] = MappingProxyType(
    {
        "barcellona_2023": LiteratureSource(
            key="barcellona_2023",
            citation=(
                "Barcellona et al., Materials Chemistry and Physics 306 "
                "(2023) 128023, doi:10.1016/j.matchemphys.2023.128023"
            ),
            url="https://doi.org/10.1016/j.matchemphys.2023.128023",
            source_kind="peer-reviewed article",
            directly_supports=(
                "PECVD a-SiNx:H blanket-film WER at 25 degC in unbuffered "
                "0.55/2.19/5.44 wt% HF"
            ),
            caveat=(
                "The bath was refreshed to suppress by-product interference; "
                "the data do not quantify deep-trench product accumulation."
            ),
        ),
        "fujitsu_siocn_2013": LiteratureSource(
            key="fujitsu_siocn_2013",
            citation="US20130164946A1, silicon carbon nitride film disclosure",
            url="https://patents.google.com/patent/US20130164946A1/en",
            source_kind="primary patent disclosure; not peer reviewed",
            directly_supports=(
                "Composition-resolved SiOCN film loss after 60 s in 100:1 "
                "H2O:HF"
            ),
            caveat=(
                "HF stock concentration and liquid temperature are not "
                "reported; 0.57 wt% and 298.15 K are transport-only modelling "
                "conventions, not disclosed process values."
            ),
        ),
        "kawarazaki_2024": LiteratureSource(
            key="kawarazaki_2024",
            citation=(
                "Kawarazaki et al., ECS Meeting Abstracts MA2024-02 (31) "
                "(2024) 2265, doi:10.1149/MA2024-02312265mtgabs"
            ),
            url="https://doi.org/10.1149/MA2024-02312265mtgabs",
            source_kind="one-page ECS meeting abstract; Fig. 2 raster",
            directly_supports=(
                "Ellipsometry thickness loss for ALD blanket SiCN C:22%, "
                "SiCN C:40%, SiOCN C:5%, and SiN after dHF 0.15% for 30 s, "
                "with and without a preceding 240 degC 30 s ozone bake; "
                "ozone-bake-time saturation from 15--120 s for the three "
                "inner-spacer films; and cumulative removal through three "
                "cycles for those three films"
            ),
            caveat=(
                "Figs. 2--4 have no error bars or numerical tables. Values "
                "below are approximate raster digitizations; carbon-percent "
                "basis, dHF concentration basis, wet temperature, film "
                "density, and full composition are not reported. Fig. 4 "
                "supports linear cumulative removal only through three cycles "
                "for the three inner-spacer films; its ozone-bake duration is "
                "not identified, and repeated-cycle SiN loss is not shown."
            ),
        ),
        "noulty_leaist_1985": LiteratureSource(
            key="noulty_leaist_1985",
            citation=(
                "Noulty and Leaist, Electrochimica Acta 30 (1985), "
                "doi:10.1016/0013-4686(85)80179-1"
            ),
            url="https://doi.org/10.1016/0013-4686(85)80179-1",
            source_kind="peer-reviewed article",
            directly_supports=(
                "Limiting molecular-HF diffusion coefficient "
                "(1.68 +/- 0.02)e-9 m2/s at 25 degC"
            ),
            caveat=(
                "Measured over 0.001--0.1 mol/dm3; use at about 0.25 M is an "
                "extrapolation and nanoconfinement is not included."
            ),
        ),
        "hamer_wu_1970": LiteratureSource(
            key="hamer_wu_1970",
            citation=(
                "Hamer and Wu, J. Phys. Chem. Ref. Data precursor/NBS critical "
                "evaluation, J. Res. NBS 74A (1970) 761"
            ),
            url=(
                "https://nvlpubs.nist.gov/nistpubs/jres/74A/"
                "jresv74An6p761_A1b.pdf"
            ),
            source_kind="NBS critical evaluation",
            directly_supports=(
                "25 degC equilibrium molalities of HF, F-, and HF2- versus "
                "analytical HF molality"
            ),
            caveat=(
                "The code linearly interpolates the evaluated table and uses "
                "pure-water density to convert molality to mol/m3."
            ),
        ),
        "braun_2021": LiteratureSource(
            key="braun_2021",
            citation=(
                "Braun et al., Physical Review Materials 5 (2021) 035604, "
                "doi:10.1103/PhysRevMaterials.5.035604"
            ),
            url="https://doi.org/10.1103/PhysRevMaterials.5.035604",
            source_kind="peer-reviewed article",
            directly_supports=(
                "PECVD a-SiNx:H density 2.3 +/- 0.1 g/cm3 and thermal "
                "conductivity 0.89--1.14 W/(m K)"
            ),
            caveat=(
                "The 5.31e4 mol-Si/m3 site density used here is derived from "
                "the reported mid-composition film, not reported directly."
            ),
        ),
        "siocn_density_2020": LiteratureSource(
            key="siocn_density_2020",
            citation="US20200294798A1, plasma-treated SiOCN film disclosure",
            url="https://patents.google.com/patent/US20200294798A1/en",
            source_kind="primary patent disclosure; not peer reviewed",
            directly_supports="SiOCN density range 1.5--2.1 g/cm3",
            caveat=(
                "The 3.25e4 mol-Si/m3 site density and 1.0 W/(m K) thermal "
                "conductivity are modelling estimates, not direct values."
            ),
        ),
        "water_iapws": LiteratureSource(
            key="water_iapws",
            citation="IAPWS Release on the Thermal Conductivity of Water (2011)",
            url="https://www.iapws.org/documents/release/ThCond",
            source_kind="international reference formulation",
            directly_supports="Water thermal conductivity near 298 K",
            caveat="The model uses 0.6065 W/(m K) for dilute HF.",
        ),
        "silicon_nist": LiteratureSource(
            key="silicon_nist",
            citation="NIST recommended thermal conductivity of silicon",
            url="https://srd.nist.gov/jpcrdreprint/1.3253100.pdf",
            source_kind="NIST critical compilation",
            directly_supports=(
                "High-purity Si thermal conductivity 149 W/(m K) at 298.2 K "
                "and 133 W/(m K) at 323.2 K"
            ),
            caveat=(
                "Wafer doping, defects, geometry, and contacts can change the "
                "effective substrate value."
            ),
        ),
    }
)


@dataclass(frozen=True)
class HFSpeciation298K:
    """Interpolated 25 degC HF equilibrium composition.

    Concentrations are returned in mol/m3 of solution.  The source table is in
    mol/kg solvent; pure-water density is used as the dilute-solution density.
    """

    hf_weight_percent: float
    solution_density_kg_m3: float
    analytical_hf_molality_mol_kg: float
    analytical_fluorine_mol_m3: float
    neutral_hf_mol_m3: float
    fluoride_mol_m3: float
    bifluoride_mol_m3: float
    hydronium_mol_m3: float
    interpolation_range_mol_kg: tuple[float, float]

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["interpolation_range_mol_kg"] = list(
            self.interpolation_range_mol_kg
        )
        return result


# Hamer--Wu evaluated values at 25 degC.  The analytical column counts F atoms,
# so C_total = [HF] + [F-] + 2[HF2-].
_HF_MOLALITY_TABLE = np.asarray([0.01, 0.05, 0.10, 0.20, 0.50], dtype=float)
_NEUTRAL_HF_TABLE = np.asarray(
    [0.007525, 0.04313, 0.08848, 0.17946, 0.45064], dtype=float
)
_FLUORIDE_TABLE = np.asarray(
    [0.002381, 0.005602, 0.007869, 0.01058, 0.01467], dtype=float
)
_BIFLUORIDE_TABLE = np.asarray(
    [0.0000470, 0.000634, 0.001827, 0.004983, 0.01735], dtype=float
)


def hf_speciation_298K_from_weight_percent(
    hf_weight_percent: float,
    *,
    solution_density_kg_m3: float = WATER_DENSITY_298_KG_M3,
) -> HFSpeciation298K:
    """Convert dilute HF wt% to the interpolated neutral-HF boundary value.

    The table is intentionally not extrapolated.  The supported interval is
    approximately 0.02--0.99 wt% HF, covering the 0.55--0.57 wt% presets.
    """

    wt_percent = float(hf_weight_percent)
    density = float(solution_density_kg_m3)
    if not math.isfinite(wt_percent) or wt_percent <= 0.0 or wt_percent >= 100.0:
        raise ValueError("hf_weight_percent must be finite and within (0, 100)")
    if not math.isfinite(density) or density <= 0.0:
        raise ValueError("solution_density_kg_m3 must be finite and positive")
    mass_fraction = wt_percent / 100.0
    solvent_mass_fraction = 1.0 - mass_fraction
    molality = (
        mass_fraction / HF_MOLAR_MASS_KG_MOL / solvent_mass_fraction
    )
    minimum = float(_HF_MOLALITY_TABLE[0])
    maximum = float(_HF_MOLALITY_TABLE[-1])
    tolerance = 1.0e-12
    if molality < minimum - tolerance or molality > maximum + tolerance:
        raise ValueError(
            "HF molality is outside the tabulated 25 degC interval "
            f"[{minimum:g}, {maximum:g}] mol/kg"
        )

    neutral_molality = float(
        np.interp(molality, _HF_MOLALITY_TABLE, _NEUTRAL_HF_TABLE)
    )
    fluoride_molality = float(
        np.interp(molality, _HF_MOLALITY_TABLE, _FLUORIDE_TABLE)
    )
    bifluoride_molality = float(
        np.interp(molality, _HF_MOLALITY_TABLE, _BIFLUORIDE_TABLE)
    )
    # Published table entries are rounded.  Preserve the analytical-fluorine
    # inventory exactly after interpolation with a sub-0.01% common rescaling.
    rounded_balance = (
        neutral_molality + fluoride_molality + 2.0 * bifluoride_molality
    )
    balance_scale = molality / rounded_balance
    neutral_molality *= balance_scale
    fluoride_molality *= balance_scale
    bifluoride_molality *= balance_scale
    solvent_kg_m3 = solvent_mass_fraction * density
    analytical = molality * solvent_kg_m3
    neutral = neutral_molality * solvent_kg_m3
    fluoride = fluoride_molality * solvent_kg_m3
    bifluoride = bifluoride_molality * solvent_kg_m3
    # Neglect OH- at these acidities.  Charge neutrality then gives this value.
    hydronium = fluoride + bifluoride
    return HFSpeciation298K(
        hf_weight_percent=wt_percent,
        solution_density_kg_m3=density,
        analytical_hf_molality_mol_kg=molality,
        analytical_fluorine_mol_m3=analytical,
        neutral_hf_mol_m3=neutral,
        fluoride_mol_m3=fluoride,
        bifluoride_mol_m3=bifluoride,
        hydronium_mol_m3=hydronium,
        interpolation_range_mol_kg=(minimum, maximum),
    )


@dataclass(frozen=True)
class LiteratureEtchPreset:
    """One film-specific empirical blanket-rate input."""

    key: str
    material: str
    rate_band: str
    film_description: str
    planar_rate_nm_min: float
    planar_rate_uncertainty_nm_min: float | None
    reported_solution: str
    reported_solution_temperature_K: float | None
    transport_hf_weight_percent: float
    transport_concentration_basis: str
    solid_density_g_cm3: float
    solid_si_site_density_mol_m3: float
    fill_thermal_conductivity_W_mK: float
    effective_hf_per_si: float
    rate_source_key: str
    property_source_keys: tuple[str, ...]
    rate_evidence: str
    extrapolation_caveat: str

    def __post_init__(self) -> None:
        if self.material not in {"SiN", "SiCN", "SiOCN"}:
            raise ValueError("material must be SiN, SiCN, or SiOCN")
        for name in (
            "planar_rate_nm_min",
            "transport_hf_weight_percent",
            "solid_density_g_cm3",
            "solid_si_site_density_mol_m3",
            "fill_thermal_conductivity_W_mK",
            "effective_hf_per_si",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        if self.planar_rate_uncertainty_nm_min is not None:
            value = float(self.planar_rate_uncertainty_nm_min)
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(
                    "planar_rate_uncertainty_nm_min must be finite and non-negative"
                )
        if self.rate_source_key not in SOURCES:
            raise ValueError(f"unknown source key {self.rate_source_key!r}")
        for key in self.property_source_keys:
            if key not in SOURCES:
                raise ValueError(f"unknown source key {key!r}")

    @property
    def planar_rate_nm_s(self) -> float:
        return self.planar_rate_nm_min / 60.0

    @property
    def planar_rate_m_s(self) -> float:
        return self.planar_rate_nm_s * 1.0e-9

    def hf_speciation(self) -> HFSpeciation298K:
        return hf_speciation_298K_from_weight_percent(
            self.transport_hf_weight_percent
        )

    def first_order_surface_transfer_nm_s(self) -> float:
        """Return the Robin velocity that closes reactant consumption.

        ``effective_hf_per_si`` is a modelling closure.  Six corresponds to
        complete conversion of each Si to H2SiF6; actual aqueous pathways and
        proton bookkeeping can differ.
        """

        concentration = self.hf_speciation().neutral_hf_mol_m3
        return (
            self.planar_rate_nm_s
            * self.solid_si_site_density_mol_m3
            * self.effective_hf_per_si
            / concentration
        )

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["property_source_keys"] = list(self.property_source_keys)
        result["planar_rate_nm_s"] = self.planar_rate_nm_s
        result["first_order_surface_transfer_nm_s"] = (
            self.first_order_surface_transfer_nm_s()
        )
        result["hf_speciation_298K"] = self.hf_speciation().to_dict()
        result["sources"] = {
            key: SOURCES[key].to_dict()
            for key in (self.rate_source_key,) + self.property_source_keys
        }
        return result


@dataclass(frozen=True)
class LiteratureCyclicEtchEndpoint:
    """One paired blanket endpoint from an oxidation/dHF experiment.

    ``dhf_only_etch_amount_nm`` is normalized linearly only when the caller
    requests a dHF-only duration.  ``ozone_then_dhf_etch_amount_nm`` remains a
    per-cycle endpoint at the reported fixed 30 s + 30 s sequence.
    """

    key: str
    material: str
    film_description: str
    nominal_carbon_percent: float | None
    carbon_percent_basis: str
    ozone_bake_temperature_K: float
    ozone_concentration_g_m3: float
    ozone_bake_duration_s: float
    dhf_reported_percent: float
    dhf_concentration_basis: str
    dhf_duration_s: float
    ozone_then_dhf_etch_amount_nm: float
    dhf_only_etch_amount_nm: float
    digitization_resolution_nm: float
    source_key: str
    value_basis: str = "raster-digitized approximate"
    linearity_assumption: str = (
        "dHF-only loss scales linearly with exposure time and the fixed "
        "30 s ozone + 30 s dHF endpoint scales linearly with cycle count"
    )
    reported_cycle_linearity_max: int = 1
    reported_cycle_ozone_duration_matches_endpoint: bool = True

    def __post_init__(self) -> None:
        if not self.key:
            raise ValueError("endpoint key must not be empty")
        if self.material not in {"SiN", "SiCN", "SiOCN"}:
            raise ValueError("material must be SiN, SiCN, or SiOCN")
        for name in (
            "ozone_bake_temperature_K",
            "ozone_concentration_g_m3",
            "ozone_bake_duration_s",
            "dhf_reported_percent",
            "dhf_duration_s",
            "digitization_resolution_nm",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        for name in (
            "ozone_then_dhf_etch_amount_nm",
            "dhf_only_etch_amount_nm",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and non-negative")
        if (
            self.ozone_then_dhf_etch_amount_nm
            < self.dhf_only_etch_amount_nm
        ):
            raise ValueError(
                "ozone+dHF endpoint cannot be below the paired dHF-only endpoint"
            )
        if self.nominal_carbon_percent is not None:
            value = float(self.nominal_carbon_percent)
            if not math.isfinite(value) or not 0.0 <= value <= 100.0:
                raise ValueError(
                    "nominal_carbon_percent must be finite and within [0, 100]"
                )
        if self.source_key not in SOURCES:
            raise ValueError(f"unknown source key {self.source_key!r}")
        if (
            not isinstance(self.reported_cycle_linearity_max, int)
            or self.reported_cycle_linearity_max < 1
        ):
            raise ValueError(
                "reported_cycle_linearity_max must be a positive integer"
            )

    @property
    def dhf_only_apparent_rate_nm_min(self) -> float:
        """Return the user-approved provisional linear 30 s normalization."""

        return round(
            self.dhf_only_etch_amount_nm * 60.0 / self.dhf_duration_s,
            12,
        )

    @property
    def ozone_enabled_increment_nm_per_cycle(self) -> float:
        """Return the paired-condition difference, not ozone-only removal."""

        return round(
            self.ozone_then_dhf_etch_amount_nm
            - self.dhf_only_etch_amount_nm,
            12,
        )

    def predict_dhf_only_etch_nm(self, duration_s: float) -> float:
        duration = float(duration_s)
        if not math.isfinite(duration) or duration < 0.0:
            raise ValueError("duration_s must be finite and non-negative")
        return round(
            self.dhf_only_apparent_rate_nm_min * duration / 60.0,
            12,
        )

    def predict_ozone_dhf_etch_nm(self, cycles: int) -> float:
        if not isinstance(cycles, int) or cycles < 0:
            raise ValueError("cycles must be a non-negative integer")
        return round(cycles * self.ozone_then_dhf_etch_amount_nm, 12)

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["dhf_only_apparent_rate_nm_min"] = (
            self.dhf_only_apparent_rate_nm_min
        )
        result["ozone_enabled_increment_nm_per_cycle"] = (
            self.ozone_enabled_increment_nm_per_cycle
        )
        result["source"] = SOURCES[self.source_key].to_dict()
        return result


_COMMON_PROPERTY_SOURCES = (
    "noulty_leaist_1985",
    "hamer_wu_1970",
    "water_iapws",
    "silicon_nist",
)


KAWARAZAKI_2024_FIG2_ENDPOINTS: Mapping[
    str, LiteratureCyclicEtchEndpoint
] = MappingProxyType(
    {
        endpoint.key: endpoint
        for endpoint in (
            LiteratureCyclicEtchEndpoint(
                key="kawarazaki_sicn_c22",
                material="SiCN",
                film_description="ALD SiCN, nominal C:22% as labelled in Fig. 2",
                nominal_carbon_percent=22.0,
                carbon_percent_basis=(
                    "nominal figure label; analytical basis undisclosed"
                ),
                ozone_bake_temperature_K=513.15,
                ozone_concentration_g_m3=100.0,
                ozone_bake_duration_s=30.0,
                dhf_reported_percent=0.15,
                dhf_concentration_basis=(
                    "reported only as 0.15%; treated as wt% for provisional "
                    "transport speciation"
                ),
                dhf_duration_s=30.0,
                ozone_then_dhf_etch_amount_nm=2.47,
                dhf_only_etch_amount_nm=0.03,
                digitization_resolution_nm=0.05,
                source_key="kawarazaki_2024",
                value_basis=(
                    "Fig. 2 raster digitization; dHF-only value aligned to "
                    "the abstract-reported 0.03 nm lower endpoint"
                ),
                reported_cycle_linearity_max=3,
                reported_cycle_ozone_duration_matches_endpoint=False,
            ),
            LiteratureCyclicEtchEndpoint(
                key="kawarazaki_sicn_c40",
                material="SiCN",
                film_description="ALD SiCN, nominal C:40% as labelled in Fig. 2",
                nominal_carbon_percent=40.0,
                carbon_percent_basis=(
                    "nominal figure label; analytical basis undisclosed"
                ),
                ozone_bake_temperature_K=513.15,
                ozone_concentration_g_m3=100.0,
                ozone_bake_duration_s=30.0,
                dhf_reported_percent=0.15,
                dhf_concentration_basis=(
                    "reported only as 0.15%; treated as wt% for provisional "
                    "transport speciation"
                ),
                dhf_duration_s=30.0,
                ozone_then_dhf_etch_amount_nm=0.70,
                dhf_only_etch_amount_nm=0.13,
                digitization_resolution_nm=0.05,
                source_key="kawarazaki_2024",
                value_basis="Fig. 2 raster-digitized approximate",
                reported_cycle_linearity_max=3,
                reported_cycle_ozone_duration_matches_endpoint=False,
            ),
            LiteratureCyclicEtchEndpoint(
                key="kawarazaki_siocn_c5",
                material="SiOCN",
                film_description="ALD SiOCN, nominal C:5% as labelled in Fig. 2",
                nominal_carbon_percent=5.0,
                carbon_percent_basis=(
                    "nominal figure label; analytical basis undisclosed"
                ),
                ozone_bake_temperature_K=513.15,
                ozone_concentration_g_m3=100.0,
                ozone_bake_duration_s=30.0,
                dhf_reported_percent=0.15,
                dhf_concentration_basis=(
                    "reported only as 0.15%; treated as wt% for provisional "
                    "transport speciation"
                ),
                dhf_duration_s=30.0,
                ozone_then_dhf_etch_amount_nm=0.50,
                dhf_only_etch_amount_nm=0.25,
                digitization_resolution_nm=0.05,
                source_key="kawarazaki_2024",
                value_basis=(
                    "Fig. 2 raster digitization; dHF-only value aligned to "
                    "the abstract-reported 0.25 nm upper endpoint"
                ),
                reported_cycle_linearity_max=3,
                reported_cycle_ozone_duration_matches_endpoint=False,
            ),
            LiteratureCyclicEtchEndpoint(
                key="kawarazaki_sin_reference",
                material="SiN",
                film_description="ALD SiN reference film in Fig. 2",
                nominal_carbon_percent=None,
                carbon_percent_basis="not applicable",
                ozone_bake_temperature_K=513.15,
                ozone_concentration_g_m3=100.0,
                ozone_bake_duration_s=30.0,
                dhf_reported_percent=0.15,
                dhf_concentration_basis=(
                    "reported only as 0.15%; treated as wt% for provisional "
                    "transport speciation"
                ),
                dhf_duration_s=30.0,
                ozone_then_dhf_etch_amount_nm=0.04,
                dhf_only_etch_amount_nm=0.04,
                digitization_resolution_nm=0.05,
                source_key="kawarazaki_2024",
                value_basis=(
                    "abstract-reported 0.04 nm in both arms; Fig. 2 shows "
                    "near-zero bars"
                ),
            ),
        )
    }
)


def get_cyclic_etch_endpoint(name: str) -> LiteratureCyclicEtchEndpoint:
    try:
        return KAWARAZAKI_2024_FIG2_ENDPOINTS[name]
    except KeyError as exc:
        choices = ", ".join(KAWARAZAKI_2024_FIG2_ENDPOINTS)
        raise ValueError(
            f"unknown cyclic etch endpoint {name!r}; choose from {choices}"
        ) from exc


def _sin_preset(
    sample: str,
    rate_band: str,
    rate_nm_min: float,
    uncertainty_nm_min: float,
    description: str,
) -> LiteratureEtchPreset:
    return LiteratureEtchPreset(
        key=f"sin_barcellona_{sample.lower()}_0p55wt",
        material="SiN",
        rate_band=rate_band,
        film_description=description,
        planar_rate_nm_min=rate_nm_min,
        planar_rate_uncertainty_nm_min=uncertainty_nm_min,
        reported_solution="unbuffered HF, actual working concentration 0.55 wt%",
        reported_solution_temperature_K=298.15,
        transport_hf_weight_percent=0.55,
        transport_concentration_basis=(
            "reported 0.55 wt%; neutral [HF] from the Hamer-Wu 25 degC table"
        ),
        solid_density_g_cm3=2.30,
        solid_si_site_density_mol_m3=5.31e4,
        fill_thermal_conductivity_W_mK=0.91,
        effective_hf_per_si=6.0,
        rate_source_key="barcellona_2023",
        property_source_keys=("braun_2021",) + _COMMON_PROPERTY_SOURCES,
        rate_evidence="direct Table 4 value; Angstrom/min converted to nm/min",
        extrapolation_caveat=(
            "Different PECVD film from the property source; constant-rate "
            "extension from a refreshed blanket bath to a 180 nm trench is "
            "not experimentally validated."
        ),
    )


def _siocn_preset(
    film: str,
    rate_band: str,
    rate_nm_min: float,
    description: str,
) -> LiteratureEtchPreset:
    return LiteratureEtchPreset(
        key=f"siocn_fujitsu_{film.lower()}_100to1",
        material="SiOCN",
        rate_band=rate_band,
        film_description=description,
        planar_rate_nm_min=rate_nm_min,
        planar_rate_uncertainty_nm_min=None,
        reported_solution="100:1 H2O:HF for 60 s; HF stock and temperature undisclosed",
        reported_solution_temperature_K=None,
        transport_hf_weight_percent=0.57,
        transport_concentration_basis=(
            "inferred 0.57 wt% from 49 wt% HF stock at 1.17 g/mL and additive "
            "volumes; used only to estimate transport depletion"
        ),
        solid_density_g_cm3=1.80,
        solid_si_site_density_mol_m3=3.25e4,
        fill_thermal_conductivity_W_mK=1.0,
        effective_hf_per_si=6.0,
        rate_source_key="fujitsu_siocn_2013",
        property_source_keys=("siocn_density_2020",) + _COMMON_PROPERTY_SOURCES,
        rate_evidence=(
            "numeric figure label divided by the disclosed 60 s exposure; "
            "primary patent disclosure, not peer reviewed"
        ),
        extrapolation_caveat=(
            "The reported loss is sub-nanometre and the stock concentration and "
            "temperature are unknown.  Linear extrapolation to 170--180 nm is "
            "therefore only an order-of-magnitude screening scenario."
        ),
    )


def _kawarazaki_hf_preset(
    endpoint_name: str,
    *,
    solid_density_g_cm3: float,
    solid_si_site_density_mol_m3: float,
    fill_thermal_conductivity_W_mK: float,
    property_source_key: str,
    property_basis: str,
) -> LiteratureEtchPreset:
    endpoint = get_cyclic_etch_endpoint(endpoint_name)
    return LiteratureEtchPreset(
        key=f"{endpoint.key}_dhf0p15_linear30s",
        material=endpoint.material,
        rate_band="fig2_linearized_30s",
        film_description=endpoint.film_description,
        planar_rate_nm_min=round(
            endpoint.dhf_only_apparent_rate_nm_min,
            12,
        ),
        planar_rate_uncertainty_nm_min=None,
        reported_solution=(
            "dHF 0.15% for 30 s after an undisclosed-duration native-oxide "
            "preclean; no ozone bake in this paired arm"
        ),
        reported_solution_temperature_K=None,
        transport_hf_weight_percent=0.15,
        transport_concentration_basis=(
            "0.15% figure label treated provisionally as wt%; neutral [HF] "
            "from the Hamer-Wu 25 degC table"
        ),
        solid_density_g_cm3=solid_density_g_cm3,
        solid_si_site_density_mol_m3=solid_si_site_density_mol_m3,
        fill_thermal_conductivity_W_mK=fill_thermal_conductivity_W_mK,
        effective_hf_per_si=6.0,
        rate_source_key="kawarazaki_2024",
        property_source_keys=(property_source_key,) + _COMMON_PROPERTY_SOURCES,
        rate_evidence=(
            f"Fig. 2 dHF-only raster endpoint "
            f"{endpoint.dhf_only_etch_amount_nm:g} nm / "
            f"{endpoint.dhf_duration_s:g} s, normalized linearly to "
            f"{endpoint.dhf_only_apparent_rate_nm_min:g} nm/min"
        ),
        extrapolation_caveat=(
            "User-approved provisional linearity assumption from one 30 s "
            "ellipsometry endpoint; no experimental uncertainty or wet "
            "temperature is reported. Raster digitization resolution is about "
            f"{endpoint.digitization_resolution_nm:g} nm. "
            f"{property_basis} This HF-only clock must not include the paired "
            "ozone-bake removal increment."
        ),
    )


LITERATURE_ETCH_PRESETS: Mapping[str, LiteratureEtchPreset] = MappingProxyType(
    {
        preset.key: preset
        for preset in (
            _sin_preset(
                "A",
                "low",
                1.3,
                0.2,
                "PECVD sample A: H=12 at%, RI=2.052",
            ),
            _sin_preset(
                "B",
                "nominal",
                2.2,
                0.2,
                "PECVD sample B: H=19 at%, RI=1.922",
            ),
            _sin_preset(
                "C",
                "high",
                4.0,
                0.1,
                "PECVD sample C: H=21 at%, RI=1.974; O-rich surface",
            ),
            _siocn_preset(
                "4A",
                "low",
                0.16,
                "Si35.0/O21.6/C8.2/N32.9 at% (XPS)",
            ),
            _siocn_preset(
                "4B",
                "nominal",
                0.38,
                "Si34.1/O26.5/C6.7/N30.6 at% (XPS)",
            ),
            _siocn_preset(
                "4D",
                "high",
                0.92,
                "Si32.6/O36.4/C6.1/N23.4 at% (XPS)",
            ),
            _kawarazaki_hf_preset(
                "kawarazaki_sicn_c22",
                solid_density_g_cm3=1.80,
                solid_si_site_density_mol_m3=3.25e4,
                fill_thermal_conductivity_W_mK=1.0,
                property_source_key="siocn_density_2020",
                property_basis=(
                    "SiOCN density/site-density/thermal values are temporary "
                    "proxies because Fig. 2 reports no SiCN properties."
                ),
            ),
            _kawarazaki_hf_preset(
                "kawarazaki_sicn_c40",
                solid_density_g_cm3=1.80,
                solid_si_site_density_mol_m3=3.25e4,
                fill_thermal_conductivity_W_mK=1.0,
                property_source_key="siocn_density_2020",
                property_basis=(
                    "SiOCN density/site-density/thermal values are temporary "
                    "proxies because Fig. 2 reports no SiCN properties."
                ),
            ),
            _kawarazaki_hf_preset(
                "kawarazaki_siocn_c5",
                solid_density_g_cm3=1.80,
                solid_si_site_density_mol_m3=3.25e4,
                fill_thermal_conductivity_W_mK=1.0,
                property_source_key="siocn_density_2020",
                property_basis=(
                    "Generic SiOCN density/site-density/thermal values are "
                    "temporary proxies rather than properties of this ALD film."
                ),
            ),
            _kawarazaki_hf_preset(
                "kawarazaki_sin_reference",
                solid_density_g_cm3=2.30,
                solid_si_site_density_mol_m3=5.31e4,
                fill_thermal_conductivity_W_mK=0.91,
                property_source_key="braun_2021",
                property_basis=(
                    "PECVD SiN properties are temporary proxies for the "
                    "uncharacterized ALD SiN reference film."
                ),
            ),
        )
    }
)


def get_literature_preset(name: str) -> LiteratureEtchPreset:
    try:
        return LITERATURE_ETCH_PRESETS[name]
    except KeyError as exc:
        choices = ", ".join(LITERATURE_ETCH_PRESETS)
        raise ValueError(
            f"unknown literature preset {name!r}; choose from {choices}"
        ) from exc


def silicon_thermal_conductivity_W_mK(temperature_K: float) -> float:
    """Linearly interpolate the NIST 298.2 and 323.2 K high-purity values."""

    temperature = float(temperature_K)
    if not math.isfinite(temperature) or temperature <= 0.0:
        raise ValueError("temperature_K must be finite and positive")
    return float(np.interp(temperature, [298.2, 323.2], [149.0, 133.0]))


__all__ = [
    "HF_DIFFUSIVITY_298_M2_S",
    "HF_DIFFUSIVITY_298_NM2_S",
    "HFSpeciation298K",
    "KAWARAZAKI_2024_FIG2_ENDPOINTS",
    "LITERATURE_ETCH_PRESETS",
    "LiteratureCyclicEtchEndpoint",
    "LiteratureEtchPreset",
    "LiteratureSource",
    "SOURCES",
    "get_cyclic_etch_endpoint",
    "get_literature_preset",
    "hf_speciation_298K_from_weight_percent",
    "silicon_thermal_conductivity_W_mK",
]

from __future__ import annotations

import math
import unittest

from surface_chemistry import (
    LocalInterfaceConditions,
    MeanFieldKineticParameters,
    MeanFieldSurfaceChemistry,
    MeanFieldSurfaceState,
    ReactionMode,
    SurfaceMaterial,
)


class SurfaceChemistryTests(unittest.TestCase):
    def test_rate_uses_local_temperature_solution_state_and_material(self) -> None:
        model = MeanFieldSurfaceChemistry(
            MeanFieldKineticParameters(
                rate_constant_ref_s=0.2,
                activation_energy_J_mol=20_000.0,
                reactant_activity_order=1.0,
                reactant_concentration_order=1.0,
                product_activity_inhibition=2.0,
                product_concentration_inhibition=1.0,
                material_rate_factors={"SiN": 1.0, "SiOCN": 0.1},
            )
        )
        state = MeanFieldSurfaceState(
            material_coverage=0.8,
            product_coverage=0.1,
            passivation_coverage=0.2,
        )
        baseline = LocalInterfaceConditions(
            temperature_K=298.15,
            reactant_activity=0.5,
            reactant_concentration=0.5,
        )
        sin_rate = model.evaluate_rate("SiN", state, baseline)
        siocn_rate = model.evaluate_rate("SiOCN", state, baseline)
        hotter = model.evaluate_rate(
            "SiN",
            state,
            LocalInterfaceConditions(
                temperature_K=330.0,
                reactant_activity=0.5,
                reactant_concentration=0.5,
            ),
        )
        inhibited = model.evaluate_rate(
            "SiN",
            state,
            LocalInterfaceConditions(
                temperature_K=298.15,
                reactant_activity=0.5,
                reactant_concentration=0.5,
                product_activity=0.5,
                product_concentration=0.5,
            ),
        )
        self.assertAlmostEqual(
            siocn_rate.reaction_rate_coverage_s,
            0.1 * sin_rate.reaction_rate_coverage_s,
        )
        self.assertGreater(hotter.reaction_rate_coverage_s, sin_rate.reaction_rate_coverage_s)
        self.assertLess(inhibited.reaction_rate_coverage_s, sin_rate.reaction_rate_coverage_s)

    def test_direct_etch_remains_bounded_for_a_long_loose_integration(self) -> None:
        model = MeanFieldSurfaceChemistry(
            MeanFieldKineticParameters(
                reaction_mode=ReactionMode.DIRECT_ETCH,
                rate_constant_ref_s=5.0,
                product_yield=2.0,
                passivation_yield=1.0,
                product_release_s=0.1,
                passivation_removal_s=0.05,
            )
        )
        initial = MeanFieldSurfaceState()
        result = model.advance(
            SurfaceMaterial.SIN,
            initial,
            LocalInterfaceConditions(temperature_K=310.0),
            20.0,
            maximum_step_s=0.2,
        )
        final = result.state
        self.assertGreaterEqual(final.material_coverage, 0.0)
        self.assertLess(final.material_coverage, initial.material_coverage)
        self.assertGreaterEqual(final.product_coverage, 0.0)
        self.assertGreaterEqual(final.passivation_coverage, 0.0)
        self.assertLessEqual(final.product_coverage + final.passivation_coverage, 1.0 + 1e-12)
        self.assertGreater(result.reaction_extent, 0.0)
        self.assertTrue(math.isfinite(result.mean_reaction_rate_coverage_s))

    def test_conversion_then_converted_etch_preserves_inventory_constraints(self) -> None:
        conditions = LocalInterfaceConditions(temperature_K=300.0)
        conversion = MeanFieldSurfaceChemistry(
            MeanFieldKineticParameters(
                reaction_mode="oxidative_conversion",
                rate_constant_ref_s=0.5,
                material_rate_factors={"SiN": 0.2, "SiOCN": 1.0},
            )
        )
        converted = conversion.advance(
            "SiOCN", MeanFieldSurfaceState(), conditions, 3.0
        ).state
        self.assertAlmostEqual(converted.material_coverage, 1.0, places=7)
        self.assertGreater(converted.converted_coverage, 0.5)

        fluoride = MeanFieldSurfaceChemistry(
            MeanFieldKineticParameters(
                reaction_mode="etch_converted",
                rate_constant_ref_s=1.0,
            )
        )
        etched = fluoride.advance("SiOCN", converted, conditions, 5.0).state
        self.assertLess(etched.material_coverage, converted.material_coverage)
        self.assertLess(etched.converted_coverage, converted.converted_coverage)
        self.assertLessEqual(etched.converted_coverage, etched.material_coverage)

    def test_sicn_is_not_aliased_to_siocn(self) -> None:
        model = MeanFieldSurfaceChemistry(
            MeanFieldKineticParameters(
                rate_constant_ref_s=1.0,
                material_rate_factors={
                    "SiN": 1.0,
                    "SiCN": 0.4,
                    "SiOCN": 0.2,
                },
            )
        )
        self.assertAlmostEqual(model.rate_constant_s("SiCN", 298.15), 0.4)
        self.assertAlmostEqual(model.rate_constant_s("SiOCN", 298.15), 0.2)

    def test_rinse_only_relaxes_interfacial_coverages(self) -> None:
        model = MeanFieldSurfaceChemistry(
            MeanFieldKineticParameters(
                reaction_mode="rinse",
                rate_constant_ref_s=0.0,
                product_release_s=0.5,
                passivation_removal_s=0.2,
            )
        )
        initial = MeanFieldSurfaceState(
            material_coverage=0.7,
            converted_coverage=0.2,
            product_coverage=0.4,
            passivation_coverage=0.3,
        )
        final = model.advance(
            "SiN",
            initial,
            LocalInterfaceConditions(temperature_K=298.15),
            4.0,
        ).state
        self.assertAlmostEqual(final.material_coverage, initial.material_coverage)
        self.assertAlmostEqual(final.converted_coverage, initial.converted_coverage)
        self.assertLess(final.product_coverage, initial.product_coverage)
        self.assertLess(final.passivation_coverage, initial.passivation_coverage)

    def test_invalid_states_and_conditions_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            MeanFieldSurfaceState(material_coverage=0.2, converted_coverage=0.3)
        with self.assertRaises(ValueError):
            MeanFieldSurfaceState(product_coverage=0.8, passivation_coverage=0.3)
        with self.assertRaises(ValueError):
            LocalInterfaceConditions(temperature_K=0.0)
        with self.assertRaises(ValueError):
            LocalInterfaceConditions(temperature_K=300.0, reactant_activity=-1.0)


if __name__ == "__main__":
    unittest.main()

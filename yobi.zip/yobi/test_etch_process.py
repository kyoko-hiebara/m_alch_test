from __future__ import annotations

import dataclasses
import math
import unittest

import numpy as np

from etch_process import (
    BOUNDARY_CONDITIONS_ONLY,
    FULLY_GAP_FILLED,
    RESERVOIR_ONLY,
    EtchProcessConfig,
    GapFillMaterial,
    InitialPhase,
    ThermalBoundaryConditions,
)
from trench_geometry import get_geometry_preset


class EtchProcessConfigTests(unittest.TestCase):
    @staticmethod
    def make_config(
        solution_temperature_K: float = 293.15,
        substrate_temperature_K: float = 323.15,
    ) -> EtchProcessConfig:
        return EtchProcessConfig(
            geometry=get_geometry_preset("10_8_180"),
            gap_fill_material=GapFillMaterial.SIN,
            thermal_bc=ThermalBoundaryConditions(
                solution_bulk_temperature_K=solution_temperature_K,
                substrate_backside_temperature_K=substrate_temperature_K,
            ),
        )

    def test_initial_trench_is_fully_solid_and_reservoir_only(self) -> None:
        config = self.make_config()
        depths = np.asarray([-1.0, 0.0, 90.0, 180.0, 180.1])
        phases = config.initial_phase_map(np.zeros_like(depths), depths)
        np.testing.assert_array_equal(
            phases,
            [
                InitialPhase.HF_RESERVOIR.value,
                InitialPhase.GAP_FILL_SOLID.value,
                InitialPhase.GAP_FILL_SOLID.value,
                InitialPhase.GAP_FILL_SOLID.value,
                InitialPhase.SI.value,
            ],
        )
        self.assertEqual(
            config.initial_phase_map(5.1, 0.0), InitialPhase.SI.value
        )
        self.assertEqual(config.initial_condition, FULLY_GAP_FILLED)
        self.assertEqual(config.initial_solution_domain, RESERVOIR_ONLY)

    def test_temperatures_remain_independent(self) -> None:
        config = self.make_config()
        self.assertEqual(config.thermal_bc.solution_bulk_temperature_K, 293.15)
        self.assertEqual(config.thermal_bc.substrate_backside_temperature_K, 323.15)
        changed = dataclasses.replace(
            config,
            thermal_bc=dataclasses.replace(
                config.thermal_bc,
                solution_bulk_temperature_K=303.15,
            ),
        )
        self.assertEqual(changed.thermal_bc.solution_bulk_temperature_K, 303.15)
        self.assertEqual(changed.thermal_bc.substrate_backside_temperature_K, 323.15)
        self.assertEqual(changed.thermal_model, BOUNDARY_CONDITIONS_ONLY)
        with self.assertRaisesRegex(RuntimeError, "interface temperature"):
            config.reaction_temperature_K()

    def test_invalid_initial_state_and_temperatures_are_rejected(self) -> None:
        for bad in (0.0, -1.0, math.nan, math.inf):
            with self.assertRaises(ValueError):
                ThermalBoundaryConditions(bad, 300.0)
            with self.assertRaises(ValueError):
                ThermalBoundaryConditions(300.0, bad)
        with self.assertRaises(ValueError):
            dataclasses.replace(self.make_config(), initial_condition="partial")
        with self.assertRaises(ValueError):
            dataclasses.replace(
                self.make_config(), initial_solution_domain="inside_trench"
            )
        with self.assertRaises(ValueError):
            dataclasses.replace(self.make_config(), gap_fill_material="unknown")

    def test_nested_json_round_trip_preserves_both_temperatures(self) -> None:
        config = self.make_config()
        restored = EtchProcessConfig.from_json(config.to_json())
        self.assertEqual(restored, config)
        values = restored.to_dict()
        self.assertEqual(values["solution"]["bulk_temperature_K"], 293.15)
        self.assertEqual(values["substrate"]["backside_temperature_K"], 323.15)
        self.assertEqual(values["gap_fill"]["initial_condition"], FULLY_GAP_FILLED)
        self.assertEqual(values["solution"]["initial_domain"], RESERVOIR_ONLY)

    def test_sicn_is_a_distinct_round_trip_material(self) -> None:
        config = dataclasses.replace(
            self.make_config(),
            gap_fill_material="SiCN",
        )
        self.assertIs(config.gap_fill_material, GapFillMaterial.SICN)
        restored = EtchProcessConfig.from_json(config.to_json())
        self.assertIs(restored.gap_fill_material, GapFillMaterial.SICN)


if __name__ == "__main__":
    unittest.main()

"""Inverse screening model for backside 395--400 nm LED wafer heating.

This module deliberately separates four questions that are often conflated:

1. optical power absorbed at the Si or SiO2/Si backside;
2. transient heating of a uniformly illuminated wafer;
3. the local temperature division between Si, a nm-scale residue, and water;
4. the *upper bound* on elastic energy available to delaminate the residue.

The output is not a cleaning recipe.  In particular, the interface fracture
energy, local water path, residue composition, and irradiance at the wafer are
not known.  The inverse result therefore reports the substrate temperature and
irradiance required for an assumed fracture energy rather than inventing a
single "removal temperature".

The pre-implementation theory specification is:
``research_memos/LED_BACKSIDE_THERMOMECHANICAL_THEORY_20260801.html``.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, replace
from typing import Callable, Iterable, Sequence

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq


SCHEMA_VERSION = "led-backside-thermomechanical/v1"

WAFER_DIAMETER_M = 0.300
WATER_BULK_TEMPERATURE_K = 298.15
WATER_BOILING_POINT_1ATM_K = 373.15
USHIO_STATED_PROCESS_CEILING_K = 873.15  # <600 degC on the official page.

SILICON_DENSITY_KG_M3 = 2330.0
SILICON_MOLAR_MASS_KG_MOL = 0.0280855
WATER_THERMAL_CONDUCTIVITY_W_MK = 0.6065

# NIST Chemistry WebBook SRD 69, solid-phase Shomate equation, 298--1685 K.
_SI_CP_SHOMATE = (22.81719, 3.899510, -0.082885, 0.042111, -0.354063)

# Green, Solar Energy Materials & Solar Cells 92 (2008) 1305--1310.
# Only the user-selected 395--400 nm band is supported by interpolation here.
_SI_OPTICAL_TABLE = {
    390.0: (6.039, 0.445, 1.43e5),  # n, kappa, absorption / cm
    400.0: (5.613, 0.296, 9.30e4),
}


def _finite_positive(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be finite and positive")
    return number


def _finite_nonnegative(name: str, value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")
    return number


def wafer_area_m2(diameter_m: float = WAFER_DIAMETER_M) -> float:
    diameter = _finite_positive("diameter_m", diameter_m)
    return math.pi * (0.5 * diameter) ** 2


def whole_wafer_irradiance_W_m2(
    optical_power_W: float,
    diameter_m: float = WAFER_DIAMETER_M,
) -> float:
    power = _finite_nonnegative("optical_power_W", optical_power_W)
    return power / wafer_area_m2(diameter_m)


def silicon_heat_capacity_J_kgK(temperature_K: float) -> float:
    """Return crystalline-Si Cp from the NIST solid Shomate equation."""

    temperature = _finite_positive("temperature_K", temperature_K)
    if not 298.0 <= temperature <= 1685.0:
        raise ValueError("silicon Shomate heat capacity supports 298--1685 K")
    t = temperature / 1000.0
    a, b, c, d, e = _SI_CP_SHOMATE
    cp_molar = a + b * t + c * t**2 + d * t**3 + e / t**2
    return cp_molar / SILICON_MOLAR_MASS_KG_MOL


def silicon_enthalpy_change_J_kg(
    temperature_K: float,
    reference_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> float:
    """Integrate the NIST Shomate Cp exactly between two temperatures."""

    temperature = _finite_positive("temperature_K", temperature_K)
    reference = _finite_positive("reference_temperature_K", reference_temperature_K)
    if not 298.0 <= min(temperature, reference) <= max(temperature, reference) <= 1685.0:
        raise ValueError("silicon Shomate enthalpy supports 298--1685 K")
    t0 = reference / 1000.0
    t1 = temperature / 1000.0
    a, b, c, d, e = _SI_CP_SHOMATE
    integral_J_mol = 1000.0 * (
        a * (t1 - t0)
        + 0.5 * b * (t1**2 - t0**2)
        + (c / 3.0) * (t1**3 - t0**3)
        + 0.25 * d * (t1**4 - t0**4)
        - e * (1.0 / t1 - 1.0 / t0)
    )
    return integral_J_mol / SILICON_MOLAR_MASS_KG_MOL


def silicon_linear_expansion_coefficient_per_K(temperature_K: float) -> float:
    """Okada--Tokumaru empirical linear CTE, valid from 120 to 1500 K."""

    temperature = _finite_positive("temperature_K", temperature_K)
    if not 120.0 <= temperature <= 1500.0:
        raise ValueError("Okada--Tokumaru silicon CTE supports 120--1500 K")
    return (
        3.725 * (1.0 - math.exp(-5.88e-3 * (temperature - 124.0)))
        + 5.548e-4 * temperature
    ) * 1.0e-6


def silicon_free_thermal_strain(
    temperature_K: float,
    reference_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> float:
    """Analytic integral of the Okada--Tokumaru CTE."""

    temperature = _finite_positive("temperature_K", temperature_K)
    reference = _finite_positive("reference_temperature_K", reference_temperature_K)
    if not 120.0 <= min(temperature, reference) <= max(temperature, reference) <= 1500.0:
        raise ValueError("Okada--Tokumaru silicon strain supports 120--1500 K")
    decay = 5.88e-3

    def primitive(value: float) -> float:
        return (
            3.725 * value
            + (3.725 / decay) * math.exp(-decay * (value - 124.0))
            + 0.5 * 5.548e-4 * value**2
        ) * 1.0e-6

    return primitive(temperature) - primitive(reference)


def silicon_thermal_conductivity_W_mK(temperature_K: float) -> float:
    """Screening interpolation for high-purity Si over the aqueous range.

    The two anchors, 149 W/(m K) at 298.2 K and 133 W/(m K) at 323.2 K,
    are the existing project's NIST compilation values.  This function is
    intentionally limited to 298--373.15 K; high-temperature inverse outputs
    do not use it for a quantitative 1-D claim.
    """

    temperature = _finite_positive("temperature_K", temperature_K)
    if not 298.0 <= temperature <= WATER_BOILING_POINT_1ATM_K:
        raise ValueError("screening silicon k supports 298--373.15 K")
    return float(np.interp(temperature, [298.2, 323.2, 373.15], [149.0, 133.0, 110.0]))


def silicon_optical_constants(wavelength_nm: float) -> tuple[float, float, float]:
    """Interpolate Green's n, kappa, and absorption coefficient in 395--400 nm."""

    wavelength = _finite_positive("wavelength_nm", wavelength_nm)
    if not 395.0 <= wavelength <= 400.0:
        raise ValueError("this model supports only the selected 395--400 nm band")
    x0, x1 = 390.0, 400.0
    fraction = (wavelength - x0) / (x1 - x0)
    values0 = _SI_OPTICAL_TABLE[x0]
    values1 = _SI_OPTICAL_TABLE[x1]
    return tuple(
        float(left + fraction * (right - left))
        for left, right in zip(values0, values1, strict=True)
    )


def fused_silica_refractive_index(wavelength_nm: float) -> float:
    """Malitson fused-silica Sellmeier equation at 20 degC."""

    wavelength_um = _finite_positive("wavelength_nm", wavelength_nm) / 1000.0
    wavelength_sq = wavelength_um**2
    n_sq = 1.0
    for coefficient, resonance_um in (
        (0.6961663, 0.0684043),
        (0.4079426, 0.1162414),
        (0.8974794, 9.896161),
    ):
        n_sq += coefficient * wavelength_sq / (wavelength_sq - resonance_um**2)
    return math.sqrt(n_sq)


@dataclass(frozen=True)
class OpticalAbsorption:
    wavelength_nm: float
    oxide_thickness_nm: float
    silicon_n: float
    silicon_kappa: float
    silicon_absorption_coefficient_per_m: float
    silicon_absorption_depth_nm: float
    oxide_refractive_index: float
    reflectance: float
    absorptance: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


def optical_absorption_air_sio2_si(
    wavelength_nm: float,
    oxide_thickness_nm: float = 0.0,
    *,
    thermal_oxide_index_factor: float = 1.004,
) -> OpticalAbsorption:
    """Normal-incidence transfer-matrix result for air/SiO2/thick-Si."""

    wavelength = _finite_positive("wavelength_nm", wavelength_nm)
    thickness = _finite_nonnegative("oxide_thickness_nm", oxide_thickness_nm)
    index_factor = _finite_positive(
        "thermal_oxide_index_factor", thermal_oxide_index_factor
    )
    silicon_n, silicon_kappa, absorption_per_cm = silicon_optical_constants(
        wavelength
    )
    n0 = 1.0 + 0.0j
    n1 = index_factor * fused_silica_refractive_index(wavelength) + 0.0j
    # Positive kappa with exp(+i beta) below gives the usual intensity Fresnel R.
    n2 = complex(silicon_n, silicon_kappa)
    r01 = (n0 - n1) / (n0 + n1)
    r12 = (n1 - n2) / (n1 + n2)
    beta = 2.0 * math.pi * n1 * thickness / wavelength
    phase = np.exp(2.0j * beta)
    amplitude = (r01 + r12 * phase) / (1.0 + r01 * r12 * phase)
    reflectance = float(abs(amplitude) ** 2)
    absorptance = 1.0 - reflectance
    absorption_per_m = absorption_per_cm * 100.0
    return OpticalAbsorption(
        wavelength_nm=wavelength,
        oxide_thickness_nm=thickness,
        silicon_n=silicon_n,
        silicon_kappa=silicon_kappa,
        silicon_absorption_coefficient_per_m=absorption_per_m,
        silicon_absorption_depth_nm=1.0e9 / absorption_per_m,
        oxide_refractive_index=float(n1.real),
        reflectance=reflectance,
        absorptance=absorptance,
    )


def band_averaged_absorptance(
    oxide_thickness_nm: float,
    wavelengths_nm: Sequence[float] = (395.0, 400.0),
    weights: Sequence[float] | None = None,
) -> float:
    if not wavelengths_nm:
        raise ValueError("wavelengths_nm must not be empty")
    if weights is None:
        weight_array = np.ones(len(wavelengths_nm), dtype=float)
    else:
        if len(weights) != len(wavelengths_nm):
            raise ValueError("weights and wavelengths_nm must have the same length")
        weight_array = np.asarray(weights, dtype=float)
    if not np.all(np.isfinite(weight_array)) or np.any(weight_array < 0.0):
        raise ValueError("weights must be finite and non-negative")
    if float(np.sum(weight_array)) <= 0.0:
        raise ValueError("weights must have a positive sum")
    values = np.array(
        [
            optical_absorption_air_sio2_si(wavelength, oxide_thickness_nm).absorptance
            for wavelength in wavelengths_nm
        ]
    )
    return float(np.average(values, weights=weight_array))


def effective_areal_heat_capacity_J_m2K(
    wafer_thickness_m: float,
    target_temperature_K: float,
    reference_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> float:
    thickness = _finite_positive("wafer_thickness_m", wafer_thickness_m)
    target = _finite_positive("target_temperature_K", target_temperature_K)
    reference = _finite_positive("reference_temperature_K", reference_temperature_K)
    if math.isclose(target, reference, abs_tol=1.0e-12):
        cp = silicon_heat_capacity_J_kgK(reference)
    else:
        cp = silicon_enthalpy_change_J_kg(target, reference) / (target - reference)
    return SILICON_DENSITY_KG_M3 * thickness * cp


def required_incident_irradiance_W_m2(
    target_temperature_K: float,
    duration_s: float,
    wafer_thickness_m: float,
    absorptance: float,
    total_heat_transfer_W_m2K: float,
    bulk_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> float:
    """Inverse constant-irradiance solution using path-average Si Cp.

    The expression is exact for constant Cp and preserves the exact Shomate
    enthalpy in the no-loss limit by using the path-average Cp.  Independent
    validation against direct integration is provided by
    :func:`required_incident_irradiance_exact_W_m2`.
    """

    target = _finite_positive("target_temperature_K", target_temperature_K)
    duration = _finite_positive("duration_s", duration_s)
    thickness = _finite_positive("wafer_thickness_m", wafer_thickness_m)
    absorption = _finite_positive("absorptance", absorptance)
    heat_transfer = _finite_nonnegative(
        "total_heat_transfer_W_m2K", total_heat_transfer_W_m2K
    )
    bulk = _finite_positive("bulk_temperature_K", bulk_temperature_K)
    if not 0.0 < absorption <= 1.0:
        raise ValueError("absorptance must be in (0, 1]")
    if target < bulk:
        raise ValueError("target_temperature_K must be at least bulk temperature")
    rise = target - bulk
    if rise == 0.0:
        return 0.0
    capacity = effective_areal_heat_capacity_J_m2K(thickness, target, bulk)
    if heat_transfer == 0.0:
        absorbed = capacity * rise / duration
    else:
        exponent = -heat_transfer * duration / capacity
        absorbed = heat_transfer * rise / (-math.expm1(exponent))
    return absorbed / absorption


def temperature_after_constant_irradiance_K(
    incident_irradiance_W_m2: float,
    duration_s: float,
    wafer_thickness_m: float,
    absorptance: float,
    total_heat_transfer_W_m2K: float,
    bulk_temperature_K: float = WATER_BULK_TEMPERATURE_K,
    *,
    maximum_temperature_K: float = 1600.0,
) -> float:
    """Directly integrate the lumped temperature ODE with NIST Cp(T)."""

    incident = _finite_nonnegative(
        "incident_irradiance_W_m2", incident_irradiance_W_m2
    )
    duration = _finite_nonnegative("duration_s", duration_s)
    thickness = _finite_positive("wafer_thickness_m", wafer_thickness_m)
    absorption = _finite_positive("absorptance", absorptance)
    heat_transfer = _finite_nonnegative(
        "total_heat_transfer_W_m2K", total_heat_transfer_W_m2K
    )
    bulk = _finite_positive("bulk_temperature_K", bulk_temperature_K)
    maximum = _finite_positive("maximum_temperature_K", maximum_temperature_K)
    if not 0.0 < absorption <= 1.0:
        raise ValueError("absorptance must be in (0, 1]")
    if duration == 0.0 or incident == 0.0:
        return bulk
    absorbed = absorption * incident
    areal_mass = SILICON_DENSITY_KG_M3 * thickness

    def rhs(_time: float, state: np.ndarray) -> np.ndarray:
        temperature = min(float(state[0]), 1684.999999)
        cp = silicon_heat_capacity_J_kgK(temperature)
        net_flux = absorbed - heat_transfer * (temperature - bulk)
        return np.array([net_flux / (areal_mass * cp)])

    def maximum_event(_time: float, state: np.ndarray) -> float:
        return maximum - float(state[0])

    maximum_event.terminal = True  # type: ignore[attr-defined]
    maximum_event.direction = -1.0  # type: ignore[attr-defined]
    solution = solve_ivp(
        rhs,
        (0.0, duration),
        np.array([bulk]),
        rtol=2.0e-9,
        atol=1.0e-10,
        events=maximum_event,
        max_step=max(duration / 100.0, 1.0e-8),
    )
    if not solution.success:
        raise RuntimeError(f"temperature integration failed: {solution.message}")
    return float(solution.y[0, -1])


def required_incident_irradiance_exact_W_m2(
    target_temperature_K: float,
    duration_s: float,
    wafer_thickness_m: float,
    absorptance: float,
    total_heat_transfer_W_m2K: float,
    bulk_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> float:
    """Numerically exact inverse of the variable-Cp lumped ODE."""

    target = _finite_positive("target_temperature_K", target_temperature_K)
    duration = _finite_positive("duration_s", duration_s)
    thickness = _finite_positive("wafer_thickness_m", wafer_thickness_m)
    absorption = _finite_positive("absorptance", absorptance)
    heat_transfer = _finite_nonnegative(
        "total_heat_transfer_W_m2K", total_heat_transfer_W_m2K
    )
    bulk = _finite_positive("bulk_temperature_K", bulk_temperature_K)
    if target < bulk:
        raise ValueError("target_temperature_K must be at least bulk temperature")
    if target == bulk:
        return 0.0
    if heat_transfer == 0.0:
        return (
            SILICON_DENSITY_KG_M3
            * thickness
            * silicon_enthalpy_change_J_kg(target, bulk)
            / duration
            / absorption
        )
    approximate_incident = required_incident_irradiance_W_m2(
        target,
        duration,
        thickness,
        absorption,
        heat_transfer,
        bulk,
    )
    hi = max(2.0 * approximate_incident, 1.0)

    def temperature_residual(incident: float) -> float:
        return temperature_after_constant_irradiance_K(
            incident,
            duration,
            thickness,
            absorption,
            heat_transfer,
            bulk,
            maximum_temperature_K=min(1684.0, max(target + 100.0, 500.0)),
        ) - target

    while temperature_residual(hi) < 0.0:
        hi *= 2.0
    return brentq(
        temperature_residual,
        0.0,
        hi,
        xtol=1.0e-9,
        rtol=1.0e-12,
    )


@dataclass(frozen=True)
class PulseThermalResult:
    peak_temperature_K: float
    minimum_cycle_temperature_K: float
    final_temperature_K: float
    peak_to_valley_K: float
    cycle_count: int
    duty_cycle: float
    period_s: float
    pulse_on_s: float
    diffusion_time_s: float
    pulse_to_diffusion_time_ratio: float
    lumped_pulse_warning: bool
    edge_times_s: tuple[float, ...]
    edge_temperatures_K: tuple[float, ...]

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["edge_times_s"] = list(self.edge_times_s)
        result["edge_temperatures_K"] = list(self.edge_temperatures_K)
        return result


def square_pulse_temperature_history(
    peak_incident_irradiance_W_m2: float,
    period_s: float,
    duty_cycle: float,
    total_duration_s: float,
    wafer_thickness_m: float,
    absorptance: float,
    total_heat_transfer_W_m2K: float,
    bulk_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> PulseThermalResult:
    """Constant-Cp exact recurrence for a square-pulse train.

    Cp is evaluated at the bulk temperature.  This is used for pulse-shape
    comparisons; the variable-Cp continuous inverse remains the quantitative
    intensity mapper.  ``peak_to_valley_K`` is the cooling excursion in the
    last *completed* on/off cycle, rather than the total warm-up from the
    initial bulk temperature.
    """

    peak = _finite_nonnegative(
        "peak_incident_irradiance_W_m2", peak_incident_irradiance_W_m2
    )
    period = _finite_positive("period_s", period_s)
    duty = float(duty_cycle)
    if not math.isfinite(duty) or not 0.0 < duty <= 1.0:
        raise ValueError("duty_cycle must be in (0, 1]")
    total = _finite_positive("total_duration_s", total_duration_s)
    thickness = _finite_positive("wafer_thickness_m", wafer_thickness_m)
    absorption = _finite_positive("absorptance", absorptance)
    heat_transfer = _finite_nonnegative(
        "total_heat_transfer_W_m2K", total_heat_transfer_W_m2K
    )
    bulk = _finite_positive("bulk_temperature_K", bulk_temperature_K)
    if not 0.0 < absorption <= 1.0:
        raise ValueError("absorptance must be in (0, 1]")
    cp = silicon_heat_capacity_J_kgK(bulk)
    areal_capacity = SILICON_DENSITY_KG_M3 * thickness * cp
    pulse_on = duty * period
    pulse_off = period - pulse_on
    absorbed_peak = absorption * peak

    def advance(rise: float, absorbed_flux: float, interval: float) -> float:
        if interval <= 0.0:
            return rise
        if heat_transfer == 0.0:
            return rise + absorbed_flux * interval / areal_capacity
        steady_rise = absorbed_flux / heat_transfer
        decay = math.exp(-heat_transfer * interval / areal_capacity)
        return steady_rise + (rise - steady_rise) * decay

    time = 0.0
    rise = 0.0
    edge_times = [0.0]
    edge_temperatures = [bulk]
    on_end_temperatures: list[float] = []
    off_end_temperatures: list[float] = []
    completed_cycles = 0
    if pulse_off == 0.0:
        rise = advance(rise, absorbed_peak, total)
        edge_times.append(total)
        edge_temperatures.append(bulk + rise)
        on_end_temperatures.append(bulk + rise)
        time = total
    while time < total - 1.0e-15:
        on_interval = min(pulse_on, total - time)
        rise = advance(rise, absorbed_peak, on_interval)
        time += on_interval
        edge_times.append(time)
        edge_temperatures.append(bulk + rise)
        on_end_temperatures.append(bulk + rise)
        if time >= total - 1.0e-15:
            break
        off_interval = min(pulse_off, total - time)
        rise = advance(rise, 0.0, off_interval)
        time += off_interval
        edge_times.append(time)
        edge_temperatures.append(bulk + rise)
        off_end_temperatures.append(bulk + rise)
        if math.isclose(off_interval, pulse_off, rel_tol=0.0, abs_tol=1.0e-14):
            completed_cycles += 1
    thermal_diffusivity = silicon_thermal_conductivity_W_mK(bulk) / (
        SILICON_DENSITY_KG_M3 * cp
    )
    diffusion_time = thickness**2 / thermal_diffusivity
    ratio = pulse_on / diffusion_time
    peak_temperature = max(on_end_temperatures or [bulk])
    if off_end_temperatures:
        last_complete_index = len(off_end_temperatures) - 1
        last_cycle_peak = on_end_temperatures[last_complete_index]
        minimum_cycle = off_end_temperatures[-1]
        cycle_amplitude = last_cycle_peak - minimum_cycle
    elif pulse_off == 0.0:
        minimum_cycle = peak_temperature
        cycle_amplitude = 0.0
    else:
        minimum_cycle = bulk
        cycle_amplitude = peak_temperature - bulk
    return PulseThermalResult(
        peak_temperature_K=peak_temperature,
        minimum_cycle_temperature_K=minimum_cycle,
        final_temperature_K=bulk + rise,
        peak_to_valley_K=cycle_amplitude,
        cycle_count=completed_cycles,
        duty_cycle=duty,
        period_s=period,
        pulse_on_s=pulse_on,
        diffusion_time_s=diffusion_time,
        pulse_to_diffusion_time_ratio=ratio,
        lumped_pulse_warning=ratio < 10.0,
        edge_times_s=tuple(edge_times),
        edge_temperatures_K=tuple(edge_temperatures),
    )


@dataclass(frozen=True)
class LocalThermalPath:
    name: str
    silicon_residue_resistance_m2K_W: float
    residue_water_resistance_m2K_W: float
    water_path_resistance_m2K_W: float
    residue_thickness_m: float = 2.0e-9
    residue_thermal_conductivity_W_mK: float = 1.0
    residue_density_kg_m3: float = 2300.0
    residue_heat_capacity_J_kgK: float = 700.0
    interpretation: str = "sensitivity case, not a measured interface"

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name must not be empty")
        for field_name in (
            "silicon_residue_resistance_m2K_W",
            "residue_water_resistance_m2K_W",
            "water_path_resistance_m2K_W",
        ):
            _finite_nonnegative(field_name, getattr(self, field_name))
        for field_name in (
            "residue_thickness_m",
            "residue_thermal_conductivity_W_mK",
            "residue_density_kg_m3",
            "residue_heat_capacity_J_kgK",
        ):
            _finite_positive(field_name, getattr(self, field_name))


@dataclass(frozen=True)
class LocalResidueThermalState:
    path_name: str
    substrate_temperature_K: float
    water_bulk_temperature_K: float
    residue_temperature_K: float
    substrate_residue_delta_K: float
    residue_water_delta_K: float
    substrate_side_resistance_m2K_W: float
    water_side_resistance_m2K_W: float
    residue_heating_fraction: float
    residue_cold_fraction: float
    relaxation_time_s: float
    heat_flux_W_m2: float

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def local_residue_thermal_state(
    substrate_temperature_K: float,
    path: LocalThermalPath,
    water_bulk_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> LocalResidueThermalState:
    substrate = _finite_positive("substrate_temperature_K", substrate_temperature_K)
    water = _finite_positive("water_bulk_temperature_K", water_bulk_temperature_K)
    half_film = 0.5 * path.residue_thickness_m / path.residue_thermal_conductivity_W_mK
    substrate_side = path.silicon_residue_resistance_m2K_W + half_film
    water_side = (
        half_film
        + path.residue_water_resistance_m2K_W
        + path.water_path_resistance_m2K_W
    )
    if substrate_side + water_side <= 0.0:
        raise ValueError("local thermal path must have positive total resistance")
    residue_heating_fraction = water_side / (substrate_side + water_side)
    residue_cold_fraction = substrate_side / (substrate_side + water_side)
    residue = water + residue_heating_fraction * (substrate - water)
    conductance = 1.0 / substrate_side + 1.0 / water_side
    areal_capacity = (
        path.residue_density_kg_m3
        * path.residue_heat_capacity_J_kgK
        * path.residue_thickness_m
    )
    relaxation = areal_capacity / conductance
    flux = (substrate - water) / (substrate_side + water_side)
    return LocalResidueThermalState(
        path_name=path.name,
        substrate_temperature_K=substrate,
        water_bulk_temperature_K=water,
        residue_temperature_K=residue,
        substrate_residue_delta_K=substrate - residue,
        residue_water_delta_K=residue - water,
        substrate_side_resistance_m2K_W=substrate_side,
        water_side_resistance_m2K_W=water_side,
        residue_heating_fraction=residue_heating_fraction,
        residue_cold_fraction=residue_cold_fraction,
        relaxation_time_s=relaxation,
        heat_flux_W_m2=flux,
    )


def local_global_active_area_fraction_ceiling(
    path: LocalThermalPath,
    total_heat_transfer_W_m2K: float,
) -> float:
    """Maximum active local-path area fraction allowed by a global heat budget.

    The local path carries ``(Ts - Tw)/(Rs + Rw)`` while the wafer-scale
    boundary carries ``H (Ts - Tw)`` per projected wafer area.  Their ratio is
    independent of temperature in this linear resistance screen.  Values near
    zero mean that the nanoscale local path can only coexist with the chosen
    wafer-scale ``H`` over a very sparse active area.  The result is capped at
    one and is not a boiling or hydrodynamic criterion.
    """

    heat_transfer = _finite_nonnegative(
        "total_heat_transfer_W_m2K", total_heat_transfer_W_m2K
    )
    unit_state = local_residue_thermal_state(
        WATER_BULK_TEMPERATURE_K + 1.0,
        path,
        WATER_BULK_TEMPERATURE_K,
    )
    if unit_state.heat_flux_W_m2 <= 0.0:
        raise ValueError("local path must carry heat for a 1 K temperature rise")
    return min(1.0, heat_transfer / unit_state.heat_flux_W_m2)


@dataclass(frozen=True)
class ResidueMechanicalProperties:
    name: str
    thickness_m: float
    thermal_expansion_per_K: float
    young_modulus_Pa: float
    poisson_ratio: float
    interpretation: str

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name must not be empty")
        _finite_positive("thickness_m", self.thickness_m)
        _finite_nonnegative("thermal_expansion_per_K", self.thermal_expansion_per_K)
        _finite_positive("young_modulus_Pa", self.young_modulus_Pa)
        if not math.isfinite(self.poisson_ratio) or not -1.0 < self.poisson_ratio < 0.5:
            raise ValueError("poisson_ratio must be finite and in (-1, 0.5)")

    @property
    def biaxial_modulus_Pa(self) -> float:
        return self.young_modulus_Pa / (1.0 - self.poisson_ratio)


@dataclass(frozen=True)
class ThermomechanicalState:
    residue_case: str
    path_name: str
    substrate_temperature_K: float
    residue_temperature_K: float
    substrate_residue_delta_K: float
    silicon_free_strain: float
    residue_free_strain: float
    mismatch_strain: float
    biaxial_stress_Pa: float
    stored_energy_upper_bound_J_m2: float
    stress_sign: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def thermomechanical_state(
    substrate_temperature_K: float,
    path: LocalThermalPath,
    residue: ResidueMechanicalProperties,
    reference_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> ThermomechanicalState:
    thermal_path = (
        path
        if math.isclose(
            path.residue_thickness_m,
            residue.thickness_m,
            rel_tol=0.0,
            abs_tol=1.0e-18,
        )
        else replace(path, residue_thickness_m=residue.thickness_m)
    )
    thermal = local_residue_thermal_state(
        substrate_temperature_K, thermal_path, reference_temperature_K
    )
    silicon_strain = silicon_free_thermal_strain(
        substrate_temperature_K, reference_temperature_K
    )
    residue_strain = residue.thermal_expansion_per_K * (
        thermal.residue_temperature_K - reference_temperature_K
    )
    mismatch = silicon_strain - residue_strain
    stress = residue.biaxial_modulus_Pa * mismatch
    stored_energy = (
        residue.biaxial_modulus_Pa * mismatch**2 * residue.thickness_m
    )
    if stress > 0.0:
        sign = "tensile"
    elif stress < 0.0:
        sign = "compressive"
    else:
        sign = "zero"
    return ThermomechanicalState(
        residue_case=residue.name,
        path_name=path.name,
        substrate_temperature_K=thermal.substrate_temperature_K,
        residue_temperature_K=thermal.residue_temperature_K,
        substrate_residue_delta_K=thermal.substrate_residue_delta_K,
        silicon_free_strain=silicon_strain,
        residue_free_strain=residue_strain,
        mismatch_strain=mismatch,
        biaxial_stress_Pa=stress,
        stored_energy_upper_bound_J_m2=stored_energy,
        stress_sign=sign,
    )


@dataclass(frozen=True)
class InverseDelaminationThreshold:
    assumed_fracture_energy_J_m2: float
    residue_case: str
    path_name: str
    reached: bool
    required_substrate_temperature_K: float | None
    required_residue_temperature_K: float | None
    required_substrate_residue_delta_K: float | None
    stress_Pa: float | None
    water_1atm_valid: bool | None
    ushio_stated_range_valid: bool | None
    note: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def inverse_delamination_temperature(
    fracture_energy_J_m2: float,
    path: LocalThermalPath,
    residue: ResidueMechanicalProperties,
    reference_temperature_K: float = WATER_BULK_TEMPERATURE_K,
    maximum_temperature_K: float = 1499.0,
    *,
    grid_points: int = 5000,
) -> InverseDelaminationThreshold:
    """Find the first T above the reference where Lambda_B reaches Gamma.

    Lambda_B is only the stored-film-energy upper bound.  A returned root is a
    necessary energetic condition under phi=1, not a prediction of removal.
    """

    fracture = _finite_nonnegative("fracture_energy_J_m2", fracture_energy_J_m2)
    reference = _finite_positive("reference_temperature_K", reference_temperature_K)
    maximum = _finite_positive("maximum_temperature_K", maximum_temperature_K)
    if maximum <= reference:
        raise ValueError("maximum_temperature_K must exceed the reference")
    if grid_points < 3:
        raise ValueError("grid_points must be at least 3")
    if fracture == 0.0:
        state = thermomechanical_state(reference, path, residue, reference)
        return InverseDelaminationThreshold(
            assumed_fracture_energy_J_m2=fracture,
            residue_case=residue.name,
            path_name=path.name,
            reached=True,
            required_substrate_temperature_K=reference,
            required_residue_temperature_K=state.residue_temperature_K,
            required_substrate_residue_delta_K=state.substrate_residue_delta_K,
            stress_Pa=state.biaxial_stress_Pa,
            water_1atm_valid=True,
            ushio_stated_range_valid=True,
            note="zero fracture-energy limit",
        )

    def residual(temperature: float) -> float:
        return (
            thermomechanical_state(temperature, path, residue, reference)
            .stored_energy_upper_bound_J_m2
            - fracture
        )

    temperatures = np.linspace(reference, maximum, grid_points)
    previous_temperature = float(temperatures[0])
    previous_value = residual(previous_temperature)
    root: float | None = None
    for temperature in temperatures[1:]:
        current_temperature = float(temperature)
        current_value = residual(current_temperature)
        if current_value >= 0.0 and previous_value < 0.0:
            root = brentq(residual, previous_temperature, current_temperature)
            break
        if current_value == 0.0:
            root = current_temperature
            break
        previous_temperature = current_temperature
        previous_value = current_value
    if root is None:
        max_energy = max(
            thermomechanical_state(float(t), path, residue, reference)
            .stored_energy_upper_bound_J_m2
            for t in temperatures
        )
        return InverseDelaminationThreshold(
            assumed_fracture_energy_J_m2=fracture,
            residue_case=residue.name,
            path_name=path.name,
            reached=False,
            required_substrate_temperature_K=None,
            required_residue_temperature_K=None,
            required_substrate_residue_delta_K=None,
            stress_Pa=None,
            water_1atm_valid=None,
            ushio_stated_range_valid=None,
            note=(
                f"not reached by {maximum:.1f} K; maximum sampled upper-bound "
                f"energy={max_energy:.6g} J/m2"
            ),
        )
    state = thermomechanical_state(root, path, residue, reference)
    return InverseDelaminationThreshold(
        assumed_fracture_energy_J_m2=fracture,
        residue_case=residue.name,
        path_name=path.name,
        reached=True,
        required_substrate_temperature_K=root,
        required_residue_temperature_K=state.residue_temperature_K,
        required_substrate_residue_delta_K=state.substrate_residue_delta_K,
        stress_Pa=state.biaxial_stress_Pa,
        water_1atm_valid=root <= WATER_BOILING_POINT_1ATM_K,
        ushio_stated_range_valid=root <= USHIO_STATED_PROCESS_CEILING_K,
        note=(
            "phi=1 stored-energy necessary condition only; pre-crack and "
            "actual interface fracture energy remain required"
        ),
    )


def substrate_temperature_for_delta_K(
    desired_substrate_residue_delta_K: float,
    path: LocalThermalPath,
    water_bulk_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> float:
    desired = _finite_nonnegative(
        "desired_substrate_residue_delta_K", desired_substrate_residue_delta_K
    )
    state = local_residue_thermal_state(
        water_bulk_temperature_K + 1.0, path, water_bulk_temperature_K
    )
    if state.residue_cold_fraction <= 0.0:
        raise ValueError("path cannot produce a substrate-residue temperature difference")
    return water_bulk_temperature_K + desired / state.residue_cold_fraction


@dataclass(frozen=True)
class OneDimensionalThermalResult:
    time_s: float
    backside_temperature_K: float
    frontside_temperature_K: float
    mean_temperature_K: float
    backside_frontside_delta_K: float
    lumped_temperature_K: float
    mean_vs_lumped_delta_K: float
    biot_number: float
    diffusion_time_s: float
    front_surface_free_plate_strain: float
    curvature_per_m: float
    temperature_profile_K: tuple[float, ...]

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["temperature_profile_K"] = list(self.temperature_profile_K)
        return result


def free_plate_surface_strain_from_profile(
    temperature_profile_K: Sequence[float],
    wafer_thickness_m: float,
    reference_temperature_K: float = WATER_BULK_TEMPERATURE_K,
) -> tuple[float, float]:
    """Return front-surface strain and curvature of a free 1-D plate.

    Constant elastic modulus is assumed.  The temperature values are finite-
    volume cell centres ordered from illuminated backside to wet frontside.
    """

    profile = np.asarray(temperature_profile_K, dtype=float)
    if profile.ndim != 1 or profile.size < 2 or not np.all(np.isfinite(profile)):
        raise ValueError("temperature_profile_K must be a finite 1-D array")
    thickness = _finite_positive("wafer_thickness_m", wafer_thickness_m)
    cell_width = thickness / profile.size
    z = (np.arange(profile.size) + 0.5) * cell_width - 0.5 * thickness
    free_strain = np.array(
        [silicon_free_thermal_strain(float(t), reference_temperature_K) for t in profile]
    )
    membrane_strain = float(np.mean(free_strain))
    curvature = float(12.0 / thickness**3 * np.sum(z * free_strain * cell_width))
    front_surface_strain = membrane_strain + curvature * 0.5 * thickness
    return front_surface_strain, curvature


def simulate_1d_wafer_constant_flux(
    incident_irradiance_W_m2: float,
    duration_s: float,
    wafer_thickness_m: float,
    absorptance: float,
    total_heat_transfer_W_m2K: float,
    bulk_temperature_K: float = WATER_BULK_TEMPERATURE_K,
    *,
    cell_count: int = 80,
) -> OneDimensionalThermalResult:
    """Independent finite-volume 1-D check for constant backside flux.

    Constant properties at the bulk temperature are used.  This validator is
    restricted to cases that remain below the 1-atm water boiling point.
    """

    incident = _finite_nonnegative(
        "incident_irradiance_W_m2", incident_irradiance_W_m2
    )
    duration = _finite_positive("duration_s", duration_s)
    thickness = _finite_positive("wafer_thickness_m", wafer_thickness_m)
    absorption = _finite_positive("absorptance", absorptance)
    heat_transfer = _finite_nonnegative(
        "total_heat_transfer_W_m2K", total_heat_transfer_W_m2K
    )
    bulk = _finite_positive("bulk_temperature_K", bulk_temperature_K)
    if cell_count < 8:
        raise ValueError("cell_count must be at least 8")
    cp = silicon_heat_capacity_J_kgK(bulk)
    conductivity = silicon_thermal_conductivity_W_mK(bulk)
    volumetric_capacity = SILICON_DENSITY_KG_M3 * cp
    diffusivity = conductivity / volumetric_capacity
    cell_width = thickness / cell_count
    absorbed = absorption * incident

    def rhs(_time: float, temperatures: np.ndarray) -> np.ndarray:
        derivative = np.empty_like(temperatures)
        derivative[0] = (
            absorbed
            + conductivity * (temperatures[1] - temperatures[0]) / cell_width
        ) / (volumetric_capacity * cell_width)
        derivative[1:-1] = diffusivity * (
            temperatures[2:] - 2.0 * temperatures[1:-1] + temperatures[:-2]
        ) / cell_width**2
        derivative[-1] = (
            conductivity * (temperatures[-2] - temperatures[-1]) / cell_width
            - heat_transfer * (temperatures[-1] - bulk)
        ) / (volumetric_capacity * cell_width)
        return derivative

    solution = solve_ivp(
        rhs,
        (0.0, duration),
        np.full(cell_count, bulk),
        method="BDF",
        rtol=2.0e-8,
        atol=2.0e-9,
        max_step=max(duration / 100.0, 1.0e-8),
    )
    if not solution.success:
        raise RuntimeError(f"1-D integration failed: {solution.message}")
    profile = solution.y[:, -1]
    if float(np.max(profile)) > WATER_BOILING_POINT_1ATM_K:
        raise ValueError("1-D validator crossed 1-atm water boiling point")
    areal_capacity = volumetric_capacity * thickness
    if heat_transfer == 0.0:
        lumped = bulk + absorbed * duration / areal_capacity
    else:
        lumped = bulk + absorbed / heat_transfer * (
            1.0 - math.exp(-heat_transfer * duration / areal_capacity)
        )
    front_strain, curvature = free_plate_surface_strain_from_profile(
        profile, thickness, bulk
    )
    biot = heat_transfer * thickness / conductivity
    diffusion_time = thickness**2 / diffusivity
    mean_temperature = float(np.mean(profile))
    return OneDimensionalThermalResult(
        time_s=duration,
        backside_temperature_K=float(profile[0]),
        frontside_temperature_K=float(profile[-1]),
        mean_temperature_K=mean_temperature,
        backside_frontside_delta_K=float(profile[0] - profile[-1]),
        lumped_temperature_K=lumped,
        mean_vs_lumped_delta_K=mean_temperature - lumped,
        biot_number=biot,
        diffusion_time_s=diffusion_time,
        front_surface_free_plate_strain=front_strain,
        curvature_per_m=curvature,
        temperature_profile_K=tuple(float(value) for value in profile),
    )


def default_local_paths() -> tuple[LocalThermalPath, ...]:
    """Return explicit sensitivity brackets for a 180 nm water path."""

    water_column = 180.0e-9 / WATER_THERMAL_CONDUCTIVITY_W_MK
    return (
        LocalThermalPath(
            name="well_bonded_180nm_water",
            silicon_residue_resistance_m2K_W=1.0e-8,
            residue_water_resistance_m2K_W=1.0e-8,
            water_path_resistance_m2K_W=water_column,
            interpretation=(
                "central interface-resistance scale plus a 180 nm stagnant-water "
                "column; local sensitivity, not a wafer-scale heat balance"
            ),
        ),
        LocalThermalPath(
            name="weak_bond_180nm_water",
            silicon_residue_resistance_m2K_W=1.0e-7,
            residue_water_resistance_m2K_W=1.0e-8,
            water_path_resistance_m2K_W=water_column,
            interpretation=(
                "tenfold larger Si/residue resistance; a weak-contact sensitivity"
            ),
        ),
        LocalThermalPath(
            name="near_debond_180nm_water",
            silicon_residue_resistance_m2K_W=1.0e-6,
            residue_water_resistance_m2K_W=1.0e-8,
            water_path_resistance_m2K_W=water_column,
            interpretation=(
                "very high Si/residue resistance representing a pre-existing gap "
                "or near-debonded residue, not an intact interface"
            ),
        ),
        LocalThermalPath(
            name="perfect_water_sink_extreme",
            silicon_residue_resistance_m2K_W=1.0e-8,
            residue_water_resistance_m2K_W=1.0e-9,
            water_path_resistance_m2K_W=0.0,
            interpretation=(
                "extreme lower water-side resistance; cannot be sustained over a "
                "large area without a matching bath heat sink"
            ),
        ),
    )


def default_residue_cases() -> tuple[ResidueMechanicalProperties, ...]:
    """Literature-anchored SiNx plus explicitly synthetic sensitivity cases."""

    return (
        ResidueMechanicalProperties(
            name="sinx_like_2nm",
            thickness_m=2.0e-9,
            thermal_expansion_per_K=3.27e-6,
            young_modulus_Pa=222.0e9,
            poisson_ratio=0.28,
            interpretation=(
                "SiNx-like anchor: PECVD CTE and thin-film bulge-test elastic "
                "constants; not calibrated to the actual residue"
            ),
        ),
        ResidueMechanicalProperties(
            name="sinx_like_10nm",
            thickness_m=10.0e-9,
            thermal_expansion_per_K=3.27e-6,
            young_modulus_Pa=222.0e9,
            poisson_ratio=0.28,
            interpretation="same SiNx-like properties, fivefold thickness sensitivity",
        ),
        ResidueMechanicalProperties(
            name="soft_high_cte_2nm_sensitivity",
            thickness_m=2.0e-9,
            thermal_expansion_per_K=50.0e-6,
            young_modulus_Pa=5.0e9,
            poisson_ratio=0.35,
            interpretation=(
                "synthetic soft/high-CTE boundary; not a literature-calibrated "
                "SiCN or SiOCN property set"
            ),
        ),
        ResidueMechanicalProperties(
            name="stiff_high_cte_2nm_sensitivity",
            thickness_m=2.0e-9,
            thermal_expansion_per_K=20.0e-6,
            young_modulus_Pa=100.0e9,
            poisson_ratio=0.30,
            interpretation=(
                "synthetic stiff/high-CTE boundary; not a literature-calibrated "
                "residue property set"
            ),
        ),
    )


__all__ = [
    "SCHEMA_VERSION",
    "WAFER_DIAMETER_M",
    "WATER_BULK_TEMPERATURE_K",
    "WATER_BOILING_POINT_1ATM_K",
    "USHIO_STATED_PROCESS_CEILING_K",
    "SILICON_DENSITY_KG_M3",
    "WATER_THERMAL_CONDUCTIVITY_W_MK",
    "OpticalAbsorption",
    "PulseThermalResult",
    "LocalThermalPath",
    "LocalResidueThermalState",
    "ResidueMechanicalProperties",
    "ThermomechanicalState",
    "InverseDelaminationThreshold",
    "OneDimensionalThermalResult",
    "wafer_area_m2",
    "whole_wafer_irradiance_W_m2",
    "silicon_heat_capacity_J_kgK",
    "silicon_enthalpy_change_J_kg",
    "silicon_linear_expansion_coefficient_per_K",
    "silicon_free_thermal_strain",
    "silicon_thermal_conductivity_W_mK",
    "silicon_optical_constants",
    "fused_silica_refractive_index",
    "optical_absorption_air_sio2_si",
    "band_averaged_absorptance",
    "effective_areal_heat_capacity_J_m2K",
    "required_incident_irradiance_W_m2",
    "temperature_after_constant_irradiance_K",
    "required_incident_irradiance_exact_W_m2",
    "square_pulse_temperature_history",
    "local_residue_thermal_state",
    "local_global_active_area_fraction_ceiling",
    "thermomechanical_state",
    "inverse_delamination_temperature",
    "substrate_temperature_for_delta_K",
    "free_plate_surface_strain_from_profile",
    "simulate_1d_wafer_constant_flux",
    "default_local_paths",
    "default_residue_cases",
]

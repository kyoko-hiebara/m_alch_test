#!/usr/bin/env python3
"""Visual diagnostics for mechanism-discrimination screening calculations.

Figure contract
---------------
Core conclusion: causes that produce similar final residue can be separated by
their intervention fingerprints and by native-versus-deposit morphology.
Evidence chain: the fingerprint heatmap shows intervention dependence; the
separability figure shows which cause pairs and experiments are informative;
the morphology plate localises native and deposited residue on wall/floor.
Archetype/backend/export: quantitative grid plus image plate, Python/Matplotlib,
300 dpi PNG.  Missing inputs remain visibly missing and are never imputed.

The reader deliberately accepts several equivalent JSON layouts.  Preferred
top-level keys are reported by :func:`expected_payload_keys`: ``causes``,
``experiments`` or ``probes``, ``fingerprints``, ``separability``,
``diagnosis_table`` and ``cases``.  Entities may be strings or mappings;
fingerprints and pairwise results may be record lists, nested mappings, or
explicit matrices.
"""

from __future__ import annotations

import json
import math
import textwrap
from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize, TwoSlopeNorm
from matplotlib.lines import Line2D
import numpy as np


# Editable-text settings remain useful if callers later add vector exports.
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = [
    "Hiragino Sans",
    "Noto Sans JP",
    "YuGothic",
    "Arial",
    "DejaVu Sans",
    "Liberation Sans",
]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42

SCREENING_NOTICE = (
    "Screening model only — cause labels and kinetic, wetting, passivation, "
    "attachment and dry-down parameters are uncalibrated.\n"
    "Do not interpret values as a process recipe."
)

EXPECTED_PAYLOAD_KEYS: dict[str, tuple[str, ...]] = {
    "causes": ("causes", "cause_profiles", "cause_order"),
    "experiments_or_probes": ("experiments", "probes", "probe_definitions"),
    "fingerprints": (
        "cause_id",
        "probe_id",
        "effect",
        "ci_low",
        "ci_high",
    ),
    "separability": (
        "pairwise_robust_distances",
        "greedy_probe_order",
        "cause_order",
        "pairwise_matrix",
        "pairwise_metric",
        "greedy_order",
    ),
    "diagnosis_table": ("cause_id", "primary_signal", "morphology"),
    "cases": ("case_id", "cause_id", "snapshot", "morphology_metrics"),
}

_STYLE = {
    "font.size": 8.0,
    "axes.titlesize": 9.5,
    "axes.labelsize": 8.0,
    "axes.linewidth": 0.7,
    "xtick.labelsize": 7.0,
    "ytick.labelsize": 7.0,
    "legend.fontsize": 6.8,
    "legend.frameon": False,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
}

_FINGERPRINT_CMAP = LinearSegmentedColormap.from_list(
    "screening_diverging", ("#3C78A8", "#F7F7F7", "#B24C4C")
)
_PAIRWISE_CMAP = LinearSegmentedColormap.from_list(
    "screening_sequential", ("#F1F4F7", "#8DB6C9", "#275D75")
)


def expected_payload_keys() -> dict[str, tuple[str, ...]]:
    """Return a copy of the preferred, non-exclusive payload schema."""

    return {key: tuple(value) for key, value in EXPECTED_PAYLOAD_KEYS.items()}


def _load_payload(value: Mapping[str, Any] | str | Path) -> Mapping[str, Any]:
    if isinstance(value, (str, Path)):
        payload = json.loads(Path(value).read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("mechanism-discrimination JSON must contain a mapping")
        return payload
    if not isinstance(value, Mapping):
        raise TypeError("expected a mapping or a JSON path")
    return value


def _number(value: Any) -> float | None:
    if isinstance(value, (bool, np.bool_)) or value is None:
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _first(mapping: Mapping[str, Any], names: Sequence[str]) -> Any:
    for name in names:
        if name in mapping and mapping[name] is not None:
            return mapping[name]
    return None


def _destination(path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def _finish(figure: plt.Figure, output_path: str | Path, *, dpi: int, bottom: float) -> Path:
    if not isinstance(dpi, int) or isinstance(dpi, bool) or dpi < 1:
        plt.close(figure)
        raise ValueError("dpi must be a positive integer")
    figure.text(
        0.5,
        0.004,
        SCREENING_NOTICE,
        ha="center",
        va="bottom",
        fontsize=6.5,
        color="0.30",
        wrap=True,
    )
    figure.subplots_adjust(bottom=bottom)
    destination = _destination(output_path)
    figure.savefig(destination, dpi=dpi, bbox_inches="tight")
    plt.close(figure)
    return destination


def _no_data(output_path: str | Path, *, title: str, message: str, dpi: int) -> Path:
    with plt.rc_context(_STYLE):
        figure, axis = plt.subplots(figsize=(7.4, 3.2))
        axis.set_axis_off()
        axis.text(0.5, 0.58, "No reported data", ha="center", va="center", fontsize=16)
        axis.text(
            0.5,
            0.39,
            message,
            ha="center",
            va="center",
            transform=axis.transAxes,
            color="0.35",
            wrap=True,
        )
        figure.suptitle(title, y=0.94, fontsize=11)
        return _finish(figure, output_path, dpi=dpi, bottom=0.14)


def _entity_records(payload: Mapping[str, Any], keys: Sequence[str]) -> list[tuple[str, str]]:
    root = _first(payload, keys)
    result: list[tuple[str, str]] = []
    if isinstance(root, Mapping):
        for key, value in root.items():
            if isinstance(value, Mapping):
                identifier = str(_first(value, ("id", "cause_id", "probe_id", "experiment_id", "name")) or key)
                label = str(_first(value, ("label", "display_name", "name", "label_ja")) or identifier)
            else:
                identifier, label = str(key), str(value)
            result.append((identifier, label))
    elif isinstance(root, Sequence) and not isinstance(root, (str, bytes)):
        for index, value in enumerate(root):
            if isinstance(value, Mapping):
                identifier = str(
                    _first(value, ("id", "cause_id", "probe_id", "experiment_id", "name"))
                    or index
                )
                label = str(_first(value, ("label", "display_name", "name", "label_ja")) or identifier)
            else:
                identifier = label = str(value)
            result.append((identifier, label))
    seen: set[str] = set()
    return [(identifier, label) for identifier, label in result if not (identifier in seen or seen.add(identifier))]


def _record_ci(record: Mapping[str, Any]) -> tuple[float | None, float | None]:
    low = _number(_first(record, ("ci_low", "lower", "low", "confidence_low")))
    high = _number(_first(record, ("ci_high", "upper", "high", "confidence_high")))
    if low is None or high is None:
        interval = _first(record, ("ci", "ci95", "confidence_interval", "interval"))
        if isinstance(interval, Sequence) and not isinstance(interval, (str, bytes)) and len(interval) >= 2:
            low, high = _number(interval[0]), _number(interval[1])
    return low, high


def _fingerprint_value(value: Any) -> tuple[float | None, float | None, float | None]:
    if isinstance(value, Mapping):
        effect = _number(
            _first(value, ("effect", "signed_effect", "median_effect", "response", "sensitivity", "score", "value"))
        )
        low, high = _record_ci(value)
        return effect, low, high
    return _number(value), None, None


def _fingerprint_records(payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    root = _first(payload, ("fingerprints", "mechanism_fingerprints", "fingerprint"))
    if root is None:
        return []
    records: list[dict[str, Any]] = []

    def add(
        cause: Any,
        probe: Any,
        value: Any,
        *,
        cause_label: str | None = None,
        signed: bool = True,
    ) -> None:
        effect, low, high = _fingerprint_value(value)
        if cause is None or probe is None or effect is None:
            return
        records.append(
            {
                "cause": str(cause),
                "cause_label": cause_label,
                "probe": str(probe),
                "effect": effect,
                "low": low,
                "high": high,
                "signed": signed,
            }
        )

    def consume_record(record: Mapping[str, Any], cause_hint: Any = None) -> None:
        cause = _first(record, ("cause_id", "cause", "mechanism_id", "mechanism", "hypothesis_id", "hypothesis")) or cause_hint
        probe = _first(record, ("probe_id", "probe", "experiment_id", "experiment", "feature", "intervention"))
        if probe is not None:
            add(cause, probe, record)
            return
        effects = _first(record, ("effects", "probes", "experiments", "fingerprint", "fingerprints"))
        if isinstance(effects, Mapping):
            for probe_id, value in effects.items():
                add(cause, probe_id, value)

        # Production fingerprints contain multiple stage-resolved response
        # metrics per probe.  Display their reported normalized RMS strength;
        # retain the detailed signed components in JSON rather than silently
        # selecting one metric for the heatmap.
        entries = record.get("entries")
        if isinstance(entries, Sequence) and not isinstance(entries, (str, bytes)):
            preset = _first(record, ("preset_id", "preset", "material"))
            material = _first(record, ("material", "preset_id"))
            row_id = str(cause) if preset is None else f"{cause}__{preset}"
            row_label = str(cause) if material is None else f"{cause} | {material}"
            by_probe: dict[str, list[float]] = {}
            for entry in entries:
                if not isinstance(entry, Mapping) or entry.get("valid", True) is False:
                    continue
                probe_id = _first(entry, ("probe", "probe_id", "experiment", "experiment_id"))
                effect = _number(_first(entry, ("linear_effect", "effect", "signed_effect", "value")))
                if probe_id is not None and effect is not None:
                    by_probe.setdefault(str(probe_id), []).append(effect)
            for probe_id, values in by_probe.items():
                strength = float(math.sqrt(np.mean(np.square(values))))
                add(row_id, probe_id, strength, cause_label=row_label, signed=False)

    # The diagnosis table emitted by the coordinator already contains the
    # exact normalized RMS probe strengths.  Prefer it when available.
    diagnosis = payload.get("diagnosis_table")
    if isinstance(diagnosis, Sequence) and not isinstance(diagnosis, (str, bytes)):
        for row in diagnosis:
            if not isinstance(row, Mapping) or not isinstance(row.get("probe_strengths"), Mapping):
                continue
            cause = _first(row, ("cause_id", "cause", "mechanism_id", "hypothesis_id"))
            preset = _first(row, ("preset_id", "preset", "material"))
            material = _first(row, ("material", "preset_id"))
            row_id = str(cause) if preset is None else f"{cause}__{preset}"
            row_label = str(_first(row, ("cause_label_ja", "cause_label")) or cause)
            if material is not None:
                row_label = f"{row_label} | {material}"
            for probe, value in row["probe_strengths"].items():
                add(row_id, probe, value, cause_label=row_label, signed=False)
        if records:
            return records

    if isinstance(root, Mapping):
        matrix = _first(root, ("matrix", "effect_matrix", "values"))
        cause_order = _first(root, ("cause_order", "causes", "row_labels"))
        probe_order = _first(root, ("probe_order", "experiment_order", "probes", "column_labels"))
        if matrix is not None and isinstance(cause_order, Sequence) and isinstance(probe_order, Sequence):
            array = np.asarray(matrix, dtype=object)
            if array.ndim == 2 and array.shape == (len(cause_order), len(probe_order)):
                for i, cause in enumerate(cause_order):
                    for j, probe in enumerate(probe_order):
                        add(cause, probe, array[i, j])
        rows = _first(root, ("records", "rows", "data"))
        if isinstance(rows, Sequence) and not isinstance(rows, (str, bytes)):
            for row in rows:
                if isinstance(row, Mapping):
                    consume_record(row)
        metadata = {"matrix", "effect_matrix", "values", "cause_order", "causes", "row_labels", "probe_order", "experiment_order", "probes", "column_labels", "records", "rows", "data", "signed", "unit", "effect_unit"}
        for cause, nested in root.items():
            if cause in metadata:
                continue
            if isinstance(nested, Mapping):
                explicit = _first(nested, ("cause_id", "cause", "mechanism_id", "hypothesis_id"))
                if explicit is not None or _first(nested, ("effects", "probes", "experiments", "fingerprint")) is not None:
                    consume_record(nested, cause)
                else:
                    for probe, value in nested.items():
                        add(cause, probe, value)
    elif isinstance(root, Sequence) and not isinstance(root, (str, bytes)):
        for row in root:
            if isinstance(row, Mapping):
                consume_record(row)
    return records


def _ordered_entities(
    declared: Sequence[tuple[str, str]], inferred: Sequence[str]
) -> tuple[list[str], list[str]]:
    identifiers, labels = [], []
    label_by_id = dict(declared)
    for identifier in [item[0] for item in declared] + [str(item) for item in inferred]:
        if identifier not in identifiers:
            identifiers.append(identifier)
            labels.append(label_by_id.get(identifier, identifier))
    return identifiers, labels


def _diagnosis_cues(payload: Mapping[str, Any]) -> dict[str, str]:
    root = payload.get("diagnosis_table")
    rows: list[tuple[str, Mapping[str, Any]]] = []
    if isinstance(root, Mapping):
        for key, value in root.items():
            if isinstance(value, Mapping):
                rows.append((str(key), value))
    elif isinstance(root, Sequence) and not isinstance(root, (str, bytes)):
        for row in root:
            if isinstance(row, Mapping):
                identifier = _first(row, ("cause_id", "cause", "mechanism_id", "hypothesis_id", "id"))
                if identifier is not None:
                    rows.append((str(identifier), row))
    result: dict[str, str] = {}
    for identifier, row in rows:
        cue = _first(
            row,
            (
                "primary_signal",
                "diagnostic_signature",
                "expected_signature",
                "signature",
                "expected_pattern",
                "interpretation",
                "morphology",
            ),
        )
        if cue is not None:
            result[identifier] = str(cue)
    return result


def plot_mechanism_fingerprint_heatmap(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot signed, reported cause-by-probe effects and supplied intervals."""

    payload = _load_payload(payload_or_path)
    records = _fingerprint_records(payload)
    if not records:
        return _no_data(
            output_path,
            title="Mechanism fingerprint heatmap",
            message="No numeric cause-by-probe fingerprint effects were reported.",
            dpi=dpi,
        )
    inferred_causes = [str(record["cause"]) for record in records]
    declared_causes = _entity_records(
        payload, ("causes", "cause_profiles", "mechanisms", "hypotheses")
    )
    # Material-resolved rows use composite IDs; do not prepend empty base-cause
    # rows merely because the payload also contains the cause catalogue.
    if declared_causes and not any(identifier in inferred_causes for identifier, _ in declared_causes):
        declared_causes = []
    causes, cause_labels = _ordered_entities(declared_causes, inferred_causes)
    probes, probe_labels = _ordered_entities(
        _entity_records(payload, ("experiments", "probes", "probe_definitions", "diagnostic_probes", "interventions")),
        [record["probe"] for record in records],
    )
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for record in records:
        grouped.setdefault((record["cause"], record["probe"]), []).append(record)
    record_labels = {
        str(record["cause"]): str(record["cause_label"])
        for record in records
        if record.get("cause_label")
    }
    cause_labels = [record_labels.get(identifier, label) for identifier, label in zip(causes, cause_labels, strict=True)]
    matrix = np.full((len(causes), len(probes)), np.nan)
    significant = np.zeros_like(matrix, dtype=bool)
    for i, cause in enumerate(causes):
        for j, probe in enumerate(probes):
            rows = grouped.get((cause, probe), [])
            if not rows:
                continue
            matrix[i, j] = float(np.median([row["effect"] for row in rows]))
            lows = [row["low"] for row in rows if row["low"] is not None]
            highs = [row["high"] for row in rows if row["high"] is not None]
            if lows and highs:
                low, high = float(np.median(lows)), float(np.median(highs))
                significant[i, j] = low > 0.0 or high < 0.0
    finite = matrix[np.isfinite(matrix)]
    maximum = max(float(np.max(np.abs(finite))), np.finfo(float).eps)
    cues = _diagnosis_cues(payload)
    cue_items = [
        (cause, label, cues[cause])
        for cause, label in zip(causes, cause_labels, strict=True)
        if cause in cues
    ]
    show_cues = 0 < len(cue_items) <= 4 and len(causes) <= 8
    with plt.rc_context(_STYLE):
        if show_cues:
            figure, (axis, cue_axis) = plt.subplots(
                1,
                2,
                figsize=(max(7.4, 0.78 * len(probes) + 5.1), max(3.5, 0.48 * len(causes) + 2.1)),
                gridspec_kw={"width_ratios": (2.35, 1.0)},
            )
        else:
            figure, axis = plt.subplots(
                figsize=(max(6.4, 0.78 * len(probes) + 2.8), max(3.4, 0.48 * len(causes) + 2.0))
            )
            cue_axis = None
        all_signed = all(bool(record.get("signed", True)) for record in records)
        cmap = (
            _FINGERPRINT_CMAP.with_extremes(bad="#E5E5E5")
            if all_signed
            else _PAIRWISE_CMAP.with_extremes(bad="#E5E5E5")
        )
        norm = (
            TwoSlopeNorm(vmin=-maximum, vcenter=0.0, vmax=maximum)
            if all_signed
            else Normalize(vmin=0.0, vmax=maximum)
        )
        image = axis.imshow(
            np.ma.masked_invalid(matrix),
            aspect="auto",
            cmap=cmap,
            norm=norm,
        )
        axis.set_xticks(range(len(probes)), probe_labels, rotation=35, ha="right")
        axis.set_yticks(range(len(causes)), cause_labels)
        # Column labels already identify the probes; omitting a redundant
        # x-axis title preserves a clean footer for the screening notice.
        axis.set_ylabel("mechanism hypothesis")
        if matrix.size <= 100:
            for (i, j), value in np.ndenumerate(matrix):
                if math.isfinite(float(value)):
                    text = f"{value:.2g}" + ("*" if significant[i, j] else "")
                    color = "white" if abs(value) > 0.58 * maximum else "#222222"
                    axis.text(j, i, text, ha="center", va="center", fontsize=6.8, color=color)
                else:
                    axis.text(j, i, "NA", ha="center", va="center", fontsize=6.2, color="0.45")
        colorbar = figure.colorbar(image, ax=axis, fraction=0.045, pad=0.025)
        fingerprint_root = payload.get("fingerprints")
        unit = None
        if isinstance(fingerprint_root, Mapping):
            unit = _first(fingerprint_root, ("effect_unit", "unit", "metric_label"))
        colorbar.set_label(str(unit or ("reported signed effect" if all_signed else "reported normalized probe strength")))
        if np.any(significant):
            axis.text(
                1.0,
                1.02,
                "* supplied interval excludes zero",
                transform=axis.transAxes,
                ha="right",
                va="bottom",
                fontsize=6.6,
                color="0.35",
            )
        if cue_axis is not None:
            cue_axis.set_axis_off()
            cue_axis.set_title("Reported diagnostic cue", loc="left")
            block = 0.90 / len(cue_items)
            for index, (cause, label, cue) in enumerate(cue_items):
                y = 0.97 - block * index
                cue_axis.text(0.0, y, label, transform=cue_axis.transAxes, va="top", fontweight="bold")
                cue_axis.text(
                    0.0,
                    y - 0.075,
                    textwrap.fill(cue, width=36),
                    transform=cue_axis.transAxes,
                    va="top",
                    color="0.28",
                )
        figure.suptitle("Mechanism fingerprints across diagnostic probes", y=0.99, fontsize=11)
        figure.tight_layout(rect=(0.01, 0.31, 0.99, 0.93))
        return _finish(figure, output_path, dpi=dpi, bottom=0.30)


def _pairwise(payload: Mapping[str, Any]) -> tuple[list[str], np.ndarray | None, str]:
    root = payload.get("separability")
    if not isinstance(root, Mapping):
        root = payload
    cause_declared = _entity_records(payload, ("causes", "cause_profiles", "mechanisms", "hypotheses"))
    order_raw = _first(root, ("cause_order", "causes", "labels", "row_labels"))
    order = [str(value) for value in order_raw] if isinstance(order_raw, Sequence) and not isinstance(order_raw, (str, bytes)) else [item[0] for item in cause_declared]
    candidate = _first(
        root,
        ("pairwise_matrix", "pairwise_balanced_accuracy", "pairwise_auc", "matrix", "pairwise", "pairwise_robust_distances"),
    )
    matrix: np.ndarray | None = None
    if isinstance(candidate, Sequence) and not isinstance(candidate, (str, bytes)):
        try:
            array = np.asarray(candidate, dtype=float)
        except (TypeError, ValueError):
            array = np.empty((0, 0))
        if array.ndim == 2 and array.size > 0 and array.shape[0] == array.shape[1]:
            matrix = array
            if not order or len(order) != array.shape[0]:
                order = [str(index) for index in range(array.shape[0])]
    elif isinstance(candidate, Mapping):
        if not order:
            order = [str(key) for key in candidate]
        array = np.full((len(order), len(order)), np.nan)
        for i, left in enumerate(order):
            row = candidate.get(left)
            if isinstance(row, Mapping):
                for j, right in enumerate(order):
                    value = _number(row.get(right))
                    if value is not None:
                        array[i, j] = value
        if np.any(np.isfinite(array)):
            matrix = array
    elif isinstance(candidate, Sequence) and not isinstance(candidate, (str, bytes)):
        pass
    # Record-oriented production form: one row per material and cause pair.
    if matrix is None and isinstance(candidate, Sequence) and not isinstance(candidate, (str, bytes)):
        pair_records = [item for item in candidate if isinstance(item, Mapping)]
        inferred = []
        for item in pair_records:
            for key in ("left_cause", "cause_a", "left", "right_cause", "cause_b", "right"):
                value = item.get(key)
                if value is not None and str(value) not in inferred:
                    inferred.append(str(value))
        if not order:
            order = inferred
        values: dict[tuple[str, str], list[float]] = {}
        for item in pair_records:
            left = _first(item, ("left_cause", "cause_a", "left", "cause_1"))
            right = _first(item, ("right_cause", "cause_b", "right", "cause_2"))
            value = _number(_first(item, ("robust_distance", "balanced_accuracy", "auc", "separability", "value", "score")))
            if left is not None and right is not None and value is not None:
                values.setdefault((str(left), str(right)), []).append(value)
        if values and order:
            array = np.full((len(order), len(order)), np.nan)
            for (left, right), reported in values.items():
                if left not in order or right not in order:
                    continue
                value = float(np.median(reported))
                i, j = order.index(left), order.index(right)
                array[i, j] = array[j, i] = value
            if np.any(np.isfinite(array)):
                matrix = array
    if matrix is not None and not np.any(np.isfinite(matrix)):
        matrix = None
    default_label = "robust fingerprint distance" if "pairwise_robust_distances" in root else "reported separability"
    label = str(_first(root, ("pairwise_metric_label", "pairwise_metric", "metric_label", "metric")) or default_label)
    return order, matrix, label


def _greedy_records(payload: Mapping[str, Any]) -> tuple[list[dict[str, Any]], str]:
    root = payload.get("separability")
    roots = [root] if isinstance(root, Mapping) else []
    roots.append(payload)
    raw = None
    metric_label = "reported incremental value"
    for source in roots:
        raw = _first(source, ("greedy_order", "greedy_probe_order", "experiment_order", "recommended_experiment_order", "ordering"))
        if raw is not None:
            metric_label = str(_first(source, ("greedy_metric_label", "information_gain_label", "order_metric_label")) or metric_label)
            break
    if raw is None:
        return [], metric_label
    probe_labels = dict(_entity_records(payload, ("experiments", "probes", "probe_definitions", "diagnostic_probes", "interventions")))
    rows: list[dict[str, Any]] = []
    if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)) and any(
        isinstance(item, Mapping) and isinstance(item.get("steps"), Sequence)
        for item in raw
    ):
        strata = [item for item in raw if isinstance(item, Mapping) and isinstance(item.get("steps"), Sequence)]
        multiple = len(strata) > 1
        for stratum in strata:
            prefix = str(_first(stratum, ("material", "preset_id", "scope", "stratum")) or "")
            for step in stratum["steps"]:
                if not isinstance(step, Mapping):
                    continue
                identifier = str(_first(step, ("probe", "probe_id", "experiment", "experiment_id", "id")) or "unknown")
                base_label = probe_labels.get(identifier, identifier)
                label = f"{prefix} · {base_label}" if multiple and prefix else base_label
                score = _number(_first(step, ("minimum_pair_distance", "conditional_information_gain_bits", "information_gain_bits", "gain", "score", "value")))
                rows.append({"id": identifier, "label": label, "score": score})
        return rows, "minimum pair distance after selection"
    iterable = list(raw.items()) if isinstance(raw, Mapping) else list(enumerate(raw)) if isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)) else []
    for fallback, value in iterable:
        if isinstance(value, Mapping):
            identifier = str(_first(value, ("probe_id", "experiment_id", "probe", "experiment", "id", "name")) or fallback)
            label = str(_first(value, ("label", "display_name", "name")) or probe_labels.get(identifier, identifier))
            score_key = next(
                (
                    key
                    for key in (
                        "conditional_information_gain_bits",
                        "information_gain_bits",
                        "incremental_information_gain_bits",
                        "gain_bits",
                        "information_gain",
                        "gain",
                        "score",
                        "value",
                    )
                    if key in value
                ),
                None,
            )
            score = _number(value.get(score_key)) if score_key else None
            if score_key and "bit" in score_key and metric_label == "reported incremental value":
                metric_label = "conditional information gain (bits)"
        else:
            identifier = str(value if not isinstance(raw, Mapping) else fallback)
            label = probe_labels.get(identifier, identifier)
            score = _number(value) if isinstance(raw, Mapping) else None
        rows.append({"id": identifier, "label": label, "score": score})
    return rows, metric_label


def plot_mechanism_separability(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot reported pairwise cause separation and greedy experiment order."""

    payload = _load_payload(payload_or_path)
    cause_order, matrix, metric_label = _pairwise(payload)
    greedy, greedy_label = _greedy_records(payload)
    if matrix is None and not greedy:
        return _no_data(
            output_path,
            title="Mechanism separability and experiment order",
            message="No pairwise separability matrix or greedy experiment order was reported.",
            dpi=dpi,
        )
    cause_labels = dict(_entity_records(payload, ("causes", "cause_profiles", "mechanisms", "hypotheses")))
    with plt.rc_context(_STYLE):
        figure, (left, right) = plt.subplots(
            1,
            2,
            figsize=(11.0, max(4.8, 0.32 * len(greedy) + 1.8)),
            gridspec_kw={"width_ratios": (1.15, 1.0)},
        )
        if matrix is None:
            left.set_axis_off()
            left.text(0.5, 0.5, "Pairwise matrix not reported", ha="center", va="center", transform=left.transAxes)
        else:
            finite = matrix[np.isfinite(matrix)]
            low, high = float(np.min(finite)), float(np.max(finite))
            if math.isclose(low, high):
                pad = max(abs(low) * 0.05, 0.5)
                low, high = low - pad, high + pad
            cmap = _PAIRWISE_CMAP.with_extremes(bad="#E5E5E5")
            image = left.imshow(np.ma.masked_invalid(matrix), cmap=cmap, norm=Normalize(vmin=low, vmax=high), aspect="equal")
            labels = [cause_labels.get(value, value) for value in cause_order]
            left.set_xticks(range(len(labels)), labels, rotation=35, ha="right")
            left.set_yticks(range(len(labels)), labels)
            if matrix.size <= 100:
                midpoint = 0.5 * (low + high)
                for (i, j), value in np.ndenumerate(matrix):
                    if math.isfinite(float(value)):
                        left.text(j, i, f"{value:.2g}", ha="center", va="center", color="white" if value > midpoint else "#202020", fontsize=6.8)
                    else:
                        left.text(j, i, "NA", ha="center", va="center", color="0.45", fontsize=6.2)
            colorbar = figure.colorbar(image, ax=left, fraction=0.046, pad=0.025)
            colorbar.set_label(metric_label)
            left.set_title("Pairwise mechanism separability")
        if not greedy:
            right.set_axis_off()
            right.text(0.5, 0.5, "Greedy order not reported", ha="center", va="center", transform=right.transAxes)
        elif any(row["score"] is not None for row in greedy):
            positions = np.arange(len(greedy))
            values = [row["score"] if row["score"] is not None else np.nan for row in greedy]
            numeric = np.asarray(values, dtype=float)
            mask = np.isfinite(numeric)
            right.barh(positions[mask], numeric[mask], color="#5A91A8", edgecolor="#244A5A", linewidth=0.5)
            right.set_yticks(positions, [f"{index + 1}. {row['label']}" for index, row in enumerate(greedy)])
            right.invert_yaxis()
            right.axvline(0.0, color="0.55", linewidth=0.7)
            right.set_xlabel(greedy_label)
            for position, value in zip(positions[mask], numeric[mask], strict=True):
                right.text(value, position, f" {value:.3g}", va="center", ha="left" if value >= 0 else "right", fontsize=6.8)
            for position, row in zip(positions[~mask], np.asarray(greedy, dtype=object)[~mask], strict=True):
                right.text(0.0, position, " score not reported", va="center", color="0.4", fontsize=6.8)
            right.spines[["top", "right"]].set_visible(False)
            right.set_title("Greedy diagnostic experiment order")
        else:
            right.set_axis_off()
            right.set_title("Greedy diagnostic experiment order", loc="left")
            for index, row in enumerate(greedy):
                right.text(0.03, 0.92 - 0.1 * index, f"{index + 1}. {row['label']}", transform=right.transAxes, va="top")
        figure.suptitle("Mechanism identifiability under the reported screening design", y=0.99, fontsize=11)
        figure.tight_layout(rect=(0.01, 0.24, 0.99, 0.94))
        return _finish(figure, output_path, dpi=dpi, bottom=0.23)


def _site_records(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [dict(item) for item in value if isinstance(item, Mapping)]
    if not isinstance(value, Mapping):
        return []
    columns: dict[str, Sequence[Any]] = {}
    lengths: list[int] = []
    for key, column in value.items():
        if isinstance(column, Sequence) and not isinstance(column, (str, bytes, Mapping)):
            columns[str(key)] = column
            lengths.append(len(column))
    if not lengths or len(set(lengths)) != 1:
        return []
    return [{key: column[index] for key, column in columns.items()} for index in range(lengths[0])]


def _snapshot(case: Mapping[str, Any]) -> Mapping[str, Any] | None:
    for key in ("snapshot", "graph_snapshot", "final_snapshot", "representative_snapshot"):
        value = case.get(key)
        if isinstance(value, Mapping):
            return value
    return case if "sites" in case else None


def _flag(site: Mapping[str, Any], kind: str) -> bool:
    value = _first(site, (kind, f"{kind}_flag", "sidewall" if kind == "wall" else kind))
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    number = _number(value)
    if number is not None:
        return number > 0.5
    region = str(site.get("region", "")).lower()
    return (kind in region) or (kind == "wall" and "sidewall" in region) or (kind == "bottom" and "floor" in region)


def _plot_snapshot(axis: plt.Axes, case: Mapping[str, Any]) -> tuple[bool, dict[str, Line2D]]:
    snapshot = _snapshot(case)
    sites = _site_records(snapshot.get("sites")) if snapshot is not None else []
    if not sites:
        return False, {}
    categories: dict[str, list[tuple[float, float, float]]] = {
        "removed native": [],
        "native wall": [],
        "native bottom": [],
        "native other": [],
        "deposit wall": [],
        "deposit bottom": [],
        "deposit other": [],
    }
    for site in sites:
        x = _number(_first(site, ("x_nm", "lateral_nm", "x")))
        depth = _number(_first(site, ("depth_nm", "z_nm", "depth", "z")))
        if x is None or depth is None:
            continue
        state = str(site.get("state", "intact")).lower()
        site_type = str(site.get("site_type", site.get("type", "matrix"))).lower()
        coverage = max(_number(_first(site, ("deposit_coverage", "coverage"))) or 0.0, 0.0)
        thickness = max(_number(_first(site, ("deposit_thickness_nm", "thickness_nm"))) or 0.0, 0.0)
        deposit = site_type == "collector" and (state in {"deposit", "precipitated", "reattached"} or coverage > 0.0 or thickness > 0.0)
        if deposit:
            strength = coverage if coverage > 0.0 else math.log1p(thickness)
            label = "deposit bottom" if _flag(site, "bottom") else "deposit wall" if _flag(site, "wall") else "deposit other"
            categories[label].append((x, depth, strength))
        elif site_type != "collector":
            if state == "removed":
                categories["removed native"].append((x, depth, 1.0))
            else:
                label = "native bottom" if _flag(site, "bottom") else "native wall" if _flag(site, "wall") else "native other"
                categories[label].append((x, depth, 1.0))
    styles = {
        "removed native": ("s", "#C8E0E8"),
        "native wall": ("s", "#315A7D"),
        "native bottom": ("s", "#D19A2A"),
        "native other": ("s", "#666666"),
        "deposit wall": ("D", "#A23B72"),
        "deposit bottom": ("^", "#6F4C9B"),
        "deposit other": ("o", "#B24C4C"),
    }
    handles: dict[str, Line2D] = {}
    for label, rows in categories.items():
        if not rows:
            continue
        array = np.asarray(rows, dtype=float)
        marker, color = styles[label]
        sizes = np.full(len(rows), 11.0)
        alpha = 0.24 if label == "removed native" else 0.9
        if label.startswith("deposit"):
            sizes = 10.0 + 45.0 * np.sqrt(np.clip(array[:, 2], 0.0, 1.0))
        axis.scatter(array[:, 0], array[:, 1], marker=marker, s=sizes, color=color, alpha=alpha, linewidth=0, rasterized=True)
        handles[label] = Line2D([], [], linestyle="", marker=marker, markerfacecolor=color, markeredgecolor="none", markersize=5, label=label)
    axis.invert_yaxis()
    axis.set_xlabel("lateral x (nm; expanded)")
    axis.set_ylabel("depth z (nm)")
    axis.grid(color="0.91", linewidth=0.45)
    return bool(handles), handles


def _case_title(case: Mapping[str, Any]) -> str:
    values = []
    for names in (
        ("cause_label", "cause_id", "cause", "mechanism"),
        ("material", "preset_id", "morphology", "pattern", "classification"),
        ("case_id", "id"),
    ):
        value = _first(case, names)
        if isinstance(value, Mapping):
            value = _first(value, ("primary_class", "label", "name"))
        if value is not None and str(value) not in values:
            values.append(str(value))
    return " | ".join(values[:2]) or "reported case"


_MORPHOLOGY_METRICS = {
    "native wall": (
        "native_wall_longest_run_primary",
        "native_wall_coverage_primary",
        "native_wall_continuity",
        "wall_native_continuity",
        "native_wall_fraction",
        "primary_wall_remaining_fraction",
        "wall_remaining_fraction",
    ),
    "native bottom": (
        "primary_bottom_remaining_fraction",
        "native_bottom_fraction",
        "bottom_native_fraction",
        "bottom_remaining_fraction",
    ),
    "deposit wall": (
        "deposit_wall_longest_run_pre_second",
        "deposit_wall_coverage_pre_second",
        "pre_second_wall_deposit_fraction",
        "deposit_wall_continuity",
        "wall_deposit_continuity",
        "deposit_wall_fraction",
        "wall_deposit_fraction",
    ),
    "deposit bottom": ("deposit_bottom_fraction", "bottom_deposit_fraction"),
}


def _morphology_metric_rows(cases: Sequence[Mapping[str, Any]]) -> tuple[list[str], list[str], np.ndarray]:
    rows: list[dict[str, Any]] = []
    for case in cases:
        sources = [case]
        for key in ("morphology_metrics", "metrics", "spatial_metrics"):
            value = case.get(key)
            if isinstance(value, Mapping):
                sources.insert(0, value)
        record: dict[str, Any] = {"label": _case_title(case)}
        for label, aliases in _MORPHOLOGY_METRICS.items():
            value = None
            for source in sources:
                value = _number(_first(source, aliases))
                if value is not None:
                    break
            record[label] = value
        if any(record[label] is not None for label in _MORPHOLOGY_METRICS):
            rows.append(record)
    labels = [row["label"] for row in rows]
    metric_labels = list(_MORPHOLOGY_METRICS)
    matrix = np.asarray([[row[label] if row[label] is not None else np.nan for label in metric_labels] for row in rows], dtype=float) if rows else np.empty((0, len(metric_labels)))
    return labels, metric_labels, matrix


def _reference_cases(
    cases: Sequence[Mapping[str, Any]], max_examples: int
) -> list[Mapping[str, Any]]:
    centre = [
        case
        for case in cases
        if str(case.get("probe_level", "")).lower() in {"center", "centre"}
        and str(case.get("status", "ok")).lower() == "ok"
    ]
    candidates = centre or [
        case for case in cases if str(case.get("status", "ok")).lower() == "ok"
    ]
    representative: list[Mapping[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for case in candidates:
        key = (
            str(case.get("cause_id", case.get("cause", ""))),
            str(case.get("preset_id", case.get("material", ""))),
        )
        if key in seen:
            continue
        seen.add(key)
        representative.append(case)
        if len(representative) >= max_examples:
            break
    return representative


def _plot_spatial_profile(
    axis: plt.Axes, case: Mapping[str, Any]
) -> tuple[bool, dict[str, Line2D]]:
    profile = case.get("spatial_profile")
    if not isinstance(profile, Mapping):
        return False, {}
    depth_raw = _first(
        profile,
        ("normalized_depth_bin_centres", "normalized_depth", "depth_fraction"),
    )
    if not isinstance(depth_raw, Sequence) or isinstance(depth_raw, (str, bytes)):
        return False, {}
    try:
        depth = np.asarray(depth_raw, dtype=float).reshape(-1)
    except (TypeError, ValueError):
        return False, {}
    if not depth.size or not np.all(np.isfinite(depth)):
        return False, {}
    definitions = (
        ("primary native wall", "primary_native_wall_occupied", "primary_native_wall_valid", "#315A7D", "-"),
        ("final native wall", "final_native_wall_occupied", "primary_native_wall_valid", "#315A7D", ":"),
        ("pre-second deposit wall", "pre_second_deposit_wall_occupied", "pre_second_deposit_wall_valid", "#A23B72", "-"),
        ("final deposit wall", "final_deposit_wall_occupied", "pre_second_deposit_wall_valid", "#A23B72", ":"),
    )
    handles: dict[str, Line2D] = {}
    for label, value_key, valid_key, color, linestyle in definitions:
        values_raw = profile.get(value_key)
        if not isinstance(values_raw, Sequence) or isinstance(values_raw, (str, bytes)):
            continue
        try:
            values = np.asarray(values_raw, dtype=float).reshape(-1)
        except (TypeError, ValueError):
            continue
        if values.size != depth.size:
            continue
        valid_raw = profile.get(valid_key)
        if isinstance(valid_raw, Sequence) and not isinstance(valid_raw, (str, bytes)):
            valid = np.asarray(valid_raw, dtype=bool).reshape(-1)
            if valid.size == depth.size:
                values = np.where(valid, values, np.nan)
        axis.step(values, depth, where="mid", color=color, linestyle=linestyle, linewidth=1.45)
        handles[label] = Line2D([], [], color=color, linestyle=linestyle, linewidth=1.45, label=label)
    if not handles:
        return False, {}
    primary_bottom = _number(profile.get("primary_bottom_remaining_fraction"))
    final_bottom = _number(profile.get("final_bottom_remaining_fraction"))
    bottom_text = []
    if primary_bottom is not None:
        bottom_text.append(f"bottom primary={primary_bottom:.2g}")
    if final_bottom is not None:
        bottom_text.append(f"final={final_bottom:.2g}")
    if bottom_text:
        axis.text(
            0.02,
            0.02,
            ", ".join(bottom_text),
            transform=axis.transAxes,
            va="bottom",
            fontsize=6.4,
            color="0.30",
        )
    axis.set_xlim(-0.04, 1.04)
    axis.set_xticks((0.0, 0.5, 1.0))
    axis.set_xlabel("wall-bin occupancy")
    axis.set_ylabel("normalized depth")
    axis.invert_yaxis()
    axis.grid(color="0.91", linewidth=0.45)
    return True, handles


def _has_spatial_occupancy(case: Mapping[str, Any]) -> bool:
    profile = case.get("spatial_profile")
    if not isinstance(profile, Mapping):
        return False
    depth = _first(
        profile,
        ("normalized_depth_bin_centres", "normalized_depth", "depth_fraction"),
    )
    if not isinstance(depth, Sequence) or isinstance(depth, (str, bytes)):
        return False
    return any(
        isinstance(profile.get(key), Sequence)
        and not isinstance(profile.get(key), (str, bytes))
        and len(profile[key]) == len(depth)
        for key in (
            "primary_native_wall_occupied",
            "final_native_wall_occupied",
            "pre_second_deposit_wall_occupied",
            "final_deposit_wall_occupied",
        )
    )


def plot_mechanism_morphology_examples(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
    max_examples: int = 18,
) -> Path:
    """Plot reported graph snapshots; use scalar morphology metrics as fallback."""

    if not isinstance(max_examples, int) or isinstance(max_examples, bool) or max_examples < 1:
        raise ValueError("max_examples must be a positive integer")
    payload = _load_payload(payload_or_path)
    raw_cases = _first(
        payload,
        (
            "cases",
            "reference_cases",
            "representatives",
            "examples",
            "probe_cases",
            "calibration_cases",
        ),
    )
    cases = [dict(value) for value in raw_cases if isinstance(value, Mapping)] if isinstance(raw_cases, Sequence) and not isinstance(raw_cases, (str, bytes)) else []
    snapshot_cases = [case for case in cases if _snapshot(case) is not None and _site_records(_snapshot(case).get("sites"))]
    if snapshot_cases:
        selected = snapshot_cases[:max_examples]
        columns = min(4, len(selected))
        rows = int(math.ceil(len(selected) / columns))
        with plt.rc_context(_STYLE):
            figure, axes_array = plt.subplots(rows, columns, figsize=(3.25 * columns, 4.4 * rows), squeeze=False)
            axes = list(axes_array.ravel())
            legend: dict[str, Line2D] = {}
            for axis, case in zip(axes, selected, strict=False):
                plotted, handles = _plot_snapshot(axis, case)
                if not plotted:
                    axis.set_axis_off()
                    axis.text(0.5, 0.5, "Snapshot has no plottable sites", ha="center", va="center", transform=axis.transAxes)
                axis.set_title(_case_title(case))
                legend.update({key: value for key, value in handles.items() if key not in legend})
            for axis in axes[len(selected) :]:
                axis.set_visible(False)
            if legend:
                figure.legend(legend.values(), legend.keys(), loc="upper center", bbox_to_anchor=(0.5, 0.935), ncol=min(7, len(legend)))
            figure.suptitle("Reported native and deposited residue morphologies", y=0.995, fontsize=11)
            figure.tight_layout(rect=(0.01, 0.12, 0.99, 0.88))
            return _finish(figure, output_path, dpi=dpi, bottom=0.14)
    # Large studies contain every low/centre/high replicate.  A morphology
    # plate should not pretend those are independent examples; keep one centre
    # case per cause/material (or the first reported cases if no level exists).
    representative = _reference_cases(cases, max_examples)
    profile_cases = [case for case in representative if _has_spatial_occupancy(case)]
    if profile_cases:
        columns = min(4, len(profile_cases))
        rows = int(math.ceil(len(profile_cases) / columns))
        with plt.rc_context(_STYLE):
            figure, axes_array = plt.subplots(
                rows,
                columns,
                figsize=(3.2 * columns, 4.1 * rows),
                squeeze=False,
            )
            axes = list(axes_array.ravel())
            legend: dict[str, Line2D] = {}
            for axis, case in zip(axes, profile_cases, strict=False):
                plotted, handles = _plot_spatial_profile(axis, case)
                if not plotted:
                    axis.set_axis_off()
                    axis.text(
                        0.5,
                        0.5,
                        "Spatial profile has no plottable occupancy",
                        ha="center",
                        va="center",
                        transform=axis.transAxes,
                    )
                axis.set_title(_case_title(case))
                legend.update({key: value for key, value in handles.items() if key not in legend})
            for axis in axes[len(profile_cases) :]:
                axis.set_visible(False)
            if legend:
                figure.legend(
                    legend.values(),
                    legend.keys(),
                    loc="upper center",
                    bbox_to_anchor=(0.5, 0.935),
                    ncol=min(4, len(legend)),
                )
            figure.suptitle(
                "Native/deposit wall occupancy versus normalized trench depth",
                y=0.995,
                fontsize=11,
            )
            figure.tight_layout(rect=(0.01, 0.12, 0.99, 0.88))
            return _finish(figure, output_path, dpi=dpi, bottom=0.14)
    labels, metric_labels, matrix = _morphology_metric_rows(representative)
    if matrix.size and np.any(np.isfinite(matrix)):
        finite = matrix[np.isfinite(matrix)]
        low, high = float(np.min(finite)), float(np.max(finite))
        if math.isclose(low, high):
            high = low + max(abs(low) * 0.05, 1.0e-6)
        with plt.rc_context(_STYLE):
            figure, axis = plt.subplots(figsize=(7.6, max(3.4, 0.48 * len(labels) + 2.0)))
            cmap = _PAIRWISE_CMAP.with_extremes(bad="#E5E5E5")
            image = axis.imshow(np.ma.masked_invalid(matrix), aspect="auto", cmap=cmap, norm=Normalize(vmin=low, vmax=high))
            axis.set_xticks(range(len(metric_labels)), metric_labels, rotation=25, ha="right")
            axis.set_yticks(range(len(labels)), labels)
            for (i, j), value in np.ndenumerate(matrix):
                axis.text(j, i, f"{value:.2g}" if math.isfinite(float(value)) else "NA", ha="center", va="center", color="white" if math.isfinite(float(value)) and value > 0.5 * (low + high) else "#202020", fontsize=6.8)
            colorbar = figure.colorbar(image, ax=axis, fraction=0.045, pad=0.025)
            colorbar.set_label("reported morphology metric")
            axis.set_title("Morphology metrics (snapshot fallback)")
            figure.tight_layout(rect=(0.01, 0.12, 0.99, 0.94))
            return _finish(figure, output_path, dpi=dpi, bottom=0.14)
    cues = _diagnosis_cues(payload)
    if cues:
        with plt.rc_context(_STYLE):
            figure, axis = plt.subplots(figsize=(8.0, max(3.2, 0.62 * len(cues) + 1.7)))
            axis.set_axis_off()
            y = 0.95
            for cause, cue in cues.items():
                axis.text(0.02, y, cause, transform=axis.transAxes, va="top", fontweight="bold")
                axis.text(0.25, y, textwrap.fill(cue, width=75), transform=axis.transAxes, va="top", color="0.28")
                y -= 0.85 / max(len(cues), 1)
            axis.set_title("Reported morphology descriptors (snapshot fallback)", loc="left")
            return _finish(figure, output_path, dpi=dpi, bottom=0.14)
    return _no_data(
        output_path,
        title="Native and deposited residue morphologies",
        message="No graph snapshots, scalar morphology metrics or morphology descriptors were reported.",
        dpi=dpi,
    )


def plot_mechanism_discrimination_visualizations(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_directory: str | Path,
    *,
    dpi: int = 300,
) -> dict[str, Path]:
    """Write all three mandatory mechanism-discrimination PNG figures."""

    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    return {
        "mechanism_fingerprint_heatmap": plot_mechanism_fingerprint_heatmap(
            payload_or_path, output / "mechanism_fingerprint_heatmap.png", dpi=dpi
        ),
        "mechanism_separability": plot_mechanism_separability(
            payload_or_path, output / "mechanism_separability.png", dpi=dpi
        ),
        "mechanism_morphology_examples": plot_mechanism_morphology_examples(
            payload_or_path, output / "mechanism_morphology_examples.png", dpi=dpi
        ),
    }


plot_mechanism_discrimination_outputs = plot_mechanism_discrimination_visualizations

__all__ = [
    "EXPECTED_PAYLOAD_KEYS",
    "SCREENING_NOTICE",
    "expected_payload_keys",
    "plot_mechanism_discrimination_outputs",
    "plot_mechanism_discrimination_visualizations",
    "plot_mechanism_fingerprint_heatmap",
    "plot_mechanism_morphology_examples",
    "plot_mechanism_separability",
]

#!/usr/bin/env python3
"""Figures for a calibrated primary-HF to second-WET sequence.

Preferred schema
----------------
The preferred payload is ``trench-calibrated-wet-sequence/v1``.  Each case is
one collector branch continued from one *observed* primary-HF event state.
Branches with a common ``paired_branch_id`` must share the primary case,
target, removal count, seed and second-WET matrix continuation.

``collector_branch.basis`` distinguishes:

``all_physical_upper``
    Every physical wall/floor collector may receive deposit.

``endpoint_liquid_accessible``
    Only collectors exposed to endpoint liquid may receive deposit.

``capture_policy`` is deliberately separate.  Restricting collector support
while keeping captured inventory fixed changes density and location, not total
deposit.  A true amount-reducing hypothesis must therefore identify itself,
for example as ``accessible_area_scaled`` and report unassigned precursor in
the stage mass balance.

The visualizer never joins standalone primary-HF and attachment payloads by
geometry or seed.  It consumes an already integrated payload with explicit
lineage, avoiding accidental connection of different stochastic trajectories.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.cm import ScalarMappable
import numpy as np


plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = [
    "Hiragino Sans",
    "Noto Sans JP",
    "YuGothic",
    "Arial",
    "DejaVu Sans",
    "Liberation Sans",
]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42


SCHEMA_VERSION = "trench-calibrated-wet-sequence/v1"
SCREENING_NOTICE = (
    "Calibrated primary-HF clock with post-HF mechanism hypotheses.\n"
    "Collector accessibility and capture policy are separate assumptions; "
    "this is not a qualified process recipe."
)

EXPECTED_PAYLOAD_KEYS: dict[str, tuple[str, ...]] = {
    "top_level": (
        "schema_version",
        "notice",
        "config",
        "cases",
        "paired_branch_contrasts",
        "quality_summary",
        "model_limitations",
        "artifacts",
    ),
    "case": (
        "case_id",
        "status",
        "stratum",
        "lineage",
        "primary_endpoint",
        "collector_branch",
        "stages",
        "final_metrics",
    ),
    "lineage": (
        "primary_case_id",
        "target_remaining_fraction",
        "removed_count_at_endpoint",
        "seed",
    ),
    "primary_endpoint": (
        "reached",
        "observation_status",
        "endpoint_physical_time_s",
        "blanket_rate_uncertainty_interval",
        "snapshot",
    ),
    "collector_branch": (
        "paired_branch_id",
        "basis",
        "capture_policy",
        "eligible_collector_mask",
        "eligible_wall_contact_fraction",
        "eligible_bottom_contact_fraction",
        "unassigned_precursor_fraction",
    ),
    "stages": (
        "hf_endpoint",
        "rinse_endpoint",
        "drydown_endpoint",
        "second_wet_endpoint",
    ),
    "stage": (
        "cumulative_physical_time_s",
        "cumulative_time_uncertainty",
        "matrix",
        "deposit_diagnostics",
        "residue_components",
        "mass_balance",
        "spatial",
    ),
    "spatial": (
        "x_nm",
        "depth_nm",
        "cavity_mask",
        "remaining_original_gap_fill_mask",
        "wall_deposit_thickness_nm",
        "bottom_deposit_thickness_nm",
    ),
}

_STYLE = {
    "font.size": 7.8,
    "axes.titlesize": 8.8,
    "axes.labelsize": 7.8,
    "axes.linewidth": 0.7,
    "xtick.labelsize": 6.8,
    "ytick.labelsize": 6.8,
    "legend.fontsize": 6.6,
    "legend.frameon": False,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
}

_STAGES = (
    ("hf_endpoint", "HF endpoint"),
    ("rinse_endpoint", "rinse"),
    ("drydown_endpoint", "dry-down"),
    ("second_wet_endpoint", "second-WET"),
)
_COMPONENTS = (
    ("matrix", "Original GAP FILL", "#3B6A91"),
    ("deposit", "Deposit equivalent", "#C56B32"),
    ("total", "Total equivalent residue", "#8F3B57"),
)
_BRANCH_COLORS = {
    "all_physical_upper": "#A54252",
    "endpoint_liquid_accessible": "#2D7592",
}
_BRANCH_LABELS = {
    "all_physical_upper": "all-collector upper",
    "endpoint_liquid_accessible": "accessible-only",
}
_MASK_CMAP = ListedColormap(("#D8DCE1", "#E6F2F6", "#545A64"))
_DEPOSIT_CMAP = LinearSegmentedColormap.from_list(
    "deposit_thickness", ("#FFE7A3", "#F39C35", "#9E2F3D")
)
_RATIO_CMAP = LinearSegmentedColormap.from_list(
    "lower_upper_ratio", ("#3F7899", "#F7F7F7", "#B44A50")
)


def expected_payload_keys() -> dict[str, tuple[str, ...]]:
    """Return a copy of the preferred, non-exclusive schema."""

    return {key: tuple(value) for key, value in EXPECTED_PAYLOAD_KEYS.items()}


def _load_payload(
    value: Mapping[str, Any] | str | Path,
) -> Mapping[str, Any]:
    if isinstance(value, (str, Path)):
        payload = json.loads(Path(value).read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("calibrated WET sequence JSON must contain a mapping")
        return payload
    if not isinstance(value, Mapping):
        raise TypeError("expected a mapping or a JSON path")
    return value


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _sequence(value: Any) -> list[Any]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return list(value)
    return []


def _number(value: Any) -> float | None:
    if value is None or isinstance(value, (bool, np.bool_)):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _first(mapping: Mapping[str, Any], names: Sequence[str]) -> Any:
    for name in names:
        value = mapping.get(name)
        if value is not None:
            return value
    return None


def _cases(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    raw = payload.get("cases", [])
    if isinstance(raw, Mapping):
        result: list[Mapping[str, Any]] = []
        for case_id, item in raw.items():
            if not isinstance(item, Mapping):
                continue
            row = dict(item)
            row.setdefault("case_id", str(case_id))
            result.append(row)
        return result
    return [item for item in _sequence(raw) if isinstance(item, Mapping)]


def _successful_cases(payload: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    result = []
    for case in _cases(payload):
        if str(case.get("status", "ok")).lower() in {"failed", "error"}:
            continue
        endpoint = _mapping(case.get("primary_endpoint"))
        observation = str(endpoint.get("observation_status", "observed"))
        if endpoint and observation in {"invalid", "budget_censored", "right_censored"}:
            continue
        if endpoint and endpoint.get("reached") is False:
            continue
        result.append(case)
    return result


def _destination(path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def _finish(
    figure: plt.Figure,
    output_path: str | Path,
    *,
    dpi: int,
    bottom: float = 0.17,
) -> Path:
    if not isinstance(dpi, int) or isinstance(dpi, bool) or dpi < 1:
        plt.close(figure)
        raise ValueError("dpi must be a positive integer")
    figure.text(
        0.5,
        0.006,
        SCREENING_NOTICE,
        ha="center",
        va="bottom",
        fontsize=6.1,
        color="0.32",
        wrap=True,
    )
    figure.subplots_adjust(bottom=bottom)
    destination = _destination(output_path)
    figure.savefig(destination, dpi=dpi, bbox_inches="tight")
    plt.close(figure)
    return destination


def _no_data(
    output_path: str | Path,
    *,
    title: str,
    message: str,
    dpi: int,
) -> Path:
    with plt.rc_context(_STYLE):
        figure, axis = plt.subplots(figsize=(7.6, 3.5))
        axis.set_axis_off()
        axis.text(
            0.5,
            0.60,
            "No integrated sequence data",
            ha="center",
            va="center",
            fontsize=15,
            fontweight="semibold",
        )
        axis.text(
            0.5,
            0.40,
            message,
            ha="center",
            va="center",
            color="0.36",
            transform=axis.transAxes,
            wrap=True,
        )
        figure.suptitle(title, y=0.95, fontsize=11)
        return _finish(figure, output_path, dpi=dpi)


def _stratum(case: Mapping[str, Any]) -> Mapping[str, Any]:
    root = _mapping(case.get("stratum"))
    return root if root else case


def _value(case: Mapping[str, Any], name: str, default: Any = "") -> Any:
    return _stratum(case).get(name, case.get(name, default))


def _scenario_label(case: Mapping[str, Any]) -> str:
    label = _value(case, "scenario_label_ja", None)
    if label is not None:
        return str(label)
    scenario = str(_value(case, "scenario", "unknown"))
    return {
        "transport_only": "transport only",
        "passivation_hypothesis": "product + passivation",
    }.get(scenario, scenario.replace("_", " "))


def _branch(case: Mapping[str, Any]) -> Mapping[str, Any]:
    return _mapping(case.get("collector_branch"))


def _branch_basis(case: Mapping[str, Any]) -> str:
    return str(_first(_branch(case), ("basis", "collector_basis", "branch")) or "unknown")


def _branch_label(case: Mapping[str, Any]) -> str:
    basis = _branch_basis(case)
    return _BRANCH_LABELS.get(basis, basis.replace("_", " "))


def _branch_color(basis: str) -> str:
    return _BRANCH_COLORS.get(basis, "#666666")


def _stage(case: Mapping[str, Any], name: str) -> Mapping[str, Any]:
    return _mapping(_mapping(case.get("stages")).get(name))


def _deposit(stage: Mapping[str, Any]) -> Mapping[str, Any]:
    nested = _first(
        stage,
        (
            "deposit_diagnostics",
            "deposit",
            "persistent_deposit",
            "deposit_metrics",
        ),
    )
    if isinstance(nested, Mapping):
        return nested
    return stage


def _residue(stage: Mapping[str, Any]) -> Mapping[str, Any]:
    return _mapping(stage.get("residue_components"))


def _matrix_fraction(stage: Mapping[str, Any]) -> float | None:
    matrix = _mapping(stage.get("matrix"))
    value = _number(
        _first(
            matrix,
            (
                "remaining_fraction",
                "matrix_remaining_fraction",
                "original_gap_fill_remaining_fraction",
            ),
        )
    )
    if value is not None:
        return value
    return _number(
        _first(
            _residue(stage),
            (
                "original_gap_fill_fraction_of_initial",
                "matrix_fraction_of_initial_gap_fill_area",
            ),
        )
    )


def _deposit_fraction(stage: Mapping[str, Any]) -> float | None:
    residue = _residue(stage)
    value = _number(
        _first(
            residue,
            (
                "deposit_fraction_of_initial_gap_fill_area",
                "deposit_equivalent_area_fraction",
            ),
        )
    )
    if value is not None:
        return value
    return _number(
        _first(
            _deposit(stage),
            (
                "fraction_of_initial_gap_fill_area",
                "deposit_fraction_of_initial_gap_fill_area",
            ),
        )
    )


def _total_fraction(stage: Mapping[str, Any]) -> float | None:
    value = _number(
        _first(
            _residue(stage),
            (
                "total_equivalent_residue_fraction",
                "total_fraction_of_initial_gap_fill_area",
            ),
        )
    )
    if value is not None:
        return value
    matrix = _matrix_fraction(stage)
    deposit = _deposit_fraction(stage)
    if matrix is None and deposit is None:
        return None
    return (matrix or 0.0) + (deposit or 0.0)


def _component_fraction(stage: Mapping[str, Any], component: str) -> float | None:
    if component == "matrix":
        return _matrix_fraction(stage)
    if component == "deposit":
        return _deposit_fraction(stage)
    if component == "total":
        return _total_fraction(stage)
    raise ValueError(f"unknown component {component!r}")


def _group_key(case: Mapping[str, Any]) -> tuple[str, str, str, str, str]:
    return (
        str(_value(case, "geometry_id", "unknown geometry")),
        str(_value(case, "preset_id", "unknown preset")),
        str(_value(case, "material", "unknown material")),
        str(_value(case, "scenario", "unknown scenario")),
        str(_branch(case).get("capture_policy", "fixed_inventory")),
    )


def _group_label(
    key: tuple[str, str, str, str, str],
    example: Mapping[str, Any],
) -> str:
    geometry, _preset, material, scenario, policy = key
    endpoint = _mapping(example.get("primary_endpoint"))
    time_s = _number(endpoint.get("endpoint_physical_time_s"))
    time_text = "tHF not reported" if time_s is None else f"tHF={time_s / 60.0:.1f} min"
    return (
        f"{geometry}\n{material} · {scenario.replace('_', ' ')}\n"
        f"{policy.replace('_', ' ')} · {time_text}"
    )


def _stage_vector(
    case: Mapping[str, Any], component: str
) -> np.ndarray:
    return np.asarray(
        [
            np.nan
            if (value := _component_fraction(_stage(case, stage), component)) is None
            else value
            for stage, _label in _STAGES
        ],
        dtype=float,
    )


def plot_calibrated_wet_stage_envelope(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot matrix, deposit and total residue through the four WET stages."""

    payload = _load_payload(payload_or_path)
    cases = _successful_cases(payload)
    cases = [
        case
        for case in cases
        if any(
            np.any(np.isfinite(_stage_vector(case, component)))
            for component, _label, _color in _COMPONENTS
        )
    ]
    if not cases:
        return _no_data(
            output_path,
            title="Calibrated HF-to-second-WET residue envelope",
            message=(
                "Expected integrated cases[*].stages with matrix remaining and "
                "deposit equivalent-area diagnostics."
            ),
            dpi=dpi,
        )

    group_keys = list(dict.fromkeys(_group_key(case) for case in cases))
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(
            len(group_keys),
            len(_COMPONENTS),
            figsize=(12.8, max(4.0, 2.65 * len(group_keys) + 1.7)),
            squeeze=False,
            sharex=True,
        )
        x = np.arange(len(_STAGES), dtype=float)
        legend: dict[str, Line2D] = {}
        for row, key in enumerate(group_keys):
            subset = [case for case in cases if _group_key(case) == key]
            branches = list(dict.fromkeys(_branch_basis(case) for case in subset))
            for column, (component, component_label, _component_color) in enumerate(
                _COMPONENTS
            ):
                axis = axes[row, column]
                for basis in branches:
                    branch_cases = [
                        case for case in subset if _branch_basis(case) == basis
                    ]
                    arrays = np.asarray(
                        [_stage_vector(case, component) for case in branch_cases],
                        dtype=float,
                    )
                    if arrays.size == 0 or not np.any(np.isfinite(arrays)):
                        continue
                    median = np.nanmedian(arrays, axis=0)
                    low = np.nanmin(arrays, axis=0)
                    high = np.nanmax(arrays, axis=0)
                    color = _branch_color(basis)
                    label = _branch_label(branch_cases[0])
                    line, = axis.plot(
                        x,
                        median,
                        marker="o",
                        markersize=3.7,
                        linewidth=1.45,
                        color=color,
                        label=label,
                    )
                    axis.fill_between(
                        x,
                        low,
                        high,
                        color=color,
                        alpha=0.15,
                        linewidth=0.0,
                    )
                    legend.setdefault(label, line)
                axis.set_ylim(bottom=0.0)
                axis.grid(axis="y", color="0.91", linewidth=0.45)
                axis.spines[["top", "right"]].set_visible(False)
                if row == 0:
                    axis.set_title(component_label, fontweight="semibold")
                if column == 0:
                    axis.set_ylabel(
                        _group_label(key, subset[0]),
                        rotation=0,
                        ha="right",
                        va="center",
                        labelpad=48,
                    )
                if row == len(group_keys) - 1:
                    axis.set_xticks(
                        x,
                        [label for _name, label in _STAGES],
                        rotation=20,
                        ha="right",
                    )
                else:
                    axis.set_xticks(x, [])
        figure.suptitle(
            "Calibrated endpoint → rinse → dry-down → second-WET",
            y=0.995,
            fontsize=11.2,
        )
        if legend:
            figure.legend(
                legend.values(),
                legend.keys(),
                loc="upper center",
                bbox_to_anchor=(0.5, 0.965),
                ncol=min(4, len(legend)),
            )
        figure.tight_layout(rect=(0.02, 0.17, 0.99, 0.92), h_pad=1.25, w_pad=1.0)
        return _finish(figure, output_path, dpi=dpi)


def _pair_id(case: Mapping[str, Any]) -> str:
    branch = _branch(case)
    explicit = _first(branch, ("paired_branch_id", "pair_id"))
    if explicit is not None:
        return str(explicit)
    lineage = _mapping(case.get("lineage"))
    return "__".join(
        (
            str(_value(case, "geometry_id", "unknown")),
            str(_value(case, "preset_id", "unknown")),
            str(_value(case, "scenario", "unknown")),
            str(lineage.get("seed", _value(case, "seed", "unknown"))),
            str(branch.get("capture_policy", "fixed_inventory")),
        )
    )


def _paired_cases(
    cases: Sequence[Mapping[str, Any]],
) -> list[tuple[str, Mapping[str, Any], Mapping[str, Any]]]:
    grouped: dict[str, list[Mapping[str, Any]]] = {}
    order: list[str] = []
    for case in cases:
        pair_id = _pair_id(case)
        if pair_id not in grouped:
            grouped[pair_id] = []
            order.append(pair_id)
        grouped[pair_id].append(case)
    result = []
    for pair_id in order:
        items = grouped[pair_id]
        upper = next(
            (
                case
                for case in items
                if _branch_basis(case) == "all_physical_upper"
                or "upper" in _branch_basis(case)
            ),
            None,
        )
        lower = next(
            (
                case
                for case in items
                if _branch_basis(case) == "endpoint_liquid_accessible"
                or "accessible" in _branch_basis(case)
            ),
            None,
        )
        if upper is not None and lower is not None:
            result.append((pair_id, upper, lower))
    return result


def _deposit_metric(
    case: Mapping[str, Any], stage_name: str, metric: str
) -> float | None:
    stage = _stage(case, stage_name)
    deposit = _deposit(stage)
    if metric == "deposit_fraction":
        return _deposit_fraction(stage)
    if metric == "total_fraction":
        return _total_fraction(stage)
    aliases = {
        "wall_density": (
            "wall_areal_inventory_mol_m2",
            "wall_areal_density_mol_m2",
        ),
        "bottom_density": (
            "bottom_areal_inventory_mol_m2",
            "bottom_areal_density_mol_m2",
        ),
    }[metric]
    enabled = _mapping(stage.get("enabled_area_normalization"))
    enabled_aliases = {
        "wall_density": (
            "wall_areal_inventory_mol_m2_enabled",
        ),
        "bottom_density": (
            "bottom_areal_inventory_mol_m2_enabled",
        ),
    }[metric]
    enabled_value = _number(_first(enabled, enabled_aliases))
    if enabled_value is not None:
        return enabled_value
    return _number(_first(deposit, aliases))


def _ratio(lower: float | None, upper: float | None) -> float | None:
    if lower is None or upper is None or upper <= 0.0:
        return None
    return lower / upper


def _branch_fraction(case: Mapping[str, Any], names: Sequence[str]) -> float | None:
    value = _number(_first(_branch(case), names))
    if value is not None:
        return value
    return _number(_first(_mapping(case.get("final_metrics")), names))


def _pair_label(
    upper: Mapping[str, Any], lower: Mapping[str, Any] | None = None
) -> str:
    seed = _mapping(upper.get("lineage")).get(
        "seed", _value(upper, "seed", "?")
    )
    label = (
        f"{_value(upper, 'geometry_id', '?')} · "
        f"{_value(upper, 'material', '?')} · {_scenario_label(upper)} · seed {seed}"
    )
    if lower is None:
        return label
    policy = str(_branch(lower).get("capture_policy", "not reported"))
    return f"{label} · {policy.replace('_', ' ')}"


def plot_collector_accessibility_comparison(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Compare paired all-collector and accessible-only branch responses."""

    payload = _load_payload(payload_or_path)
    pairs = _paired_cases(_successful_cases(payload))
    if not pairs:
        return _no_data(
            output_path,
            title="Collector-accessibility branch comparison",
            message=(
                "Expected paired cases sharing collector_branch.paired_branch_id "
                "with all_physical_upper and endpoint_liquid_accessible bases."
            ),
            dpi=dpi,
        )

    metric_specs = (
        ("dry deposit", "drydown_endpoint", "deposit_fraction"),
        ("dry wall density", "drydown_endpoint", "wall_density"),
        ("dry bottom density", "drydown_endpoint", "bottom_density"),
        ("final deposit", "second_wet_endpoint", "deposit_fraction"),
        ("final total residue", "second_wet_endpoint", "total_fraction"),
    )
    ratios = np.full((len(pairs), len(metric_specs)), np.nan, dtype=float)
    for row, (_pair_id_value, upper, lower) in enumerate(pairs):
        for column, (_label, stage_name, metric) in enumerate(metric_specs):
            ratios[row, column] = (
                np.nan
                if (
                    value := _ratio(
                        _deposit_metric(lower, stage_name, metric),
                        _deposit_metric(upper, stage_name, metric),
                    )
                )
                is None
                else value
            )

    auxiliary = np.full((len(pairs), 3), np.nan, dtype=float)
    for row, (_pair_id_value, _upper, lower) in enumerate(pairs):
        for column, aliases in enumerate(
            (
                (
                    "eligible_wall_contact_fraction",
                    "accessible_wall_contact_fraction",
                ),
                (
                    "eligible_bottom_contact_fraction",
                    "accessible_bottom_contact_fraction",
                ),
                (
                    "unassigned_precursor_fraction",
                    "unattached_precursor_fraction",
                ),
            )
        ):
            value = _branch_fraction(lower, aliases)
            if value is not None:
                auxiliary[row, column] = value

    finite = ratios[np.isfinite(ratios)]
    color_max = max(2.0, float(np.max(finite, initial=1.0)))
    color_max = min(color_max, 4.0)
    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(
            1,
            2,
            figsize=(13.0, max(4.2, 0.58 * len(pairs) + 2.5)),
            gridspec_kw={"width_ratios": (1.45, 1.0)},
        )
        image = axes[0].imshow(
            np.clip(ratios, 0.0, color_max),
            aspect="auto",
            origin="upper",
            cmap=_RATIO_CMAP,
            vmin=0.0,
            vmax=color_max,
        )
        axes[0].set_xticks(
            np.arange(len(metric_specs)),
            [item[0] for item in metric_specs],
            rotation=25,
            ha="right",
        )
        axes[0].set_yticks(
            np.arange(len(pairs)),
            [
                _pair_label(upper, lower)
                for _pair_id_value, upper, lower in pairs
            ],
        )
        axes[0].set_title(
            "a  accessible / all-collector response ratio",
            loc="left",
            fontweight="semibold",
        )
        for row in range(ratios.shape[0]):
            for column in range(ratios.shape[1]):
                value = ratios[row, column]
                text = "NA" if not np.isfinite(value) else f"{value:.2f}"
                axes[0].text(
                    column,
                    row,
                    text,
                    ha="center",
                    va="center",
                    fontsize=6.5,
                    color=(
                        "white"
                        if np.isfinite(value)
                        and (value < 0.28 * color_max or value > 0.78 * color_max)
                        else "0.16"
                    ),
                )
        colorbar = figure.colorbar(image, ax=axes[0], fraction=0.045, pad=0.025)
        colorbar.set_label("accessible-only / all-collector")

        y = np.arange(len(pairs), dtype=float)
        offsets = (-0.22, 0.0, 0.22)
        labels = (
            "accessible wall contact",
            "accessible bottom contact",
            "unassigned precursor",
        )
        colors = ("#497F9D", "#D19A2A", "#9E4150")
        for column, (offset, label, color) in enumerate(
            zip(offsets, labels, colors, strict=True)
        ):
            values = auxiliary[:, column]
            valid = np.isfinite(values)
            axes[1].barh(
                y[valid] + offset,
                values[valid],
                height=0.18,
                color=color,
                label=label,
            )
        axes[1].set_xlim(0.0, max(1.02, float(np.nanmax(auxiliary, initial=1.0))))
        axes[1].set_yticks(y, [])
        axes[1].invert_yaxis()
        axes[1].set_xlabel("fraction")
        axes[1].set_title(
            "b  accessibility and rejected inventory",
            loc="left",
            fontweight="semibold",
        )
        axes[1].grid(axis="x", color="0.91", linewidth=0.45)
        axes[1].legend(loc="lower right")
        axes[1].spines[["top", "right"]].set_visible(False)

        policies = sorted(
            {
                str(_branch(lower).get("capture_policy", "not reported"))
                for _pair_id_value, _upper, lower in pairs
            }
        )
        figure.suptitle(
            "All-collector upper versus endpoint-liquid-accessible branch\n"
            f"capture policy: {', '.join(policies)}",
            y=0.995,
            fontsize=11.0,
        )
        figure.tight_layout(rect=(0.02, 0.25, 0.99, 0.91), w_pad=1.2)
        return _finish(figure, output_path, dpi=dpi, bottom=0.24)


def _spatial(stage: Mapping[str, Any]) -> Mapping[str, Any]:
    nested = _first(stage, ("spatial", "snapshot", "masks", "fields"))
    return nested if isinstance(nested, Mapping) else {}


def _spatial_arrays(
    stage: Mapping[str, Any],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None:
    spatial = _spatial(stage)
    try:
        x = np.asarray(_sequence(spatial.get("x_nm")), dtype=float)
        depth = np.asarray(_sequence(spatial.get("depth_nm")), dtype=float)
        cavity = np.asarray(spatial.get("cavity_mask"), dtype=bool)
        remaining = np.asarray(
            spatial.get("remaining_original_gap_fill_mask"), dtype=bool
        )
    except (TypeError, ValueError):
        return None
    if (
        x.ndim != 1
        or depth.ndim != 1
        or x.size < 1
        or depth.size < 1
        or cavity.shape != (depth.size, x.size)
        or remaining.shape != cavity.shape
        or not np.all(np.isfinite(x))
        or not np.all(np.isfinite(depth))
    ):
        return None
    wall = spatial.get("wall_deposit_thickness_nm")
    bottom = spatial.get("bottom_deposit_thickness_nm")
    try:
        wall_array = (
            np.zeros(cavity.shape, dtype=float)
            if wall is None
            else np.asarray(wall, dtype=float)
        )
        bottom_array = (
            np.zeros(cavity.shape, dtype=float)
            if bottom is None
            else np.asarray(bottom, dtype=float)
        )
    except (TypeError, ValueError):
        return None
    if wall_array.shape != cavity.shape or bottom_array.shape != cavity.shape:
        return None
    deposit = np.maximum(wall_array, 0.0) + np.maximum(bottom_array, 0.0)
    deposit[~np.isfinite(deposit)] = 0.0
    return x, depth, cavity, remaining, deposit


def _edges(values: np.ndarray) -> np.ndarray:
    if values.size == 1:
        return np.asarray([values[0] - 0.5, values[0] + 0.5])
    difference = np.diff(values)
    return np.concatenate(
        (
            [values[0] - 0.5 * difference[0]],
            values[:-1] + 0.5 * difference,
            [values[-1] + 0.5 * difference[-1]],
        )
    )


def _pair_spatial_score(
    pair: tuple[str, Mapping[str, Any], Mapping[str, Any]]
) -> int:
    return sum(
        _spatial_arrays(_stage(case, stage_name)) is not None
        for case in pair[1:]
        for stage_name, _label in _STAGES
    )


def _plot_spatial(
    axis: plt.Axes,
    stage: Mapping[str, Any],
    *,
    deposit_vmax: float,
) -> bool:
    arrays = _spatial_arrays(stage)
    if arrays is None:
        return False
    x, depth, cavity, remaining, deposit = arrays
    x_edges = _edges(x)
    depth_edges = _edges(depth)
    state = np.zeros(cavity.shape, dtype=np.uint8)
    state[cavity] = 1
    state[remaining] = 2
    axis.pcolormesh(
        x_edges,
        depth_edges,
        state,
        cmap=_MASK_CMAP,
        vmin=-0.5,
        vmax=2.5,
        shading="flat",
        rasterized=True,
    )
    positive = deposit > 0.0
    if np.any(positive) and deposit_vmax > 0.0:
        overlay = np.ma.masked_where(~positive, deposit)
        axis.pcolormesh(
            x_edges,
            depth_edges,
            overlay,
            cmap=_DEPOSIT_CMAP,
            norm=Normalize(vmin=0.0, vmax=deposit_vmax),
            shading="flat",
            rasterized=True,
        )
    axis.set_xlim(float(x_edges[0]), float(x_edges[-1]))
    axis.set_ylim(float(depth_edges[-1]), float(depth_edges[0]))
    axis.axhline(0.0, color="0.25", linewidth=0.5, linestyle=":")
    axis.set_aspect("auto")
    return True


def plot_calibrated_wet_sequence_masks(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_path: str | Path,
    *,
    dpi: int = 300,
) -> Path:
    """Plot four process stages for one complete paired collector comparison."""

    payload = _load_payload(payload_or_path)
    pairs = _paired_cases(_successful_cases(payload))
    pairs = [pair for pair in pairs if _pair_spatial_score(pair) > 0]
    if not pairs:
        return _no_data(
            output_path,
            title="Calibrated WET sequence morphology",
            message=(
                "Expected paired cases with stages[*].spatial physical-coordinate "
                "matrix masks and optional deposit-thickness fields."
            ),
            dpi=dpi,
        )
    preferred_id = payload.get("representative_pair_id")
    pair = next(
        (item for item in pairs if preferred_id is not None and item[0] == preferred_id),
        max(pairs, key=_pair_spatial_score),
    )
    _pair_id_value, upper, lower = pair
    branch_cases = (upper, lower)
    all_deposit = []
    for case in branch_cases:
        for stage_name, _label in _STAGES:
            arrays = _spatial_arrays(_stage(case, stage_name))
            if arrays is not None:
                all_deposit.append(arrays[-1])
    deposit_vmax = max(
        (float(np.max(field, initial=0.0)) for field in all_deposit),
        default=0.0,
    )

    with plt.rc_context(_STYLE):
        figure, axes = plt.subplots(
            len(_STAGES),
            2,
            figsize=(8.8, 10.8),
            squeeze=False,
        )
        for row, (stage_name, stage_label) in enumerate(_STAGES):
            for column, case in enumerate(branch_cases):
                axis = axes[row, column]
                stage = _stage(case, stage_name)
                plotted = _plot_spatial(
                    axis,
                    stage,
                    deposit_vmax=deposit_vmax,
                )
                if not plotted:
                    axis.set_axis_off()
                    axis.text(
                        0.5,
                        0.5,
                        "spatial stage not reported",
                        ha="center",
                        va="center",
                        transform=axis.transAxes,
                        color="0.38",
                    )
                time_s = _number(stage.get("cumulative_physical_time_s"))
                if row == 0:
                    axis.set_title(_branch_label(case), fontsize=8.5)
                if column == 0:
                    time_text = "" if time_s is None else f"\n{time_s / 60.0:.2f} min"
                    axis.set_ylabel(f"{stage_label}{time_text}\nDepth z (nm)")
                if row == len(_STAGES) - 1 and plotted:
                    axis.set_xlabel("Lateral position x (nm)")

        handles = [
            Patch(facecolor=_MASK_CMAP(0), edgecolor="0.5", label="outside trench"),
            Patch(facecolor=_MASK_CMAP(1), edgecolor="0.5", label="removed / liquid"),
            Patch(facecolor=_MASK_CMAP(2), edgecolor="0.5", label="original GAP FILL"),
        ]
        figure.legend(
            handles=handles,
            loc="upper center",
            bbox_to_anchor=(0.5, 0.925),
            ncol=3,
        )
        figure.subplots_adjust(
            left=0.11,
            right=0.88,
            bottom=0.16,
            top=0.82,
            hspace=0.36,
            wspace=0.13,
        )
        if deposit_vmax > 0.0:
            colorbar = figure.colorbar(
                ScalarMappable(
                    norm=Normalize(vmin=0.0, vmax=deposit_vmax),
                    cmap=_DEPOSIT_CMAP,
                ),
                ax=axes,
                fraction=0.018,
                pad=0.018,
            )
            colorbar.set_label("deposit thickness (nm)")
        figure.suptitle(
            f"Stage morphology — {_pair_label(upper)}",
            y=0.997,
            fontsize=10.7,
        )
        figure.text(
            0.5,
            0.955,
            "Horizontal direction enlarged for visibility; x and z ticks are "
            "physical nm (non-equal display aspect)",
            ha="center",
            va="top",
            fontsize=7.2,
            color="0.30",
        )
        return _finish(figure, output_path, dpi=dpi)


def plot_calibrated_wet_sequence_visualizations(
    payload_or_path: Mapping[str, Any] | str | Path,
    output_directory: str | Path,
    *,
    dpi: int = 300,
) -> dict[str, Path]:
    """Write the three standard calibrated WET-sequence PNG figures."""

    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    return {
        "calibrated_wet_stage_envelope": plot_calibrated_wet_stage_envelope(
            payload_or_path,
            directory / "calibrated_wet_stage_envelope.png",
            dpi=dpi,
        ),
        "collector_accessibility_comparison": (
            plot_collector_accessibility_comparison(
                payload_or_path,
                directory / "collector_accessibility_comparison.png",
                dpi=dpi,
            )
        ),
        "calibrated_wet_sequence_masks": plot_calibrated_wet_sequence_masks(
            payload_or_path,
            directory / "calibrated_wet_sequence_masks.png",
            dpi=dpi,
        ),
    }


__all__ = [
    "EXPECTED_PAYLOAD_KEYS",
    "SCHEMA_VERSION",
    "SCREENING_NOTICE",
    "expected_payload_keys",
    "plot_calibrated_wet_sequence_masks",
    "plot_calibrated_wet_sequence_visualizations",
    "plot_calibrated_wet_stage_envelope",
    "plot_collector_accessibility_comparison",
]

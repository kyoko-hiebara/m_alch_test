from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from literature_sweep import (
    LiteratureFirstOrderRateLaw,
    LiteratureSweepConfig,
    run_literature_case,
    run_literature_sweep,
)
from run_literature_sweep import main


class LiteratureSweepTests(unittest.TestCase):
    def test_linear_rate_law_scales_with_neutral_hf(self) -> None:
        law = LiteratureFirstOrderRateLaw(0.2, 250.0)
        reactant = np.asarray([[250.0, 125.0], [0.0, 250.0]])
        product = np.zeros_like(reactant)
        passivation = np.asarray([[0.0, 0.0], [0.0, 0.25]])
        interface = np.asarray([[True, True], [True, False]])
        velocity = law(reactant, product, passivation, interface)
        np.testing.assert_allclose(velocity, [[0.2, 0.1], [0.0, 0.0]])

    def test_flat_null_model_has_negligible_bulk_transport_loss(self) -> None:
        config = LiteratureSweepConfig(
            geometries=("10_8_180",),
            presets=("sin_barcellona_b_0p55wt",),
            include_2d=False,
        )
        payload = run_literature_sweep(config)
        case = payload["cases"][0]
        result = case["flat_1d"]
        self.assertTrue(result["completed"])
        self.assertGreater(result["bottom_neutral_hf_fraction_of_bulk"], 0.999)
        self.assertAlmostEqual(result["completion_over_planar"], 1.0, places=4)
        self.assertNotIn("continuum_2d", case)

    def test_sicn_fig2_prior_keeps_material_and_0p15_percent_transport(self) -> None:
        preset_id = "kawarazaki_sicn_c40_dhf0p15_linear30s"
        config = LiteratureSweepConfig(
            geometries=("10_8_180",),
            presets=(preset_id,),
            include_2d=False,
        )
        payload = run_literature_sweep(config)
        case = payload["cases"][0]
        self.assertEqual(case["material"], "SiCN")
        self.assertEqual(case["preset"]["planar_rate_nm_min"], 0.26)
        self.assertEqual(
            case["preset"]["transport_hf_weight_percent"],
            0.15,
        )
        self.assertIn("kawarazaki_2024", payload["source_classification"])

    def test_coarse_2d_case_completes_and_records_half_profile(self) -> None:
        config = LiteratureSweepConfig(
            geometries=("7_4p5_170",),
            presets=("siocn_fujitsu_4b_100to1",),
            grid_spacing_nm=5.0,
            reservoir_height_nm=5.0,
            maximum_history_points=12,
        )
        case = run_literature_case(
            "7_4p5_170", "siocn_fujitsu_4b_100to1", config
        )
        result = case["continuum_2d"]
        self.assertTrue(result["completed"])
        self.assertTrue(result["reactant_converged"])
        self.assertTrue(result["product_converged"])
        self.assertTrue(result["nonlinear_converged"])
        self.assertLessEqual(len(result["history"]), 12)
        self.assertGreater(
            result["remaining_mass_fraction_at_half_planar_time"], 0.25
        )
        self.assertLess(
            result["remaining_mass_fraction_at_half_planar_time"], 0.75
        )
        profile = result["profile_at_half_planar_time"]
        self.assertEqual(len(profile["depth_nm"]), len(profile["remaining_row_fraction"]))
        self.assertLess(result["maximum_front_mass_balance_relative_error"], 1.0e-10)

    def test_cli_writes_plain_json_and_keeps_temperatures_separate(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "literature.json"
            payload = main(
                [
                    "--geometry",
                    "10_8_180",
                    "--preset",
                    "sin_barcellona_b_0p55wt",
                    "--skip-2d",
                    "--solution-temperature-k",
                    "295",
                    "--substrate-temperature-k",
                    "320",
                    "--output",
                    str(output),
                ]
            )
            saved = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(saved, payload)
            temperatures = saved["cases"][0]["boundary_temperatures_K"]
            self.assertEqual(temperatures["solution_bulk"], 295.0)
            self.assertEqual(temperatures["substrate_backside"], 320.0)
            self.assertFalse(saved["calibrated_for_deep_trench"])

    def test_process_parallel_cases_match_serial_order_and_values(self) -> None:
        common = dict(
            geometries=("10_8_180", "7_4p5_170"),
            presets=(
                "sin_barcellona_b_0p55wt",
                "siocn_fujitsu_4b_100to1",
            ),
            include_2d=False,
        )
        serial = run_literature_sweep(
            LiteratureSweepConfig(**common, parallel_workers=1)
        )
        parallel = run_literature_sweep(
            LiteratureSweepConfig(**common, parallel_workers=2)
        )
        self.assertEqual(
            [case["case_id"] for case in serial["cases"]],
            [case["case_id"] for case in parallel["cases"]],
        )
        for expected, actual in zip(
            serial["cases"], parallel["cases"], strict=True
        ):
            self.assertEqual(expected, actual)
        self.assertEqual(
            parallel["parallel_execution"]["effective_workers"], 2
        )


if __name__ == "__main__":
    unittest.main()

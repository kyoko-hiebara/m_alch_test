"""Flat-front 1-D model for top-down removal of a tapered trench gap fill.

At ``t = 0`` the trench is fully filled with solid and the liquid domain has
zero depth.  A horizontal solid--liquid interface then moves from the opening
towards the bottom.  Reactant and dissolved product are treated as
quasi-steady in the liquid above that front.  Their exact tapered-channel
diffusion resistances are combined with first-order interface kinetics.

This is a screening model, not an atomistic reaction model.  The transported
reactant concentration should therefore be interpreted as the concentration
of the effective reactive HF species supplied by a separate speciation model.
All calculations use SI units; ``front_depth_nm`` is provided only as a result
convenience property.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.integrate import solve_ivp

from etch_process import EtchProcessConfig
from numerical_settings import LOOSE_NUMERICS
from thermal_model import (
    InterfaceThermalState,
    NM_TO_M,
    ThermalResistanceModel,
    inverse_width_integral,
)


GAS_CONSTANT_J_MOL_K = 8.31446261815324


def _finite_positive(name: str, value: float) -> None:
    if not math.isfinite(value) or value <= 0.0:
        raise ValueError(f"{name} must be finite and positive")


def _finite_nonnegative(name: str, value: float) -> None:
    if not math.isfinite(value) or value < 0.0:
        raise ValueError(f"{name} must be finite and non-negative")


def _optional_finite_positive(name: str, value: float | None) -> None:
    if value is not None:
        _finite_positive(name, float(value))


def _arrhenius_value(
    reference_value: float,
    activation_energy_J_mol: float,
    temperature_K: float,
    reference_temperature_K: float,
) -> float:
    """Return a reference-temperature Arrhenius correction."""

    if reference_value == 0.0:
        return 0.0
    exponent = -activation_energy_J_mol / GAS_CONSTANT_J_MOL_K * (
        1.0 / temperature_K - 1.0 / reference_temperature_K
    )
    if exponent > 700.0:
        raise ValueError("Arrhenius parameters overflow at the local temperature")
    return reference_value * math.exp(exponent)


@dataclass(frozen=True)
class MassTransportParameters:
    """Bulk concentrations, diffusivities, and optional mouth-film transfer."""

    reactant_bulk_concentration_mol_m3: float
    reactant_diffusivity_ref_m2_s: float = 1.0e-9
    product_diffusivity_ref_m2_s: float = 1.0e-9
    product_bulk_concentration_mol_m3: float = 0.0
    reference_temperature_K: float = 298.15
    reactant_diffusion_activation_energy_J_mol: float = 0.0
    product_diffusion_activation_energy_J_mol: float = 0.0
    reactant_boundary_mass_transfer_coefficient_m_s: float | None = None
    product_boundary_mass_transfer_coefficient_m_s: float | None = None

    def __post_init__(self) -> None:
        for name in (
            "reactant_bulk_concentration_mol_m3",
            "product_bulk_concentration_mol_m3",
            "reactant_diffusion_activation_energy_J_mol",
            "product_diffusion_activation_energy_J_mol",
        ):
            _finite_nonnegative(name, float(getattr(self, name)))
        for name in (
            "reactant_diffusivity_ref_m2_s",
            "product_diffusivity_ref_m2_s",
            "reference_temperature_K",
        ):
            _finite_positive(name, float(getattr(self, name)))
        _optional_finite_positive(
            "reactant_boundary_mass_transfer_coefficient_m_s",
            self.reactant_boundary_mass_transfer_coefficient_m_s,
        )
        _optional_finite_positive(
            "product_boundary_mass_transfer_coefficient_m_s",
            self.product_boundary_mass_transfer_coefficient_m_s,
        )


@dataclass(frozen=True)
class InterfaceKinetics:
    """First-order etch kinetics and solid/reactant stoichiometry.

    ``reaction_heat_release_J_mol_solid`` is positive for an exothermic
    reaction and negative for an endothermic one.
    """

    rate_constant_ref_m_s: float
    solid_molar_density_mol_m3: float
    reactant_stoichiometry_mol_per_mol_solid: float = 1.0
    product_yield_mol_per_mol_solid: float = 1.0
    activation_energy_J_mol: float = 0.0
    reference_temperature_K: float = 298.15
    reaction_heat_release_J_mol_solid: float = 0.0

    def __post_init__(self) -> None:
        _finite_nonnegative("rate_constant_ref_m_s", self.rate_constant_ref_m_s)
        for name in (
            "solid_molar_density_mol_m3",
            "reactant_stoichiometry_mol_per_mol_solid",
            "reference_temperature_K",
        ):
            _finite_positive(name, float(getattr(self, name)))
        for name in ("product_yield_mol_per_mol_solid", "activation_energy_J_mol"):
            _finite_nonnegative(name, float(getattr(self, name)))
        if not math.isfinite(self.reaction_heat_release_J_mol_solid):
            raise ValueError("reaction_heat_release_J_mol_solid must be finite")


@dataclass(frozen=True)
class PassivationParameters:
    """Reversible product-assisted blocking of interface sites."""

    initial_fraction: float = 0.0
    formation_rate_ref_s_inv: float = 0.0
    removal_rate_ref_s_inv: float = 0.0
    product_reference_concentration_mol_m3: float = 1.0
    product_order: float = 1.0
    formation_activation_energy_J_mol: float = 0.0
    removal_activation_energy_J_mol: float = 0.0
    reference_temperature_K: float = 298.15

    def __post_init__(self) -> None:
        if (
            not math.isfinite(self.initial_fraction)
            or self.initial_fraction < 0.0
            or self.initial_fraction > 1.0
        ):
            raise ValueError("initial_fraction must be finite and within [0, 1]")
        for name in (
            "formation_rate_ref_s_inv",
            "removal_rate_ref_s_inv",
            "product_order",
            "formation_activation_energy_J_mol",
            "removal_activation_energy_J_mol",
        ):
            _finite_nonnegative(name, float(getattr(self, name)))
        for name in (
            "product_reference_concentration_mol_m3",
            "reference_temperature_K",
        ):
            _finite_positive(name, float(getattr(self, name)))


@dataclass(frozen=True)
class IntegrationOptions:
    """Adaptive RK45 controls; defaults follow the shared loose settings."""

    relative_tolerance: float = LOOSE_NUMERICS.linear_relative_tolerance
    absolute_tolerance: float = LOOSE_NUMERICS.linear_absolute_tolerance
    maximum_time_step_s: float = LOOSE_NUMERICS.maximum_time_step_s
    first_time_step_s: float | None = None
    thermal_coupling_relative_tolerance: float = (
        LOOSE_NUMERICS.nonlinear_relative_tolerance
    )
    maximum_thermal_iterations: int = LOOSE_NUMERICS.maximum_nonlinear_iterations

    def __post_init__(self) -> None:
        for name in (
            "relative_tolerance",
            "absolute_tolerance",
            "maximum_time_step_s",
            "thermal_coupling_relative_tolerance",
        ):
            _finite_positive(name, float(getattr(self, name)))
        _optional_finite_positive("first_time_step_s", self.first_time_step_s)
        if self.maximum_thermal_iterations < 1:
            raise ValueError("maximum_thermal_iterations must be positive")


@dataclass(frozen=True)
class FlatFrontLocalState:
    """Algebraic quasi-steady state at one front location."""

    front_depth_m: float
    front_width_m: float
    passivation_fraction: float
    interface_temperature_K: float
    effective_liquid_temperature_K: float
    reactant_diffusivity_m2_s: float
    product_diffusivity_m2_s: float
    reactant_transport_resistance_s_m2: float
    product_transport_resistance_s_m2: float
    reactant_interface_concentration_mol_m3: float
    product_interface_concentration_mol_m3: float
    reactant_flux_mol_m2_s: float
    solid_removal_flux_mol_m2_s: float
    product_flux_mol_m2_s: float
    etch_velocity_m_s: float
    passivation_rate_s_inv: float
    reaction_heat_flux_W_m2: float
    thermal_state: InterfaceThermalState


@dataclass(frozen=True)
class FlatFrontEtchResult:
    """Adaptive time history returned by :meth:`FlatFrontEtchSolver.solve`."""

    time_s: np.ndarray
    front_depth_m: np.ndarray
    front_fraction: np.ndarray
    residual_fill_depth_m: np.ndarray
    front_width_m: np.ndarray
    passivation_fraction: np.ndarray
    interface_temperature_K: np.ndarray
    effective_liquid_temperature_K: np.ndarray
    reactant_diffusivity_m2_s: np.ndarray
    product_diffusivity_m2_s: np.ndarray
    reactant_interface_concentration_mol_m3: np.ndarray
    product_interface_concentration_mol_m3: np.ndarray
    reactant_transport_resistance_s_m2: np.ndarray
    product_transport_resistance_s_m2: np.ndarray
    reactant_flux_mol_m2_s: np.ndarray
    solid_removal_flux_mol_m2_s: np.ndarray
    product_flux_mol_m2_s: np.ndarray
    etch_velocity_m_s: np.ndarray
    passivation_rate_s_inv: np.ndarray
    reaction_heat_flux_W_m2: np.ndarray
    completed: bool
    completion_time_s: float | None
    solver_message: str

    @property
    def front_depth_nm(self) -> np.ndarray:
        return self.front_depth_m / NM_TO_M

    @property
    def residual_fill_depth_nm(self) -> np.ndarray:
        return self.residual_fill_depth_m / NM_TO_M


class FlatFrontEtchSolver:
    """Couple tapered mass transfer, interface kinetics, passivation, and heat."""

    def __init__(
        self,
        process: EtchProcessConfig,
        thermal_model: ThermalResistanceModel,
        transport: MassTransportParameters,
        kinetics: InterfaceKinetics,
        passivation: PassivationParameters | None = None,
        options: IntegrationOptions | None = None,
    ) -> None:
        if thermal_model.geometry != process.geometry:
            raise ValueError("thermal_model and process must use the same geometry")
        self.process = process
        self.thermal_model = thermal_model
        self.transport = transport
        self.kinetics = kinetics
        self.passivation = passivation or PassivationParameters()
        self.options = options or IntegrationOptions()
        self._height_m = process.geometry.depth_nm * NM_TO_M
        self._top_width_m = process.geometry.top_width_nm * NM_TO_M

    def _boundary_mass_resistance_s_m2(
        self,
        coefficient_m_s: float | None,
    ) -> float:
        if coefficient_m_s is None:
            return 0.0
        return 1.0 / (coefficient_m_s * self._top_width_m)

    def _mass_and_reaction_state(
        self,
        front_depth_m: float,
        passivation_fraction: float,
        thermal_state: InterfaceThermalState,
    ) -> dict[str, float]:
        temperature = thermal_state.interface_temperature_K
        liquid_temperature = 0.5 * (
            self.process.thermal_bc.solution_bulk_temperature_K + temperature
        )
        tr = self.transport
        kin = self.kinetics
        geometry = self.process.geometry
        front_width = float(
            geometry.width_at_depth_nm(front_depth_m / NM_TO_M)
        ) * NM_TO_M

        reactant_diffusivity = _arrhenius_value(
            tr.reactant_diffusivity_ref_m2_s,
            tr.reactant_diffusion_activation_energy_J_mol,
            liquid_temperature,
            tr.reference_temperature_K,
        )
        product_diffusivity = _arrhenius_value(
            tr.product_diffusivity_ref_m2_s,
            tr.product_diffusion_activation_energy_J_mol,
            liquid_temperature,
            tr.reference_temperature_K,
        )
        shape_resistance = inverse_width_integral(
            geometry, 0.0, front_depth_m
        )
        reactant_resistance = (
            shape_resistance / reactant_diffusivity
            + self._boundary_mass_resistance_s_m2(
                tr.reactant_boundary_mass_transfer_coefficient_m_s
            )
        )
        product_resistance = (
            shape_resistance / product_diffusivity
            + self._boundary_mass_resistance_s_m2(
                tr.product_boundary_mass_transfer_coefficient_m_s
            )
        )

        intrinsic_rate_constant = _arrhenius_value(
            kin.rate_constant_ref_m_s,
            kin.activation_energy_J_mol,
            temperature,
            kin.reference_temperature_K,
        )
        active_rate_constant = intrinsic_rate_constant * (
            1.0 - passivation_fraction
        )
        transport_modulus = active_rate_constant * front_width * reactant_resistance
        reactant_interface_concentration = (
            tr.reactant_bulk_concentration_mol_m3 / (1.0 + transport_modulus)
        )
        reactant_flux = active_rate_constant * reactant_interface_concentration
        solid_flux = reactant_flux / kin.reactant_stoichiometry_mol_per_mol_solid
        product_flux = solid_flux * kin.product_yield_mol_per_mol_solid
        product_interface_concentration = (
            tr.product_bulk_concentration_mol_m3
            + product_flux * front_width * product_resistance
        )
        velocity = solid_flux / kin.solid_molar_density_mol_m3

        return {
            "front_width_m": front_width,
            "effective_liquid_temperature_K": liquid_temperature,
            "reactant_diffusivity_m2_s": reactant_diffusivity,
            "product_diffusivity_m2_s": product_diffusivity,
            "reactant_transport_resistance_s_m2": reactant_resistance,
            "product_transport_resistance_s_m2": product_resistance,
            "reactant_interface_concentration_mol_m3": (
                reactant_interface_concentration
            ),
            "product_interface_concentration_mol_m3": (
                product_interface_concentration
            ),
            "reactant_flux_mol_m2_s": reactant_flux,
            "solid_removal_flux_mol_m2_s": solid_flux,
            "product_flux_mol_m2_s": product_flux,
            "etch_velocity_m_s": velocity,
        }

    def local_state(
        self,
        front_depth_m: float,
        passivation_fraction: float,
    ) -> FlatFrontLocalState:
        """Evaluate all algebraic quantities at a front depth and coverage."""

        depth = float(front_depth_m)
        fraction = float(passivation_fraction)
        if not math.isfinite(fraction) or fraction < 0.0 or fraction > 1.0:
            raise ValueError("passivation_fraction must be finite and within [0, 1]")
        # The thermal model performs the depth validation and clipping.
        depth = self.thermal_model.resistances(depth).front_depth_m

        heat_flux = 0.0
        mass_state: dict[str, float] | None = None
        thermal_state: InterfaceThermalState | None = None
        heat_release = self.kinetics.reaction_heat_release_J_mol_solid
        for iteration in range(self.options.maximum_thermal_iterations):
            thermal_state = self.thermal_model.evaluate(
                depth,
                self.process.thermal_bc,
                reaction_heat_flux_W_m2=heat_flux,
            )
            mass_state = self._mass_and_reaction_state(depth, fraction, thermal_state)
            target_heat_flux = (
                heat_release * mass_state["solid_removal_flux_mol_m2_s"]
            )
            scale = max(abs(target_heat_flux), abs(heat_flux), 1.0e-30)
            if abs(target_heat_flux - heat_flux) <= (
                self.options.thermal_coupling_relative_tolerance * scale
            ):
                heat_flux = target_heat_flux
                thermal_state = self.thermal_model.evaluate(
                    depth,
                    self.process.thermal_bc,
                    reaction_heat_flux_W_m2=heat_flux,
                )
                mass_state = self._mass_and_reaction_state(
                    depth, fraction, thermal_state
                )
                break
            # Under-relaxation prevents a strong Arrhenius response from
            # oscillating between the two thermal branches.
            heat_flux = 0.5 * (heat_flux + target_heat_flux)
        else:
            raise RuntimeError(
                "reaction-heat/interface-temperature coupling did not converge"
            )

        assert mass_state is not None and thermal_state is not None
        p = self.passivation
        temperature = thermal_state.interface_temperature_K
        formation_coefficient = _arrhenius_value(
            p.formation_rate_ref_s_inv,
            p.formation_activation_energy_J_mol,
            temperature,
            p.reference_temperature_K,
        )
        removal_coefficient = _arrhenius_value(
            p.removal_rate_ref_s_inv,
            p.removal_activation_energy_J_mol,
            temperature,
            p.reference_temperature_K,
        )
        product_activity = (
            mass_state["product_interface_concentration_mol_m3"]
            / p.product_reference_concentration_mol_m3
        ) ** p.product_order
        passivation_rate = (
            formation_coefficient * product_activity * (1.0 - fraction)
            - removal_coefficient * fraction
        )

        return FlatFrontLocalState(
            front_depth_m=depth,
            front_width_m=mass_state["front_width_m"],
            passivation_fraction=fraction,
            interface_temperature_K=temperature,
            effective_liquid_temperature_K=(
                mass_state["effective_liquid_temperature_K"]
            ),
            reactant_diffusivity_m2_s=mass_state["reactant_diffusivity_m2_s"],
            product_diffusivity_m2_s=mass_state["product_diffusivity_m2_s"],
            reactant_transport_resistance_s_m2=(
                mass_state["reactant_transport_resistance_s_m2"]
            ),
            product_transport_resistance_s_m2=(
                mass_state["product_transport_resistance_s_m2"]
            ),
            reactant_interface_concentration_mol_m3=(
                mass_state["reactant_interface_concentration_mol_m3"]
            ),
            product_interface_concentration_mol_m3=(
                mass_state["product_interface_concentration_mol_m3"]
            ),
            reactant_flux_mol_m2_s=mass_state["reactant_flux_mol_m2_s"],
            solid_removal_flux_mol_m2_s=(
                mass_state["solid_removal_flux_mol_m2_s"]
            ),
            product_flux_mol_m2_s=mass_state["product_flux_mol_m2_s"],
            etch_velocity_m_s=mass_state["etch_velocity_m_s"],
            passivation_rate_s_inv=passivation_rate,
            reaction_heat_flux_W_m2=heat_flux,
            thermal_state=thermal_state,
        )

    @staticmethod
    def _readonly(values: np.ndarray | list[float]) -> np.ndarray:
        result = np.asarray(values, dtype=float)
        result.setflags(write=False)
        return result

    def solve(self, maximum_time_s: float) -> FlatFrontEtchResult:
        """Integrate until the bottom is reached or ``maximum_time_s`` expires."""

        end_time = float(maximum_time_s)
        _finite_positive("maximum_time_s", end_time)

        def rhs(_time_s: float, state: np.ndarray) -> np.ndarray:
            raw_front_fraction = float(state[0])
            front_fraction = min(max(raw_front_fraction, 0.0), 1.0)
            passivation_fraction = min(max(float(state[1]), 0.0), 1.0)
            local = self.local_state(
                front_fraction * self._height_m,
                passivation_fraction,
            )
            front_rate = local.etch_velocity_m_s / self._height_m
            # Keep the derivative continuous through the terminal root.  The
            # event stops integration at front_fraction == 1; forcing the RHS
            # to zero in RK stages that briefly overshoot the root biases the
            # interpolated completion time by a step-size-dependent amount.
            passivation_rate = local.passivation_rate_s_inv
            if state[1] <= 0.0 and passivation_rate < 0.0:
                passivation_rate = 0.0
            elif state[1] >= 1.0 and passivation_rate > 0.0:
                passivation_rate = 0.0
            return np.asarray([front_rate, passivation_rate], dtype=float)

        def bottom_event(_time_s: float, state: np.ndarray) -> float:
            return float(state[0] - 1.0)

        bottom_event.terminal = True  # type: ignore[attr-defined]
        bottom_event.direction = 1.0  # type: ignore[attr-defined]

        solve_kwargs: dict[str, float] = {
            "rtol": self.options.relative_tolerance,
            "atol": self.options.absolute_tolerance,
            "max_step": self.options.maximum_time_step_s,
        }
        if self.options.first_time_step_s is not None:
            solve_kwargs["first_step"] = min(
                self.options.first_time_step_s,
                end_time,
            )
        solution = solve_ivp(
            rhs,
            (0.0, end_time),
            np.asarray([0.0, self.passivation.initial_fraction], dtype=float),
            method="RK45",
            events=bottom_event,
            **solve_kwargs,
        )
        if not solution.success:
            raise RuntimeError(f"adaptive integration failed: {solution.message}")

        front_fraction = np.clip(solution.y[0], 0.0, 1.0)
        passivation_fraction = np.clip(solution.y[1], 0.0, 1.0)
        front_depth = front_fraction * self._height_m
        local_states = [
            self.local_state(float(depth), float(coverage))
            for depth, coverage in zip(front_depth, passivation_fraction, strict=True)
        ]

        completed = bool(solution.t_events[0].size)
        completion_time = (
            float(solution.t_events[0][0]) if completed else None
        )

        def history(attribute: str) -> np.ndarray:
            return self._readonly(
                [float(getattr(item, attribute)) for item in local_states]
            )

        return FlatFrontEtchResult(
            time_s=self._readonly(solution.t),
            front_depth_m=self._readonly(front_depth),
            front_fraction=self._readonly(front_fraction),
            residual_fill_depth_m=self._readonly(self._height_m - front_depth),
            front_width_m=history("front_width_m"),
            passivation_fraction=self._readonly(passivation_fraction),
            interface_temperature_K=history("interface_temperature_K"),
            effective_liquid_temperature_K=history(
                "effective_liquid_temperature_K"
            ),
            reactant_diffusivity_m2_s=history("reactant_diffusivity_m2_s"),
            product_diffusivity_m2_s=history("product_diffusivity_m2_s"),
            reactant_interface_concentration_mol_m3=history(
                "reactant_interface_concentration_mol_m3"
            ),
            product_interface_concentration_mol_m3=history(
                "product_interface_concentration_mol_m3"
            ),
            reactant_transport_resistance_s_m2=history(
                "reactant_transport_resistance_s_m2"
            ),
            product_transport_resistance_s_m2=history(
                "product_transport_resistance_s_m2"
            ),
            reactant_flux_mol_m2_s=history("reactant_flux_mol_m2_s"),
            solid_removal_flux_mol_m2_s=history(
                "solid_removal_flux_mol_m2_s"
            ),
            product_flux_mol_m2_s=history("product_flux_mol_m2_s"),
            etch_velocity_m_s=history("etch_velocity_m_s"),
            passivation_rate_s_inv=history("passivation_rate_s_inv"),
            reaction_heat_flux_W_m2=history("reaction_heat_flux_W_m2"),
            completed=completed,
            completion_time_s=completion_time,
            solver_message=str(solution.message),
        )

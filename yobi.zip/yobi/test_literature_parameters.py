from __future__ import annotations

import unittest

from literature_parameters import (
    KAWARAZAKI_2024_FIG2_ENDPOINTS,
    LITERATURE_ETCH_PRESETS,
    get_cyclic_etch_endpoint,
    get_literature_preset,
    hf_speciation_298K_from_weight_percent,
    silicon_thermal_conductivity_W_mK,
)


class LiteratureParameterTests(unittest.TestCase):
    def test_hf_table_interpolation_preserves_fluorine_inventory(self) -> None:
        state = hf_speciation_298K_from_weight_percent(0.55)
        reconstructed = (
            state.neutral_hf_mol_m3
            + state.fluoride_mol_m3
            + 2.0 * state.bifluoride_mol_m3
        )
        self.assertAlmostEqual(
            reconstructed,
            state.analytical_fluorine_mol_m3,
            places=10,
        )
        self.assertGreater(state.analytical_fluorine_mol_m3, 270.0)
        self.assertLess(state.neutral_hf_mol_m3, state.analytical_fluorine_mol_m3)
        with self.assertRaises(ValueError):
            hf_speciation_298K_from_weight_percent(5.0)

    def test_direct_rate_conversions_are_exact(self) -> None:
        expected_nm_min = {
            "sin_barcellona_a_0p55wt": 1.3,
            "sin_barcellona_b_0p55wt": 2.2,
            "sin_barcellona_c_0p55wt": 4.0,
            "siocn_fujitsu_4a_100to1": 0.16,
            "siocn_fujitsu_4b_100to1": 0.38,
            "siocn_fujitsu_4d_100to1": 0.92,
            "kawarazaki_sicn_c22_dhf0p15_linear30s": 0.06,
            "kawarazaki_sicn_c40_dhf0p15_linear30s": 0.26,
            "kawarazaki_siocn_c5_dhf0p15_linear30s": 0.50,
            "kawarazaki_sin_reference_dhf0p15_linear30s": 0.08,
        }
        self.assertEqual(set(expected_nm_min), set(LITERATURE_ETCH_PRESETS))
        for name, rate in expected_nm_min.items():
            with self.subTest(name=name):
                preset = get_literature_preset(name)
                self.assertEqual(preset.planar_rate_nm_min, rate)
                self.assertAlmostEqual(preset.planar_rate_nm_s, rate / 60.0)

    def test_kawarazaki_endpoints_preserve_raw_and_derived_values(self) -> None:
        self.assertEqual(
            set(KAWARAZAKI_2024_FIG2_ENDPOINTS),
            {
                "kawarazaki_sicn_c22",
                "kawarazaki_sicn_c40",
                "kawarazaki_siocn_c5",
                "kawarazaki_sin_reference",
            },
        )
        c22 = get_cyclic_etch_endpoint("kawarazaki_sicn_c22")
        self.assertEqual(c22.material, "SiCN")
        self.assertEqual(c22.dhf_only_etch_amount_nm, 0.03)
        self.assertEqual(c22.ozone_then_dhf_etch_amount_nm, 2.47)
        self.assertAlmostEqual(c22.dhf_only_apparent_rate_nm_min, 0.06)
        self.assertAlmostEqual(
            c22.ozone_enabled_increment_nm_per_cycle,
            2.44,
        )
        self.assertAlmostEqual(c22.predict_dhf_only_etch_nm(120.0), 0.12)
        self.assertAlmostEqual(c22.predict_ozone_dhf_etch_nm(3), 7.41)
        self.assertIn("raster", c22.value_basis)
        self.assertIn("linear", c22.linearity_assumption)
        with self.assertRaises(ValueError):
            c22.predict_dhf_only_etch_nm(-1.0)
        with self.assertRaises(ValueError):
            c22.predict_ozone_dhf_etch_nm(1.5)  # type: ignore[arg-type]

    def test_robin_transfer_closes_effective_reactant_inventory(self) -> None:
        for preset in LITERATURE_ETCH_PRESETS.values():
            with self.subTest(preset=preset.key):
                concentration = preset.hf_speciation().neutral_hf_mol_m3
                reconstructed_velocity = (
                    preset.first_order_surface_transfer_nm_s()
                    * concentration
                    / (
                        preset.solid_si_site_density_mol_m3
                        * preset.effective_hf_per_si
                    )
                )
                self.assertAlmostEqual(
                    reconstructed_velocity,
                    preset.planar_rate_nm_s,
                    places=14,
                )

    def test_silicon_thermal_conductivity_interpolation(self) -> None:
        self.assertEqual(silicon_thermal_conductivity_W_mK(298.2), 149.0)
        self.assertEqual(silicon_thermal_conductivity_W_mK(323.2), 133.0)
        self.assertAlmostEqual(
            silicon_thermal_conductivity_W_mK(310.7), 141.0
        )

    def test_unknown_preset_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            get_literature_preset("generic_SiN")


if __name__ == "__main__":
    unittest.main()
